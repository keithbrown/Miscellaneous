XML Music Player w/ ActionScript 3
______________________________________________________________
--------------------------------------------------------------
Created by Craig Campbell
--------------------------------------------------------------
--------------------------------------------------------------
School of Flash - Flash Tutorials, News, Freebies, and Blather
--------------------------------------------------------------
--------------------------------------------------------------
http://www.schoolofflash.com

Be sure to keep all files in the same folder structure as the zip file.


To update playlist:
1. Add mp3 files to the "songs" folder.
2. Update the jukebox.xml file with the songs you want to play on your website.
   Use the current jukebox.xml file as an example of the structure of the document.
   (You can add as many songs to the playlist as you would like.)
3. Stop by http://www.schoolofflash.com and let me know what you think!