-- root-types-contained: SystemModel_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.5

INSERT INTO S_SYS
	VALUES ("ecb50217-b066-4ecf-a826-866ec62dc0da",
	's2');
INSERT INTO S_DOM
	VALUES ("0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'sudoku',
	'',
	0,
	"00000000-0000-0000-0000-000000000001",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO S_DPK
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	'Datatypes',
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"606ca061-c661-4bbf-bb1a-bb2345f5239e");
INSERT INTO S_DT
	VALUES ("606ca061-c661-4bbf-bb1a-bb2345f5239e",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("606ca061-c661-4bbf-bb1a-bb2345f5239e",
	0);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"4e005777-df64-4279-9c02-400e239872b9");
INSERT INTO S_DT
	VALUES ("4e005777-df64-4279-9c02-400e239872b9",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("4e005777-df64-4279-9c02-400e239872b9",
	1);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO S_DT
	VALUES ("811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("811f1dd7-74f0-407e-b449-939d0de5ee8d",
	2);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"6eb4ed0f-02b6-4ccc-82c4-b1c3ff6b05c1");
INSERT INTO S_DT
	VALUES ("6eb4ed0f-02b6-4ccc-82c4-b1c3ff6b05c1",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("6eb4ed0f-02b6-4ccc-82c4-b1c3ff6b05c1",
	3);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c");
INSERT INTO S_DT
	VALUES ("e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	4);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"4b663f44-4e7f-4028-addc-989073553ced");
INSERT INTO S_DT
	VALUES ("4b663f44-4e7f-4028-addc-989073553ced",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("4b663f44-4e7f-4028-addc-989073553ced",
	5);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"ea4f2014-da78-4798-8130-991e8750cff6");
INSERT INTO S_DT
	VALUES ("ea4f2014-da78-4798-8130-991e8750cff6",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ea4f2014-da78-4798-8130-991e8750cff6",
	6);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"1a418377-64f4-47d9-aa0e-0773ca94143a");
INSERT INTO S_DT
	VALUES ("1a418377-64f4-47d9-aa0e-0773ca94143a",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("1a418377-64f4-47d9-aa0e-0773ca94143a",
	7);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO S_DT
	VALUES ("1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("1a2907d2-496f-482d-ba4d-df818f73d6fa",
	8);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO S_DT
	VALUES ("bd7c827f-c0a0-4115-8268-33db6654fef9",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("bd7c827f-c0a0-4115-8268-33db6654fef9",
	9);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"444f9fb0-5d90-49ca-b343-ec1f06cd8ceb");
INSERT INTO S_DT
	VALUES ("444f9fb0-5d90-49ca-b343-ec1f06cd8ceb",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("444f9fb0-5d90-49ca-b343-ec1f06cd8ceb",
	10);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"d10decc3-81df-4ded-b2d6-8c9c049ea18b");
INSERT INTO S_DT
	VALUES ("d10decc3-81df-4ded-b2d6-8c9c049ea18b",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("d10decc3-81df-4ded-b2d6-8c9c049ea18b",
	11);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"4a115d6e-8f4c-4a02-8278-658751ab184a");
INSERT INTO S_DT
	VALUES ("4a115d6e-8f4c-4a02-8278-658751ab184a",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("4a115d6e-8f4c-4a02-8278-658751ab184a",
	12);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"3181e074-fe1b-4d6e-9a56-0d67d162a34e");
INSERT INTO S_DT
	VALUES ("3181e074-fe1b-4d6e-9a56-0d67d162a34e",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'date',
	'Time as known in the external world. For example, 12 October 1492,
13:25:10. The accuracy of external time is dependent on the architecture and
implementation.',
	'');
INSERT INTO S_UDT
	VALUES ("3181e074-fe1b-4d6e-9a56-0d67d162a34e",
	"d10decc3-81df-4ded-b2d6-8c9c049ea18b",
	1);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"a655f816-965c-407d-b502-1f645579c6c8");
INSERT INTO S_DT
	VALUES ("a655f816-965c-407d-b502-1f645579c6c8",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'timestamp',
	' The system clock counts time in ticks. The size of a tick is dependent on the
 architecture and implementation.',
	'');
INSERT INTO S_UDT
	VALUES ("a655f816-965c-407d-b502-1f645579c6c8",
	"d10decc3-81df-4ded-b2d6-8c9c049ea18b",
	2);
INSERT INTO S_DIP
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"7f209d5f-cba1-401d-827f-d2a1a8ca5694");
INSERT INTO S_DT
	VALUES ("7f209d5f-cba1-401d-827f-d2a1a8ca5694",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("7f209d5f-cba1-401d-827f-d2a1a8ca5694",
	"4a115d6e-8f4c-4a02-8278-658751ab184a",
	3);
INSERT INTO EP_SPKG
	VALUES ("5ca49327-ab45-401d-a1b3-b1f8ac839213",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_EEPK
	VALUES ("c7dc2569-bca7-4e80-bed9-f96b7fcd0883",
	'External Entities',
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_EEPIP
	VALUES ("c7dc2569-bca7-4e80-bed9-f96b7fcd0883");
INSERT INTO PL_EEPID
	VALUES ("0eb5e6c3-13b6-4550-b154-5d6824e51255",
	"c7dc2569-bca7-4e80-bed9-f96b7fcd0883");
INSERT INTO S_EEIP
	VALUES ("c7dc2569-bca7-4e80-bed9-f96b7fcd0883",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6");
INSERT INTO S_EE
	VALUES ("1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'Time',
	'The Time external entity provides date, timestamp, and timer related operations.',
	'TIM',
	"0eb5e6c3-13b6-4550-b154-5d6824e51255");
INSERT INTO S_BRG
	VALUES ("beb5738b-a376-46d9-b908-3e6504216ae5",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'current_date',
	'',
	0,
	"3181e074-fe1b-4d6e-9a56-0d67d162a34e",
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES ("5bb102b8-f82c-44fa-9a14-07c9be20832a",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'create_date',
	'',
	0,
	"3181e074-fe1b-4d6e-9a56-0d67d162a34e",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("241bde56-b8af-4303-b324-01a3341288be",
	"5bb102b8-f82c-44fa-9a14-07c9be20832a",
	'second',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"8f9326cf-5a06-4b42-8260-25d0d243814f",
	'');
INSERT INTO S_BPARM
	VALUES ("28d88787-e576-4872-a489-ad6a8baa5701",
	"5bb102b8-f82c-44fa-9a14-07c9be20832a",
	'minute',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"a7e3a808-4461-48f8-aa96-5248feea15f1",
	'');
INSERT INTO S_BPARM
	VALUES ("a7e3a808-4461-48f8-aa96-5248feea15f1",
	"5bb102b8-f82c-44fa-9a14-07c9be20832a",
	'hour',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"f8a0bc40-89bb-4d11-9d4f-c569beea62d7",
	'');
INSERT INTO S_BPARM
	VALUES ("f8a0bc40-89bb-4d11-9d4f-c569beea62d7",
	"5bb102b8-f82c-44fa-9a14-07c9be20832a",
	'day',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BPARM
	VALUES ("8f9326cf-5a06-4b42-8260-25d0d243814f",
	"5bb102b8-f82c-44fa-9a14-07c9be20832a",
	'month',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"28d88787-e576-4872-a489-ad6a8baa5701",
	'');
INSERT INTO S_BPARM
	VALUES ("7e9ec035-5efe-4fa4-8592-d4a94d04ae41",
	"5bb102b8-f82c-44fa-9a14-07c9be20832a",
	'year',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"241bde56-b8af-4303-b324-01a3341288be",
	'');
INSERT INTO S_BRG
	VALUES ("67fec0e0-676d-413b-aee2-2f432bfa58d4",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'get_second',
	'',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("07b81ae8-6a44-4d37-be15-60878ad4a42d",
	"67fec0e0-676d-413b-aee2-2f432bfa58d4",
	'date',
	"3181e074-fe1b-4d6e-9a56-0d67d162a34e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("e606f3a3-b83f-4da1-8cf1-0c70a4d424b1",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'get_minute',
	'',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("3801be14-15c6-4bc1-8087-5cb6687f65b6",
	"e606f3a3-b83f-4da1-8cf1-0c70a4d424b1",
	'date',
	"3181e074-fe1b-4d6e-9a56-0d67d162a34e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("eeb27634-b32d-4f64-965e-f2bddf0155bd",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'get_hour',
	'',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("01bf1cbf-1719-48b6-a93f-d98c6e4b81fa",
	"eeb27634-b32d-4f64-965e-f2bddf0155bd",
	'date',
	"3181e074-fe1b-4d6e-9a56-0d67d162a34e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("99c5f4e6-fb36-450d-841a-55fa997e717b",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'get_day',
	'',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("ff92032b-f779-4250-80b7-60a1ff2f6537",
	"99c5f4e6-fb36-450d-841a-55fa997e717b",
	'date',
	"3181e074-fe1b-4d6e-9a56-0d67d162a34e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("97ed9f03-f58b-4258-b0fc-f092a492d1b0",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'get_month',
	'',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("9fc3dc23-cddd-4860-9155-1dd70d7637f6",
	"97ed9f03-f58b-4258-b0fc-f092a492d1b0",
	'date',
	"3181e074-fe1b-4d6e-9a56-0d67d162a34e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("4db859a7-4a45-4e4d-a80f-cc2d71b181f2",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'get_year',
	'',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("8a22cb26-b435-4b2f-a29b-3cd861a6c1c5",
	"4db859a7-4a45-4e4d-a80f-cc2d71b181f2",
	'date',
	"3181e074-fe1b-4d6e-9a56-0d67d162a34e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("e1e90330-1e22-4429-b50c-c66c999cc747",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'current_clock',
	'',
	0,
	"a655f816-965c-407d-b502-1f645579c6c8",
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES ("607a071c-e105-468e-906b-7a2974d151dd",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'timer_start',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Returns the instance
handle of the timer.',
	0,
	"7f209d5f-cba1-401d-827f-d2a1a8ca5694",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("e399b265-93b5-4e75-a1f9-2727e4b25512",
	"607a071c-e105-468e-906b-7a2974d151dd",
	'microseconds',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"16e15215-531c-4abb-9b10-76ccd5c5c876",
	'');
INSERT INTO S_BPARM
	VALUES ("16e15215-531c-4abb-9b10-76ccd5c5c876",
	"607a071c-e105-468e-906b-7a2974d151dd",
	'event_inst',
	"444f9fb0-5d90-49ca-b343-ec1f06cd8ceb",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("05a8c55a-4976-40bc-b308-a1f1a786f65c",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'timer_start_recurring',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Upon expiration, the
timer will be restarted and fire again in the specified number of microseconds
generating the passed event. This bridge operation returns the instance handle
of the timer.',
	0,
	"7f209d5f-cba1-401d-827f-d2a1a8ca5694",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("2c7ed6d1-f3ae-4d6a-8dbf-549dce377e2c",
	"05a8c55a-4976-40bc-b308-a1f1a786f65c",
	'microseconds',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"63a0054e-eecc-4268-833d-726dc3154153",
	'');
INSERT INTO S_BPARM
	VALUES ("63a0054e-eecc-4268-833d-726dc3154153",
	"05a8c55a-4976-40bc-b308-a1f1a786f65c",
	'event_inst',
	"444f9fb0-5d90-49ca-b343-ec1f06cd8ceb",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("1aa33f2e-101a-4f4b-aa5c-d6e90343c344",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'timer_remaining_time',
	'Returns the time remaining (in microseconds) for the passed timer instance. If
the timer has expired, a zero value is returned.',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("c0527c0d-0b68-4c11-9ec5-5c975f26f6e2",
	"1aa33f2e-101a-4f4b-aa5c-d6e90343c344",
	'timer_inst_ref',
	"7f209d5f-cba1-401d-827f-d2a1a8ca5694",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("f3835484-0d71-41af-9f10-6c8424e02353",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'timer_reset_time',
	'This bridge operation attempts to set the passed existing timer to expire in
the specified number of microseconds. If the timer exists (that is, it has not
expired), a TRUE value is returned. If the timer no longer exists, a FALSE value
is returned.',
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("db882e28-1c13-4da6-a6b2-6cddb9f8e493",
	"f3835484-0d71-41af-9f10-6c8424e02353",
	'timer_inst_ref',
	"7f209d5f-cba1-401d-827f-d2a1a8ca5694",
	0,
	'',
	"5b06d04c-aca5-444b-a2e2-d74adc6cef8e",
	'');
INSERT INTO S_BPARM
	VALUES ("5b06d04c-aca5-444b-a2e2-d74adc6cef8e",
	"f3835484-0d71-41af-9f10-6c8424e02353",
	'microseconds',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("020a2fa2-77eb-443f-80b3-e270818b63c6",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'timer_add_time',
	'This bridge operation attempts to add the specified number of microseconds to a
passed existing timer. If the timer exists (that is, it has not expired), a TRUE
value is returned. If the timer no longer exists, a FALSE value is returned.',
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("4b5ad8a0-0bee-41e5-b8cd-55c1661a1288",
	"020a2fa2-77eb-443f-80b3-e270818b63c6",
	'timer_inst_ref',
	"7f209d5f-cba1-401d-827f-d2a1a8ca5694",
	0,
	'',
	"217b01a4-72f7-4887-aeab-86e0bb773d5f",
	'');
INSERT INTO S_BPARM
	VALUES ("217b01a4-72f7-4887-aeab-86e0bb773d5f",
	"020a2fa2-77eb-443f-80b3-e270818b63c6",
	'microseconds',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("1e53fa51-cbe8-4fb0-9386-ac25f0d36ac4",
	"1ca9fee7-f2dd-4268-a378-22f35dcf49a6",
	'timer_cancel',
	'This bridge operation cancels and deletes the passed timer instance. If the 
timer exists (that is, it had not expired), a TRUE value is returned. If the
timer no longer exists, a FALSE value is returned.',
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("e86404ee-0d21-4238-97a3-3d5619b1bb75",
	"1e53fa51-cbe8-4fb0-9386-ac25f0d36ac4",
	'timer_inst_ref',
	"7f209d5f-cba1-401d-827f-d2a1a8ca5694",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_EEIP
	VALUES ("c7dc2569-bca7-4e80-bed9-f96b7fcd0883",
	"406fbd8e-38c7-4991-97e7-df664d262859");
INSERT INTO S_EE
	VALUES ("406fbd8e-38c7-4991-97e7-df664d262859",
	'Architecture',
	'',
	'ARCH',
	"0eb5e6c3-13b6-4550-b154-5d6824e51255");
INSERT INTO S_BRG
	VALUES ("7f8d2590-a4fd-4b10-9b14-e1df75f77ae0",
	"406fbd8e-38c7-4991-97e7-df664d262859",
	'shutdown',
	'',
	0,
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	'',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES ("055c0fd6-4b39-4e02-8bc4-fe41b80ffa41",
	"7f8d2590-a4fd-4b10-9b14-e1df75f77ae0");
INSERT INTO ACT_ACT
	VALUES ("055c0fd6-4b39-4e02-8bc4-fe41b80ffa41",
	'bridge',
	0,
	"9191e541-3cef-40ba-9d42-bb8ea348097f",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Architecture::shutdown',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("9191e541-3cef-40ba-9d42-bb8ea348097f",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"055c0fd6-4b39-4e02-8bc4-fe41b80ffa41",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_EEIP
	VALUES ("c7dc2569-bca7-4e80-bed9-f96b7fcd0883",
	"c8c40f8e-f37c-4ef1-90ad-9b0d5dff37d6");
INSERT INTO S_EE
	VALUES ("c8c40f8e-f37c-4ef1-90ad-9b0d5dff37d6",
	'Logging',
	'',
	'LOG',
	"0eb5e6c3-13b6-4550-b154-5d6824e51255");
INSERT INTO S_BRG
	VALUES ("ea25943b-c6c2-4423-922c-947a3cd960ad",
	"c8c40f8e-f37c-4ef1-90ad-9b0d5dff37d6",
	'LogFailure',
	'',
	0,
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("74a3dd15-1233-46de-ad73-378d8347a65b",
	"ea25943b-c6c2-4423-922c-947a3cd960ad",
	'message',
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("628d4cdc-090f-44a3-b279-e83e408d1871",
	"ea25943b-c6c2-4423-922c-947a3cd960ad");
INSERT INTO ACT_ACT
	VALUES ("628d4cdc-090f-44a3-b279-e83e408d1871",
	'bridge',
	0,
	"e2b40ac6-ddf4-495f-af7c-4fe8ae6e2046",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogFailure',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("e2b40ac6-ddf4-495f-af7c-4fe8ae6e2046",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"628d4cdc-090f-44a3-b279-e83e408d1871",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("20118c86-a3a0-4c4b-80f0-5ef1a2122e2f",
	"c8c40f8e-f37c-4ef1-90ad-9b0d5dff37d6",
	'LogInfo',
	'',
	0,
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("61ba0773-0d61-40d3-b6d8-d4e23bb2afd5",
	"20118c86-a3a0-4c4b-80f0-5ef1a2122e2f",
	'message',
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("235a40f2-876f-440f-a17b-09aa0722df9f",
	"20118c86-a3a0-4c4b-80f0-5ef1a2122e2f");
INSERT INTO ACT_ACT
	VALUES ("235a40f2-876f-440f-a17b-09aa0722df9f",
	'bridge',
	0,
	"e0dafab5-55b6-4d89-a7a4-f842c9b2461e",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogInfo',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("e0dafab5-55b6-4d89-a7a4-f842c9b2461e",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"235a40f2-876f-440f-a17b-09aa0722df9f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("c1b48c1e-b947-4620-bd45-5dfde8d96e53",
	"c8c40f8e-f37c-4ef1-90ad-9b0d5dff37d6",
	'LogSuccess',
	'',
	0,
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("6ab8dfa3-4f6a-4b58-9b5a-cc20cf4f4d11",
	"c1b48c1e-b947-4620-bd45-5dfde8d96e53",
	'message',
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("e492d1e6-9e9c-4a8b-8b76-01e459ebb67f",
	"c1b48c1e-b947-4620-bd45-5dfde8d96e53");
INSERT INTO ACT_ACT
	VALUES ("e492d1e6-9e9c-4a8b-8b76-01e459ebb67f",
	'bridge',
	0,
	"0ae4f435-338f-4be3-81a1-3dcf3f82dd4e",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogSuccess',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("0ae4f435-338f-4be3-81a1-3dcf3f82dd4e",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"e492d1e6-9e9c-4a8b-8b76-01e459ebb67f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("6d236d53-aad5-4092-8ead-4374100f0ef7",
	"c8c40f8e-f37c-4ef1-90ad-9b0d5dff37d6",
	'LogInteger',
	'',
	0,
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("95ea46a5-1532-425f-a9ee-1967a9908734",
	"6d236d53-aad5-4092-8ead-4374100f0ef7",
	'message',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'[9]',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_DIM
	VALUES (9,
	0,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"95ea46a5-1532-425f-a9ee-1967a9908734",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"9e4f08ed-ab40-4aa1-8599-30464788942b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BRB
	VALUES ("4b57e284-9379-4126-9150-a75f29cac2c6",
	"6d236d53-aad5-4092-8ead-4374100f0ef7");
INSERT INTO ACT_ACT
	VALUES ("4b57e284-9379-4126-9150-a75f29cac2c6",
	'bridge',
	0,
	"8751fec4-0c4a-47e8-aeab-3a75ae81e413",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogInteger',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("8751fec4-0c4a-47e8-aeab-3a75ae81e413",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4b57e284-9379-4126-9150-a75f29cac2c6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_EEIP
	VALUES ("c7dc2569-bca7-4e80-bed9-f96b7fcd0883",
	"7f9e124d-30e8-49e2-aed2-23757fbeda8c");
INSERT INTO S_EE
	VALUES ("7f9e124d-30e8-49e2-aed2-23757fbeda8c",
	'Non-Volatile Storage',
	'',
	'NVS',
	"0eb5e6c3-13b6-4550-b154-5d6824e51255");
INSERT INTO S_BRG
	VALUES ("ca2c181d-fd92-4b62-b6bf-c494c018da0c",
	"7f9e124d-30e8-49e2-aed2-23757fbeda8c",
	'version',
	'',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'return 0;',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("f9a1867a-5823-4d2e-83b0-8e3714ea79ad",
	"ca2c181d-fd92-4b62-b6bf-c494c018da0c",
	'first',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BPARM
	VALUES ("d75ec77f-cd52-4962-ab83-a5c6b5cbd010",
	"ca2c181d-fd92-4b62-b6bf-c494c018da0c",
	'second',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"f9a1867a-5823-4d2e-83b0-8e3714ea79ad",
	'');
INSERT INTO ACT_BRB
	VALUES ("e388020e-5da7-4c41-87ae-21d2aaa51598",
	"ca2c181d-fd92-4b62-b6bf-c494c018da0c");
INSERT INTO ACT_ACT
	VALUES ("e388020e-5da7-4c41-87ae-21d2aaa51598",
	'bridge',
	0,
	"741f8a57-9a3c-474e-8bde-e582871563e8",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Non-Volatile Storage::version',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("741f8a57-9a3c-474e-8bde-e582871563e8",
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"e388020e-5da7-4c41-87ae-21d2aaa51598",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b2a3f9e5-9a18-4481-825e-947ea410616e",
	"741f8a57-9a3c-474e-8bde-e582871563e8",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'Non-Volatile Storage::version line: 1');
INSERT INTO ACT_RET
	VALUES ("b2a3f9e5-9a18-4481-825e-947ea410616e",
	"443db7c2-11ba-4ccc-90c3-d46d54609f78");
INSERT INTO V_VAL
	VALUES ("443db7c2-11ba-4ccc-90c3-d46d54609f78",
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"741f8a57-9a3c-474e-8bde-e582871563e8");
INSERT INTO V_LIN
	VALUES ("443db7c2-11ba-4ccc-90c3-d46d54609f78",
	'0');
INSERT INTO S_BRG
	VALUES ("0d03b975-963a-405e-9231-c470ac2ac717",
	"7f9e124d-30e8-49e2-aed2-23757fbeda8c",
	'checksum',
	'',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'return 0;',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("acc349eb-58b5-412e-b86d-b51fac06c03b",
	"0d03b975-963a-405e-9231-c470ac2ac717",
	'first',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BPARM
	VALUES ("48ed4b34-b3bc-46f2-b6fa-efa94e073228",
	"0d03b975-963a-405e-9231-c470ac2ac717",
	'second',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"acc349eb-58b5-412e-b86d-b51fac06c03b",
	'');
INSERT INTO ACT_BRB
	VALUES ("5e5e3f21-57f7-4b14-b01c-611cec7f6ba3",
	"0d03b975-963a-405e-9231-c470ac2ac717");
INSERT INTO ACT_ACT
	VALUES ("5e5e3f21-57f7-4b14-b01c-611cec7f6ba3",
	'bridge',
	0,
	"a186c831-2ea3-460b-8a28-1ad10cb04faa",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Non-Volatile Storage::checksum',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a186c831-2ea3-460b-8a28-1ad10cb04faa",
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"5e5e3f21-57f7-4b14-b01c-611cec7f6ba3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ae7801e3-b315-42f5-96c1-d669d73d15f1",
	"a186c831-2ea3-460b-8a28-1ad10cb04faa",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'Non-Volatile Storage::checksum line: 1');
INSERT INTO ACT_RET
	VALUES ("ae7801e3-b315-42f5-96c1-d669d73d15f1",
	"1190fc61-bdef-492d-9040-ceb2fbc5d25f");
INSERT INTO V_VAL
	VALUES ("1190fc61-bdef-492d-9040-ceb2fbc5d25f",
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a186c831-2ea3-460b-8a28-1ad10cb04faa");
INSERT INTO V_LIN
	VALUES ("1190fc61-bdef-492d-9040-ceb2fbc5d25f",
	'0');
INSERT INTO S_BRG
	VALUES ("6ab0cff9-f794-495b-9a7b-b0c076259c1d",
	"7f9e124d-30e8-49e2-aed2-23757fbeda8c",
	'space_used',
	'',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'return 0;',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES ("21f80ecd-7e43-4077-b3c8-2624a5be915a",
	"6ab0cff9-f794-495b-9a7b-b0c076259c1d");
INSERT INTO ACT_ACT
	VALUES ("21f80ecd-7e43-4077-b3c8-2624a5be915a",
	'bridge',
	0,
	"e3b964be-e54c-4193-9c93-1f8439669c9d",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Non-Volatile Storage::space_used',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("e3b964be-e54c-4193-9c93-1f8439669c9d",
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"21f80ecd-7e43-4077-b3c8-2624a5be915a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5ead3976-3ac8-4814-bc41-fd7f5b3dc4a4",
	"e3b964be-e54c-4193-9c93-1f8439669c9d",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'Non-Volatile Storage::space_used line: 1');
INSERT INTO ACT_RET
	VALUES ("5ead3976-3ac8-4814-bc41-fd7f5b3dc4a4",
	"ab1dac2c-fc14-4ffd-9013-d8b0d69d57fb");
INSERT INTO V_VAL
	VALUES ("ab1dac2c-fc14-4ffd-9013-d8b0d69d57fb",
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e3b964be-e54c-4193-9c93-1f8439669c9d");
INSERT INTO V_LIN
	VALUES ("ab1dac2c-fc14-4ffd-9013-d8b0d69d57fb",
	'0');
INSERT INTO S_BRG
	VALUES ("ec0815d4-cb52-4154-bbc9-7c85a2d01db4",
	"7f9e124d-30e8-49e2-aed2-23757fbeda8c",
	'format',
	'',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'return 0;',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES ("a879899b-a1e1-46a8-8e7e-0af31b0d30a7",
	"ec0815d4-cb52-4154-bbc9-7c85a2d01db4");
INSERT INTO ACT_ACT
	VALUES ("a879899b-a1e1-46a8-8e7e-0af31b0d30a7",
	'bridge',
	0,
	"c93dbacd-8eb3-4e8a-8f96-c731c5572958",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Non-Volatile Storage::format',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c93dbacd-8eb3-4e8a-8f96-c731c5572958",
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"a879899b-a1e1-46a8-8e7e-0af31b0d30a7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("bcd4063a-3e93-459b-a8f9-0d74de7c65e6",
	"c93dbacd-8eb3-4e8a-8f96-c731c5572958",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'Non-Volatile Storage::format line: 1');
INSERT INTO ACT_RET
	VALUES ("bcd4063a-3e93-459b-a8f9-0d74de7c65e6",
	"820718ce-44fa-4947-aabc-a2ee2ffa63c0");
INSERT INTO V_VAL
	VALUES ("820718ce-44fa-4947-aabc-a2ee2ffa63c0",
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c93dbacd-8eb3-4e8a-8f96-c731c5572958");
INSERT INTO V_LIN
	VALUES ("820718ce-44fa-4947-aabc-a2ee2ffa63c0",
	'0');
INSERT INTO S_FPK
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	'functions',
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PL_FPID
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255");
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"401030fa-dd34-4c89-8014-44ec7b0e1bb7");
INSERT INTO S_SYNC
	VALUES ("401030fa-dd34-4c89-8014-44ec7b0e1bb7",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'setup',
	'',
	'// 
// Check to see if any instances are already here.
// This would mean that we have restored from NVS
// or that preexisting instances were defined in data.
//

select any sequence from instances of SEQUENCE;
if ( empty sequence )
  i = NVS::space_used();
  if ( i < 100 )
    i = NVS::format();
    if( i != 0 )
      LOG::LogFailure( message:"Error formatting the NVS." );
    end if;
  end if;

  LOG::LogInfo( message:"Did not find any PEI data, initializing NVS" );
  i = NVS::version( first:1, second:2 );
  i =  NVS::checksum( first:1, second:2 );
  
// Create 9 digits.
i = 9;
while ( 0 < i )
  create object instance digit of DIGIT;
  digit.value = i;
  i = i - 1;
end while;
create object instance digit of DIGIT;
digit.value = 0;


i = 9;
while ( 0 < i )

  // Create the row sequence.
  create object instance sequence of SEQUENCE;
  sequence.solved = false;
  sequence.requests = 0;
  create object instance row of ROW;
  row.number = i;
  relate row to sequence across R1;
  
  // Create the column sequence.
  create object instance sequence of SEQUENCE;
  sequence.solved = false;
  sequence.requests = 0;
  create object instance column of COLUMN;
  column.number = i;
  relate column to sequence across R1;
  
  // Create the box sequence.
  create object instance sequence of SEQUENCE;
  sequence.solved = false;
  sequence.requests = 0;
  create object instance box of BOX;
  box.number = i;
  relate box to sequence across R1;
  
  i = i - 1;
end while;

select many rows from instances of ROW;
for each row in rows
  select many columns from instances of COLUMN;
  for each column in columns;
    create object instance cell of CELL;
    select any digit from instances of DIGIT where ( selected.value == 0 );
    relate cell to digit across R9; 
    relate cell to row across R2;
    relate cell to column across R3;
  
    // Link in all 9 digits to each cell.
    select many digits from instances of DIGIT where ( selected.value != 0 );
    for each digit in digits
      create object instance eligible of ELIGIBLE;
      relate digit to cell across R8 using eligible;
    end for;
  end for;
end for;

// Link the cells to the correct boxes.
select many cells from instances of CELL;
for each cell in cells
  if ( ( cell.row_number <= 3 ) and
     ( cell.column_number <= 3 ) )
    select any box from instances of BOX where ( selected.number == 1 );
    relate cell to box across R4;
  elif ( ( cell.row_number <= 3 ) and
     ( ( 4 <= cell.column_number ) and ( cell.column_number <= 6 ) ) )
    select any box from instances of BOX where ( selected.number == 2 );
    relate cell to box across R4;
  elif ( ( cell.row_number <= 3 ) and
     ( 7 <= cell.column_number ) )
    select any box from instances of BOX where ( selected.number == 3 );
    relate cell to box across R4;
  elif ( ( ( 4 <= cell.row_number ) and ( cell.row_number <= 6 ) ) and
     ( cell.column_number <= 3 ) )
    select any box from instances of BOX where ( selected.number == 4 );
    relate cell to box across R4;
  elif ( ( ( 4 <= cell.row_number ) and ( cell.row_number <= 6 ) ) and
     ( ( 4 <= cell.column_number ) and ( cell.column_number <= 6 ) ) )
    select any box from instances of BOX where ( selected.number == 5 );
    relate cell to box across R4;
  elif ( ( ( 4 <= cell.row_number ) and ( cell.row_number <= 6 ) ) and
     ( 7 <= cell.column_number ) )
    select any box from instances of BOX where ( selected.number == 6 );
    relate cell to box across R4;
  elif ( ( 7 <= cell.row_number ) and
     ( cell.column_number <= 3 ) )
    select any box from instances of BOX where ( selected.number == 7 );
    relate cell to box across R4;
  elif ( ( 7 <= cell.row_number ) and
     ( ( 4 <= cell.column_number ) and ( cell.column_number <= 6 ) ) )
    select any box from instances of BOX where ( selected.number == 8 );
    relate cell to box across R4;
  elif ( ( 7 <= cell.row_number ) and
     ( 7 <= cell.column_number ) )
    select any box from instances of BOX where ( selected.number == 9 );
    relate cell to box across R4;
  end if;
end for;

else
  LOG::LogInfo( message:"PEI data found." );
end if;
',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"401030fa-dd34-4c89-8014-44ec7b0e1bb7");
INSERT INTO ACT_ACT
	VALUES ("d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	'function',
	0,
	"2e27336d-81b0-468e-807c-36343750a282",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setup',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("2e27336d-81b0-468e-807c-36343750a282",
	1,
	0,
	0,
	'',
	'',
	'',
	123,
	1,
	7,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("45714f15-060d-46bb-98b9-4538f1ff483b",
	"2e27336d-81b0-468e-807c-36343750a282",
	"92ced465-b4c6-4302-adb6-9b5c7575b6c5",
	7,
	1,
	'setup line: 7');
INSERT INTO ACT_FIO
	VALUES ("45714f15-060d-46bb-98b9-4538f1ff483b",
	"89237add-72b5-4354-9355-c1d2698d5496",
	1,
	'any',
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	7,
	39);
INSERT INTO ACT_SMT
	VALUES ("92ced465-b4c6-4302-adb6-9b5c7575b6c5",
	"2e27336d-81b0-468e-807c-36343750a282",
	"00000000-0000-0000-0000-000000000000",
	8,
	1,
	'setup line: 8');
INSERT INTO ACT_IF
	VALUES ("92ced465-b4c6-4302-adb6-9b5c7575b6c5",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"c6b18628-1e97-4bbc-bccb-c06860d7aec6",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b145e80d-a3c4-49f6-80f8-38f7583f04af",
	"2e27336d-81b0-468e-807c-36343750a282",
	"00000000-0000-0000-0000-000000000000",
	123,
	1,
	'setup line: 123');
INSERT INTO ACT_E
	VALUES ("b145e80d-a3c4-49f6-80f8-38f7583f04af",
	"2388dd92-7c8f-4b5d-bd3e-a855669f2922",
	"92ced465-b4c6-4302-adb6-9b5c7575b6c5");
INSERT INTO V_VAL
	VALUES ("6e596b0e-6a88-4346-9f70-176fb5344fd0",
	0,
	0,
	8,
	12,
	19,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"2e27336d-81b0-468e-807c-36343750a282");
INSERT INTO V_IRF
	VALUES ("6e596b0e-6a88-4346-9f70-176fb5344fd0",
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_VAL
	VALUES ("c6b18628-1e97-4bbc-bccb-c06860d7aec6",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"2e27336d-81b0-468e-807c-36343750a282");
INSERT INTO V_UNY
	VALUES ("c6b18628-1e97-4bbc-bccb-c06860d7aec6",
	"6e596b0e-6a88-4346-9f70-176fb5344fd0",
	'empty');
INSERT INTO V_VAR
	VALUES ("89237add-72b5-4354-9355-c1d2698d5496",
	"2e27336d-81b0-468e-807c-36343750a282",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("89237add-72b5-4354-9355-c1d2698d5496",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("011b6335-8a59-407d-8815-44176e651f0f",
	7,
	12,
	19,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("76209fba-3242-4a48-b678-857d3db81869",
	36,
	26,
	33,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("5d2531da-3810-43b7-9d93-fba7026a3048",
	37,
	3,
	10,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("0a3639eb-82f2-45a4-ad59-3d4a41b7b2b2",
	38,
	3,
	10,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("10421b94-d9f2-4b97-b0bc-21544b7801bd",
	41,
	17,
	24,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("29137585-8759-4c82-aa85-8828c2c444d4",
	44,
	26,
	33,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("7f027331-a6ae-4c64-9964-161ab097e60b",
	45,
	3,
	10,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("c2ec4b5e-86e4-4580-9f87-8ca8cf0152ab",
	46,
	3,
	10,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("5188a340-04a6-41d5-8b58-b2263c9776fc",
	49,
	20,
	27,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("3c282966-2f2c-4b5c-96ca-f494e94ed879",
	52,
	26,
	33,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("76c78c55-3509-4372-950c-4089ddcfad5d",
	53,
	3,
	10,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("43e6f806-f25c-487f-986b-07d8beafa5be",
	54,
	3,
	10,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_LOC
	VALUES ("b57f02c4-2c11-418d-8086-569b7fa74a99",
	57,
	17,
	24,
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO ACT_BLK
	VALUES ("0a9b33c4-af5e-4d70-bdcd-210414af1031",
	1,
	0,
	0,
	'NVS',
	'',
	'',
	83,
	1,
	82,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c1f8c5d3-7612-4720-8bb4-b31a4943160a",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"22c9d406-eceb-43a0-8ae1-cfaad799c6d4",
	9,
	3,
	'setup line: 9');
INSERT INTO ACT_AI
	VALUES ("c1f8c5d3-7612-4720-8bb4-b31a4943160a",
	"093d245f-59bc-424f-a3cc-4eebe633828e",
	"9a573408-a5d4-4ea1-b1e3-2cce98a5eea9",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("22c9d406-eceb-43a0-8ae1-cfaad799c6d4",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"175c2810-71ec-448a-ab6a-9ed11abba15b",
	10,
	3,
	'setup line: 10');
INSERT INTO ACT_IF
	VALUES ("22c9d406-eceb-43a0-8ae1-cfaad799c6d4",
	"b81787d3-59eb-434e-b830-021eec3c67cd",
	"59a54870-dd1c-48b7-9143-48865ee60ff6",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("175c2810-71ec-448a-ab6a-9ed11abba15b",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"75067dd1-b97b-4a44-b636-955cce97daa9",
	17,
	3,
	'setup line: 17');
INSERT INTO ACT_BRG
	VALUES ("175c2810-71ec-448a-ab6a-9ed11abba15b",
	"20118c86-a3a0-4c4b-80f0-5ef1a2122e2f",
	17,
	8,
	17,
	3);
INSERT INTO ACT_SMT
	VALUES ("75067dd1-b97b-4a44-b636-955cce97daa9",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"3a386bfe-c1dc-4ab0-bf82-85efd7337f7c",
	18,
	3,
	'setup line: 18');
INSERT INTO ACT_AI
	VALUES ("75067dd1-b97b-4a44-b636-955cce97daa9",
	"ec12023f-aeec-4d7a-9e4f-764d9d87c4e0",
	"bddeabaa-4893-4721-9bba-a5ff48f5a636",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("3a386bfe-c1dc-4ab0-bf82-85efd7337f7c",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"22e83c43-179d-4095-9ba9-221d7287aa03",
	19,
	3,
	'setup line: 19');
INSERT INTO ACT_AI
	VALUES ("3a386bfe-c1dc-4ab0-bf82-85efd7337f7c",
	"476beaf6-627b-44e9-ac56-7e1bf0648ab8",
	"f571fec6-502d-4b7e-8772-3561d8f54de7",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("22e83c43-179d-4095-9ba9-221d7287aa03",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"eb844ae9-4d37-4836-8e78-7a891272ebc1",
	22,
	1,
	'setup line: 22');
INSERT INTO ACT_AI
	VALUES ("22e83c43-179d-4095-9ba9-221d7287aa03",
	"d3d6287d-696e-4a7d-bcdf-5229b7103d54",
	"d4982c23-04eb-4962-87be-c8d100ff0749",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("eb844ae9-4d37-4836-8e78-7a891272ebc1",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"4c924693-1998-431d-a1be-14619e3b46b6",
	23,
	1,
	'setup line: 23');
INSERT INTO ACT_WHL
	VALUES ("eb844ae9-4d37-4836-8e78-7a891272ebc1",
	"f1ca5d2c-1032-40de-beb6-1d076f9efc03",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db");
INSERT INTO ACT_SMT
	VALUES ("4c924693-1998-431d-a1be-14619e3b46b6",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"4f84e19e-a9b6-4572-babc-dd7e9b76a336",
	28,
	1,
	'setup line: 28');
INSERT INTO ACT_CR
	VALUES ("4c924693-1998-431d-a1be-14619e3b46b6",
	"b0991106-99dc-4c9a-b681-ef1915ad5416",
	1,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	28,
	33);
INSERT INTO ACT_SMT
	VALUES ("4f84e19e-a9b6-4572-babc-dd7e9b76a336",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"82102783-3637-466d-a9b5-295b95e5a97d",
	29,
	1,
	'setup line: 29');
INSERT INTO ACT_AI
	VALUES ("4f84e19e-a9b6-4572-babc-dd7e9b76a336",
	"abf8d810-10fb-46e8-98f8-89b528c5dff8",
	"72dcc38e-c4ee-43c6-a1fd-bb134bfdca95",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("82102783-3637-466d-a9b5-295b95e5a97d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"c1a545ff-a3b0-4363-a5ce-5ff6bd7b2272",
	32,
	1,
	'setup line: 32');
INSERT INTO ACT_AI
	VALUES ("82102783-3637-466d-a9b5-295b95e5a97d",
	"a614dc16-2dd3-45a5-9470-31097337b19b",
	"d38192aa-14af-409e-9ff2-f6b8dba7278b",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c1a545ff-a3b0-4363-a5ce-5ff6bd7b2272",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"109632fb-ed92-4444-b377-6a8f708a2d23",
	33,
	1,
	'setup line: 33');
INSERT INTO ACT_WHL
	VALUES ("c1a545ff-a3b0-4363-a5ce-5ff6bd7b2272",
	"13547703-9b43-41e7-89e7-267ad1296a2b",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO ACT_SMT
	VALUES ("109632fb-ed92-4444-b377-6a8f708a2d23",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"b518fb47-787a-4501-81bf-f1f68f0af84e",
	62,
	1,
	'setup line: 62');
INSERT INTO ACT_FIO
	VALUES ("109632fb-ed92-4444-b377-6a8f708a2d23",
	"9c35674f-ea94-4b8f-9f75-a02bcad6f205",
	1,
	'many',
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	62,
	36);
INSERT INTO ACT_SMT
	VALUES ("b518fb47-787a-4501-81bf-f1f68f0af84e",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"5dc068f4-ace8-4caf-86a8-2356a4ed0a8b",
	63,
	1,
	'setup line: 63');
INSERT INTO ACT_FOR
	VALUES ("b518fb47-787a-4501-81bf-f1f68f0af84e",
	"592b84a4-6f65-49cf-8d86-7d900aa8eaa9",
	1,
	"c7ea13d0-0a5e-4dba-8137-0c4cb62a6561",
	"9c35674f-ea94-4b8f-9f75-a02bcad6f205",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO ACT_SMT
	VALUES ("5dc068f4-ace8-4caf-86a8-2356a4ed0a8b",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"2cd86fc9-4b25-4512-aa12-857f7136fb94",
	82,
	1,
	'setup line: 82');
INSERT INTO ACT_FIO
	VALUES ("5dc068f4-ace8-4caf-86a8-2356a4ed0a8b",
	"cb9b685e-496c-4953-b72d-3f2acd0a08eb",
	1,
	'many',
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	82,
	37);
INSERT INTO ACT_SMT
	VALUES ("2cd86fc9-4b25-4512-aa12-857f7136fb94",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	"00000000-0000-0000-0000-000000000000",
	83,
	1,
	'setup line: 83');
INSERT INTO ACT_FOR
	VALUES ("2cd86fc9-4b25-4512-aa12-857f7136fb94",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	1,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"cb9b685e-496c-4953-b72d-3f2acd0a08eb",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_VAL
	VALUES ("9a573408-a5d4-4ea1-b1e3-2cce98a5eea9",
	1,
	1,
	9,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_TVL
	VALUES ("9a573408-a5d4-4ea1-b1e3-2cce98a5eea9",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("093d245f-59bc-424f-a3cc-4eebe633828e",
	0,
	0,
	9,
	12,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_BRV
	VALUES ("093d245f-59bc-424f-a3cc-4eebe633828e",
	"6ab0cff9-f794-495b-9a7b-b0c076259c1d",
	1,
	9,
	7);
INSERT INTO V_VAL
	VALUES ("61b03f31-8c83-4869-8b20-965fc0b9a2f1",
	0,
	0,
	10,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_TVL
	VALUES ("61b03f31-8c83-4869-8b20-965fc0b9a2f1",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("59a54870-dd1c-48b7-9143-48865ee60ff6",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_BIN
	VALUES ("59a54870-dd1c-48b7-9143-48865ee60ff6",
	"48253bc5-ca20-4004-97fd-6d898b787ca8",
	"61b03f31-8c83-4869-8b20-965fc0b9a2f1",
	'<');
INSERT INTO V_VAL
	VALUES ("48253bc5-ca20-4004-97fd-6d898b787ca8",
	0,
	0,
	10,
	12,
	14,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LIN
	VALUES ("48253bc5-ca20-4004-97fd-6d898b787ca8",
	'100');
INSERT INTO V_VAL
	VALUES ("ca765403-1e55-406e-ba21-b2ae7d919950",
	0,
	0,
	17,
	25,
	68,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LST
	VALUES ("ca765403-1e55-406e-ba21-b2ae7d919950",
	'Did not find any PEI data, initializing NVS');
INSERT INTO V_PAR
	VALUES ("ca765403-1e55-406e-ba21-b2ae7d919950",
	"175c2810-71ec-448a-ab6a-9ed11abba15b",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	17,
	17);
INSERT INTO V_VAL
	VALUES ("bddeabaa-4893-4721-9bba-a5ff48f5a636",
	1,
	0,
	18,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_TVL
	VALUES ("bddeabaa-4893-4721-9bba-a5ff48f5a636",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("ec12023f-aeec-4d7a-9e4f-764d9d87c4e0",
	0,
	0,
	18,
	12,
	-1,
	18,
	21,
	18,
	30,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_BRV
	VALUES ("ec12023f-aeec-4d7a-9e4f-764d9d87c4e0",
	"ca2c181d-fd92-4b62-b6bf-c494c018da0c",
	1,
	18,
	7);
INSERT INTO V_VAL
	VALUES ("e384a3bf-3583-4f6e-9b1c-52c090e123fd",
	0,
	0,
	18,
	27,
	27,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LIN
	VALUES ("e384a3bf-3583-4f6e-9b1c-52c090e123fd",
	'1');
INSERT INTO V_PAR
	VALUES ("e384a3bf-3583-4f6e-9b1c-52c090e123fd",
	"00000000-0000-0000-0000-000000000000",
	"ec12023f-aeec-4d7a-9e4f-764d9d87c4e0",
	'first',
	"41a610a7-50a9-46e2-944a-cb540d9b2cc9",
	18,
	21);
INSERT INTO V_VAL
	VALUES ("41a610a7-50a9-46e2-944a-cb540d9b2cc9",
	0,
	0,
	18,
	37,
	37,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LIN
	VALUES ("41a610a7-50a9-46e2-944a-cb540d9b2cc9",
	'2');
INSERT INTO V_PAR
	VALUES ("41a610a7-50a9-46e2-944a-cb540d9b2cc9",
	"00000000-0000-0000-0000-000000000000",
	"ec12023f-aeec-4d7a-9e4f-764d9d87c4e0",
	'second',
	"00000000-0000-0000-0000-000000000000",
	18,
	30);
INSERT INTO V_VAL
	VALUES ("f571fec6-502d-4b7e-8772-3561d8f54de7",
	1,
	0,
	19,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_TVL
	VALUES ("f571fec6-502d-4b7e-8772-3561d8f54de7",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("476beaf6-627b-44e9-ac56-7e1bf0648ab8",
	0,
	0,
	19,
	13,
	-1,
	19,
	23,
	19,
	32,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_BRV
	VALUES ("476beaf6-627b-44e9-ac56-7e1bf0648ab8",
	"0d03b975-963a-405e-9231-c470ac2ac717",
	1,
	19,
	8);
INSERT INTO V_VAL
	VALUES ("3a5d8691-76c7-446b-ae9d-1d27671dc4be",
	0,
	0,
	19,
	29,
	29,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LIN
	VALUES ("3a5d8691-76c7-446b-ae9d-1d27671dc4be",
	'1');
INSERT INTO V_PAR
	VALUES ("3a5d8691-76c7-446b-ae9d-1d27671dc4be",
	"00000000-0000-0000-0000-000000000000",
	"476beaf6-627b-44e9-ac56-7e1bf0648ab8",
	'first',
	"6fc16952-782f-4c5f-a606-66881b136ecd",
	19,
	23);
INSERT INTO V_VAL
	VALUES ("6fc16952-782f-4c5f-a606-66881b136ecd",
	0,
	0,
	19,
	39,
	39,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LIN
	VALUES ("6fc16952-782f-4c5f-a606-66881b136ecd",
	'2');
INSERT INTO V_PAR
	VALUES ("6fc16952-782f-4c5f-a606-66881b136ecd",
	"00000000-0000-0000-0000-000000000000",
	"476beaf6-627b-44e9-ac56-7e1bf0648ab8",
	'second',
	"00000000-0000-0000-0000-000000000000",
	19,
	32);
INSERT INTO V_VAL
	VALUES ("d4982c23-04eb-4962-87be-c8d100ff0749",
	1,
	0,
	22,
	1,
	1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_TVL
	VALUES ("d4982c23-04eb-4962-87be-c8d100ff0749",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("d3d6287d-696e-4a7d-bcdf-5229b7103d54",
	0,
	0,
	22,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LIN
	VALUES ("d3d6287d-696e-4a7d-bcdf-5229b7103d54",
	'9');
INSERT INTO V_VAL
	VALUES ("15ed806f-2961-4763-b0b7-f6718e825858",
	0,
	0,
	23,
	9,
	9,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LIN
	VALUES ("15ed806f-2961-4763-b0b7-f6718e825858",
	'0');
INSERT INTO V_VAL
	VALUES ("f1ca5d2c-1032-40de-beb6-1d076f9efc03",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_BIN
	VALUES ("f1ca5d2c-1032-40de-beb6-1d076f9efc03",
	"414ce2ad-9555-4d41-8c73-b848de590793",
	"15ed806f-2961-4763-b0b7-f6718e825858",
	'<');
INSERT INTO V_VAL
	VALUES ("414ce2ad-9555-4d41-8c73-b848de590793",
	0,
	0,
	23,
	13,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_TVL
	VALUES ("414ce2ad-9555-4d41-8c73-b848de590793",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("b538502a-cdf8-4ed6-a6b8-2af8b7f9f111",
	1,
	0,
	29,
	1,
	5,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_IRF
	VALUES ("b538502a-cdf8-4ed6-a6b8-2af8b7f9f111",
	"b0991106-99dc-4c9a-b681-ef1915ad5416");
INSERT INTO V_VAL
	VALUES ("72dcc38e-c4ee-43c6-a1fd-bb134bfdca95",
	1,
	0,
	29,
	7,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_AVL
	VALUES ("72dcc38e-c4ee-43c6-a1fd-bb134bfdca95",
	"b538502a-cdf8-4ed6-a6b8-2af8b7f9f111",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO V_VAL
	VALUES ("abf8d810-10fb-46e8-98f8-89b528c5dff8",
	0,
	0,
	29,
	15,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LIN
	VALUES ("abf8d810-10fb-46e8-98f8-89b528c5dff8",
	'0');
INSERT INTO V_VAL
	VALUES ("d38192aa-14af-409e-9ff2-f6b8dba7278b",
	1,
	0,
	32,
	1,
	1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_TVL
	VALUES ("d38192aa-14af-409e-9ff2-f6b8dba7278b",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("a614dc16-2dd3-45a5-9470-31097337b19b",
	0,
	0,
	32,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LIN
	VALUES ("a614dc16-2dd3-45a5-9470-31097337b19b",
	'9');
INSERT INTO V_VAL
	VALUES ("ea2b7c32-3b3d-4a2a-afac-0de4cf804093",
	0,
	0,
	33,
	9,
	9,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_LIN
	VALUES ("ea2b7c32-3b3d-4a2a-afac-0de4cf804093",
	'0');
INSERT INTO V_VAL
	VALUES ("13547703-9b43-41e7-89e7-267ad1296a2b",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_BIN
	VALUES ("13547703-9b43-41e7-89e7-267ad1296a2b",
	"35c06faf-3c9b-46eb-9001-882aa146ad23",
	"ea2b7c32-3b3d-4a2a-afac-0de4cf804093",
	'<');
INSERT INTO V_VAL
	VALUES ("35c06faf-3c9b-46eb-9001-882aa146ad23",
	0,
	0,
	33,
	13,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031");
INSERT INTO V_TVL
	VALUES ("35c06faf-3c9b-46eb-9001-882aa146ad23",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAR
	VALUES ("875381df-3143-40f5-b144-3f13ce6aafc7",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	'i',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("875381df-3143-40f5-b144-3f13ce6aafc7",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("902908af-0573-42b2-a6f4-09e2e0e6fe92",
	9,
	3,
	3,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("607b95b5-dab5-4835-8df6-afd478e633e2",
	10,
	8,
	8,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("2577097e-446d-4942-9413-68accad6f6f8",
	11,
	5,
	5,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("00fd4327-ae0c-4a34-a5e5-48ca754d809b",
	12,
	9,
	9,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("2307d00a-e656-4d1e-a372-c096396cdd15",
	18,
	3,
	3,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("3e68e0ba-a68e-4888-8ee8-ee3180b414d9",
	19,
	3,
	3,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("c53da8ee-20f3-49be-a95a-e4ecaf30bd55",
	22,
	1,
	1,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("e695c4cc-5c17-4f36-a1e8-845acd12673f",
	23,
	13,
	13,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("85691105-ec10-4855-9a57-91e92eda5d4e",
	25,
	17,
	17,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("048926e9-fe51-42be-a45a-f6d4dd45154b",
	26,
	3,
	3,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("cae48a90-e8da-4708-8b5b-1d185b7b016a",
	26,
	7,
	7,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("8e1b034a-7cd6-4411-8bc4-55278018c154",
	32,
	1,
	1,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("f9ddd0e6-0d50-4b91-b762-65d165979670",
	33,
	13,
	13,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("fc4cd756-2c1e-4829-9cd2-0d139695b998",
	40,
	16,
	16,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("443844d1-fc77-4600-ac9f-90be6a729cec",
	48,
	19,
	19,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("5fa8bb79-097b-4673-b7de-4cb75a4f755f",
	56,
	16,
	16,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("dda39d00-949b-4d65-8917-11b1182311c2",
	59,
	3,
	3,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_LOC
	VALUES ("6ab1e882-a238-4122-937b-396dc070adba",
	59,
	7,
	7,
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAR
	VALUES ("b0991106-99dc-4c9a-b681-ef1915ad5416",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	'digit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("b0991106-99dc-4c9a-b681-ef1915ad5416",
	0,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("0a655e22-7d19-4dcf-b34a-a6a37232917b",
	28,
	24,
	28,
	"b0991106-99dc-4c9a-b681-ef1915ad5416");
INSERT INTO V_LOC
	VALUES ("936a9ebb-2305-4356-a8d2-2e53149bfcca",
	29,
	1,
	5,
	"b0991106-99dc-4c9a-b681-ef1915ad5416");
INSERT INTO V_LOC
	VALUES ("8238a1c2-508c-4ae6-83c2-5779f7a5e8b5",
	67,
	16,
	20,
	"b0991106-99dc-4c9a-b681-ef1915ad5416");
INSERT INTO V_LOC
	VALUES ("6f0734a1-e744-4b74-bc95-db6ad70b0265",
	68,
	20,
	24,
	"b0991106-99dc-4c9a-b681-ef1915ad5416");
INSERT INTO V_LOC
	VALUES ("30b6c301-87e7-40d7-8024-c813ae262e52",
	74,
	14,
	18,
	"b0991106-99dc-4c9a-b681-ef1915ad5416");
INSERT INTO V_LOC
	VALUES ("9ef54af5-cdee-49f1-a7fc-f5618118496b",
	76,
	14,
	18,
	"b0991106-99dc-4c9a-b681-ef1915ad5416");
INSERT INTO V_VAR
	VALUES ("9c35674f-ea94-4b8f-9f75-a02bcad6f205",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	'rows',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("9c35674f-ea94-4b8f-9f75-a02bcad6f205",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("54ef7df3-d6c9-4eb3-aadf-5a17cd704560",
	62,
	13,
	16,
	"9c35674f-ea94-4b8f-9f75-a02bcad6f205");
INSERT INTO V_LOC
	VALUES ("17531366-e9ec-4bf9-839c-7fbd9c8a7185",
	63,
	17,
	20,
	"9c35674f-ea94-4b8f-9f75-a02bcad6f205");
INSERT INTO V_VAR
	VALUES ("c7ea13d0-0a5e-4dba-8137-0c4cb62a6561",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	'row',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("c7ea13d0-0a5e-4dba-8137-0c4cb62a6561",
	1,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("22af0eb8-6ffd-452e-81dd-ad127321621c",
	63,
	10,
	12,
	"c7ea13d0-0a5e-4dba-8137-0c4cb62a6561");
INSERT INTO V_LOC
	VALUES ("92becf9f-06f9-4fa7-92e4-6563f3a4dc64",
	69,
	20,
	22,
	"c7ea13d0-0a5e-4dba-8137-0c4cb62a6561");
INSERT INTO V_VAR
	VALUES ("cb9b685e-496c-4953-b72d-3f2acd0a08eb",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	'cells',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("cb9b685e-496c-4953-b72d-3f2acd0a08eb",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("3d735c72-4685-4f8d-889c-a75abd22655b",
	82,
	13,
	17,
	"cb9b685e-496c-4953-b72d-3f2acd0a08eb");
INSERT INTO V_LOC
	VALUES ("23ad9280-8275-4f52-9f9a-7cc43443992f",
	83,
	18,
	22,
	"cb9b685e-496c-4953-b72d-3f2acd0a08eb");
INSERT INTO V_VAR
	VALUES ("8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"0a9b33c4-af5e-4d70-bdcd-210414af1031",
	'cell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("8c61dd78-2dbb-4631-8d53-ff49377330f6",
	1,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("4721b637-bf99-40d0-80bc-c2be237cc002",
	83,
	10,
	13,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("341414dc-c67e-4700-af68-040dc1327f93",
	84,
	10,
	13,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("7870a078-a89a-40cf-a4ad-7abcc19048a7",
	85,
	8,
	11,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("2d91f346-24f7-44f2-8f60-f4caa0105147",
	87,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("69115967-7cb4-4efc-9d91-313350236269",
	88,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("28d46b2c-30c8-4993-b656-e9630ee01c43",
	89,
	15,
	18,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("7200d399-9a3d-481d-9034-04c3230763c7",
	89,
	42,
	45,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("676fb54c-28a7-4913-9060-d9c4ff19c19b",
	91,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("603e0346-8c73-4bde-bd52-bb59f4a89f77",
	92,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("998394ad-b0b7-41df-bdbc-9a5cffff4355",
	93,
	13,
	16,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("335fd8b8-3003-44b7-961b-18053c1cedb8",
	95,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("fd8f66d7-12d0-4fb3-8779-517d202e43ad",
	96,
	19,
	22,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("3bd03958-084a-4b07-966d-b8ab6dfffae5",
	96,
	43,
	46,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("421a772d-15ac-4c76-9a32-20f8dad033b9",
	97,
	8,
	11,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("90a6fa06-4a4b-4407-a61e-89d375475924",
	99,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("0874af2e-ada1-48f3-a938-1cd5b94f1a6e",
	100,
	19,
	22,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("ecd51122-f6ab-4459-9713-5b2ba1985516",
	100,
	43,
	46,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("ad07ea29-fe74-40a7-852d-651d6f1bb54e",
	101,
	15,
	18,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("8fd432d4-e623-4920-a530-7833dd91ff74",
	101,
	42,
	45,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("9bc0a753-3a3d-4698-bce1-db7a4949a7a5",
	103,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("17db8284-48e9-40be-94cd-5b696e37a4e3",
	104,
	19,
	22,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("d97fe900-796c-4dcd-b1f5-def94ea899ef",
	104,
	43,
	46,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("39113919-a203-46ce-8c7e-8df1d94ab153",
	105,
	13,
	16,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("4b0b3be4-c495-45b8-b1b6-00e422319b86",
	107,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("0a3fc706-5131-4d22-a8d5-46508f0a5e6f",
	108,
	17,
	20,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("f8c38c20-3b40-4da1-ab7d-32a8969e1c9f",
	109,
	8,
	11,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("f442ec18-19a1-40b1-8425-ef12b49c3195",
	111,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("f18f3aaf-8d11-4c30-8dc6-3fb3b55f2132",
	112,
	17,
	20,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("1ec6e11a-2585-4120-b4aa-8c740bf3b66c",
	113,
	15,
	18,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("101f5644-8ccb-40b6-a6b7-8bbbb2093b94",
	113,
	42,
	45,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("811858f1-7c8b-44d0-96a4-3a685ab71c96",
	115,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("054a3e17-b441-464e-9a80-a4cbd40848d3",
	116,
	17,
	20,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("8ce5a7cf-86f4-447f-9599-896e17351b3f",
	117,
	13,
	16,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_LOC
	VALUES ("f763de7d-82b6-43e7-8caf-1f63a3ad5dd1",
	119,
	12,
	15,
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO ACT_BLK
	VALUES ("b81787d3-59eb-434e-b830-021eec3c67cd",
	0,
	0,
	0,
	'NVS',
	'',
	'',
	12,
	5,
	11,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4a6d4b82-69c0-4906-b05c-cccde5773bd1",
	"b81787d3-59eb-434e-b830-021eec3c67cd",
	"068eaa66-1227-4d31-8234-2418000a4cd4",
	11,
	5,
	'setup line: 11');
INSERT INTO ACT_AI
	VALUES ("4a6d4b82-69c0-4906-b05c-cccde5773bd1",
	"a6d1e4e9-3c07-4420-b23f-4d4470486f6e",
	"59c0bae4-087c-489b-b11a-1b530d04af84",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("068eaa66-1227-4d31-8234-2418000a4cd4",
	"b81787d3-59eb-434e-b830-021eec3c67cd",
	"00000000-0000-0000-0000-000000000000",
	12,
	5,
	'setup line: 12');
INSERT INTO ACT_IF
	VALUES ("068eaa66-1227-4d31-8234-2418000a4cd4",
	"ea931dab-407e-450e-8b69-04f11d1a7e42",
	"be79a1d8-2115-4613-b0f9-850248ea779e",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("59c0bae4-087c-489b-b11a-1b530d04af84",
	1,
	0,
	11,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b81787d3-59eb-434e-b830-021eec3c67cd");
INSERT INTO V_TVL
	VALUES ("59c0bae4-087c-489b-b11a-1b530d04af84",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("a6d1e4e9-3c07-4420-b23f-4d4470486f6e",
	0,
	0,
	11,
	14,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b81787d3-59eb-434e-b830-021eec3c67cd");
INSERT INTO V_BRV
	VALUES ("a6d1e4e9-3c07-4420-b23f-4d4470486f6e",
	"ec0815d4-cb52-4154-bbc9-7c85a2d01db4",
	1,
	11,
	9);
INSERT INTO V_VAL
	VALUES ("1526413b-40a6-440c-8fbd-de37cc9def15",
	0,
	0,
	12,
	9,
	9,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b81787d3-59eb-434e-b830-021eec3c67cd");
INSERT INTO V_TVL
	VALUES ("1526413b-40a6-440c-8fbd-de37cc9def15",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("be79a1d8-2115-4613-b0f9-850248ea779e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"b81787d3-59eb-434e-b830-021eec3c67cd");
INSERT INTO V_BIN
	VALUES ("be79a1d8-2115-4613-b0f9-850248ea779e",
	"35f980cc-945d-4992-8b01-74954c7fdd2c",
	"1526413b-40a6-440c-8fbd-de37cc9def15",
	'!=');
INSERT INTO V_VAL
	VALUES ("35f980cc-945d-4992-8b01-74954c7fdd2c",
	0,
	0,
	12,
	14,
	14,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b81787d3-59eb-434e-b830-021eec3c67cd");
INSERT INTO V_LIN
	VALUES ("35f980cc-945d-4992-8b01-74954c7fdd2c",
	'0');
INSERT INTO ACT_BLK
	VALUES ("ea931dab-407e-450e-8b69-04f11d1a7e42",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	13,
	7,
	13,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ea5b7557-ba23-4062-a10d-45fe8a3a7854",
	"ea931dab-407e-450e-8b69-04f11d1a7e42",
	"00000000-0000-0000-0000-000000000000",
	13,
	7,
	'setup line: 13');
INSERT INTO ACT_BRG
	VALUES ("ea5b7557-ba23-4062-a10d-45fe8a3a7854",
	"ea25943b-c6c2-4423-922c-947a3cd960ad",
	13,
	12,
	13,
	7);
INSERT INTO V_VAL
	VALUES ("eea3c206-3172-4451-a29b-b34129dfda9c",
	0,
	0,
	13,
	32,
	57,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"ea931dab-407e-450e-8b69-04f11d1a7e42");
INSERT INTO V_LST
	VALUES ("eea3c206-3172-4451-a29b-b34129dfda9c",
	'Error formatting the NVS.');
INSERT INTO V_PAR
	VALUES ("eea3c206-3172-4451-a29b-b34129dfda9c",
	"ea5b7557-ba23-4062-a10d-45fe8a3a7854",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	13,
	24);
INSERT INTO ACT_BLK
	VALUES ("df1dbcb3-9871-4ace-9b42-7c95b479a7db",
	0,
	0,
	0,
	'',
	'',
	'',
	26,
	3,
	24,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ba22ac80-64f4-442a-a0b3-2aa376be1901",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db",
	"3189de7c-bcd5-4138-aa4e-f95e1079327c",
	24,
	3,
	'setup line: 24');
INSERT INTO ACT_CR
	VALUES ("ba22ac80-64f4-442a-a0b3-2aa376be1901",
	"4ab133b7-756b-42d0-aa07-74ce5d35a628",
	1,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	24,
	35);
INSERT INTO ACT_SMT
	VALUES ("3189de7c-bcd5-4138-aa4e-f95e1079327c",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db",
	"f8b041e5-b7ec-4dd8-8304-405e03fdff1b",
	25,
	3,
	'setup line: 25');
INSERT INTO ACT_AI
	VALUES ("3189de7c-bcd5-4138-aa4e-f95e1079327c",
	"51c2df46-5577-4898-b441-c5ab9e737417",
	"f8e1c9d6-13b8-4367-9a68-239edd9a1ff2",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f8b041e5-b7ec-4dd8-8304-405e03fdff1b",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db",
	"00000000-0000-0000-0000-000000000000",
	26,
	3,
	'setup line: 26');
INSERT INTO ACT_AI
	VALUES ("f8b041e5-b7ec-4dd8-8304-405e03fdff1b",
	"774b87a7-0f1f-4e74-9933-0efaac49b3d1",
	"532d3c83-5a9d-494f-81a1-3f2f0ec268d4",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("8c3c9e9f-2e3a-4787-9291-d960f7a3c7bf",
	1,
	0,
	25,
	3,
	7,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db");
INSERT INTO V_IRF
	VALUES ("8c3c9e9f-2e3a-4787-9291-d960f7a3c7bf",
	"4ab133b7-756b-42d0-aa07-74ce5d35a628");
INSERT INTO V_VAL
	VALUES ("f8e1c9d6-13b8-4367-9a68-239edd9a1ff2",
	1,
	0,
	25,
	9,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db");
INSERT INTO V_AVL
	VALUES ("f8e1c9d6-13b8-4367-9a68-239edd9a1ff2",
	"8c3c9e9f-2e3a-4787-9291-d960f7a3c7bf",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO V_VAL
	VALUES ("51c2df46-5577-4898-b441-c5ab9e737417",
	0,
	0,
	25,
	17,
	17,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db");
INSERT INTO V_TVL
	VALUES ("51c2df46-5577-4898-b441-c5ab9e737417",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("532d3c83-5a9d-494f-81a1-3f2f0ec268d4",
	1,
	0,
	26,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db");
INSERT INTO V_TVL
	VALUES ("532d3c83-5a9d-494f-81a1-3f2f0ec268d4",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("74ac413a-b150-4eca-ab6f-8d254cff8270",
	0,
	0,
	26,
	7,
	7,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db");
INSERT INTO V_TVL
	VALUES ("74ac413a-b150-4eca-ab6f-8d254cff8270",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("774b87a7-0f1f-4e74-9933-0efaac49b3d1",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db");
INSERT INTO V_BIN
	VALUES ("774b87a7-0f1f-4e74-9933-0efaac49b3d1",
	"e3e4f07f-5589-4919-b2c5-f26793a95da0",
	"74ac413a-b150-4eca-ab6f-8d254cff8270",
	'-');
INSERT INTO V_VAL
	VALUES ("e3e4f07f-5589-4919-b2c5-f26793a95da0",
	0,
	0,
	26,
	11,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db");
INSERT INTO V_LIN
	VALUES ("e3e4f07f-5589-4919-b2c5-f26793a95da0",
	'1');
INSERT INTO V_VAR
	VALUES ("4ab133b7-756b-42d0-aa07-74ce5d35a628",
	"df1dbcb3-9871-4ace-9b42-7c95b479a7db",
	'digit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("4ab133b7-756b-42d0-aa07-74ce5d35a628",
	0,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("74285cf3-2adc-4dcc-87c7-72978bccd2c3",
	24,
	26,
	30,
	"4ab133b7-756b-42d0-aa07-74ce5d35a628");
INSERT INTO V_LOC
	VALUES ("02676595-4164-4082-aa12-999c4b7e2ae1",
	25,
	3,
	7,
	"4ab133b7-756b-42d0-aa07-74ce5d35a628");
INSERT INTO ACT_BLK
	VALUES ("537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	0,
	0,
	0,
	'',
	'',
	'',
	59,
	3,
	55,
	33,
	0,
	0,
	57,
	33,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f4bee3c6-bb56-4230-837b-d5524050cf48",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"b2d60ef5-4bbe-43f7-8d40-bbbe139ea6a0",
	36,
	3,
	'setup line: 36');
INSERT INTO ACT_CR
	VALUES ("f4bee3c6-bb56-4230-837b-d5524050cf48",
	"89237add-72b5-4354-9355-c1d2698d5496",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	36,
	38);
INSERT INTO ACT_SMT
	VALUES ("b2d60ef5-4bbe-43f7-8d40-bbbe139ea6a0",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"15817337-1a6d-49ec-9231-b8f3039e3362",
	37,
	3,
	'setup line: 37');
INSERT INTO ACT_AI
	VALUES ("b2d60ef5-4bbe-43f7-8d40-bbbe139ea6a0",
	"8afcd2be-e841-4a92-8a21-0ae42373e1e5",
	"6d8fe954-831e-447f-b59f-c8bcab118da3",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("15817337-1a6d-49ec-9231-b8f3039e3362",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"b7507c4b-3954-491f-a3ee-e4eb9dec880d",
	38,
	3,
	'setup line: 38');
INSERT INTO ACT_AI
	VALUES ("15817337-1a6d-49ec-9231-b8f3039e3362",
	"924bef47-ad31-4bef-9d07-019532fc5ce6",
	"fb653958-cea6-425b-ba48-ee67ea50e297",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b7507c4b-3954-491f-a3ee-e4eb9dec880d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"ab71825d-b364-406f-8ff7-73dcfab8dd69",
	39,
	3,
	'setup line: 39');
INSERT INTO ACT_CR
	VALUES ("b7507c4b-3954-491f-a3ee-e4eb9dec880d",
	"2a897f05-5f0c-4587-a6b7-93633635137f",
	1,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	39,
	33);
INSERT INTO ACT_SMT
	VALUES ("ab71825d-b364-406f-8ff7-73dcfab8dd69",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"1e4dbcbb-5b90-4bc8-9381-7d8bb9eea026",
	40,
	3,
	'setup line: 40');
INSERT INTO ACT_AI
	VALUES ("ab71825d-b364-406f-8ff7-73dcfab8dd69",
	"434dbed3-111c-4d35-917f-88b2ff7a131e",
	"f62cf684-b07a-49be-9faa-6af1b37dcd5b",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("1e4dbcbb-5b90-4bc8-9381-7d8bb9eea026",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"5c037e78-808a-426e-b216-8e2ed69cc386",
	41,
	3,
	'setup line: 41');
INSERT INTO ACT_REL
	VALUES ("1e4dbcbb-5b90-4bc8-9381-7d8bb9eea026",
	"2a897f05-5f0c-4587-a6b7-93633635137f",
	"89237add-72b5-4354-9355-c1d2698d5496",
	'',
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	41,
	33,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5c037e78-808a-426e-b216-8e2ed69cc386",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"94882b31-ed30-42bb-afdb-4cde211ed551",
	44,
	3,
	'setup line: 44');
INSERT INTO ACT_CR
	VALUES ("5c037e78-808a-426e-b216-8e2ed69cc386",
	"89237add-72b5-4354-9355-c1d2698d5496",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	44,
	38);
INSERT INTO ACT_SMT
	VALUES ("94882b31-ed30-42bb-afdb-4cde211ed551",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"45937289-7d63-4afe-8ee3-4da2d6a28275",
	45,
	3,
	'setup line: 45');
INSERT INTO ACT_AI
	VALUES ("94882b31-ed30-42bb-afdb-4cde211ed551",
	"75037820-1c39-4bcd-a273-2d573439eb66",
	"fe635f42-79e4-4c4b-91dd-1355c0ad4f26",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("45937289-7d63-4afe-8ee3-4da2d6a28275",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"54a9ba35-4cb3-467a-96dd-fd45e155a38f",
	46,
	3,
	'setup line: 46');
INSERT INTO ACT_AI
	VALUES ("45937289-7d63-4afe-8ee3-4da2d6a28275",
	"231ba46c-982c-464f-9917-48850f98ffb4",
	"89bd6af6-8388-4b1d-9c2e-dd665143b137",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("54a9ba35-4cb3-467a-96dd-fd45e155a38f",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"96a91458-103a-4717-90aa-d16f5a97fc15",
	47,
	3,
	'setup line: 47');
INSERT INTO ACT_CR
	VALUES ("54a9ba35-4cb3-467a-96dd-fd45e155a38f",
	"a483b426-8170-4ea0-84e2-ac4e742e8f12",
	1,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	47,
	36);
INSERT INTO ACT_SMT
	VALUES ("96a91458-103a-4717-90aa-d16f5a97fc15",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"b3d5bb95-fb7c-447d-b12b-314ebe6f6696",
	48,
	3,
	'setup line: 48');
INSERT INTO ACT_AI
	VALUES ("96a91458-103a-4717-90aa-d16f5a97fc15",
	"2379e40c-9526-489b-af54-6cbb288b3a8f",
	"7b0d41f1-9c71-48c4-b61b-88c79e8f67af",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b3d5bb95-fb7c-447d-b12b-314ebe6f6696",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"74bad68b-0362-48cc-869b-743f27a2ab9f",
	49,
	3,
	'setup line: 49');
INSERT INTO ACT_REL
	VALUES ("b3d5bb95-fb7c-447d-b12b-314ebe6f6696",
	"a483b426-8170-4ea0-84e2-ac4e742e8f12",
	"89237add-72b5-4354-9355-c1d2698d5496",
	'',
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	49,
	36,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("74bad68b-0362-48cc-869b-743f27a2ab9f",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"4859a8a5-cc86-4c5a-90c5-382d00608c02",
	52,
	3,
	'setup line: 52');
INSERT INTO ACT_CR
	VALUES ("74bad68b-0362-48cc-869b-743f27a2ab9f",
	"89237add-72b5-4354-9355-c1d2698d5496",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	52,
	38);
INSERT INTO ACT_SMT
	VALUES ("4859a8a5-cc86-4c5a-90c5-382d00608c02",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"bd0d048d-a921-46c1-9a81-e9f2d8511686",
	53,
	3,
	'setup line: 53');
INSERT INTO ACT_AI
	VALUES ("4859a8a5-cc86-4c5a-90c5-382d00608c02",
	"56212039-c828-420c-baaf-a700af013280",
	"ad7ca8bc-ae42-45a8-8539-93c10b6b5057",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("bd0d048d-a921-46c1-9a81-e9f2d8511686",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"b5fb907a-4958-499c-b9bf-02639899758e",
	54,
	3,
	'setup line: 54');
INSERT INTO ACT_AI
	VALUES ("bd0d048d-a921-46c1-9a81-e9f2d8511686",
	"08c913cf-634b-4bbb-8015-f29893ab213c",
	"bd1d8392-7982-43e6-9f76-5f16de1994a0",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b5fb907a-4958-499c-b9bf-02639899758e",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"641dfc75-8b74-4a54-8da6-b852c85c9428",
	55,
	3,
	'setup line: 55');
INSERT INTO ACT_CR
	VALUES ("b5fb907a-4958-499c-b9bf-02639899758e",
	"107662a4-aa06-4dd0-beed-9724722897df",
	1,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	55,
	33);
INSERT INTO ACT_SMT
	VALUES ("641dfc75-8b74-4a54-8da6-b852c85c9428",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"5af65560-c09a-459a-a9e7-6946026ac2ed",
	56,
	3,
	'setup line: 56');
INSERT INTO ACT_AI
	VALUES ("641dfc75-8b74-4a54-8da6-b852c85c9428",
	"c41a66ab-ade3-42e4-bc7e-ab86f0147394",
	"683bf2db-2758-438d-a2ac-7b3aa02c0299",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5af65560-c09a-459a-a9e7-6946026ac2ed",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"60407e82-2eb3-49c3-8b0d-f5277fa79b90",
	57,
	3,
	'setup line: 57');
INSERT INTO ACT_REL
	VALUES ("5af65560-c09a-459a-a9e7-6946026ac2ed",
	"107662a4-aa06-4dd0-beed-9724722897df",
	"89237add-72b5-4354-9355-c1d2698d5496",
	'',
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	57,
	33,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("60407e82-2eb3-49c3-8b0d-f5277fa79b90",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	"00000000-0000-0000-0000-000000000000",
	59,
	3,
	'setup line: 59');
INSERT INTO ACT_AI
	VALUES ("60407e82-2eb3-49c3-8b0d-f5277fa79b90",
	"ff4220c5-bfbb-42f3-835b-099f5f30d939",
	"be6553e9-37da-4061-a849-9bcb777c0c29",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("731ebf8b-08b4-4814-bf51-d75b1fac0503",
	1,
	0,
	37,
	3,
	10,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_IRF
	VALUES ("731ebf8b-08b4-4814-bf51-d75b1fac0503",
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_VAL
	VALUES ("6d8fe954-831e-447f-b59f-c8bcab118da3",
	1,
	0,
	37,
	12,
	17,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_AVL
	VALUES ("6d8fe954-831e-447f-b59f-c8bcab118da3",
	"731ebf8b-08b4-4814-bf51-d75b1fac0503",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"48d19dd8-8465-49b9-b4d0-dd14aa6d653f");
INSERT INTO V_VAL
	VALUES ("8afcd2be-e841-4a92-8a21-0ae42373e1e5",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_LBO
	VALUES ("8afcd2be-e841-4a92-8a21-0ae42373e1e5",
	'FALSE');
INSERT INTO V_VAL
	VALUES ("ed22f7a5-739e-4e03-ba50-5ec1c6727de3",
	1,
	0,
	38,
	3,
	10,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_IRF
	VALUES ("ed22f7a5-739e-4e03-ba50-5ec1c6727de3",
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_VAL
	VALUES ("fb653958-cea6-425b-ba48-ee67ea50e297",
	1,
	0,
	38,
	12,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_AVL
	VALUES ("fb653958-cea6-425b-ba48-ee67ea50e297",
	"ed22f7a5-739e-4e03-ba50-5ec1c6727de3",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("924bef47-ad31-4bef-9d07-019532fc5ce6",
	0,
	0,
	38,
	23,
	23,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_LIN
	VALUES ("924bef47-ad31-4bef-9d07-019532fc5ce6",
	'0');
INSERT INTO V_VAL
	VALUES ("7afdb0a6-6391-467e-8364-3133a9b474a3",
	1,
	0,
	40,
	3,
	5,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_IRF
	VALUES ("7afdb0a6-6391-467e-8364-3133a9b474a3",
	"2a897f05-5f0c-4587-a6b7-93633635137f");
INSERT INTO V_VAL
	VALUES ("f62cf684-b07a-49be-9faa-6af1b37dcd5b",
	1,
	0,
	40,
	7,
	12,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_AVL
	VALUES ("f62cf684-b07a-49be-9faa-6af1b37dcd5b",
	"7afdb0a6-6391-467e-8364-3133a9b474a3",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	"b7c46385-7816-4616-9e73-922fad4f4af1");
INSERT INTO V_VAL
	VALUES ("434dbed3-111c-4d35-917f-88b2ff7a131e",
	0,
	0,
	40,
	16,
	16,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_TVL
	VALUES ("434dbed3-111c-4d35-917f-88b2ff7a131e",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("ddf659df-532b-4dce-a9e5-02f3c2ad3cfb",
	1,
	0,
	45,
	3,
	10,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_IRF
	VALUES ("ddf659df-532b-4dce-a9e5-02f3c2ad3cfb",
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_VAL
	VALUES ("fe635f42-79e4-4c4b-91dd-1355c0ad4f26",
	1,
	0,
	45,
	12,
	17,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_AVL
	VALUES ("fe635f42-79e4-4c4b-91dd-1355c0ad4f26",
	"ddf659df-532b-4dce-a9e5-02f3c2ad3cfb",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"48d19dd8-8465-49b9-b4d0-dd14aa6d653f");
INSERT INTO V_VAL
	VALUES ("75037820-1c39-4bcd-a273-2d573439eb66",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_LBO
	VALUES ("75037820-1c39-4bcd-a273-2d573439eb66",
	'FALSE');
INSERT INTO V_VAL
	VALUES ("c6c513c8-f6fe-4bc0-afed-4f85087a2d5b",
	1,
	0,
	46,
	3,
	10,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_IRF
	VALUES ("c6c513c8-f6fe-4bc0-afed-4f85087a2d5b",
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_VAL
	VALUES ("89bd6af6-8388-4b1d-9c2e-dd665143b137",
	1,
	0,
	46,
	12,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_AVL
	VALUES ("89bd6af6-8388-4b1d-9c2e-dd665143b137",
	"c6c513c8-f6fe-4bc0-afed-4f85087a2d5b",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("231ba46c-982c-464f-9917-48850f98ffb4",
	0,
	0,
	46,
	23,
	23,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_LIN
	VALUES ("231ba46c-982c-464f-9917-48850f98ffb4",
	'0');
INSERT INTO V_VAL
	VALUES ("f8d106d8-6ddf-48cc-8606-68b3fba15b95",
	1,
	0,
	48,
	3,
	8,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_IRF
	VALUES ("f8d106d8-6ddf-48cc-8606-68b3fba15b95",
	"a483b426-8170-4ea0-84e2-ac4e742e8f12");
INSERT INTO V_VAL
	VALUES ("7b0d41f1-9c71-48c4-b61b-88c79e8f67af",
	1,
	0,
	48,
	10,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_AVL
	VALUES ("7b0d41f1-9c71-48c4-b61b-88c79e8f67af",
	"f8d106d8-6ddf-48cc-8606-68b3fba15b95",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	"90e0d09a-7fa5-45f0-ac4f-f519aa651f29");
INSERT INTO V_VAL
	VALUES ("2379e40c-9526-489b-af54-6cbb288b3a8f",
	0,
	0,
	48,
	19,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_TVL
	VALUES ("2379e40c-9526-489b-af54-6cbb288b3a8f",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("ab3614f4-62d9-454f-be79-1096f1f418ad",
	1,
	0,
	53,
	3,
	10,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_IRF
	VALUES ("ab3614f4-62d9-454f-be79-1096f1f418ad",
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_VAL
	VALUES ("ad7ca8bc-ae42-45a8-8539-93c10b6b5057",
	1,
	0,
	53,
	12,
	17,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_AVL
	VALUES ("ad7ca8bc-ae42-45a8-8539-93c10b6b5057",
	"ab3614f4-62d9-454f-be79-1096f1f418ad",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"48d19dd8-8465-49b9-b4d0-dd14aa6d653f");
INSERT INTO V_VAL
	VALUES ("56212039-c828-420c-baaf-a700af013280",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_LBO
	VALUES ("56212039-c828-420c-baaf-a700af013280",
	'FALSE');
INSERT INTO V_VAL
	VALUES ("32e62a3c-7c0b-4ce1-a67d-1f821579d0f3",
	1,
	0,
	54,
	3,
	10,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_IRF
	VALUES ("32e62a3c-7c0b-4ce1-a67d-1f821579d0f3",
	"89237add-72b5-4354-9355-c1d2698d5496");
INSERT INTO V_VAL
	VALUES ("bd1d8392-7982-43e6-9f76-5f16de1994a0",
	1,
	0,
	54,
	12,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_AVL
	VALUES ("bd1d8392-7982-43e6-9f76-5f16de1994a0",
	"32e62a3c-7c0b-4ce1-a67d-1f821579d0f3",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("08c913cf-634b-4bbb-8015-f29893ab213c",
	0,
	0,
	54,
	23,
	23,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_LIN
	VALUES ("08c913cf-634b-4bbb-8015-f29893ab213c",
	'0');
INSERT INTO V_VAL
	VALUES ("898f6882-3f7e-4339-9fec-e36e5bab266e",
	1,
	0,
	56,
	3,
	5,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_IRF
	VALUES ("898f6882-3f7e-4339-9fec-e36e5bab266e",
	"107662a4-aa06-4dd0-beed-9724722897df");
INSERT INTO V_VAL
	VALUES ("683bf2db-2758-438d-a2ac-7b3aa02c0299",
	1,
	0,
	56,
	7,
	12,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_AVL
	VALUES ("683bf2db-2758-438d-a2ac-7b3aa02c0299",
	"898f6882-3f7e-4339-9fec-e36e5bab266e",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1");
INSERT INTO V_VAL
	VALUES ("c41a66ab-ade3-42e4-bc7e-ab86f0147394",
	0,
	0,
	56,
	16,
	16,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_TVL
	VALUES ("c41a66ab-ade3-42e4-bc7e-ab86f0147394",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("be6553e9-37da-4061-a849-9bcb777c0c29",
	1,
	0,
	59,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_TVL
	VALUES ("be6553e9-37da-4061-a849-9bcb777c0c29",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("d83a5e60-967e-4e77-ba6a-37e786720e2c",
	0,
	0,
	59,
	7,
	7,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_TVL
	VALUES ("d83a5e60-967e-4e77-ba6a-37e786720e2c",
	"875381df-3143-40f5-b144-3f13ce6aafc7");
INSERT INTO V_VAL
	VALUES ("ff4220c5-bfbb-42f3-835b-099f5f30d939",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_BIN
	VALUES ("ff4220c5-bfbb-42f3-835b-099f5f30d939",
	"b5bc8667-efa4-47a2-b911-e028cc00bbba",
	"d83a5e60-967e-4e77-ba6a-37e786720e2c",
	'-');
INSERT INTO V_VAL
	VALUES ("b5bc8667-efa4-47a2-b911-e028cc00bbba",
	0,
	0,
	59,
	11,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f");
INSERT INTO V_LIN
	VALUES ("b5bc8667-efa4-47a2-b911-e028cc00bbba",
	'1');
INSERT INTO V_VAR
	VALUES ("2a897f05-5f0c-4587-a6b7-93633635137f",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	'row',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("2a897f05-5f0c-4587-a6b7-93633635137f",
	0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("e797d326-0436-4d27-a631-99891e8f8f52",
	39,
	26,
	28,
	"2a897f05-5f0c-4587-a6b7-93633635137f");
INSERT INTO V_LOC
	VALUES ("3af53054-5910-4240-814e-6cc0f1f00701",
	40,
	3,
	5,
	"2a897f05-5f0c-4587-a6b7-93633635137f");
INSERT INTO V_LOC
	VALUES ("86825d69-0222-4e26-b299-86bd0d87145b",
	41,
	10,
	12,
	"2a897f05-5f0c-4587-a6b7-93633635137f");
INSERT INTO V_VAR
	VALUES ("a483b426-8170-4ea0-84e2-ac4e742e8f12",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	'column',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("a483b426-8170-4ea0-84e2-ac4e742e8f12",
	0,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_LOC
	VALUES ("74f04ddb-9b60-48f4-9b02-3014d88e95c4",
	47,
	26,
	31,
	"a483b426-8170-4ea0-84e2-ac4e742e8f12");
INSERT INTO V_LOC
	VALUES ("98841963-44a5-4ba6-8ded-5ab4dd25a453",
	48,
	3,
	8,
	"a483b426-8170-4ea0-84e2-ac4e742e8f12");
INSERT INTO V_LOC
	VALUES ("6ecfc84b-93aa-4056-8bae-839c1dc0ba07",
	49,
	10,
	15,
	"a483b426-8170-4ea0-84e2-ac4e742e8f12");
INSERT INTO V_VAR
	VALUES ("107662a4-aa06-4dd0-beed-9724722897df",
	"537aaa7b-fc14-4b5e-937f-ad5a9349110f",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("107662a4-aa06-4dd0-beed-9724722897df",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("553c1aec-4aa0-486b-b1d8-b6dede502835",
	55,
	26,
	28,
	"107662a4-aa06-4dd0-beed-9724722897df");
INSERT INTO V_LOC
	VALUES ("5153c091-0046-4722-9dde-09c66d69e70d",
	56,
	3,
	5,
	"107662a4-aa06-4dd0-beed-9724722897df");
INSERT INTO V_LOC
	VALUES ("a70230e6-5634-4448-b116-873bb2052d63",
	57,
	10,
	12,
	"107662a4-aa06-4dd0-beed-9724722897df");
INSERT INTO ACT_BLK
	VALUES ("592b84a4-6f65-49cf-8d86-7d900aa8eaa9",
	1,
	0,
	0,
	'',
	'',
	'',
	65,
	3,
	64,
	41,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ab048782-8a79-468a-8f05-9fd6a2929815",
	"592b84a4-6f65-49cf-8d86-7d900aa8eaa9",
	"736ba3cc-72c6-461e-8e1d-6c5ea4c159a4",
	64,
	3,
	'setup line: 64');
INSERT INTO ACT_FIO
	VALUES ("ab048782-8a79-468a-8f05-9fd6a2929815",
	"f771b821-e2ec-46f9-a72c-8a73a63aa741",
	1,
	'many',
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	64,
	41);
INSERT INTO ACT_SMT
	VALUES ("736ba3cc-72c6-461e-8e1d-6c5ea4c159a4",
	"592b84a4-6f65-49cf-8d86-7d900aa8eaa9",
	"00000000-0000-0000-0000-000000000000",
	65,
	3,
	'setup line: 65');
INSERT INTO ACT_FOR
	VALUES ("736ba3cc-72c6-461e-8e1d-6c5ea4c159a4",
	"6b825613-0f35-4da3-addd-449a4ef78b3d",
	1,
	"d3ba367c-27f4-44d7-a43c-6a75c08c98dc",
	"f771b821-e2ec-46f9-a72c-8a73a63aa741",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_VAR
	VALUES ("f771b821-e2ec-46f9-a72c-8a73a63aa741",
	"592b84a4-6f65-49cf-8d86-7d900aa8eaa9",
	'columns',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("f771b821-e2ec-46f9-a72c-8a73a63aa741",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_LOC
	VALUES ("d2dd3289-eb4d-455e-858c-1c0db1b9ae63",
	64,
	15,
	21,
	"f771b821-e2ec-46f9-a72c-8a73a63aa741");
INSERT INTO V_LOC
	VALUES ("825eff6c-024d-47f9-96f9-60a57744ce1f",
	65,
	22,
	28,
	"f771b821-e2ec-46f9-a72c-8a73a63aa741");
INSERT INTO V_VAR
	VALUES ("d3ba367c-27f4-44d7-a43c-6a75c08c98dc",
	"592b84a4-6f65-49cf-8d86-7d900aa8eaa9",
	'column',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("d3ba367c-27f4-44d7-a43c-6a75c08c98dc",
	1,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_LOC
	VALUES ("a9fb64e4-e93e-4667-b1d0-0d7c770be594",
	65,
	12,
	17,
	"d3ba367c-27f4-44d7-a43c-6a75c08c98dc");
INSERT INTO V_LOC
	VALUES ("4199759a-b659-4258-8f71-a642a075c803",
	70,
	20,
	25,
	"d3ba367c-27f4-44d7-a43c-6a75c08c98dc");
INSERT INTO ACT_BLK
	VALUES ("6b825613-0f35-4da3-addd-449a4ef78b3d",
	1,
	0,
	1,
	'',
	'',
	'',
	74,
	5,
	73,
	42,
	0,
	0,
	70,
	34,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("58bbc912-ef5d-463e-aab3-8fa110b05d79",
	"6b825613-0f35-4da3-addd-449a4ef78b3d",
	"1719f70d-ace3-48ab-8c63-3bbe6ceef7fa",
	66,
	5,
	'setup line: 66');
INSERT INTO ACT_CR
	VALUES ("58bbc912-ef5d-463e-aab3-8fa110b05d79",
	"60ae151c-a035-44ce-91e3-cc7e076415f7",
	1,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	66,
	36);
INSERT INTO ACT_SMT
	VALUES ("1719f70d-ace3-48ab-8c63-3bbe6ceef7fa",
	"6b825613-0f35-4da3-addd-449a4ef78b3d",
	"915788b4-2b5e-405a-a896-7c5f1c0a97eb",
	67,
	5,
	'setup line: 67');
INSERT INTO ACT_FIW
	VALUES ("1719f70d-ace3-48ab-8c63-3bbe6ceef7fa",
	"b0991106-99dc-4c9a-b681-ef1915ad5416",
	0,
	'any',
	"846a02db-fbdd-46e2-9c8d-232f38d55a6e",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	67,
	40);
INSERT INTO ACT_SMT
	VALUES ("915788b4-2b5e-405a-a896-7c5f1c0a97eb",
	"6b825613-0f35-4da3-addd-449a4ef78b3d",
	"81bcbb9a-51dc-4b93-a045-72186ebb01cc",
	68,
	5,
	'setup line: 68');
INSERT INTO ACT_REL
	VALUES ("915788b4-2b5e-405a-a896-7c5f1c0a97eb",
	"60ae151c-a035-44ce-91e3-cc7e076415f7",
	"b0991106-99dc-4c9a-b681-ef1915ad5416",
	'',
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	68,
	33,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("81bcbb9a-51dc-4b93-a045-72186ebb01cc",
	"6b825613-0f35-4da3-addd-449a4ef78b3d",
	"3be54a0c-4fc5-4863-8836-3957e49756e9",
	69,
	5,
	'setup line: 69');
INSERT INTO ACT_REL
	VALUES ("81bcbb9a-51dc-4b93-a045-72186ebb01cc",
	"60ae151c-a035-44ce-91e3-cc7e076415f7",
	"c7ea13d0-0a5e-4dba-8137-0c4cb62a6561",
	'',
	"c9931c97-9acb-4b55-af72-81add52c1825",
	69,
	31,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("3be54a0c-4fc5-4863-8836-3957e49756e9",
	"6b825613-0f35-4da3-addd-449a4ef78b3d",
	"eef76554-a101-41f6-a7df-3ae3419eb26e",
	70,
	5,
	'setup line: 70');
INSERT INTO ACT_REL
	VALUES ("3be54a0c-4fc5-4863-8836-3957e49756e9",
	"60ae151c-a035-44ce-91e3-cc7e076415f7",
	"d3ba367c-27f4-44d7-a43c-6a75c08c98dc",
	'',
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	70,
	34,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("eef76554-a101-41f6-a7df-3ae3419eb26e",
	"6b825613-0f35-4da3-addd-449a4ef78b3d",
	"5e3dd1ac-bd81-41a8-ac4d-33eb0d518243",
	73,
	5,
	'setup line: 73');
INSERT INTO ACT_FIW
	VALUES ("eef76554-a101-41f6-a7df-3ae3419eb26e",
	"976d5ec6-1fea-49af-b8b0-8c548f9a1310",
	1,
	'many',
	"d4123dc9-e9f2-4a16-8678-d34f196e0f15",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	73,
	42);
INSERT INTO ACT_SMT
	VALUES ("5e3dd1ac-bd81-41a8-ac4d-33eb0d518243",
	"6b825613-0f35-4da3-addd-449a4ef78b3d",
	"00000000-0000-0000-0000-000000000000",
	74,
	5,
	'setup line: 74');
INSERT INTO ACT_FOR
	VALUES ("5e3dd1ac-bd81-41a8-ac4d-33eb0d518243",
	"251717cd-b8be-4d1e-a85f-f473a4fbbfea",
	0,
	"b0991106-99dc-4c9a-b681-ef1915ad5416",
	"976d5ec6-1fea-49af-b8b0-8c548f9a1310",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_VAL
	VALUES ("faf90528-eae7-49f6-8140-313fa492704e",
	0,
	0,
	67,
	54,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"6b825613-0f35-4da3-addd-449a4ef78b3d");
INSERT INTO V_SLR
	VALUES ("faf90528-eae7-49f6-8140-313fa492704e",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("dc1ce734-08fd-45fa-87be-471887c09e5f",
	0,
	0,
	67,
	63,
	67,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"6b825613-0f35-4da3-addd-449a4ef78b3d");
INSERT INTO V_AVL
	VALUES ("dc1ce734-08fd-45fa-87be-471887c09e5f",
	"faf90528-eae7-49f6-8140-313fa492704e",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO V_VAL
	VALUES ("846a02db-fbdd-46e2-9c8d-232f38d55a6e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"6b825613-0f35-4da3-addd-449a4ef78b3d");
INSERT INTO V_BIN
	VALUES ("846a02db-fbdd-46e2-9c8d-232f38d55a6e",
	"e7985a2a-56bb-4c7a-9fbf-624e64bef871",
	"dc1ce734-08fd-45fa-87be-471887c09e5f",
	'==');
INSERT INTO V_VAL
	VALUES ("e7985a2a-56bb-4c7a-9fbf-624e64bef871",
	0,
	0,
	67,
	72,
	72,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"6b825613-0f35-4da3-addd-449a4ef78b3d");
INSERT INTO V_LIN
	VALUES ("e7985a2a-56bb-4c7a-9fbf-624e64bef871",
	'0');
INSERT INTO V_VAL
	VALUES ("bedd3883-c82a-4526-854b-dae0999d746d",
	0,
	0,
	73,
	56,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"6b825613-0f35-4da3-addd-449a4ef78b3d");
INSERT INTO V_SLR
	VALUES ("bedd3883-c82a-4526-854b-dae0999d746d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("44653fff-f9f6-4b1b-a7c9-ed959a0fdda8",
	0,
	0,
	73,
	65,
	69,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"6b825613-0f35-4da3-addd-449a4ef78b3d");
INSERT INTO V_AVL
	VALUES ("44653fff-f9f6-4b1b-a7c9-ed959a0fdda8",
	"bedd3883-c82a-4526-854b-dae0999d746d",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO V_VAL
	VALUES ("d4123dc9-e9f2-4a16-8678-d34f196e0f15",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"6b825613-0f35-4da3-addd-449a4ef78b3d");
INSERT INTO V_BIN
	VALUES ("d4123dc9-e9f2-4a16-8678-d34f196e0f15",
	"f53cd4b9-168d-4376-985c-30f8cb7fdfb7",
	"44653fff-f9f6-4b1b-a7c9-ed959a0fdda8",
	'!=');
INSERT INTO V_VAL
	VALUES ("f53cd4b9-168d-4376-985c-30f8cb7fdfb7",
	0,
	0,
	73,
	74,
	74,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"6b825613-0f35-4da3-addd-449a4ef78b3d");
INSERT INTO V_LIN
	VALUES ("f53cd4b9-168d-4376-985c-30f8cb7fdfb7",
	'0');
INSERT INTO V_VAR
	VALUES ("60ae151c-a035-44ce-91e3-cc7e076415f7",
	"6b825613-0f35-4da3-addd-449a4ef78b3d",
	'cell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("60ae151c-a035-44ce-91e3-cc7e076415f7",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("ca44f6df-f80e-4fda-a03f-c84a93deca09",
	66,
	28,
	31,
	"60ae151c-a035-44ce-91e3-cc7e076415f7");
INSERT INTO V_LOC
	VALUES ("1642e5e6-b6a0-4605-a9a8-34f5dfef7c7f",
	68,
	12,
	15,
	"60ae151c-a035-44ce-91e3-cc7e076415f7");
INSERT INTO V_LOC
	VALUES ("680c3bb9-7ea9-42db-9205-e470d22b2a10",
	69,
	12,
	15,
	"60ae151c-a035-44ce-91e3-cc7e076415f7");
INSERT INTO V_LOC
	VALUES ("dabc0db7-fbae-40dc-a2da-e00e001de907",
	70,
	12,
	15,
	"60ae151c-a035-44ce-91e3-cc7e076415f7");
INSERT INTO V_LOC
	VALUES ("b005ca59-a2bd-41ea-8bfb-6b281df8967e",
	76,
	23,
	26,
	"60ae151c-a035-44ce-91e3-cc7e076415f7");
INSERT INTO V_VAR
	VALUES ("976d5ec6-1fea-49af-b8b0-8c548f9a1310",
	"6b825613-0f35-4da3-addd-449a4ef78b3d",
	'digits',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("976d5ec6-1fea-49af-b8b0-8c548f9a1310",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("2f991f63-c05a-4e48-a6a3-7f897393b426",
	73,
	17,
	22,
	"976d5ec6-1fea-49af-b8b0-8c548f9a1310");
INSERT INTO V_LOC
	VALUES ("5829e39b-ff24-46fe-82c5-c99b39b055d9",
	74,
	23,
	28,
	"976d5ec6-1fea-49af-b8b0-8c548f9a1310");
INSERT INTO ACT_BLK
	VALUES ("251717cd-b8be-4d1e-a85f-f473a4fbbfea",
	0,
	0,
	0,
	'',
	'',
	'',
	76,
	7,
	75,
	42,
	0,
	0,
	76,
	35,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d1b6929a-9cee-42aa-b77a-6d3694801955",
	"251717cd-b8be-4d1e-a85f-f473a4fbbfea",
	"13a04376-b8a5-47ec-a100-f25d17eb1de4",
	75,
	7,
	'setup line: 75');
INSERT INTO ACT_CR
	VALUES ("d1b6929a-9cee-42aa-b77a-6d3694801955",
	"13b1217c-9a0e-4005-8401-630dce7da115",
	1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	75,
	42);
INSERT INTO ACT_SMT
	VALUES ("13a04376-b8a5-47ec-a100-f25d17eb1de4",
	"251717cd-b8be-4d1e-a85f-f473a4fbbfea",
	"00000000-0000-0000-0000-000000000000",
	76,
	7,
	'setup line: 76');
INSERT INTO ACT_RU
	VALUES ("13a04376-b8a5-47ec-a100-f25d17eb1de4",
	"b0991106-99dc-4c9a-b681-ef1915ad5416",
	"60ae151c-a035-44ce-91e3-cc7e076415f7",
	"13b1217c-9a0e-4005-8401-630dce7da115",
	'',
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	76,
	35,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("13b1217c-9a0e-4005-8401-630dce7da115",
	"251717cd-b8be-4d1e-a85f-f473a4fbbfea",
	'eligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("13b1217c-9a0e-4005-8401-630dce7da115",
	0,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("456fb2c6-d154-4d12-add5-7cca0fd6b289",
	75,
	30,
	37,
	"13b1217c-9a0e-4005-8401-630dce7da115");
INSERT INTO V_LOC
	VALUES ("ee524a22-ad4c-448c-87a0-26bd5a01d506",
	76,
	44,
	51,
	"13b1217c-9a0e-4005-8401-630dce7da115");
INSERT INTO ACT_BLK
	VALUES ("ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	0,
	0,
	0,
	'',
	'',
	'',
	116,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3bf85d97-0101-4dbe-91b2-9c802c7e73e7",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	"00000000-0000-0000-0000-000000000000",
	84,
	3,
	'setup line: 84');
INSERT INTO ACT_IF
	VALUES ("3bf85d97-0101-4dbe-91b2-9c802c7e73e7",
	"e813b265-52dc-49cb-97d1-6870b2ce39b5",
	"616ef082-06f0-4b47-91a2-1f4be8fe0144",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("cb4eb6e4-8a53-49c1-9406-a129699092a8",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	"00000000-0000-0000-0000-000000000000",
	88,
	3,
	'setup line: 88');
INSERT INTO ACT_EL
	VALUES ("cb4eb6e4-8a53-49c1-9406-a129699092a8",
	"90fe7960-f2b8-42e5-8b27-5097b29aa7b1",
	"3acbde3d-6cf0-45df-b606-41b840554f23",
	"3bf85d97-0101-4dbe-91b2-9c802c7e73e7");
INSERT INTO ACT_SMT
	VALUES ("e026696d-4150-44f9-8de9-17b09de93ae8",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	"00000000-0000-0000-0000-000000000000",
	92,
	3,
	'setup line: 92');
INSERT INTO ACT_EL
	VALUES ("e026696d-4150-44f9-8de9-17b09de93ae8",
	"5f8c51e9-feb6-4d18-bb84-f99bfae5c4ab",
	"0c6af2f7-08e8-4dd7-ace9-4d02ddd48825",
	"3bf85d97-0101-4dbe-91b2-9c802c7e73e7");
INSERT INTO ACT_SMT
	VALUES ("91d0f876-352a-4083-97cf-a1ba8e0c54ac",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	"00000000-0000-0000-0000-000000000000",
	96,
	3,
	'setup line: 96');
INSERT INTO ACT_EL
	VALUES ("91d0f876-352a-4083-97cf-a1ba8e0c54ac",
	"56f01c9c-dc5f-42b0-89fa-d67cbe802ea7",
	"49d3c3b0-cd7c-4ac0-803b-b1378ba036f8",
	"3bf85d97-0101-4dbe-91b2-9c802c7e73e7");
INSERT INTO ACT_SMT
	VALUES ("c3700faa-a4a8-4b42-a0c9-5bc6ab9845ab",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	"00000000-0000-0000-0000-000000000000",
	100,
	3,
	'setup line: 100');
INSERT INTO ACT_EL
	VALUES ("c3700faa-a4a8-4b42-a0c9-5bc6ab9845ab",
	"a10039c3-4604-4312-b92c-813ea8d76386",
	"8357274b-099b-4237-bfe0-66280eed2d39",
	"3bf85d97-0101-4dbe-91b2-9c802c7e73e7");
INSERT INTO ACT_SMT
	VALUES ("c43f10f7-35d4-423f-85e1-1a8038966974",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	"00000000-0000-0000-0000-000000000000",
	104,
	3,
	'setup line: 104');
INSERT INTO ACT_EL
	VALUES ("c43f10f7-35d4-423f-85e1-1a8038966974",
	"b9440527-e276-47ef-a28e-53681b782ead",
	"f64df9d2-818f-4283-a83e-0e55c211669b",
	"3bf85d97-0101-4dbe-91b2-9c802c7e73e7");
INSERT INTO ACT_SMT
	VALUES ("0abccf26-be64-41b0-9c48-7fd5f3c12b0f",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	"00000000-0000-0000-0000-000000000000",
	108,
	3,
	'setup line: 108');
INSERT INTO ACT_EL
	VALUES ("0abccf26-be64-41b0-9c48-7fd5f3c12b0f",
	"d282a724-4883-4fcd-95ca-9846870ef19c",
	"18ada3f5-b2b4-44f1-ac78-3757d40c2de1",
	"3bf85d97-0101-4dbe-91b2-9c802c7e73e7");
INSERT INTO ACT_SMT
	VALUES ("bb4c5a6b-6647-4b68-a11b-7d522deca146",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	"00000000-0000-0000-0000-000000000000",
	112,
	3,
	'setup line: 112');
INSERT INTO ACT_EL
	VALUES ("bb4c5a6b-6647-4b68-a11b-7d522deca146",
	"95064ec7-3be4-4e60-899f-293c293e9949",
	"f57df546-b562-4f27-8ebc-7ae788e92b84",
	"3bf85d97-0101-4dbe-91b2-9c802c7e73e7");
INSERT INTO ACT_SMT
	VALUES ("796a1707-13b2-4ffd-9e16-b4d2a0041f64",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2",
	"00000000-0000-0000-0000-000000000000",
	116,
	3,
	'setup line: 116');
INSERT INTO ACT_EL
	VALUES ("796a1707-13b2-4ffd-9e16-b4d2a0041f64",
	"ec2eb6f8-9922-4a3b-ac21-63312c0301d5",
	"f8f5ff6e-babf-4c4e-a2b8-0e8b2d0cd691",
	"3bf85d97-0101-4dbe-91b2-9c802c7e73e7");
INSERT INTO V_VAL
	VALUES ("3faae48c-15f6-4638-ba72-e30c43634d50",
	0,
	0,
	84,
	10,
	13,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("3faae48c-15f6-4638-ba72-e30c43634d50",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("048a6ea5-aaf8-41a8-8c16-fb9dfcffbe21",
	0,
	0,
	84,
	15,
	24,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("048a6ea5-aaf8-41a8-8c16-fb9dfcffbe21",
	"3faae48c-15f6-4638-ba72-e30c43634d50",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("d75a26c6-168a-4a82-95d7-29908e7926f0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("d75a26c6-168a-4a82-95d7-29908e7926f0",
	"7ee2ca41-902f-4052-8cfb-9821d6af2d45",
	"048a6ea5-aaf8-41a8-8c16-fb9dfcffbe21",
	'<=');
INSERT INTO V_VAL
	VALUES ("7ee2ca41-902f-4052-8cfb-9821d6af2d45",
	0,
	0,
	84,
	29,
	29,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("7ee2ca41-902f-4052-8cfb-9821d6af2d45",
	'3');
INSERT INTO V_VAL
	VALUES ("aba94e4a-028a-42de-a2bc-ce68bff1cbd4",
	0,
	0,
	85,
	8,
	11,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("aba94e4a-028a-42de-a2bc-ce68bff1cbd4",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("5682c839-db2d-419d-b66c-cb3b40f38857",
	0,
	0,
	85,
	13,
	25,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("5682c839-db2d-419d-b66c-cb3b40f38857",
	"aba94e4a-028a-42de-a2bc-ce68bff1cbd4",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("36f4dbe4-e340-4d20-85f5-5e3e00a935ca",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("36f4dbe4-e340-4d20-85f5-5e3e00a935ca",
	"9d51ed0c-61d9-4619-88b3-ca8b1835dcf9",
	"5682c839-db2d-419d-b66c-cb3b40f38857",
	'<=');
INSERT INTO V_VAL
	VALUES ("9d51ed0c-61d9-4619-88b3-ca8b1835dcf9",
	0,
	0,
	85,
	30,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("9d51ed0c-61d9-4619-88b3-ca8b1835dcf9",
	'3');
INSERT INTO V_VAL
	VALUES ("616ef082-06f0-4b47-91a2-1f4be8fe0144",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("616ef082-06f0-4b47-91a2-1f4be8fe0144",
	"36f4dbe4-e340-4d20-85f5-5e3e00a935ca",
	"d75a26c6-168a-4a82-95d7-29908e7926f0",
	'and');
INSERT INTO V_VAL
	VALUES ("1728d308-fd26-4ce3-af0d-45d39954696e",
	0,
	0,
	88,
	12,
	15,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("1728d308-fd26-4ce3-af0d-45d39954696e",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("cd21360d-03cc-4523-91bb-ed5838bf9e21",
	0,
	0,
	88,
	17,
	26,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("cd21360d-03cc-4523-91bb-ed5838bf9e21",
	"1728d308-fd26-4ce3-af0d-45d39954696e",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("93e33b87-f2f9-482d-8c83-e6263cc93335",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("93e33b87-f2f9-482d-8c83-e6263cc93335",
	"075e547b-a1ae-4077-9b71-18093b10b001",
	"cd21360d-03cc-4523-91bb-ed5838bf9e21",
	'<=');
INSERT INTO V_VAL
	VALUES ("075e547b-a1ae-4077-9b71-18093b10b001",
	0,
	0,
	88,
	31,
	31,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("075e547b-a1ae-4077-9b71-18093b10b001",
	'3');
INSERT INTO V_VAL
	VALUES ("c81c8fd6-052f-4de2-b161-6df8332d218e",
	0,
	0,
	89,
	10,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("c81c8fd6-052f-4de2-b161-6df8332d218e",
	'4');
INSERT INTO V_VAL
	VALUES ("abbc6c2f-dbe4-42db-81ae-2edf0e4253d6",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("abbc6c2f-dbe4-42db-81ae-2edf0e4253d6",
	"68592d4f-4e69-450c-a935-a0daa0633179",
	"c81c8fd6-052f-4de2-b161-6df8332d218e",
	'<=');
INSERT INTO V_VAL
	VALUES ("ed875d07-a251-4eca-9c7f-a72e6227fb52",
	0,
	0,
	89,
	15,
	18,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("ed875d07-a251-4eca-9c7f-a72e6227fb52",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("68592d4f-4e69-450c-a935-a0daa0633179",
	0,
	0,
	89,
	20,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("68592d4f-4e69-450c-a935-a0daa0633179",
	"ed875d07-a251-4eca-9c7f-a72e6227fb52",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("68f95abe-3a05-4da6-8e92-f317b70e6442",
	0,
	0,
	89,
	42,
	45,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("68f95abe-3a05-4da6-8e92-f317b70e6442",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("f1c30d5a-aa56-42fd-89af-d7591b5caa68",
	0,
	0,
	89,
	47,
	59,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("f1c30d5a-aa56-42fd-89af-d7591b5caa68",
	"68f95abe-3a05-4da6-8e92-f317b70e6442",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("9a409133-bc3c-48fe-8369-88def05e6928",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("9a409133-bc3c-48fe-8369-88def05e6928",
	"f2b295eb-d7f4-4b02-81ca-8e761d0d4b88",
	"f1c30d5a-aa56-42fd-89af-d7591b5caa68",
	'<=');
INSERT INTO V_VAL
	VALUES ("f2b295eb-d7f4-4b02-81ca-8e761d0d4b88",
	0,
	0,
	89,
	64,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("f2b295eb-d7f4-4b02-81ca-8e761d0d4b88",
	'6');
INSERT INTO V_VAL
	VALUES ("f31c9bcd-ced1-4025-8ec3-dd2aaf8d8e06",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("f31c9bcd-ced1-4025-8ec3-dd2aaf8d8e06",
	"9a409133-bc3c-48fe-8369-88def05e6928",
	"abbc6c2f-dbe4-42db-81ae-2edf0e4253d6",
	'and');
INSERT INTO V_VAL
	VALUES ("3acbde3d-6cf0-45df-b606-41b840554f23",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("3acbde3d-6cf0-45df-b606-41b840554f23",
	"f31c9bcd-ced1-4025-8ec3-dd2aaf8d8e06",
	"93e33b87-f2f9-482d-8c83-e6263cc93335",
	'and');
INSERT INTO V_VAL
	VALUES ("7a10bd7d-3d91-4d00-a0d4-c40897ba1a90",
	0,
	0,
	92,
	12,
	15,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("7a10bd7d-3d91-4d00-a0d4-c40897ba1a90",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("830e5b0d-a75c-4f44-97cc-4888f5a84647",
	0,
	0,
	92,
	17,
	26,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("830e5b0d-a75c-4f44-97cc-4888f5a84647",
	"7a10bd7d-3d91-4d00-a0d4-c40897ba1a90",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("46c48b32-e76f-4c09-93a2-dfd343440ef0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("46c48b32-e76f-4c09-93a2-dfd343440ef0",
	"790a8d12-37ab-446a-8964-e494c2778ef4",
	"830e5b0d-a75c-4f44-97cc-4888f5a84647",
	'<=');
INSERT INTO V_VAL
	VALUES ("790a8d12-37ab-446a-8964-e494c2778ef4",
	0,
	0,
	92,
	31,
	31,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("790a8d12-37ab-446a-8964-e494c2778ef4",
	'3');
INSERT INTO V_VAL
	VALUES ("cc923948-96f3-4da0-bd50-c189d0ed31d2",
	0,
	0,
	93,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("cc923948-96f3-4da0-bd50-c189d0ed31d2",
	'7');
INSERT INTO V_VAL
	VALUES ("874bf0d5-740e-48e0-9a8c-423a4774b4b8",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("874bf0d5-740e-48e0-9a8c-423a4774b4b8",
	"a830e638-0bcb-466d-9be4-ef1689e9a59b",
	"cc923948-96f3-4da0-bd50-c189d0ed31d2",
	'<=');
INSERT INTO V_VAL
	VALUES ("fedb3042-365e-4e7c-8fc9-123d3ad5a02e",
	0,
	0,
	93,
	13,
	16,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("fedb3042-365e-4e7c-8fc9-123d3ad5a02e",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("a830e638-0bcb-466d-9be4-ef1689e9a59b",
	0,
	0,
	93,
	18,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("a830e638-0bcb-466d-9be4-ef1689e9a59b",
	"fedb3042-365e-4e7c-8fc9-123d3ad5a02e",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("0c6af2f7-08e8-4dd7-ace9-4d02ddd48825",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("0c6af2f7-08e8-4dd7-ace9-4d02ddd48825",
	"874bf0d5-740e-48e0-9a8c-423a4774b4b8",
	"46c48b32-e76f-4c09-93a2-dfd343440ef0",
	'and');
INSERT INTO V_VAL
	VALUES ("675606d0-4fef-438f-9ed6-778d1357432b",
	0,
	0,
	96,
	14,
	14,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("675606d0-4fef-438f-9ed6-778d1357432b",
	'4');
INSERT INTO V_VAL
	VALUES ("9f4bdc82-2a3c-4fdd-bcce-824832c3478b",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("9f4bdc82-2a3c-4fdd-bcce-824832c3478b",
	"04000476-0f26-4227-8ba0-1ccc716e1c78",
	"675606d0-4fef-438f-9ed6-778d1357432b",
	'<=');
INSERT INTO V_VAL
	VALUES ("49cf5321-6a70-4255-b339-7ecd148d624e",
	0,
	0,
	96,
	19,
	22,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("49cf5321-6a70-4255-b339-7ecd148d624e",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("04000476-0f26-4227-8ba0-1ccc716e1c78",
	0,
	0,
	96,
	24,
	33,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("04000476-0f26-4227-8ba0-1ccc716e1c78",
	"49cf5321-6a70-4255-b339-7ecd148d624e",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("aa462f9f-dc15-45b1-9560-c23ddb11ff39",
	0,
	0,
	96,
	43,
	46,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("aa462f9f-dc15-45b1-9560-c23ddb11ff39",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("f55a0d74-affc-4c67-ac0c-22d8b72a0a29",
	0,
	0,
	96,
	48,
	57,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("f55a0d74-affc-4c67-ac0c-22d8b72a0a29",
	"aa462f9f-dc15-45b1-9560-c23ddb11ff39",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("51d4a33f-af68-478d-a8b4-b021578eac58",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("51d4a33f-af68-478d-a8b4-b021578eac58",
	"b3d32dc9-8074-4952-969d-4f755ebedaaf",
	"f55a0d74-affc-4c67-ac0c-22d8b72a0a29",
	'<=');
INSERT INTO V_VAL
	VALUES ("b3d32dc9-8074-4952-969d-4f755ebedaaf",
	0,
	0,
	96,
	62,
	62,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("b3d32dc9-8074-4952-969d-4f755ebedaaf",
	'6');
INSERT INTO V_VAL
	VALUES ("8bce1363-1337-4cdc-9eb6-08ace6dd5d21",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("8bce1363-1337-4cdc-9eb6-08ace6dd5d21",
	"51d4a33f-af68-478d-a8b4-b021578eac58",
	"9f4bdc82-2a3c-4fdd-bcce-824832c3478b",
	'and');
INSERT INTO V_VAL
	VALUES ("02485596-9a8b-4eda-9694-0d18750db845",
	0,
	0,
	97,
	8,
	11,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("02485596-9a8b-4eda-9694-0d18750db845",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("67a48555-fe8e-4c37-a140-247495a3bb75",
	0,
	0,
	97,
	13,
	25,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("67a48555-fe8e-4c37-a140-247495a3bb75",
	"02485596-9a8b-4eda-9694-0d18750db845",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("2edf57a5-ecd5-44d4-95c0-9092085f11e6",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("2edf57a5-ecd5-44d4-95c0-9092085f11e6",
	"727b27af-d91d-4771-ae36-f0f19b24ccb6",
	"67a48555-fe8e-4c37-a140-247495a3bb75",
	'<=');
INSERT INTO V_VAL
	VALUES ("727b27af-d91d-4771-ae36-f0f19b24ccb6",
	0,
	0,
	97,
	30,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("727b27af-d91d-4771-ae36-f0f19b24ccb6",
	'3');
INSERT INTO V_VAL
	VALUES ("49d3c3b0-cd7c-4ac0-803b-b1378ba036f8",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("49d3c3b0-cd7c-4ac0-803b-b1378ba036f8",
	"2edf57a5-ecd5-44d4-95c0-9092085f11e6",
	"8bce1363-1337-4cdc-9eb6-08ace6dd5d21",
	'and');
INSERT INTO V_VAL
	VALUES ("ea87808b-c322-49ce-bb1a-81eb9a212901",
	0,
	0,
	100,
	14,
	14,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("ea87808b-c322-49ce-bb1a-81eb9a212901",
	'4');
INSERT INTO V_VAL
	VALUES ("55fb786a-2f56-4a4a-bdc7-008cdd0e3765",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("55fb786a-2f56-4a4a-bdc7-008cdd0e3765",
	"c9813c96-c75c-43e2-9882-18a08cbd7290",
	"ea87808b-c322-49ce-bb1a-81eb9a212901",
	'<=');
INSERT INTO V_VAL
	VALUES ("83da22d0-becd-456b-b38f-c32757f0818c",
	0,
	0,
	100,
	19,
	22,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("83da22d0-becd-456b-b38f-c32757f0818c",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("c9813c96-c75c-43e2-9882-18a08cbd7290",
	0,
	0,
	100,
	24,
	33,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("c9813c96-c75c-43e2-9882-18a08cbd7290",
	"83da22d0-becd-456b-b38f-c32757f0818c",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("42997b47-102a-4ca6-8bee-22fe406d033a",
	0,
	0,
	100,
	43,
	46,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("42997b47-102a-4ca6-8bee-22fe406d033a",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("1803d91a-083b-403a-875b-e3feef5d5332",
	0,
	0,
	100,
	48,
	57,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("1803d91a-083b-403a-875b-e3feef5d5332",
	"42997b47-102a-4ca6-8bee-22fe406d033a",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("91d748a4-87db-4428-ade1-daa2e4c1243e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("91d748a4-87db-4428-ade1-daa2e4c1243e",
	"18bb05a0-a1c0-4e43-a273-22a61a276f00",
	"1803d91a-083b-403a-875b-e3feef5d5332",
	'<=');
INSERT INTO V_VAL
	VALUES ("18bb05a0-a1c0-4e43-a273-22a61a276f00",
	0,
	0,
	100,
	62,
	62,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("18bb05a0-a1c0-4e43-a273-22a61a276f00",
	'6');
INSERT INTO V_VAL
	VALUES ("586eb8fd-179d-436d-96a0-29ed29eb017f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("586eb8fd-179d-436d-96a0-29ed29eb017f",
	"91d748a4-87db-4428-ade1-daa2e4c1243e",
	"55fb786a-2f56-4a4a-bdc7-008cdd0e3765",
	'and');
INSERT INTO V_VAL
	VALUES ("202fa41c-cd8c-4d82-aad6-922c90e86ba5",
	0,
	0,
	101,
	10,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("202fa41c-cd8c-4d82-aad6-922c90e86ba5",
	'4');
INSERT INTO V_VAL
	VALUES ("3ef8fc5d-ea4b-4db9-9871-712b9d1a40c1",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("3ef8fc5d-ea4b-4db9-9871-712b9d1a40c1",
	"7cf100b6-57fe-4415-94cb-ed4c83481d19",
	"202fa41c-cd8c-4d82-aad6-922c90e86ba5",
	'<=');
INSERT INTO V_VAL
	VALUES ("f9804076-b541-4b28-b372-4a880f5714aa",
	0,
	0,
	101,
	15,
	18,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("f9804076-b541-4b28-b372-4a880f5714aa",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("7cf100b6-57fe-4415-94cb-ed4c83481d19",
	0,
	0,
	101,
	20,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("7cf100b6-57fe-4415-94cb-ed4c83481d19",
	"f9804076-b541-4b28-b372-4a880f5714aa",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("14e7258a-80c7-4359-a04f-34f69b1c6ebb",
	0,
	0,
	101,
	42,
	45,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("14e7258a-80c7-4359-a04f-34f69b1c6ebb",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("af70e4ff-4b69-4128-bfd0-8c6199b16828",
	0,
	0,
	101,
	47,
	59,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("af70e4ff-4b69-4128-bfd0-8c6199b16828",
	"14e7258a-80c7-4359-a04f-34f69b1c6ebb",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("38f0efdc-a0a5-45ba-8a1a-7b05e4459887",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("38f0efdc-a0a5-45ba-8a1a-7b05e4459887",
	"4ad7bd62-4c71-49ee-9d03-1ea7ed5543e3",
	"af70e4ff-4b69-4128-bfd0-8c6199b16828",
	'<=');
INSERT INTO V_VAL
	VALUES ("4ad7bd62-4c71-49ee-9d03-1ea7ed5543e3",
	0,
	0,
	101,
	64,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("4ad7bd62-4c71-49ee-9d03-1ea7ed5543e3",
	'6');
INSERT INTO V_VAL
	VALUES ("153264df-ed95-455e-8ef7-8aca1771f29f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("153264df-ed95-455e-8ef7-8aca1771f29f",
	"38f0efdc-a0a5-45ba-8a1a-7b05e4459887",
	"3ef8fc5d-ea4b-4db9-9871-712b9d1a40c1",
	'and');
INSERT INTO V_VAL
	VALUES ("8357274b-099b-4237-bfe0-66280eed2d39",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("8357274b-099b-4237-bfe0-66280eed2d39",
	"153264df-ed95-455e-8ef7-8aca1771f29f",
	"586eb8fd-179d-436d-96a0-29ed29eb017f",
	'and');
INSERT INTO V_VAL
	VALUES ("d8ac3040-05ee-4494-a7e9-0756fd4359af",
	0,
	0,
	104,
	14,
	14,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("d8ac3040-05ee-4494-a7e9-0756fd4359af",
	'4');
INSERT INTO V_VAL
	VALUES ("6894db80-670f-4074-81b9-2e88ae23f616",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("6894db80-670f-4074-81b9-2e88ae23f616",
	"ee1d8ba3-4fbb-4ab2-9a27-d22112192e8d",
	"d8ac3040-05ee-4494-a7e9-0756fd4359af",
	'<=');
INSERT INTO V_VAL
	VALUES ("2f65b47e-7c78-4bf6-8beb-0b453d82d8b2",
	0,
	0,
	104,
	19,
	22,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("2f65b47e-7c78-4bf6-8beb-0b453d82d8b2",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("ee1d8ba3-4fbb-4ab2-9a27-d22112192e8d",
	0,
	0,
	104,
	24,
	33,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("ee1d8ba3-4fbb-4ab2-9a27-d22112192e8d",
	"2f65b47e-7c78-4bf6-8beb-0b453d82d8b2",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("cad6c157-2adf-4cd2-80d9-61625f6157ea",
	0,
	0,
	104,
	43,
	46,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("cad6c157-2adf-4cd2-80d9-61625f6157ea",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("af9e3442-1e20-474a-9bad-e75e81bb9297",
	0,
	0,
	104,
	48,
	57,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("af9e3442-1e20-474a-9bad-e75e81bb9297",
	"cad6c157-2adf-4cd2-80d9-61625f6157ea",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("d8291a45-f3f4-492e-af4f-0234c505395f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("d8291a45-f3f4-492e-af4f-0234c505395f",
	"8c5b0129-7bc6-41ab-ba8d-af83adf822c2",
	"af9e3442-1e20-474a-9bad-e75e81bb9297",
	'<=');
INSERT INTO V_VAL
	VALUES ("8c5b0129-7bc6-41ab-ba8d-af83adf822c2",
	0,
	0,
	104,
	62,
	62,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("8c5b0129-7bc6-41ab-ba8d-af83adf822c2",
	'6');
INSERT INTO V_VAL
	VALUES ("505c9257-eb21-4268-afdd-c62a98550743",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("505c9257-eb21-4268-afdd-c62a98550743",
	"d8291a45-f3f4-492e-af4f-0234c505395f",
	"6894db80-670f-4074-81b9-2e88ae23f616",
	'and');
INSERT INTO V_VAL
	VALUES ("a1d3eab8-2103-4d49-8548-fbbb177421f4",
	0,
	0,
	105,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("a1d3eab8-2103-4d49-8548-fbbb177421f4",
	'7');
INSERT INTO V_VAL
	VALUES ("6b259b7d-6005-47f0-b84c-4078f9bf35fd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("6b259b7d-6005-47f0-b84c-4078f9bf35fd",
	"d078182e-ab67-42ca-88ca-5028f1764554",
	"a1d3eab8-2103-4d49-8548-fbbb177421f4",
	'<=');
INSERT INTO V_VAL
	VALUES ("7ba5e473-a98c-4445-abf1-3b57bf7bb107",
	0,
	0,
	105,
	13,
	16,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("7ba5e473-a98c-4445-abf1-3b57bf7bb107",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("d078182e-ab67-42ca-88ca-5028f1764554",
	0,
	0,
	105,
	18,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("d078182e-ab67-42ca-88ca-5028f1764554",
	"7ba5e473-a98c-4445-abf1-3b57bf7bb107",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("f64df9d2-818f-4283-a83e-0e55c211669b",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("f64df9d2-818f-4283-a83e-0e55c211669b",
	"6b259b7d-6005-47f0-b84c-4078f9bf35fd",
	"505c9257-eb21-4268-afdd-c62a98550743",
	'and');
INSERT INTO V_VAL
	VALUES ("968ef438-3a53-4c99-8384-6aba4081b738",
	0,
	0,
	108,
	12,
	12,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("968ef438-3a53-4c99-8384-6aba4081b738",
	'7');
INSERT INTO V_VAL
	VALUES ("c9e5dfa5-c05f-4d3f-a0cc-b1cbeae2b4bd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("c9e5dfa5-c05f-4d3f-a0cc-b1cbeae2b4bd",
	"84ddf395-45e0-4479-b235-cb2e0ca3fe7c",
	"968ef438-3a53-4c99-8384-6aba4081b738",
	'<=');
INSERT INTO V_VAL
	VALUES ("4a2ddcc6-f33d-43b4-8241-8b138a85dd53",
	0,
	0,
	108,
	17,
	20,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("4a2ddcc6-f33d-43b4-8241-8b138a85dd53",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("84ddf395-45e0-4479-b235-cb2e0ca3fe7c",
	0,
	0,
	108,
	22,
	31,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("84ddf395-45e0-4479-b235-cb2e0ca3fe7c",
	"4a2ddcc6-f33d-43b4-8241-8b138a85dd53",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("c16d9bdb-1391-49d0-a6bd-4bf8be1f6c1d",
	0,
	0,
	109,
	8,
	11,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("c16d9bdb-1391-49d0-a6bd-4bf8be1f6c1d",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("f8ed00bd-7b0f-4117-b7de-057d0fd0b5df",
	0,
	0,
	109,
	13,
	25,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("f8ed00bd-7b0f-4117-b7de-057d0fd0b5df",
	"c16d9bdb-1391-49d0-a6bd-4bf8be1f6c1d",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("4944adfd-7ced-4ad7-9002-ca12576f2656",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("4944adfd-7ced-4ad7-9002-ca12576f2656",
	"0febb821-7bb6-4bc4-b699-883183bbca4c",
	"f8ed00bd-7b0f-4117-b7de-057d0fd0b5df",
	'<=');
INSERT INTO V_VAL
	VALUES ("0febb821-7bb6-4bc4-b699-883183bbca4c",
	0,
	0,
	109,
	30,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("0febb821-7bb6-4bc4-b699-883183bbca4c",
	'3');
INSERT INTO V_VAL
	VALUES ("18ada3f5-b2b4-44f1-ac78-3757d40c2de1",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("18ada3f5-b2b4-44f1-ac78-3757d40c2de1",
	"4944adfd-7ced-4ad7-9002-ca12576f2656",
	"c9e5dfa5-c05f-4d3f-a0cc-b1cbeae2b4bd",
	'and');
INSERT INTO V_VAL
	VALUES ("a7353b10-96ff-4f75-a1da-36e2072beedc",
	0,
	0,
	112,
	12,
	12,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("a7353b10-96ff-4f75-a1da-36e2072beedc",
	'7');
INSERT INTO V_VAL
	VALUES ("c33250ed-977a-418e-8f2c-f859c98e7116",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("c33250ed-977a-418e-8f2c-f859c98e7116",
	"cdc4a2f7-1144-4c6d-b8ef-e7bdbac25002",
	"a7353b10-96ff-4f75-a1da-36e2072beedc",
	'<=');
INSERT INTO V_VAL
	VALUES ("6d39b9c3-d0ce-4727-bd48-5161af1aaa5b",
	0,
	0,
	112,
	17,
	20,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("6d39b9c3-d0ce-4727-bd48-5161af1aaa5b",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("cdc4a2f7-1144-4c6d-b8ef-e7bdbac25002",
	0,
	0,
	112,
	22,
	31,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("cdc4a2f7-1144-4c6d-b8ef-e7bdbac25002",
	"6d39b9c3-d0ce-4727-bd48-5161af1aaa5b",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("379d5405-8d67-4fc8-910e-fff7c580ba71",
	0,
	0,
	113,
	10,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("379d5405-8d67-4fc8-910e-fff7c580ba71",
	'4');
INSERT INTO V_VAL
	VALUES ("938c19d4-a826-4838-b3b8-61d79ce5da8a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("938c19d4-a826-4838-b3b8-61d79ce5da8a",
	"9ad83ecb-c70f-417f-9dcb-01548abe0b0a",
	"379d5405-8d67-4fc8-910e-fff7c580ba71",
	'<=');
INSERT INTO V_VAL
	VALUES ("6c1c40ea-1776-4607-b9f9-07a44b8f62b7",
	0,
	0,
	113,
	15,
	18,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("6c1c40ea-1776-4607-b9f9-07a44b8f62b7",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("9ad83ecb-c70f-417f-9dcb-01548abe0b0a",
	0,
	0,
	113,
	20,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("9ad83ecb-c70f-417f-9dcb-01548abe0b0a",
	"6c1c40ea-1776-4607-b9f9-07a44b8f62b7",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("8b9ce146-379a-4841-8d96-97d1bc8b7c7a",
	0,
	0,
	113,
	42,
	45,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("8b9ce146-379a-4841-8d96-97d1bc8b7c7a",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("91081d56-c6d4-41c3-a76a-d1e212dd81a0",
	0,
	0,
	113,
	47,
	59,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("91081d56-c6d4-41c3-a76a-d1e212dd81a0",
	"8b9ce146-379a-4841-8d96-97d1bc8b7c7a",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("49c1a936-73a9-4a08-bef5-8b35425fa01f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("49c1a936-73a9-4a08-bef5-8b35425fa01f",
	"2894f0d4-9282-4fb8-b40e-47d5d488c5b9",
	"91081d56-c6d4-41c3-a76a-d1e212dd81a0",
	'<=');
INSERT INTO V_VAL
	VALUES ("2894f0d4-9282-4fb8-b40e-47d5d488c5b9",
	0,
	0,
	113,
	64,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("2894f0d4-9282-4fb8-b40e-47d5d488c5b9",
	'6');
INSERT INTO V_VAL
	VALUES ("e4c506eb-cc13-43df-af3c-50585935a47e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("e4c506eb-cc13-43df-af3c-50585935a47e",
	"49c1a936-73a9-4a08-bef5-8b35425fa01f",
	"938c19d4-a826-4838-b3b8-61d79ce5da8a",
	'and');
INSERT INTO V_VAL
	VALUES ("f57df546-b562-4f27-8ebc-7ae788e92b84",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("f57df546-b562-4f27-8ebc-7ae788e92b84",
	"e4c506eb-cc13-43df-af3c-50585935a47e",
	"c33250ed-977a-418e-8f2c-f859c98e7116",
	'and');
INSERT INTO V_VAL
	VALUES ("d9b633b4-5026-4b6a-9918-452ddf9e5ba1",
	0,
	0,
	116,
	12,
	12,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("d9b633b4-5026-4b6a-9918-452ddf9e5ba1",
	'7');
INSERT INTO V_VAL
	VALUES ("018abdad-409a-484e-b3ef-e40dde6dc40c",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("018abdad-409a-484e-b3ef-e40dde6dc40c",
	"9ea76563-204a-4887-bd2d-26f93a0d1261",
	"d9b633b4-5026-4b6a-9918-452ddf9e5ba1",
	'<=');
INSERT INTO V_VAL
	VALUES ("5b27dbbb-6764-4d20-b94a-f0ad8de17153",
	0,
	0,
	116,
	17,
	20,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("5b27dbbb-6764-4d20-b94a-f0ad8de17153",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("9ea76563-204a-4887-bd2d-26f93a0d1261",
	0,
	0,
	116,
	22,
	31,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("9ea76563-204a-4887-bd2d-26f93a0d1261",
	"5b27dbbb-6764-4d20-b94a-f0ad8de17153",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("e8203090-6887-41dc-9891-e25905712882",
	0,
	0,
	117,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_LIN
	VALUES ("e8203090-6887-41dc-9891-e25905712882",
	'7');
INSERT INTO V_VAL
	VALUES ("cc1c3193-fe5f-4d7e-b535-e05ad94d18ce",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("cc1c3193-fe5f-4d7e-b535-e05ad94d18ce",
	"a331a2d1-1bef-4729-88a4-c433e9a2456d",
	"e8203090-6887-41dc-9891-e25905712882",
	'<=');
INSERT INTO V_VAL
	VALUES ("044300aa-d3ba-4154-98dd-43dc349edca6",
	0,
	0,
	117,
	13,
	16,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_IRF
	VALUES ("044300aa-d3ba-4154-98dd-43dc349edca6",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6");
INSERT INTO V_VAL
	VALUES ("a331a2d1-1bef-4729-88a4-c433e9a2456d",
	0,
	0,
	117,
	18,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_AVL
	VALUES ("a331a2d1-1bef-4729-88a4-c433e9a2456d",
	"044300aa-d3ba-4154-98dd-43dc349edca6",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("f8f5ff6e-babf-4c4e-a2b8-0e8b2d0cd691",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ae2764bf-00fd-4baf-97fe-b2e9148cd1b2");
INSERT INTO V_BIN
	VALUES ("f8f5ff6e-babf-4c4e-a2b8-0e8b2d0cd691",
	"cc1c3193-fe5f-4d7e-b535-e05ad94d18ce",
	"018abdad-409a-484e-b3ef-e40dde6dc40c",
	'and');
INSERT INTO ACT_BLK
	VALUES ("e813b265-52dc-49cb-97d1-6870b2ce39b5",
	1,
	0,
	1,
	'',
	'',
	'',
	87,
	5,
	86,
	38,
	0,
	0,
	87,
	31,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("24be6ad0-6435-4ecd-8c6f-b407409dd5fe",
	"e813b265-52dc-49cb-97d1-6870b2ce39b5",
	"38f50556-eba3-4345-bdb9-a4f2d7bb5821",
	86,
	5,
	'setup line: 86');
INSERT INTO ACT_FIW
	VALUES ("24be6ad0-6435-4ecd-8c6f-b407409dd5fe",
	"dbefb217-eed7-4c46-9eeb-8a93829be2ca",
	1,
	'any',
	"50c798bb-de71-4293-9208-1cb44a6ac608",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	86,
	38);
INSERT INTO ACT_SMT
	VALUES ("38f50556-eba3-4345-bdb9-a4f2d7bb5821",
	"e813b265-52dc-49cb-97d1-6870b2ce39b5",
	"00000000-0000-0000-0000-000000000000",
	87,
	5,
	'setup line: 87');
INSERT INTO ACT_REL
	VALUES ("38f50556-eba3-4345-bdb9-a4f2d7bb5821",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"dbefb217-eed7-4c46-9eeb-8a93829be2ca",
	'',
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	87,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("821737e2-080d-4b8a-82eb-401c88a0e249",
	0,
	0,
	86,
	50,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"e813b265-52dc-49cb-97d1-6870b2ce39b5");
INSERT INTO V_SLR
	VALUES ("821737e2-080d-4b8a-82eb-401c88a0e249",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("4413da0a-6854-46f0-bd58-1ad4796edd59",
	0,
	0,
	86,
	59,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e813b265-52dc-49cb-97d1-6870b2ce39b5");
INSERT INTO V_AVL
	VALUES ("4413da0a-6854-46f0-bd58-1ad4796edd59",
	"821737e2-080d-4b8a-82eb-401c88a0e249",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1");
INSERT INTO V_VAL
	VALUES ("50c798bb-de71-4293-9208-1cb44a6ac608",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"e813b265-52dc-49cb-97d1-6870b2ce39b5");
INSERT INTO V_BIN
	VALUES ("50c798bb-de71-4293-9208-1cb44a6ac608",
	"cb8f6b6f-6849-4bb6-b1b9-9699d0e4306d",
	"4413da0a-6854-46f0-bd58-1ad4796edd59",
	'==');
INSERT INTO V_VAL
	VALUES ("cb8f6b6f-6849-4bb6-b1b9-9699d0e4306d",
	0,
	0,
	86,
	69,
	69,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e813b265-52dc-49cb-97d1-6870b2ce39b5");
INSERT INTO V_LIN
	VALUES ("cb8f6b6f-6849-4bb6-b1b9-9699d0e4306d",
	'1');
INSERT INTO V_VAR
	VALUES ("dbefb217-eed7-4c46-9eeb-8a93829be2ca",
	"e813b265-52dc-49cb-97d1-6870b2ce39b5",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("dbefb217-eed7-4c46-9eeb-8a93829be2ca",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("86ef4a9e-5fb2-42fb-b4f8-fc344c4b3950",
	86,
	16,
	18,
	"dbefb217-eed7-4c46-9eeb-8a93829be2ca");
INSERT INTO V_LOC
	VALUES ("ffea86a5-33b5-466c-92b1-b120a046672b",
	87,
	20,
	22,
	"dbefb217-eed7-4c46-9eeb-8a93829be2ca");
INSERT INTO ACT_BLK
	VALUES ("90fe7960-f2b8-42e5-8b27-5097b29aa7b1",
	1,
	0,
	1,
	'',
	'',
	'',
	91,
	5,
	90,
	38,
	0,
	0,
	91,
	31,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("58253cfe-0f00-4b03-973f-5b1f4a15d148",
	"90fe7960-f2b8-42e5-8b27-5097b29aa7b1",
	"8b7d03bb-2153-4fb1-ac20-c25c45740781",
	90,
	5,
	'setup line: 90');
INSERT INTO ACT_FIW
	VALUES ("58253cfe-0f00-4b03-973f-5b1f4a15d148",
	"d7c3ae6a-b300-459f-8d67-fdeef17a770a",
	1,
	'any',
	"25a2b57a-0ee6-43ad-9aae-4bbbe6c83155",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	90,
	38);
INSERT INTO ACT_SMT
	VALUES ("8b7d03bb-2153-4fb1-ac20-c25c45740781",
	"90fe7960-f2b8-42e5-8b27-5097b29aa7b1",
	"00000000-0000-0000-0000-000000000000",
	91,
	5,
	'setup line: 91');
INSERT INTO ACT_REL
	VALUES ("8b7d03bb-2153-4fb1-ac20-c25c45740781",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"d7c3ae6a-b300-459f-8d67-fdeef17a770a",
	'',
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	91,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("59a36612-6375-47b3-aa45-0f6efd058661",
	0,
	0,
	90,
	50,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"90fe7960-f2b8-42e5-8b27-5097b29aa7b1");
INSERT INTO V_SLR
	VALUES ("59a36612-6375-47b3-aa45-0f6efd058661",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("37f08d94-bb28-4740-8b6f-240d499ec0a6",
	0,
	0,
	90,
	59,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"90fe7960-f2b8-42e5-8b27-5097b29aa7b1");
INSERT INTO V_AVL
	VALUES ("37f08d94-bb28-4740-8b6f-240d499ec0a6",
	"59a36612-6375-47b3-aa45-0f6efd058661",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1");
INSERT INTO V_VAL
	VALUES ("25a2b57a-0ee6-43ad-9aae-4bbbe6c83155",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"90fe7960-f2b8-42e5-8b27-5097b29aa7b1");
INSERT INTO V_BIN
	VALUES ("25a2b57a-0ee6-43ad-9aae-4bbbe6c83155",
	"397bcde6-1f5c-4dfe-8f12-115d11576174",
	"37f08d94-bb28-4740-8b6f-240d499ec0a6",
	'==');
INSERT INTO V_VAL
	VALUES ("397bcde6-1f5c-4dfe-8f12-115d11576174",
	0,
	0,
	90,
	69,
	69,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"90fe7960-f2b8-42e5-8b27-5097b29aa7b1");
INSERT INTO V_LIN
	VALUES ("397bcde6-1f5c-4dfe-8f12-115d11576174",
	'2');
INSERT INTO V_VAR
	VALUES ("d7c3ae6a-b300-459f-8d67-fdeef17a770a",
	"90fe7960-f2b8-42e5-8b27-5097b29aa7b1",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("d7c3ae6a-b300-459f-8d67-fdeef17a770a",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("37acbd78-d989-4535-a170-c5a1537b018e",
	90,
	16,
	18,
	"d7c3ae6a-b300-459f-8d67-fdeef17a770a");
INSERT INTO V_LOC
	VALUES ("4fff6713-f8c9-4da0-878c-c1280635f8ff",
	91,
	20,
	22,
	"d7c3ae6a-b300-459f-8d67-fdeef17a770a");
INSERT INTO ACT_BLK
	VALUES ("5f8c51e9-feb6-4d18-bb84-f99bfae5c4ab",
	1,
	0,
	1,
	'',
	'',
	'',
	95,
	5,
	94,
	38,
	0,
	0,
	95,
	31,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("590f4c7d-2b23-4744-8fbd-7190e91662dd",
	"5f8c51e9-feb6-4d18-bb84-f99bfae5c4ab",
	"cc136d78-c3e8-44da-b032-b1c274f10873",
	94,
	5,
	'setup line: 94');
INSERT INTO ACT_FIW
	VALUES ("590f4c7d-2b23-4744-8fbd-7190e91662dd",
	"441d13d4-6a04-4f0f-a0cf-e3446d3d58f9",
	1,
	'any',
	"e5c1cec8-331b-45ef-b941-0aee4d74d67a",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	94,
	38);
INSERT INTO ACT_SMT
	VALUES ("cc136d78-c3e8-44da-b032-b1c274f10873",
	"5f8c51e9-feb6-4d18-bb84-f99bfae5c4ab",
	"00000000-0000-0000-0000-000000000000",
	95,
	5,
	'setup line: 95');
INSERT INTO ACT_REL
	VALUES ("cc136d78-c3e8-44da-b032-b1c274f10873",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"441d13d4-6a04-4f0f-a0cf-e3446d3d58f9",
	'',
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	95,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("6b4b3034-8a4a-4483-ac70-8cfd9cd410ae",
	0,
	0,
	94,
	50,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"5f8c51e9-feb6-4d18-bb84-f99bfae5c4ab");
INSERT INTO V_SLR
	VALUES ("6b4b3034-8a4a-4483-ac70-8cfd9cd410ae",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("ca7ecef0-8904-4988-9bd5-6b012b270663",
	0,
	0,
	94,
	59,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"5f8c51e9-feb6-4d18-bb84-f99bfae5c4ab");
INSERT INTO V_AVL
	VALUES ("ca7ecef0-8904-4988-9bd5-6b012b270663",
	"6b4b3034-8a4a-4483-ac70-8cfd9cd410ae",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1");
INSERT INTO V_VAL
	VALUES ("e5c1cec8-331b-45ef-b941-0aee4d74d67a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"5f8c51e9-feb6-4d18-bb84-f99bfae5c4ab");
INSERT INTO V_BIN
	VALUES ("e5c1cec8-331b-45ef-b941-0aee4d74d67a",
	"6f2a1ce7-e733-4d0d-bb52-f569f2bd6994",
	"ca7ecef0-8904-4988-9bd5-6b012b270663",
	'==');
INSERT INTO V_VAL
	VALUES ("6f2a1ce7-e733-4d0d-bb52-f569f2bd6994",
	0,
	0,
	94,
	69,
	69,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"5f8c51e9-feb6-4d18-bb84-f99bfae5c4ab");
INSERT INTO V_LIN
	VALUES ("6f2a1ce7-e733-4d0d-bb52-f569f2bd6994",
	'3');
INSERT INTO V_VAR
	VALUES ("441d13d4-6a04-4f0f-a0cf-e3446d3d58f9",
	"5f8c51e9-feb6-4d18-bb84-f99bfae5c4ab",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("441d13d4-6a04-4f0f-a0cf-e3446d3d58f9",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("28f0bc25-45ae-420d-8c6b-f02a1c37f97b",
	94,
	16,
	18,
	"441d13d4-6a04-4f0f-a0cf-e3446d3d58f9");
INSERT INTO V_LOC
	VALUES ("86211ce3-36b6-4376-9966-f6118f8468c9",
	95,
	20,
	22,
	"441d13d4-6a04-4f0f-a0cf-e3446d3d58f9");
INSERT INTO ACT_BLK
	VALUES ("56f01c9c-dc5f-42b0-89fa-d67cbe802ea7",
	1,
	0,
	1,
	'',
	'',
	'',
	99,
	5,
	98,
	38,
	0,
	0,
	99,
	31,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9f4711f7-cbd0-4c55-ab6d-aebf46997d12",
	"56f01c9c-dc5f-42b0-89fa-d67cbe802ea7",
	"354e9c34-b8f5-476b-bf3c-318a7786c0a3",
	98,
	5,
	'setup line: 98');
INSERT INTO ACT_FIW
	VALUES ("9f4711f7-cbd0-4c55-ab6d-aebf46997d12",
	"949e6649-66de-4dca-92dc-73658e14d558",
	1,
	'any',
	"8d6cbd14-0648-4f3d-b19b-7a8f5d677f70",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	98,
	38);
INSERT INTO ACT_SMT
	VALUES ("354e9c34-b8f5-476b-bf3c-318a7786c0a3",
	"56f01c9c-dc5f-42b0-89fa-d67cbe802ea7",
	"00000000-0000-0000-0000-000000000000",
	99,
	5,
	'setup line: 99');
INSERT INTO ACT_REL
	VALUES ("354e9c34-b8f5-476b-bf3c-318a7786c0a3",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"949e6649-66de-4dca-92dc-73658e14d558",
	'',
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	99,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("fade48cb-d4cd-4a34-9d50-47d92ee63533",
	0,
	0,
	98,
	50,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"56f01c9c-dc5f-42b0-89fa-d67cbe802ea7");
INSERT INTO V_SLR
	VALUES ("fade48cb-d4cd-4a34-9d50-47d92ee63533",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("3c581ccb-19de-4af8-9697-488a97da0ea1",
	0,
	0,
	98,
	59,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"56f01c9c-dc5f-42b0-89fa-d67cbe802ea7");
INSERT INTO V_AVL
	VALUES ("3c581ccb-19de-4af8-9697-488a97da0ea1",
	"fade48cb-d4cd-4a34-9d50-47d92ee63533",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1");
INSERT INTO V_VAL
	VALUES ("8d6cbd14-0648-4f3d-b19b-7a8f5d677f70",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"56f01c9c-dc5f-42b0-89fa-d67cbe802ea7");
INSERT INTO V_BIN
	VALUES ("8d6cbd14-0648-4f3d-b19b-7a8f5d677f70",
	"681961b9-19b7-4ab7-b808-94102ff37e45",
	"3c581ccb-19de-4af8-9697-488a97da0ea1",
	'==');
INSERT INTO V_VAL
	VALUES ("681961b9-19b7-4ab7-b808-94102ff37e45",
	0,
	0,
	98,
	69,
	69,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"56f01c9c-dc5f-42b0-89fa-d67cbe802ea7");
INSERT INTO V_LIN
	VALUES ("681961b9-19b7-4ab7-b808-94102ff37e45",
	'4');
INSERT INTO V_VAR
	VALUES ("949e6649-66de-4dca-92dc-73658e14d558",
	"56f01c9c-dc5f-42b0-89fa-d67cbe802ea7",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("949e6649-66de-4dca-92dc-73658e14d558",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("41d368a9-2e84-4dca-b3c8-48f4e689de76",
	98,
	16,
	18,
	"949e6649-66de-4dca-92dc-73658e14d558");
INSERT INTO V_LOC
	VALUES ("177d7597-4496-46bc-bf47-cfdc9aca60b4",
	99,
	20,
	22,
	"949e6649-66de-4dca-92dc-73658e14d558");
INSERT INTO ACT_BLK
	VALUES ("a10039c3-4604-4312-b92c-813ea8d76386",
	1,
	0,
	1,
	'',
	'',
	'',
	103,
	5,
	102,
	38,
	0,
	0,
	103,
	31,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d7ad3d3f-5f2b-4b6c-977f-f093c3f42743",
	"a10039c3-4604-4312-b92c-813ea8d76386",
	"db388522-1901-4830-9222-92d7e2fe7dce",
	102,
	5,
	'setup line: 102');
INSERT INTO ACT_FIW
	VALUES ("d7ad3d3f-5f2b-4b6c-977f-f093c3f42743",
	"1149c493-a04c-43a5-91e3-bf114162a53b",
	1,
	'any',
	"12bda060-049a-473c-8bc1-be73768257a4",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	102,
	38);
INSERT INTO ACT_SMT
	VALUES ("db388522-1901-4830-9222-92d7e2fe7dce",
	"a10039c3-4604-4312-b92c-813ea8d76386",
	"00000000-0000-0000-0000-000000000000",
	103,
	5,
	'setup line: 103');
INSERT INTO ACT_REL
	VALUES ("db388522-1901-4830-9222-92d7e2fe7dce",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"1149c493-a04c-43a5-91e3-bf114162a53b",
	'',
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	103,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("d648f987-89a4-45f7-90fd-d2f950288c7b",
	0,
	0,
	102,
	50,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"a10039c3-4604-4312-b92c-813ea8d76386");
INSERT INTO V_SLR
	VALUES ("d648f987-89a4-45f7-90fd-d2f950288c7b",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("7fc10708-93d5-4dcc-bd11-2c0e656b88f7",
	0,
	0,
	102,
	59,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a10039c3-4604-4312-b92c-813ea8d76386");
INSERT INTO V_AVL
	VALUES ("7fc10708-93d5-4dcc-bd11-2c0e656b88f7",
	"d648f987-89a4-45f7-90fd-d2f950288c7b",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1");
INSERT INTO V_VAL
	VALUES ("12bda060-049a-473c-8bc1-be73768257a4",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"a10039c3-4604-4312-b92c-813ea8d76386");
INSERT INTO V_BIN
	VALUES ("12bda060-049a-473c-8bc1-be73768257a4",
	"9ae8e797-f363-4595-aa03-00825940e10b",
	"7fc10708-93d5-4dcc-bd11-2c0e656b88f7",
	'==');
INSERT INTO V_VAL
	VALUES ("9ae8e797-f363-4595-aa03-00825940e10b",
	0,
	0,
	102,
	69,
	69,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a10039c3-4604-4312-b92c-813ea8d76386");
INSERT INTO V_LIN
	VALUES ("9ae8e797-f363-4595-aa03-00825940e10b",
	'5');
INSERT INTO V_VAR
	VALUES ("1149c493-a04c-43a5-91e3-bf114162a53b",
	"a10039c3-4604-4312-b92c-813ea8d76386",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("1149c493-a04c-43a5-91e3-bf114162a53b",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("c2a8a33f-136a-4303-b589-aa614b9f3c5f",
	102,
	16,
	18,
	"1149c493-a04c-43a5-91e3-bf114162a53b");
INSERT INTO V_LOC
	VALUES ("8dd64a33-7995-45bc-bcbe-811abfbf144d",
	103,
	20,
	22,
	"1149c493-a04c-43a5-91e3-bf114162a53b");
INSERT INTO ACT_BLK
	VALUES ("b9440527-e276-47ef-a28e-53681b782ead",
	1,
	0,
	1,
	'',
	'',
	'',
	107,
	5,
	106,
	38,
	0,
	0,
	107,
	31,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8016c499-ad4a-4df8-9d38-c65ed3276840",
	"b9440527-e276-47ef-a28e-53681b782ead",
	"07deac30-670b-4ba9-a306-e20e5df3b089",
	106,
	5,
	'setup line: 106');
INSERT INTO ACT_FIW
	VALUES ("8016c499-ad4a-4df8-9d38-c65ed3276840",
	"0eff3c84-39df-4d1c-b6c1-be1278cc1b19",
	1,
	'any',
	"916abafb-fb5d-4aeb-8d52-61829f0ef1bd",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	106,
	38);
INSERT INTO ACT_SMT
	VALUES ("07deac30-670b-4ba9-a306-e20e5df3b089",
	"b9440527-e276-47ef-a28e-53681b782ead",
	"00000000-0000-0000-0000-000000000000",
	107,
	5,
	'setup line: 107');
INSERT INTO ACT_REL
	VALUES ("07deac30-670b-4ba9-a306-e20e5df3b089",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"0eff3c84-39df-4d1c-b6c1-be1278cc1b19",
	'',
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	107,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("adf70ef0-0fbe-4371-ab1b-44c5461f4b07",
	0,
	0,
	106,
	50,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"b9440527-e276-47ef-a28e-53681b782ead");
INSERT INTO V_SLR
	VALUES ("adf70ef0-0fbe-4371-ab1b-44c5461f4b07",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("65f06bc2-0a08-4473-a90c-97da4cd08711",
	0,
	0,
	106,
	59,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b9440527-e276-47ef-a28e-53681b782ead");
INSERT INTO V_AVL
	VALUES ("65f06bc2-0a08-4473-a90c-97da4cd08711",
	"adf70ef0-0fbe-4371-ab1b-44c5461f4b07",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1");
INSERT INTO V_VAL
	VALUES ("916abafb-fb5d-4aeb-8d52-61829f0ef1bd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"b9440527-e276-47ef-a28e-53681b782ead");
INSERT INTO V_BIN
	VALUES ("916abafb-fb5d-4aeb-8d52-61829f0ef1bd",
	"3ebdab41-18ac-4ea9-9785-9b3675d1e57c",
	"65f06bc2-0a08-4473-a90c-97da4cd08711",
	'==');
INSERT INTO V_VAL
	VALUES ("3ebdab41-18ac-4ea9-9785-9b3675d1e57c",
	0,
	0,
	106,
	69,
	69,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b9440527-e276-47ef-a28e-53681b782ead");
INSERT INTO V_LIN
	VALUES ("3ebdab41-18ac-4ea9-9785-9b3675d1e57c",
	'6');
INSERT INTO V_VAR
	VALUES ("0eff3c84-39df-4d1c-b6c1-be1278cc1b19",
	"b9440527-e276-47ef-a28e-53681b782ead",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("0eff3c84-39df-4d1c-b6c1-be1278cc1b19",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("c377ffc9-1dee-445b-98cc-842f1bd5167a",
	106,
	16,
	18,
	"0eff3c84-39df-4d1c-b6c1-be1278cc1b19");
INSERT INTO V_LOC
	VALUES ("6a9be16c-a2f9-4aa5-ab1b-a36f5a80d9fd",
	107,
	20,
	22,
	"0eff3c84-39df-4d1c-b6c1-be1278cc1b19");
INSERT INTO ACT_BLK
	VALUES ("d282a724-4883-4fcd-95ca-9846870ef19c",
	1,
	0,
	1,
	'',
	'',
	'',
	111,
	5,
	110,
	38,
	0,
	0,
	111,
	31,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0672c12a-e120-4bd0-ac71-28b8f709be92",
	"d282a724-4883-4fcd-95ca-9846870ef19c",
	"9ead6fd8-7821-4e04-8b10-edadb4735ddd",
	110,
	5,
	'setup line: 110');
INSERT INTO ACT_FIW
	VALUES ("0672c12a-e120-4bd0-ac71-28b8f709be92",
	"45ce92bd-9ac4-43f0-983f-7a99ec23c0f0",
	1,
	'any',
	"8badf148-c907-404a-81f1-eee438c05e46",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	110,
	38);
INSERT INTO ACT_SMT
	VALUES ("9ead6fd8-7821-4e04-8b10-edadb4735ddd",
	"d282a724-4883-4fcd-95ca-9846870ef19c",
	"00000000-0000-0000-0000-000000000000",
	111,
	5,
	'setup line: 111');
INSERT INTO ACT_REL
	VALUES ("9ead6fd8-7821-4e04-8b10-edadb4735ddd",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"45ce92bd-9ac4-43f0-983f-7a99ec23c0f0",
	'',
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	111,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("87cabf08-e78d-46f7-84ac-d7c8b602cd5c",
	0,
	0,
	110,
	50,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"d282a724-4883-4fcd-95ca-9846870ef19c");
INSERT INTO V_SLR
	VALUES ("87cabf08-e78d-46f7-84ac-d7c8b602cd5c",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("2a0befd3-1b82-4855-8bcb-05ebea570caf",
	0,
	0,
	110,
	59,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d282a724-4883-4fcd-95ca-9846870ef19c");
INSERT INTO V_AVL
	VALUES ("2a0befd3-1b82-4855-8bcb-05ebea570caf",
	"87cabf08-e78d-46f7-84ac-d7c8b602cd5c",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1");
INSERT INTO V_VAL
	VALUES ("8badf148-c907-404a-81f1-eee438c05e46",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"d282a724-4883-4fcd-95ca-9846870ef19c");
INSERT INTO V_BIN
	VALUES ("8badf148-c907-404a-81f1-eee438c05e46",
	"816b49f8-6744-414e-87a2-442cba37c12e",
	"2a0befd3-1b82-4855-8bcb-05ebea570caf",
	'==');
INSERT INTO V_VAL
	VALUES ("816b49f8-6744-414e-87a2-442cba37c12e",
	0,
	0,
	110,
	69,
	69,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d282a724-4883-4fcd-95ca-9846870ef19c");
INSERT INTO V_LIN
	VALUES ("816b49f8-6744-414e-87a2-442cba37c12e",
	'7');
INSERT INTO V_VAR
	VALUES ("45ce92bd-9ac4-43f0-983f-7a99ec23c0f0",
	"d282a724-4883-4fcd-95ca-9846870ef19c",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("45ce92bd-9ac4-43f0-983f-7a99ec23c0f0",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("95b7fe2a-e5df-4102-a045-51e102a2bef2",
	110,
	16,
	18,
	"45ce92bd-9ac4-43f0-983f-7a99ec23c0f0");
INSERT INTO V_LOC
	VALUES ("9df4aa43-c727-40fa-865c-97d56f241f4d",
	111,
	20,
	22,
	"45ce92bd-9ac4-43f0-983f-7a99ec23c0f0");
INSERT INTO ACT_BLK
	VALUES ("95064ec7-3be4-4e60-899f-293c293e9949",
	1,
	0,
	1,
	'',
	'',
	'',
	115,
	5,
	114,
	38,
	0,
	0,
	115,
	31,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4b36a5e7-3db2-4426-9c3c-4081511d736d",
	"95064ec7-3be4-4e60-899f-293c293e9949",
	"0bb9febf-eeae-44f4-9835-2c67b8c798ae",
	114,
	5,
	'setup line: 114');
INSERT INTO ACT_FIW
	VALUES ("4b36a5e7-3db2-4426-9c3c-4081511d736d",
	"8b80c97c-5e30-426c-97c8-c47425a3e730",
	1,
	'any',
	"f145f9cc-47a8-497d-a80b-c5f74e6c6dba",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	114,
	38);
INSERT INTO ACT_SMT
	VALUES ("0bb9febf-eeae-44f4-9835-2c67b8c798ae",
	"95064ec7-3be4-4e60-899f-293c293e9949",
	"00000000-0000-0000-0000-000000000000",
	115,
	5,
	'setup line: 115');
INSERT INTO ACT_REL
	VALUES ("0bb9febf-eeae-44f4-9835-2c67b8c798ae",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"8b80c97c-5e30-426c-97c8-c47425a3e730",
	'',
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	115,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("464a21fa-a041-4f73-9d19-9c7d4dff6b7a",
	0,
	0,
	114,
	50,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"95064ec7-3be4-4e60-899f-293c293e9949");
INSERT INTO V_SLR
	VALUES ("464a21fa-a041-4f73-9d19-9c7d4dff6b7a",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("d5b2bbef-560e-4f3f-874d-293e19261b13",
	0,
	0,
	114,
	59,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"95064ec7-3be4-4e60-899f-293c293e9949");
INSERT INTO V_AVL
	VALUES ("d5b2bbef-560e-4f3f-874d-293e19261b13",
	"464a21fa-a041-4f73-9d19-9c7d4dff6b7a",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1");
INSERT INTO V_VAL
	VALUES ("f145f9cc-47a8-497d-a80b-c5f74e6c6dba",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"95064ec7-3be4-4e60-899f-293c293e9949");
INSERT INTO V_BIN
	VALUES ("f145f9cc-47a8-497d-a80b-c5f74e6c6dba",
	"5c21fc86-07b9-4b24-8759-df68caf68a8e",
	"d5b2bbef-560e-4f3f-874d-293e19261b13",
	'==');
INSERT INTO V_VAL
	VALUES ("5c21fc86-07b9-4b24-8759-df68caf68a8e",
	0,
	0,
	114,
	69,
	69,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"95064ec7-3be4-4e60-899f-293c293e9949");
INSERT INTO V_LIN
	VALUES ("5c21fc86-07b9-4b24-8759-df68caf68a8e",
	'8');
INSERT INTO V_VAR
	VALUES ("8b80c97c-5e30-426c-97c8-c47425a3e730",
	"95064ec7-3be4-4e60-899f-293c293e9949",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("8b80c97c-5e30-426c-97c8-c47425a3e730",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("b425125a-f943-44bd-909d-b240b553edd2",
	114,
	16,
	18,
	"8b80c97c-5e30-426c-97c8-c47425a3e730");
INSERT INTO V_LOC
	VALUES ("c86afc0e-b217-41cd-b363-1ddc896b9c8c",
	115,
	20,
	22,
	"8b80c97c-5e30-426c-97c8-c47425a3e730");
INSERT INTO ACT_BLK
	VALUES ("ec2eb6f8-9922-4a3b-ac21-63312c0301d5",
	1,
	0,
	1,
	'',
	'',
	'',
	119,
	5,
	118,
	38,
	0,
	0,
	119,
	31,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("721437db-4a67-49a4-9588-4cca831f0187",
	"ec2eb6f8-9922-4a3b-ac21-63312c0301d5",
	"5a4a802f-f466-4a6f-aebe-d1dbdf23da3b",
	118,
	5,
	'setup line: 118');
INSERT INTO ACT_FIW
	VALUES ("721437db-4a67-49a4-9588-4cca831f0187",
	"20e7bb55-493f-4b80-bb11-6174c21d6984",
	1,
	'any',
	"8b032330-ec38-4004-882f-1db685614310",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	118,
	38);
INSERT INTO ACT_SMT
	VALUES ("5a4a802f-f466-4a6f-aebe-d1dbdf23da3b",
	"ec2eb6f8-9922-4a3b-ac21-63312c0301d5",
	"00000000-0000-0000-0000-000000000000",
	119,
	5,
	'setup line: 119');
INSERT INTO ACT_REL
	VALUES ("5a4a802f-f466-4a6f-aebe-d1dbdf23da3b",
	"8c61dd78-2dbb-4631-8d53-ff49377330f6",
	"20e7bb55-493f-4b80-bb11-6174c21d6984",
	'',
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	119,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("baf47500-f2ab-4cf8-92e7-dee6ac4f55ac",
	0,
	0,
	118,
	50,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ec2eb6f8-9922-4a3b-ac21-63312c0301d5");
INSERT INTO V_SLR
	VALUES ("baf47500-f2ab-4cf8-92e7-dee6ac4f55ac",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("2d3ad556-47be-423f-bc5f-f139bd29b297",
	0,
	0,
	118,
	59,
	64,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ec2eb6f8-9922-4a3b-ac21-63312c0301d5");
INSERT INTO V_AVL
	VALUES ("2d3ad556-47be-423f-bc5f-f139bd29b297",
	"baf47500-f2ab-4cf8-92e7-dee6ac4f55ac",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1");
INSERT INTO V_VAL
	VALUES ("8b032330-ec38-4004-882f-1db685614310",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"ec2eb6f8-9922-4a3b-ac21-63312c0301d5");
INSERT INTO V_BIN
	VALUES ("8b032330-ec38-4004-882f-1db685614310",
	"2bd1e237-5aef-45f6-ae82-ed68e9d66c63",
	"2d3ad556-47be-423f-bc5f-f139bd29b297",
	'==');
INSERT INTO V_VAL
	VALUES ("2bd1e237-5aef-45f6-ae82-ed68e9d66c63",
	0,
	0,
	118,
	69,
	69,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ec2eb6f8-9922-4a3b-ac21-63312c0301d5");
INSERT INTO V_LIN
	VALUES ("2bd1e237-5aef-45f6-ae82-ed68e9d66c63",
	'9');
INSERT INTO V_VAR
	VALUES ("20e7bb55-493f-4b80-bb11-6174c21d6984",
	"ec2eb6f8-9922-4a3b-ac21-63312c0301d5",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("20e7bb55-493f-4b80-bb11-6174c21d6984",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("a90bbba0-4294-418b-ab21-2f85105d9d99",
	118,
	16,
	18,
	"20e7bb55-493f-4b80-bb11-6174c21d6984");
INSERT INTO V_LOC
	VALUES ("caa7f346-a5bd-4880-8a19-1aa3fb677daf",
	119,
	20,
	22,
	"20e7bb55-493f-4b80-bb11-6174c21d6984");
INSERT INTO ACT_BLK
	VALUES ("2388dd92-7c8f-4b5d-bd3e-a855669f2922",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	124,
	3,
	124,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"d0e48559-ca31-4fe2-9a70-55408fd80c5a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d7193bd0-d81c-4825-a0f5-38faefbdd9f1",
	"2388dd92-7c8f-4b5d-bd3e-a855669f2922",
	"00000000-0000-0000-0000-000000000000",
	124,
	3,
	'setup line: 124');
INSERT INTO ACT_BRG
	VALUES ("d7193bd0-d81c-4825-a0f5-38faefbdd9f1",
	"20118c86-a3a0-4c4b-80f0-5ef1a2122e2f",
	124,
	8,
	124,
	3);
INSERT INTO V_VAL
	VALUES ("647554d9-bff7-4930-ab41-b971f21023b2",
	0,
	0,
	124,
	25,
	40,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"2388dd92-7c8f-4b5d-bd3e-a855669f2922");
INSERT INTO V_LST
	VALUES ("647554d9-bff7-4930-ab41-b971f21023b2",
	'PEI data found.');
INSERT INTO V_PAR
	VALUES ("647554d9-bff7-4930-ab41-b971f21023b2",
	"d7193bd0-d81c-4825-a0f5-38faefbdd9f1",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	124,
	17);
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"eac4991b-5f13-4165-af93-0cbd5fbd09ee");
INSERT INTO S_SYNC
	VALUES ("eac4991b-5f13-4165-af93-0cbd5fbd09ee",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'setz1_given',
	'',
	'

CELL::set_given( row:1, column:3, answer:9 );
CELL::set_given( row:1, column:4, answer:3 );
CELL::set_given( row:1, column:9, answer:5 );

CELL::set_given( row:2, column:4, answer:5 );
CELL::set_given( row:2, column:5, answer:1 );
CELL::set_given( row:2, column:6, answer:4 );
CELL::set_given( row:2, column:8, answer:7 );

CELL::set_given( row:3, column:1, answer:1 );
CELL::set_given( row:3, column:2, answer:5 );
CELL::set_given( row:3, column:3, answer:6 );
CELL::set_given( row:3, column:8, answer:8 );

CELL::set_given( row:4, column:1, answer:9 );
CELL::set_given( row:4, column:5, answer:8 );
CELL::set_given( row:4, column:9, answer:1 );

CELL::set_given( row:5, column:1, answer:7 );
CELL::set_given( row:5, column:4, answer:9 );
CELL::set_given( row:5, column:6, answer:5 );
CELL::set_given( row:5, column:9, answer:2 );

CELL::set_given( row:6, column:1, answer:5 );
CELL::set_given( row:6, column:5, answer:3 );
CELL::set_given( row:6, column:9, answer:9 );

CELL::set_given( row:7, column:2, answer:2 );
CELL::set_given( row:7, column:7, answer:4 );
CELL::set_given( row:7, column:8, answer:1 );
CELL::set_given( row:7, column:9, answer:7 );

CELL::set_given( row:8, column:2, answer:4 );
CELL::set_given( row:8, column:4, answer:1 );
CELL::set_given( row:8, column:5, answer:5 );
CELL::set_given( row:8, column:6, answer:6 );

CELL::set_given( row:9, column:1, answer:3 );
CELL::set_given( row:9, column:6, answer:7 );
CELL::set_given( row:9, column:7, answer:5 );

',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("9bf23685-f8dc-4e08-82df-63b7bfbc0aba",
	"eac4991b-5f13-4165-af93-0cbd5fbd09ee");
INSERT INTO ACT_ACT
	VALUES ("9bf23685-f8dc-4e08-82df-63b7bfbc0aba",
	'function',
	0,
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setz1_given',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("535b3d66-ad27-4edc-a45b-26b2751e5713",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	42,
	1,
	42,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9bf23685-f8dc-4e08-82df-63b7bfbc0aba",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e7fa1bdd-90d5-4b25-a955-6c4d0cd2284c",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"1faa1962-f6e0-415e-87df-6901a09f4dcd",
	3,
	1,
	'setz1_given line: 3');
INSERT INTO ACT_TFM
	VALUES ("e7fa1bdd-90d5-4b25-a955-6c4d0cd2284c",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES ("1faa1962-f6e0-415e-87df-6901a09f4dcd",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"4d9e499b-bd00-40c6-90d7-f41bc3e8a43b",
	4,
	1,
	'setz1_given line: 4');
INSERT INTO ACT_TFM
	VALUES ("1faa1962-f6e0-415e-87df-6901a09f4dcd",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES ("4d9e499b-bd00-40c6-90d7-f41bc3e8a43b",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"c8fb46fb-3624-4220-a205-f487c83448a9",
	5,
	1,
	'setz1_given line: 5');
INSERT INTO ACT_TFM
	VALUES ("4d9e499b-bd00-40c6-90d7-f41bc3e8a43b",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	5,
	7,
	5,
	1);
INSERT INTO ACT_SMT
	VALUES ("c8fb46fb-3624-4220-a205-f487c83448a9",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"f5a479a4-19db-4cee-a8a3-69a1f209269e",
	7,
	1,
	'setz1_given line: 7');
INSERT INTO ACT_TFM
	VALUES ("c8fb46fb-3624-4220-a205-f487c83448a9",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES ("f5a479a4-19db-4cee-a8a3-69a1f209269e",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"76c5aa2b-83ef-4a72-8cbc-dcd43093e4f3",
	8,
	1,
	'setz1_given line: 8');
INSERT INTO ACT_TFM
	VALUES ("f5a479a4-19db-4cee-a8a3-69a1f209269e",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES ("76c5aa2b-83ef-4a72-8cbc-dcd43093e4f3",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"a2a93bba-4a6c-441d-b919-96be7e0223f2",
	9,
	1,
	'setz1_given line: 9');
INSERT INTO ACT_TFM
	VALUES ("76c5aa2b-83ef-4a72-8cbc-dcd43093e4f3",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	9,
	7,
	9,
	1);
INSERT INTO ACT_SMT
	VALUES ("a2a93bba-4a6c-441d-b919-96be7e0223f2",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"47664703-24bd-411a-8c0d-3a7a8de21c8b",
	10,
	1,
	'setz1_given line: 10');
INSERT INTO ACT_TFM
	VALUES ("a2a93bba-4a6c-441d-b919-96be7e0223f2",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES ("47664703-24bd-411a-8c0d-3a7a8de21c8b",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"3f368079-b20b-4490-acb3-34267e2cd7d7",
	12,
	1,
	'setz1_given line: 12');
INSERT INTO ACT_TFM
	VALUES ("47664703-24bd-411a-8c0d-3a7a8de21c8b",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES ("3f368079-b20b-4490-acb3-34267e2cd7d7",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"d484731d-9543-42a1-8b3d-1505a4213181",
	13,
	1,
	'setz1_given line: 13');
INSERT INTO ACT_TFM
	VALUES ("3f368079-b20b-4490-acb3-34267e2cd7d7",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	13,
	7,
	13,
	1);
INSERT INTO ACT_SMT
	VALUES ("d484731d-9543-42a1-8b3d-1505a4213181",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"742116a2-f7ef-4bb0-974e-be0777422a5b",
	14,
	1,
	'setz1_given line: 14');
INSERT INTO ACT_TFM
	VALUES ("d484731d-9543-42a1-8b3d-1505a4213181",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	14,
	7,
	14,
	1);
INSERT INTO ACT_SMT
	VALUES ("742116a2-f7ef-4bb0-974e-be0777422a5b",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"4ec9cd58-ab59-43d7-8c05-3d55810ea0a4",
	15,
	1,
	'setz1_given line: 15');
INSERT INTO ACT_TFM
	VALUES ("742116a2-f7ef-4bb0-974e-be0777422a5b",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES ("4ec9cd58-ab59-43d7-8c05-3d55810ea0a4",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"19e0f260-2f28-4818-97e8-523b8ef6c00d",
	17,
	1,
	'setz1_given line: 17');
INSERT INTO ACT_TFM
	VALUES ("4ec9cd58-ab59-43d7-8c05-3d55810ea0a4",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES ("19e0f260-2f28-4818-97e8-523b8ef6c00d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"371f074b-ea95-4b69-bfeb-8547d60f7449",
	18,
	1,
	'setz1_given line: 18');
INSERT INTO ACT_TFM
	VALUES ("19e0f260-2f28-4818-97e8-523b8ef6c00d",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	18,
	7,
	18,
	1);
INSERT INTO ACT_SMT
	VALUES ("371f074b-ea95-4b69-bfeb-8547d60f7449",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"6edc62d1-8a53-4cc4-82fe-3bc4bfe1f753",
	19,
	1,
	'setz1_given line: 19');
INSERT INTO ACT_TFM
	VALUES ("371f074b-ea95-4b69-bfeb-8547d60f7449",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	19,
	7,
	19,
	1);
INSERT INTO ACT_SMT
	VALUES ("6edc62d1-8a53-4cc4-82fe-3bc4bfe1f753",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"fc98fc22-f1b0-4727-9505-cc022dd4b5ea",
	21,
	1,
	'setz1_given line: 21');
INSERT INTO ACT_TFM
	VALUES ("6edc62d1-8a53-4cc4-82fe-3bc4bfe1f753",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	21,
	7,
	21,
	1);
INSERT INTO ACT_SMT
	VALUES ("fc98fc22-f1b0-4727-9505-cc022dd4b5ea",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"f4af9fa0-485d-498b-8668-183bfdd9de8b",
	22,
	1,
	'setz1_given line: 22');
INSERT INTO ACT_TFM
	VALUES ("fc98fc22-f1b0-4727-9505-cc022dd4b5ea",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	22,
	7,
	22,
	1);
INSERT INTO ACT_SMT
	VALUES ("f4af9fa0-485d-498b-8668-183bfdd9de8b",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"6b964b60-e89e-4076-80fb-e9f3518f1957",
	23,
	1,
	'setz1_given line: 23');
INSERT INTO ACT_TFM
	VALUES ("f4af9fa0-485d-498b-8668-183bfdd9de8b",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES ("6b964b60-e89e-4076-80fb-e9f3518f1957",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"46b877f8-916b-4aaa-a7b4-bd74497a400b",
	24,
	1,
	'setz1_given line: 24');
INSERT INTO ACT_TFM
	VALUES ("6b964b60-e89e-4076-80fb-e9f3518f1957",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES ("46b877f8-916b-4aaa-a7b4-bd74497a400b",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"d3b35c25-4f26-4d80-b644-daefaf968b67",
	26,
	1,
	'setz1_given line: 26');
INSERT INTO ACT_TFM
	VALUES ("46b877f8-916b-4aaa-a7b4-bd74497a400b",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	26,
	7,
	26,
	1);
INSERT INTO ACT_SMT
	VALUES ("d3b35c25-4f26-4d80-b644-daefaf968b67",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"7df256a8-768d-4bd5-afcc-074bf5c82d56",
	27,
	1,
	'setz1_given line: 27');
INSERT INTO ACT_TFM
	VALUES ("d3b35c25-4f26-4d80-b644-daefaf968b67",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	27,
	7,
	27,
	1);
INSERT INTO ACT_SMT
	VALUES ("7df256a8-768d-4bd5-afcc-074bf5c82d56",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"41b9012e-181f-463f-b3c2-7ccbac103489",
	28,
	1,
	'setz1_given line: 28');
INSERT INTO ACT_TFM
	VALUES ("7df256a8-768d-4bd5-afcc-074bf5c82d56",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	28,
	7,
	28,
	1);
INSERT INTO ACT_SMT
	VALUES ("41b9012e-181f-463f-b3c2-7ccbac103489",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"29c9ee6a-1e63-4f36-be61-0c6e70ea87c2",
	30,
	1,
	'setz1_given line: 30');
INSERT INTO ACT_TFM
	VALUES ("41b9012e-181f-463f-b3c2-7ccbac103489",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	30,
	7,
	30,
	1);
INSERT INTO ACT_SMT
	VALUES ("29c9ee6a-1e63-4f36-be61-0c6e70ea87c2",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"068c8519-63a9-435e-b75a-38e175149f55",
	31,
	1,
	'setz1_given line: 31');
INSERT INTO ACT_TFM
	VALUES ("29c9ee6a-1e63-4f36-be61-0c6e70ea87c2",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES ("068c8519-63a9-435e-b75a-38e175149f55",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"47202f26-ec4d-4bfe-a9de-ce07b2289053",
	32,
	1,
	'setz1_given line: 32');
INSERT INTO ACT_TFM
	VALUES ("068c8519-63a9-435e-b75a-38e175149f55",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES ("47202f26-ec4d-4bfe-a9de-ce07b2289053",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"a3b97f2d-6fdb-42c3-96c7-38e9f7c5687a",
	33,
	1,
	'setz1_given line: 33');
INSERT INTO ACT_TFM
	VALUES ("47202f26-ec4d-4bfe-a9de-ce07b2289053",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES ("a3b97f2d-6fdb-42c3-96c7-38e9f7c5687a",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"fc8e6db3-ad36-4ade-a1cc-7b8756bf2243",
	35,
	1,
	'setz1_given line: 35');
INSERT INTO ACT_TFM
	VALUES ("a3b97f2d-6fdb-42c3-96c7-38e9f7c5687a",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	35,
	7,
	35,
	1);
INSERT INTO ACT_SMT
	VALUES ("fc8e6db3-ad36-4ade-a1cc-7b8756bf2243",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"46eebedd-7a2f-435f-b8f7-9288ce34a6b9",
	36,
	1,
	'setz1_given line: 36');
INSERT INTO ACT_TFM
	VALUES ("fc8e6db3-ad36-4ade-a1cc-7b8756bf2243",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES ("46eebedd-7a2f-435f-b8f7-9288ce34a6b9",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"fafcf2cf-8a79-4505-ba0b-1c767b61e5d6",
	37,
	1,
	'setz1_given line: 37');
INSERT INTO ACT_TFM
	VALUES ("46eebedd-7a2f-435f-b8f7-9288ce34a6b9",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	37,
	7,
	37,
	1);
INSERT INTO ACT_SMT
	VALUES ("fafcf2cf-8a79-4505-ba0b-1c767b61e5d6",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"5ad98987-e256-4564-898a-c34f3d599c83",
	38,
	1,
	'setz1_given line: 38');
INSERT INTO ACT_TFM
	VALUES ("fafcf2cf-8a79-4505-ba0b-1c767b61e5d6",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	38,
	7,
	38,
	1);
INSERT INTO ACT_SMT
	VALUES ("5ad98987-e256-4564-898a-c34f3d599c83",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"ab5a422b-5eb4-4b60-928e-62cb206f53cf",
	40,
	1,
	'setz1_given line: 40');
INSERT INTO ACT_TFM
	VALUES ("5ad98987-e256-4564-898a-c34f3d599c83",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	40,
	7,
	40,
	1);
INSERT INTO ACT_SMT
	VALUES ("ab5a422b-5eb4-4b60-928e-62cb206f53cf",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"0c93d446-a93e-481c-a207-36cb01630e1e",
	41,
	1,
	'setz1_given line: 41');
INSERT INTO ACT_TFM
	VALUES ("ab5a422b-5eb4-4b60-928e-62cb206f53cf",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	41,
	7,
	41,
	1);
INSERT INTO ACT_SMT
	VALUES ("0c93d446-a93e-481c-a207-36cb01630e1e",
	"535b3d66-ad27-4edc-a45b-26b2751e5713",
	"00000000-0000-0000-0000-000000000000",
	42,
	1,
	'setz1_given line: 42');
INSERT INTO ACT_TFM
	VALUES ("0c93d446-a93e-481c-a207-36cb01630e1e",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	42,
	7,
	42,
	1);
INSERT INTO V_VAL
	VALUES ("6de5759a-2000-48fd-aa89-c0b4f8f00dd7",
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("6de5759a-2000-48fd-aa89-c0b4f8f00dd7",
	'1');
INSERT INTO V_PAR
	VALUES ("6de5759a-2000-48fd-aa89-c0b4f8f00dd7",
	"e7fa1bdd-90d5-4b25-a955-6c4d0cd2284c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"8d349e52-d0c6-4350-b68e-bb890a86303e",
	3,
	18);
INSERT INTO V_VAL
	VALUES ("8d349e52-d0c6-4350-b68e-bb890a86303e",
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("8d349e52-d0c6-4350-b68e-bb890a86303e",
	'3');
INSERT INTO V_PAR
	VALUES ("8d349e52-d0c6-4350-b68e-bb890a86303e",
	"e7fa1bdd-90d5-4b25-a955-6c4d0cd2284c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"ee4ddc12-9d0d-46c9-a2f1-7baeba30e35e",
	3,
	25);
INSERT INTO V_VAL
	VALUES ("ee4ddc12-9d0d-46c9-a2f1-7baeba30e35e",
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("ee4ddc12-9d0d-46c9-a2f1-7baeba30e35e",
	'9');
INSERT INTO V_PAR
	VALUES ("ee4ddc12-9d0d-46c9-a2f1-7baeba30e35e",
	"e7fa1bdd-90d5-4b25-a955-6c4d0cd2284c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	3,
	35);
INSERT INTO V_VAL
	VALUES ("71bb0f7a-7022-43c3-b7b4-2b3acc2b948b",
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("71bb0f7a-7022-43c3-b7b4-2b3acc2b948b",
	'1');
INSERT INTO V_PAR
	VALUES ("71bb0f7a-7022-43c3-b7b4-2b3acc2b948b",
	"1faa1962-f6e0-415e-87df-6901a09f4dcd",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"a07da4ad-412a-4fb3-8a6b-52195577033e",
	4,
	18);
INSERT INTO V_VAL
	VALUES ("a07da4ad-412a-4fb3-8a6b-52195577033e",
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("a07da4ad-412a-4fb3-8a6b-52195577033e",
	'4');
INSERT INTO V_PAR
	VALUES ("a07da4ad-412a-4fb3-8a6b-52195577033e",
	"1faa1962-f6e0-415e-87df-6901a09f4dcd",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"1267f2df-2db2-4b27-9de8-e4c456693f32",
	4,
	25);
INSERT INTO V_VAL
	VALUES ("1267f2df-2db2-4b27-9de8-e4c456693f32",
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("1267f2df-2db2-4b27-9de8-e4c456693f32",
	'3');
INSERT INTO V_PAR
	VALUES ("1267f2df-2db2-4b27-9de8-e4c456693f32",
	"1faa1962-f6e0-415e-87df-6901a09f4dcd",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	4,
	35);
INSERT INTO V_VAL
	VALUES ("07c5cd14-f890-4f32-88e1-fbfb6e9b9301",
	0,
	0,
	5,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("07c5cd14-f890-4f32-88e1-fbfb6e9b9301",
	'1');
INSERT INTO V_PAR
	VALUES ("07c5cd14-f890-4f32-88e1-fbfb6e9b9301",
	"4d9e499b-bd00-40c6-90d7-f41bc3e8a43b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"1261b74e-a844-4aec-a7ec-de069b41a664",
	5,
	18);
INSERT INTO V_VAL
	VALUES ("1261b74e-a844-4aec-a7ec-de069b41a664",
	0,
	0,
	5,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("1261b74e-a844-4aec-a7ec-de069b41a664",
	'9');
INSERT INTO V_PAR
	VALUES ("1261b74e-a844-4aec-a7ec-de069b41a664",
	"4d9e499b-bd00-40c6-90d7-f41bc3e8a43b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"0610335c-3bac-4a91-93e7-2f6ec96294c9",
	5,
	25);
INSERT INTO V_VAL
	VALUES ("0610335c-3bac-4a91-93e7-2f6ec96294c9",
	0,
	0,
	5,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("0610335c-3bac-4a91-93e7-2f6ec96294c9",
	'5');
INSERT INTO V_PAR
	VALUES ("0610335c-3bac-4a91-93e7-2f6ec96294c9",
	"4d9e499b-bd00-40c6-90d7-f41bc3e8a43b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	5,
	35);
INSERT INTO V_VAL
	VALUES ("7d65c88a-5615-4e4f-9fec-e8be5781d01b",
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("7d65c88a-5615-4e4f-9fec-e8be5781d01b",
	'2');
INSERT INTO V_PAR
	VALUES ("7d65c88a-5615-4e4f-9fec-e8be5781d01b",
	"c8fb46fb-3624-4220-a205-f487c83448a9",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4032b1e7-dc76-4be6-b170-e1325998256b",
	7,
	18);
INSERT INTO V_VAL
	VALUES ("4032b1e7-dc76-4be6-b170-e1325998256b",
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("4032b1e7-dc76-4be6-b170-e1325998256b",
	'4');
INSERT INTO V_PAR
	VALUES ("4032b1e7-dc76-4be6-b170-e1325998256b",
	"c8fb46fb-3624-4220-a205-f487c83448a9",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"69351008-d9d6-483e-b584-19506d1c9245",
	7,
	25);
INSERT INTO V_VAL
	VALUES ("69351008-d9d6-483e-b584-19506d1c9245",
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("69351008-d9d6-483e-b584-19506d1c9245",
	'5');
INSERT INTO V_PAR
	VALUES ("69351008-d9d6-483e-b584-19506d1c9245",
	"c8fb46fb-3624-4220-a205-f487c83448a9",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	7,
	35);
INSERT INTO V_VAL
	VALUES ("03fe8860-7f31-494b-8f04-6a29dcd56634",
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("03fe8860-7f31-494b-8f04-6a29dcd56634",
	'2');
INSERT INTO V_PAR
	VALUES ("03fe8860-7f31-494b-8f04-6a29dcd56634",
	"f5a479a4-19db-4cee-a8a3-69a1f209269e",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"3125f79d-6995-4c89-8ed1-569778d60559",
	8,
	18);
INSERT INTO V_VAL
	VALUES ("3125f79d-6995-4c89-8ed1-569778d60559",
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("3125f79d-6995-4c89-8ed1-569778d60559",
	'5');
INSERT INTO V_PAR
	VALUES ("3125f79d-6995-4c89-8ed1-569778d60559",
	"f5a479a4-19db-4cee-a8a3-69a1f209269e",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"2f72b1d3-8116-470c-9c09-c7de7837bdc5",
	8,
	25);
INSERT INTO V_VAL
	VALUES ("2f72b1d3-8116-470c-9c09-c7de7837bdc5",
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("2f72b1d3-8116-470c-9c09-c7de7837bdc5",
	'1');
INSERT INTO V_PAR
	VALUES ("2f72b1d3-8116-470c-9c09-c7de7837bdc5",
	"f5a479a4-19db-4cee-a8a3-69a1f209269e",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	8,
	35);
INSERT INTO V_VAL
	VALUES ("dfa88fad-983d-4504-b934-fd3fb80aad3e",
	0,
	0,
	9,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("dfa88fad-983d-4504-b934-fd3fb80aad3e",
	'2');
INSERT INTO V_PAR
	VALUES ("dfa88fad-983d-4504-b934-fd3fb80aad3e",
	"76c5aa2b-83ef-4a72-8cbc-dcd43093e4f3",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"5056ba74-a325-478f-8227-25268f7ed1d3",
	9,
	18);
INSERT INTO V_VAL
	VALUES ("5056ba74-a325-478f-8227-25268f7ed1d3",
	0,
	0,
	9,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("5056ba74-a325-478f-8227-25268f7ed1d3",
	'6');
INSERT INTO V_PAR
	VALUES ("5056ba74-a325-478f-8227-25268f7ed1d3",
	"76c5aa2b-83ef-4a72-8cbc-dcd43093e4f3",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f67227f8-5dea-4bf3-bbc3-5af543dd7add",
	9,
	25);
INSERT INTO V_VAL
	VALUES ("f67227f8-5dea-4bf3-bbc3-5af543dd7add",
	0,
	0,
	9,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("f67227f8-5dea-4bf3-bbc3-5af543dd7add",
	'4');
INSERT INTO V_PAR
	VALUES ("f67227f8-5dea-4bf3-bbc3-5af543dd7add",
	"76c5aa2b-83ef-4a72-8cbc-dcd43093e4f3",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	9,
	35);
INSERT INTO V_VAL
	VALUES ("f7eae264-8338-4f9d-acc3-009f9921daaf",
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("f7eae264-8338-4f9d-acc3-009f9921daaf",
	'2');
INSERT INTO V_PAR
	VALUES ("f7eae264-8338-4f9d-acc3-009f9921daaf",
	"a2a93bba-4a6c-441d-b919-96be7e0223f2",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"302f66f8-70a7-487d-a6f0-15ca8d076102",
	10,
	18);
INSERT INTO V_VAL
	VALUES ("302f66f8-70a7-487d-a6f0-15ca8d076102",
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("302f66f8-70a7-487d-a6f0-15ca8d076102",
	'8');
INSERT INTO V_PAR
	VALUES ("302f66f8-70a7-487d-a6f0-15ca8d076102",
	"a2a93bba-4a6c-441d-b919-96be7e0223f2",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"75ed556f-a71b-4d30-8026-292163f917f2",
	10,
	25);
INSERT INTO V_VAL
	VALUES ("75ed556f-a71b-4d30-8026-292163f917f2",
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("75ed556f-a71b-4d30-8026-292163f917f2",
	'7');
INSERT INTO V_PAR
	VALUES ("75ed556f-a71b-4d30-8026-292163f917f2",
	"a2a93bba-4a6c-441d-b919-96be7e0223f2",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	10,
	35);
INSERT INTO V_VAL
	VALUES ("2a6a956e-29c8-4218-80bf-5265b7b5c22f",
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("2a6a956e-29c8-4218-80bf-5265b7b5c22f",
	'3');
INSERT INTO V_PAR
	VALUES ("2a6a956e-29c8-4218-80bf-5265b7b5c22f",
	"47664703-24bd-411a-8c0d-3a7a8de21c8b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2b9a8cd5-62ff-465b-9c84-42061ca28ca7",
	12,
	18);
INSERT INTO V_VAL
	VALUES ("2b9a8cd5-62ff-465b-9c84-42061ca28ca7",
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("2b9a8cd5-62ff-465b-9c84-42061ca28ca7",
	'1');
INSERT INTO V_PAR
	VALUES ("2b9a8cd5-62ff-465b-9c84-42061ca28ca7",
	"47664703-24bd-411a-8c0d-3a7a8de21c8b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"df4f2929-d141-4c9b-97af-d946bd4e9453",
	12,
	25);
INSERT INTO V_VAL
	VALUES ("df4f2929-d141-4c9b-97af-d946bd4e9453",
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("df4f2929-d141-4c9b-97af-d946bd4e9453",
	'1');
INSERT INTO V_PAR
	VALUES ("df4f2929-d141-4c9b-97af-d946bd4e9453",
	"47664703-24bd-411a-8c0d-3a7a8de21c8b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	12,
	35);
INSERT INTO V_VAL
	VALUES ("01105da6-02b3-478d-a7a2-c35a2bc35f22",
	0,
	0,
	13,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("01105da6-02b3-478d-a7a2-c35a2bc35f22",
	'3');
INSERT INTO V_PAR
	VALUES ("01105da6-02b3-478d-a7a2-c35a2bc35f22",
	"3f368079-b20b-4490-acb3-34267e2cd7d7",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"43af8883-540c-49e9-86bf-81d3eda507c3",
	13,
	18);
INSERT INTO V_VAL
	VALUES ("43af8883-540c-49e9-86bf-81d3eda507c3",
	0,
	0,
	13,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("43af8883-540c-49e9-86bf-81d3eda507c3",
	'2');
INSERT INTO V_PAR
	VALUES ("43af8883-540c-49e9-86bf-81d3eda507c3",
	"3f368079-b20b-4490-acb3-34267e2cd7d7",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"a4842fa0-b1fa-4bf9-b0da-c1af1309e25c",
	13,
	25);
INSERT INTO V_VAL
	VALUES ("a4842fa0-b1fa-4bf9-b0da-c1af1309e25c",
	0,
	0,
	13,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("a4842fa0-b1fa-4bf9-b0da-c1af1309e25c",
	'5');
INSERT INTO V_PAR
	VALUES ("a4842fa0-b1fa-4bf9-b0da-c1af1309e25c",
	"3f368079-b20b-4490-acb3-34267e2cd7d7",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	13,
	35);
INSERT INTO V_VAL
	VALUES ("79b4eeb5-03ef-4dda-8147-a1027914c9a4",
	0,
	0,
	14,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("79b4eeb5-03ef-4dda-8147-a1027914c9a4",
	'3');
INSERT INTO V_PAR
	VALUES ("79b4eeb5-03ef-4dda-8147-a1027914c9a4",
	"d484731d-9543-42a1-8b3d-1505a4213181",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"3e60545a-b1e1-4b26-9f91-2c55a17e6de9",
	14,
	18);
INSERT INTO V_VAL
	VALUES ("3e60545a-b1e1-4b26-9f91-2c55a17e6de9",
	0,
	0,
	14,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("3e60545a-b1e1-4b26-9f91-2c55a17e6de9",
	'3');
INSERT INTO V_PAR
	VALUES ("3e60545a-b1e1-4b26-9f91-2c55a17e6de9",
	"d484731d-9543-42a1-8b3d-1505a4213181",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"77cf025f-8614-474a-9e92-67829d9320ad",
	14,
	25);
INSERT INTO V_VAL
	VALUES ("77cf025f-8614-474a-9e92-67829d9320ad",
	0,
	0,
	14,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("77cf025f-8614-474a-9e92-67829d9320ad",
	'6');
INSERT INTO V_PAR
	VALUES ("77cf025f-8614-474a-9e92-67829d9320ad",
	"d484731d-9543-42a1-8b3d-1505a4213181",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	14,
	35);
INSERT INTO V_VAL
	VALUES ("dc184ff3-a7a3-47c6-9579-3df4e068178c",
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("dc184ff3-a7a3-47c6-9579-3df4e068178c",
	'3');
INSERT INTO V_PAR
	VALUES ("dc184ff3-a7a3-47c6-9579-3df4e068178c",
	"742116a2-f7ef-4bb0-974e-be0777422a5b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2805ca3f-a930-4c4c-bc06-41281d0eb982",
	15,
	18);
INSERT INTO V_VAL
	VALUES ("2805ca3f-a930-4c4c-bc06-41281d0eb982",
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("2805ca3f-a930-4c4c-bc06-41281d0eb982",
	'8');
INSERT INTO V_PAR
	VALUES ("2805ca3f-a930-4c4c-bc06-41281d0eb982",
	"742116a2-f7ef-4bb0-974e-be0777422a5b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"e5edcb84-66f3-4f74-85d6-5412ea8cad31",
	15,
	25);
INSERT INTO V_VAL
	VALUES ("e5edcb84-66f3-4f74-85d6-5412ea8cad31",
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("e5edcb84-66f3-4f74-85d6-5412ea8cad31",
	'8');
INSERT INTO V_PAR
	VALUES ("e5edcb84-66f3-4f74-85d6-5412ea8cad31",
	"742116a2-f7ef-4bb0-974e-be0777422a5b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	15,
	35);
INSERT INTO V_VAL
	VALUES ("eb0f6dcb-3bde-4c35-91b5-4c52869f9c8f",
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("eb0f6dcb-3bde-4c35-91b5-4c52869f9c8f",
	'4');
INSERT INTO V_PAR
	VALUES ("eb0f6dcb-3bde-4c35-91b5-4c52869f9c8f",
	"4ec9cd58-ab59-43d7-8c05-3d55810ea0a4",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"57c05893-78e7-4375-ae80-5f38edc89b29",
	17,
	18);
INSERT INTO V_VAL
	VALUES ("57c05893-78e7-4375-ae80-5f38edc89b29",
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("57c05893-78e7-4375-ae80-5f38edc89b29",
	'1');
INSERT INTO V_PAR
	VALUES ("57c05893-78e7-4375-ae80-5f38edc89b29",
	"4ec9cd58-ab59-43d7-8c05-3d55810ea0a4",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"3c96ffe7-62ee-41e6-a373-189e555f292b",
	17,
	25);
INSERT INTO V_VAL
	VALUES ("3c96ffe7-62ee-41e6-a373-189e555f292b",
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("3c96ffe7-62ee-41e6-a373-189e555f292b",
	'9');
INSERT INTO V_PAR
	VALUES ("3c96ffe7-62ee-41e6-a373-189e555f292b",
	"4ec9cd58-ab59-43d7-8c05-3d55810ea0a4",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	17,
	35);
INSERT INTO V_VAL
	VALUES ("ddea638a-54a8-4d58-a1ba-9ae2e81ed3a6",
	0,
	0,
	18,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("ddea638a-54a8-4d58-a1ba-9ae2e81ed3a6",
	'4');
INSERT INTO V_PAR
	VALUES ("ddea638a-54a8-4d58-a1ba-9ae2e81ed3a6",
	"19e0f260-2f28-4818-97e8-523b8ef6c00d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"a1f8f93d-667c-4e71-9481-3aa2dae7896e",
	18,
	18);
INSERT INTO V_VAL
	VALUES ("a1f8f93d-667c-4e71-9481-3aa2dae7896e",
	0,
	0,
	18,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("a1f8f93d-667c-4e71-9481-3aa2dae7896e",
	'5');
INSERT INTO V_PAR
	VALUES ("a1f8f93d-667c-4e71-9481-3aa2dae7896e",
	"19e0f260-2f28-4818-97e8-523b8ef6c00d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"58ece580-c8f5-4290-a8a9-a3a1858812b2",
	18,
	25);
INSERT INTO V_VAL
	VALUES ("58ece580-c8f5-4290-a8a9-a3a1858812b2",
	0,
	0,
	18,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("58ece580-c8f5-4290-a8a9-a3a1858812b2",
	'8');
INSERT INTO V_PAR
	VALUES ("58ece580-c8f5-4290-a8a9-a3a1858812b2",
	"19e0f260-2f28-4818-97e8-523b8ef6c00d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	18,
	35);
INSERT INTO V_VAL
	VALUES ("b18b9278-1fb9-4091-a8d7-98e4a9376223",
	0,
	0,
	19,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("b18b9278-1fb9-4091-a8d7-98e4a9376223",
	'4');
INSERT INTO V_PAR
	VALUES ("b18b9278-1fb9-4091-a8d7-98e4a9376223",
	"371f074b-ea95-4b69-bfeb-8547d60f7449",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"3fb4c5b9-08ea-472f-8277-1c3037ffb05e",
	19,
	18);
INSERT INTO V_VAL
	VALUES ("3fb4c5b9-08ea-472f-8277-1c3037ffb05e",
	0,
	0,
	19,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("3fb4c5b9-08ea-472f-8277-1c3037ffb05e",
	'9');
INSERT INTO V_PAR
	VALUES ("3fb4c5b9-08ea-472f-8277-1c3037ffb05e",
	"371f074b-ea95-4b69-bfeb-8547d60f7449",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"a1ff02a9-1aa8-4687-bba6-eca44f79f8e0",
	19,
	25);
INSERT INTO V_VAL
	VALUES ("a1ff02a9-1aa8-4687-bba6-eca44f79f8e0",
	0,
	0,
	19,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("a1ff02a9-1aa8-4687-bba6-eca44f79f8e0",
	'1');
INSERT INTO V_PAR
	VALUES ("a1ff02a9-1aa8-4687-bba6-eca44f79f8e0",
	"371f074b-ea95-4b69-bfeb-8547d60f7449",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	19,
	35);
INSERT INTO V_VAL
	VALUES ("8844a089-267e-4918-8baf-609b197d13db",
	0,
	0,
	21,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("8844a089-267e-4918-8baf-609b197d13db",
	'5');
INSERT INTO V_PAR
	VALUES ("8844a089-267e-4918-8baf-609b197d13db",
	"6edc62d1-8a53-4cc4-82fe-3bc4bfe1f753",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"8b3af3b0-63f4-4b6f-8cd8-637154b547bd",
	21,
	18);
INSERT INTO V_VAL
	VALUES ("8b3af3b0-63f4-4b6f-8cd8-637154b547bd",
	0,
	0,
	21,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("8b3af3b0-63f4-4b6f-8cd8-637154b547bd",
	'1');
INSERT INTO V_PAR
	VALUES ("8b3af3b0-63f4-4b6f-8cd8-637154b547bd",
	"6edc62d1-8a53-4cc4-82fe-3bc4bfe1f753",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"21e780a3-a894-4e2e-93e9-953468db88b3",
	21,
	25);
INSERT INTO V_VAL
	VALUES ("21e780a3-a894-4e2e-93e9-953468db88b3",
	0,
	0,
	21,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("21e780a3-a894-4e2e-93e9-953468db88b3",
	'7');
INSERT INTO V_PAR
	VALUES ("21e780a3-a894-4e2e-93e9-953468db88b3",
	"6edc62d1-8a53-4cc4-82fe-3bc4bfe1f753",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	21,
	35);
INSERT INTO V_VAL
	VALUES ("aee6dae9-9fcd-4d8b-8264-03515b9895a7",
	0,
	0,
	22,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("aee6dae9-9fcd-4d8b-8264-03515b9895a7",
	'5');
INSERT INTO V_PAR
	VALUES ("aee6dae9-9fcd-4d8b-8264-03515b9895a7",
	"fc98fc22-f1b0-4727-9505-cc022dd4b5ea",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"1623ac57-d653-4cbe-a7e8-1c70b9ce2476",
	22,
	18);
INSERT INTO V_VAL
	VALUES ("1623ac57-d653-4cbe-a7e8-1c70b9ce2476",
	0,
	0,
	22,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("1623ac57-d653-4cbe-a7e8-1c70b9ce2476",
	'4');
INSERT INTO V_PAR
	VALUES ("1623ac57-d653-4cbe-a7e8-1c70b9ce2476",
	"fc98fc22-f1b0-4727-9505-cc022dd4b5ea",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"21abd0dd-683c-4c5e-9c79-070ea7b90970",
	22,
	25);
INSERT INTO V_VAL
	VALUES ("21abd0dd-683c-4c5e-9c79-070ea7b90970",
	0,
	0,
	22,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("21abd0dd-683c-4c5e-9c79-070ea7b90970",
	'9');
INSERT INTO V_PAR
	VALUES ("21abd0dd-683c-4c5e-9c79-070ea7b90970",
	"fc98fc22-f1b0-4727-9505-cc022dd4b5ea",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	22,
	35);
INSERT INTO V_VAL
	VALUES ("7525b768-5613-4416-9dca-3415e5f798ee",
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("7525b768-5613-4416-9dca-3415e5f798ee",
	'5');
INSERT INTO V_PAR
	VALUES ("7525b768-5613-4416-9dca-3415e5f798ee",
	"f4af9fa0-485d-498b-8668-183bfdd9de8b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4b9a26c2-345b-418e-9081-bec74adb525d",
	23,
	18);
INSERT INTO V_VAL
	VALUES ("4b9a26c2-345b-418e-9081-bec74adb525d",
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("4b9a26c2-345b-418e-9081-bec74adb525d",
	'6');
INSERT INTO V_PAR
	VALUES ("4b9a26c2-345b-418e-9081-bec74adb525d",
	"f4af9fa0-485d-498b-8668-183bfdd9de8b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"c834ed40-214c-42f5-89d5-4d7fe83ce259",
	23,
	25);
INSERT INTO V_VAL
	VALUES ("c834ed40-214c-42f5-89d5-4d7fe83ce259",
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("c834ed40-214c-42f5-89d5-4d7fe83ce259",
	'5');
INSERT INTO V_PAR
	VALUES ("c834ed40-214c-42f5-89d5-4d7fe83ce259",
	"f4af9fa0-485d-498b-8668-183bfdd9de8b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	23,
	35);
INSERT INTO V_VAL
	VALUES ("bfacb7f6-bb0c-46fb-b030-b3b282807fc3",
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("bfacb7f6-bb0c-46fb-b030-b3b282807fc3",
	'5');
INSERT INTO V_PAR
	VALUES ("bfacb7f6-bb0c-46fb-b030-b3b282807fc3",
	"6b964b60-e89e-4076-80fb-e9f3518f1957",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"6fd33b07-1d40-412f-8370-001cd142107a",
	24,
	18);
INSERT INTO V_VAL
	VALUES ("6fd33b07-1d40-412f-8370-001cd142107a",
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("6fd33b07-1d40-412f-8370-001cd142107a",
	'9');
INSERT INTO V_PAR
	VALUES ("6fd33b07-1d40-412f-8370-001cd142107a",
	"6b964b60-e89e-4076-80fb-e9f3518f1957",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"c6d0aa63-69af-40e1-871f-f182024af60c",
	24,
	25);
INSERT INTO V_VAL
	VALUES ("c6d0aa63-69af-40e1-871f-f182024af60c",
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("c6d0aa63-69af-40e1-871f-f182024af60c",
	'2');
INSERT INTO V_PAR
	VALUES ("c6d0aa63-69af-40e1-871f-f182024af60c",
	"6b964b60-e89e-4076-80fb-e9f3518f1957",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	24,
	35);
INSERT INTO V_VAL
	VALUES ("2285cbc3-7a31-402f-b247-cb54a1731ba9",
	0,
	0,
	26,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("2285cbc3-7a31-402f-b247-cb54a1731ba9",
	'6');
INSERT INTO V_PAR
	VALUES ("2285cbc3-7a31-402f-b247-cb54a1731ba9",
	"46b877f8-916b-4aaa-a7b4-bd74497a400b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"21edc76b-d20d-4836-9806-65cb39fab29a",
	26,
	18);
INSERT INTO V_VAL
	VALUES ("21edc76b-d20d-4836-9806-65cb39fab29a",
	0,
	0,
	26,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("21edc76b-d20d-4836-9806-65cb39fab29a",
	'1');
INSERT INTO V_PAR
	VALUES ("21edc76b-d20d-4836-9806-65cb39fab29a",
	"46b877f8-916b-4aaa-a7b4-bd74497a400b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"2f7f81ff-c973-47af-a901-e221b22636be",
	26,
	25);
INSERT INTO V_VAL
	VALUES ("2f7f81ff-c973-47af-a901-e221b22636be",
	0,
	0,
	26,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("2f7f81ff-c973-47af-a901-e221b22636be",
	'5');
INSERT INTO V_PAR
	VALUES ("2f7f81ff-c973-47af-a901-e221b22636be",
	"46b877f8-916b-4aaa-a7b4-bd74497a400b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	26,
	35);
INSERT INTO V_VAL
	VALUES ("be938434-8306-4165-9a0a-4dbb3568340c",
	0,
	0,
	27,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("be938434-8306-4165-9a0a-4dbb3568340c",
	'6');
INSERT INTO V_PAR
	VALUES ("be938434-8306-4165-9a0a-4dbb3568340c",
	"d3b35c25-4f26-4d80-b644-daefaf968b67",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"cd800fad-37f0-4ff6-addb-8821ddea8f46",
	27,
	18);
INSERT INTO V_VAL
	VALUES ("cd800fad-37f0-4ff6-addb-8821ddea8f46",
	0,
	0,
	27,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("cd800fad-37f0-4ff6-addb-8821ddea8f46",
	'5');
INSERT INTO V_PAR
	VALUES ("cd800fad-37f0-4ff6-addb-8821ddea8f46",
	"d3b35c25-4f26-4d80-b644-daefaf968b67",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"78d14b99-ed6c-40e1-8f03-383005106872",
	27,
	25);
INSERT INTO V_VAL
	VALUES ("78d14b99-ed6c-40e1-8f03-383005106872",
	0,
	0,
	27,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("78d14b99-ed6c-40e1-8f03-383005106872",
	'3');
INSERT INTO V_PAR
	VALUES ("78d14b99-ed6c-40e1-8f03-383005106872",
	"d3b35c25-4f26-4d80-b644-daefaf968b67",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	27,
	35);
INSERT INTO V_VAL
	VALUES ("b926a701-5650-40b8-8fea-4e0dea4ed5aa",
	0,
	0,
	28,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("b926a701-5650-40b8-8fea-4e0dea4ed5aa",
	'6');
INSERT INTO V_PAR
	VALUES ("b926a701-5650-40b8-8fea-4e0dea4ed5aa",
	"7df256a8-768d-4bd5-afcc-074bf5c82d56",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"22d32900-2f6e-4ff6-ad6e-f5149b4909a8",
	28,
	18);
INSERT INTO V_VAL
	VALUES ("22d32900-2f6e-4ff6-ad6e-f5149b4909a8",
	0,
	0,
	28,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("22d32900-2f6e-4ff6-ad6e-f5149b4909a8",
	'9');
INSERT INTO V_PAR
	VALUES ("22d32900-2f6e-4ff6-ad6e-f5149b4909a8",
	"7df256a8-768d-4bd5-afcc-074bf5c82d56",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"87fa5b2c-0c0c-4d1d-92bb-e6d3d711aad5",
	28,
	25);
INSERT INTO V_VAL
	VALUES ("87fa5b2c-0c0c-4d1d-92bb-e6d3d711aad5",
	0,
	0,
	28,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("87fa5b2c-0c0c-4d1d-92bb-e6d3d711aad5",
	'9');
INSERT INTO V_PAR
	VALUES ("87fa5b2c-0c0c-4d1d-92bb-e6d3d711aad5",
	"7df256a8-768d-4bd5-afcc-074bf5c82d56",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	28,
	35);
INSERT INTO V_VAL
	VALUES ("fe1bdb7d-4e32-4cee-86ff-8b216924723d",
	0,
	0,
	30,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("fe1bdb7d-4e32-4cee-86ff-8b216924723d",
	'7');
INSERT INTO V_PAR
	VALUES ("fe1bdb7d-4e32-4cee-86ff-8b216924723d",
	"41b9012e-181f-463f-b3c2-7ccbac103489",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"d5ba00f4-4ce7-45ee-a505-04ef08ccef83",
	30,
	18);
INSERT INTO V_VAL
	VALUES ("d5ba00f4-4ce7-45ee-a505-04ef08ccef83",
	0,
	0,
	30,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("d5ba00f4-4ce7-45ee-a505-04ef08ccef83",
	'2');
INSERT INTO V_PAR
	VALUES ("d5ba00f4-4ce7-45ee-a505-04ef08ccef83",
	"41b9012e-181f-463f-b3c2-7ccbac103489",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f2cf500b-3f85-455a-a2f0-78dc1297b1f2",
	30,
	25);
INSERT INTO V_VAL
	VALUES ("f2cf500b-3f85-455a-a2f0-78dc1297b1f2",
	0,
	0,
	30,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("f2cf500b-3f85-455a-a2f0-78dc1297b1f2",
	'2');
INSERT INTO V_PAR
	VALUES ("f2cf500b-3f85-455a-a2f0-78dc1297b1f2",
	"41b9012e-181f-463f-b3c2-7ccbac103489",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	30,
	35);
INSERT INTO V_VAL
	VALUES ("55439ed8-1801-49f9-8376-9d83ef6228d0",
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("55439ed8-1801-49f9-8376-9d83ef6228d0",
	'7');
INSERT INTO V_PAR
	VALUES ("55439ed8-1801-49f9-8376-9d83ef6228d0",
	"29c9ee6a-1e63-4f36-be61-0c6e70ea87c2",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"9b2bd6a5-012b-4f7d-a3d3-4259fbc57407",
	31,
	18);
INSERT INTO V_VAL
	VALUES ("9b2bd6a5-012b-4f7d-a3d3-4259fbc57407",
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("9b2bd6a5-012b-4f7d-a3d3-4259fbc57407",
	'7');
INSERT INTO V_PAR
	VALUES ("9b2bd6a5-012b-4f7d-a3d3-4259fbc57407",
	"29c9ee6a-1e63-4f36-be61-0c6e70ea87c2",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"491354b3-2542-4184-aabc-d87169890150",
	31,
	25);
INSERT INTO V_VAL
	VALUES ("491354b3-2542-4184-aabc-d87169890150",
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("491354b3-2542-4184-aabc-d87169890150",
	'4');
INSERT INTO V_PAR
	VALUES ("491354b3-2542-4184-aabc-d87169890150",
	"29c9ee6a-1e63-4f36-be61-0c6e70ea87c2",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	31,
	35);
INSERT INTO V_VAL
	VALUES ("c7a702f7-f26f-4495-b602-f27b918e0e8b",
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("c7a702f7-f26f-4495-b602-f27b918e0e8b",
	'7');
INSERT INTO V_PAR
	VALUES ("c7a702f7-f26f-4495-b602-f27b918e0e8b",
	"068c8519-63a9-435e-b75a-38e175149f55",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"95e1f839-1571-4494-9f5a-845ac9d35341",
	32,
	18);
INSERT INTO V_VAL
	VALUES ("95e1f839-1571-4494-9f5a-845ac9d35341",
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("95e1f839-1571-4494-9f5a-845ac9d35341",
	'8');
INSERT INTO V_PAR
	VALUES ("95e1f839-1571-4494-9f5a-845ac9d35341",
	"068c8519-63a9-435e-b75a-38e175149f55",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"655fd56f-a7f1-40ac-9c40-9d38b5ee161d",
	32,
	25);
INSERT INTO V_VAL
	VALUES ("655fd56f-a7f1-40ac-9c40-9d38b5ee161d",
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("655fd56f-a7f1-40ac-9c40-9d38b5ee161d",
	'1');
INSERT INTO V_PAR
	VALUES ("655fd56f-a7f1-40ac-9c40-9d38b5ee161d",
	"068c8519-63a9-435e-b75a-38e175149f55",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	32,
	35);
INSERT INTO V_VAL
	VALUES ("e0ec958a-5362-4790-aa58-47f80a749160",
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("e0ec958a-5362-4790-aa58-47f80a749160",
	'7');
INSERT INTO V_PAR
	VALUES ("e0ec958a-5362-4790-aa58-47f80a749160",
	"47202f26-ec4d-4bfe-a9de-ce07b2289053",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"fa2ebb1b-767b-4a87-bdd3-77d87edee3e4",
	33,
	18);
INSERT INTO V_VAL
	VALUES ("fa2ebb1b-767b-4a87-bdd3-77d87edee3e4",
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("fa2ebb1b-767b-4a87-bdd3-77d87edee3e4",
	'9');
INSERT INTO V_PAR
	VALUES ("fa2ebb1b-767b-4a87-bdd3-77d87edee3e4",
	"47202f26-ec4d-4bfe-a9de-ce07b2289053",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"e8e583b0-20ef-4ce0-9401-7299596860e0",
	33,
	25);
INSERT INTO V_VAL
	VALUES ("e8e583b0-20ef-4ce0-9401-7299596860e0",
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("e8e583b0-20ef-4ce0-9401-7299596860e0",
	'7');
INSERT INTO V_PAR
	VALUES ("e8e583b0-20ef-4ce0-9401-7299596860e0",
	"47202f26-ec4d-4bfe-a9de-ce07b2289053",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	33,
	35);
INSERT INTO V_VAL
	VALUES ("1efed169-98f6-4fe8-aa05-d9e2638d9005",
	0,
	0,
	35,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("1efed169-98f6-4fe8-aa05-d9e2638d9005",
	'8');
INSERT INTO V_PAR
	VALUES ("1efed169-98f6-4fe8-aa05-d9e2638d9005",
	"a3b97f2d-6fdb-42c3-96c7-38e9f7c5687a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"d279ef73-f5e1-492f-a0d4-5ecf3d694459",
	35,
	18);
INSERT INTO V_VAL
	VALUES ("d279ef73-f5e1-492f-a0d4-5ecf3d694459",
	0,
	0,
	35,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("d279ef73-f5e1-492f-a0d4-5ecf3d694459",
	'2');
INSERT INTO V_PAR
	VALUES ("d279ef73-f5e1-492f-a0d4-5ecf3d694459",
	"a3b97f2d-6fdb-42c3-96c7-38e9f7c5687a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"05313603-1f7d-4e94-a27b-c000c99b1f9c",
	35,
	25);
INSERT INTO V_VAL
	VALUES ("05313603-1f7d-4e94-a27b-c000c99b1f9c",
	0,
	0,
	35,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("05313603-1f7d-4e94-a27b-c000c99b1f9c",
	'4');
INSERT INTO V_PAR
	VALUES ("05313603-1f7d-4e94-a27b-c000c99b1f9c",
	"a3b97f2d-6fdb-42c3-96c7-38e9f7c5687a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	35,
	35);
INSERT INTO V_VAL
	VALUES ("6b229c02-6bc9-4502-ab07-d020a4a2e5f7",
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("6b229c02-6bc9-4502-ab07-d020a4a2e5f7",
	'8');
INSERT INTO V_PAR
	VALUES ("6b229c02-6bc9-4502-ab07-d020a4a2e5f7",
	"fc8e6db3-ad36-4ade-a1cc-7b8756bf2243",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"10e8be1a-574e-4ce7-9339-aa6ad25e4839",
	36,
	18);
INSERT INTO V_VAL
	VALUES ("10e8be1a-574e-4ce7-9339-aa6ad25e4839",
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("10e8be1a-574e-4ce7-9339-aa6ad25e4839",
	'4');
INSERT INTO V_PAR
	VALUES ("10e8be1a-574e-4ce7-9339-aa6ad25e4839",
	"fc8e6db3-ad36-4ade-a1cc-7b8756bf2243",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"174c0f4d-8276-4651-85a8-8c842b34f2ec",
	36,
	25);
INSERT INTO V_VAL
	VALUES ("174c0f4d-8276-4651-85a8-8c842b34f2ec",
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("174c0f4d-8276-4651-85a8-8c842b34f2ec",
	'1');
INSERT INTO V_PAR
	VALUES ("174c0f4d-8276-4651-85a8-8c842b34f2ec",
	"fc8e6db3-ad36-4ade-a1cc-7b8756bf2243",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	36,
	35);
INSERT INTO V_VAL
	VALUES ("c6c877d5-693e-4380-b1f3-f1940f8424df",
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("c6c877d5-693e-4380-b1f3-f1940f8424df",
	'8');
INSERT INTO V_PAR
	VALUES ("c6c877d5-693e-4380-b1f3-f1940f8424df",
	"46eebedd-7a2f-435f-b8f7-9288ce34a6b9",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"079915f1-f2d1-48bd-b479-e9598def045d",
	37,
	18);
INSERT INTO V_VAL
	VALUES ("079915f1-f2d1-48bd-b479-e9598def045d",
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("079915f1-f2d1-48bd-b479-e9598def045d",
	'5');
INSERT INTO V_PAR
	VALUES ("079915f1-f2d1-48bd-b479-e9598def045d",
	"46eebedd-7a2f-435f-b8f7-9288ce34a6b9",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"abee2aca-8b0c-4b70-885b-633c659d67e7",
	37,
	25);
INSERT INTO V_VAL
	VALUES ("abee2aca-8b0c-4b70-885b-633c659d67e7",
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("abee2aca-8b0c-4b70-885b-633c659d67e7",
	'5');
INSERT INTO V_PAR
	VALUES ("abee2aca-8b0c-4b70-885b-633c659d67e7",
	"46eebedd-7a2f-435f-b8f7-9288ce34a6b9",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	37,
	35);
INSERT INTO V_VAL
	VALUES ("acca8507-3205-40c7-89c3-f1b45a46a2f6",
	0,
	0,
	38,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("acca8507-3205-40c7-89c3-f1b45a46a2f6",
	'8');
INSERT INTO V_PAR
	VALUES ("acca8507-3205-40c7-89c3-f1b45a46a2f6",
	"fafcf2cf-8a79-4505-ba0b-1c767b61e5d6",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"63850049-10f9-491a-a8e8-4dd86b3aaeb7",
	38,
	18);
INSERT INTO V_VAL
	VALUES ("63850049-10f9-491a-a8e8-4dd86b3aaeb7",
	0,
	0,
	38,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("63850049-10f9-491a-a8e8-4dd86b3aaeb7",
	'6');
INSERT INTO V_PAR
	VALUES ("63850049-10f9-491a-a8e8-4dd86b3aaeb7",
	"fafcf2cf-8a79-4505-ba0b-1c767b61e5d6",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"0dcbce54-d7a6-4274-a9f9-cdc59038a3c4",
	38,
	25);
INSERT INTO V_VAL
	VALUES ("0dcbce54-d7a6-4274-a9f9-cdc59038a3c4",
	0,
	0,
	38,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("0dcbce54-d7a6-4274-a9f9-cdc59038a3c4",
	'6');
INSERT INTO V_PAR
	VALUES ("0dcbce54-d7a6-4274-a9f9-cdc59038a3c4",
	"fafcf2cf-8a79-4505-ba0b-1c767b61e5d6",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	38,
	35);
INSERT INTO V_VAL
	VALUES ("b1cf8753-1413-45a0-a2ee-17ebe94acb5f",
	0,
	0,
	40,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("b1cf8753-1413-45a0-a2ee-17ebe94acb5f",
	'9');
INSERT INTO V_PAR
	VALUES ("b1cf8753-1413-45a0-a2ee-17ebe94acb5f",
	"5ad98987-e256-4564-898a-c34f3d599c83",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2411e1bf-3ad2-440f-8f9e-1a0347c1d1b9",
	40,
	18);
INSERT INTO V_VAL
	VALUES ("2411e1bf-3ad2-440f-8f9e-1a0347c1d1b9",
	0,
	0,
	40,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("2411e1bf-3ad2-440f-8f9e-1a0347c1d1b9",
	'1');
INSERT INTO V_PAR
	VALUES ("2411e1bf-3ad2-440f-8f9e-1a0347c1d1b9",
	"5ad98987-e256-4564-898a-c34f3d599c83",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"3f7db84e-7d1c-4b34-91b1-ae9f029ab6bb",
	40,
	25);
INSERT INTO V_VAL
	VALUES ("3f7db84e-7d1c-4b34-91b1-ae9f029ab6bb",
	0,
	0,
	40,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("3f7db84e-7d1c-4b34-91b1-ae9f029ab6bb",
	'3');
INSERT INTO V_PAR
	VALUES ("3f7db84e-7d1c-4b34-91b1-ae9f029ab6bb",
	"5ad98987-e256-4564-898a-c34f3d599c83",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	40,
	35);
INSERT INTO V_VAL
	VALUES ("0debcf60-95ec-4aaa-8411-639b890191b6",
	0,
	0,
	41,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("0debcf60-95ec-4aaa-8411-639b890191b6",
	'9');
INSERT INTO V_PAR
	VALUES ("0debcf60-95ec-4aaa-8411-639b890191b6",
	"ab5a422b-5eb4-4b60-928e-62cb206f53cf",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"d0ef36c5-0263-4801-af7a-6f3c6f94920c",
	41,
	18);
INSERT INTO V_VAL
	VALUES ("d0ef36c5-0263-4801-af7a-6f3c6f94920c",
	0,
	0,
	41,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("d0ef36c5-0263-4801-af7a-6f3c6f94920c",
	'6');
INSERT INTO V_PAR
	VALUES ("d0ef36c5-0263-4801-af7a-6f3c6f94920c",
	"ab5a422b-5eb4-4b60-928e-62cb206f53cf",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"a4ff6145-9893-401c-a912-71c65de731a2",
	41,
	25);
INSERT INTO V_VAL
	VALUES ("a4ff6145-9893-401c-a912-71c65de731a2",
	0,
	0,
	41,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("a4ff6145-9893-401c-a912-71c65de731a2",
	'7');
INSERT INTO V_PAR
	VALUES ("a4ff6145-9893-401c-a912-71c65de731a2",
	"ab5a422b-5eb4-4b60-928e-62cb206f53cf",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	41,
	35);
INSERT INTO V_VAL
	VALUES ("34957899-70a1-4d63-9842-68d6935b5497",
	0,
	0,
	42,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("34957899-70a1-4d63-9842-68d6935b5497",
	'9');
INSERT INTO V_PAR
	VALUES ("34957899-70a1-4d63-9842-68d6935b5497",
	"0c93d446-a93e-481c-a207-36cb01630e1e",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"ca8f0ddc-afff-4ddd-b91b-53b324a4a415",
	42,
	18);
INSERT INTO V_VAL
	VALUES ("ca8f0ddc-afff-4ddd-b91b-53b324a4a415",
	0,
	0,
	42,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("ca8f0ddc-afff-4ddd-b91b-53b324a4a415",
	'7');
INSERT INTO V_PAR
	VALUES ("ca8f0ddc-afff-4ddd-b91b-53b324a4a415",
	"0c93d446-a93e-481c-a207-36cb01630e1e",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"ac51620c-440e-498d-89d8-5d31cb301a81",
	42,
	25);
INSERT INTO V_VAL
	VALUES ("ac51620c-440e-498d-89d8-5d31cb301a81",
	0,
	0,
	42,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"535b3d66-ad27-4edc-a45b-26b2751e5713");
INSERT INTO V_LIN
	VALUES ("ac51620c-440e-498d-89d8-5d31cb301a81",
	'5');
INSERT INTO V_PAR
	VALUES ("ac51620c-440e-498d-89d8-5d31cb301a81",
	"0c93d446-a93e-481c-a207-36cb01630e1e",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	42,
	35);
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"ea7999d4-ad63-4a57-abe3-4a8224d30de0");
INSERT INTO S_SYNC
	VALUES ("ea7999d4-ad63-4a57-abe3-4a8224d30de0",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'display',
	'',
	'i = 1;
LOG::LogInfo( message:"\n|-+-+-+-+-+-+-+-+-|\n" );
while ( i <= 9 )
  j = 1;
  /*#inline
  printf( "|" );
  */
  b[8] = 0;
  while ( j <= 9 )
    select any cell from instances of CELL
      where ( ( selected.row_number == i ) and ( selected.column_number == j ) );
    a = cell.answer_value;
    b[j-1] = a;
    /*#inline
    if ( 0 == v59_a )
      printf( "   |" );
    else
      printf( " %d |", v59_a );
    */
    j = j + 1;
  end while;  
  LOG::LogInteger( message:b );
  i = i + 1;
end while;
LOG::LogInfo( message:"\n|-+-+-+-+-+-+-+-+-|\n" );
',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("67f4e561-9c59-42b1-bc8f-e840462afdf5",
	"ea7999d4-ad63-4a57-abe3-4a8224d30de0");
INSERT INTO ACT_ACT
	VALUES ("67f4e561-9c59-42b1-bc8f-e840462afdf5",
	'function',
	0,
	"1f911ae7-7a81-411b-8601-3abb75e39a7a",
	"00000000-0000-0000-0000-000000000000",
	0,
	'display',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("1f911ae7-7a81-411b-8601-3abb75e39a7a",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	25,
	1,
	25,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"67f4e561-9c59-42b1-bc8f-e840462afdf5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("fd388310-fde8-4500-8752-72622e1a95e8",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a",
	"827d547b-2c17-45bf-b83e-e214f85514e4",
	1,
	1,
	'display line: 1');
INSERT INTO ACT_AI
	VALUES ("fd388310-fde8-4500-8752-72622e1a95e8",
	"aab906a8-0926-4e32-82e9-1f59ffeae242",
	"bc5c7718-8811-41fd-91de-0d6c49b7131b",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("827d547b-2c17-45bf-b83e-e214f85514e4",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a",
	"427ca369-35ec-4853-9c52-4d5e79cc7d93",
	2,
	1,
	'display line: 2');
INSERT INTO ACT_BRG
	VALUES ("827d547b-2c17-45bf-b83e-e214f85514e4",
	"20118c86-a3a0-4c4b-80f0-5ef1a2122e2f",
	2,
	6,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES ("427ca369-35ec-4853-9c52-4d5e79cc7d93",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a",
	"ef254253-d844-4c71-98cd-f79bc39fba1c",
	3,
	1,
	'display line: 3');
INSERT INTO ACT_WHL
	VALUES ("427ca369-35ec-4853-9c52-4d5e79cc7d93",
	"87d002e3-9bb0-4c48-aa5c-64858d6f923d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO ACT_SMT
	VALUES ("ef254253-d844-4c71-98cd-f79bc39fba1c",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a",
	"00000000-0000-0000-0000-000000000000",
	25,
	1,
	'display line: 25');
INSERT INTO ACT_BRG
	VALUES ("ef254253-d844-4c71-98cd-f79bc39fba1c",
	"20118c86-a3a0-4c4b-80f0-5ef1a2122e2f",
	25,
	6,
	25,
	1);
INSERT INTO V_VAL
	VALUES ("bc5c7718-8811-41fd-91de-0d6c49b7131b",
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a");
INSERT INTO V_TVL
	VALUES ("bc5c7718-8811-41fd-91de-0d6c49b7131b",
	"8eeaa680-cea1-474b-b4c1-69977d17d2e8");
INSERT INTO V_VAL
	VALUES ("aab906a8-0926-4e32-82e9-1f59ffeae242",
	0,
	0,
	1,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a");
INSERT INTO V_LIN
	VALUES ("aab906a8-0926-4e32-82e9-1f59ffeae242",
	'1');
INSERT INTO V_VAL
	VALUES ("d4dacb5a-e09f-4540-8942-9546f2c75a1f",
	0,
	0,
	2,
	23,
	46,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a");
INSERT INTO V_LST
	VALUES ("d4dacb5a-e09f-4540-8942-9546f2c75a1f",
	'\n|-+-+-+-+-+-+-+-+-|\n');
INSERT INTO V_PAR
	VALUES ("d4dacb5a-e09f-4540-8942-9546f2c75a1f",
	"827d547b-2c17-45bf-b83e-e214f85514e4",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	2,
	15);
INSERT INTO V_VAL
	VALUES ("07cb5fca-74bb-4f26-8a21-8a4f18947439",
	0,
	0,
	3,
	9,
	9,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a");
INSERT INTO V_TVL
	VALUES ("07cb5fca-74bb-4f26-8a21-8a4f18947439",
	"8eeaa680-cea1-474b-b4c1-69977d17d2e8");
INSERT INTO V_VAL
	VALUES ("87d002e3-9bb0-4c48-aa5c-64858d6f923d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a");
INSERT INTO V_BIN
	VALUES ("87d002e3-9bb0-4c48-aa5c-64858d6f923d",
	"57bdc1c8-e68c-4523-a95b-ca3bce58eea8",
	"07cb5fca-74bb-4f26-8a21-8a4f18947439",
	'<=');
INSERT INTO V_VAL
	VALUES ("57bdc1c8-e68c-4523-a95b-ca3bce58eea8",
	0,
	0,
	3,
	14,
	14,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a");
INSERT INTO V_LIN
	VALUES ("57bdc1c8-e68c-4523-a95b-ca3bce58eea8",
	'9');
INSERT INTO V_VAL
	VALUES ("72c18ca8-5ab7-4321-b145-2d1084d83bd5",
	0,
	0,
	25,
	23,
	46,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a");
INSERT INTO V_LST
	VALUES ("72c18ca8-5ab7-4321-b145-2d1084d83bd5",
	'\n|-+-+-+-+-+-+-+-+-|\n');
INSERT INTO V_PAR
	VALUES ("72c18ca8-5ab7-4321-b145-2d1084d83bd5",
	"ef254253-d844-4c71-98cd-f79bc39fba1c",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	25,
	15);
INSERT INTO V_VAR
	VALUES ("8eeaa680-cea1-474b-b4c1-69977d17d2e8",
	"1f911ae7-7a81-411b-8601-3abb75e39a7a",
	'i',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("8eeaa680-cea1-474b-b4c1-69977d17d2e8",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("0daa37e2-b8ad-4dc7-b6f5-3ddd750938d1",
	1,
	1,
	1,
	"8eeaa680-cea1-474b-b4c1-69977d17d2e8");
INSERT INTO V_LOC
	VALUES ("81a24aa1-c48b-45fa-809e-f1af476add2a",
	3,
	9,
	9,
	"8eeaa680-cea1-474b-b4c1-69977d17d2e8");
INSERT INTO V_LOC
	VALUES ("e863a20f-7459-45cd-a89d-28c493f4f110",
	11,
	40,
	40,
	"8eeaa680-cea1-474b-b4c1-69977d17d2e8");
INSERT INTO V_LOC
	VALUES ("d5b35551-df9e-4b4e-ac7e-31a0deecfcfc",
	23,
	3,
	3,
	"8eeaa680-cea1-474b-b4c1-69977d17d2e8");
INSERT INTO V_LOC
	VALUES ("3fd673d7-8f4c-4f56-85cf-7178594df588",
	23,
	7,
	7,
	"8eeaa680-cea1-474b-b4c1-69977d17d2e8");
INSERT INTO ACT_BLK
	VALUES ("9706e2c7-6d93-400e-89c2-a8a11c84835d",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	23,
	3,
	22,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"67f4e561-9c59-42b1-bc8f-e840462afdf5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9d28c65e-c8fe-4452-ae5a-f210b73dd135",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d",
	"caac4fd0-8785-4c46-bac0-9fa00a3e102b",
	4,
	3,
	'display line: 4');
INSERT INTO ACT_AI
	VALUES ("9d28c65e-c8fe-4452-ae5a-f210b73dd135",
	"f6c20b4e-a1de-403e-9a5d-f7075b9e2ad1",
	"796b9d13-3758-4319-8f58-539dd90fadcc",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("caac4fd0-8785-4c46-bac0-9fa00a3e102b",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d",
	"eb698ac4-9235-4255-a768-684e94941c3a",
	8,
	3,
	'display line: 8');
INSERT INTO ACT_AI
	VALUES ("caac4fd0-8785-4c46-bac0-9fa00a3e102b",
	"db00eeef-5c6f-4cff-b59a-c92af0b4065f",
	"883e40ec-ea3c-470c-89ef-7c87a39666ef",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("eb698ac4-9235-4255-a768-684e94941c3a",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d",
	"253386d1-2542-4a39-9956-78658b3d3137",
	9,
	3,
	'display line: 9');
INSERT INTO ACT_WHL
	VALUES ("eb698ac4-9235-4255-a768-684e94941c3a",
	"82d059d8-bd0c-4852-987e-3094fc77296e",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO ACT_SMT
	VALUES ("253386d1-2542-4a39-9956-78658b3d3137",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d",
	"0fd55a0f-fd9d-4c7f-b9b9-26976d77607b",
	22,
	3,
	'display line: 22');
INSERT INTO ACT_BRG
	VALUES ("253386d1-2542-4a39-9956-78658b3d3137",
	"6d236d53-aad5-4092-8ead-4374100f0ef7",
	22,
	8,
	22,
	3);
INSERT INTO ACT_SMT
	VALUES ("0fd55a0f-fd9d-4c7f-b9b9-26976d77607b",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d",
	"00000000-0000-0000-0000-000000000000",
	23,
	3,
	'display line: 23');
INSERT INTO ACT_AI
	VALUES ("0fd55a0f-fd9d-4c7f-b9b9-26976d77607b",
	"f9d75124-078d-4ecc-826e-ca819933ba57",
	"80920c68-f88f-448c-95f4-844af9926929",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("796b9d13-3758-4319-8f58-539dd90fadcc",
	1,
	1,
	4,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_TVL
	VALUES ("796b9d13-3758-4319-8f58-539dd90fadcc",
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_VAL
	VALUES ("f6c20b4e-a1de-403e-9a5d-f7075b9e2ad1",
	0,
	0,
	4,
	7,
	7,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_LIN
	VALUES ("f6c20b4e-a1de-403e-9a5d-f7075b9e2ad1",
	'1');
INSERT INTO V_VAL
	VALUES ("90e5e6af-9d1e-49ea-865a-afdd38986590",
	0,
	0,
	8,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_LIN
	VALUES ("90e5e6af-9d1e-49ea-865a-afdd38986590",
	'8');
INSERT INTO V_VAL
	VALUES ("e9649b05-9a26-4d7b-8d45-a3c64cf0782c",
	1,
	1,
	8,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_TVL
	VALUES ("e9649b05-9a26-4d7b-8d45-a3c64cf0782c",
	"d66f597e-6a57-4130-b1a5-9c48b17b6e16");
INSERT INTO V_VAL
	VALUES ("883e40ec-ea3c-470c-89ef-7c87a39666ef",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_AER
	VALUES ("883e40ec-ea3c-470c-89ef-7c87a39666ef",
	"e9649b05-9a26-4d7b-8d45-a3c64cf0782c",
	"90e5e6af-9d1e-49ea-865a-afdd38986590");
INSERT INTO V_VAL
	VALUES ("db00eeef-5c6f-4cff-b59a-c92af0b4065f",
	0,
	0,
	8,
	10,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_LIN
	VALUES ("db00eeef-5c6f-4cff-b59a-c92af0b4065f",
	'0');
INSERT INTO V_VAL
	VALUES ("925c4b2d-c4e2-491d-a3b5-03f683819e91",
	0,
	0,
	9,
	11,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_TVL
	VALUES ("925c4b2d-c4e2-491d-a3b5-03f683819e91",
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_VAL
	VALUES ("82d059d8-bd0c-4852-987e-3094fc77296e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_BIN
	VALUES ("82d059d8-bd0c-4852-987e-3094fc77296e",
	"033b048b-03c2-4cbf-9108-0a6cdfeff05f",
	"925c4b2d-c4e2-491d-a3b5-03f683819e91",
	'<=');
INSERT INTO V_VAL
	VALUES ("033b048b-03c2-4cbf-9108-0a6cdfeff05f",
	0,
	0,
	9,
	16,
	16,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_LIN
	VALUES ("033b048b-03c2-4cbf-9108-0a6cdfeff05f",
	'9');
INSERT INTO V_VAL
	VALUES ("dd997f5e-0f16-4575-b046-b66a395d94fb",
	0,
	0,
	22,
	28,
	28,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_TVL
	VALUES ("dd997f5e-0f16-4575-b046-b66a395d94fb",
	"d66f597e-6a57-4130-b1a5-9c48b17b6e16");
INSERT INTO V_PAR
	VALUES ("dd997f5e-0f16-4575-b046-b66a395d94fb",
	"253386d1-2542-4a39-9956-78658b3d3137",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	22,
	20);
INSERT INTO V_VAL
	VALUES ("80920c68-f88f-448c-95f4-844af9926929",
	1,
	0,
	23,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_TVL
	VALUES ("80920c68-f88f-448c-95f4-844af9926929",
	"8eeaa680-cea1-474b-b4c1-69977d17d2e8");
INSERT INTO V_VAL
	VALUES ("1c27b15f-2892-4e29-aa2d-6ac3d9055f62",
	0,
	0,
	23,
	7,
	7,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_TVL
	VALUES ("1c27b15f-2892-4e29-aa2d-6ac3d9055f62",
	"8eeaa680-cea1-474b-b4c1-69977d17d2e8");
INSERT INTO V_VAL
	VALUES ("f9d75124-078d-4ecc-826e-ca819933ba57",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_BIN
	VALUES ("f9d75124-078d-4ecc-826e-ca819933ba57",
	"6393efb7-2698-4dcf-afaf-d5b8fa84fee8",
	"1c27b15f-2892-4e29-aa2d-6ac3d9055f62",
	'+');
INSERT INTO V_VAL
	VALUES ("6393efb7-2698-4dcf-afaf-d5b8fa84fee8",
	0,
	0,
	23,
	11,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d");
INSERT INTO V_LIN
	VALUES ("6393efb7-2698-4dcf-afaf-d5b8fa84fee8",
	'1');
INSERT INTO V_VAR
	VALUES ("86619ebd-091e-442f-8a93-88ab0e0c7720",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d",
	'j',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("86619ebd-091e-442f-8a93-88ab0e0c7720",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("235e0395-d633-421c-bb84-8d97cafcb1cd",
	4,
	3,
	3,
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_LOC
	VALUES ("586dffc3-481f-4b1c-bee3-3ebd251b028c",
	9,
	11,
	11,
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_LOC
	VALUES ("a3e9391c-72bc-4879-b616-bf58038a024f",
	11,
	76,
	76,
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_LOC
	VALUES ("8a5717ed-4442-4fb5-8158-e51cc27eeddf",
	13,
	7,
	7,
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_LOC
	VALUES ("77162d5c-26c7-41e8-a014-cce4e3e4ad6e",
	20,
	5,
	5,
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_LOC
	VALUES ("6deb78e3-80bc-4382-91f2-111b03e512f3",
	20,
	9,
	9,
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_VAR
	VALUES ("d66f597e-6a57-4130-b1a5-9c48b17b6e16",
	"9706e2c7-6d93-400e-89c2-a8a11c84835d",
	'b',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("d66f597e-6a57-4130-b1a5-9c48b17b6e16",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("3a6bf690-01c6-4624-89f2-93bc9c926de3",
	8,
	3,
	3,
	"d66f597e-6a57-4130-b1a5-9c48b17b6e16");
INSERT INTO V_LOC
	VALUES ("c5f846cb-7035-4eb8-84c8-3c1b170ffc28",
	13,
	5,
	5,
	"d66f597e-6a57-4130-b1a5-9c48b17b6e16");
INSERT INTO V_LOC
	VALUES ("f905b016-9e2a-4c5a-a3d7-3f1e2d3ac67a",
	22,
	28,
	28,
	"d66f597e-6a57-4130-b1a5-9c48b17b6e16");
INSERT INTO S_DIM
	VALUES (9,
	0,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"2163bd26-6fef-486c-9a3b-dceb2d3df9a8",
	"d66f597e-6a57-4130-b1a5-9c48b17b6e16");
INSERT INTO ACT_BLK
	VALUES ("b66981a4-32c6-4941-8c5b-f1f03e86e10c",
	1,
	0,
	1,
	'',
	'',
	'',
	20,
	5,
	10,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"67f4e561-9c59-42b1-bc8f-e840462afdf5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("bffc494c-ebb3-4156-b3e2-b3de2737feac",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c",
	"c32beafc-fbf4-4a8a-8369-3154789a2f31",
	10,
	5,
	'display line: 10');
INSERT INTO ACT_FIW
	VALUES ("bffc494c-ebb3-4156-b3e2-b3de2737feac",
	"d5098fb2-bcdc-4b60-90f4-f4556335ac08",
	1,
	'any',
	"a1cc0809-dde9-4959-bde6-0c37e8ba77bc",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	10,
	39);
INSERT INTO ACT_SMT
	VALUES ("c32beafc-fbf4-4a8a-8369-3154789a2f31",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c",
	"de7125c3-c0e3-4dd1-a1d2-3dabf2af9976",
	12,
	5,
	'display line: 12');
INSERT INTO ACT_AI
	VALUES ("c32beafc-fbf4-4a8a-8369-3154789a2f31",
	"6c84cf32-7bd6-4add-9ed5-05f5cc192760",
	"58737f22-61af-463f-a179-a81bb4c981d2",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("de7125c3-c0e3-4dd1-a1d2-3dabf2af9976",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c",
	"70032aab-8c0b-4334-bd28-acaf4acbf64c",
	13,
	5,
	'display line: 13');
INSERT INTO ACT_AI
	VALUES ("de7125c3-c0e3-4dd1-a1d2-3dabf2af9976",
	"6ed41154-5ff6-475c-a5e5-036f85f283ef",
	"5ec1eb7d-f03f-4eab-8fd8-995f39b22ab8",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("70032aab-8c0b-4334-bd28-acaf4acbf64c",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c",
	"00000000-0000-0000-0000-000000000000",
	20,
	5,
	'display line: 20');
INSERT INTO ACT_AI
	VALUES ("70032aab-8c0b-4334-bd28-acaf4acbf64c",
	"c1e1632d-5a5c-482e-b077-f58ed43457be",
	"7ce8f032-a270-4a90-854f-b7a1df21969c",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("598e30e6-4681-4b12-8ea0-49d711bf9f6b",
	0,
	0,
	11,
	17,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_SLR
	VALUES ("598e30e6-4681-4b12-8ea0-49d711bf9f6b",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("6827aa9c-bb97-485e-9541-5300fe328f95",
	0,
	0,
	11,
	26,
	35,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_AVL
	VALUES ("6827aa9c-bb97-485e-9541-5300fe328f95",
	"598e30e6-4681-4b12-8ea0-49d711bf9f6b",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("3f34de4b-19fe-4d29-b980-e764ef491efe",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_BIN
	VALUES ("3f34de4b-19fe-4d29-b980-e764ef491efe",
	"7a411739-b5d9-4158-8eab-1c05ad24248e",
	"6827aa9c-bb97-485e-9541-5300fe328f95",
	'==');
INSERT INTO V_VAL
	VALUES ("7a411739-b5d9-4158-8eab-1c05ad24248e",
	0,
	0,
	11,
	40,
	40,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_TVL
	VALUES ("7a411739-b5d9-4158-8eab-1c05ad24248e",
	"8eeaa680-cea1-474b-b4c1-69977d17d2e8");
INSERT INTO V_VAL
	VALUES ("eedc8106-9196-45a0-8ff6-711b51df2418",
	0,
	0,
	11,
	50,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_SLR
	VALUES ("eedc8106-9196-45a0-8ff6-711b51df2418",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("c3528954-da2e-40f9-ad72-66388a55fb11",
	0,
	0,
	11,
	59,
	71,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_AVL
	VALUES ("c3528954-da2e-40f9-ad72-66388a55fb11",
	"eedc8106-9196-45a0-8ff6-711b51df2418",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("a2ea0558-93c1-4cea-9a70-c58205ca7632",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_BIN
	VALUES ("a2ea0558-93c1-4cea-9a70-c58205ca7632",
	"0255f909-6b87-4d57-ab44-e441e9acb64f",
	"c3528954-da2e-40f9-ad72-66388a55fb11",
	'==');
INSERT INTO V_VAL
	VALUES ("0255f909-6b87-4d57-ab44-e441e9acb64f",
	0,
	0,
	11,
	76,
	76,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_TVL
	VALUES ("0255f909-6b87-4d57-ab44-e441e9acb64f",
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_VAL
	VALUES ("a1cc0809-dde9-4959-bde6-0c37e8ba77bc",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_BIN
	VALUES ("a1cc0809-dde9-4959-bde6-0c37e8ba77bc",
	"a2ea0558-93c1-4cea-9a70-c58205ca7632",
	"3f34de4b-19fe-4d29-b980-e764ef491efe",
	'and');
INSERT INTO V_VAL
	VALUES ("58737f22-61af-463f-a179-a81bb4c981d2",
	1,
	1,
	12,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_TVL
	VALUES ("58737f22-61af-463f-a179-a81bb4c981d2",
	"6dfb5a6b-2062-4323-8a83-b4bde79b5ab5");
INSERT INTO V_VAL
	VALUES ("d4a7a27f-6acf-4574-af59-b5437db00566",
	0,
	0,
	12,
	9,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_IRF
	VALUES ("d4a7a27f-6acf-4574-af59-b5437db00566",
	"d5098fb2-bcdc-4b60-90f4-f4556335ac08");
INSERT INTO V_VAL
	VALUES ("6c84cf32-7bd6-4add-9ed5-05f5cc192760",
	0,
	0,
	12,
	14,
	25,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_AVL
	VALUES ("6c84cf32-7bd6-4add-9ed5-05f5cc192760",
	"d4a7a27f-6acf-4574-af59-b5437db00566",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"009f5557-7ee7-4e44-9444-4d92eb448359");
INSERT INTO V_VAL
	VALUES ("3bf52f35-f1fe-4acf-866b-db1f5fc15414",
	1,
	0,
	13,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_TVL
	VALUES ("3bf52f35-f1fe-4acf-866b-db1f5fc15414",
	"d66f597e-6a57-4130-b1a5-9c48b17b6e16");
INSERT INTO V_VAL
	VALUES ("c1910ef2-6790-485e-b7f5-7bdffa942154",
	0,
	0,
	13,
	7,
	7,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_TVL
	VALUES ("c1910ef2-6790-485e-b7f5-7bdffa942154",
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_VAL
	VALUES ("c30c2878-6173-4a3a-8f47-6da006ec7abd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_BIN
	VALUES ("c30c2878-6173-4a3a-8f47-6da006ec7abd",
	"aaba912b-89f1-4a3e-a48f-d741ae2a626d",
	"c1910ef2-6790-485e-b7f5-7bdffa942154",
	'-');
INSERT INTO V_VAL
	VALUES ("aaba912b-89f1-4a3e-a48f-d741ae2a626d",
	0,
	0,
	13,
	9,
	9,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_LIN
	VALUES ("aaba912b-89f1-4a3e-a48f-d741ae2a626d",
	'1');
INSERT INTO V_VAL
	VALUES ("5ec1eb7d-f03f-4eab-8fd8-995f39b22ab8",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_AER
	VALUES ("5ec1eb7d-f03f-4eab-8fd8-995f39b22ab8",
	"3bf52f35-f1fe-4acf-866b-db1f5fc15414",
	"c30c2878-6173-4a3a-8f47-6da006ec7abd");
INSERT INTO V_VAL
	VALUES ("6ed41154-5ff6-475c-a5e5-036f85f283ef",
	0,
	0,
	13,
	14,
	14,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_TVL
	VALUES ("6ed41154-5ff6-475c-a5e5-036f85f283ef",
	"6dfb5a6b-2062-4323-8a83-b4bde79b5ab5");
INSERT INTO V_VAL
	VALUES ("7ce8f032-a270-4a90-854f-b7a1df21969c",
	1,
	0,
	20,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_TVL
	VALUES ("7ce8f032-a270-4a90-854f-b7a1df21969c",
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_VAL
	VALUES ("10a9e701-4754-42c3-9eaf-2b30d757bd25",
	0,
	0,
	20,
	9,
	9,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_TVL
	VALUES ("10a9e701-4754-42c3-9eaf-2b30d757bd25",
	"86619ebd-091e-442f-8a93-88ab0e0c7720");
INSERT INTO V_VAL
	VALUES ("c1e1632d-5a5c-482e-b077-f58ed43457be",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_BIN
	VALUES ("c1e1632d-5a5c-482e-b077-f58ed43457be",
	"af92c92a-ea78-4cdf-a656-3838da8f8947",
	"10a9e701-4754-42c3-9eaf-2b30d757bd25",
	'+');
INSERT INTO V_VAL
	VALUES ("af92c92a-ea78-4cdf-a656-3838da8f8947",
	0,
	0,
	20,
	13,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c");
INSERT INTO V_LIN
	VALUES ("af92c92a-ea78-4cdf-a656-3838da8f8947",
	'1');
INSERT INTO V_VAR
	VALUES ("d5098fb2-bcdc-4b60-90f4-f4556335ac08",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c",
	'cell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("d5098fb2-bcdc-4b60-90f4-f4556335ac08",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("84a00873-3ce7-4958-9167-21a9249bb4e5",
	10,
	16,
	19,
	"d5098fb2-bcdc-4b60-90f4-f4556335ac08");
INSERT INTO V_LOC
	VALUES ("f92721b4-df4f-4279-ab5d-75d8efd14baa",
	12,
	9,
	12,
	"d5098fb2-bcdc-4b60-90f4-f4556335ac08");
INSERT INTO V_VAR
	VALUES ("6dfb5a6b-2062-4323-8a83-b4bde79b5ab5",
	"b66981a4-32c6-4941-8c5b-f1f03e86e10c",
	'a',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("6dfb5a6b-2062-4323-8a83-b4bde79b5ab5",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("497619cb-7e49-496e-92bb-d8ce8c8d68a8",
	12,
	5,
	5,
	"6dfb5a6b-2062-4323-8a83-b4bde79b5ab5");
INSERT INTO V_LOC
	VALUES ("e56f8c91-0bfc-48c2-9c64-7372ca9db2dc",
	13,
	14,
	14,
	"6dfb5a6b-2062-4323-8a83-b4bde79b5ab5");
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"836e2a9b-86e2-4c61-8e39-fa204d8644dd");
INSERT INTO S_SYNC
	VALUES ("836e2a9b-86e2-4c61-8e39-fa204d8644dd",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'solve',
	'',
	'score = CELL::score();
::display();

SEQUENCE::solve();

score = CELL::score();
if ( 81 == score )
  LOG::LogSuccess( message:"solved the puzzle" );
else
  LOG::LogFailure( message:"failed to solved the puzzle" );
end if;
::display();',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("94a9f46e-75bb-4abf-b346-652c65c573c6",
	"836e2a9b-86e2-4c61-8e39-fa204d8644dd");
INSERT INTO ACT_ACT
	VALUES ("94a9f46e-75bb-4abf-b346-652c65c573c6",
	'function',
	0,
	"a779bc2e-93d8-42d4-8dda-b32507ac778b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'solve',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a779bc2e-93d8-42d4-8dda-b32507ac778b",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	12,
	1,
	6,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"94a9f46e-75bb-4abf-b346-652c65c573c6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("11cb3436-acc6-458f-886d-a10ad18275c5",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b",
	"02f42204-ca8d-492f-b050-caed45f31587",
	1,
	1,
	'solve line: 1');
INSERT INTO ACT_AI
	VALUES ("11cb3436-acc6-458f-886d-a10ad18275c5",
	"f7e5f3cd-9c8a-4d16-a2ec-b6c3812e9b50",
	"a7e5756b-cd63-4db8-bc80-da54d1e593e2",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("02f42204-ca8d-492f-b050-caed45f31587",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b",
	"18b0a868-0e41-4fbe-8375-5206ada39c10",
	2,
	1,
	'solve line: 2');
INSERT INTO ACT_FNC
	VALUES ("02f42204-ca8d-492f-b050-caed45f31587",
	"ea7999d4-ad63-4a57-abe3-4a8224d30de0",
	2,
	3);
INSERT INTO ACT_SMT
	VALUES ("18b0a868-0e41-4fbe-8375-5206ada39c10",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b",
	"25bf1d22-0057-45b8-bdb4-509f44c80929",
	4,
	1,
	'solve line: 4');
INSERT INTO ACT_TFM
	VALUES ("18b0a868-0e41-4fbe-8375-5206ada39c10",
	"a76fd039-37b9-41cc-9e9a-ea4943cde168",
	"00000000-0000-0000-0000-000000000000",
	4,
	11,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES ("25bf1d22-0057-45b8-bdb4-509f44c80929",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b",
	"59aeac55-839a-4358-bbfb-a00f5fc778c3",
	6,
	1,
	'solve line: 6');
INSERT INTO ACT_AI
	VALUES ("25bf1d22-0057-45b8-bdb4-509f44c80929",
	"bc1b7376-0823-4119-8619-5676b840be24",
	"ef59a9cf-7232-44ca-9547-b432a48d13d8",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("59aeac55-839a-4358-bbfb-a00f5fc778c3",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b",
	"bd781b4b-c2d0-4752-8b81-8acc72e7a16b",
	7,
	1,
	'solve line: 7');
INSERT INTO ACT_IF
	VALUES ("59aeac55-839a-4358-bbfb-a00f5fc778c3",
	"a6f943f6-d5ac-4857-ba94-ae53754cf918",
	"b26ac67b-a8fc-4eba-a22e-89fc5ca32230",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("52b14283-eb6b-4845-844a-1f9f94533735",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b",
	"00000000-0000-0000-0000-000000000000",
	9,
	1,
	'solve line: 9');
INSERT INTO ACT_E
	VALUES ("52b14283-eb6b-4845-844a-1f9f94533735",
	"e7de57aa-a71e-43ee-a093-15be36d36d1e",
	"59aeac55-839a-4358-bbfb-a00f5fc778c3");
INSERT INTO ACT_SMT
	VALUES ("bd781b4b-c2d0-4752-8b81-8acc72e7a16b",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b",
	"00000000-0000-0000-0000-000000000000",
	12,
	1,
	'solve line: 12');
INSERT INTO ACT_FNC
	VALUES ("bd781b4b-c2d0-4752-8b81-8acc72e7a16b",
	"ea7999d4-ad63-4a57-abe3-4a8224d30de0",
	12,
	3);
INSERT INTO V_VAL
	VALUES ("a7e5756b-cd63-4db8-bc80-da54d1e593e2",
	1,
	1,
	1,
	1,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b");
INSERT INTO V_TVL
	VALUES ("a7e5756b-cd63-4db8-bc80-da54d1e593e2",
	"8469f428-8d0c-4785-a925-0bde0cd2b2b1");
INSERT INTO V_VAL
	VALUES ("f7e5f3cd-9c8a-4d16-a2ec-b6c3812e9b50",
	0,
	0,
	1,
	15,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b");
INSERT INTO V_TRV
	VALUES ("f7e5f3cd-9c8a-4d16-a2ec-b6c3812e9b50",
	"e7682414-c9d4-490e-84ef-68b46fb9a8f1",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	9);
INSERT INTO V_VAL
	VALUES ("ef59a9cf-7232-44ca-9547-b432a48d13d8",
	1,
	0,
	6,
	1,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b");
INSERT INTO V_TVL
	VALUES ("ef59a9cf-7232-44ca-9547-b432a48d13d8",
	"8469f428-8d0c-4785-a925-0bde0cd2b2b1");
INSERT INTO V_VAL
	VALUES ("bc1b7376-0823-4119-8619-5676b840be24",
	0,
	0,
	6,
	15,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b");
INSERT INTO V_TRV
	VALUES ("bc1b7376-0823-4119-8619-5676b840be24",
	"e7682414-c9d4-490e-84ef-68b46fb9a8f1",
	"00000000-0000-0000-0000-000000000000",
	1,
	6,
	9);
INSERT INTO V_VAL
	VALUES ("b7be09f6-08e8-4a85-a975-7e5c14fbc56c",
	0,
	0,
	7,
	6,
	7,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b");
INSERT INTO V_LIN
	VALUES ("b7be09f6-08e8-4a85-a975-7e5c14fbc56c",
	'81');
INSERT INTO V_VAL
	VALUES ("b26ac67b-a8fc-4eba-a22e-89fc5ca32230",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b");
INSERT INTO V_BIN
	VALUES ("b26ac67b-a8fc-4eba-a22e-89fc5ca32230",
	"0bab6493-68a7-4393-bad7-772246f3dc47",
	"b7be09f6-08e8-4a85-a975-7e5c14fbc56c",
	'==');
INSERT INTO V_VAL
	VALUES ("0bab6493-68a7-4393-bad7-772246f3dc47",
	0,
	0,
	7,
	12,
	16,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b");
INSERT INTO V_TVL
	VALUES ("0bab6493-68a7-4393-bad7-772246f3dc47",
	"8469f428-8d0c-4785-a925-0bde0cd2b2b1");
INSERT INTO V_VAR
	VALUES ("8469f428-8d0c-4785-a925-0bde0cd2b2b1",
	"a779bc2e-93d8-42d4-8dda-b32507ac778b",
	'score',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("8469f428-8d0c-4785-a925-0bde0cd2b2b1",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("6326174b-16b4-412c-b609-b9eff58c9333",
	1,
	1,
	5,
	"8469f428-8d0c-4785-a925-0bde0cd2b2b1");
INSERT INTO V_LOC
	VALUES ("c9cc235e-4576-4f2e-a0f7-cf3f9e91c2ac",
	6,
	1,
	5,
	"8469f428-8d0c-4785-a925-0bde0cd2b2b1");
INSERT INTO V_LOC
	VALUES ("d856cd21-be04-4744-a5a8-756945db501f",
	7,
	12,
	16,
	"8469f428-8d0c-4785-a925-0bde0cd2b2b1");
INSERT INTO ACT_BLK
	VALUES ("a6f943f6-d5ac-4857-ba94-ae53754cf918",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	8,
	3,
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"94a9f46e-75bb-4abf-b346-652c65c573c6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e6b22b95-ee2f-4da6-b39e-b5eec594ed82",
	"a6f943f6-d5ac-4857-ba94-ae53754cf918",
	"00000000-0000-0000-0000-000000000000",
	8,
	3,
	'solve line: 8');
INSERT INTO ACT_BRG
	VALUES ("e6b22b95-ee2f-4da6-b39e-b5eec594ed82",
	"c1b48c1e-b947-4620-bd45-5dfde8d96e53",
	8,
	8,
	8,
	3);
INSERT INTO V_VAL
	VALUES ("5e2ea465-7ed7-4c53-b31e-8ea062e626d3",
	0,
	0,
	8,
	28,
	45,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"a6f943f6-d5ac-4857-ba94-ae53754cf918");
INSERT INTO V_LST
	VALUES ("5e2ea465-7ed7-4c53-b31e-8ea062e626d3",
	'solved the puzzle');
INSERT INTO V_PAR
	VALUES ("5e2ea465-7ed7-4c53-b31e-8ea062e626d3",
	"e6b22b95-ee2f-4da6-b39e-b5eec594ed82",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	8,
	20);
INSERT INTO ACT_BLK
	VALUES ("e7de57aa-a71e-43ee-a093-15be36d36d1e",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	10,
	3,
	10,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"94a9f46e-75bb-4abf-b346-652c65c573c6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c6d87a5b-2a1b-4048-97b5-d8151d0ab0c4",
	"e7de57aa-a71e-43ee-a093-15be36d36d1e",
	"00000000-0000-0000-0000-000000000000",
	10,
	3,
	'solve line: 10');
INSERT INTO ACT_BRG
	VALUES ("c6d87a5b-2a1b-4048-97b5-d8151d0ab0c4",
	"ea25943b-c6c2-4423-922c-947a3cd960ad",
	10,
	8,
	10,
	3);
INSERT INTO V_VAL
	VALUES ("0b82ba56-a2bb-4dac-a3d1-bdba458eed79",
	0,
	0,
	10,
	28,
	55,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"e7de57aa-a71e-43ee-a093-15be36d36d1e");
INSERT INTO V_LST
	VALUES ("0b82ba56-a2bb-4dac-a3d1-bdba458eed79",
	'failed to solved the puzzle');
INSERT INTO V_PAR
	VALUES ("0b82ba56-a2bb-4dac-a3d1-bdba458eed79",
	"c6d87a5b-2a1b-4048-97b5-d8151d0ab0c4",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	10,
	20);
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"7927caa7-9d02-461c-a9c8-d57fc88efd9a");
INSERT INTO S_SYNC
	VALUES ("7927caa7-9d02-461c-a9c8-d57fc88efd9a",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'setz2_given',
	'',
	'
CELL::set_given( row:1, column:2, answer:6 );
CELL::set_given( row:1, column:4, answer:1 );
CELL::set_given( row:1, column:6, answer:4 );
CELL::set_given( row:1, column:8, answer:5 );

CELL::set_given( row:2, column:3, answer:8 );
CELL::set_given( row:2, column:4, answer:3 );
CELL::set_given( row:2, column:6, answer:5 );
CELL::set_given( row:2, column:7, answer:6 );

CELL::set_given( row:3, column:1, answer:2 );
CELL::set_given( row:3, column:9, answer:1 );

CELL::set_given( row:4, column:1, answer:8 );
CELL::set_given( row:4, column:4, answer:4 );
CELL::set_given( row:4, column:6, answer:7 );
CELL::set_given( row:4, column:9, answer:6 );

CELL::set_given( row:5, column:3, answer:6 );
CELL::set_given( row:5, column:7, answer:3 );

CELL::set_given( row:6, column:1, answer:7 );
CELL::set_given( row:6, column:4, answer:9 );
CELL::set_given( row:6, column:6, answer:1 );
CELL::set_given( row:6, column:9, answer:4 );

CELL::set_given( row:7, column:1, answer:5 );
CELL::set_given( row:7, column:9, answer:2 );

CELL::set_given( row:8, column:3, answer:7 );
CELL::set_given( row:8, column:4, answer:2 );
CELL::set_given( row:8, column:6, answer:6 );
CELL::set_given( row:8, column:7, answer:9 );

CELL::set_given( row:9, column:2, answer:4 );
CELL::set_given( row:9, column:4, answer:5 );
CELL::set_given( row:9, column:6, answer:8 );
CELL::set_given( row:9, column:8, answer:7 );

// This is extra.  Should not need this.
//CELL::set_given( row:8, column:1, answer:3 );
',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("163efb67-52fd-49d9-8215-7ea6c3db3648",
	"7927caa7-9d02-461c-a9c8-d57fc88efd9a");
INSERT INTO ACT_ACT
	VALUES ("163efb67-52fd-49d9-8215-7ea6c3db3648",
	'function',
	0,
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setz2_given',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("9eec6965-effd-443f-80be-757fec1efb9a",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	39,
	1,
	39,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"163efb67-52fd-49d9-8215-7ea6c3db3648",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f1592f17-179b-4a05-8122-8e9c3d9ff5ff",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"5830f0a2-c288-4a66-befe-2e28b0c697ad",
	2,
	1,
	'setz2_given line: 2');
INSERT INTO ACT_TFM
	VALUES ("f1592f17-179b-4a05-8122-8e9c3d9ff5ff",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	2,
	7,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES ("5830f0a2-c288-4a66-befe-2e28b0c697ad",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"e309c6ec-9104-40ad-a00b-2f0552c4bcff",
	3,
	1,
	'setz2_given line: 3');
INSERT INTO ACT_TFM
	VALUES ("5830f0a2-c288-4a66-befe-2e28b0c697ad",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES ("e309c6ec-9104-40ad-a00b-2f0552c4bcff",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"b891c4b1-4ba6-4361-9916-220745893b67",
	4,
	1,
	'setz2_given line: 4');
INSERT INTO ACT_TFM
	VALUES ("e309c6ec-9104-40ad-a00b-2f0552c4bcff",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES ("b891c4b1-4ba6-4361-9916-220745893b67",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"f7d57199-3f83-4d56-a373-9e1c1577622b",
	5,
	1,
	'setz2_given line: 5');
INSERT INTO ACT_TFM
	VALUES ("b891c4b1-4ba6-4361-9916-220745893b67",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	5,
	7,
	5,
	1);
INSERT INTO ACT_SMT
	VALUES ("f7d57199-3f83-4d56-a373-9e1c1577622b",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"9174ad37-6073-419c-b169-f13d60566634",
	7,
	1,
	'setz2_given line: 7');
INSERT INTO ACT_TFM
	VALUES ("f7d57199-3f83-4d56-a373-9e1c1577622b",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES ("9174ad37-6073-419c-b169-f13d60566634",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"55d44aaf-b84b-4f6d-9b66-1f9390aff822",
	8,
	1,
	'setz2_given line: 8');
INSERT INTO ACT_TFM
	VALUES ("9174ad37-6073-419c-b169-f13d60566634",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES ("55d44aaf-b84b-4f6d-9b66-1f9390aff822",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"fe0ed46d-5476-434e-95fb-d2ac3438de1a",
	9,
	1,
	'setz2_given line: 9');
INSERT INTO ACT_TFM
	VALUES ("55d44aaf-b84b-4f6d-9b66-1f9390aff822",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	9,
	7,
	9,
	1);
INSERT INTO ACT_SMT
	VALUES ("fe0ed46d-5476-434e-95fb-d2ac3438de1a",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"3f218e0a-bc84-4d77-9c16-0ed7e67b303f",
	10,
	1,
	'setz2_given line: 10');
INSERT INTO ACT_TFM
	VALUES ("fe0ed46d-5476-434e-95fb-d2ac3438de1a",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES ("3f218e0a-bc84-4d77-9c16-0ed7e67b303f",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"a7c387ae-aaa3-4ce7-861a-7b1c6f65b02f",
	12,
	1,
	'setz2_given line: 12');
INSERT INTO ACT_TFM
	VALUES ("3f218e0a-bc84-4d77-9c16-0ed7e67b303f",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES ("a7c387ae-aaa3-4ce7-861a-7b1c6f65b02f",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"2a1e287e-a774-4712-9b3c-b477b7aac032",
	13,
	1,
	'setz2_given line: 13');
INSERT INTO ACT_TFM
	VALUES ("a7c387ae-aaa3-4ce7-861a-7b1c6f65b02f",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	13,
	7,
	13,
	1);
INSERT INTO ACT_SMT
	VALUES ("2a1e287e-a774-4712-9b3c-b477b7aac032",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"1a20c8e5-d34c-4ad4-9126-2a78b6a2ced2",
	15,
	1,
	'setz2_given line: 15');
INSERT INTO ACT_TFM
	VALUES ("2a1e287e-a774-4712-9b3c-b477b7aac032",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES ("1a20c8e5-d34c-4ad4-9126-2a78b6a2ced2",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"a523ca9f-a81e-4ffc-af78-833712e26ec7",
	16,
	1,
	'setz2_given line: 16');
INSERT INTO ACT_TFM
	VALUES ("1a20c8e5-d34c-4ad4-9126-2a78b6a2ced2",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	16,
	1);
INSERT INTO ACT_SMT
	VALUES ("a523ca9f-a81e-4ffc-af78-833712e26ec7",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"6d4e252b-ce81-4687-96bf-8595bf598385",
	17,
	1,
	'setz2_given line: 17');
INSERT INTO ACT_TFM
	VALUES ("a523ca9f-a81e-4ffc-af78-833712e26ec7",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES ("6d4e252b-ce81-4687-96bf-8595bf598385",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"dde9861c-b1d3-48d1-93b9-f85d94a65c9e",
	18,
	1,
	'setz2_given line: 18');
INSERT INTO ACT_TFM
	VALUES ("6d4e252b-ce81-4687-96bf-8595bf598385",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	18,
	7,
	18,
	1);
INSERT INTO ACT_SMT
	VALUES ("dde9861c-b1d3-48d1-93b9-f85d94a65c9e",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"c00ca8c0-0f9c-4c4d-91e7-68588c642d62",
	20,
	1,
	'setz2_given line: 20');
INSERT INTO ACT_TFM
	VALUES ("dde9861c-b1d3-48d1-93b9-f85d94a65c9e",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	20,
	7,
	20,
	1);
INSERT INTO ACT_SMT
	VALUES ("c00ca8c0-0f9c-4c4d-91e7-68588c642d62",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"c244059f-1fb6-42ce-8103-b7e0eaaf5d18",
	21,
	1,
	'setz2_given line: 21');
INSERT INTO ACT_TFM
	VALUES ("c00ca8c0-0f9c-4c4d-91e7-68588c642d62",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	21,
	7,
	21,
	1);
INSERT INTO ACT_SMT
	VALUES ("c244059f-1fb6-42ce-8103-b7e0eaaf5d18",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"1595d3d9-e7fa-4872-83ca-775d92356f50",
	23,
	1,
	'setz2_given line: 23');
INSERT INTO ACT_TFM
	VALUES ("c244059f-1fb6-42ce-8103-b7e0eaaf5d18",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES ("1595d3d9-e7fa-4872-83ca-775d92356f50",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"e0da6ada-63f4-4185-a3a7-2d836f617f12",
	24,
	1,
	'setz2_given line: 24');
INSERT INTO ACT_TFM
	VALUES ("1595d3d9-e7fa-4872-83ca-775d92356f50",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES ("e0da6ada-63f4-4185-a3a7-2d836f617f12",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"671e6ae9-3b99-440e-9630-3b8b24f13b87",
	25,
	1,
	'setz2_given line: 25');
INSERT INTO ACT_TFM
	VALUES ("e0da6ada-63f4-4185-a3a7-2d836f617f12",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	25,
	7,
	25,
	1);
INSERT INTO ACT_SMT
	VALUES ("671e6ae9-3b99-440e-9630-3b8b24f13b87",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"53fcd69d-1d07-400e-b726-69290bdca9a2",
	26,
	1,
	'setz2_given line: 26');
INSERT INTO ACT_TFM
	VALUES ("671e6ae9-3b99-440e-9630-3b8b24f13b87",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	26,
	7,
	26,
	1);
INSERT INTO ACT_SMT
	VALUES ("53fcd69d-1d07-400e-b726-69290bdca9a2",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"6006c84d-7bd0-4931-8ed4-0d282cb1aa4d",
	28,
	1,
	'setz2_given line: 28');
INSERT INTO ACT_TFM
	VALUES ("53fcd69d-1d07-400e-b726-69290bdca9a2",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	28,
	7,
	28,
	1);
INSERT INTO ACT_SMT
	VALUES ("6006c84d-7bd0-4931-8ed4-0d282cb1aa4d",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"b8276c76-8c6e-49a2-a4e0-847d7b3623de",
	29,
	1,
	'setz2_given line: 29');
INSERT INTO ACT_TFM
	VALUES ("6006c84d-7bd0-4931-8ed4-0d282cb1aa4d",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	29,
	7,
	29,
	1);
INSERT INTO ACT_SMT
	VALUES ("b8276c76-8c6e-49a2-a4e0-847d7b3623de",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"f68c05df-f28f-49e1-9b0c-20aa7b947b8c",
	31,
	1,
	'setz2_given line: 31');
INSERT INTO ACT_TFM
	VALUES ("b8276c76-8c6e-49a2-a4e0-847d7b3623de",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES ("f68c05df-f28f-49e1-9b0c-20aa7b947b8c",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"6fccb77e-e00b-413f-9ed2-b31a888731a6",
	32,
	1,
	'setz2_given line: 32');
INSERT INTO ACT_TFM
	VALUES ("f68c05df-f28f-49e1-9b0c-20aa7b947b8c",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES ("6fccb77e-e00b-413f-9ed2-b31a888731a6",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"c01a2da0-1da6-430e-a443-444db4c2d1f6",
	33,
	1,
	'setz2_given line: 33');
INSERT INTO ACT_TFM
	VALUES ("6fccb77e-e00b-413f-9ed2-b31a888731a6",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES ("c01a2da0-1da6-430e-a443-444db4c2d1f6",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"d370d3be-8408-4c29-9b4a-cfb4e6b201a2",
	34,
	1,
	'setz2_given line: 34');
INSERT INTO ACT_TFM
	VALUES ("c01a2da0-1da6-430e-a443-444db4c2d1f6",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	34,
	7,
	34,
	1);
INSERT INTO ACT_SMT
	VALUES ("d370d3be-8408-4c29-9b4a-cfb4e6b201a2",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"002bb144-55ac-420a-a109-c1e8052242a9",
	36,
	1,
	'setz2_given line: 36');
INSERT INTO ACT_TFM
	VALUES ("d370d3be-8408-4c29-9b4a-cfb4e6b201a2",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES ("002bb144-55ac-420a-a109-c1e8052242a9",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"79de25ca-22da-4afc-8e23-a171496c24bc",
	37,
	1,
	'setz2_given line: 37');
INSERT INTO ACT_TFM
	VALUES ("002bb144-55ac-420a-a109-c1e8052242a9",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	37,
	7,
	37,
	1);
INSERT INTO ACT_SMT
	VALUES ("79de25ca-22da-4afc-8e23-a171496c24bc",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"4e6f9b31-8b94-4f2e-b1e7-073158cb7b94",
	38,
	1,
	'setz2_given line: 38');
INSERT INTO ACT_TFM
	VALUES ("79de25ca-22da-4afc-8e23-a171496c24bc",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	38,
	7,
	38,
	1);
INSERT INTO ACT_SMT
	VALUES ("4e6f9b31-8b94-4f2e-b1e7-073158cb7b94",
	"9eec6965-effd-443f-80be-757fec1efb9a",
	"00000000-0000-0000-0000-000000000000",
	39,
	1,
	'setz2_given line: 39');
INSERT INTO ACT_TFM
	VALUES ("4e6f9b31-8b94-4f2e-b1e7-073158cb7b94",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	39,
	7,
	39,
	1);
INSERT INTO V_VAL
	VALUES ("43ed22d2-b3ab-4c01-bc64-22b018489a25",
	0,
	0,
	2,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("43ed22d2-b3ab-4c01-bc64-22b018489a25",
	'1');
INSERT INTO V_PAR
	VALUES ("43ed22d2-b3ab-4c01-bc64-22b018489a25",
	"f1592f17-179b-4a05-8122-8e9c3d9ff5ff",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"541da540-83c0-4c23-8cce-5cc2caabf17b",
	2,
	18);
INSERT INTO V_VAL
	VALUES ("541da540-83c0-4c23-8cce-5cc2caabf17b",
	0,
	0,
	2,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("541da540-83c0-4c23-8cce-5cc2caabf17b",
	'2');
INSERT INTO V_PAR
	VALUES ("541da540-83c0-4c23-8cce-5cc2caabf17b",
	"f1592f17-179b-4a05-8122-8e9c3d9ff5ff",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"ddab7160-d6a4-458f-9d8b-6a220bcb4158",
	2,
	25);
INSERT INTO V_VAL
	VALUES ("ddab7160-d6a4-458f-9d8b-6a220bcb4158",
	0,
	0,
	2,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("ddab7160-d6a4-458f-9d8b-6a220bcb4158",
	'6');
INSERT INTO V_PAR
	VALUES ("ddab7160-d6a4-458f-9d8b-6a220bcb4158",
	"f1592f17-179b-4a05-8122-8e9c3d9ff5ff",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	2,
	35);
INSERT INTO V_VAL
	VALUES ("8c0e8960-1387-4166-9415-69a282d6a744",
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("8c0e8960-1387-4166-9415-69a282d6a744",
	'1');
INSERT INTO V_PAR
	VALUES ("8c0e8960-1387-4166-9415-69a282d6a744",
	"5830f0a2-c288-4a66-befe-2e28b0c697ad",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"8a516fd1-20e7-4f72-b99a-e124b4c65e85",
	3,
	18);
INSERT INTO V_VAL
	VALUES ("8a516fd1-20e7-4f72-b99a-e124b4c65e85",
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("8a516fd1-20e7-4f72-b99a-e124b4c65e85",
	'4');
INSERT INTO V_PAR
	VALUES ("8a516fd1-20e7-4f72-b99a-e124b4c65e85",
	"5830f0a2-c288-4a66-befe-2e28b0c697ad",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"e0100cd8-920d-4ebf-a701-425f957abfae",
	3,
	25);
INSERT INTO V_VAL
	VALUES ("e0100cd8-920d-4ebf-a701-425f957abfae",
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("e0100cd8-920d-4ebf-a701-425f957abfae",
	'1');
INSERT INTO V_PAR
	VALUES ("e0100cd8-920d-4ebf-a701-425f957abfae",
	"5830f0a2-c288-4a66-befe-2e28b0c697ad",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	3,
	35);
INSERT INTO V_VAL
	VALUES ("137e9d14-c93c-4c3b-b139-7d1838e016e2",
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("137e9d14-c93c-4c3b-b139-7d1838e016e2",
	'1');
INSERT INTO V_PAR
	VALUES ("137e9d14-c93c-4c3b-b139-7d1838e016e2",
	"e309c6ec-9104-40ad-a00b-2f0552c4bcff",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"a03d8c6d-c605-4c4c-a810-9b7d8a7fc637",
	4,
	18);
INSERT INTO V_VAL
	VALUES ("a03d8c6d-c605-4c4c-a810-9b7d8a7fc637",
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("a03d8c6d-c605-4c4c-a810-9b7d8a7fc637",
	'6');
INSERT INTO V_PAR
	VALUES ("a03d8c6d-c605-4c4c-a810-9b7d8a7fc637",
	"e309c6ec-9104-40ad-a00b-2f0552c4bcff",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"72146af2-c62e-47eb-b145-b6fe5a763d78",
	4,
	25);
INSERT INTO V_VAL
	VALUES ("72146af2-c62e-47eb-b145-b6fe5a763d78",
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("72146af2-c62e-47eb-b145-b6fe5a763d78",
	'4');
INSERT INTO V_PAR
	VALUES ("72146af2-c62e-47eb-b145-b6fe5a763d78",
	"e309c6ec-9104-40ad-a00b-2f0552c4bcff",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	4,
	35);
INSERT INTO V_VAL
	VALUES ("e1b7ba5c-6952-4972-aa2a-2fc4a41263e1",
	0,
	0,
	5,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("e1b7ba5c-6952-4972-aa2a-2fc4a41263e1",
	'1');
INSERT INTO V_PAR
	VALUES ("e1b7ba5c-6952-4972-aa2a-2fc4a41263e1",
	"b891c4b1-4ba6-4361-9916-220745893b67",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2564d601-9c96-4b6e-9201-36d6845b1964",
	5,
	18);
INSERT INTO V_VAL
	VALUES ("2564d601-9c96-4b6e-9201-36d6845b1964",
	0,
	0,
	5,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("2564d601-9c96-4b6e-9201-36d6845b1964",
	'8');
INSERT INTO V_PAR
	VALUES ("2564d601-9c96-4b6e-9201-36d6845b1964",
	"b891c4b1-4ba6-4361-9916-220745893b67",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"a9b8b38f-1582-4f99-a06e-653e1bb416d6",
	5,
	25);
INSERT INTO V_VAL
	VALUES ("a9b8b38f-1582-4f99-a06e-653e1bb416d6",
	0,
	0,
	5,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("a9b8b38f-1582-4f99-a06e-653e1bb416d6",
	'5');
INSERT INTO V_PAR
	VALUES ("a9b8b38f-1582-4f99-a06e-653e1bb416d6",
	"b891c4b1-4ba6-4361-9916-220745893b67",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	5,
	35);
INSERT INTO V_VAL
	VALUES ("f91f4ce2-f287-48ad-b22f-6db9b0f6ca36",
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("f91f4ce2-f287-48ad-b22f-6db9b0f6ca36",
	'2');
INSERT INTO V_PAR
	VALUES ("f91f4ce2-f287-48ad-b22f-6db9b0f6ca36",
	"f7d57199-3f83-4d56-a373-9e1c1577622b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"95d9d43f-0861-4e5d-9e2c-f9b732d65e47",
	7,
	18);
INSERT INTO V_VAL
	VALUES ("95d9d43f-0861-4e5d-9e2c-f9b732d65e47",
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("95d9d43f-0861-4e5d-9e2c-f9b732d65e47",
	'3');
INSERT INTO V_PAR
	VALUES ("95d9d43f-0861-4e5d-9e2c-f9b732d65e47",
	"f7d57199-3f83-4d56-a373-9e1c1577622b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"12cf4f67-89ac-46f6-a17c-1ba32c454538",
	7,
	25);
INSERT INTO V_VAL
	VALUES ("12cf4f67-89ac-46f6-a17c-1ba32c454538",
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("12cf4f67-89ac-46f6-a17c-1ba32c454538",
	'8');
INSERT INTO V_PAR
	VALUES ("12cf4f67-89ac-46f6-a17c-1ba32c454538",
	"f7d57199-3f83-4d56-a373-9e1c1577622b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	7,
	35);
INSERT INTO V_VAL
	VALUES ("f5897cfc-7520-4a77-8080-85eae3b443c3",
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("f5897cfc-7520-4a77-8080-85eae3b443c3",
	'2');
INSERT INTO V_PAR
	VALUES ("f5897cfc-7520-4a77-8080-85eae3b443c3",
	"9174ad37-6073-419c-b169-f13d60566634",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"a3562498-3732-4cbb-9e3d-6df6203088ee",
	8,
	18);
INSERT INTO V_VAL
	VALUES ("a3562498-3732-4cbb-9e3d-6df6203088ee",
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("a3562498-3732-4cbb-9e3d-6df6203088ee",
	'4');
INSERT INTO V_PAR
	VALUES ("a3562498-3732-4cbb-9e3d-6df6203088ee",
	"9174ad37-6073-419c-b169-f13d60566634",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"1b088e4d-a39d-4f62-af4c-cf949e69fc1c",
	8,
	25);
INSERT INTO V_VAL
	VALUES ("1b088e4d-a39d-4f62-af4c-cf949e69fc1c",
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("1b088e4d-a39d-4f62-af4c-cf949e69fc1c",
	'3');
INSERT INTO V_PAR
	VALUES ("1b088e4d-a39d-4f62-af4c-cf949e69fc1c",
	"9174ad37-6073-419c-b169-f13d60566634",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	8,
	35);
INSERT INTO V_VAL
	VALUES ("a6f7b1c2-fdab-4424-bbce-699d838d947c",
	0,
	0,
	9,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("a6f7b1c2-fdab-4424-bbce-699d838d947c",
	'2');
INSERT INTO V_PAR
	VALUES ("a6f7b1c2-fdab-4424-bbce-699d838d947c",
	"55d44aaf-b84b-4f6d-9b66-1f9390aff822",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7b673600-24ef-41f3-8c16-a5f70c218122",
	9,
	18);
INSERT INTO V_VAL
	VALUES ("7b673600-24ef-41f3-8c16-a5f70c218122",
	0,
	0,
	9,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("7b673600-24ef-41f3-8c16-a5f70c218122",
	'6');
INSERT INTO V_PAR
	VALUES ("7b673600-24ef-41f3-8c16-a5f70c218122",
	"55d44aaf-b84b-4f6d-9b66-1f9390aff822",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"58cb22ac-c474-4d18-8de3-ab4d47bbe8f4",
	9,
	25);
INSERT INTO V_VAL
	VALUES ("58cb22ac-c474-4d18-8de3-ab4d47bbe8f4",
	0,
	0,
	9,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("58cb22ac-c474-4d18-8de3-ab4d47bbe8f4",
	'5');
INSERT INTO V_PAR
	VALUES ("58cb22ac-c474-4d18-8de3-ab4d47bbe8f4",
	"55d44aaf-b84b-4f6d-9b66-1f9390aff822",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	9,
	35);
INSERT INTO V_VAL
	VALUES ("0b1dd0e0-953d-453b-9871-0a02b176e3d6",
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("0b1dd0e0-953d-453b-9871-0a02b176e3d6",
	'2');
INSERT INTO V_PAR
	VALUES ("0b1dd0e0-953d-453b-9871-0a02b176e3d6",
	"fe0ed46d-5476-434e-95fb-d2ac3438de1a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"20ecc7d4-5b4b-48af-baa4-5fd19fcf99b9",
	10,
	18);
INSERT INTO V_VAL
	VALUES ("20ecc7d4-5b4b-48af-baa4-5fd19fcf99b9",
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("20ecc7d4-5b4b-48af-baa4-5fd19fcf99b9",
	'7');
INSERT INTO V_PAR
	VALUES ("20ecc7d4-5b4b-48af-baa4-5fd19fcf99b9",
	"fe0ed46d-5476-434e-95fb-d2ac3438de1a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"fe5aa865-5a89-4e88-82df-5e38738610b6",
	10,
	25);
INSERT INTO V_VAL
	VALUES ("fe5aa865-5a89-4e88-82df-5e38738610b6",
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("fe5aa865-5a89-4e88-82df-5e38738610b6",
	'6');
INSERT INTO V_PAR
	VALUES ("fe5aa865-5a89-4e88-82df-5e38738610b6",
	"fe0ed46d-5476-434e-95fb-d2ac3438de1a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	10,
	35);
INSERT INTO V_VAL
	VALUES ("bfc096c6-2ab9-491c-adea-72b4d619e661",
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("bfc096c6-2ab9-491c-adea-72b4d619e661",
	'3');
INSERT INTO V_PAR
	VALUES ("bfc096c6-2ab9-491c-adea-72b4d619e661",
	"3f218e0a-bc84-4d77-9c16-0ed7e67b303f",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"81591bfc-09b8-4dcf-a4c2-f0af6f8e8210",
	12,
	18);
INSERT INTO V_VAL
	VALUES ("81591bfc-09b8-4dcf-a4c2-f0af6f8e8210",
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("81591bfc-09b8-4dcf-a4c2-f0af6f8e8210",
	'1');
INSERT INTO V_PAR
	VALUES ("81591bfc-09b8-4dcf-a4c2-f0af6f8e8210",
	"3f218e0a-bc84-4d77-9c16-0ed7e67b303f",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"edb3c505-63dc-4486-9d3c-07b967f2feb9",
	12,
	25);
INSERT INTO V_VAL
	VALUES ("edb3c505-63dc-4486-9d3c-07b967f2feb9",
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("edb3c505-63dc-4486-9d3c-07b967f2feb9",
	'2');
INSERT INTO V_PAR
	VALUES ("edb3c505-63dc-4486-9d3c-07b967f2feb9",
	"3f218e0a-bc84-4d77-9c16-0ed7e67b303f",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	12,
	35);
INSERT INTO V_VAL
	VALUES ("099bf1c4-07eb-4f74-ba4a-4f4312ff2748",
	0,
	0,
	13,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("099bf1c4-07eb-4f74-ba4a-4f4312ff2748",
	'3');
INSERT INTO V_PAR
	VALUES ("099bf1c4-07eb-4f74-ba4a-4f4312ff2748",
	"a7c387ae-aaa3-4ce7-861a-7b1c6f65b02f",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"aeb21287-4c1b-4add-a94b-d8b81500443a",
	13,
	18);
INSERT INTO V_VAL
	VALUES ("aeb21287-4c1b-4add-a94b-d8b81500443a",
	0,
	0,
	13,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("aeb21287-4c1b-4add-a94b-d8b81500443a",
	'9');
INSERT INTO V_PAR
	VALUES ("aeb21287-4c1b-4add-a94b-d8b81500443a",
	"a7c387ae-aaa3-4ce7-861a-7b1c6f65b02f",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"48b4b717-0531-4c7c-a718-795e8f67d678",
	13,
	25);
INSERT INTO V_VAL
	VALUES ("48b4b717-0531-4c7c-a718-795e8f67d678",
	0,
	0,
	13,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("48b4b717-0531-4c7c-a718-795e8f67d678",
	'1');
INSERT INTO V_PAR
	VALUES ("48b4b717-0531-4c7c-a718-795e8f67d678",
	"a7c387ae-aaa3-4ce7-861a-7b1c6f65b02f",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	13,
	35);
INSERT INTO V_VAL
	VALUES ("bf1d1bd4-f679-4479-a8d7-e3d98971a8a6",
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("bf1d1bd4-f679-4479-a8d7-e3d98971a8a6",
	'4');
INSERT INTO V_PAR
	VALUES ("bf1d1bd4-f679-4479-a8d7-e3d98971a8a6",
	"2a1e287e-a774-4712-9b3c-b477b7aac032",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"d3c0c668-97b9-415b-af88-f4252f0f5192",
	15,
	18);
INSERT INTO V_VAL
	VALUES ("d3c0c668-97b9-415b-af88-f4252f0f5192",
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("d3c0c668-97b9-415b-af88-f4252f0f5192",
	'1');
INSERT INTO V_PAR
	VALUES ("d3c0c668-97b9-415b-af88-f4252f0f5192",
	"2a1e287e-a774-4712-9b3c-b477b7aac032",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"2ef7cbe8-11e9-4bee-b6f1-d90984fd7341",
	15,
	25);
INSERT INTO V_VAL
	VALUES ("2ef7cbe8-11e9-4bee-b6f1-d90984fd7341",
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("2ef7cbe8-11e9-4bee-b6f1-d90984fd7341",
	'8');
INSERT INTO V_PAR
	VALUES ("2ef7cbe8-11e9-4bee-b6f1-d90984fd7341",
	"2a1e287e-a774-4712-9b3c-b477b7aac032",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	15,
	35);
INSERT INTO V_VAL
	VALUES ("c6639e3a-c588-4b8d-8369-112f0e7cfa4e",
	0,
	0,
	16,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("c6639e3a-c588-4b8d-8369-112f0e7cfa4e",
	'4');
INSERT INTO V_PAR
	VALUES ("c6639e3a-c588-4b8d-8369-112f0e7cfa4e",
	"1a20c8e5-d34c-4ad4-9126-2a78b6a2ced2",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"cf80d01c-64fa-4018-b693-d2da9bb1d246",
	16,
	18);
INSERT INTO V_VAL
	VALUES ("cf80d01c-64fa-4018-b693-d2da9bb1d246",
	0,
	0,
	16,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("cf80d01c-64fa-4018-b693-d2da9bb1d246",
	'4');
INSERT INTO V_PAR
	VALUES ("cf80d01c-64fa-4018-b693-d2da9bb1d246",
	"1a20c8e5-d34c-4ad4-9126-2a78b6a2ced2",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f4bde9cb-c2d3-4d2a-b910-fa36050eec0b",
	16,
	25);
INSERT INTO V_VAL
	VALUES ("f4bde9cb-c2d3-4d2a-b910-fa36050eec0b",
	0,
	0,
	16,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("f4bde9cb-c2d3-4d2a-b910-fa36050eec0b",
	'4');
INSERT INTO V_PAR
	VALUES ("f4bde9cb-c2d3-4d2a-b910-fa36050eec0b",
	"1a20c8e5-d34c-4ad4-9126-2a78b6a2ced2",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	16,
	35);
INSERT INTO V_VAL
	VALUES ("dc2f9b6d-c04f-47b4-98f5-f3ac7356f4f8",
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("dc2f9b6d-c04f-47b4-98f5-f3ac7356f4f8",
	'4');
INSERT INTO V_PAR
	VALUES ("dc2f9b6d-c04f-47b4-98f5-f3ac7356f4f8",
	"a523ca9f-a81e-4ffc-af78-833712e26ec7",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2ef533a8-eb90-4cda-9658-741412182337",
	17,
	18);
INSERT INTO V_VAL
	VALUES ("2ef533a8-eb90-4cda-9658-741412182337",
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("2ef533a8-eb90-4cda-9658-741412182337",
	'6');
INSERT INTO V_PAR
	VALUES ("2ef533a8-eb90-4cda-9658-741412182337",
	"a523ca9f-a81e-4ffc-af78-833712e26ec7",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"3d7c3514-8c83-4a96-b2ad-85cb66b6c0d1",
	17,
	25);
INSERT INTO V_VAL
	VALUES ("3d7c3514-8c83-4a96-b2ad-85cb66b6c0d1",
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("3d7c3514-8c83-4a96-b2ad-85cb66b6c0d1",
	'7');
INSERT INTO V_PAR
	VALUES ("3d7c3514-8c83-4a96-b2ad-85cb66b6c0d1",
	"a523ca9f-a81e-4ffc-af78-833712e26ec7",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	17,
	35);
INSERT INTO V_VAL
	VALUES ("37af0178-7943-449e-9203-7478e4429f9f",
	0,
	0,
	18,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("37af0178-7943-449e-9203-7478e4429f9f",
	'4');
INSERT INTO V_PAR
	VALUES ("37af0178-7943-449e-9203-7478e4429f9f",
	"6d4e252b-ce81-4687-96bf-8595bf598385",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"0cbca634-db06-414c-9dda-e5afb862ab34",
	18,
	18);
INSERT INTO V_VAL
	VALUES ("0cbca634-db06-414c-9dda-e5afb862ab34",
	0,
	0,
	18,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("0cbca634-db06-414c-9dda-e5afb862ab34",
	'9');
INSERT INTO V_PAR
	VALUES ("0cbca634-db06-414c-9dda-e5afb862ab34",
	"6d4e252b-ce81-4687-96bf-8595bf598385",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"fc6d7c2e-a656-4702-a806-d735bb0ba546",
	18,
	25);
INSERT INTO V_VAL
	VALUES ("fc6d7c2e-a656-4702-a806-d735bb0ba546",
	0,
	0,
	18,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("fc6d7c2e-a656-4702-a806-d735bb0ba546",
	'6');
INSERT INTO V_PAR
	VALUES ("fc6d7c2e-a656-4702-a806-d735bb0ba546",
	"6d4e252b-ce81-4687-96bf-8595bf598385",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	18,
	35);
INSERT INTO V_VAL
	VALUES ("a9dc4792-6fb6-480a-b7e9-0082257a5120",
	0,
	0,
	20,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("a9dc4792-6fb6-480a-b7e9-0082257a5120",
	'5');
INSERT INTO V_PAR
	VALUES ("a9dc4792-6fb6-480a-b7e9-0082257a5120",
	"dde9861c-b1d3-48d1-93b9-f85d94a65c9e",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"ab6f93b5-2357-4b84-af80-6d40411141db",
	20,
	18);
INSERT INTO V_VAL
	VALUES ("ab6f93b5-2357-4b84-af80-6d40411141db",
	0,
	0,
	20,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("ab6f93b5-2357-4b84-af80-6d40411141db",
	'3');
INSERT INTO V_PAR
	VALUES ("ab6f93b5-2357-4b84-af80-6d40411141db",
	"dde9861c-b1d3-48d1-93b9-f85d94a65c9e",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"18a55a80-4ca8-4cdb-8eb4-4f8a4addc17a",
	20,
	25);
INSERT INTO V_VAL
	VALUES ("18a55a80-4ca8-4cdb-8eb4-4f8a4addc17a",
	0,
	0,
	20,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("18a55a80-4ca8-4cdb-8eb4-4f8a4addc17a",
	'6');
INSERT INTO V_PAR
	VALUES ("18a55a80-4ca8-4cdb-8eb4-4f8a4addc17a",
	"dde9861c-b1d3-48d1-93b9-f85d94a65c9e",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	20,
	35);
INSERT INTO V_VAL
	VALUES ("5847e55e-5192-4171-ac03-e9643e8205e2",
	0,
	0,
	21,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("5847e55e-5192-4171-ac03-e9643e8205e2",
	'5');
INSERT INTO V_PAR
	VALUES ("5847e55e-5192-4171-ac03-e9643e8205e2",
	"c00ca8c0-0f9c-4c4d-91e7-68588c642d62",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4b8dab78-d8ea-4936-90db-7044cbdf77b3",
	21,
	18);
INSERT INTO V_VAL
	VALUES ("4b8dab78-d8ea-4936-90db-7044cbdf77b3",
	0,
	0,
	21,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("4b8dab78-d8ea-4936-90db-7044cbdf77b3",
	'7');
INSERT INTO V_PAR
	VALUES ("4b8dab78-d8ea-4936-90db-7044cbdf77b3",
	"c00ca8c0-0f9c-4c4d-91e7-68588c642d62",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"d8fd24a6-e73f-4f51-8b27-c2ea4a672eb4",
	21,
	25);
INSERT INTO V_VAL
	VALUES ("d8fd24a6-e73f-4f51-8b27-c2ea4a672eb4",
	0,
	0,
	21,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("d8fd24a6-e73f-4f51-8b27-c2ea4a672eb4",
	'3');
INSERT INTO V_PAR
	VALUES ("d8fd24a6-e73f-4f51-8b27-c2ea4a672eb4",
	"c00ca8c0-0f9c-4c4d-91e7-68588c642d62",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	21,
	35);
INSERT INTO V_VAL
	VALUES ("a278b684-8b13-4a5a-b1d4-14d7554378c3",
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("a278b684-8b13-4a5a-b1d4-14d7554378c3",
	'6');
INSERT INTO V_PAR
	VALUES ("a278b684-8b13-4a5a-b1d4-14d7554378c3",
	"c244059f-1fb6-42ce-8103-b7e0eaaf5d18",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"c1112de8-0c07-4a78-b94c-7f2cf06c3371",
	23,
	18);
INSERT INTO V_VAL
	VALUES ("c1112de8-0c07-4a78-b94c-7f2cf06c3371",
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("c1112de8-0c07-4a78-b94c-7f2cf06c3371",
	'1');
INSERT INTO V_PAR
	VALUES ("c1112de8-0c07-4a78-b94c-7f2cf06c3371",
	"c244059f-1fb6-42ce-8103-b7e0eaaf5d18",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"619a0550-d37f-476a-a352-0a8ee17dac41",
	23,
	25);
INSERT INTO V_VAL
	VALUES ("619a0550-d37f-476a-a352-0a8ee17dac41",
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("619a0550-d37f-476a-a352-0a8ee17dac41",
	'7');
INSERT INTO V_PAR
	VALUES ("619a0550-d37f-476a-a352-0a8ee17dac41",
	"c244059f-1fb6-42ce-8103-b7e0eaaf5d18",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	23,
	35);
INSERT INTO V_VAL
	VALUES ("96eae412-f2e2-4fb5-aa5f-c4fce4615fba",
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("96eae412-f2e2-4fb5-aa5f-c4fce4615fba",
	'6');
INSERT INTO V_PAR
	VALUES ("96eae412-f2e2-4fb5-aa5f-c4fce4615fba",
	"1595d3d9-e7fa-4872-83ca-775d92356f50",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"8c096e10-2f24-4c94-9a34-8f69f0ab11ce",
	24,
	18);
INSERT INTO V_VAL
	VALUES ("8c096e10-2f24-4c94-9a34-8f69f0ab11ce",
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("8c096e10-2f24-4c94-9a34-8f69f0ab11ce",
	'4');
INSERT INTO V_PAR
	VALUES ("8c096e10-2f24-4c94-9a34-8f69f0ab11ce",
	"1595d3d9-e7fa-4872-83ca-775d92356f50",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"22bdc3b7-6c6d-4bd3-883d-62651e18e19e",
	24,
	25);
INSERT INTO V_VAL
	VALUES ("22bdc3b7-6c6d-4bd3-883d-62651e18e19e",
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("22bdc3b7-6c6d-4bd3-883d-62651e18e19e",
	'9');
INSERT INTO V_PAR
	VALUES ("22bdc3b7-6c6d-4bd3-883d-62651e18e19e",
	"1595d3d9-e7fa-4872-83ca-775d92356f50",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	24,
	35);
INSERT INTO V_VAL
	VALUES ("d5c03144-ccb1-4a7c-bbd3-745207e803ad",
	0,
	0,
	25,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("d5c03144-ccb1-4a7c-bbd3-745207e803ad",
	'6');
INSERT INTO V_PAR
	VALUES ("d5c03144-ccb1-4a7c-bbd3-745207e803ad",
	"e0da6ada-63f4-4185-a3a7-2d836f617f12",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7529355c-53ee-4017-9230-0b6639fc0755",
	25,
	18);
INSERT INTO V_VAL
	VALUES ("7529355c-53ee-4017-9230-0b6639fc0755",
	0,
	0,
	25,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("7529355c-53ee-4017-9230-0b6639fc0755",
	'6');
INSERT INTO V_PAR
	VALUES ("7529355c-53ee-4017-9230-0b6639fc0755",
	"e0da6ada-63f4-4185-a3a7-2d836f617f12",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"94e6c5f2-5d80-4f1a-b14b-f4d76d4d1647",
	25,
	25);
INSERT INTO V_VAL
	VALUES ("94e6c5f2-5d80-4f1a-b14b-f4d76d4d1647",
	0,
	0,
	25,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("94e6c5f2-5d80-4f1a-b14b-f4d76d4d1647",
	'1');
INSERT INTO V_PAR
	VALUES ("94e6c5f2-5d80-4f1a-b14b-f4d76d4d1647",
	"e0da6ada-63f4-4185-a3a7-2d836f617f12",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	25,
	35);
INSERT INTO V_VAL
	VALUES ("ff17463b-1733-48a6-8b79-c0fbaf50e5e3",
	0,
	0,
	26,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("ff17463b-1733-48a6-8b79-c0fbaf50e5e3",
	'6');
INSERT INTO V_PAR
	VALUES ("ff17463b-1733-48a6-8b79-c0fbaf50e5e3",
	"671e6ae9-3b99-440e-9630-3b8b24f13b87",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"bb3e52a7-4937-4b8a-8249-3742f0183218",
	26,
	18);
INSERT INTO V_VAL
	VALUES ("bb3e52a7-4937-4b8a-8249-3742f0183218",
	0,
	0,
	26,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("bb3e52a7-4937-4b8a-8249-3742f0183218",
	'9');
INSERT INTO V_PAR
	VALUES ("bb3e52a7-4937-4b8a-8249-3742f0183218",
	"671e6ae9-3b99-440e-9630-3b8b24f13b87",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"66ced2f2-0efe-4878-b2cf-333fb00ac634",
	26,
	25);
INSERT INTO V_VAL
	VALUES ("66ced2f2-0efe-4878-b2cf-333fb00ac634",
	0,
	0,
	26,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("66ced2f2-0efe-4878-b2cf-333fb00ac634",
	'4');
INSERT INTO V_PAR
	VALUES ("66ced2f2-0efe-4878-b2cf-333fb00ac634",
	"671e6ae9-3b99-440e-9630-3b8b24f13b87",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	26,
	35);
INSERT INTO V_VAL
	VALUES ("7f99311d-3ccb-4513-b70b-1ea7038a1094",
	0,
	0,
	28,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("7f99311d-3ccb-4513-b70b-1ea7038a1094",
	'7');
INSERT INTO V_PAR
	VALUES ("7f99311d-3ccb-4513-b70b-1ea7038a1094",
	"53fcd69d-1d07-400e-b726-69290bdca9a2",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"813a2cf2-ca4b-4a1d-8b9a-549c09cb0f35",
	28,
	18);
INSERT INTO V_VAL
	VALUES ("813a2cf2-ca4b-4a1d-8b9a-549c09cb0f35",
	0,
	0,
	28,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("813a2cf2-ca4b-4a1d-8b9a-549c09cb0f35",
	'1');
INSERT INTO V_PAR
	VALUES ("813a2cf2-ca4b-4a1d-8b9a-549c09cb0f35",
	"53fcd69d-1d07-400e-b726-69290bdca9a2",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"900c4852-e2de-4782-8cba-d513982e6941",
	28,
	25);
INSERT INTO V_VAL
	VALUES ("900c4852-e2de-4782-8cba-d513982e6941",
	0,
	0,
	28,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("900c4852-e2de-4782-8cba-d513982e6941",
	'5');
INSERT INTO V_PAR
	VALUES ("900c4852-e2de-4782-8cba-d513982e6941",
	"53fcd69d-1d07-400e-b726-69290bdca9a2",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	28,
	35);
INSERT INTO V_VAL
	VALUES ("ed5c6f15-8dc0-4527-b347-669bf882e9f2",
	0,
	0,
	29,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("ed5c6f15-8dc0-4527-b347-669bf882e9f2",
	'7');
INSERT INTO V_PAR
	VALUES ("ed5c6f15-8dc0-4527-b347-669bf882e9f2",
	"6006c84d-7bd0-4931-8ed4-0d282cb1aa4d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"c6f7cd84-e6aa-4cca-8ed2-f0ff894e96f2",
	29,
	18);
INSERT INTO V_VAL
	VALUES ("c6f7cd84-e6aa-4cca-8ed2-f0ff894e96f2",
	0,
	0,
	29,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("c6f7cd84-e6aa-4cca-8ed2-f0ff894e96f2",
	'9');
INSERT INTO V_PAR
	VALUES ("c6f7cd84-e6aa-4cca-8ed2-f0ff894e96f2",
	"6006c84d-7bd0-4931-8ed4-0d282cb1aa4d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"dc991bf4-3aac-4043-aca2-8058791ea276",
	29,
	25);
INSERT INTO V_VAL
	VALUES ("dc991bf4-3aac-4043-aca2-8058791ea276",
	0,
	0,
	29,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("dc991bf4-3aac-4043-aca2-8058791ea276",
	'2');
INSERT INTO V_PAR
	VALUES ("dc991bf4-3aac-4043-aca2-8058791ea276",
	"6006c84d-7bd0-4931-8ed4-0d282cb1aa4d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	29,
	35);
INSERT INTO V_VAL
	VALUES ("d1a33f50-0d94-4888-9433-df08356d0cae",
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("d1a33f50-0d94-4888-9433-df08356d0cae",
	'8');
INSERT INTO V_PAR
	VALUES ("d1a33f50-0d94-4888-9433-df08356d0cae",
	"b8276c76-8c6e-49a2-a4e0-847d7b3623de",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"cf1bc027-a479-4f08-bad8-6a7fa017163d",
	31,
	18);
INSERT INTO V_VAL
	VALUES ("cf1bc027-a479-4f08-bad8-6a7fa017163d",
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("cf1bc027-a479-4f08-bad8-6a7fa017163d",
	'3');
INSERT INTO V_PAR
	VALUES ("cf1bc027-a479-4f08-bad8-6a7fa017163d",
	"b8276c76-8c6e-49a2-a4e0-847d7b3623de",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"aef6aec7-a70f-404f-830f-994b7f0279bf",
	31,
	25);
INSERT INTO V_VAL
	VALUES ("aef6aec7-a70f-404f-830f-994b7f0279bf",
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("aef6aec7-a70f-404f-830f-994b7f0279bf",
	'7');
INSERT INTO V_PAR
	VALUES ("aef6aec7-a70f-404f-830f-994b7f0279bf",
	"b8276c76-8c6e-49a2-a4e0-847d7b3623de",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	31,
	35);
INSERT INTO V_VAL
	VALUES ("b0cbccec-8faa-44b7-8420-2860b633c070",
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("b0cbccec-8faa-44b7-8420-2860b633c070",
	'8');
INSERT INTO V_PAR
	VALUES ("b0cbccec-8faa-44b7-8420-2860b633c070",
	"f68c05df-f28f-49e1-9b0c-20aa7b947b8c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"e5a124fb-d804-4d1a-866f-03b5661b552d",
	32,
	18);
INSERT INTO V_VAL
	VALUES ("e5a124fb-d804-4d1a-866f-03b5661b552d",
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("e5a124fb-d804-4d1a-866f-03b5661b552d",
	'4');
INSERT INTO V_PAR
	VALUES ("e5a124fb-d804-4d1a-866f-03b5661b552d",
	"f68c05df-f28f-49e1-9b0c-20aa7b947b8c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"85bdf50a-b769-4558-9c40-6ad94178ffec",
	32,
	25);
INSERT INTO V_VAL
	VALUES ("85bdf50a-b769-4558-9c40-6ad94178ffec",
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("85bdf50a-b769-4558-9c40-6ad94178ffec",
	'2');
INSERT INTO V_PAR
	VALUES ("85bdf50a-b769-4558-9c40-6ad94178ffec",
	"f68c05df-f28f-49e1-9b0c-20aa7b947b8c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	32,
	35);
INSERT INTO V_VAL
	VALUES ("2dd598d9-08c6-4760-aba1-eb1ab97042ab",
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("2dd598d9-08c6-4760-aba1-eb1ab97042ab",
	'8');
INSERT INTO V_PAR
	VALUES ("2dd598d9-08c6-4760-aba1-eb1ab97042ab",
	"6fccb77e-e00b-413f-9ed2-b31a888731a6",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"20502a4c-f6aa-49fb-b9bc-f908c282db18",
	33,
	18);
INSERT INTO V_VAL
	VALUES ("20502a4c-f6aa-49fb-b9bc-f908c282db18",
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("20502a4c-f6aa-49fb-b9bc-f908c282db18",
	'6');
INSERT INTO V_PAR
	VALUES ("20502a4c-f6aa-49fb-b9bc-f908c282db18",
	"6fccb77e-e00b-413f-9ed2-b31a888731a6",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"c3c3d5c2-feeb-400a-b3c2-e72cf7ed1841",
	33,
	25);
INSERT INTO V_VAL
	VALUES ("c3c3d5c2-feeb-400a-b3c2-e72cf7ed1841",
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("c3c3d5c2-feeb-400a-b3c2-e72cf7ed1841",
	'6');
INSERT INTO V_PAR
	VALUES ("c3c3d5c2-feeb-400a-b3c2-e72cf7ed1841",
	"6fccb77e-e00b-413f-9ed2-b31a888731a6",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	33,
	35);
INSERT INTO V_VAL
	VALUES ("6846a64b-0c91-48fa-b53e-165fde5809a5",
	0,
	0,
	34,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("6846a64b-0c91-48fa-b53e-165fde5809a5",
	'8');
INSERT INTO V_PAR
	VALUES ("6846a64b-0c91-48fa-b53e-165fde5809a5",
	"c01a2da0-1da6-430e-a443-444db4c2d1f6",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"dcac20e0-aecf-42d7-9aca-2787c5d80519",
	34,
	18);
INSERT INTO V_VAL
	VALUES ("dcac20e0-aecf-42d7-9aca-2787c5d80519",
	0,
	0,
	34,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("dcac20e0-aecf-42d7-9aca-2787c5d80519",
	'7');
INSERT INTO V_PAR
	VALUES ("dcac20e0-aecf-42d7-9aca-2787c5d80519",
	"c01a2da0-1da6-430e-a443-444db4c2d1f6",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"0ee3929e-1bbc-4ad7-8992-ecf19d57768f",
	34,
	25);
INSERT INTO V_VAL
	VALUES ("0ee3929e-1bbc-4ad7-8992-ecf19d57768f",
	0,
	0,
	34,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("0ee3929e-1bbc-4ad7-8992-ecf19d57768f",
	'9');
INSERT INTO V_PAR
	VALUES ("0ee3929e-1bbc-4ad7-8992-ecf19d57768f",
	"c01a2da0-1da6-430e-a443-444db4c2d1f6",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	34,
	35);
INSERT INTO V_VAL
	VALUES ("5f75ef4c-00de-488f-9ae7-b7747df74c40",
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("5f75ef4c-00de-488f-9ae7-b7747df74c40",
	'9');
INSERT INTO V_PAR
	VALUES ("5f75ef4c-00de-488f-9ae7-b7747df74c40",
	"d370d3be-8408-4c29-9b4a-cfb4e6b201a2",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2cd28539-a0ce-4b9a-920f-73338b21def9",
	36,
	18);
INSERT INTO V_VAL
	VALUES ("2cd28539-a0ce-4b9a-920f-73338b21def9",
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("2cd28539-a0ce-4b9a-920f-73338b21def9",
	'2');
INSERT INTO V_PAR
	VALUES ("2cd28539-a0ce-4b9a-920f-73338b21def9",
	"d370d3be-8408-4c29-9b4a-cfb4e6b201a2",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"fc35afe4-1e46-4d98-b231-1276b71bb42f",
	36,
	25);
INSERT INTO V_VAL
	VALUES ("fc35afe4-1e46-4d98-b231-1276b71bb42f",
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("fc35afe4-1e46-4d98-b231-1276b71bb42f",
	'4');
INSERT INTO V_PAR
	VALUES ("fc35afe4-1e46-4d98-b231-1276b71bb42f",
	"d370d3be-8408-4c29-9b4a-cfb4e6b201a2",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	36,
	35);
INSERT INTO V_VAL
	VALUES ("74ddb736-b3e2-4fda-8ed1-dcd6013aa5e7",
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("74ddb736-b3e2-4fda-8ed1-dcd6013aa5e7",
	'9');
INSERT INTO V_PAR
	VALUES ("74ddb736-b3e2-4fda-8ed1-dcd6013aa5e7",
	"002bb144-55ac-420a-a109-c1e8052242a9",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2a08b477-32b6-411b-b8ae-60a9dff7f47d",
	37,
	18);
INSERT INTO V_VAL
	VALUES ("2a08b477-32b6-411b-b8ae-60a9dff7f47d",
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("2a08b477-32b6-411b-b8ae-60a9dff7f47d",
	'4');
INSERT INTO V_PAR
	VALUES ("2a08b477-32b6-411b-b8ae-60a9dff7f47d",
	"002bb144-55ac-420a-a109-c1e8052242a9",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"c945d029-9986-4e5d-b362-68e029c5bbe8",
	37,
	25);
INSERT INTO V_VAL
	VALUES ("c945d029-9986-4e5d-b362-68e029c5bbe8",
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("c945d029-9986-4e5d-b362-68e029c5bbe8",
	'5');
INSERT INTO V_PAR
	VALUES ("c945d029-9986-4e5d-b362-68e029c5bbe8",
	"002bb144-55ac-420a-a109-c1e8052242a9",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	37,
	35);
INSERT INTO V_VAL
	VALUES ("19f8789a-433b-468a-b073-2a07695fec70",
	0,
	0,
	38,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("19f8789a-433b-468a-b073-2a07695fec70",
	'9');
INSERT INTO V_PAR
	VALUES ("19f8789a-433b-468a-b073-2a07695fec70",
	"79de25ca-22da-4afc-8e23-a171496c24bc",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"86d06651-e2ba-4f85-843a-44bd6fc5f488",
	38,
	18);
INSERT INTO V_VAL
	VALUES ("86d06651-e2ba-4f85-843a-44bd6fc5f488",
	0,
	0,
	38,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("86d06651-e2ba-4f85-843a-44bd6fc5f488",
	'6');
INSERT INTO V_PAR
	VALUES ("86d06651-e2ba-4f85-843a-44bd6fc5f488",
	"79de25ca-22da-4afc-8e23-a171496c24bc",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"6fc223f8-e1a9-4026-8bd2-8627af23701f",
	38,
	25);
INSERT INTO V_VAL
	VALUES ("6fc223f8-e1a9-4026-8bd2-8627af23701f",
	0,
	0,
	38,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("6fc223f8-e1a9-4026-8bd2-8627af23701f",
	'8');
INSERT INTO V_PAR
	VALUES ("6fc223f8-e1a9-4026-8bd2-8627af23701f",
	"79de25ca-22da-4afc-8e23-a171496c24bc",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	38,
	35);
INSERT INTO V_VAL
	VALUES ("1af41dc6-a77a-4ae0-b17c-f15db5937d14",
	0,
	0,
	39,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("1af41dc6-a77a-4ae0-b17c-f15db5937d14",
	'9');
INSERT INTO V_PAR
	VALUES ("1af41dc6-a77a-4ae0-b17c-f15db5937d14",
	"4e6f9b31-8b94-4f2e-b1e7-073158cb7b94",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"55c9981f-6054-4983-acc6-a822c5c234c3",
	39,
	18);
INSERT INTO V_VAL
	VALUES ("55c9981f-6054-4983-acc6-a822c5c234c3",
	0,
	0,
	39,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("55c9981f-6054-4983-acc6-a822c5c234c3",
	'8');
INSERT INTO V_PAR
	VALUES ("55c9981f-6054-4983-acc6-a822c5c234c3",
	"4e6f9b31-8b94-4f2e-b1e7-073158cb7b94",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"b360ef20-4ec9-4dd7-892f-6f30b1a1c1ff",
	39,
	25);
INSERT INTO V_VAL
	VALUES ("b360ef20-4ec9-4dd7-892f-6f30b1a1c1ff",
	0,
	0,
	39,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9eec6965-effd-443f-80be-757fec1efb9a");
INSERT INTO V_LIN
	VALUES ("b360ef20-4ec9-4dd7-892f-6f30b1a1c1ff",
	'7');
INSERT INTO V_PAR
	VALUES ("b360ef20-4ec9-4dd7-892f-6f30b1a1c1ff",
	"4e6f9b31-8b94-4f2e-b1e7-073158cb7b94",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	39,
	35);
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"de19ead6-66ec-425f-9bbf-71eea915c2b4");
INSERT INTO S_SYNC
	VALUES ("de19ead6-66ec-425f-9bbf-71eea915c2b4",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'setz3_given',
	'',
	'
CELL::set_given( row:1, column:2, answer:9 );
CELL::set_given( row:1, column:5, answer:6 );
CELL::set_given( row:1, column:6, answer:5 );

CELL::set_given( row:2, column:4, answer:3 );
CELL::set_given( row:2, column:7, answer:4 );
CELL::set_given( row:2, column:8, answer:9 );

CELL::set_given( row:3, column:2, answer:8 );
CELL::set_given( row:3, column:3, answer:3 );
CELL::set_given( row:3, column:7, answer:2 );

CELL::set_given( row:4, column:1, answer:3 );
CELL::set_given( row:4, column:4, answer:8 );
CELL::set_given( row:4, column:6, answer:4 );
CELL::set_given( row:4, column:9, answer:6 );

CELL::set_given( row:5, column:1, answer:1 );
CELL::set_given( row:5, column:9, answer:7 );

CELL::set_given( row:6, column:1, answer:5 );
CELL::set_given( row:6, column:4, answer:2 );
CELL::set_given( row:6, column:6, answer:3 );
CELL::set_given( row:6, column:9, answer:9 );

CELL::set_given( row:7, column:3, answer:4 );
CELL::set_given( row:7, column:7, answer:6 );
CELL::set_given( row:7, column:8, answer:1 );

CELL::set_given( row:8, column:2, answer:2 );
CELL::set_given( row:8, column:3, answer:7 );
CELL::set_given( row:8, column:6, answer:6 );

CELL::set_given( row:9, column:4, answer:9 );
CELL::set_given( row:9, column:5, answer:3 );
CELL::set_given( row:9, column:8, answer:8 );',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("b5949c3e-6480-4222-b571-591ebffc51ff",
	"de19ead6-66ec-425f-9bbf-71eea915c2b4");
INSERT INTO ACT_ACT
	VALUES ("b5949c3e-6480-4222-b571-591ebffc51ff",
	'function',
	0,
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setz3_given',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c8796c9a-e584-4759-9a36-58c78d2a88b2",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	37,
	1,
	37,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"b5949c3e-6480-4222-b571-591ebffc51ff",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("da98269e-376c-4703-ac81-eca372b52cf4",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"a2d6c292-530b-42f6-bab8-930b007c45ed",
	2,
	1,
	'setz3_given line: 2');
INSERT INTO ACT_TFM
	VALUES ("da98269e-376c-4703-ac81-eca372b52cf4",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	2,
	7,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES ("a2d6c292-530b-42f6-bab8-930b007c45ed",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"58c6e4d7-4e5a-4adc-bd8f-7a9b24676e1e",
	3,
	1,
	'setz3_given line: 3');
INSERT INTO ACT_TFM
	VALUES ("a2d6c292-530b-42f6-bab8-930b007c45ed",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES ("58c6e4d7-4e5a-4adc-bd8f-7a9b24676e1e",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"85aca936-0669-4712-94c9-d21a3790ed55",
	4,
	1,
	'setz3_given line: 4');
INSERT INTO ACT_TFM
	VALUES ("58c6e4d7-4e5a-4adc-bd8f-7a9b24676e1e",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES ("85aca936-0669-4712-94c9-d21a3790ed55",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"0c68d89d-7104-49fa-8d54-48334cd70926",
	6,
	1,
	'setz3_given line: 6');
INSERT INTO ACT_TFM
	VALUES ("85aca936-0669-4712-94c9-d21a3790ed55",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	6,
	7,
	6,
	1);
INSERT INTO ACT_SMT
	VALUES ("0c68d89d-7104-49fa-8d54-48334cd70926",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"c3168e93-4a2d-44b9-8c68-888e37da4dab",
	7,
	1,
	'setz3_given line: 7');
INSERT INTO ACT_TFM
	VALUES ("0c68d89d-7104-49fa-8d54-48334cd70926",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES ("c3168e93-4a2d-44b9-8c68-888e37da4dab",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"116fdb50-0d18-44b2-8d32-7fe20b665e42",
	8,
	1,
	'setz3_given line: 8');
INSERT INTO ACT_TFM
	VALUES ("c3168e93-4a2d-44b9-8c68-888e37da4dab",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES ("116fdb50-0d18-44b2-8d32-7fe20b665e42",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"e7731530-ae26-494f-afc3-ae4310b7480b",
	10,
	1,
	'setz3_given line: 10');
INSERT INTO ACT_TFM
	VALUES ("116fdb50-0d18-44b2-8d32-7fe20b665e42",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES ("e7731530-ae26-494f-afc3-ae4310b7480b",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"9d437e49-8082-461b-9738-58a495330b84",
	11,
	1,
	'setz3_given line: 11');
INSERT INTO ACT_TFM
	VALUES ("e7731530-ae26-494f-afc3-ae4310b7480b",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	11,
	7,
	11,
	1);
INSERT INTO ACT_SMT
	VALUES ("9d437e49-8082-461b-9738-58a495330b84",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"f63b0050-c5dd-408d-87ca-143d5a3d8d2f",
	12,
	1,
	'setz3_given line: 12');
INSERT INTO ACT_TFM
	VALUES ("9d437e49-8082-461b-9738-58a495330b84",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES ("f63b0050-c5dd-408d-87ca-143d5a3d8d2f",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"bfc6ebf2-322f-443e-8f60-e823597b908a",
	14,
	1,
	'setz3_given line: 14');
INSERT INTO ACT_TFM
	VALUES ("f63b0050-c5dd-408d-87ca-143d5a3d8d2f",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	14,
	7,
	14,
	1);
INSERT INTO ACT_SMT
	VALUES ("bfc6ebf2-322f-443e-8f60-e823597b908a",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"f23046ca-d270-4226-8f5c-2ad1980b562c",
	15,
	1,
	'setz3_given line: 15');
INSERT INTO ACT_TFM
	VALUES ("bfc6ebf2-322f-443e-8f60-e823597b908a",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES ("f23046ca-d270-4226-8f5c-2ad1980b562c",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"8238e699-5413-4d7c-a94c-c3df683bc21f",
	16,
	1,
	'setz3_given line: 16');
INSERT INTO ACT_TFM
	VALUES ("f23046ca-d270-4226-8f5c-2ad1980b562c",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	16,
	1);
INSERT INTO ACT_SMT
	VALUES ("8238e699-5413-4d7c-a94c-c3df683bc21f",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"36f4774f-5ee3-46e4-90c6-ed9f8e5af4fd",
	17,
	1,
	'setz3_given line: 17');
INSERT INTO ACT_TFM
	VALUES ("8238e699-5413-4d7c-a94c-c3df683bc21f",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES ("36f4774f-5ee3-46e4-90c6-ed9f8e5af4fd",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"4a2b4afc-9803-4095-893b-ed083560da30",
	19,
	1,
	'setz3_given line: 19');
INSERT INTO ACT_TFM
	VALUES ("36f4774f-5ee3-46e4-90c6-ed9f8e5af4fd",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	19,
	7,
	19,
	1);
INSERT INTO ACT_SMT
	VALUES ("4a2b4afc-9803-4095-893b-ed083560da30",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"cd42e905-e4dd-434b-866b-b139f6c18f1b",
	20,
	1,
	'setz3_given line: 20');
INSERT INTO ACT_TFM
	VALUES ("4a2b4afc-9803-4095-893b-ed083560da30",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	20,
	7,
	20,
	1);
INSERT INTO ACT_SMT
	VALUES ("cd42e905-e4dd-434b-866b-b139f6c18f1b",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"84d8fe5c-3b16-46a7-afa6-749dcb5b3cb8",
	22,
	1,
	'setz3_given line: 22');
INSERT INTO ACT_TFM
	VALUES ("cd42e905-e4dd-434b-866b-b139f6c18f1b",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	22,
	7,
	22,
	1);
INSERT INTO ACT_SMT
	VALUES ("84d8fe5c-3b16-46a7-afa6-749dcb5b3cb8",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"c460bfc6-4f99-4298-95b4-c8044b67d682",
	23,
	1,
	'setz3_given line: 23');
INSERT INTO ACT_TFM
	VALUES ("84d8fe5c-3b16-46a7-afa6-749dcb5b3cb8",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES ("c460bfc6-4f99-4298-95b4-c8044b67d682",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"b106aecd-459d-4ad9-9912-0ebd300dca9a",
	24,
	1,
	'setz3_given line: 24');
INSERT INTO ACT_TFM
	VALUES ("c460bfc6-4f99-4298-95b4-c8044b67d682",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES ("b106aecd-459d-4ad9-9912-0ebd300dca9a",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"bc943dc2-939d-4e8f-a81f-617e70692df1",
	25,
	1,
	'setz3_given line: 25');
INSERT INTO ACT_TFM
	VALUES ("b106aecd-459d-4ad9-9912-0ebd300dca9a",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	25,
	7,
	25,
	1);
INSERT INTO ACT_SMT
	VALUES ("bc943dc2-939d-4e8f-a81f-617e70692df1",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"70fb7dd4-2dc4-46cb-b062-d7f0b985b45d",
	27,
	1,
	'setz3_given line: 27');
INSERT INTO ACT_TFM
	VALUES ("bc943dc2-939d-4e8f-a81f-617e70692df1",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	27,
	7,
	27,
	1);
INSERT INTO ACT_SMT
	VALUES ("70fb7dd4-2dc4-46cb-b062-d7f0b985b45d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"da8cb909-638d-4dc5-8f68-90a371e06483",
	28,
	1,
	'setz3_given line: 28');
INSERT INTO ACT_TFM
	VALUES ("70fb7dd4-2dc4-46cb-b062-d7f0b985b45d",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	28,
	7,
	28,
	1);
INSERT INTO ACT_SMT
	VALUES ("da8cb909-638d-4dc5-8f68-90a371e06483",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"7df72e3f-b644-4c46-9ba1-9e78b88a6e17",
	29,
	1,
	'setz3_given line: 29');
INSERT INTO ACT_TFM
	VALUES ("da8cb909-638d-4dc5-8f68-90a371e06483",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	29,
	7,
	29,
	1);
INSERT INTO ACT_SMT
	VALUES ("7df72e3f-b644-4c46-9ba1-9e78b88a6e17",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"d569114e-6ef5-4da0-adc9-4fe997a4bd65",
	31,
	1,
	'setz3_given line: 31');
INSERT INTO ACT_TFM
	VALUES ("7df72e3f-b644-4c46-9ba1-9e78b88a6e17",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES ("d569114e-6ef5-4da0-adc9-4fe997a4bd65",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"ed92de21-0c9a-48f7-83e1-13e9c7909eeb",
	32,
	1,
	'setz3_given line: 32');
INSERT INTO ACT_TFM
	VALUES ("d569114e-6ef5-4da0-adc9-4fe997a4bd65",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES ("ed92de21-0c9a-48f7-83e1-13e9c7909eeb",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"2c97c2de-0c73-4d77-95d1-b381d6d50ae7",
	33,
	1,
	'setz3_given line: 33');
INSERT INTO ACT_TFM
	VALUES ("ed92de21-0c9a-48f7-83e1-13e9c7909eeb",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES ("2c97c2de-0c73-4d77-95d1-b381d6d50ae7",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"03522ea4-e80d-4336-abea-60093904713a",
	35,
	1,
	'setz3_given line: 35');
INSERT INTO ACT_TFM
	VALUES ("2c97c2de-0c73-4d77-95d1-b381d6d50ae7",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	35,
	7,
	35,
	1);
INSERT INTO ACT_SMT
	VALUES ("03522ea4-e80d-4336-abea-60093904713a",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"2579e94b-dfc8-459a-a243-7e148b855ddd",
	36,
	1,
	'setz3_given line: 36');
INSERT INTO ACT_TFM
	VALUES ("03522ea4-e80d-4336-abea-60093904713a",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES ("2579e94b-dfc8-459a-a243-7e148b855ddd",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2",
	"00000000-0000-0000-0000-000000000000",
	37,
	1,
	'setz3_given line: 37');
INSERT INTO ACT_TFM
	VALUES ("2579e94b-dfc8-459a-a243-7e148b855ddd",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	37,
	7,
	37,
	1);
INSERT INTO V_VAL
	VALUES ("e3f4f3c5-bdaf-4cc6-867f-dab627de4556",
	0,
	0,
	2,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("e3f4f3c5-bdaf-4cc6-867f-dab627de4556",
	'1');
INSERT INTO V_PAR
	VALUES ("e3f4f3c5-bdaf-4cc6-867f-dab627de4556",
	"da98269e-376c-4703-ac81-eca372b52cf4",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"8ac01e34-2480-4ff4-8cb6-42dbf56d4854",
	2,
	18);
INSERT INTO V_VAL
	VALUES ("8ac01e34-2480-4ff4-8cb6-42dbf56d4854",
	0,
	0,
	2,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("8ac01e34-2480-4ff4-8cb6-42dbf56d4854",
	'2');
INSERT INTO V_PAR
	VALUES ("8ac01e34-2480-4ff4-8cb6-42dbf56d4854",
	"da98269e-376c-4703-ac81-eca372b52cf4",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"d36c4abe-4572-4764-b722-c695b84616ab",
	2,
	25);
INSERT INTO V_VAL
	VALUES ("d36c4abe-4572-4764-b722-c695b84616ab",
	0,
	0,
	2,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("d36c4abe-4572-4764-b722-c695b84616ab",
	'9');
INSERT INTO V_PAR
	VALUES ("d36c4abe-4572-4764-b722-c695b84616ab",
	"da98269e-376c-4703-ac81-eca372b52cf4",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	2,
	35);
INSERT INTO V_VAL
	VALUES ("421aa6d6-e77e-45fb-b252-78085e5b1156",
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("421aa6d6-e77e-45fb-b252-78085e5b1156",
	'1');
INSERT INTO V_PAR
	VALUES ("421aa6d6-e77e-45fb-b252-78085e5b1156",
	"a2d6c292-530b-42f6-bab8-930b007c45ed",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"9d1c1c71-bc57-4a2c-8974-1f8653df5bcd",
	3,
	18);
INSERT INTO V_VAL
	VALUES ("9d1c1c71-bc57-4a2c-8974-1f8653df5bcd",
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("9d1c1c71-bc57-4a2c-8974-1f8653df5bcd",
	'5');
INSERT INTO V_PAR
	VALUES ("9d1c1c71-bc57-4a2c-8974-1f8653df5bcd",
	"a2d6c292-530b-42f6-bab8-930b007c45ed",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8440d1df-8efa-42e2-9f29-dc1fa3e5ccd1",
	3,
	25);
INSERT INTO V_VAL
	VALUES ("8440d1df-8efa-42e2-9f29-dc1fa3e5ccd1",
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("8440d1df-8efa-42e2-9f29-dc1fa3e5ccd1",
	'6');
INSERT INTO V_PAR
	VALUES ("8440d1df-8efa-42e2-9f29-dc1fa3e5ccd1",
	"a2d6c292-530b-42f6-bab8-930b007c45ed",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	3,
	35);
INSERT INTO V_VAL
	VALUES ("678e035b-3553-43a4-b5ea-bce4b0f0f466",
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("678e035b-3553-43a4-b5ea-bce4b0f0f466",
	'1');
INSERT INTO V_PAR
	VALUES ("678e035b-3553-43a4-b5ea-bce4b0f0f466",
	"58c6e4d7-4e5a-4adc-bd8f-7a9b24676e1e",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"b31c46e5-78be-46ac-b030-dddf47c5c042",
	4,
	18);
INSERT INTO V_VAL
	VALUES ("b31c46e5-78be-46ac-b030-dddf47c5c042",
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("b31c46e5-78be-46ac-b030-dddf47c5c042",
	'6');
INSERT INTO V_PAR
	VALUES ("b31c46e5-78be-46ac-b030-dddf47c5c042",
	"58c6e4d7-4e5a-4adc-bd8f-7a9b24676e1e",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"92fdcab3-a610-4828-b28c-dba4f6d6a8f1",
	4,
	25);
INSERT INTO V_VAL
	VALUES ("92fdcab3-a610-4828-b28c-dba4f6d6a8f1",
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("92fdcab3-a610-4828-b28c-dba4f6d6a8f1",
	'5');
INSERT INTO V_PAR
	VALUES ("92fdcab3-a610-4828-b28c-dba4f6d6a8f1",
	"58c6e4d7-4e5a-4adc-bd8f-7a9b24676e1e",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	4,
	35);
INSERT INTO V_VAL
	VALUES ("eff509e5-38fe-497e-9425-9c6dd58a3800",
	0,
	0,
	6,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("eff509e5-38fe-497e-9425-9c6dd58a3800",
	'2');
INSERT INTO V_PAR
	VALUES ("eff509e5-38fe-497e-9425-9c6dd58a3800",
	"85aca936-0669-4712-94c9-d21a3790ed55",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"66333650-e4af-4d4d-8dbe-d5c7c4d15f10",
	6,
	18);
INSERT INTO V_VAL
	VALUES ("66333650-e4af-4d4d-8dbe-d5c7c4d15f10",
	0,
	0,
	6,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("66333650-e4af-4d4d-8dbe-d5c7c4d15f10",
	'4');
INSERT INTO V_PAR
	VALUES ("66333650-e4af-4d4d-8dbe-d5c7c4d15f10",
	"85aca936-0669-4712-94c9-d21a3790ed55",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"20025a01-5b7d-44a4-95ba-7a32f563b576",
	6,
	25);
INSERT INTO V_VAL
	VALUES ("20025a01-5b7d-44a4-95ba-7a32f563b576",
	0,
	0,
	6,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("20025a01-5b7d-44a4-95ba-7a32f563b576",
	'3');
INSERT INTO V_PAR
	VALUES ("20025a01-5b7d-44a4-95ba-7a32f563b576",
	"85aca936-0669-4712-94c9-d21a3790ed55",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	6,
	35);
INSERT INTO V_VAL
	VALUES ("cd0109cc-c19f-4d55-96cf-6133f6bd4c1a",
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("cd0109cc-c19f-4d55-96cf-6133f6bd4c1a",
	'2');
INSERT INTO V_PAR
	VALUES ("cd0109cc-c19f-4d55-96cf-6133f6bd4c1a",
	"0c68d89d-7104-49fa-8d54-48334cd70926",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"0e534134-6caf-4ef7-bdb1-be6bafb8e1b9",
	7,
	18);
INSERT INTO V_VAL
	VALUES ("0e534134-6caf-4ef7-bdb1-be6bafb8e1b9",
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("0e534134-6caf-4ef7-bdb1-be6bafb8e1b9",
	'7');
INSERT INTO V_PAR
	VALUES ("0e534134-6caf-4ef7-bdb1-be6bafb8e1b9",
	"0c68d89d-7104-49fa-8d54-48334cd70926",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"9b438b5a-5117-4345-9568-9222895ff143",
	7,
	25);
INSERT INTO V_VAL
	VALUES ("9b438b5a-5117-4345-9568-9222895ff143",
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("9b438b5a-5117-4345-9568-9222895ff143",
	'4');
INSERT INTO V_PAR
	VALUES ("9b438b5a-5117-4345-9568-9222895ff143",
	"0c68d89d-7104-49fa-8d54-48334cd70926",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	7,
	35);
INSERT INTO V_VAL
	VALUES ("1b9456d6-8b0d-4f03-81c6-439f03fb1b3b",
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("1b9456d6-8b0d-4f03-81c6-439f03fb1b3b",
	'2');
INSERT INTO V_PAR
	VALUES ("1b9456d6-8b0d-4f03-81c6-439f03fb1b3b",
	"c3168e93-4a2d-44b9-8c68-888e37da4dab",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2c89ad2d-4b97-4cb5-b13e-a6162249b440",
	8,
	18);
INSERT INTO V_VAL
	VALUES ("2c89ad2d-4b97-4cb5-b13e-a6162249b440",
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("2c89ad2d-4b97-4cb5-b13e-a6162249b440",
	'8');
INSERT INTO V_PAR
	VALUES ("2c89ad2d-4b97-4cb5-b13e-a6162249b440",
	"c3168e93-4a2d-44b9-8c68-888e37da4dab",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"3829228d-5f0a-4182-9870-49fab03cfb04",
	8,
	25);
INSERT INTO V_VAL
	VALUES ("3829228d-5f0a-4182-9870-49fab03cfb04",
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("3829228d-5f0a-4182-9870-49fab03cfb04",
	'9');
INSERT INTO V_PAR
	VALUES ("3829228d-5f0a-4182-9870-49fab03cfb04",
	"c3168e93-4a2d-44b9-8c68-888e37da4dab",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	8,
	35);
INSERT INTO V_VAL
	VALUES ("18c79628-b978-4866-be74-6985d9b288e3",
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("18c79628-b978-4866-be74-6985d9b288e3",
	'3');
INSERT INTO V_PAR
	VALUES ("18c79628-b978-4866-be74-6985d9b288e3",
	"116fdb50-0d18-44b2-8d32-7fe20b665e42",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"491fa22b-ef8c-47e6-9416-f43036ae8aec",
	10,
	18);
INSERT INTO V_VAL
	VALUES ("491fa22b-ef8c-47e6-9416-f43036ae8aec",
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("491fa22b-ef8c-47e6-9416-f43036ae8aec",
	'2');
INSERT INTO V_PAR
	VALUES ("491fa22b-ef8c-47e6-9416-f43036ae8aec",
	"116fdb50-0d18-44b2-8d32-7fe20b665e42",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"df064263-6ee9-40d3-8a0f-a74c221786c9",
	10,
	25);
INSERT INTO V_VAL
	VALUES ("df064263-6ee9-40d3-8a0f-a74c221786c9",
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("df064263-6ee9-40d3-8a0f-a74c221786c9",
	'8');
INSERT INTO V_PAR
	VALUES ("df064263-6ee9-40d3-8a0f-a74c221786c9",
	"116fdb50-0d18-44b2-8d32-7fe20b665e42",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	10,
	35);
INSERT INTO V_VAL
	VALUES ("dd0af9d4-146a-415e-833a-ce4453acc553",
	0,
	0,
	11,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("dd0af9d4-146a-415e-833a-ce4453acc553",
	'3');
INSERT INTO V_PAR
	VALUES ("dd0af9d4-146a-415e-833a-ce4453acc553",
	"e7731530-ae26-494f-afc3-ae4310b7480b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"da3541c6-3918-4d80-be15-0c067739fe7c",
	11,
	18);
INSERT INTO V_VAL
	VALUES ("da3541c6-3918-4d80-be15-0c067739fe7c",
	0,
	0,
	11,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("da3541c6-3918-4d80-be15-0c067739fe7c",
	'3');
INSERT INTO V_PAR
	VALUES ("da3541c6-3918-4d80-be15-0c067739fe7c",
	"e7731530-ae26-494f-afc3-ae4310b7480b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"ec1acaa9-f70a-4189-884e-b2a5517056b8",
	11,
	25);
INSERT INTO V_VAL
	VALUES ("ec1acaa9-f70a-4189-884e-b2a5517056b8",
	0,
	0,
	11,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("ec1acaa9-f70a-4189-884e-b2a5517056b8",
	'3');
INSERT INTO V_PAR
	VALUES ("ec1acaa9-f70a-4189-884e-b2a5517056b8",
	"e7731530-ae26-494f-afc3-ae4310b7480b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	11,
	35);
INSERT INTO V_VAL
	VALUES ("0ded1323-e3cc-4495-a698-604ad82b9e2a",
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("0ded1323-e3cc-4495-a698-604ad82b9e2a",
	'3');
INSERT INTO V_PAR
	VALUES ("0ded1323-e3cc-4495-a698-604ad82b9e2a",
	"9d437e49-8082-461b-9738-58a495330b84",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"0a89bece-c8eb-46a3-ae8d-968f1ade0807",
	12,
	18);
INSERT INTO V_VAL
	VALUES ("0a89bece-c8eb-46a3-ae8d-968f1ade0807",
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("0a89bece-c8eb-46a3-ae8d-968f1ade0807",
	'7');
INSERT INTO V_PAR
	VALUES ("0a89bece-c8eb-46a3-ae8d-968f1ade0807",
	"9d437e49-8082-461b-9738-58a495330b84",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"d694783a-f106-45ce-98ad-62ce513586ec",
	12,
	25);
INSERT INTO V_VAL
	VALUES ("d694783a-f106-45ce-98ad-62ce513586ec",
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("d694783a-f106-45ce-98ad-62ce513586ec",
	'2');
INSERT INTO V_PAR
	VALUES ("d694783a-f106-45ce-98ad-62ce513586ec",
	"9d437e49-8082-461b-9738-58a495330b84",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	12,
	35);
INSERT INTO V_VAL
	VALUES ("25dc5f7d-2d47-4485-91be-83ecd96451de",
	0,
	0,
	14,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("25dc5f7d-2d47-4485-91be-83ecd96451de",
	'4');
INSERT INTO V_PAR
	VALUES ("25dc5f7d-2d47-4485-91be-83ecd96451de",
	"f63b0050-c5dd-408d-87ca-143d5a3d8d2f",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"bc87cf89-679e-4023-8ee7-cde7460c1f33",
	14,
	18);
INSERT INTO V_VAL
	VALUES ("bc87cf89-679e-4023-8ee7-cde7460c1f33",
	0,
	0,
	14,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("bc87cf89-679e-4023-8ee7-cde7460c1f33",
	'1');
INSERT INTO V_PAR
	VALUES ("bc87cf89-679e-4023-8ee7-cde7460c1f33",
	"f63b0050-c5dd-408d-87ca-143d5a3d8d2f",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"a70d3288-fdf7-45a9-a72d-820ea9bbba77",
	14,
	25);
INSERT INTO V_VAL
	VALUES ("a70d3288-fdf7-45a9-a72d-820ea9bbba77",
	0,
	0,
	14,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("a70d3288-fdf7-45a9-a72d-820ea9bbba77",
	'3');
INSERT INTO V_PAR
	VALUES ("a70d3288-fdf7-45a9-a72d-820ea9bbba77",
	"f63b0050-c5dd-408d-87ca-143d5a3d8d2f",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	14,
	35);
INSERT INTO V_VAL
	VALUES ("1e7113e3-3040-483e-8268-8af4b3d1f897",
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("1e7113e3-3040-483e-8268-8af4b3d1f897",
	'4');
INSERT INTO V_PAR
	VALUES ("1e7113e3-3040-483e-8268-8af4b3d1f897",
	"bfc6ebf2-322f-443e-8f60-e823597b908a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"46c53cce-7ef5-43e4-ae3a-bc49cfeea527",
	15,
	18);
INSERT INTO V_VAL
	VALUES ("46c53cce-7ef5-43e4-ae3a-bc49cfeea527",
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("46c53cce-7ef5-43e4-ae3a-bc49cfeea527",
	'4');
INSERT INTO V_PAR
	VALUES ("46c53cce-7ef5-43e4-ae3a-bc49cfeea527",
	"bfc6ebf2-322f-443e-8f60-e823597b908a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"7d5880d9-a33e-4c7f-8809-7114822f6935",
	15,
	25);
INSERT INTO V_VAL
	VALUES ("7d5880d9-a33e-4c7f-8809-7114822f6935",
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("7d5880d9-a33e-4c7f-8809-7114822f6935",
	'8');
INSERT INTO V_PAR
	VALUES ("7d5880d9-a33e-4c7f-8809-7114822f6935",
	"bfc6ebf2-322f-443e-8f60-e823597b908a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	15,
	35);
INSERT INTO V_VAL
	VALUES ("2c96ac75-d83e-41d7-a8da-0bec3322d28d",
	0,
	0,
	16,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("2c96ac75-d83e-41d7-a8da-0bec3322d28d",
	'4');
INSERT INTO V_PAR
	VALUES ("2c96ac75-d83e-41d7-a8da-0bec3322d28d",
	"f23046ca-d270-4226-8f5c-2ad1980b562c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"a380df17-8ad7-43ab-a332-97fdcd9def33",
	16,
	18);
INSERT INTO V_VAL
	VALUES ("a380df17-8ad7-43ab-a332-97fdcd9def33",
	0,
	0,
	16,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("a380df17-8ad7-43ab-a332-97fdcd9def33",
	'6');
INSERT INTO V_PAR
	VALUES ("a380df17-8ad7-43ab-a332-97fdcd9def33",
	"f23046ca-d270-4226-8f5c-2ad1980b562c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"ae2630bd-2506-470e-9438-61375b726719",
	16,
	25);
INSERT INTO V_VAL
	VALUES ("ae2630bd-2506-470e-9438-61375b726719",
	0,
	0,
	16,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("ae2630bd-2506-470e-9438-61375b726719",
	'4');
INSERT INTO V_PAR
	VALUES ("ae2630bd-2506-470e-9438-61375b726719",
	"f23046ca-d270-4226-8f5c-2ad1980b562c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	16,
	35);
INSERT INTO V_VAL
	VALUES ("e84d3ad9-c9de-43ec-869c-d3b4b3910b86",
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("e84d3ad9-c9de-43ec-869c-d3b4b3910b86",
	'4');
INSERT INTO V_PAR
	VALUES ("e84d3ad9-c9de-43ec-869c-d3b4b3910b86",
	"8238e699-5413-4d7c-a94c-c3df683bc21f",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7dcee728-fd29-49c7-86b1-bc12bb83e122",
	17,
	18);
INSERT INTO V_VAL
	VALUES ("7dcee728-fd29-49c7-86b1-bc12bb83e122",
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("7dcee728-fd29-49c7-86b1-bc12bb83e122",
	'9');
INSERT INTO V_PAR
	VALUES ("7dcee728-fd29-49c7-86b1-bc12bb83e122",
	"8238e699-5413-4d7c-a94c-c3df683bc21f",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"92bb3814-d905-446e-b370-4441c748f623",
	17,
	25);
INSERT INTO V_VAL
	VALUES ("92bb3814-d905-446e-b370-4441c748f623",
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("92bb3814-d905-446e-b370-4441c748f623",
	'6');
INSERT INTO V_PAR
	VALUES ("92bb3814-d905-446e-b370-4441c748f623",
	"8238e699-5413-4d7c-a94c-c3df683bc21f",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	17,
	35);
INSERT INTO V_VAL
	VALUES ("eb31569e-7031-4dd6-bef7-75641c46b200",
	0,
	0,
	19,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("eb31569e-7031-4dd6-bef7-75641c46b200",
	'5');
INSERT INTO V_PAR
	VALUES ("eb31569e-7031-4dd6-bef7-75641c46b200",
	"36f4774f-5ee3-46e4-90c6-ed9f8e5af4fd",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"a87df36b-018c-41df-999e-ae7c1dcadae5",
	19,
	18);
INSERT INTO V_VAL
	VALUES ("a87df36b-018c-41df-999e-ae7c1dcadae5",
	0,
	0,
	19,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("a87df36b-018c-41df-999e-ae7c1dcadae5",
	'1');
INSERT INTO V_PAR
	VALUES ("a87df36b-018c-41df-999e-ae7c1dcadae5",
	"36f4774f-5ee3-46e4-90c6-ed9f8e5af4fd",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8315c3a6-67c4-4c5b-96c6-b81288dfdf70",
	19,
	25);
INSERT INTO V_VAL
	VALUES ("8315c3a6-67c4-4c5b-96c6-b81288dfdf70",
	0,
	0,
	19,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("8315c3a6-67c4-4c5b-96c6-b81288dfdf70",
	'1');
INSERT INTO V_PAR
	VALUES ("8315c3a6-67c4-4c5b-96c6-b81288dfdf70",
	"36f4774f-5ee3-46e4-90c6-ed9f8e5af4fd",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	19,
	35);
INSERT INTO V_VAL
	VALUES ("ec80ced4-59f7-4415-b458-9b125db85a89",
	0,
	0,
	20,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("ec80ced4-59f7-4415-b458-9b125db85a89",
	'5');
INSERT INTO V_PAR
	VALUES ("ec80ced4-59f7-4415-b458-9b125db85a89",
	"4a2b4afc-9803-4095-893b-ed083560da30",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"197de461-61de-448f-bff9-543bfb022978",
	20,
	18);
INSERT INTO V_VAL
	VALUES ("197de461-61de-448f-bff9-543bfb022978",
	0,
	0,
	20,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("197de461-61de-448f-bff9-543bfb022978",
	'9');
INSERT INTO V_PAR
	VALUES ("197de461-61de-448f-bff9-543bfb022978",
	"4a2b4afc-9803-4095-893b-ed083560da30",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"c5b30ee9-a394-44a6-82e2-7caf01b4762d",
	20,
	25);
INSERT INTO V_VAL
	VALUES ("c5b30ee9-a394-44a6-82e2-7caf01b4762d",
	0,
	0,
	20,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("c5b30ee9-a394-44a6-82e2-7caf01b4762d",
	'7');
INSERT INTO V_PAR
	VALUES ("c5b30ee9-a394-44a6-82e2-7caf01b4762d",
	"4a2b4afc-9803-4095-893b-ed083560da30",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	20,
	35);
INSERT INTO V_VAL
	VALUES ("11ecfc80-151e-4fdb-ad1a-709fd734702b",
	0,
	0,
	22,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("11ecfc80-151e-4fdb-ad1a-709fd734702b",
	'6');
INSERT INTO V_PAR
	VALUES ("11ecfc80-151e-4fdb-ad1a-709fd734702b",
	"cd42e905-e4dd-434b-866b-b139f6c18f1b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"803653bf-b0e8-42eb-be63-eadcdc5b5bfe",
	22,
	18);
INSERT INTO V_VAL
	VALUES ("803653bf-b0e8-42eb-be63-eadcdc5b5bfe",
	0,
	0,
	22,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("803653bf-b0e8-42eb-be63-eadcdc5b5bfe",
	'1');
INSERT INTO V_PAR
	VALUES ("803653bf-b0e8-42eb-be63-eadcdc5b5bfe",
	"cd42e905-e4dd-434b-866b-b139f6c18f1b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"743f4348-f71a-4cd9-bf5e-2b2fff030fd9",
	22,
	25);
INSERT INTO V_VAL
	VALUES ("743f4348-f71a-4cd9-bf5e-2b2fff030fd9",
	0,
	0,
	22,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("743f4348-f71a-4cd9-bf5e-2b2fff030fd9",
	'5');
INSERT INTO V_PAR
	VALUES ("743f4348-f71a-4cd9-bf5e-2b2fff030fd9",
	"cd42e905-e4dd-434b-866b-b139f6c18f1b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	22,
	35);
INSERT INTO V_VAL
	VALUES ("33e26125-c8c8-494c-8c6c-034a56f6e6bd",
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("33e26125-c8c8-494c-8c6c-034a56f6e6bd",
	'6');
INSERT INTO V_PAR
	VALUES ("33e26125-c8c8-494c-8c6c-034a56f6e6bd",
	"84d8fe5c-3b16-46a7-afa6-749dcb5b3cb8",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4d76a7ba-987e-4615-ab8f-0749077fa5e0",
	23,
	18);
INSERT INTO V_VAL
	VALUES ("4d76a7ba-987e-4615-ab8f-0749077fa5e0",
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("4d76a7ba-987e-4615-ab8f-0749077fa5e0",
	'4');
INSERT INTO V_PAR
	VALUES ("4d76a7ba-987e-4615-ab8f-0749077fa5e0",
	"84d8fe5c-3b16-46a7-afa6-749dcb5b3cb8",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"0a848690-e8ba-47ea-b730-e32039a3dcb7",
	23,
	25);
INSERT INTO V_VAL
	VALUES ("0a848690-e8ba-47ea-b730-e32039a3dcb7",
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("0a848690-e8ba-47ea-b730-e32039a3dcb7",
	'2');
INSERT INTO V_PAR
	VALUES ("0a848690-e8ba-47ea-b730-e32039a3dcb7",
	"84d8fe5c-3b16-46a7-afa6-749dcb5b3cb8",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	23,
	35);
INSERT INTO V_VAL
	VALUES ("d1dab7d8-96d9-4378-b260-65eaf8d2ae14",
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("d1dab7d8-96d9-4378-b260-65eaf8d2ae14",
	'6');
INSERT INTO V_PAR
	VALUES ("d1dab7d8-96d9-4378-b260-65eaf8d2ae14",
	"c460bfc6-4f99-4298-95b4-c8044b67d682",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"f785c836-654e-4618-a7fc-56022e24aa41",
	24,
	18);
INSERT INTO V_VAL
	VALUES ("f785c836-654e-4618-a7fc-56022e24aa41",
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("f785c836-654e-4618-a7fc-56022e24aa41",
	'6');
INSERT INTO V_PAR
	VALUES ("f785c836-654e-4618-a7fc-56022e24aa41",
	"c460bfc6-4f99-4298-95b4-c8044b67d682",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"98ad9ea5-e97a-4f91-ab36-98050c259d3a",
	24,
	25);
INSERT INTO V_VAL
	VALUES ("98ad9ea5-e97a-4f91-ab36-98050c259d3a",
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("98ad9ea5-e97a-4f91-ab36-98050c259d3a",
	'3');
INSERT INTO V_PAR
	VALUES ("98ad9ea5-e97a-4f91-ab36-98050c259d3a",
	"c460bfc6-4f99-4298-95b4-c8044b67d682",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	24,
	35);
INSERT INTO V_VAL
	VALUES ("61fe283f-9ae0-4631-a3d1-3c33a63c6868",
	0,
	0,
	25,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("61fe283f-9ae0-4631-a3d1-3c33a63c6868",
	'6');
INSERT INTO V_PAR
	VALUES ("61fe283f-9ae0-4631-a3d1-3c33a63c6868",
	"b106aecd-459d-4ad9-9912-0ebd300dca9a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"b0adf214-70c7-449d-bbe9-a211752df206",
	25,
	18);
INSERT INTO V_VAL
	VALUES ("b0adf214-70c7-449d-bbe9-a211752df206",
	0,
	0,
	25,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("b0adf214-70c7-449d-bbe9-a211752df206",
	'9');
INSERT INTO V_PAR
	VALUES ("b0adf214-70c7-449d-bbe9-a211752df206",
	"b106aecd-459d-4ad9-9912-0ebd300dca9a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"402c5863-6b73-424a-8928-b40ca5162932",
	25,
	25);
INSERT INTO V_VAL
	VALUES ("402c5863-6b73-424a-8928-b40ca5162932",
	0,
	0,
	25,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("402c5863-6b73-424a-8928-b40ca5162932",
	'9');
INSERT INTO V_PAR
	VALUES ("402c5863-6b73-424a-8928-b40ca5162932",
	"b106aecd-459d-4ad9-9912-0ebd300dca9a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	25,
	35);
INSERT INTO V_VAL
	VALUES ("1d5697ad-b6b7-4d21-a74b-a37f9b99ff0c",
	0,
	0,
	27,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("1d5697ad-b6b7-4d21-a74b-a37f9b99ff0c",
	'7');
INSERT INTO V_PAR
	VALUES ("1d5697ad-b6b7-4d21-a74b-a37f9b99ff0c",
	"bc943dc2-939d-4e8f-a81f-617e70692df1",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7e30d20e-0dbf-42dd-b344-1535738d8567",
	27,
	18);
INSERT INTO V_VAL
	VALUES ("7e30d20e-0dbf-42dd-b344-1535738d8567",
	0,
	0,
	27,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("7e30d20e-0dbf-42dd-b344-1535738d8567",
	'3');
INSERT INTO V_PAR
	VALUES ("7e30d20e-0dbf-42dd-b344-1535738d8567",
	"bc943dc2-939d-4e8f-a81f-617e70692df1",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"6537fbd6-e4f2-4eff-99cd-dfe1cd9920f6",
	27,
	25);
INSERT INTO V_VAL
	VALUES ("6537fbd6-e4f2-4eff-99cd-dfe1cd9920f6",
	0,
	0,
	27,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("6537fbd6-e4f2-4eff-99cd-dfe1cd9920f6",
	'4');
INSERT INTO V_PAR
	VALUES ("6537fbd6-e4f2-4eff-99cd-dfe1cd9920f6",
	"bc943dc2-939d-4e8f-a81f-617e70692df1",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	27,
	35);
INSERT INTO V_VAL
	VALUES ("74fa932c-9ac2-4b43-8145-79463e19af48",
	0,
	0,
	28,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("74fa932c-9ac2-4b43-8145-79463e19af48",
	'7');
INSERT INTO V_PAR
	VALUES ("74fa932c-9ac2-4b43-8145-79463e19af48",
	"70fb7dd4-2dc4-46cb-b062-d7f0b985b45d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"8a87dc80-a039-4854-8580-21829e6db66d",
	28,
	18);
INSERT INTO V_VAL
	VALUES ("8a87dc80-a039-4854-8580-21829e6db66d",
	0,
	0,
	28,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("8a87dc80-a039-4854-8580-21829e6db66d",
	'7');
INSERT INTO V_PAR
	VALUES ("8a87dc80-a039-4854-8580-21829e6db66d",
	"70fb7dd4-2dc4-46cb-b062-d7f0b985b45d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"1e70056c-d336-4e51-a661-9e65db8d7709",
	28,
	25);
INSERT INTO V_VAL
	VALUES ("1e70056c-d336-4e51-a661-9e65db8d7709",
	0,
	0,
	28,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("1e70056c-d336-4e51-a661-9e65db8d7709",
	'6');
INSERT INTO V_PAR
	VALUES ("1e70056c-d336-4e51-a661-9e65db8d7709",
	"70fb7dd4-2dc4-46cb-b062-d7f0b985b45d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	28,
	35);
INSERT INTO V_VAL
	VALUES ("378e8b60-b913-4443-84a3-ce41f5fc7588",
	0,
	0,
	29,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("378e8b60-b913-4443-84a3-ce41f5fc7588",
	'7');
INSERT INTO V_PAR
	VALUES ("378e8b60-b913-4443-84a3-ce41f5fc7588",
	"da8cb909-638d-4dc5-8f68-90a371e06483",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"5beb6027-5917-4526-9938-c55d38f905f2",
	29,
	18);
INSERT INTO V_VAL
	VALUES ("5beb6027-5917-4526-9938-c55d38f905f2",
	0,
	0,
	29,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("5beb6027-5917-4526-9938-c55d38f905f2",
	'8');
INSERT INTO V_PAR
	VALUES ("5beb6027-5917-4526-9938-c55d38f905f2",
	"da8cb909-638d-4dc5-8f68-90a371e06483",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"afd29c64-80b2-4ea3-8ae5-3fca63428c37",
	29,
	25);
INSERT INTO V_VAL
	VALUES ("afd29c64-80b2-4ea3-8ae5-3fca63428c37",
	0,
	0,
	29,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("afd29c64-80b2-4ea3-8ae5-3fca63428c37",
	'1');
INSERT INTO V_PAR
	VALUES ("afd29c64-80b2-4ea3-8ae5-3fca63428c37",
	"da8cb909-638d-4dc5-8f68-90a371e06483",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	29,
	35);
INSERT INTO V_VAL
	VALUES ("28b4e2bd-c59c-4ba1-80cb-bf7997d072d4",
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("28b4e2bd-c59c-4ba1-80cb-bf7997d072d4",
	'8');
INSERT INTO V_PAR
	VALUES ("28b4e2bd-c59c-4ba1-80cb-bf7997d072d4",
	"7df72e3f-b644-4c46-9ba1-9e78b88a6e17",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"485f84e7-804f-4cad-9875-adb84c759fe8",
	31,
	18);
INSERT INTO V_VAL
	VALUES ("485f84e7-804f-4cad-9875-adb84c759fe8",
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("485f84e7-804f-4cad-9875-adb84c759fe8",
	'2');
INSERT INTO V_PAR
	VALUES ("485f84e7-804f-4cad-9875-adb84c759fe8",
	"7df72e3f-b644-4c46-9ba1-9e78b88a6e17",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"782f523a-31ff-494c-84aa-fe0efdbbed20",
	31,
	25);
INSERT INTO V_VAL
	VALUES ("782f523a-31ff-494c-84aa-fe0efdbbed20",
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("782f523a-31ff-494c-84aa-fe0efdbbed20",
	'2');
INSERT INTO V_PAR
	VALUES ("782f523a-31ff-494c-84aa-fe0efdbbed20",
	"7df72e3f-b644-4c46-9ba1-9e78b88a6e17",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	31,
	35);
INSERT INTO V_VAL
	VALUES ("41034c40-d360-4cd3-b644-ea975e5ec05b",
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("41034c40-d360-4cd3-b644-ea975e5ec05b",
	'8');
INSERT INTO V_PAR
	VALUES ("41034c40-d360-4cd3-b644-ea975e5ec05b",
	"d569114e-6ef5-4da0-adc9-4fe997a4bd65",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"30b6fd70-68cf-4127-ab20-0d1f34ca4409",
	32,
	18);
INSERT INTO V_VAL
	VALUES ("30b6fd70-68cf-4127-ab20-0d1f34ca4409",
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("30b6fd70-68cf-4127-ab20-0d1f34ca4409",
	'3');
INSERT INTO V_PAR
	VALUES ("30b6fd70-68cf-4127-ab20-0d1f34ca4409",
	"d569114e-6ef5-4da0-adc9-4fe997a4bd65",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"2dead81b-29da-466d-ba54-6c2c46f940f7",
	32,
	25);
INSERT INTO V_VAL
	VALUES ("2dead81b-29da-466d-ba54-6c2c46f940f7",
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("2dead81b-29da-466d-ba54-6c2c46f940f7",
	'7');
INSERT INTO V_PAR
	VALUES ("2dead81b-29da-466d-ba54-6c2c46f940f7",
	"d569114e-6ef5-4da0-adc9-4fe997a4bd65",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	32,
	35);
INSERT INTO V_VAL
	VALUES ("4f420ed7-cb90-4fd7-890f-d1f4ce9c4c00",
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("4f420ed7-cb90-4fd7-890f-d1f4ce9c4c00",
	'8');
INSERT INTO V_PAR
	VALUES ("4f420ed7-cb90-4fd7-890f-d1f4ce9c4c00",
	"ed92de21-0c9a-48f7-83e1-13e9c7909eeb",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"1d4a0793-e35b-4b96-b2aa-c0728ce2e8d3",
	33,
	18);
INSERT INTO V_VAL
	VALUES ("1d4a0793-e35b-4b96-b2aa-c0728ce2e8d3",
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("1d4a0793-e35b-4b96-b2aa-c0728ce2e8d3",
	'6');
INSERT INTO V_PAR
	VALUES ("1d4a0793-e35b-4b96-b2aa-c0728ce2e8d3",
	"ed92de21-0c9a-48f7-83e1-13e9c7909eeb",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"231eafe8-d5e4-47b4-905b-c540cb93595f",
	33,
	25);
INSERT INTO V_VAL
	VALUES ("231eafe8-d5e4-47b4-905b-c540cb93595f",
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("231eafe8-d5e4-47b4-905b-c540cb93595f",
	'6');
INSERT INTO V_PAR
	VALUES ("231eafe8-d5e4-47b4-905b-c540cb93595f",
	"ed92de21-0c9a-48f7-83e1-13e9c7909eeb",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	33,
	35);
INSERT INTO V_VAL
	VALUES ("216ab19d-21c8-44f5-9103-bfc72557ed27",
	0,
	0,
	35,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("216ab19d-21c8-44f5-9103-bfc72557ed27",
	'9');
INSERT INTO V_PAR
	VALUES ("216ab19d-21c8-44f5-9103-bfc72557ed27",
	"2c97c2de-0c73-4d77-95d1-b381d6d50ae7",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"05c2b93f-504a-40c8-bf2f-ef25c8976838",
	35,
	18);
INSERT INTO V_VAL
	VALUES ("05c2b93f-504a-40c8-bf2f-ef25c8976838",
	0,
	0,
	35,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("05c2b93f-504a-40c8-bf2f-ef25c8976838",
	'4');
INSERT INTO V_PAR
	VALUES ("05c2b93f-504a-40c8-bf2f-ef25c8976838",
	"2c97c2de-0c73-4d77-95d1-b381d6d50ae7",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"84111127-415e-443c-887c-6bda6c655706",
	35,
	25);
INSERT INTO V_VAL
	VALUES ("84111127-415e-443c-887c-6bda6c655706",
	0,
	0,
	35,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("84111127-415e-443c-887c-6bda6c655706",
	'9');
INSERT INTO V_PAR
	VALUES ("84111127-415e-443c-887c-6bda6c655706",
	"2c97c2de-0c73-4d77-95d1-b381d6d50ae7",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	35,
	35);
INSERT INTO V_VAL
	VALUES ("b3b117ca-7c24-4530-b571-8db9a9f3fd82",
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("b3b117ca-7c24-4530-b571-8db9a9f3fd82",
	'9');
INSERT INTO V_PAR
	VALUES ("b3b117ca-7c24-4530-b571-8db9a9f3fd82",
	"03522ea4-e80d-4336-abea-60093904713a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"5d4607e5-c6b1-4e6f-91dc-6f1ae6f89056",
	36,
	18);
INSERT INTO V_VAL
	VALUES ("5d4607e5-c6b1-4e6f-91dc-6f1ae6f89056",
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("5d4607e5-c6b1-4e6f-91dc-6f1ae6f89056",
	'5');
INSERT INTO V_PAR
	VALUES ("5d4607e5-c6b1-4e6f-91dc-6f1ae6f89056",
	"03522ea4-e80d-4336-abea-60093904713a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8ca7a878-8011-485d-8a53-3a19b83d1b54",
	36,
	25);
INSERT INTO V_VAL
	VALUES ("8ca7a878-8011-485d-8a53-3a19b83d1b54",
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("8ca7a878-8011-485d-8a53-3a19b83d1b54",
	'3');
INSERT INTO V_PAR
	VALUES ("8ca7a878-8011-485d-8a53-3a19b83d1b54",
	"03522ea4-e80d-4336-abea-60093904713a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	36,
	35);
INSERT INTO V_VAL
	VALUES ("25fdbb02-ffd8-4c84-a982-8cd473d7955f",
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("25fdbb02-ffd8-4c84-a982-8cd473d7955f",
	'9');
INSERT INTO V_PAR
	VALUES ("25fdbb02-ffd8-4c84-a982-8cd473d7955f",
	"2579e94b-dfc8-459a-a243-7e148b855ddd",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"c7017144-88ac-4f79-8ff7-c550b39cbdf9",
	37,
	18);
INSERT INTO V_VAL
	VALUES ("c7017144-88ac-4f79-8ff7-c550b39cbdf9",
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("c7017144-88ac-4f79-8ff7-c550b39cbdf9",
	'8');
INSERT INTO V_PAR
	VALUES ("c7017144-88ac-4f79-8ff7-c550b39cbdf9",
	"2579e94b-dfc8-459a-a243-7e148b855ddd",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"48dde7a4-654c-4fc6-9390-cedccbcbcb2a",
	37,
	25);
INSERT INTO V_VAL
	VALUES ("48dde7a4-654c-4fc6-9390-cedccbcbcb2a",
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c8796c9a-e584-4759-9a36-58c78d2a88b2");
INSERT INTO V_LIN
	VALUES ("48dde7a4-654c-4fc6-9390-cedccbcbcb2a",
	'8');
INSERT INTO V_PAR
	VALUES ("48dde7a4-654c-4fc6-9390-cedccbcbcb2a",
	"2579e94b-dfc8-459a-a243-7e148b855ddd",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	37,
	35);
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"3912b453-eed4-452d-b98b-819c6c21dc8f");
INSERT INTO S_SYNC
	VALUES ("3912b453-eed4-452d-b98b-819c6c21dc8f",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'setz4_spectrum',
	'',
	'
CELL::set_given( row:1, column:5, answer:8 );
CELL::set_given( row:1, column:6, answer:3 );
CELL::set_given( row:1, column:7, answer:4 );

CELL::set_given( row:2, column:1, answer:3 );
CELL::set_given( row:2, column:6, answer:4 );
CELL::set_given( row:2, column:7, answer:8 );
CELL::set_given( row:2, column:8, answer:2 );
CELL::set_given( row:2, column:9, answer:1 );

CELL::set_given( row:3, column:1, answer:7 );

CELL::set_given( row:4, column:3, answer:9 );
CELL::set_given( row:4, column:4, answer:4 );
CELL::set_given( row:4, column:6, answer:1 );
CELL::set_given( row:4, column:8, answer:8 );
CELL::set_given( row:4, column:9, answer:3 );


CELL::set_given( row:6, column:1, answer:4 );
CELL::set_given( row:6, column:2, answer:6 );
CELL::set_given( row:6, column:4, answer:5 );
CELL::set_given( row:6, column:6, answer:7 );
CELL::set_given( row:6, column:7, answer:1 );

CELL::set_given( row:7, column:9, answer:7 );

CELL::set_given( row:8, column:1, answer:1 );
CELL::set_given( row:8, column:2, answer:2 );
CELL::set_given( row:8, column:3, answer:5 );
CELL::set_given( row:8, column:4, answer:3 );
CELL::set_given( row:8, column:9, answer:9 );

CELL::set_given( row:9, column:3, answer:7 );
CELL::set_given( row:9, column:4, answer:2 );
CELL::set_given( row:9, column:5, answer:4 );',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("7fc3658d-c7aa-49da-9625-5d060f2f889c",
	"3912b453-eed4-452d-b98b-819c6c21dc8f");
INSERT INTO ACT_ACT
	VALUES ("7fc3658d-c7aa-49da-9625-5d060f2f889c",
	'function',
	0,
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setz4_spectrum',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	37,
	1,
	37,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7fc3658d-c7aa-49da-9625-5d060f2f889c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("771b3d3b-4ba1-4169-adce-bae7e6ef1fa2",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"1d1b20cd-e4a6-4b49-8d04-8c6715ad3416",
	2,
	1,
	'setz4_spectrum line: 2');
INSERT INTO ACT_TFM
	VALUES ("771b3d3b-4ba1-4169-adce-bae7e6ef1fa2",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	2,
	7,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES ("1d1b20cd-e4a6-4b49-8d04-8c6715ad3416",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"858d435f-af98-4c2b-bda8-7d8f685e2d86",
	3,
	1,
	'setz4_spectrum line: 3');
INSERT INTO ACT_TFM
	VALUES ("1d1b20cd-e4a6-4b49-8d04-8c6715ad3416",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES ("858d435f-af98-4c2b-bda8-7d8f685e2d86",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"5e12f679-4d60-4d11-a0a0-f1fd588e3cb9",
	4,
	1,
	'setz4_spectrum line: 4');
INSERT INTO ACT_TFM
	VALUES ("858d435f-af98-4c2b-bda8-7d8f685e2d86",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES ("5e12f679-4d60-4d11-a0a0-f1fd588e3cb9",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"3b8d76e7-72fb-4a48-912f-d6711ffdf08e",
	6,
	1,
	'setz4_spectrum line: 6');
INSERT INTO ACT_TFM
	VALUES ("5e12f679-4d60-4d11-a0a0-f1fd588e3cb9",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	6,
	7,
	6,
	1);
INSERT INTO ACT_SMT
	VALUES ("3b8d76e7-72fb-4a48-912f-d6711ffdf08e",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"8d16b764-40d7-4a7b-9408-fdc61a079cfd",
	7,
	1,
	'setz4_spectrum line: 7');
INSERT INTO ACT_TFM
	VALUES ("3b8d76e7-72fb-4a48-912f-d6711ffdf08e",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES ("8d16b764-40d7-4a7b-9408-fdc61a079cfd",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"72b5e150-a216-43c1-9bd6-1557d5afe8c8",
	8,
	1,
	'setz4_spectrum line: 8');
INSERT INTO ACT_TFM
	VALUES ("8d16b764-40d7-4a7b-9408-fdc61a079cfd",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES ("72b5e150-a216-43c1-9bd6-1557d5afe8c8",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"b492dd86-5917-4111-8068-fddd693b4936",
	9,
	1,
	'setz4_spectrum line: 9');
INSERT INTO ACT_TFM
	VALUES ("72b5e150-a216-43c1-9bd6-1557d5afe8c8",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	9,
	7,
	9,
	1);
INSERT INTO ACT_SMT
	VALUES ("b492dd86-5917-4111-8068-fddd693b4936",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"826d238b-ef80-4e3f-abfd-b9a933ad11dd",
	10,
	1,
	'setz4_spectrum line: 10');
INSERT INTO ACT_TFM
	VALUES ("b492dd86-5917-4111-8068-fddd693b4936",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES ("826d238b-ef80-4e3f-abfd-b9a933ad11dd",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"bef05914-8b19-4d91-9480-2f2f306ef931",
	12,
	1,
	'setz4_spectrum line: 12');
INSERT INTO ACT_TFM
	VALUES ("826d238b-ef80-4e3f-abfd-b9a933ad11dd",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES ("bef05914-8b19-4d91-9480-2f2f306ef931",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"273daf24-0262-4a2a-8ce9-5bf3df60b0b6",
	14,
	1,
	'setz4_spectrum line: 14');
INSERT INTO ACT_TFM
	VALUES ("bef05914-8b19-4d91-9480-2f2f306ef931",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	14,
	7,
	14,
	1);
INSERT INTO ACT_SMT
	VALUES ("273daf24-0262-4a2a-8ce9-5bf3df60b0b6",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"3b3523e6-1ed7-422c-b693-20172994043c",
	15,
	1,
	'setz4_spectrum line: 15');
INSERT INTO ACT_TFM
	VALUES ("273daf24-0262-4a2a-8ce9-5bf3df60b0b6",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES ("3b3523e6-1ed7-422c-b693-20172994043c",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"55758027-04fe-45e3-89e5-d528defe829a",
	16,
	1,
	'setz4_spectrum line: 16');
INSERT INTO ACT_TFM
	VALUES ("3b3523e6-1ed7-422c-b693-20172994043c",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	16,
	1);
INSERT INTO ACT_SMT
	VALUES ("55758027-04fe-45e3-89e5-d528defe829a",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"0f259e5d-5562-4f1a-aca6-8b8f7c2b5ebe",
	17,
	1,
	'setz4_spectrum line: 17');
INSERT INTO ACT_TFM
	VALUES ("55758027-04fe-45e3-89e5-d528defe829a",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES ("0f259e5d-5562-4f1a-aca6-8b8f7c2b5ebe",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"bc4b2f03-fa8d-4512-b9d5-df65540a9f16",
	18,
	1,
	'setz4_spectrum line: 18');
INSERT INTO ACT_TFM
	VALUES ("0f259e5d-5562-4f1a-aca6-8b8f7c2b5ebe",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	18,
	7,
	18,
	1);
INSERT INTO ACT_SMT
	VALUES ("bc4b2f03-fa8d-4512-b9d5-df65540a9f16",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"324da7ee-2fcc-4209-ba27-1319c3e6adcc",
	21,
	1,
	'setz4_spectrum line: 21');
INSERT INTO ACT_TFM
	VALUES ("bc4b2f03-fa8d-4512-b9d5-df65540a9f16",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	21,
	7,
	21,
	1);
INSERT INTO ACT_SMT
	VALUES ("324da7ee-2fcc-4209-ba27-1319c3e6adcc",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"e223c8e2-1b20-4557-aebb-db99fcc27271",
	22,
	1,
	'setz4_spectrum line: 22');
INSERT INTO ACT_TFM
	VALUES ("324da7ee-2fcc-4209-ba27-1319c3e6adcc",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	22,
	7,
	22,
	1);
INSERT INTO ACT_SMT
	VALUES ("e223c8e2-1b20-4557-aebb-db99fcc27271",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"eab0581a-f2c2-40b5-8052-433915070d13",
	23,
	1,
	'setz4_spectrum line: 23');
INSERT INTO ACT_TFM
	VALUES ("e223c8e2-1b20-4557-aebb-db99fcc27271",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES ("eab0581a-f2c2-40b5-8052-433915070d13",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"6d32f3ea-cc97-4d5f-bf94-09c115662ad8",
	24,
	1,
	'setz4_spectrum line: 24');
INSERT INTO ACT_TFM
	VALUES ("eab0581a-f2c2-40b5-8052-433915070d13",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES ("6d32f3ea-cc97-4d5f-bf94-09c115662ad8",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"b9e3c612-47ac-4a2c-98d6-6457f0dfc258",
	25,
	1,
	'setz4_spectrum line: 25');
INSERT INTO ACT_TFM
	VALUES ("6d32f3ea-cc97-4d5f-bf94-09c115662ad8",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	25,
	7,
	25,
	1);
INSERT INTO ACT_SMT
	VALUES ("b9e3c612-47ac-4a2c-98d6-6457f0dfc258",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"9be705a7-1f33-41f8-a8aa-5760ef3aa93a",
	27,
	1,
	'setz4_spectrum line: 27');
INSERT INTO ACT_TFM
	VALUES ("b9e3c612-47ac-4a2c-98d6-6457f0dfc258",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	27,
	7,
	27,
	1);
INSERT INTO ACT_SMT
	VALUES ("9be705a7-1f33-41f8-a8aa-5760ef3aa93a",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"c833f123-af23-4848-b230-5817d55d65fe",
	29,
	1,
	'setz4_spectrum line: 29');
INSERT INTO ACT_TFM
	VALUES ("9be705a7-1f33-41f8-a8aa-5760ef3aa93a",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	29,
	7,
	29,
	1);
INSERT INTO ACT_SMT
	VALUES ("c833f123-af23-4848-b230-5817d55d65fe",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"277aaa9d-5d0e-4496-98d4-98cd29fdbd80",
	30,
	1,
	'setz4_spectrum line: 30');
INSERT INTO ACT_TFM
	VALUES ("c833f123-af23-4848-b230-5817d55d65fe",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	30,
	7,
	30,
	1);
INSERT INTO ACT_SMT
	VALUES ("277aaa9d-5d0e-4496-98d4-98cd29fdbd80",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"ef104f20-21dd-4135-9afc-0949974585b8",
	31,
	1,
	'setz4_spectrum line: 31');
INSERT INTO ACT_TFM
	VALUES ("277aaa9d-5d0e-4496-98d4-98cd29fdbd80",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES ("ef104f20-21dd-4135-9afc-0949974585b8",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"5a122d4a-7978-4d75-a0ad-af57d44e8218",
	32,
	1,
	'setz4_spectrum line: 32');
INSERT INTO ACT_TFM
	VALUES ("ef104f20-21dd-4135-9afc-0949974585b8",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES ("5a122d4a-7978-4d75-a0ad-af57d44e8218",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"bb2fe854-52e1-4b42-920f-0fe78efd4ece",
	33,
	1,
	'setz4_spectrum line: 33');
INSERT INTO ACT_TFM
	VALUES ("5a122d4a-7978-4d75-a0ad-af57d44e8218",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES ("bb2fe854-52e1-4b42-920f-0fe78efd4ece",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"69ecc5b2-922c-4041-926e-59e2fe990d71",
	35,
	1,
	'setz4_spectrum line: 35');
INSERT INTO ACT_TFM
	VALUES ("bb2fe854-52e1-4b42-920f-0fe78efd4ece",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	35,
	7,
	35,
	1);
INSERT INTO ACT_SMT
	VALUES ("69ecc5b2-922c-4041-926e-59e2fe990d71",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"dc885afd-ccad-4e59-8230-b6bb8a7b8262",
	36,
	1,
	'setz4_spectrum line: 36');
INSERT INTO ACT_TFM
	VALUES ("69ecc5b2-922c-4041-926e-59e2fe990d71",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES ("dc885afd-ccad-4e59-8230-b6bb8a7b8262",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5",
	"00000000-0000-0000-0000-000000000000",
	37,
	1,
	'setz4_spectrum line: 37');
INSERT INTO ACT_TFM
	VALUES ("dc885afd-ccad-4e59-8230-b6bb8a7b8262",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	"00000000-0000-0000-0000-000000000000",
	37,
	7,
	37,
	1);
INSERT INTO V_VAL
	VALUES ("3b636813-f624-456d-8dc5-ad2cdee0d181",
	0,
	0,
	2,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("3b636813-f624-456d-8dc5-ad2cdee0d181",
	'1');
INSERT INTO V_PAR
	VALUES ("3b636813-f624-456d-8dc5-ad2cdee0d181",
	"771b3d3b-4ba1-4169-adce-bae7e6ef1fa2",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"85a1b8a3-269b-45f3-848e-2b53abcec26f",
	2,
	18);
INSERT INTO V_VAL
	VALUES ("85a1b8a3-269b-45f3-848e-2b53abcec26f",
	0,
	0,
	2,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("85a1b8a3-269b-45f3-848e-2b53abcec26f",
	'5');
INSERT INTO V_PAR
	VALUES ("85a1b8a3-269b-45f3-848e-2b53abcec26f",
	"771b3d3b-4ba1-4169-adce-bae7e6ef1fa2",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"182ab1d8-0010-4c58-958e-b94129bb2ad8",
	2,
	25);
INSERT INTO V_VAL
	VALUES ("182ab1d8-0010-4c58-958e-b94129bb2ad8",
	0,
	0,
	2,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("182ab1d8-0010-4c58-958e-b94129bb2ad8",
	'8');
INSERT INTO V_PAR
	VALUES ("182ab1d8-0010-4c58-958e-b94129bb2ad8",
	"771b3d3b-4ba1-4169-adce-bae7e6ef1fa2",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	2,
	35);
INSERT INTO V_VAL
	VALUES ("3ca3c347-f9d0-44a9-bf4c-a885d6324079",
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("3ca3c347-f9d0-44a9-bf4c-a885d6324079",
	'1');
INSERT INTO V_PAR
	VALUES ("3ca3c347-f9d0-44a9-bf4c-a885d6324079",
	"1d1b20cd-e4a6-4b49-8d04-8c6715ad3416",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"61b2c5c1-ce27-4aef-b142-c4bffc2798dc",
	3,
	18);
INSERT INTO V_VAL
	VALUES ("61b2c5c1-ce27-4aef-b142-c4bffc2798dc",
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("61b2c5c1-ce27-4aef-b142-c4bffc2798dc",
	'6');
INSERT INTO V_PAR
	VALUES ("61b2c5c1-ce27-4aef-b142-c4bffc2798dc",
	"1d1b20cd-e4a6-4b49-8d04-8c6715ad3416",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"63de1dd3-4f23-4029-8504-e409c771eeec",
	3,
	25);
INSERT INTO V_VAL
	VALUES ("63de1dd3-4f23-4029-8504-e409c771eeec",
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("63de1dd3-4f23-4029-8504-e409c771eeec",
	'3');
INSERT INTO V_PAR
	VALUES ("63de1dd3-4f23-4029-8504-e409c771eeec",
	"1d1b20cd-e4a6-4b49-8d04-8c6715ad3416",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	3,
	35);
INSERT INTO V_VAL
	VALUES ("a187b8c1-aa69-417b-8bdd-1d4e7a5b1c4e",
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("a187b8c1-aa69-417b-8bdd-1d4e7a5b1c4e",
	'1');
INSERT INTO V_PAR
	VALUES ("a187b8c1-aa69-417b-8bdd-1d4e7a5b1c4e",
	"858d435f-af98-4c2b-bda8-7d8f685e2d86",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"28c92401-073a-4d2a-8f7a-f72f609b4d94",
	4,
	18);
INSERT INTO V_VAL
	VALUES ("28c92401-073a-4d2a-8f7a-f72f609b4d94",
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("28c92401-073a-4d2a-8f7a-f72f609b4d94",
	'7');
INSERT INTO V_PAR
	VALUES ("28c92401-073a-4d2a-8f7a-f72f609b4d94",
	"858d435f-af98-4c2b-bda8-7d8f685e2d86",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f75cb5ef-e26d-486a-b154-a0c5ca4d9f60",
	4,
	25);
INSERT INTO V_VAL
	VALUES ("f75cb5ef-e26d-486a-b154-a0c5ca4d9f60",
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("f75cb5ef-e26d-486a-b154-a0c5ca4d9f60",
	'4');
INSERT INTO V_PAR
	VALUES ("f75cb5ef-e26d-486a-b154-a0c5ca4d9f60",
	"858d435f-af98-4c2b-bda8-7d8f685e2d86",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	4,
	35);
INSERT INTO V_VAL
	VALUES ("8f44671c-c9ff-49d3-b9c4-05968a366e7c",
	0,
	0,
	6,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("8f44671c-c9ff-49d3-b9c4-05968a366e7c",
	'2');
INSERT INTO V_PAR
	VALUES ("8f44671c-c9ff-49d3-b9c4-05968a366e7c",
	"5e12f679-4d60-4d11-a0a0-f1fd588e3cb9",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"6ed4027c-8b92-4303-9520-79a18439977c",
	6,
	18);
INSERT INTO V_VAL
	VALUES ("6ed4027c-8b92-4303-9520-79a18439977c",
	0,
	0,
	6,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("6ed4027c-8b92-4303-9520-79a18439977c",
	'1');
INSERT INTO V_PAR
	VALUES ("6ed4027c-8b92-4303-9520-79a18439977c",
	"5e12f679-4d60-4d11-a0a0-f1fd588e3cb9",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"b550a91d-a866-4390-a1c3-0eaf339deb05",
	6,
	25);
INSERT INTO V_VAL
	VALUES ("b550a91d-a866-4390-a1c3-0eaf339deb05",
	0,
	0,
	6,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("b550a91d-a866-4390-a1c3-0eaf339deb05",
	'3');
INSERT INTO V_PAR
	VALUES ("b550a91d-a866-4390-a1c3-0eaf339deb05",
	"5e12f679-4d60-4d11-a0a0-f1fd588e3cb9",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	6,
	35);
INSERT INTO V_VAL
	VALUES ("0cc8aaa5-4506-4298-8c4d-128cbcc73ed0",
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("0cc8aaa5-4506-4298-8c4d-128cbcc73ed0",
	'2');
INSERT INTO V_PAR
	VALUES ("0cc8aaa5-4506-4298-8c4d-128cbcc73ed0",
	"3b8d76e7-72fb-4a48-912f-d6711ffdf08e",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7634bba9-a7b4-4a19-b9d6-e4d5eb8131ac",
	7,
	18);
INSERT INTO V_VAL
	VALUES ("7634bba9-a7b4-4a19-b9d6-e4d5eb8131ac",
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("7634bba9-a7b4-4a19-b9d6-e4d5eb8131ac",
	'6');
INSERT INTO V_PAR
	VALUES ("7634bba9-a7b4-4a19-b9d6-e4d5eb8131ac",
	"3b8d76e7-72fb-4a48-912f-d6711ffdf08e",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"95a5d496-681c-4c58-8d0e-50637b460d34",
	7,
	25);
INSERT INTO V_VAL
	VALUES ("95a5d496-681c-4c58-8d0e-50637b460d34",
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("95a5d496-681c-4c58-8d0e-50637b460d34",
	'4');
INSERT INTO V_PAR
	VALUES ("95a5d496-681c-4c58-8d0e-50637b460d34",
	"3b8d76e7-72fb-4a48-912f-d6711ffdf08e",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	7,
	35);
INSERT INTO V_VAL
	VALUES ("336a3e66-8c17-47fa-bcb9-65adec6d366c",
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("336a3e66-8c17-47fa-bcb9-65adec6d366c",
	'2');
INSERT INTO V_PAR
	VALUES ("336a3e66-8c17-47fa-bcb9-65adec6d366c",
	"8d16b764-40d7-4a7b-9408-fdc61a079cfd",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"1b289746-eefc-48c4-9577-3ef78c113d47",
	8,
	18);
INSERT INTO V_VAL
	VALUES ("1b289746-eefc-48c4-9577-3ef78c113d47",
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("1b289746-eefc-48c4-9577-3ef78c113d47",
	'7');
INSERT INTO V_PAR
	VALUES ("1b289746-eefc-48c4-9577-3ef78c113d47",
	"8d16b764-40d7-4a7b-9408-fdc61a079cfd",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8fd7ab38-0767-47ef-bec8-53ab417f2293",
	8,
	25);
INSERT INTO V_VAL
	VALUES ("8fd7ab38-0767-47ef-bec8-53ab417f2293",
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("8fd7ab38-0767-47ef-bec8-53ab417f2293",
	'8');
INSERT INTO V_PAR
	VALUES ("8fd7ab38-0767-47ef-bec8-53ab417f2293",
	"8d16b764-40d7-4a7b-9408-fdc61a079cfd",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	8,
	35);
INSERT INTO V_VAL
	VALUES ("52d816c4-e28c-45df-96a9-3911167878ab",
	0,
	0,
	9,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("52d816c4-e28c-45df-96a9-3911167878ab",
	'2');
INSERT INTO V_PAR
	VALUES ("52d816c4-e28c-45df-96a9-3911167878ab",
	"72b5e150-a216-43c1-9bd6-1557d5afe8c8",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"c33455ee-ffaa-4fa7-b180-c73059469498",
	9,
	18);
INSERT INTO V_VAL
	VALUES ("c33455ee-ffaa-4fa7-b180-c73059469498",
	0,
	0,
	9,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("c33455ee-ffaa-4fa7-b180-c73059469498",
	'8');
INSERT INTO V_PAR
	VALUES ("c33455ee-ffaa-4fa7-b180-c73059469498",
	"72b5e150-a216-43c1-9bd6-1557d5afe8c8",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"ca96c895-a1ff-4ffd-8be3-e1ae59b57bb1",
	9,
	25);
INSERT INTO V_VAL
	VALUES ("ca96c895-a1ff-4ffd-8be3-e1ae59b57bb1",
	0,
	0,
	9,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("ca96c895-a1ff-4ffd-8be3-e1ae59b57bb1",
	'2');
INSERT INTO V_PAR
	VALUES ("ca96c895-a1ff-4ffd-8be3-e1ae59b57bb1",
	"72b5e150-a216-43c1-9bd6-1557d5afe8c8",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	9,
	35);
INSERT INTO V_VAL
	VALUES ("104b3a3a-9b02-456c-8b4a-ad33e45e5bf0",
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("104b3a3a-9b02-456c-8b4a-ad33e45e5bf0",
	'2');
INSERT INTO V_PAR
	VALUES ("104b3a3a-9b02-456c-8b4a-ad33e45e5bf0",
	"b492dd86-5917-4111-8068-fddd693b4936",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"3af2b77f-1eaf-4c57-ae3a-c51da575f200",
	10,
	18);
INSERT INTO V_VAL
	VALUES ("3af2b77f-1eaf-4c57-ae3a-c51da575f200",
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("3af2b77f-1eaf-4c57-ae3a-c51da575f200",
	'9');
INSERT INTO V_PAR
	VALUES ("3af2b77f-1eaf-4c57-ae3a-c51da575f200",
	"b492dd86-5917-4111-8068-fddd693b4936",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"89a9f8d5-d105-49df-95ac-36282f8ed1e6",
	10,
	25);
INSERT INTO V_VAL
	VALUES ("89a9f8d5-d105-49df-95ac-36282f8ed1e6",
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("89a9f8d5-d105-49df-95ac-36282f8ed1e6",
	'1');
INSERT INTO V_PAR
	VALUES ("89a9f8d5-d105-49df-95ac-36282f8ed1e6",
	"b492dd86-5917-4111-8068-fddd693b4936",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	10,
	35);
INSERT INTO V_VAL
	VALUES ("ae0ba5d2-109d-4864-9290-abeca9e01e4c",
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("ae0ba5d2-109d-4864-9290-abeca9e01e4c",
	'3');
INSERT INTO V_PAR
	VALUES ("ae0ba5d2-109d-4864-9290-abeca9e01e4c",
	"826d238b-ef80-4e3f-abfd-b9a933ad11dd",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"ec1147fd-489c-4df9-8328-ed1f62cfe752",
	12,
	18);
INSERT INTO V_VAL
	VALUES ("ec1147fd-489c-4df9-8328-ed1f62cfe752",
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("ec1147fd-489c-4df9-8328-ed1f62cfe752",
	'1');
INSERT INTO V_PAR
	VALUES ("ec1147fd-489c-4df9-8328-ed1f62cfe752",
	"826d238b-ef80-4e3f-abfd-b9a933ad11dd",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"1e10d8c7-d430-4289-b2f6-219ca9d7d8c8",
	12,
	25);
INSERT INTO V_VAL
	VALUES ("1e10d8c7-d430-4289-b2f6-219ca9d7d8c8",
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("1e10d8c7-d430-4289-b2f6-219ca9d7d8c8",
	'7');
INSERT INTO V_PAR
	VALUES ("1e10d8c7-d430-4289-b2f6-219ca9d7d8c8",
	"826d238b-ef80-4e3f-abfd-b9a933ad11dd",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	12,
	35);
INSERT INTO V_VAL
	VALUES ("0bed872a-1705-43cb-8146-e30058d58feb",
	0,
	0,
	14,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("0bed872a-1705-43cb-8146-e30058d58feb",
	'4');
INSERT INTO V_PAR
	VALUES ("0bed872a-1705-43cb-8146-e30058d58feb",
	"bef05914-8b19-4d91-9480-2f2f306ef931",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4e0b21ec-b783-4301-a26b-20e87eaef53e",
	14,
	18);
INSERT INTO V_VAL
	VALUES ("4e0b21ec-b783-4301-a26b-20e87eaef53e",
	0,
	0,
	14,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("4e0b21ec-b783-4301-a26b-20e87eaef53e",
	'3');
INSERT INTO V_PAR
	VALUES ("4e0b21ec-b783-4301-a26b-20e87eaef53e",
	"bef05914-8b19-4d91-9480-2f2f306ef931",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"df223072-67cc-40a5-92be-14290a23a2d0",
	14,
	25);
INSERT INTO V_VAL
	VALUES ("df223072-67cc-40a5-92be-14290a23a2d0",
	0,
	0,
	14,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("df223072-67cc-40a5-92be-14290a23a2d0",
	'9');
INSERT INTO V_PAR
	VALUES ("df223072-67cc-40a5-92be-14290a23a2d0",
	"bef05914-8b19-4d91-9480-2f2f306ef931",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	14,
	35);
INSERT INTO V_VAL
	VALUES ("281925bb-1159-4124-aacd-4cc218372f8b",
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("281925bb-1159-4124-aacd-4cc218372f8b",
	'4');
INSERT INTO V_PAR
	VALUES ("281925bb-1159-4124-aacd-4cc218372f8b",
	"273daf24-0262-4a2a-8ce9-5bf3df60b0b6",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"96d5bebe-ed54-4ee5-93c1-6f238767d620",
	15,
	18);
INSERT INTO V_VAL
	VALUES ("96d5bebe-ed54-4ee5-93c1-6f238767d620",
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("96d5bebe-ed54-4ee5-93c1-6f238767d620",
	'4');
INSERT INTO V_PAR
	VALUES ("96d5bebe-ed54-4ee5-93c1-6f238767d620",
	"273daf24-0262-4a2a-8ce9-5bf3df60b0b6",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"bd7dc6c1-4d4b-4ba1-b550-59afd3565e56",
	15,
	25);
INSERT INTO V_VAL
	VALUES ("bd7dc6c1-4d4b-4ba1-b550-59afd3565e56",
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("bd7dc6c1-4d4b-4ba1-b550-59afd3565e56",
	'4');
INSERT INTO V_PAR
	VALUES ("bd7dc6c1-4d4b-4ba1-b550-59afd3565e56",
	"273daf24-0262-4a2a-8ce9-5bf3df60b0b6",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	15,
	35);
INSERT INTO V_VAL
	VALUES ("f86c12f3-4feb-4d6e-b53c-9235272a0700",
	0,
	0,
	16,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("f86c12f3-4feb-4d6e-b53c-9235272a0700",
	'4');
INSERT INTO V_PAR
	VALUES ("f86c12f3-4feb-4d6e-b53c-9235272a0700",
	"3b3523e6-1ed7-422c-b693-20172994043c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"5b313cfd-d249-41b8-bbac-953dc01901a1",
	16,
	18);
INSERT INTO V_VAL
	VALUES ("5b313cfd-d249-41b8-bbac-953dc01901a1",
	0,
	0,
	16,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("5b313cfd-d249-41b8-bbac-953dc01901a1",
	'6');
INSERT INTO V_PAR
	VALUES ("5b313cfd-d249-41b8-bbac-953dc01901a1",
	"3b3523e6-1ed7-422c-b693-20172994043c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"1376498f-de39-4bfd-86c7-c3494d567aa2",
	16,
	25);
INSERT INTO V_VAL
	VALUES ("1376498f-de39-4bfd-86c7-c3494d567aa2",
	0,
	0,
	16,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("1376498f-de39-4bfd-86c7-c3494d567aa2",
	'1');
INSERT INTO V_PAR
	VALUES ("1376498f-de39-4bfd-86c7-c3494d567aa2",
	"3b3523e6-1ed7-422c-b693-20172994043c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	16,
	35);
INSERT INTO V_VAL
	VALUES ("37f3c5c1-bfed-42e1-a4a7-b32b7e8154e9",
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("37f3c5c1-bfed-42e1-a4a7-b32b7e8154e9",
	'4');
INSERT INTO V_PAR
	VALUES ("37f3c5c1-bfed-42e1-a4a7-b32b7e8154e9",
	"55758027-04fe-45e3-89e5-d528defe829a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"daa9bea4-925f-43ee-a05a-044a740491ba",
	17,
	18);
INSERT INTO V_VAL
	VALUES ("daa9bea4-925f-43ee-a05a-044a740491ba",
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("daa9bea4-925f-43ee-a05a-044a740491ba",
	'8');
INSERT INTO V_PAR
	VALUES ("daa9bea4-925f-43ee-a05a-044a740491ba",
	"55758027-04fe-45e3-89e5-d528defe829a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"10267586-0b91-49bf-a8e7-8ff342097c41",
	17,
	25);
INSERT INTO V_VAL
	VALUES ("10267586-0b91-49bf-a8e7-8ff342097c41",
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("10267586-0b91-49bf-a8e7-8ff342097c41",
	'8');
INSERT INTO V_PAR
	VALUES ("10267586-0b91-49bf-a8e7-8ff342097c41",
	"55758027-04fe-45e3-89e5-d528defe829a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	17,
	35);
INSERT INTO V_VAL
	VALUES ("f1968bed-786b-40d4-9673-3e4947f3bcf7",
	0,
	0,
	18,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("f1968bed-786b-40d4-9673-3e4947f3bcf7",
	'4');
INSERT INTO V_PAR
	VALUES ("f1968bed-786b-40d4-9673-3e4947f3bcf7",
	"0f259e5d-5562-4f1a-aca6-8b8f7c2b5ebe",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"0f31c5a3-4402-4f37-b793-2c4a05a526ab",
	18,
	18);
INSERT INTO V_VAL
	VALUES ("0f31c5a3-4402-4f37-b793-2c4a05a526ab",
	0,
	0,
	18,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("0f31c5a3-4402-4f37-b793-2c4a05a526ab",
	'9');
INSERT INTO V_PAR
	VALUES ("0f31c5a3-4402-4f37-b793-2c4a05a526ab",
	"0f259e5d-5562-4f1a-aca6-8b8f7c2b5ebe",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"67b03b39-736a-4863-92aa-45f2e25d0c5f",
	18,
	25);
INSERT INTO V_VAL
	VALUES ("67b03b39-736a-4863-92aa-45f2e25d0c5f",
	0,
	0,
	18,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("67b03b39-736a-4863-92aa-45f2e25d0c5f",
	'3');
INSERT INTO V_PAR
	VALUES ("67b03b39-736a-4863-92aa-45f2e25d0c5f",
	"0f259e5d-5562-4f1a-aca6-8b8f7c2b5ebe",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	18,
	35);
INSERT INTO V_VAL
	VALUES ("b4d744c9-4d75-4566-9a00-4de7a444001f",
	0,
	0,
	21,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("b4d744c9-4d75-4566-9a00-4de7a444001f",
	'6');
INSERT INTO V_PAR
	VALUES ("b4d744c9-4d75-4566-9a00-4de7a444001f",
	"bc4b2f03-fa8d-4512-b9d5-df65540a9f16",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"f76af454-7a98-4208-adfc-9d78baff5320",
	21,
	18);
INSERT INTO V_VAL
	VALUES ("f76af454-7a98-4208-adfc-9d78baff5320",
	0,
	0,
	21,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("f76af454-7a98-4208-adfc-9d78baff5320",
	'1');
INSERT INTO V_PAR
	VALUES ("f76af454-7a98-4208-adfc-9d78baff5320",
	"bc4b2f03-fa8d-4512-b9d5-df65540a9f16",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"40f288b3-bbd8-43fb-9b34-7075bc381765",
	21,
	25);
INSERT INTO V_VAL
	VALUES ("40f288b3-bbd8-43fb-9b34-7075bc381765",
	0,
	0,
	21,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("40f288b3-bbd8-43fb-9b34-7075bc381765",
	'4');
INSERT INTO V_PAR
	VALUES ("40f288b3-bbd8-43fb-9b34-7075bc381765",
	"bc4b2f03-fa8d-4512-b9d5-df65540a9f16",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	21,
	35);
INSERT INTO V_VAL
	VALUES ("f4d2b342-73f7-493b-aca7-b722a62dec69",
	0,
	0,
	22,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("f4d2b342-73f7-493b-aca7-b722a62dec69",
	'6');
INSERT INTO V_PAR
	VALUES ("f4d2b342-73f7-493b-aca7-b722a62dec69",
	"324da7ee-2fcc-4209-ba27-1319c3e6adcc",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"ea4824b8-1dfa-4a9a-a7a9-ed969b7535e2",
	22,
	18);
INSERT INTO V_VAL
	VALUES ("ea4824b8-1dfa-4a9a-a7a9-ed969b7535e2",
	0,
	0,
	22,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("ea4824b8-1dfa-4a9a-a7a9-ed969b7535e2",
	'2');
INSERT INTO V_PAR
	VALUES ("ea4824b8-1dfa-4a9a-a7a9-ed969b7535e2",
	"324da7ee-2fcc-4209-ba27-1319c3e6adcc",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"2f34645c-5a4b-49e2-a1e8-d03ccba55c60",
	22,
	25);
INSERT INTO V_VAL
	VALUES ("2f34645c-5a4b-49e2-a1e8-d03ccba55c60",
	0,
	0,
	22,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("2f34645c-5a4b-49e2-a1e8-d03ccba55c60",
	'6');
INSERT INTO V_PAR
	VALUES ("2f34645c-5a4b-49e2-a1e8-d03ccba55c60",
	"324da7ee-2fcc-4209-ba27-1319c3e6adcc",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	22,
	35);
INSERT INTO V_VAL
	VALUES ("6acd262a-b074-4d44-a903-3f19ab2bb7c5",
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("6acd262a-b074-4d44-a903-3f19ab2bb7c5",
	'6');
INSERT INTO V_PAR
	VALUES ("6acd262a-b074-4d44-a903-3f19ab2bb7c5",
	"e223c8e2-1b20-4557-aebb-db99fcc27271",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"10cf7cc4-0fdd-4667-914a-733f9ed28c88",
	23,
	18);
INSERT INTO V_VAL
	VALUES ("10cf7cc4-0fdd-4667-914a-733f9ed28c88",
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("10cf7cc4-0fdd-4667-914a-733f9ed28c88",
	'4');
INSERT INTO V_PAR
	VALUES ("10cf7cc4-0fdd-4667-914a-733f9ed28c88",
	"e223c8e2-1b20-4557-aebb-db99fcc27271",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"7487ace4-20b1-4dfa-b918-9ff563da88bb",
	23,
	25);
INSERT INTO V_VAL
	VALUES ("7487ace4-20b1-4dfa-b918-9ff563da88bb",
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("7487ace4-20b1-4dfa-b918-9ff563da88bb",
	'5');
INSERT INTO V_PAR
	VALUES ("7487ace4-20b1-4dfa-b918-9ff563da88bb",
	"e223c8e2-1b20-4557-aebb-db99fcc27271",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	23,
	35);
INSERT INTO V_VAL
	VALUES ("72a9cc5d-1bc8-4136-92ba-ed8560310559",
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("72a9cc5d-1bc8-4136-92ba-ed8560310559",
	'6');
INSERT INTO V_PAR
	VALUES ("72a9cc5d-1bc8-4136-92ba-ed8560310559",
	"eab0581a-f2c2-40b5-8052-433915070d13",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"232c35b0-c615-43df-b860-e019257c1eef",
	24,
	18);
INSERT INTO V_VAL
	VALUES ("232c35b0-c615-43df-b860-e019257c1eef",
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("232c35b0-c615-43df-b860-e019257c1eef",
	'6');
INSERT INTO V_PAR
	VALUES ("232c35b0-c615-43df-b860-e019257c1eef",
	"eab0581a-f2c2-40b5-8052-433915070d13",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"6ca0297e-fc75-4b05-9c62-62f0d9c80342",
	24,
	25);
INSERT INTO V_VAL
	VALUES ("6ca0297e-fc75-4b05-9c62-62f0d9c80342",
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("6ca0297e-fc75-4b05-9c62-62f0d9c80342",
	'7');
INSERT INTO V_PAR
	VALUES ("6ca0297e-fc75-4b05-9c62-62f0d9c80342",
	"eab0581a-f2c2-40b5-8052-433915070d13",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	24,
	35);
INSERT INTO V_VAL
	VALUES ("48a8d90c-7c6b-457e-aeb7-b2a37ebc0bc7",
	0,
	0,
	25,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("48a8d90c-7c6b-457e-aeb7-b2a37ebc0bc7",
	'6');
INSERT INTO V_PAR
	VALUES ("48a8d90c-7c6b-457e-aeb7-b2a37ebc0bc7",
	"6d32f3ea-cc97-4d5f-bf94-09c115662ad8",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2d9e6159-a789-4caf-848a-780baa85cc73",
	25,
	18);
INSERT INTO V_VAL
	VALUES ("2d9e6159-a789-4caf-848a-780baa85cc73",
	0,
	0,
	25,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("2d9e6159-a789-4caf-848a-780baa85cc73",
	'7');
INSERT INTO V_PAR
	VALUES ("2d9e6159-a789-4caf-848a-780baa85cc73",
	"6d32f3ea-cc97-4d5f-bf94-09c115662ad8",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"d02bdc34-ffb2-4b4c-8095-2a4b20015484",
	25,
	25);
INSERT INTO V_VAL
	VALUES ("d02bdc34-ffb2-4b4c-8095-2a4b20015484",
	0,
	0,
	25,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("d02bdc34-ffb2-4b4c-8095-2a4b20015484",
	'1');
INSERT INTO V_PAR
	VALUES ("d02bdc34-ffb2-4b4c-8095-2a4b20015484",
	"6d32f3ea-cc97-4d5f-bf94-09c115662ad8",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	25,
	35);
INSERT INTO V_VAL
	VALUES ("35d9cd55-594c-4ff2-8c28-04a021afbc01",
	0,
	0,
	27,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("35d9cd55-594c-4ff2-8c28-04a021afbc01",
	'7');
INSERT INTO V_PAR
	VALUES ("35d9cd55-594c-4ff2-8c28-04a021afbc01",
	"b9e3c612-47ac-4a2c-98d6-6457f0dfc258",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"f235956f-7b5d-4b35-9d34-26416268446c",
	27,
	18);
INSERT INTO V_VAL
	VALUES ("f235956f-7b5d-4b35-9d34-26416268446c",
	0,
	0,
	27,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("f235956f-7b5d-4b35-9d34-26416268446c",
	'9');
INSERT INTO V_PAR
	VALUES ("f235956f-7b5d-4b35-9d34-26416268446c",
	"b9e3c612-47ac-4a2c-98d6-6457f0dfc258",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"4edbc6b2-9d1d-4ed0-9337-bc780a20c701",
	27,
	25);
INSERT INTO V_VAL
	VALUES ("4edbc6b2-9d1d-4ed0-9337-bc780a20c701",
	0,
	0,
	27,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("4edbc6b2-9d1d-4ed0-9337-bc780a20c701",
	'7');
INSERT INTO V_PAR
	VALUES ("4edbc6b2-9d1d-4ed0-9337-bc780a20c701",
	"b9e3c612-47ac-4a2c-98d6-6457f0dfc258",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	27,
	35);
INSERT INTO V_VAL
	VALUES ("3ce2b915-b6b3-40ed-8a9c-f24d27f131f3",
	0,
	0,
	29,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("3ce2b915-b6b3-40ed-8a9c-f24d27f131f3",
	'8');
INSERT INTO V_PAR
	VALUES ("3ce2b915-b6b3-40ed-8a9c-f24d27f131f3",
	"9be705a7-1f33-41f8-a8aa-5760ef3aa93a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2b2bbd70-4a79-4fdc-838f-3c7ce19c8674",
	29,
	18);
INSERT INTO V_VAL
	VALUES ("2b2bbd70-4a79-4fdc-838f-3c7ce19c8674",
	0,
	0,
	29,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("2b2bbd70-4a79-4fdc-838f-3c7ce19c8674",
	'1');
INSERT INTO V_PAR
	VALUES ("2b2bbd70-4a79-4fdc-838f-3c7ce19c8674",
	"9be705a7-1f33-41f8-a8aa-5760ef3aa93a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f27a3c47-27a8-4f34-aed0-ae2b9118c250",
	29,
	25);
INSERT INTO V_VAL
	VALUES ("f27a3c47-27a8-4f34-aed0-ae2b9118c250",
	0,
	0,
	29,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("f27a3c47-27a8-4f34-aed0-ae2b9118c250",
	'1');
INSERT INTO V_PAR
	VALUES ("f27a3c47-27a8-4f34-aed0-ae2b9118c250",
	"9be705a7-1f33-41f8-a8aa-5760ef3aa93a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	29,
	35);
INSERT INTO V_VAL
	VALUES ("8b4a4b53-9c91-4081-9602-9baccfe7eb04",
	0,
	0,
	30,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("8b4a4b53-9c91-4081-9602-9baccfe7eb04",
	'8');
INSERT INTO V_PAR
	VALUES ("8b4a4b53-9c91-4081-9602-9baccfe7eb04",
	"c833f123-af23-4848-b230-5817d55d65fe",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"8153081d-de29-4c74-a083-fce098cb0e5e",
	30,
	18);
INSERT INTO V_VAL
	VALUES ("8153081d-de29-4c74-a083-fce098cb0e5e",
	0,
	0,
	30,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("8153081d-de29-4c74-a083-fce098cb0e5e",
	'2');
INSERT INTO V_PAR
	VALUES ("8153081d-de29-4c74-a083-fce098cb0e5e",
	"c833f123-af23-4848-b230-5817d55d65fe",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"df84360c-a1b8-4f71-a4a4-a1d219cc7c70",
	30,
	25);
INSERT INTO V_VAL
	VALUES ("df84360c-a1b8-4f71-a4a4-a1d219cc7c70",
	0,
	0,
	30,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("df84360c-a1b8-4f71-a4a4-a1d219cc7c70",
	'2');
INSERT INTO V_PAR
	VALUES ("df84360c-a1b8-4f71-a4a4-a1d219cc7c70",
	"c833f123-af23-4848-b230-5817d55d65fe",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	30,
	35);
INSERT INTO V_VAL
	VALUES ("064c7185-c879-45f2-85ed-1a277561d68b",
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("064c7185-c879-45f2-85ed-1a277561d68b",
	'8');
INSERT INTO V_PAR
	VALUES ("064c7185-c879-45f2-85ed-1a277561d68b",
	"277aaa9d-5d0e-4496-98d4-98cd29fdbd80",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"ef12d0da-cd73-4d31-bd5e-4b8b6f4b8189",
	31,
	18);
INSERT INTO V_VAL
	VALUES ("ef12d0da-cd73-4d31-bd5e-4b8b6f4b8189",
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("ef12d0da-cd73-4d31-bd5e-4b8b6f4b8189",
	'3');
INSERT INTO V_PAR
	VALUES ("ef12d0da-cd73-4d31-bd5e-4b8b6f4b8189",
	"277aaa9d-5d0e-4496-98d4-98cd29fdbd80",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"9ae616d7-b02a-4540-b349-deb9e1cb80f9",
	31,
	25);
INSERT INTO V_VAL
	VALUES ("9ae616d7-b02a-4540-b349-deb9e1cb80f9",
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("9ae616d7-b02a-4540-b349-deb9e1cb80f9",
	'5');
INSERT INTO V_PAR
	VALUES ("9ae616d7-b02a-4540-b349-deb9e1cb80f9",
	"277aaa9d-5d0e-4496-98d4-98cd29fdbd80",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	31,
	35);
INSERT INTO V_VAL
	VALUES ("611521a3-fa65-4aeb-87b3-c386d6c6aa6e",
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("611521a3-fa65-4aeb-87b3-c386d6c6aa6e",
	'8');
INSERT INTO V_PAR
	VALUES ("611521a3-fa65-4aeb-87b3-c386d6c6aa6e",
	"ef104f20-21dd-4135-9afc-0949974585b8",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"80754e4b-b81c-4086-8e33-069e7c9ae582",
	32,
	18);
INSERT INTO V_VAL
	VALUES ("80754e4b-b81c-4086-8e33-069e7c9ae582",
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("80754e4b-b81c-4086-8e33-069e7c9ae582",
	'4');
INSERT INTO V_PAR
	VALUES ("80754e4b-b81c-4086-8e33-069e7c9ae582",
	"ef104f20-21dd-4135-9afc-0949974585b8",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"1b476aa9-11fa-4a2b-ba76-7b16f499647b",
	32,
	25);
INSERT INTO V_VAL
	VALUES ("1b476aa9-11fa-4a2b-ba76-7b16f499647b",
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("1b476aa9-11fa-4a2b-ba76-7b16f499647b",
	'3');
INSERT INTO V_PAR
	VALUES ("1b476aa9-11fa-4a2b-ba76-7b16f499647b",
	"ef104f20-21dd-4135-9afc-0949974585b8",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	32,
	35);
INSERT INTO V_VAL
	VALUES ("825486bf-2427-4938-8215-425f17681a88",
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("825486bf-2427-4938-8215-425f17681a88",
	'8');
INSERT INTO V_PAR
	VALUES ("825486bf-2427-4938-8215-425f17681a88",
	"5a122d4a-7978-4d75-a0ad-af57d44e8218",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"621abd3d-c01d-444f-8b51-f21738eeb9a8",
	33,
	18);
INSERT INTO V_VAL
	VALUES ("621abd3d-c01d-444f-8b51-f21738eeb9a8",
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("621abd3d-c01d-444f-8b51-f21738eeb9a8",
	'9');
INSERT INTO V_PAR
	VALUES ("621abd3d-c01d-444f-8b51-f21738eeb9a8",
	"5a122d4a-7978-4d75-a0ad-af57d44e8218",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"92171754-6088-45b7-9fdb-43778f622dbc",
	33,
	25);
INSERT INTO V_VAL
	VALUES ("92171754-6088-45b7-9fdb-43778f622dbc",
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("92171754-6088-45b7-9fdb-43778f622dbc",
	'9');
INSERT INTO V_PAR
	VALUES ("92171754-6088-45b7-9fdb-43778f622dbc",
	"5a122d4a-7978-4d75-a0ad-af57d44e8218",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	33,
	35);
INSERT INTO V_VAL
	VALUES ("40f18d0c-52b2-4d3d-a391-362ab1fa50a2",
	0,
	0,
	35,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("40f18d0c-52b2-4d3d-a391-362ab1fa50a2",
	'9');
INSERT INTO V_PAR
	VALUES ("40f18d0c-52b2-4d3d-a391-362ab1fa50a2",
	"bb2fe854-52e1-4b42-920f-0fe78efd4ece",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7d897875-1177-42b3-bc22-adf5777d32b9",
	35,
	18);
INSERT INTO V_VAL
	VALUES ("7d897875-1177-42b3-bc22-adf5777d32b9",
	0,
	0,
	35,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("7d897875-1177-42b3-bc22-adf5777d32b9",
	'3');
INSERT INTO V_PAR
	VALUES ("7d897875-1177-42b3-bc22-adf5777d32b9",
	"bb2fe854-52e1-4b42-920f-0fe78efd4ece",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"fe038972-67e0-438f-98d5-98887dc08a72",
	35,
	25);
INSERT INTO V_VAL
	VALUES ("fe038972-67e0-438f-98d5-98887dc08a72",
	0,
	0,
	35,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("fe038972-67e0-438f-98d5-98887dc08a72",
	'7');
INSERT INTO V_PAR
	VALUES ("fe038972-67e0-438f-98d5-98887dc08a72",
	"bb2fe854-52e1-4b42-920f-0fe78efd4ece",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	35,
	35);
INSERT INTO V_VAL
	VALUES ("c1f6df63-34c5-49a8-a70f-43efdfaa6599",
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("c1f6df63-34c5-49a8-a70f-43efdfaa6599",
	'9');
INSERT INTO V_PAR
	VALUES ("c1f6df63-34c5-49a8-a70f-43efdfaa6599",
	"69ecc5b2-922c-4041-926e-59e2fe990d71",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"c0ec1c5f-7ea2-437a-84a4-38d8bb6ebac9",
	36,
	18);
INSERT INTO V_VAL
	VALUES ("c0ec1c5f-7ea2-437a-84a4-38d8bb6ebac9",
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("c0ec1c5f-7ea2-437a-84a4-38d8bb6ebac9",
	'4');
INSERT INTO V_PAR
	VALUES ("c0ec1c5f-7ea2-437a-84a4-38d8bb6ebac9",
	"69ecc5b2-922c-4041-926e-59e2fe990d71",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"fe53b98f-6137-4030-ab6e-e375324d8b52",
	36,
	25);
INSERT INTO V_VAL
	VALUES ("fe53b98f-6137-4030-ab6e-e375324d8b52",
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("fe53b98f-6137-4030-ab6e-e375324d8b52",
	'2');
INSERT INTO V_PAR
	VALUES ("fe53b98f-6137-4030-ab6e-e375324d8b52",
	"69ecc5b2-922c-4041-926e-59e2fe990d71",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	36,
	35);
INSERT INTO V_VAL
	VALUES ("9cb9f552-a754-4e18-bcb0-64051b3ef1a2",
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("9cb9f552-a754-4e18-bcb0-64051b3ef1a2",
	'9');
INSERT INTO V_PAR
	VALUES ("9cb9f552-a754-4e18-bcb0-64051b3ef1a2",
	"dc885afd-ccad-4e59-8230-b6bb8a7b8262",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"014d70a5-227e-43b0-b042-67432d29b859",
	37,
	18);
INSERT INTO V_VAL
	VALUES ("014d70a5-227e-43b0-b042-67432d29b859",
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("014d70a5-227e-43b0-b042-67432d29b859",
	'5');
INSERT INTO V_PAR
	VALUES ("014d70a5-227e-43b0-b042-67432d29b859",
	"dc885afd-ccad-4e59-8230-b6bb8a7b8262",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"e7824406-3ff3-4066-9c98-0a6340efd9e2",
	37,
	25);
INSERT INTO V_VAL
	VALUES ("e7824406-3ff3-4066-9c98-0a6340efd9e2",
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2089ece1-fa65-40f9-bc1b-290e690fd3c5");
INSERT INTO V_LIN
	VALUES ("e7824406-3ff3-4066-9c98-0a6340efd9e2",
	'4');
INSERT INTO V_PAR
	VALUES ("e7824406-3ff3-4066-9c98-0a6340efd9e2",
	"dc885afd-ccad-4e59-8230-b6bb8a7b8262",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	37,
	35);
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"f1a6a34e-1aed-485d-ac48-328614a1378b");
INSERT INTO S_SYNC
	VALUES ("f1a6a34e-1aed-485d-ac48-328614a1378b",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'test',
	'',
	'// Run the puzzles we know about.
::setz1_given();
::solve();
::cleanup();

/*
::setup();
::setz2_given();
::solve();
::cleanup();

::setup();
::setz4_spectrum();
::solve();
::cleanup();
*/
',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("5960ecd8-84b7-4dbc-abaa-2c0c93f63ddc",
	"f1a6a34e-1aed-485d-ac48-328614a1378b");
INSERT INTO ACT_ACT
	VALUES ("5960ecd8-84b7-4dbc-abaa-2c0c93f63ddc",
	'function',
	0,
	"849bb12e-cd2e-42f9-995d-9bba6b009a18",
	"00000000-0000-0000-0000-000000000000",
	0,
	'test',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("849bb12e-cd2e-42f9-995d-9bba6b009a18",
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"5960ecd8-84b7-4dbc-abaa-2c0c93f63ddc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8f40858f-909d-43f6-abf2-e3a14a17f269",
	"849bb12e-cd2e-42f9-995d-9bba6b009a18",
	"c1d02a50-7979-4321-b94f-f8a194a238c4",
	2,
	1,
	'test line: 2');
INSERT INTO ACT_FNC
	VALUES ("8f40858f-909d-43f6-abf2-e3a14a17f269",
	"eac4991b-5f13-4165-af93-0cbd5fbd09ee",
	2,
	3);
INSERT INTO ACT_SMT
	VALUES ("c1d02a50-7979-4321-b94f-f8a194a238c4",
	"849bb12e-cd2e-42f9-995d-9bba6b009a18",
	"100b1562-74f9-4163-a5f0-5cc4e65a71b0",
	3,
	1,
	'test line: 3');
INSERT INTO ACT_FNC
	VALUES ("c1d02a50-7979-4321-b94f-f8a194a238c4",
	"836e2a9b-86e2-4c61-8e39-fa204d8644dd",
	3,
	3);
INSERT INTO ACT_SMT
	VALUES ("100b1562-74f9-4163-a5f0-5cc4e65a71b0",
	"849bb12e-cd2e-42f9-995d-9bba6b009a18",
	"00000000-0000-0000-0000-000000000000",
	4,
	1,
	'test line: 4');
INSERT INTO ACT_FNC
	VALUES ("100b1562-74f9-4163-a5f0-5cc4e65a71b0",
	"e267a797-d4ba-4fcd-8895-7508fac2ead0",
	4,
	3);
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"e267a797-d4ba-4fcd-8895-7508fac2ead0");
INSERT INTO S_SYNC
	VALUES ("e267a797-d4ba-4fcd-8895-7508fac2ead0",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'cleanup',
	'',
	'
// Clean up any and all eligible digits.
select many eligibles from instances of ELIGIBLE;
for each eligible in eligibles
  select one cell related by eligible->CELL[R8];
  select one digit related by eligible->DIGIT[R8];
  unrelate cell from digit across R8 using eligible;
  delete object instance eligible;
end for;

// Unrelate the answers.
select many cells from instances of CELL;
for each cell in cells
  select one digit related by cell->DIGIT[R9];
  if ( not_empty digit )
    unrelate cell from digit across R9;
  end if;
end for;

// Delete the digits.
select many digits from instances of DIGIT;
for each digit in digits
  delete object instance digit;
end for;

// Unrelate/delete the cells from the rows, columns and boxes.
// Unrelate/delete the sequences.
// Delete the cells while unrelating the boxes.
select many rows from instances of ROW;
for each row in rows
  select many cells related by row->CELL[R2];
  for each cell in cells
    unrelate row from cell across R2;
  end for;
  select one sequence related by row->SEQUENCE[R1];
  delete object instance sequence;
  delete object instance row;
end for;  
select many columns from instances of COLUMN;
for each column in columns
  select many cells related by column->CELL[R3];
  for each cell in cells
    unrelate column from cell across R3;
  end for;
  select one sequence related by column->SEQUENCE[R1];
  delete object instance sequence;
  delete object instance column;
end for;  
select many boxes from instances of BOX;
for each box in boxes
  select many cells related by box->CELL[R4];
  for each cell in cells
    unrelate box from cell across R4;
    delete object instance cell;
  end for;
  select one sequence related by box->SEQUENCE[R1];
  delete object instance sequence;
  delete object instance box;
end for;  
',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"e267a797-d4ba-4fcd-8895-7508fac2ead0");
INSERT INTO ACT_ACT
	VALUES ("ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	'function',
	0,
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cleanup',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("7dee5455-0530-4f6d-8884-5dcddd52c631",
	1,
	0,
	0,
	'',
	'',
	'',
	50,
	1,
	49,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0c5e496f-84f8-477f-8527-967123f1dc3e",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"bf4646e0-5fc9-4cca-8a51-2d3a52b447ad",
	3,
	1,
	'cleanup line: 3');
INSERT INTO ACT_FIO
	VALUES ("0c5e496f-84f8-477f-8527-967123f1dc3e",
	"a7df7d94-9686-4c6d-9a40-a8d613cd0a84",
	1,
	'many',
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	3,
	41);
INSERT INTO ACT_SMT
	VALUES ("bf4646e0-5fc9-4cca-8a51-2d3a52b447ad",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"02426d2f-bc3d-4c02-8b1a-2930d61f2708",
	4,
	1,
	'cleanup line: 4');
INSERT INTO ACT_FOR
	VALUES ("bf4646e0-5fc9-4cca-8a51-2d3a52b447ad",
	"94e23c54-fafa-4201-8ee4-fc24d6067c11",
	1,
	"a86b3260-0590-4bf8-ad6f-91846ac56fbf",
	"a7df7d94-9686-4c6d-9a40-a8d613cd0a84",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO ACT_SMT
	VALUES ("02426d2f-bc3d-4c02-8b1a-2930d61f2708",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"04da8a09-e012-4f36-88bd-e8b44feec7bf",
	12,
	1,
	'cleanup line: 12');
INSERT INTO ACT_FIO
	VALUES ("02426d2f-bc3d-4c02-8b1a-2930d61f2708",
	"da1f6670-8831-4811-8a54-bca0371333e9",
	1,
	'many',
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	12,
	37);
INSERT INTO ACT_SMT
	VALUES ("04da8a09-e012-4f36-88bd-e8b44feec7bf",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"7daaec74-eff6-4e4f-acc7-488979fbc325",
	13,
	1,
	'cleanup line: 13');
INSERT INTO ACT_FOR
	VALUES ("04da8a09-e012-4f36-88bd-e8b44feec7bf",
	"fb4d3b22-6b22-4bd6-a7cd-7b52c88f005e",
	1,
	"561c3392-a233-4856-a28e-ef7960e837b3",
	"da1f6670-8831-4811-8a54-bca0371333e9",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO ACT_SMT
	VALUES ("7daaec74-eff6-4e4f-acc7-488979fbc325",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"275da925-98ee-4171-b5a1-58a0b633a2d0",
	21,
	1,
	'cleanup line: 21');
INSERT INTO ACT_FIO
	VALUES ("7daaec74-eff6-4e4f-acc7-488979fbc325",
	"10a16e5f-b016-41e6-ab75-07dfd61f8d14",
	1,
	'many',
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	21,
	38);
INSERT INTO ACT_SMT
	VALUES ("275da925-98ee-4171-b5a1-58a0b633a2d0",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"d9f02914-e2e0-4caa-8fbf-6337192be6a8",
	22,
	1,
	'cleanup line: 22');
INSERT INTO ACT_FOR
	VALUES ("275da925-98ee-4171-b5a1-58a0b633a2d0",
	"0fa11745-489a-47a4-900f-d71ee7d1a34a",
	1,
	"2ab6ac8d-4414-4dfb-9849-621e9665f01c",
	"10a16e5f-b016-41e6-ab75-07dfd61f8d14",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO ACT_SMT
	VALUES ("d9f02914-e2e0-4caa-8fbf-6337192be6a8",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"a284888c-cbe8-4540-a1c0-c6089f1898c9",
	29,
	1,
	'cleanup line: 29');
INSERT INTO ACT_FIO
	VALUES ("d9f02914-e2e0-4caa-8fbf-6337192be6a8",
	"603e604b-cff7-4410-9eb8-281b91c14994",
	1,
	'many',
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	29,
	36);
INSERT INTO ACT_SMT
	VALUES ("a284888c-cbe8-4540-a1c0-c6089f1898c9",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"78068294-33bf-4dc4-ace6-0aa0c055e8b0",
	30,
	1,
	'cleanup line: 30');
INSERT INTO ACT_FOR
	VALUES ("a284888c-cbe8-4540-a1c0-c6089f1898c9",
	"2a1d405a-61d9-4f42-9f94-c7eb8a0a40ac",
	1,
	"a2c6a7a6-3807-4efc-a00b-166fca5bb159",
	"603e604b-cff7-4410-9eb8-281b91c14994",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO ACT_SMT
	VALUES ("78068294-33bf-4dc4-ace6-0aa0c055e8b0",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"d883289f-3456-4804-9c97-9a5b23f2d974",
	39,
	1,
	'cleanup line: 39');
INSERT INTO ACT_FIO
	VALUES ("78068294-33bf-4dc4-ace6-0aa0c055e8b0",
	"4b6a2991-a87d-4d51-aafd-aa4c24a41477",
	1,
	'many',
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	39,
	39);
INSERT INTO ACT_SMT
	VALUES ("d883289f-3456-4804-9c97-9a5b23f2d974",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"abf2276c-fee5-4016-a313-45d40cecacbd",
	40,
	1,
	'cleanup line: 40');
INSERT INTO ACT_FOR
	VALUES ("d883289f-3456-4804-9c97-9a5b23f2d974",
	"cd9ede86-01ed-42c5-96d6-ce9d6e743db5",
	1,
	"90b68bc2-55c3-4535-807a-b5ff812e9e9b",
	"4b6a2991-a87d-4d51-aafd-aa4c24a41477",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO ACT_SMT
	VALUES ("abf2276c-fee5-4016-a313-45d40cecacbd",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"8b8e80ea-ad96-4893-a2ff-942f855f4d64",
	49,
	1,
	'cleanup line: 49');
INSERT INTO ACT_FIO
	VALUES ("abf2276c-fee5-4016-a313-45d40cecacbd",
	"be9a367a-811d-47c0-b1d1-ccb22ccab2a0",
	1,
	'many',
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	49,
	37);
INSERT INTO ACT_SMT
	VALUES ("8b8e80ea-ad96-4893-a2ff-942f855f4d64",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	"00000000-0000-0000-0000-000000000000",
	50,
	1,
	'cleanup line: 50');
INSERT INTO ACT_FOR
	VALUES ("8b8e80ea-ad96-4893-a2ff-942f855f4d64",
	"8b92d1f8-031c-4760-b5ae-44f1c8435430",
	1,
	"9289d906-4e8a-4199-a6e1-53356053cc58",
	"be9a367a-811d-47c0-b1d1-ccb22ccab2a0",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_VAR
	VALUES ("a7df7d94-9686-4c6d-9a40-a8d613cd0a84",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'eligibles',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("a7df7d94-9686-4c6d-9a40-a8d613cd0a84",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("5bd980be-1ee5-4a8c-be6d-49f03f1d2613",
	3,
	13,
	21,
	"a7df7d94-9686-4c6d-9a40-a8d613cd0a84");
INSERT INTO V_LOC
	VALUES ("97a160f0-7541-463c-817d-e349ca11ad60",
	4,
	22,
	30,
	"a7df7d94-9686-4c6d-9a40-a8d613cd0a84");
INSERT INTO V_VAR
	VALUES ("a86b3260-0590-4bf8-ad6f-91846ac56fbf",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'eligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("a86b3260-0590-4bf8-ad6f-91846ac56fbf",
	1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("610a80c0-a9c0-453c-9bfa-35d7fde49c8d",
	4,
	10,
	17,
	"a86b3260-0590-4bf8-ad6f-91846ac56fbf");
INSERT INTO V_LOC
	VALUES ("24ecb4dd-d758-48b3-a033-98cbd8e80278",
	7,
	44,
	51,
	"a86b3260-0590-4bf8-ad6f-91846ac56fbf");
INSERT INTO V_LOC
	VALUES ("bc575eaf-97dc-4e4b-b681-6b568bbad807",
	8,
	26,
	33,
	"a86b3260-0590-4bf8-ad6f-91846ac56fbf");
INSERT INTO V_VAR
	VALUES ("da1f6670-8831-4811-8a54-bca0371333e9",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'cells',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("da1f6670-8831-4811-8a54-bca0371333e9",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("0f2a0eea-db96-479e-bfad-86e97391c56f",
	12,
	13,
	17,
	"da1f6670-8831-4811-8a54-bca0371333e9");
INSERT INTO V_LOC
	VALUES ("18b89afe-377d-4128-a400-97060aa10e4a",
	13,
	18,
	22,
	"da1f6670-8831-4811-8a54-bca0371333e9");
INSERT INTO V_LOC
	VALUES ("3ed17f22-7934-40b8-aa42-2d2c34517eb1",
	31,
	15,
	19,
	"da1f6670-8831-4811-8a54-bca0371333e9");
INSERT INTO V_LOC
	VALUES ("b9fd9e75-1c84-42db-8b09-2a635547872e",
	32,
	20,
	24,
	"da1f6670-8831-4811-8a54-bca0371333e9");
INSERT INTO V_LOC
	VALUES ("44ac3874-636d-42a4-8570-10a32a3d1066",
	41,
	15,
	19,
	"da1f6670-8831-4811-8a54-bca0371333e9");
INSERT INTO V_LOC
	VALUES ("13d65269-03c3-4215-bfde-8dabf92c012b",
	42,
	20,
	24,
	"da1f6670-8831-4811-8a54-bca0371333e9");
INSERT INTO V_LOC
	VALUES ("2ac0e161-970a-4ab2-88f1-6ec0caf02920",
	51,
	15,
	19,
	"da1f6670-8831-4811-8a54-bca0371333e9");
INSERT INTO V_LOC
	VALUES ("ab5e4c55-2293-4ae9-a914-9e26a3d9bb4d",
	52,
	20,
	24,
	"da1f6670-8831-4811-8a54-bca0371333e9");
INSERT INTO V_VAR
	VALUES ("561c3392-a233-4856-a28e-ef7960e837b3",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'cell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("561c3392-a233-4856-a28e-ef7960e837b3",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("59132f0d-a4fd-45fd-9b45-8333651e9e76",
	13,
	10,
	13,
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO V_LOC
	VALUES ("63b6c963-87d4-4713-93f5-2436f191ca0e",
	16,
	14,
	17,
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO V_LOC
	VALUES ("0ba77eb3-c0d0-4834-bf78-2ec67a1f740f",
	32,
	12,
	15,
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO V_LOC
	VALUES ("c6d3b36c-7485-4a7e-8b2a-5e6de9db636e",
	33,
	23,
	26,
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO V_LOC
	VALUES ("a31bca8f-1f9d-4744-b52f-080dc1c4a12e",
	42,
	12,
	15,
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO V_LOC
	VALUES ("4193b3a6-ef8f-420d-8f76-7e509dad84d2",
	43,
	26,
	29,
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO V_LOC
	VALUES ("51fa6268-b8ec-4906-816c-98e429362b3d",
	52,
	12,
	15,
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO V_LOC
	VALUES ("89ef66cc-2250-43f8-9149-8cf447ee0db6",
	53,
	23,
	26,
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO V_LOC
	VALUES ("1dbf3888-57b8-44eb-b79a-971e26717de7",
	54,
	28,
	31,
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO V_VAR
	VALUES ("10a16e5f-b016-41e6-ab75-07dfd61f8d14",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'digits',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("10a16e5f-b016-41e6-ab75-07dfd61f8d14",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("47b7b744-178b-4deb-900d-eea35e2345ae",
	21,
	13,
	18,
	"10a16e5f-b016-41e6-ab75-07dfd61f8d14");
INSERT INTO V_LOC
	VALUES ("37aabaa8-fa20-4765-a863-808327bd2955",
	22,
	19,
	24,
	"10a16e5f-b016-41e6-ab75-07dfd61f8d14");
INSERT INTO V_VAR
	VALUES ("2ab6ac8d-4414-4dfb-9849-621e9665f01c",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'digit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("2ab6ac8d-4414-4dfb-9849-621e9665f01c",
	1,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("63fef4f1-3466-483d-b71b-9d8241d76e05",
	22,
	10,
	14,
	"2ab6ac8d-4414-4dfb-9849-621e9665f01c");
INSERT INTO V_LOC
	VALUES ("9ace9d9b-99e3-489f-8f90-66630da57325",
	23,
	26,
	30,
	"2ab6ac8d-4414-4dfb-9849-621e9665f01c");
INSERT INTO V_VAR
	VALUES ("603e604b-cff7-4410-9eb8-281b91c14994",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'rows',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("603e604b-cff7-4410-9eb8-281b91c14994",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("62b4fd8e-96a4-4d30-9285-ce1e2c0e59fb",
	29,
	13,
	16,
	"603e604b-cff7-4410-9eb8-281b91c14994");
INSERT INTO V_LOC
	VALUES ("19171bcd-63d9-4d19-bca0-d875012eb569",
	30,
	17,
	20,
	"603e604b-cff7-4410-9eb8-281b91c14994");
INSERT INTO V_VAR
	VALUES ("a2c6a7a6-3807-4efc-a00b-166fca5bb159",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'row',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("a2c6a7a6-3807-4efc-a00b-166fca5bb159",
	1,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("37844d15-a39e-4e10-96a8-d39e8a14ca9f",
	30,
	10,
	12,
	"a2c6a7a6-3807-4efc-a00b-166fca5bb159");
INSERT INTO V_LOC
	VALUES ("af450cd3-768f-40f4-8f67-fb951d71c4b0",
	33,
	14,
	16,
	"a2c6a7a6-3807-4efc-a00b-166fca5bb159");
INSERT INTO V_LOC
	VALUES ("d6c1359e-1e12-4f04-8f60-0ae1755bd958",
	37,
	26,
	28,
	"a2c6a7a6-3807-4efc-a00b-166fca5bb159");
INSERT INTO V_VAR
	VALUES ("4b6a2991-a87d-4d51-aafd-aa4c24a41477",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'columns',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("4b6a2991-a87d-4d51-aafd-aa4c24a41477",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_LOC
	VALUES ("4302ff14-8673-4167-b5ee-62a139980c0a",
	39,
	13,
	19,
	"4b6a2991-a87d-4d51-aafd-aa4c24a41477");
INSERT INTO V_LOC
	VALUES ("59213e37-3c83-49c5-8a1d-472f83e2f51a",
	40,
	20,
	26,
	"4b6a2991-a87d-4d51-aafd-aa4c24a41477");
INSERT INTO V_VAR
	VALUES ("90b68bc2-55c3-4535-807a-b5ff812e9e9b",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'column',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("90b68bc2-55c3-4535-807a-b5ff812e9e9b",
	1,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_LOC
	VALUES ("496e422d-1f3c-43f5-93d3-cffd76f14d31",
	40,
	10,
	15,
	"90b68bc2-55c3-4535-807a-b5ff812e9e9b");
INSERT INTO V_LOC
	VALUES ("f65a247a-091a-4827-893f-128ba065666a",
	43,
	14,
	19,
	"90b68bc2-55c3-4535-807a-b5ff812e9e9b");
INSERT INTO V_LOC
	VALUES ("d6988a07-2a62-47e5-84b4-a3d6a32230c6",
	47,
	26,
	31,
	"90b68bc2-55c3-4535-807a-b5ff812e9e9b");
INSERT INTO V_VAR
	VALUES ("be9a367a-811d-47c0-b1d1-ccb22ccab2a0",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'boxes',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("be9a367a-811d-47c0-b1d1-ccb22ccab2a0",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("c91387d8-316d-4b90-bac5-5cee54dcdee3",
	49,
	13,
	17,
	"be9a367a-811d-47c0-b1d1-ccb22ccab2a0");
INSERT INTO V_LOC
	VALUES ("e6e169f9-59aa-4feb-8039-426c8a41012d",
	50,
	17,
	21,
	"be9a367a-811d-47c0-b1d1-ccb22ccab2a0");
INSERT INTO V_VAR
	VALUES ("9289d906-4e8a-4199-a6e1-53356053cc58",
	"7dee5455-0530-4f6d-8884-5dcddd52c631",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("9289d906-4e8a-4199-a6e1-53356053cc58",
	1,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("d61dbb31-5a0a-4598-b134-3936d949e05a",
	50,
	10,
	12,
	"9289d906-4e8a-4199-a6e1-53356053cc58");
INSERT INTO V_LOC
	VALUES ("eebf536f-08b0-425d-a271-235afc1f55f0",
	53,
	14,
	16,
	"9289d906-4e8a-4199-a6e1-53356053cc58");
INSERT INTO V_LOC
	VALUES ("22c282bd-b7a3-4017-abfa-a01b1740c2a4",
	58,
	26,
	28,
	"9289d906-4e8a-4199-a6e1-53356053cc58");
INSERT INTO ACT_BLK
	VALUES ("94e23c54-fafa-4201-8ee4-fc24d6067c11",
	1,
	0,
	0,
	'',
	'',
	'',
	8,
	3,
	6,
	41,
	0,
	0,
	7,
	35,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("348ff83d-c4a1-479d-b0ef-5eb00e8e85a6",
	"94e23c54-fafa-4201-8ee4-fc24d6067c11",
	"4b2ff9e4-ba0a-4d61-a8d0-c9d7d6aa4e4c",
	5,
	3,
	'cleanup line: 5');
INSERT INTO ACT_SEL
	VALUES ("348ff83d-c4a1-479d-b0ef-5eb00e8e85a6",
	"a6a95101-2061-4a61-86be-061b3b5a4846",
	1,
	'one',
	"6c201759-6d6b-4ac4-bbb1-233a492d7795");
INSERT INTO ACT_SR
	VALUES ("348ff83d-c4a1-479d-b0ef-5eb00e8e85a6");
INSERT INTO ACT_LNK
	VALUES ("735ae1ad-3d5a-49c7-ba4e-5637d3e10eb2",
	'',
	"348ff83d-c4a1-479d-b0ef-5eb00e8e85a6",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("4b2ff9e4-ba0a-4d61-a8d0-c9d7d6aa4e4c",
	"94e23c54-fafa-4201-8ee4-fc24d6067c11",
	"26b2c4c9-419f-4a33-80a4-8f297f8a7391",
	6,
	3,
	'cleanup line: 6');
INSERT INTO ACT_SEL
	VALUES ("4b2ff9e4-ba0a-4d61-a8d0-c9d7d6aa4e4c",
	"934b6c7e-6e08-4ca2-a949-d749fc3811dd",
	1,
	'one',
	"e840104f-42d4-49c7-880a-24f5c9f84275");
INSERT INTO ACT_SR
	VALUES ("4b2ff9e4-ba0a-4d61-a8d0-c9d7d6aa4e4c");
INSERT INTO ACT_LNK
	VALUES ("1da75544-a30c-418e-99cb-f14edc538337",
	'',
	"4b2ff9e4-ba0a-4d61-a8d0-c9d7d6aa4e4c",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	6,
	41,
	6,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("26b2c4c9-419f-4a33-80a4-8f297f8a7391",
	"94e23c54-fafa-4201-8ee4-fc24d6067c11",
	"a2168258-ca01-48a9-be26-dbd64a22f434",
	7,
	3,
	'cleanup line: 7');
INSERT INTO ACT_URU
	VALUES ("26b2c4c9-419f-4a33-80a4-8f297f8a7391",
	"a6a95101-2061-4a61-86be-061b3b5a4846",
	"934b6c7e-6e08-4ca2-a949-d749fc3811dd",
	"a86b3260-0590-4bf8-ad6f-91846ac56fbf",
	'',
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	7,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a2168258-ca01-48a9-be26-dbd64a22f434",
	"94e23c54-fafa-4201-8ee4-fc24d6067c11",
	"00000000-0000-0000-0000-000000000000",
	8,
	3,
	'cleanup line: 8');
INSERT INTO ACT_DEL
	VALUES ("a2168258-ca01-48a9-be26-dbd64a22f434",
	"a86b3260-0590-4bf8-ad6f-91846ac56fbf");
INSERT INTO V_VAL
	VALUES ("6c201759-6d6b-4ac4-bbb1-233a492d7795",
	0,
	0,
	5,
	30,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"94e23c54-fafa-4201-8ee4-fc24d6067c11");
INSERT INTO V_IRF
	VALUES ("6c201759-6d6b-4ac4-bbb1-233a492d7795",
	"a86b3260-0590-4bf8-ad6f-91846ac56fbf");
INSERT INTO V_VAL
	VALUES ("e840104f-42d4-49c7-880a-24f5c9f84275",
	0,
	0,
	6,
	31,
	38,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"94e23c54-fafa-4201-8ee4-fc24d6067c11");
INSERT INTO V_IRF
	VALUES ("e840104f-42d4-49c7-880a-24f5c9f84275",
	"a86b3260-0590-4bf8-ad6f-91846ac56fbf");
INSERT INTO V_VAR
	VALUES ("a6a95101-2061-4a61-86be-061b3b5a4846",
	"94e23c54-fafa-4201-8ee4-fc24d6067c11",
	'cell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("a6a95101-2061-4a61-86be-061b3b5a4846",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("c7d1d99e-1900-4e00-bcbc-b53183c219db",
	5,
	14,
	17,
	"a6a95101-2061-4a61-86be-061b3b5a4846");
INSERT INTO V_LOC
	VALUES ("4a69bd51-0097-4ea8-8a98-38f337998fa6",
	7,
	12,
	15,
	"a6a95101-2061-4a61-86be-061b3b5a4846");
INSERT INTO V_VAR
	VALUES ("934b6c7e-6e08-4ca2-a949-d749fc3811dd",
	"94e23c54-fafa-4201-8ee4-fc24d6067c11",
	'digit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("934b6c7e-6e08-4ca2-a949-d749fc3811dd",
	0,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("5e17fc1d-77a0-4576-8ebd-3470854d7a21",
	6,
	14,
	18,
	"934b6c7e-6e08-4ca2-a949-d749fc3811dd");
INSERT INTO V_LOC
	VALUES ("16ed2703-f596-453b-9472-b86f09c61057",
	7,
	22,
	26,
	"934b6c7e-6e08-4ca2-a949-d749fc3811dd");
INSERT INTO ACT_BLK
	VALUES ("fb4d3b22-6b22-4bd6-a7cd-7b52c88f005e",
	1,
	0,
	0,
	'',
	'',
	'',
	15,
	3,
	14,
	37,
	0,
	0,
	14,
	43,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("17bea735-1d0e-40c7-9c32-74d6aac47c1b",
	"fb4d3b22-6b22-4bd6-a7cd-7b52c88f005e",
	"db51571a-7639-4ff3-933f-3a13910d7bb5",
	14,
	3,
	'cleanup line: 14');
INSERT INTO ACT_SEL
	VALUES ("17bea735-1d0e-40c7-9c32-74d6aac47c1b",
	"15195644-3b67-4479-8ac6-7a15899cff77",
	1,
	'one',
	"7919ec69-cdaf-460d-a60e-8a8f6bef77da");
INSERT INTO ACT_SR
	VALUES ("17bea735-1d0e-40c7-9c32-74d6aac47c1b");
INSERT INTO ACT_LNK
	VALUES ("498cc380-9bb8-4a3a-8046-9cd7a0038e95",
	'',
	"17bea735-1d0e-40c7-9c32-74d6aac47c1b",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"00000000-0000-0000-0000-000000000000",
	2,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	14,
	37,
	14,
	43,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("db51571a-7639-4ff3-933f-3a13910d7bb5",
	"fb4d3b22-6b22-4bd6-a7cd-7b52c88f005e",
	"00000000-0000-0000-0000-000000000000",
	15,
	3,
	'cleanup line: 15');
INSERT INTO ACT_IF
	VALUES ("db51571a-7639-4ff3-933f-3a13910d7bb5",
	"d8affc6c-1f13-423d-a568-a09ffe1199b3",
	"fac12608-f34a-4b14-a0e6-35ddc5600357",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("7919ec69-cdaf-460d-a60e-8a8f6bef77da",
	0,
	0,
	14,
	31,
	34,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"fb4d3b22-6b22-4bd6-a7cd-7b52c88f005e");
INSERT INTO V_IRF
	VALUES ("7919ec69-cdaf-460d-a60e-8a8f6bef77da",
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO V_VAL
	VALUES ("9ca327cd-d095-42ab-9974-9afd0721a3e7",
	0,
	0,
	15,
	18,
	22,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"fb4d3b22-6b22-4bd6-a7cd-7b52c88f005e");
INSERT INTO V_IRF
	VALUES ("9ca327cd-d095-42ab-9974-9afd0721a3e7",
	"15195644-3b67-4479-8ac6-7a15899cff77");
INSERT INTO V_VAL
	VALUES ("fac12608-f34a-4b14-a0e6-35ddc5600357",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"fb4d3b22-6b22-4bd6-a7cd-7b52c88f005e");
INSERT INTO V_UNY
	VALUES ("fac12608-f34a-4b14-a0e6-35ddc5600357",
	"9ca327cd-d095-42ab-9974-9afd0721a3e7",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("15195644-3b67-4479-8ac6-7a15899cff77",
	"fb4d3b22-6b22-4bd6-a7cd-7b52c88f005e",
	'digit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("15195644-3b67-4479-8ac6-7a15899cff77",
	0,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("6a1b09af-821a-4548-a7fa-1dc02f7631b0",
	14,
	14,
	18,
	"15195644-3b67-4479-8ac6-7a15899cff77");
INSERT INTO V_LOC
	VALUES ("6dce19bb-b296-4a8b-9a6d-2d6095f68ee4",
	16,
	24,
	28,
	"15195644-3b67-4479-8ac6-7a15899cff77");
INSERT INTO ACT_BLK
	VALUES ("d8affc6c-1f13-423d-a568-a09ffe1199b3",
	0,
	0,
	0,
	'',
	'',
	'',
	16,
	5,
	0,
	0,
	0,
	0,
	16,
	37,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("32cd45c9-7416-4c2c-91bb-df7711c70faf",
	"d8affc6c-1f13-423d-a568-a09ffe1199b3",
	"00000000-0000-0000-0000-000000000000",
	16,
	5,
	'cleanup line: 16');
INSERT INTO ACT_UNR
	VALUES ("32cd45c9-7416-4c2c-91bb-df7711c70faf",
	"561c3392-a233-4856-a28e-ef7960e837b3",
	"15195644-3b67-4479-8ac6-7a15899cff77",
	'',
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	16,
	37,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("0fa11745-489a-47a4-900f-d71ee7d1a34a",
	0,
	0,
	0,
	'',
	'',
	'',
	23,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e055ed79-5479-4576-9718-8bb08faaa4cf",
	"0fa11745-489a-47a4-900f-d71ee7d1a34a",
	"00000000-0000-0000-0000-000000000000",
	23,
	3,
	'cleanup line: 23');
INSERT INTO ACT_DEL
	VALUES ("e055ed79-5479-4576-9718-8bb08faaa4cf",
	"2ab6ac8d-4414-4dfb-9849-621e9665f01c");
INSERT INTO ACT_BLK
	VALUES ("2a1d405a-61d9-4f42-9f94-c7eb8a0a40ac",
	1,
	0,
	0,
	'',
	'',
	'',
	37,
	3,
	35,
	39,
	0,
	0,
	35,
	48,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("70211177-cf1b-4ea4-9aa1-e7b55acbfa73",
	"2a1d405a-61d9-4f42-9f94-c7eb8a0a40ac",
	"07c7ed8d-db7d-49c1-b332-1263229710e0",
	31,
	3,
	'cleanup line: 31');
INSERT INTO ACT_SEL
	VALUES ("70211177-cf1b-4ea4-9aa1-e7b55acbfa73",
	"da1f6670-8831-4811-8a54-bca0371333e9",
	0,
	'many',
	"485fb207-e68b-472b-b3e7-df62741f88ab");
INSERT INTO ACT_SR
	VALUES ("70211177-cf1b-4ea4-9aa1-e7b55acbfa73");
INSERT INTO ACT_LNK
	VALUES ("e479a4d7-8692-45b7-b080-0acbbc478cab",
	'',
	"70211177-cf1b-4ea4-9aa1-e7b55acbfa73",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"00000000-0000-0000-0000-000000000000",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	31,
	37,
	31,
	42,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("07c7ed8d-db7d-49c1-b332-1263229710e0",
	"2a1d405a-61d9-4f42-9f94-c7eb8a0a40ac",
	"fc8414ae-ee95-42fe-8291-d0c00bfd1d4b",
	32,
	3,
	'cleanup line: 32');
INSERT INTO ACT_FOR
	VALUES ("07c7ed8d-db7d-49c1-b332-1263229710e0",
	"16be52b0-37a1-4273-b15b-26e331abca0b",
	0,
	"561c3392-a233-4856-a28e-ef7960e837b3",
	"da1f6670-8831-4811-8a54-bca0371333e9",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO ACT_SMT
	VALUES ("fc8414ae-ee95-42fe-8291-d0c00bfd1d4b",
	"2a1d405a-61d9-4f42-9f94-c7eb8a0a40ac",
	"0cc2f61f-fda5-47a3-8d7f-43658fa8a22a",
	35,
	3,
	'cleanup line: 35');
INSERT INTO ACT_SEL
	VALUES ("fc8414ae-ee95-42fe-8291-d0c00bfd1d4b",
	"0e1e5ed0-c093-4a77-b174-5f76ce4da671",
	1,
	'one',
	"3d151370-8ba4-4825-97f1-b862abee7b47");
INSERT INTO ACT_SR
	VALUES ("fc8414ae-ee95-42fe-8291-d0c00bfd1d4b");
INSERT INTO ACT_LNK
	VALUES ("b789b86d-1afe-4966-a8f3-b4fc86703327",
	'',
	"fc8414ae-ee95-42fe-8291-d0c00bfd1d4b",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	35,
	39,
	35,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0cc2f61f-fda5-47a3-8d7f-43658fa8a22a",
	"2a1d405a-61d9-4f42-9f94-c7eb8a0a40ac",
	"50212837-a558-4189-9141-d39e4e110021",
	36,
	3,
	'cleanup line: 36');
INSERT INTO ACT_DEL
	VALUES ("0cc2f61f-fda5-47a3-8d7f-43658fa8a22a",
	"0e1e5ed0-c093-4a77-b174-5f76ce4da671");
INSERT INTO ACT_SMT
	VALUES ("50212837-a558-4189-9141-d39e4e110021",
	"2a1d405a-61d9-4f42-9f94-c7eb8a0a40ac",
	"00000000-0000-0000-0000-000000000000",
	37,
	3,
	'cleanup line: 37');
INSERT INTO ACT_DEL
	VALUES ("50212837-a558-4189-9141-d39e4e110021",
	"a2c6a7a6-3807-4efc-a00b-166fca5bb159");
INSERT INTO V_VAL
	VALUES ("485fb207-e68b-472b-b3e7-df62741f88ab",
	0,
	0,
	31,
	32,
	34,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"2a1d405a-61d9-4f42-9f94-c7eb8a0a40ac");
INSERT INTO V_IRF
	VALUES ("485fb207-e68b-472b-b3e7-df62741f88ab",
	"a2c6a7a6-3807-4efc-a00b-166fca5bb159");
INSERT INTO V_VAL
	VALUES ("3d151370-8ba4-4825-97f1-b862abee7b47",
	0,
	0,
	35,
	34,
	36,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"2a1d405a-61d9-4f42-9f94-c7eb8a0a40ac");
INSERT INTO V_IRF
	VALUES ("3d151370-8ba4-4825-97f1-b862abee7b47",
	"a2c6a7a6-3807-4efc-a00b-166fca5bb159");
INSERT INTO V_VAR
	VALUES ("0e1e5ed0-c093-4a77-b174-5f76ce4da671",
	"2a1d405a-61d9-4f42-9f94-c7eb8a0a40ac",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("0e1e5ed0-c093-4a77-b174-5f76ce4da671",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("a3b36604-d6a5-4d13-a30a-eb40292c8b2a",
	35,
	14,
	21,
	"0e1e5ed0-c093-4a77-b174-5f76ce4da671");
INSERT INTO V_LOC
	VALUES ("bd465335-f077-4499-961b-deac0f72067e",
	36,
	26,
	33,
	"0e1e5ed0-c093-4a77-b174-5f76ce4da671");
INSERT INTO ACT_BLK
	VALUES ("16be52b0-37a1-4273-b15b-26e331abca0b",
	0,
	0,
	0,
	'',
	'',
	'',
	33,
	5,
	0,
	0,
	0,
	0,
	33,
	35,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("6d475548-543c-4811-ae9b-6a590db070ba",
	"16be52b0-37a1-4273-b15b-26e331abca0b",
	"00000000-0000-0000-0000-000000000000",
	33,
	5,
	'cleanup line: 33');
INSERT INTO ACT_UNR
	VALUES ("6d475548-543c-4811-ae9b-6a590db070ba",
	"a2c6a7a6-3807-4efc-a00b-166fca5bb159",
	"561c3392-a233-4856-a28e-ef7960e837b3",
	'',
	"c9931c97-9acb-4b55-af72-81add52c1825",
	33,
	35,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("cd9ede86-01ed-42c5-96d6-ce9d6e743db5",
	1,
	0,
	0,
	'',
	'',
	'',
	47,
	3,
	45,
	42,
	0,
	0,
	45,
	51,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d500c3ea-c044-4088-83a2-e1dd4dfceed3",
	"cd9ede86-01ed-42c5-96d6-ce9d6e743db5",
	"8e2800b7-db45-400b-9207-9612f096f43e",
	41,
	3,
	'cleanup line: 41');
INSERT INTO ACT_SEL
	VALUES ("d500c3ea-c044-4088-83a2-e1dd4dfceed3",
	"da1f6670-8831-4811-8a54-bca0371333e9",
	0,
	'many',
	"fcd84c4f-e4e8-4a89-ba87-5a6ae53b512c");
INSERT INTO ACT_SR
	VALUES ("d500c3ea-c044-4088-83a2-e1dd4dfceed3");
INSERT INTO ACT_LNK
	VALUES ("3ad53e23-afa5-4aeb-bbc1-0a4dd609189e",
	'',
	"d500c3ea-c044-4088-83a2-e1dd4dfceed3",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"00000000-0000-0000-0000-000000000000",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	41,
	40,
	41,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8e2800b7-db45-400b-9207-9612f096f43e",
	"cd9ede86-01ed-42c5-96d6-ce9d6e743db5",
	"0169ee17-7913-4011-9717-34ab054c7767",
	42,
	3,
	'cleanup line: 42');
INSERT INTO ACT_FOR
	VALUES ("8e2800b7-db45-400b-9207-9612f096f43e",
	"4eab389c-e26f-46bb-bf38-a2b25be44d65",
	0,
	"561c3392-a233-4856-a28e-ef7960e837b3",
	"da1f6670-8831-4811-8a54-bca0371333e9",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO ACT_SMT
	VALUES ("0169ee17-7913-4011-9717-34ab054c7767",
	"cd9ede86-01ed-42c5-96d6-ce9d6e743db5",
	"2a577d45-7aa7-4862-9efd-44e8351fc96d",
	45,
	3,
	'cleanup line: 45');
INSERT INTO ACT_SEL
	VALUES ("0169ee17-7913-4011-9717-34ab054c7767",
	"9dd57224-131b-4169-b4a5-81a1ade21800",
	1,
	'one',
	"e9930caa-7dfb-40fa-b70f-2bc385463cec");
INSERT INTO ACT_SR
	VALUES ("0169ee17-7913-4011-9717-34ab054c7767");
INSERT INTO ACT_LNK
	VALUES ("37eeb212-e28a-4166-83ac-f5494c1f041d",
	'',
	"0169ee17-7913-4011-9717-34ab054c7767",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	45,
	42,
	45,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("2a577d45-7aa7-4862-9efd-44e8351fc96d",
	"cd9ede86-01ed-42c5-96d6-ce9d6e743db5",
	"7f603fd3-c528-4490-b180-e28602dc0fe9",
	46,
	3,
	'cleanup line: 46');
INSERT INTO ACT_DEL
	VALUES ("2a577d45-7aa7-4862-9efd-44e8351fc96d",
	"9dd57224-131b-4169-b4a5-81a1ade21800");
INSERT INTO ACT_SMT
	VALUES ("7f603fd3-c528-4490-b180-e28602dc0fe9",
	"cd9ede86-01ed-42c5-96d6-ce9d6e743db5",
	"00000000-0000-0000-0000-000000000000",
	47,
	3,
	'cleanup line: 47');
INSERT INTO ACT_DEL
	VALUES ("7f603fd3-c528-4490-b180-e28602dc0fe9",
	"90b68bc2-55c3-4535-807a-b5ff812e9e9b");
INSERT INTO V_VAL
	VALUES ("fcd84c4f-e4e8-4a89-ba87-5a6ae53b512c",
	0,
	0,
	41,
	32,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"cd9ede86-01ed-42c5-96d6-ce9d6e743db5");
INSERT INTO V_IRF
	VALUES ("fcd84c4f-e4e8-4a89-ba87-5a6ae53b512c",
	"90b68bc2-55c3-4535-807a-b5ff812e9e9b");
INSERT INTO V_VAL
	VALUES ("e9930caa-7dfb-40fa-b70f-2bc385463cec",
	0,
	0,
	45,
	34,
	39,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"cd9ede86-01ed-42c5-96d6-ce9d6e743db5");
INSERT INTO V_IRF
	VALUES ("e9930caa-7dfb-40fa-b70f-2bc385463cec",
	"90b68bc2-55c3-4535-807a-b5ff812e9e9b");
INSERT INTO V_VAR
	VALUES ("9dd57224-131b-4169-b4a5-81a1ade21800",
	"cd9ede86-01ed-42c5-96d6-ce9d6e743db5",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("9dd57224-131b-4169-b4a5-81a1ade21800",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("69585200-89ab-41b4-8d65-1e8f17ff319f",
	45,
	14,
	21,
	"9dd57224-131b-4169-b4a5-81a1ade21800");
INSERT INTO V_LOC
	VALUES ("ea163ddd-ca6b-4f0d-b931-67425755671b",
	46,
	26,
	33,
	"9dd57224-131b-4169-b4a5-81a1ade21800");
INSERT INTO ACT_BLK
	VALUES ("4eab389c-e26f-46bb-bf38-a2b25be44d65",
	0,
	0,
	0,
	'',
	'',
	'',
	43,
	5,
	0,
	0,
	0,
	0,
	43,
	38,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9b98e10d-d678-4090-a325-6648a624e62a",
	"4eab389c-e26f-46bb-bf38-a2b25be44d65",
	"00000000-0000-0000-0000-000000000000",
	43,
	5,
	'cleanup line: 43');
INSERT INTO ACT_UNR
	VALUES ("9b98e10d-d678-4090-a325-6648a624e62a",
	"90b68bc2-55c3-4535-807a-b5ff812e9e9b",
	"561c3392-a233-4856-a28e-ef7960e837b3",
	'',
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	43,
	38,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("8b92d1f8-031c-4760-b5ae-44f1c8435430",
	1,
	0,
	0,
	'',
	'',
	'',
	58,
	3,
	56,
	39,
	0,
	0,
	56,
	48,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b5ffbf5f-3265-4e71-961a-fb9f4f7753e1",
	"8b92d1f8-031c-4760-b5ae-44f1c8435430",
	"8281272b-cfee-4911-ac77-dab5d92ce1ec",
	51,
	3,
	'cleanup line: 51');
INSERT INTO ACT_SEL
	VALUES ("b5ffbf5f-3265-4e71-961a-fb9f4f7753e1",
	"da1f6670-8831-4811-8a54-bca0371333e9",
	0,
	'many',
	"e6d79fa9-5326-436c-8d8a-5ff0e37cb21c");
INSERT INTO ACT_SR
	VALUES ("b5ffbf5f-3265-4e71-961a-fb9f4f7753e1");
INSERT INTO ACT_LNK
	VALUES ("0acef47a-9e67-44d3-8f6c-c59d07a92f17",
	'',
	"b5ffbf5f-3265-4e71-961a-fb9f4f7753e1",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"00000000-0000-0000-0000-000000000000",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	51,
	37,
	51,
	42,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8281272b-cfee-4911-ac77-dab5d92ce1ec",
	"8b92d1f8-031c-4760-b5ae-44f1c8435430",
	"219f0ba1-95f4-4e7c-a183-0604cdc37dfa",
	52,
	3,
	'cleanup line: 52');
INSERT INTO ACT_FOR
	VALUES ("8281272b-cfee-4911-ac77-dab5d92ce1ec",
	"a2918bdb-38f5-4dc1-8123-d54d775cd191",
	0,
	"561c3392-a233-4856-a28e-ef7960e837b3",
	"da1f6670-8831-4811-8a54-bca0371333e9",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO ACT_SMT
	VALUES ("219f0ba1-95f4-4e7c-a183-0604cdc37dfa",
	"8b92d1f8-031c-4760-b5ae-44f1c8435430",
	"e59eb472-2406-4d0c-b718-51fa6df28768",
	56,
	3,
	'cleanup line: 56');
INSERT INTO ACT_SEL
	VALUES ("219f0ba1-95f4-4e7c-a183-0604cdc37dfa",
	"093b656e-e271-433d-bb27-8ce0ba32a45c",
	1,
	'one',
	"cbeb1c6b-7bbb-4674-b989-f4db3ac0a210");
INSERT INTO ACT_SR
	VALUES ("219f0ba1-95f4-4e7c-a183-0604cdc37dfa");
INSERT INTO ACT_LNK
	VALUES ("cabb0359-0524-46c5-9b3f-5969a988f3c8",
	'',
	"219f0ba1-95f4-4e7c-a183-0604cdc37dfa",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	56,
	39,
	56,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e59eb472-2406-4d0c-b718-51fa6df28768",
	"8b92d1f8-031c-4760-b5ae-44f1c8435430",
	"7edbefc3-de1b-4cd8-b69b-20e099474372",
	57,
	3,
	'cleanup line: 57');
INSERT INTO ACT_DEL
	VALUES ("e59eb472-2406-4d0c-b718-51fa6df28768",
	"093b656e-e271-433d-bb27-8ce0ba32a45c");
INSERT INTO ACT_SMT
	VALUES ("7edbefc3-de1b-4cd8-b69b-20e099474372",
	"8b92d1f8-031c-4760-b5ae-44f1c8435430",
	"00000000-0000-0000-0000-000000000000",
	58,
	3,
	'cleanup line: 58');
INSERT INTO ACT_DEL
	VALUES ("7edbefc3-de1b-4cd8-b69b-20e099474372",
	"9289d906-4e8a-4199-a6e1-53356053cc58");
INSERT INTO V_VAL
	VALUES ("e6d79fa9-5326-436c-8d8a-5ff0e37cb21c",
	0,
	0,
	51,
	32,
	34,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"8b92d1f8-031c-4760-b5ae-44f1c8435430");
INSERT INTO V_IRF
	VALUES ("e6d79fa9-5326-436c-8d8a-5ff0e37cb21c",
	"9289d906-4e8a-4199-a6e1-53356053cc58");
INSERT INTO V_VAL
	VALUES ("cbeb1c6b-7bbb-4674-b989-f4db3ac0a210",
	0,
	0,
	56,
	34,
	36,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"8b92d1f8-031c-4760-b5ae-44f1c8435430");
INSERT INTO V_IRF
	VALUES ("cbeb1c6b-7bbb-4674-b989-f4db3ac0a210",
	"9289d906-4e8a-4199-a6e1-53356053cc58");
INSERT INTO V_VAR
	VALUES ("093b656e-e271-433d-bb27-8ce0ba32a45c",
	"8b92d1f8-031c-4760-b5ae-44f1c8435430",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("093b656e-e271-433d-bb27-8ce0ba32a45c",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("eab09389-a898-4543-8dc4-a8f7edd43db9",
	56,
	14,
	21,
	"093b656e-e271-433d-bb27-8ce0ba32a45c");
INSERT INTO V_LOC
	VALUES ("1ec639df-1e25-4146-9d25-bccd1636a851",
	57,
	26,
	33,
	"093b656e-e271-433d-bb27-8ce0ba32a45c");
INSERT INTO ACT_BLK
	VALUES ("a2918bdb-38f5-4dc1-8123-d54d775cd191",
	0,
	0,
	0,
	'',
	'',
	'',
	54,
	5,
	0,
	0,
	0,
	0,
	53,
	35,
	0,
	0,
	0,
	0,
	0,
	"ddf1f004-0ab9-4a62-8113-7176f0a15b5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("07f00042-5936-439c-ad61-af7036cb1f04",
	"a2918bdb-38f5-4dc1-8123-d54d775cd191",
	"718f3c75-82ab-4640-9df1-1f28baefd2ac",
	53,
	5,
	'cleanup line: 53');
INSERT INTO ACT_UNR
	VALUES ("07f00042-5936-439c-ad61-af7036cb1f04",
	"9289d906-4e8a-4199-a6e1-53356053cc58",
	"561c3392-a233-4856-a28e-ef7960e837b3",
	'',
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	53,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("718f3c75-82ab-4640-9df1-1f28baefd2ac",
	"a2918bdb-38f5-4dc1-8123-d54d775cd191",
	"00000000-0000-0000-0000-000000000000",
	54,
	5,
	'cleanup line: 54');
INSERT INTO ACT_DEL
	VALUES ("718f3c75-82ab-4640-9df1-1f28baefd2ac",
	"561c3392-a233-4856-a28e-ef7960e837b3");
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"9d06c026-8e4f-4638-96fd-a161e2589df3");
INSERT INTO S_SYNC
	VALUES ("9d06c026-8e4f-4638-96fd-a161e2589df3",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'xit',
	'',
	'::cleanup();
ARCH::shutdown();',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("93c94fbd-ec8d-4419-be8d-24985d355bdc",
	"9d06c026-8e4f-4638-96fd-a161e2589df3");
INSERT INTO ACT_ACT
	VALUES ("93c94fbd-ec8d-4419-be8d-24985d355bdc",
	'function',
	0,
	"2ffe1b1e-e12b-4ab7-a8e4-a5acaebda3ae",
	"00000000-0000-0000-0000-000000000000",
	0,
	'xit',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("2ffe1b1e-e12b-4ab7-a8e4-a5acaebda3ae",
	0,
	0,
	0,
	'ARCH',
	'',
	'',
	2,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"93c94fbd-ec8d-4419-be8d-24985d355bdc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f5d08ce0-3638-4524-a59b-15db7d2b74f1",
	"2ffe1b1e-e12b-4ab7-a8e4-a5acaebda3ae",
	"7d8fe8ef-cf8f-4eb3-b664-16004c854b7e",
	1,
	1,
	'xit line: 1');
INSERT INTO ACT_FNC
	VALUES ("f5d08ce0-3638-4524-a59b-15db7d2b74f1",
	"e267a797-d4ba-4fcd-8895-7508fac2ead0",
	1,
	3);
INSERT INTO ACT_SMT
	VALUES ("7d8fe8ef-cf8f-4eb3-b664-16004c854b7e",
	"2ffe1b1e-e12b-4ab7-a8e4-a5acaebda3ae",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'xit line: 2');
INSERT INTO ACT_BRG
	VALUES ("7d8fe8ef-cf8f-4eb3-b664-16004c854b7e",
	"7f8d2590-a4fd-4b10-9b14-e1df75f77ae0",
	2,
	7,
	2,
	1);
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"3483e234-6a32-47b8-a45c-ff2fd22193a8");
INSERT INTO S_SYNC
	VALUES ("3483e234-6a32-47b8-a45c-ff2fd22193a8",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'cort',
	'',
	'',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("2ad35f7d-933a-4d89-91e6-c56172ce8a08",
	"3483e234-6a32-47b8-a45c-ff2fd22193a8");
INSERT INTO ACT_ACT
	VALUES ("2ad35f7d-933a-4d89-91e6-c56172ce8a08",
	'function',
	0,
	"4cc41b16-c95b-47a1-a0b1-0688bb1ec4be",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cort',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("4cc41b16-c95b-47a1-a0b1-0688bb1ec4be",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"2ad35f7d-933a-4d89-91e6-c56172ce8a08",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"601ee25f-c1d5-4cef-a1f0-e93f220df055");
INSERT INTO S_SYNC
	VALUES ("601ee25f-c1d5-4cef-a1f0-e93f220df055",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'solve_concurrently',
	'',
	'score = CELL::score();
::display();

select any row from instances of ROW;
generate ROW1:update() to row;',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("f650dcf6-fe63-4432-9799-179602c80267",
	"601ee25f-c1d5-4cef-a1f0-e93f220df055");
INSERT INTO ACT_ACT
	VALUES ("f650dcf6-fe63-4432-9799-179602c80267",
	'function',
	0,
	"8cb4a3cc-eac7-453e-b8b0-a39d14fd431d",
	"00000000-0000-0000-0000-000000000000",
	0,
	'solve_concurrently',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("8cb4a3cc-eac7-453e-b8b0-a39d14fd431d",
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	5,
	1,
	4,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f650dcf6-fe63-4432-9799-179602c80267",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3934d649-dac2-47c9-9d87-cfac157009f9",
	"8cb4a3cc-eac7-453e-b8b0-a39d14fd431d",
	"55cc9490-da8c-4193-8a94-9edf24a4e9ab",
	1,
	1,
	'solve_concurrently line: 1');
INSERT INTO ACT_AI
	VALUES ("3934d649-dac2-47c9-9d87-cfac157009f9",
	"99567a8a-36ea-4e0b-b811-89dba261554a",
	"f4a844a1-a60e-4370-995b-adf0ccfaeb8a",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("55cc9490-da8c-4193-8a94-9edf24a4e9ab",
	"8cb4a3cc-eac7-453e-b8b0-a39d14fd431d",
	"91acdbb6-075a-4919-aec2-51bc164ca31b",
	2,
	1,
	'solve_concurrently line: 2');
INSERT INTO ACT_FNC
	VALUES ("55cc9490-da8c-4193-8a94-9edf24a4e9ab",
	"ea7999d4-ad63-4a57-abe3-4a8224d30de0",
	2,
	3);
INSERT INTO ACT_SMT
	VALUES ("91acdbb6-075a-4919-aec2-51bc164ca31b",
	"8cb4a3cc-eac7-453e-b8b0-a39d14fd431d",
	"c4700370-1685-4dcc-9260-5307d5800d0b",
	4,
	1,
	'solve_concurrently line: 4');
INSERT INTO ACT_FIO
	VALUES ("91acdbb6-075a-4919-aec2-51bc164ca31b",
	"a618f00c-5edf-4c10-b124-f3b77d4bc83a",
	1,
	'any',
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	4,
	34);
INSERT INTO ACT_SMT
	VALUES ("c4700370-1685-4dcc-9260-5307d5800d0b",
	"8cb4a3cc-eac7-453e-b8b0-a39d14fd431d",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'solve_concurrently line: 5');
INSERT INTO E_ESS
	VALUES ("c4700370-1685-4dcc-9260-5307d5800d0b",
	1,
	0,
	5,
	10,
	5,
	15,
	4,
	34,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("c4700370-1685-4dcc-9260-5307d5800d0b");
INSERT INTO E_GSME
	VALUES ("c4700370-1685-4dcc-9260-5307d5800d0b",
	"3c0abb69-5aa0-487e-996b-7909858726cf",
	"07fc627f-b641-41fe-a1af-748fb116451e");
INSERT INTO E_GEN
	VALUES ("c4700370-1685-4dcc-9260-5307d5800d0b",
	"a618f00c-5edf-4c10-b124-f3b77d4bc83a");
INSERT INTO V_VAL
	VALUES ("f4a844a1-a60e-4370-995b-adf0ccfaeb8a",
	1,
	1,
	1,
	1,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"8cb4a3cc-eac7-453e-b8b0-a39d14fd431d");
INSERT INTO V_TVL
	VALUES ("f4a844a1-a60e-4370-995b-adf0ccfaeb8a",
	"729d42fc-1684-4038-9277-f13a37162884");
INSERT INTO V_VAL
	VALUES ("99567a8a-36ea-4e0b-b811-89dba261554a",
	0,
	0,
	1,
	15,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"8cb4a3cc-eac7-453e-b8b0-a39d14fd431d");
INSERT INTO V_TRV
	VALUES ("99567a8a-36ea-4e0b-b811-89dba261554a",
	"e7682414-c9d4-490e-84ef-68b46fb9a8f1",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	9);
INSERT INTO V_VAR
	VALUES ("729d42fc-1684-4038-9277-f13a37162884",
	"8cb4a3cc-eac7-453e-b8b0-a39d14fd431d",
	'score',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("729d42fc-1684-4038-9277-f13a37162884",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("34c58ccc-8ddd-4ea2-a7db-f34e18c13c5c",
	1,
	1,
	5,
	"729d42fc-1684-4038-9277-f13a37162884");
INSERT INTO V_VAR
	VALUES ("a618f00c-5edf-4c10-b124-f3b77d4bc83a",
	"8cb4a3cc-eac7-453e-b8b0-a39d14fd431d",
	'row',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("a618f00c-5edf-4c10-b124-f3b77d4bc83a",
	0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("c84c0135-c625-4e20-a0c9-9b849f4d691f",
	4,
	12,
	14,
	"a618f00c-5edf-4c10-b124-f3b77d4bc83a");
INSERT INTO V_LOC
	VALUES ("572cd777-7443-47fd-b606-7f404e09fc99",
	5,
	27,
	29,
	"a618f00c-5edf-4c10-b124-f3b77d4bc83a");
INSERT INTO S_FIP
	VALUES ("902fee5d-2cc1-44d8-a018-7d4ab96f184d",
	"84284394-5fac-4f2f-a0ed-ad21ca330f28");
INSERT INTO S_SYNC
	VALUES ("84284394-5fac-4f2f-a0ed-ad21ca330f28",
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	'check',
	'',
	'score = CELL::score();
if ( 81 == score )
  LOG::LogSuccess( message:"solved the puzzle" );
else
  LOG::LogFailure( message:"failed to solved the puzzle" );
end if;
::display();',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("31e73268-b7ea-4a94-9d07-5e92e0fb6ad2",
	"84284394-5fac-4f2f-a0ed-ad21ca330f28");
INSERT INTO ACT_ACT
	VALUES ("31e73268-b7ea-4a94-9d07-5e92e0fb6ad2",
	'function',
	0,
	"3d3e13a1-1171-4747-9735-c4760b992d59",
	"00000000-0000-0000-0000-000000000000",
	0,
	'check',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("3d3e13a1-1171-4747-9735-c4760b992d59",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	7,
	1,
	1,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"31e73268-b7ea-4a94-9d07-5e92e0fb6ad2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ed87072f-d6bd-454d-b714-5cc665ee4464",
	"3d3e13a1-1171-4747-9735-c4760b992d59",
	"8fc964eb-5b63-4734-8f34-7cabf5273314",
	1,
	1,
	'check line: 1');
INSERT INTO ACT_AI
	VALUES ("ed87072f-d6bd-454d-b714-5cc665ee4464",
	"ffac1c28-2b2a-48aa-8c1c-8f8f3f23c8ef",
	"08214dee-4d15-42cc-a089-b0063811b177",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8fc964eb-5b63-4734-8f34-7cabf5273314",
	"3d3e13a1-1171-4747-9735-c4760b992d59",
	"76d12927-a7ec-4947-991b-2b654f45ddb1",
	2,
	1,
	'check line: 2');
INSERT INTO ACT_IF
	VALUES ("8fc964eb-5b63-4734-8f34-7cabf5273314",
	"d0297daa-7a29-4774-821e-a5fd551071cb",
	"76f97640-3cdd-4078-8aa5-8785d314d20d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e68047bf-7ae4-41be-a54b-c2afc27eaaa7",
	"3d3e13a1-1171-4747-9735-c4760b992d59",
	"00000000-0000-0000-0000-000000000000",
	4,
	1,
	'check line: 4');
INSERT INTO ACT_E
	VALUES ("e68047bf-7ae4-41be-a54b-c2afc27eaaa7",
	"f32544e5-5d4d-4951-99a7-722e2106781c",
	"8fc964eb-5b63-4734-8f34-7cabf5273314");
INSERT INTO ACT_SMT
	VALUES ("76d12927-a7ec-4947-991b-2b654f45ddb1",
	"3d3e13a1-1171-4747-9735-c4760b992d59",
	"00000000-0000-0000-0000-000000000000",
	7,
	1,
	'check line: 7');
INSERT INTO ACT_FNC
	VALUES ("76d12927-a7ec-4947-991b-2b654f45ddb1",
	"ea7999d4-ad63-4a57-abe3-4a8224d30de0",
	7,
	3);
INSERT INTO V_VAL
	VALUES ("08214dee-4d15-42cc-a089-b0063811b177",
	1,
	1,
	1,
	1,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3d3e13a1-1171-4747-9735-c4760b992d59");
INSERT INTO V_TVL
	VALUES ("08214dee-4d15-42cc-a089-b0063811b177",
	"6ea6d236-8681-43fb-850b-177cc3289986");
INSERT INTO V_VAL
	VALUES ("ffac1c28-2b2a-48aa-8c1c-8f8f3f23c8ef",
	0,
	0,
	1,
	15,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3d3e13a1-1171-4747-9735-c4760b992d59");
INSERT INTO V_TRV
	VALUES ("ffac1c28-2b2a-48aa-8c1c-8f8f3f23c8ef",
	"e7682414-c9d4-490e-84ef-68b46fb9a8f1",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	9);
INSERT INTO V_VAL
	VALUES ("5878f4cf-3c3e-4db8-ba71-6de93eaa050e",
	0,
	0,
	2,
	6,
	7,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3d3e13a1-1171-4747-9735-c4760b992d59");
INSERT INTO V_LIN
	VALUES ("5878f4cf-3c3e-4db8-ba71-6de93eaa050e",
	'81');
INSERT INTO V_VAL
	VALUES ("76f97640-3cdd-4078-8aa5-8785d314d20d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"3d3e13a1-1171-4747-9735-c4760b992d59");
INSERT INTO V_BIN
	VALUES ("76f97640-3cdd-4078-8aa5-8785d314d20d",
	"f14785d0-5b02-4c8a-bc24-b4175fbf3cf1",
	"5878f4cf-3c3e-4db8-ba71-6de93eaa050e",
	'==');
INSERT INTO V_VAL
	VALUES ("f14785d0-5b02-4c8a-bc24-b4175fbf3cf1",
	0,
	0,
	2,
	12,
	16,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3d3e13a1-1171-4747-9735-c4760b992d59");
INSERT INTO V_TVL
	VALUES ("f14785d0-5b02-4c8a-bc24-b4175fbf3cf1",
	"6ea6d236-8681-43fb-850b-177cc3289986");
INSERT INTO V_VAR
	VALUES ("6ea6d236-8681-43fb-850b-177cc3289986",
	"3d3e13a1-1171-4747-9735-c4760b992d59",
	'score',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("6ea6d236-8681-43fb-850b-177cc3289986",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("4b500923-66f3-4a68-9c8a-36cacd503765",
	1,
	1,
	5,
	"6ea6d236-8681-43fb-850b-177cc3289986");
INSERT INTO V_LOC
	VALUES ("cb9164e2-3713-462d-96ae-a6deb4c440d6",
	2,
	12,
	16,
	"6ea6d236-8681-43fb-850b-177cc3289986");
INSERT INTO ACT_BLK
	VALUES ("d0297daa-7a29-4774-821e-a5fd551071cb",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	3,
	3,
	3,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"31e73268-b7ea-4a94-9d07-5e92e0fb6ad2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("683f51d2-4a54-4d4d-9c87-837a90b314ed",
	"d0297daa-7a29-4774-821e-a5fd551071cb",
	"00000000-0000-0000-0000-000000000000",
	3,
	3,
	'check line: 3');
INSERT INTO ACT_BRG
	VALUES ("683f51d2-4a54-4d4d-9c87-837a90b314ed",
	"c1b48c1e-b947-4620-bd45-5dfde8d96e53",
	3,
	8,
	3,
	3);
INSERT INTO V_VAL
	VALUES ("69251b17-a79e-4579-b0e5-fd20176922a8",
	0,
	0,
	3,
	28,
	45,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"d0297daa-7a29-4774-821e-a5fd551071cb");
INSERT INTO V_LST
	VALUES ("69251b17-a79e-4579-b0e5-fd20176922a8",
	'solved the puzzle');
INSERT INTO V_PAR
	VALUES ("69251b17-a79e-4579-b0e5-fd20176922a8",
	"683f51d2-4a54-4d4d-9c87-837a90b314ed",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	3,
	20);
INSERT INTO ACT_BLK
	VALUES ("f32544e5-5d4d-4951-99a7-722e2106781c",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	5,
	3,
	5,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"31e73268-b7ea-4a94-9d07-5e92e0fb6ad2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("01cfe8fa-c448-4249-a227-e9ed8d664c6d",
	"f32544e5-5d4d-4951-99a7-722e2106781c",
	"00000000-0000-0000-0000-000000000000",
	5,
	3,
	'check line: 5');
INSERT INTO ACT_BRG
	VALUES ("01cfe8fa-c448-4249-a227-e9ed8d664c6d",
	"ea25943b-c6c2-4423-922c-947a3cd960ad",
	5,
	8,
	5,
	3);
INSERT INTO V_VAL
	VALUES ("a47d00c7-1001-465c-bd2e-c8d30203506b",
	0,
	0,
	5,
	28,
	55,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"f32544e5-5d4d-4951-99a7-722e2106781c");
INSERT INTO V_LST
	VALUES ("a47d00c7-1001-465c-bd2e-c8d30203506b",
	'failed to solved the puzzle');
INSERT INTO V_PAR
	VALUES ("a47d00c7-1001-465c-bd2e-c8d30203506b",
	"01cfe8fa-c448-4249-a227-e9ed8d664c6d",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	5,
	20);
INSERT INTO S_SID
	VALUES ("0eb5e6c3-13b6-4550-b154-5d6824e51255",
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO S_SS
	VALUES ("3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1",
	'sudoku',
	'',
	'',
	0,
	"0eb5e6c3-13b6-4550-b154-5d6824e51255",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_OBJ
	VALUES ("83fd5a00-5820-4fb5-ade7-97f8217b945f",
	'box',
	4,
	'BOX',
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO O_TFR
	VALUES ("30f7d1fd-f731-455f-93b4-963d0aa6e745",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	'prune',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	1,
	'// Cut off eligible digits that match any answer digit for this sequence.

temperature = 0;
select many answerdigits related by self->CELL[R4]->DIGIT[R9] where ( selected.value != 0 );
select many eligibles related by self->CELL[R4]->ELIGIBLE[R8];
for each eligible in eligibles
  for each answerdigit in answerdigits
    if ( eligible.digit_value == answerdigit.value )
      select one opencell related by eligible->CELL[R8];
      if ( opencell.answer_value != eligible.digit_value )
        unrelate answerdigit from opencell across R8 using eligible;
        delete object instance eligible;
        //generate CELL1:eliminate( digit:answerdigit.value ) to opencell;
      end if;
      temperature = 1;
      break;
    end if;
  end for;
end for;
  
select many opencells related by self->CELL[R4]
  where ( selected.answer_value == 0 );
if ( empty opencells )
  temperature = 100;
end if;
for each opencell in opencells
  // Notice if we have the answer now.
  select many eligibles related by opencell->ELIGIBLE[R8];
  c = cardinality eligibles;
  if ( 1 == c )
    select any answer related by opencell->ELIGIBLE[R8];
    opencell.answer( answer_digit:answer.digit_value );
    //generate CELL2:answer( digit:answer.digit_value ) to opencell;
    temperature = 1;
  end if;
end for;

return temperature;
',
	1,
	'',
	"95951fd8-2a86-4a4a-b9aa-8e2e2e1bbd9b");
INSERT INTO ACT_OPB
	VALUES ("bf7d48fd-0b7b-4469-aaa5-02e39028d1f0",
	"30f7d1fd-f731-455f-93b4-963d0aa6e745");
INSERT INTO ACT_ACT
	VALUES ("bf7d48fd-0b7b-4469-aaa5-02e39028d1f0",
	'operation',
	0,
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	"00000000-0000-0000-0000-000000000000",
	0,
	'box::prune',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	1,
	0,
	1,
	'',
	'',
	'',
	38,
	1,
	21,
	40,
	0,
	0,
	21,
	45,
	0,
	0,
	0,
	0,
	0,
	"bf7d48fd-0b7b-4469-aaa5-02e39028d1f0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("146d414c-c07a-4bcc-97b5-093897961994",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	"ee76ac14-17ee-4af3-8c27-130e8dafd977",
	3,
	1,
	'box::prune line: 3');
INSERT INTO ACT_AI
	VALUES ("146d414c-c07a-4bcc-97b5-093897961994",
	"77cc3c5f-c523-4e77-93ef-908c6e4d711b",
	"d2c1cba4-a6a7-4bdc-a88c-b1053680fc5f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ee76ac14-17ee-4af3-8c27-130e8dafd977",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	"23fe9b8c-514f-4c33-9a70-bddd488407ac",
	4,
	1,
	'box::prune line: 4');
INSERT INTO ACT_SEL
	VALUES ("ee76ac14-17ee-4af3-8c27-130e8dafd977",
	"a26f2127-4c64-4c63-a87b-0ec68fd4897a",
	1,
	'many',
	"28d88e72-7efd-49af-92fe-bf2d44b86416");
INSERT INTO ACT_SRW
	VALUES ("ee76ac14-17ee-4af3-8c27-130e8dafd977",
	"753de55c-d162-43c4-b120-7bfa6e89a632");
INSERT INTO ACT_LNK
	VALUES ("3febe324-79b9-49fc-87a1-a0324d7dec39",
	'',
	"ee76ac14-17ee-4af3-8c27-130e8dafd977",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"2717e162-69fa-4091-abd3-21a4e519a899",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	4,
	43,
	4,
	48,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("2717e162-69fa-4091-abd3-21a4e519a899",
	'',
	"00000000-0000-0000-0000-000000000000",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"00000000-0000-0000-0000-000000000000",
	2,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	4,
	53,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("23fe9b8c-514f-4c33-9a70-bddd488407ac",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	"d5fffa2b-eaa8-49fb-b6b9-f8be94b0f218",
	5,
	1,
	'box::prune line: 5');
INSERT INTO ACT_SEL
	VALUES ("23fe9b8c-514f-4c33-9a70-bddd488407ac",
	"8f12d7dd-6492-463b-a384-89b98885acc6",
	1,
	'many',
	"1e2daf32-0e7a-4483-a998-26b2c8ced826");
INSERT INTO ACT_SR
	VALUES ("23fe9b8c-514f-4c33-9a70-bddd488407ac");
INSERT INTO ACT_LNK
	VALUES ("ada8dde1-3a3d-49ed-9282-936d05100640",
	'',
	"23fe9b8c-514f-4c33-9a70-bddd488407ac",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"477ee289-bca1-421b-9dbe-47c8a4fd3e6a",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("477ee289-bca1-421b-9dbe-47c8a4fd3e6a",
	'',
	"00000000-0000-0000-0000-000000000000",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d5fffa2b-eaa8-49fb-b6b9-f8be94b0f218",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	"3b0119bc-1fd8-4d0c-8a08-328c02895a0f",
	6,
	1,
	'box::prune line: 6');
INSERT INTO ACT_FOR
	VALUES ("d5fffa2b-eaa8-49fb-b6b9-f8be94b0f218",
	"821a81c7-b4e6-43cc-b13d-12b76efd3247",
	1,
	"c881e36a-6041-440b-b97c-659820e0a2d7",
	"8f12d7dd-6492-463b-a384-89b98885acc6",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO ACT_SMT
	VALUES ("3b0119bc-1fd8-4d0c-8a08-328c02895a0f",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	"56fd9470-753c-4847-b5b8-2b1e9b0504c4",
	21,
	1,
	'box::prune line: 21');
INSERT INTO ACT_SEL
	VALUES ("3b0119bc-1fd8-4d0c-8a08-328c02895a0f",
	"88feeb30-110d-4fa6-86cf-1704c39c8f86",
	1,
	'many',
	"2868df8a-47de-40af-8081-913418b0ca94");
INSERT INTO ACT_SRW
	VALUES ("3b0119bc-1fd8-4d0c-8a08-328c02895a0f",
	"de3c1d2f-f2e5-4054-bdb7-7641965506b9");
INSERT INTO ACT_LNK
	VALUES ("86565c44-a423-43ca-a962-5ebcf99c93a4",
	'',
	"3b0119bc-1fd8-4d0c-8a08-328c02895a0f",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"00000000-0000-0000-0000-000000000000",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	21,
	40,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("56fd9470-753c-4847-b5b8-2b1e9b0504c4",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	"0924ec9f-a072-4e8f-9261-8efc649a588b",
	23,
	1,
	'box::prune line: 23');
INSERT INTO ACT_IF
	VALUES ("56fd9470-753c-4847-b5b8-2b1e9b0504c4",
	"cc4d0d65-e47f-45fb-82a2-9f0895b1663c",
	"d832b374-e179-4ca3-a489-29673a692f42",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0924ec9f-a072-4e8f-9261-8efc649a588b",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	"ce0a060e-c86c-4366-9aec-a81ebdad5967",
	26,
	1,
	'box::prune line: 26');
INSERT INTO ACT_FOR
	VALUES ("0924ec9f-a072-4e8f-9261-8efc649a588b",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4",
	1,
	"d68725e4-40f1-4552-940d-c203e1c8e08e",
	"88feeb30-110d-4fa6-86cf-1704c39c8f86",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO ACT_SMT
	VALUES ("ce0a060e-c86c-4366-9aec-a81ebdad5967",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	"00000000-0000-0000-0000-000000000000",
	38,
	1,
	'box::prune line: 38');
INSERT INTO ACT_RET
	VALUES ("ce0a060e-c86c-4366-9aec-a81ebdad5967",
	"145faa54-ad9a-4e63-b83a-2086b8e79563");
INSERT INTO V_VAL
	VALUES ("d2c1cba4-a6a7-4bdc-a88c-b1053680fc5f",
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_TVL
	VALUES ("d2c1cba4-a6a7-4bdc-a88c-b1053680fc5f",
	"05140403-a2f8-4277-8b33-870e3118bda6");
INSERT INTO V_VAL
	VALUES ("77cc3c5f-c523-4e77-93ef-908c6e4d711b",
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_LIN
	VALUES ("77cc3c5f-c523-4e77-93ef-908c6e4d711b",
	'0');
INSERT INTO V_VAL
	VALUES ("28d88e72-7efd-49af-92fe-bf2d44b86416",
	0,
	0,
	4,
	37,
	40,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_IRF
	VALUES ("28d88e72-7efd-49af-92fe-bf2d44b86416",
	"2923d25c-69a5-4efd-ad93-bc8093716e43");
INSERT INTO V_VAL
	VALUES ("d1586a72-99a9-4246-b53c-dcd24c47dd7a",
	0,
	0,
	4,
	71,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_SLR
	VALUES ("d1586a72-99a9-4246-b53c-dcd24c47dd7a",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("1f3e8274-8e97-4084-84fb-5264b84a0f71",
	0,
	0,
	4,
	80,
	84,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_AVL
	VALUES ("1f3e8274-8e97-4084-84fb-5264b84a0f71",
	"d1586a72-99a9-4246-b53c-dcd24c47dd7a",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO V_VAL
	VALUES ("753de55c-d162-43c4-b120-7bfa6e89a632",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_BIN
	VALUES ("753de55c-d162-43c4-b120-7bfa6e89a632",
	"5718838b-78f7-4844-ba95-02b13413ea61",
	"1f3e8274-8e97-4084-84fb-5264b84a0f71",
	'!=');
INSERT INTO V_VAL
	VALUES ("5718838b-78f7-4844-ba95-02b13413ea61",
	0,
	0,
	4,
	89,
	89,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_LIN
	VALUES ("5718838b-78f7-4844-ba95-02b13413ea61",
	'0');
INSERT INTO V_VAL
	VALUES ("1e2daf32-0e7a-4483-a998-26b2c8ced826",
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_IRF
	VALUES ("1e2daf32-0e7a-4483-a998-26b2c8ced826",
	"2923d25c-69a5-4efd-ad93-bc8093716e43");
INSERT INTO V_VAL
	VALUES ("2868df8a-47de-40af-8081-913418b0ca94",
	0,
	0,
	21,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_IRF
	VALUES ("2868df8a-47de-40af-8081-913418b0ca94",
	"2923d25c-69a5-4efd-ad93-bc8093716e43");
INSERT INTO V_VAL
	VALUES ("051652bf-1081-4c82-a1b1-b3977960698b",
	0,
	0,
	22,
	11,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_SLR
	VALUES ("051652bf-1081-4c82-a1b1-b3977960698b",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("ef4a475e-3ed9-46c7-8f07-cf53f374b4df",
	0,
	0,
	22,
	20,
	31,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_AVL
	VALUES ("ef4a475e-3ed9-46c7-8f07-cf53f374b4df",
	"051652bf-1081-4c82-a1b1-b3977960698b",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"009f5557-7ee7-4e44-9444-4d92eb448359");
INSERT INTO V_VAL
	VALUES ("de3c1d2f-f2e5-4054-bdb7-7641965506b9",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_BIN
	VALUES ("de3c1d2f-f2e5-4054-bdb7-7641965506b9",
	"32cb0cd0-7e79-45b2-b4b4-07cbb60171ec",
	"ef4a475e-3ed9-46c7-8f07-cf53f374b4df",
	'==');
INSERT INTO V_VAL
	VALUES ("32cb0cd0-7e79-45b2-b4b4-07cbb60171ec",
	0,
	0,
	22,
	36,
	36,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_LIN
	VALUES ("32cb0cd0-7e79-45b2-b4b4-07cbb60171ec",
	'0');
INSERT INTO V_VAL
	VALUES ("36451f65-4057-4b7f-9668-bdbafaa8f0f0",
	0,
	0,
	23,
	12,
	20,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_ISR
	VALUES ("36451f65-4057-4b7f-9668-bdbafaa8f0f0",
	"88feeb30-110d-4fa6-86cf-1704c39c8f86");
INSERT INTO V_VAL
	VALUES ("d832b374-e179-4ca3-a489-29673a692f42",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_UNY
	VALUES ("d832b374-e179-4ca3-a489-29673a692f42",
	"36451f65-4057-4b7f-9668-bdbafaa8f0f0",
	'empty');
INSERT INTO V_VAL
	VALUES ("145faa54-ad9a-4e63-b83a-2086b8e79563",
	0,
	0,
	38,
	8,
	18,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35");
INSERT INTO V_TVL
	VALUES ("145faa54-ad9a-4e63-b83a-2086b8e79563",
	"05140403-a2f8-4277-8b33-870e3118bda6");
INSERT INTO V_VAR
	VALUES ("05140403-a2f8-4277-8b33-870e3118bda6",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	'temperature',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("05140403-a2f8-4277-8b33-870e3118bda6",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("138d52bd-34f3-4250-8480-f2fa1bab3488",
	3,
	1,
	11,
	"05140403-a2f8-4277-8b33-870e3118bda6");
INSERT INTO V_LOC
	VALUES ("f32eb5e7-91d1-4f93-bcc7-8bc58adb9092",
	15,
	7,
	17,
	"05140403-a2f8-4277-8b33-870e3118bda6");
INSERT INTO V_LOC
	VALUES ("43ccaf9c-d3af-46a5-a559-fc477cf2e71d",
	24,
	3,
	13,
	"05140403-a2f8-4277-8b33-870e3118bda6");
INSERT INTO V_LOC
	VALUES ("b2914583-44ab-4842-bedf-3f3b97d0fa58",
	34,
	5,
	15,
	"05140403-a2f8-4277-8b33-870e3118bda6");
INSERT INTO V_LOC
	VALUES ("47690308-6b8d-4c68-896d-a142a0db3c3c",
	38,
	8,
	18,
	"05140403-a2f8-4277-8b33-870e3118bda6");
INSERT INTO V_VAR
	VALUES ("a26f2127-4c64-4c63-a87b-0ec68fd4897a",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	'answerdigits',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("a26f2127-4c64-4c63-a87b-0ec68fd4897a",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("54399791-acab-40f3-afec-7ab56b7ad223",
	4,
	13,
	24,
	"a26f2127-4c64-4c63-a87b-0ec68fd4897a");
INSERT INTO V_LOC
	VALUES ("dc45b1e2-02f8-46a9-b398-9d4af5b7ffec",
	7,
	27,
	38,
	"a26f2127-4c64-4c63-a87b-0ec68fd4897a");
INSERT INTO V_VAR
	VALUES ("2923d25c-69a5-4efd-ad93-bc8093716e43",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("2923d25c-69a5-4efd-ad93-bc8093716e43",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_VAR
	VALUES ("8f12d7dd-6492-463b-a384-89b98885acc6",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	'eligibles',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("8f12d7dd-6492-463b-a384-89b98885acc6",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("8f21fd20-fbbb-46df-a783-0183d2c02c3b",
	5,
	13,
	21,
	"8f12d7dd-6492-463b-a384-89b98885acc6");
INSERT INTO V_LOC
	VALUES ("7c5cbf4d-15e2-4c08-8ee5-7420cd63dc06",
	6,
	22,
	30,
	"8f12d7dd-6492-463b-a384-89b98885acc6");
INSERT INTO V_LOC
	VALUES ("bf8be25f-bcf3-480c-ad46-4a1facaed25c",
	28,
	15,
	23,
	"8f12d7dd-6492-463b-a384-89b98885acc6");
INSERT INTO V_VAR
	VALUES ("c881e36a-6041-440b-b97c-659820e0a2d7",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	'eligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("c881e36a-6041-440b-b97c-659820e0a2d7",
	1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("69fbfdd2-e6f4-4128-a2b9-31de68be93a3",
	6,
	10,
	17,
	"c881e36a-6041-440b-b97c-659820e0a2d7");
INSERT INTO V_LOC
	VALUES ("35754514-546a-4e68-a0c2-988fd1b8d996",
	8,
	10,
	17,
	"c881e36a-6041-440b-b97c-659820e0a2d7");
INSERT INTO V_LOC
	VALUES ("df61f4a7-c6f6-43fc-bc0c-90bfe5f8916a",
	10,
	37,
	44,
	"c881e36a-6041-440b-b97c-659820e0a2d7");
INSERT INTO V_LOC
	VALUES ("d8bee4ab-b857-4be8-ab31-31d1666e4f43",
	11,
	60,
	67,
	"c881e36a-6041-440b-b97c-659820e0a2d7");
INSERT INTO V_LOC
	VALUES ("c05c84c5-12c2-41e5-90b6-16f6333376ec",
	12,
	32,
	39,
	"c881e36a-6041-440b-b97c-659820e0a2d7");
INSERT INTO V_VAR
	VALUES ("88feeb30-110d-4fa6-86cf-1704c39c8f86",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	'opencells',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("88feeb30-110d-4fa6-86cf-1704c39c8f86",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("fb894490-ae74-446a-8ccb-ff75db09e682",
	21,
	13,
	21,
	"88feeb30-110d-4fa6-86cf-1704c39c8f86");
INSERT INTO V_LOC
	VALUES ("c6af0d08-d161-49b4-86bd-318b3b6fe2fb",
	26,
	22,
	30,
	"88feeb30-110d-4fa6-86cf-1704c39c8f86");
INSERT INTO V_VAR
	VALUES ("d68725e4-40f1-4552-940d-c203e1c8e08e",
	"35d61fa1-1017-4f63-92bb-6d02f7a94b35",
	'opencell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("d68725e4-40f1-4552-940d-c203e1c8e08e",
	1,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("334a055b-be92-431f-ac19-b94d24e377a7",
	26,
	10,
	17,
	"d68725e4-40f1-4552-940d-c203e1c8e08e");
INSERT INTO V_LOC
	VALUES ("0b30831d-9181-490c-a6e5-110ac6a4e610",
	32,
	5,
	12,
	"d68725e4-40f1-4552-940d-c203e1c8e08e");
INSERT INTO ACT_BLK
	VALUES ("821a81c7-b4e6-43cc-b13d-12b76efd3247",
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"bf7d48fd-0b7b-4469-aaa5-02e39028d1f0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4ee03e58-6767-42e8-ad9c-7ee76c1ddaf6",
	"821a81c7-b4e6-43cc-b13d-12b76efd3247",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'box::prune line: 7');
INSERT INTO ACT_FOR
	VALUES ("4ee03e58-6767-42e8-ad9c-7ee76c1ddaf6",
	"70fdaf49-1562-4ce2-9a94-7726942a7319",
	1,
	"a5eb5557-ebd9-4ba6-9b21-e6d39d7870a3",
	"a26f2127-4c64-4c63-a87b-0ec68fd4897a",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_VAR
	VALUES ("a5eb5557-ebd9-4ba6-9b21-e6d39d7870a3",
	"821a81c7-b4e6-43cc-b13d-12b76efd3247",
	'answerdigit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("a5eb5557-ebd9-4ba6-9b21-e6d39d7870a3",
	1,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("b0616b36-2433-4e33-a8e9-71ef687166df",
	7,
	12,
	22,
	"a5eb5557-ebd9-4ba6-9b21-e6d39d7870a3");
INSERT INTO V_LOC
	VALUES ("206dad53-4557-4fa4-8e7f-da75bd52ddf6",
	8,
	34,
	44,
	"a5eb5557-ebd9-4ba6-9b21-e6d39d7870a3");
INSERT INTO V_LOC
	VALUES ("fc505e49-5ef4-4ee4-8158-0e8e3efed172",
	11,
	18,
	28,
	"a5eb5557-ebd9-4ba6-9b21-e6d39d7870a3");
INSERT INTO ACT_BLK
	VALUES ("70fdaf49-1562-4ce2-9a94-7726942a7319",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"bf7d48fd-0b7b-4469-aaa5-02e39028d1f0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d1421d56-77e0-4406-86c1-9b6cb51aa1d3",
	"70fdaf49-1562-4ce2-9a94-7726942a7319",
	"00000000-0000-0000-0000-000000000000",
	8,
	5,
	'box::prune line: 8');
INSERT INTO ACT_IF
	VALUES ("d1421d56-77e0-4406-86c1-9b6cb51aa1d3",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331",
	"cfc10ce3-94e6-43ff-ac19-9ca17637e107",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("c8e7d801-1282-40fa-b011-d5846460caa8",
	0,
	0,
	8,
	10,
	17,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"70fdaf49-1562-4ce2-9a94-7726942a7319");
INSERT INTO V_IRF
	VALUES ("c8e7d801-1282-40fa-b011-d5846460caa8",
	"c881e36a-6041-440b-b97c-659820e0a2d7");
INSERT INTO V_VAL
	VALUES ("bd68d0fb-47a3-4dcd-9a22-488338fa37e2",
	0,
	0,
	8,
	19,
	29,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"70fdaf49-1562-4ce2-9a94-7726942a7319");
INSERT INTO V_AVL
	VALUES ("bd68d0fb-47a3-4dcd-9a22-488338fa37e2",
	"c8e7d801-1282-40fa-b011-d5846460caa8",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("cfc10ce3-94e6-43ff-ac19-9ca17637e107",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"70fdaf49-1562-4ce2-9a94-7726942a7319");
INSERT INTO V_BIN
	VALUES ("cfc10ce3-94e6-43ff-ac19-9ca17637e107",
	"8ba0c590-ad0a-4454-9751-8ebe4b862dd9",
	"bd68d0fb-47a3-4dcd-9a22-488338fa37e2",
	'==');
INSERT INTO V_VAL
	VALUES ("686edf5b-dd09-4eee-b9b3-c0b4c7661866",
	0,
	0,
	8,
	34,
	44,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"70fdaf49-1562-4ce2-9a94-7726942a7319");
INSERT INTO V_IRF
	VALUES ("686edf5b-dd09-4eee-b9b3-c0b4c7661866",
	"a5eb5557-ebd9-4ba6-9b21-e6d39d7870a3");
INSERT INTO V_VAL
	VALUES ("8ba0c590-ad0a-4454-9751-8ebe4b862dd9",
	0,
	0,
	8,
	46,
	50,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"70fdaf49-1562-4ce2-9a94-7726942a7319");
INSERT INTO V_AVL
	VALUES ("8ba0c590-ad0a-4454-9751-8ebe4b862dd9",
	"686edf5b-dd09-4eee-b9b3-c0b4c7661866",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO ACT_BLK
	VALUES ("2bc41390-7c86-47d5-9a1d-f037c6f3f331",
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	7,
	9,
	48,
	0,
	0,
	9,
	53,
	0,
	0,
	0,
	0,
	0,
	"bf7d48fd-0b7b-4469-aaa5-02e39028d1f0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ee24254b-bb0a-4028-8714-cca5a21a3c89",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331",
	"52647158-75ad-4ab6-98d6-f790e0d2def9",
	9,
	7,
	'box::prune line: 9');
INSERT INTO ACT_SEL
	VALUES ("ee24254b-bb0a-4028-8714-cca5a21a3c89",
	"46f1ee23-5189-4059-92d8-26a617544668",
	1,
	'one',
	"d69dd272-cffa-4954-9eab-ea266587ebb1");
INSERT INTO ACT_SR
	VALUES ("ee24254b-bb0a-4028-8714-cca5a21a3c89");
INSERT INTO ACT_LNK
	VALUES ("9d6a62f0-3448-4c98-bc79-0716d90d54dc",
	'',
	"ee24254b-bb0a-4028-8714-cca5a21a3c89",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	9,
	48,
	9,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("52647158-75ad-4ab6-98d6-f790e0d2def9",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331",
	"79dc4c6e-2c1e-4545-932c-533df46fdd48",
	10,
	7,
	'box::prune line: 10');
INSERT INTO ACT_IF
	VALUES ("52647158-75ad-4ab6-98d6-f790e0d2def9",
	"05436117-4b4a-49df-8846-7929d36e7dd8",
	"d43c0844-837e-4710-954f-4e6e26e816ff",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("79dc4c6e-2c1e-4545-932c-533df46fdd48",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331",
	"aeb6b879-8aa0-4d4f-ae65-c9ab02295fa4",
	15,
	7,
	'box::prune line: 15');
INSERT INTO ACT_AI
	VALUES ("79dc4c6e-2c1e-4545-932c-533df46fdd48",
	"b8cc0182-ea81-44f1-a6df-08aab591e711",
	"f41661e2-ef38-4271-a94d-67cbfad912a5",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("aeb6b879-8aa0-4d4f-ae65-c9ab02295fa4",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	'box::prune line: 16');
INSERT INTO ACT_BRK
	VALUES ("aeb6b879-8aa0-4d4f-ae65-c9ab02295fa4");
INSERT INTO V_VAL
	VALUES ("d69dd272-cffa-4954-9eab-ea266587ebb1",
	0,
	0,
	9,
	38,
	45,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331");
INSERT INTO V_IRF
	VALUES ("d69dd272-cffa-4954-9eab-ea266587ebb1",
	"c881e36a-6041-440b-b97c-659820e0a2d7");
INSERT INTO V_VAL
	VALUES ("c73aa968-e84c-4f39-a083-0d13b956f5a8",
	0,
	0,
	10,
	12,
	19,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331");
INSERT INTO V_IRF
	VALUES ("c73aa968-e84c-4f39-a083-0d13b956f5a8",
	"46f1ee23-5189-4059-92d8-26a617544668");
INSERT INTO V_VAL
	VALUES ("b6df1e91-d0ad-4fde-bba8-e55fa544f1a9",
	0,
	0,
	10,
	21,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331");
INSERT INTO V_AVL
	VALUES ("b6df1e91-d0ad-4fde-bba8-e55fa544f1a9",
	"c73aa968-e84c-4f39-a083-0d13b956f5a8",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"009f5557-7ee7-4e44-9444-4d92eb448359");
INSERT INTO V_VAL
	VALUES ("d43c0844-837e-4710-954f-4e6e26e816ff",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331");
INSERT INTO V_BIN
	VALUES ("d43c0844-837e-4710-954f-4e6e26e816ff",
	"49712e3b-539e-4e67-9735-ecaf54458920",
	"b6df1e91-d0ad-4fde-bba8-e55fa544f1a9",
	'!=');
INSERT INTO V_VAL
	VALUES ("aa43d81d-f959-498d-a1ce-6c023e9e02d4",
	0,
	0,
	10,
	37,
	44,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331");
INSERT INTO V_IRF
	VALUES ("aa43d81d-f959-498d-a1ce-6c023e9e02d4",
	"c881e36a-6041-440b-b97c-659820e0a2d7");
INSERT INTO V_VAL
	VALUES ("49712e3b-539e-4e67-9735-ecaf54458920",
	0,
	0,
	10,
	46,
	56,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331");
INSERT INTO V_AVL
	VALUES ("49712e3b-539e-4e67-9735-ecaf54458920",
	"aa43d81d-f959-498d-a1ce-6c023e9e02d4",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("f41661e2-ef38-4271-a94d-67cbfad912a5",
	1,
	0,
	15,
	7,
	17,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331");
INSERT INTO V_TVL
	VALUES ("f41661e2-ef38-4271-a94d-67cbfad912a5",
	"05140403-a2f8-4277-8b33-870e3118bda6");
INSERT INTO V_VAL
	VALUES ("b8cc0182-ea81-44f1-a6df-08aab591e711",
	0,
	0,
	15,
	21,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331");
INSERT INTO V_LIN
	VALUES ("b8cc0182-ea81-44f1-a6df-08aab591e711",
	'1');
INSERT INTO V_VAR
	VALUES ("46f1ee23-5189-4059-92d8-26a617544668",
	"2bc41390-7c86-47d5-9a1d-f037c6f3f331",
	'opencell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("46f1ee23-5189-4059-92d8-26a617544668",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("185ea01d-d544-4d5d-bbfb-0d49e4d523a2",
	9,
	18,
	25,
	"46f1ee23-5189-4059-92d8-26a617544668");
INSERT INTO V_LOC
	VALUES ("3258c8f6-7814-4748-b626-f41140ebff9c",
	10,
	12,
	19,
	"46f1ee23-5189-4059-92d8-26a617544668");
INSERT INTO V_LOC
	VALUES ("abbe54ed-ab44-4af6-a60d-cc63cc8f75f3",
	11,
	35,
	42,
	"46f1ee23-5189-4059-92d8-26a617544668");
INSERT INTO ACT_BLK
	VALUES ("05436117-4b4a-49df-8846-7929d36e7dd8",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	9,
	0,
	0,
	0,
	0,
	11,
	51,
	0,
	0,
	0,
	0,
	0,
	"bf7d48fd-0b7b-4469-aaa5-02e39028d1f0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8fd9812f-3f12-4f17-a28a-fc0c65be7597",
	"05436117-4b4a-49df-8846-7929d36e7dd8",
	"1f810121-5087-449d-ad9d-9988f9e7fb7e",
	11,
	9,
	'box::prune line: 11');
INSERT INTO ACT_URU
	VALUES ("8fd9812f-3f12-4f17-a28a-fc0c65be7597",
	"a5eb5557-ebd9-4ba6-9b21-e6d39d7870a3",
	"46f1ee23-5189-4059-92d8-26a617544668",
	"c881e36a-6041-440b-b97c-659820e0a2d7",
	'',
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	11,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("1f810121-5087-449d-ad9d-9988f9e7fb7e",
	"05436117-4b4a-49df-8846-7929d36e7dd8",
	"00000000-0000-0000-0000-000000000000",
	12,
	9,
	'box::prune line: 12');
INSERT INTO ACT_DEL
	VALUES ("1f810121-5087-449d-ad9d-9988f9e7fb7e",
	"c881e36a-6041-440b-b97c-659820e0a2d7");
INSERT INTO ACT_BLK
	VALUES ("cc4d0d65-e47f-45fb-82a2-9f0895b1663c",
	0,
	0,
	0,
	'',
	'',
	'',
	24,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"bf7d48fd-0b7b-4469-aaa5-02e39028d1f0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("07f520bf-34ec-4eb4-bce7-95c55a248045",
	"cc4d0d65-e47f-45fb-82a2-9f0895b1663c",
	"00000000-0000-0000-0000-000000000000",
	24,
	3,
	'box::prune line: 24');
INSERT INTO ACT_AI
	VALUES ("07f520bf-34ec-4eb4-bce7-95c55a248045",
	"aca23a2d-9163-4bc5-842a-ef7f76b98f06",
	"6978e766-91cb-47be-8f24-0da5a992dd90",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("6978e766-91cb-47be-8f24-0da5a992dd90",
	1,
	0,
	24,
	3,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"cc4d0d65-e47f-45fb-82a2-9f0895b1663c");
INSERT INTO V_TVL
	VALUES ("6978e766-91cb-47be-8f24-0da5a992dd90",
	"05140403-a2f8-4277-8b33-870e3118bda6");
INSERT INTO V_VAL
	VALUES ("aca23a2d-9163-4bc5-842a-ef7f76b98f06",
	0,
	0,
	24,
	17,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"cc4d0d65-e47f-45fb-82a2-9f0895b1663c");
INSERT INTO V_LIN
	VALUES ("aca23a2d-9163-4bc5-842a-ef7f76b98f06",
	'100');
INSERT INTO ACT_BLK
	VALUES ("1977df15-79b4-429f-8dbf-ce1bd1135ef4",
	1,
	0,
	0,
	'',
	'',
	'',
	30,
	3,
	28,
	46,
	0,
	0,
	28,
	55,
	0,
	0,
	0,
	0,
	0,
	"bf7d48fd-0b7b-4469-aaa5-02e39028d1f0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ef1933a0-6979-4f65-9622-19131697e664",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4",
	"42df3fe7-f183-4d40-a9e0-75ea0f3d0915",
	28,
	3,
	'box::prune line: 28');
INSERT INTO ACT_SEL
	VALUES ("ef1933a0-6979-4f65-9622-19131697e664",
	"8f12d7dd-6492-463b-a384-89b98885acc6",
	0,
	'many',
	"f66c20b8-4f94-49c6-9229-faa4c051cd75");
INSERT INTO ACT_SR
	VALUES ("ef1933a0-6979-4f65-9622-19131697e664");
INSERT INTO ACT_LNK
	VALUES ("eedad790-5f92-4b5d-93b7-72e63a1878c2",
	'',
	"ef1933a0-6979-4f65-9622-19131697e664",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	28,
	46,
	28,
	55,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("42df3fe7-f183-4d40-a9e0-75ea0f3d0915",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4",
	"e8e784c1-fbbd-405c-9b9b-f2873e723f1b",
	29,
	3,
	'box::prune line: 29');
INSERT INTO ACT_AI
	VALUES ("42df3fe7-f183-4d40-a9e0-75ea0f3d0915",
	"60802b6a-4e51-4a2d-98f1-7c2445fef7e6",
	"736a27bb-7b43-47df-96fa-b936343627a1",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e8e784c1-fbbd-405c-9b9b-f2873e723f1b",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4",
	"00000000-0000-0000-0000-000000000000",
	30,
	3,
	'box::prune line: 30');
INSERT INTO ACT_IF
	VALUES ("e8e784c1-fbbd-405c-9b9b-f2873e723f1b",
	"9f80ae54-a49f-4828-8c58-69ebc7f31495",
	"66c8345d-9ac0-4312-89af-c68a849b86f9",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("f66c20b8-4f94-49c6-9229-faa4c051cd75",
	0,
	0,
	28,
	36,
	43,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4");
INSERT INTO V_IRF
	VALUES ("f66c20b8-4f94-49c6-9229-faa4c051cd75",
	"d68725e4-40f1-4552-940d-c203e1c8e08e");
INSERT INTO V_VAL
	VALUES ("736a27bb-7b43-47df-96fa-b936343627a1",
	1,
	1,
	29,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4");
INSERT INTO V_TVL
	VALUES ("736a27bb-7b43-47df-96fa-b936343627a1",
	"96af32a8-43a0-485e-8fb1-dcfd246c0c8a");
INSERT INTO V_VAL
	VALUES ("202da950-6921-4987-9aaf-5b8964272c79",
	0,
	0,
	29,
	19,
	27,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4");
INSERT INTO V_ISR
	VALUES ("202da950-6921-4987-9aaf-5b8964272c79",
	"8f12d7dd-6492-463b-a384-89b98885acc6");
INSERT INTO V_VAL
	VALUES ("60802b6a-4e51-4a2d-98f1-7c2445fef7e6",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4");
INSERT INTO V_UNY
	VALUES ("60802b6a-4e51-4a2d-98f1-7c2445fef7e6",
	"202da950-6921-4987-9aaf-5b8964272c79",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("a509bf8a-d6e3-46d9-bfe5-6ac503071426",
	0,
	0,
	30,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4");
INSERT INTO V_LIN
	VALUES ("a509bf8a-d6e3-46d9-bfe5-6ac503071426",
	'1');
INSERT INTO V_VAL
	VALUES ("66c8345d-9ac0-4312-89af-c68a849b86f9",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4");
INSERT INTO V_BIN
	VALUES ("66c8345d-9ac0-4312-89af-c68a849b86f9",
	"746b9eef-197f-4f87-8d8b-9a2e4c32163c",
	"a509bf8a-d6e3-46d9-bfe5-6ac503071426",
	'==');
INSERT INTO V_VAL
	VALUES ("746b9eef-197f-4f87-8d8b-9a2e4c32163c",
	0,
	0,
	30,
	13,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4");
INSERT INTO V_TVL
	VALUES ("746b9eef-197f-4f87-8d8b-9a2e4c32163c",
	"96af32a8-43a0-485e-8fb1-dcfd246c0c8a");
INSERT INTO V_VAR
	VALUES ("96af32a8-43a0-485e-8fb1-dcfd246c0c8a",
	"1977df15-79b4-429f-8dbf-ce1bd1135ef4",
	'c',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("96af32a8-43a0-485e-8fb1-dcfd246c0c8a",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("132ffce7-7141-4762-8e93-29b8eac192e3",
	29,
	3,
	3,
	"96af32a8-43a0-485e-8fb1-dcfd246c0c8a");
INSERT INTO V_LOC
	VALUES ("b54c9315-26bb-490b-a84c-3ddb1c5fca14",
	30,
	13,
	13,
	"96af32a8-43a0-485e-8fb1-dcfd246c0c8a");
INSERT INTO ACT_BLK
	VALUES ("9f80ae54-a49f-4828-8c58-69ebc7f31495",
	1,
	0,
	0,
	'',
	'',
	'',
	34,
	5,
	31,
	44,
	0,
	0,
	31,
	53,
	0,
	0,
	0,
	0,
	0,
	"bf7d48fd-0b7b-4469-aaa5-02e39028d1f0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("990d39b7-eb2a-4b17-9a1e-fae7e97c314d",
	"9f80ae54-a49f-4828-8c58-69ebc7f31495",
	"6359d7c5-dbfc-464c-8f07-2f69d0956806",
	31,
	5,
	'box::prune line: 31');
INSERT INTO ACT_SEL
	VALUES ("990d39b7-eb2a-4b17-9a1e-fae7e97c314d",
	"b770e828-4a5a-428a-a6f5-1b38573f7a11",
	1,
	'any',
	"6781afb1-d5c1-411c-b023-2869ae83f8ef");
INSERT INTO ACT_SR
	VALUES ("990d39b7-eb2a-4b17-9a1e-fae7e97c314d");
INSERT INTO ACT_LNK
	VALUES ("0b80150a-a925-42f2-9aa7-316c7c15b906",
	'',
	"990d39b7-eb2a-4b17-9a1e-fae7e97c314d",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	31,
	44,
	31,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("6359d7c5-dbfc-464c-8f07-2f69d0956806",
	"9f80ae54-a49f-4828-8c58-69ebc7f31495",
	"0ec46b32-5096-4673-a27e-b3b4e520646b",
	32,
	5,
	'box::prune line: 32');
INSERT INTO ACT_TFM
	VALUES ("6359d7c5-dbfc-464c-8f07-2f69d0956806",
	"a3632caa-a4af-4c7b-8e5d-212826ddcf99",
	"d68725e4-40f1-4552-940d-c203e1c8e08e",
	32,
	14,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0ec46b32-5096-4673-a27e-b3b4e520646b",
	"9f80ae54-a49f-4828-8c58-69ebc7f31495",
	"00000000-0000-0000-0000-000000000000",
	34,
	5,
	'box::prune line: 34');
INSERT INTO ACT_AI
	VALUES ("0ec46b32-5096-4673-a27e-b3b4e520646b",
	"c8c848c1-2d8c-4c16-8f14-937a6f34ac29",
	"48cf170b-3c1c-440f-bc73-20510ecbccd6",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("6781afb1-d5c1-411c-b023-2869ae83f8ef",
	0,
	0,
	31,
	34,
	41,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"9f80ae54-a49f-4828-8c58-69ebc7f31495");
INSERT INTO V_IRF
	VALUES ("6781afb1-d5c1-411c-b023-2869ae83f8ef",
	"d68725e4-40f1-4552-940d-c203e1c8e08e");
INSERT INTO V_VAL
	VALUES ("740e9c69-450e-423a-bb52-91a3348a19d8",
	0,
	0,
	32,
	35,
	40,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"9f80ae54-a49f-4828-8c58-69ebc7f31495");
INSERT INTO V_IRF
	VALUES ("740e9c69-450e-423a-bb52-91a3348a19d8",
	"b770e828-4a5a-428a-a6f5-1b38573f7a11");
INSERT INTO V_VAL
	VALUES ("aff8b7bc-c2b6-415a-a82c-4fb120a7552c",
	0,
	0,
	32,
	42,
	52,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9f80ae54-a49f-4828-8c58-69ebc7f31495");
INSERT INTO V_AVL
	VALUES ("aff8b7bc-c2b6-415a-a82c-4fb120a7552c",
	"740e9c69-450e-423a-bb52-91a3348a19d8",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_PAR
	VALUES ("aff8b7bc-c2b6-415a-a82c-4fb120a7552c",
	"6359d7c5-dbfc-464c-8f07-2f69d0956806",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	32,
	22);
INSERT INTO V_VAL
	VALUES ("48cf170b-3c1c-440f-bc73-20510ecbccd6",
	1,
	0,
	34,
	5,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9f80ae54-a49f-4828-8c58-69ebc7f31495");
INSERT INTO V_TVL
	VALUES ("48cf170b-3c1c-440f-bc73-20510ecbccd6",
	"05140403-a2f8-4277-8b33-870e3118bda6");
INSERT INTO V_VAL
	VALUES ("c8c848c1-2d8c-4c16-8f14-937a6f34ac29",
	0,
	0,
	34,
	19,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9f80ae54-a49f-4828-8c58-69ebc7f31495");
INSERT INTO V_LIN
	VALUES ("c8c848c1-2d8c-4c16-8f14-937a6f34ac29",
	'1');
INSERT INTO V_VAR
	VALUES ("b770e828-4a5a-428a-a6f5-1b38573f7a11",
	"9f80ae54-a49f-4828-8c58-69ebc7f31495",
	'answer',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("b770e828-4a5a-428a-a6f5-1b38573f7a11",
	0,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("4b472530-11eb-4046-b4e7-eafb68b83dec",
	31,
	16,
	21,
	"b770e828-4a5a-428a-a6f5-1b38573f7a11");
INSERT INTO V_LOC
	VALUES ("67ad0892-8dc2-49a7-ab21-60957daf42b4",
	32,
	35,
	40,
	"b770e828-4a5a-428a-a6f5-1b38573f7a11");
INSERT INTO O_TFR
	VALUES ("95951fd8-2a86-4a4a-b9aa-8e2e2e1bbd9b",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	'eliminate',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	1,
	'// Solve by selecting eligible digits.
// Notice if any eligible digit appears only once.

temperature = 0;
select many eligibles related by self->CELL[R4]->ELIGIBLE[R8];
c = cardinality eligibles;
if ( 9 == c )
  temperature = 100;
else
for each eligible in eligibles
  select many loners related by self->CELL[R4]->ELIGIBLE[R8]
    where ( selected.digit_value == eligible.digit_value );
  c = cardinality loners;
  if ( 1 == c )
    // This is an answer!
    select one cell related by eligible->CELL[R8];
    cell.answer( answer_digit:eligible.digit_value );
    //generate CELL2:answer( digit:eligible.digit_value ) to cell;
    temperature = 1;
    break;
  end if;
end for;
end if;
return temperature;',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_OPB
	VALUES ("727b1689-2c5e-491d-921d-829a699b13b5",
	"95951fd8-2a86-4a4a-b9aa-8e2e2e1bbd9b");
INSERT INTO ACT_ACT
	VALUES ("727b1689-2c5e-491d-921d-829a699b13b5",
	'operation',
	0,
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	"00000000-0000-0000-0000-000000000000",
	0,
	'box::eliminate',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("98353b97-ac1c-470f-9b75-5c409680b6c8",
	1,
	0,
	0,
	'',
	'',
	'',
	24,
	1,
	5,
	50,
	0,
	0,
	5,
	59,
	0,
	0,
	0,
	0,
	0,
	"727b1689-2c5e-491d-921d-829a699b13b5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("194aecf4-aeb5-4e2e-8f96-20da5f93e393",
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	"28830069-b08e-455b-bff4-6a82942fef55",
	4,
	1,
	'box::eliminate line: 4');
INSERT INTO ACT_AI
	VALUES ("194aecf4-aeb5-4e2e-8f96-20da5f93e393",
	"9f0c78f2-8125-46d4-8d60-0770aaa98363",
	"f841dbed-de94-402a-ad0e-1d11b487784a",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("28830069-b08e-455b-bff4-6a82942fef55",
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	"115b3deb-a228-4fed-bfb0-0324029eedbd",
	5,
	1,
	'box::eliminate line: 5');
INSERT INTO ACT_SEL
	VALUES ("28830069-b08e-455b-bff4-6a82942fef55",
	"0e77b343-6d99-44d0-9816-cb934d3e59af",
	1,
	'many',
	"e7733184-a26b-4f54-960e-fb81dbf193db");
INSERT INTO ACT_SR
	VALUES ("28830069-b08e-455b-bff4-6a82942fef55");
INSERT INTO ACT_LNK
	VALUES ("9613af58-e2ce-445b-8e76-d9aff7e729e7",
	'',
	"28830069-b08e-455b-bff4-6a82942fef55",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"ec59f39d-ff47-4b5f-a3da-fe7cc13c90ce",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("ec59f39d-ff47-4b5f-a3da-fe7cc13c90ce",
	'',
	"00000000-0000-0000-0000-000000000000",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("115b3deb-a228-4fed-bfb0-0324029eedbd",
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	"94583258-16c4-4d5c-8091-1eb6c2919534",
	6,
	1,
	'box::eliminate line: 6');
INSERT INTO ACT_AI
	VALUES ("115b3deb-a228-4fed-bfb0-0324029eedbd",
	"9fd9ad5c-2a05-4f8e-901c-a337b782c7bd",
	"0402de92-4498-4d19-8fbc-52e2c47fd002",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("94583258-16c4-4d5c-8091-1eb6c2919534",
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	"e4702b83-f83b-4875-8325-d18531b71609",
	7,
	1,
	'box::eliminate line: 7');
INSERT INTO ACT_IF
	VALUES ("94583258-16c4-4d5c-8091-1eb6c2919534",
	"5a668498-7a79-49cf-8103-375edb244287",
	"0a3af581-58b9-4aee-b3b0-834b149a3386",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("cebdc412-60d8-42ed-a6f7-98bb0f505ddd",
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	"00000000-0000-0000-0000-000000000000",
	9,
	1,
	'box::eliminate line: 9');
INSERT INTO ACT_E
	VALUES ("cebdc412-60d8-42ed-a6f7-98bb0f505ddd",
	"885e3d5e-9246-4cd0-b609-f64d87ffcde6",
	"94583258-16c4-4d5c-8091-1eb6c2919534");
INSERT INTO ACT_SMT
	VALUES ("e4702b83-f83b-4875-8325-d18531b71609",
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	"00000000-0000-0000-0000-000000000000",
	24,
	1,
	'box::eliminate line: 24');
INSERT INTO ACT_RET
	VALUES ("e4702b83-f83b-4875-8325-d18531b71609",
	"96088e63-0cbe-4d65-a94d-3d083938b812");
INSERT INTO V_VAL
	VALUES ("f841dbed-de94-402a-ad0e-1d11b487784a",
	1,
	1,
	4,
	1,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"98353b97-ac1c-470f-9b75-5c409680b6c8");
INSERT INTO V_TVL
	VALUES ("f841dbed-de94-402a-ad0e-1d11b487784a",
	"8abe66da-f4a5-4fc6-b634-916a3c5b4d4e");
INSERT INTO V_VAL
	VALUES ("9f0c78f2-8125-46d4-8d60-0770aaa98363",
	0,
	0,
	4,
	15,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"98353b97-ac1c-470f-9b75-5c409680b6c8");
INSERT INTO V_LIN
	VALUES ("9f0c78f2-8125-46d4-8d60-0770aaa98363",
	'0');
INSERT INTO V_VAL
	VALUES ("e7733184-a26b-4f54-960e-fb81dbf193db",
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"98353b97-ac1c-470f-9b75-5c409680b6c8");
INSERT INTO V_IRF
	VALUES ("e7733184-a26b-4f54-960e-fb81dbf193db",
	"7721b7eb-7fa6-4e83-b5c5-994713d7710c");
INSERT INTO V_VAL
	VALUES ("0402de92-4498-4d19-8fbc-52e2c47fd002",
	1,
	1,
	6,
	1,
	1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"98353b97-ac1c-470f-9b75-5c409680b6c8");
INSERT INTO V_TVL
	VALUES ("0402de92-4498-4d19-8fbc-52e2c47fd002",
	"211f2c72-9769-4d08-bd72-06c370abd346");
INSERT INTO V_VAL
	VALUES ("20c43c11-ce47-4bae-a5f3-766fe629a61e",
	0,
	0,
	6,
	17,
	25,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"98353b97-ac1c-470f-9b75-5c409680b6c8");
INSERT INTO V_ISR
	VALUES ("20c43c11-ce47-4bae-a5f3-766fe629a61e",
	"0e77b343-6d99-44d0-9816-cb934d3e59af");
INSERT INTO V_VAL
	VALUES ("9fd9ad5c-2a05-4f8e-901c-a337b782c7bd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"98353b97-ac1c-470f-9b75-5c409680b6c8");
INSERT INTO V_UNY
	VALUES ("9fd9ad5c-2a05-4f8e-901c-a337b782c7bd",
	"20c43c11-ce47-4bae-a5f3-766fe629a61e",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("290557da-5446-456d-8204-d76c26f94b8c",
	0,
	0,
	7,
	6,
	6,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"98353b97-ac1c-470f-9b75-5c409680b6c8");
INSERT INTO V_LIN
	VALUES ("290557da-5446-456d-8204-d76c26f94b8c",
	'9');
INSERT INTO V_VAL
	VALUES ("0a3af581-58b9-4aee-b3b0-834b149a3386",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"98353b97-ac1c-470f-9b75-5c409680b6c8");
INSERT INTO V_BIN
	VALUES ("0a3af581-58b9-4aee-b3b0-834b149a3386",
	"d2174bb4-cebb-4110-a197-152cc0082dfb",
	"290557da-5446-456d-8204-d76c26f94b8c",
	'==');
INSERT INTO V_VAL
	VALUES ("d2174bb4-cebb-4110-a197-152cc0082dfb",
	0,
	0,
	7,
	11,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"98353b97-ac1c-470f-9b75-5c409680b6c8");
INSERT INTO V_TVL
	VALUES ("d2174bb4-cebb-4110-a197-152cc0082dfb",
	"211f2c72-9769-4d08-bd72-06c370abd346");
INSERT INTO V_VAL
	VALUES ("96088e63-0cbe-4d65-a94d-3d083938b812",
	0,
	0,
	24,
	8,
	18,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"98353b97-ac1c-470f-9b75-5c409680b6c8");
INSERT INTO V_TVL
	VALUES ("96088e63-0cbe-4d65-a94d-3d083938b812",
	"8abe66da-f4a5-4fc6-b634-916a3c5b4d4e");
INSERT INTO V_VAR
	VALUES ("8abe66da-f4a5-4fc6-b634-916a3c5b4d4e",
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	'temperature',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("8abe66da-f4a5-4fc6-b634-916a3c5b4d4e",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("548b4748-a58f-49b0-8358-8358a0c18cfc",
	4,
	1,
	11,
	"8abe66da-f4a5-4fc6-b634-916a3c5b4d4e");
INSERT INTO V_LOC
	VALUES ("e8366120-f6e7-4fb5-88d2-03ece4b8905e",
	8,
	3,
	13,
	"8abe66da-f4a5-4fc6-b634-916a3c5b4d4e");
INSERT INTO V_LOC
	VALUES ("ae3f7fc7-cdeb-479b-8d4b-865f3c011300",
	19,
	5,
	15,
	"8abe66da-f4a5-4fc6-b634-916a3c5b4d4e");
INSERT INTO V_LOC
	VALUES ("b8e5d50c-4c89-4777-810e-d95c12d6c990",
	24,
	8,
	18,
	"8abe66da-f4a5-4fc6-b634-916a3c5b4d4e");
INSERT INTO V_VAR
	VALUES ("0e77b343-6d99-44d0-9816-cb934d3e59af",
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	'eligibles',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("0e77b343-6d99-44d0-9816-cb934d3e59af",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("842bc416-3ad5-49c5-8f26-5eda5b296362",
	5,
	13,
	21,
	"0e77b343-6d99-44d0-9816-cb934d3e59af");
INSERT INTO V_LOC
	VALUES ("306d8e07-3836-4486-a2fc-3f442d67a81c",
	10,
	22,
	30,
	"0e77b343-6d99-44d0-9816-cb934d3e59af");
INSERT INTO V_VAR
	VALUES ("7721b7eb-7fa6-4e83-b5c5-994713d7710c",
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("7721b7eb-7fa6-4e83-b5c5-994713d7710c",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_VAR
	VALUES ("211f2c72-9769-4d08-bd72-06c370abd346",
	"98353b97-ac1c-470f-9b75-5c409680b6c8",
	'c',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("211f2c72-9769-4d08-bd72-06c370abd346",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("32d3f992-d7e9-4ae5-89d0-a13bd0b8da47",
	6,
	1,
	1,
	"211f2c72-9769-4d08-bd72-06c370abd346");
INSERT INTO V_LOC
	VALUES ("cc161648-1506-4746-9d67-e54dfec84bf1",
	7,
	11,
	11,
	"211f2c72-9769-4d08-bd72-06c370abd346");
INSERT INTO V_LOC
	VALUES ("29030a8b-f858-4c77-be52-5761eb1f52e7",
	13,
	3,
	3,
	"211f2c72-9769-4d08-bd72-06c370abd346");
INSERT INTO V_LOC
	VALUES ("9b1fc138-eba8-41c9-a6f2-9a5c6653339b",
	14,
	13,
	13,
	"211f2c72-9769-4d08-bd72-06c370abd346");
INSERT INTO ACT_BLK
	VALUES ("5a668498-7a79-49cf-8103-375edb244287",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"727b1689-2c5e-491d-921d-829a699b13b5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8f591119-0aff-4b40-9f8c-a6bc961f4814",
	"5a668498-7a79-49cf-8103-375edb244287",
	"00000000-0000-0000-0000-000000000000",
	8,
	3,
	'box::eliminate line: 8');
INSERT INTO ACT_AI
	VALUES ("8f591119-0aff-4b40-9f8c-a6bc961f4814",
	"7cd72c2d-a949-42e1-be8f-4f8815934521",
	"673de02a-0277-4b44-9b6f-c53c3280379f",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("673de02a-0277-4b44-9b6f-c53c3280379f",
	1,
	0,
	8,
	3,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"5a668498-7a79-49cf-8103-375edb244287");
INSERT INTO V_TVL
	VALUES ("673de02a-0277-4b44-9b6f-c53c3280379f",
	"8abe66da-f4a5-4fc6-b634-916a3c5b4d4e");
INSERT INTO V_VAL
	VALUES ("7cd72c2d-a949-42e1-be8f-4f8815934521",
	0,
	0,
	8,
	17,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"5a668498-7a79-49cf-8103-375edb244287");
INSERT INTO V_LIN
	VALUES ("7cd72c2d-a949-42e1-be8f-4f8815934521",
	'100');
INSERT INTO ACT_BLK
	VALUES ("885e3d5e-9246-4cd0-b609-f64d87ffcde6",
	0,
	0,
	0,
	'',
	'',
	'',
	10,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"727b1689-2c5e-491d-921d-829a699b13b5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("eb347d0a-3760-47d7-a184-8bbc36261d9d",
	"885e3d5e-9246-4cd0-b609-f64d87ffcde6",
	"00000000-0000-0000-0000-000000000000",
	10,
	1,
	'box::eliminate line: 10');
INSERT INTO ACT_FOR
	VALUES ("eb347d0a-3760-47d7-a184-8bbc36261d9d",
	"383f7b33-2064-4151-b686-97e88a824959",
	1,
	"431486f8-ee46-4de9-9b10-524d8f7d0c1b",
	"0e77b343-6d99-44d0-9816-cb934d3e59af",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_VAR
	VALUES ("431486f8-ee46-4de9-9b10-524d8f7d0c1b",
	"885e3d5e-9246-4cd0-b609-f64d87ffcde6",
	'eligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("431486f8-ee46-4de9-9b10-524d8f7d0c1b",
	1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("85586af2-6bd4-436e-967a-d28a5eb0cf04",
	10,
	10,
	17,
	"431486f8-ee46-4de9-9b10-524d8f7d0c1b");
INSERT INTO V_LOC
	VALUES ("b738130a-bd6c-49dd-83e1-c1a2d3f29808",
	12,
	37,
	44,
	"431486f8-ee46-4de9-9b10-524d8f7d0c1b");
INSERT INTO V_LOC
	VALUES ("63ac5ff6-7cbb-41bf-8f19-f18a86bf253b",
	17,
	31,
	38,
	"431486f8-ee46-4de9-9b10-524d8f7d0c1b");
INSERT INTO ACT_BLK
	VALUES ("383f7b33-2064-4151-b686-97e88a824959",
	1,
	0,
	1,
	'',
	'',
	'',
	14,
	3,
	11,
	49,
	0,
	0,
	11,
	58,
	0,
	0,
	0,
	0,
	0,
	"727b1689-2c5e-491d-921d-829a699b13b5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9351d91c-cb4e-487f-bef2-52ba906d5337",
	"383f7b33-2064-4151-b686-97e88a824959",
	"1101653d-a62f-42b2-8c37-8a5afc798aee",
	11,
	3,
	'box::eliminate line: 11');
INSERT INTO ACT_SEL
	VALUES ("9351d91c-cb4e-487f-bef2-52ba906d5337",
	"3161d2e2-aedf-4d9c-909d-ee220a8812d4",
	1,
	'many',
	"46df3fc6-2845-4749-90fd-b44b6c4aa080");
INSERT INTO ACT_SRW
	VALUES ("9351d91c-cb4e-487f-bef2-52ba906d5337",
	"b23cd141-941d-4de5-82da-a6465f08daa8");
INSERT INTO ACT_LNK
	VALUES ("f5fb3b1c-aa15-46d8-a2c8-acf7470b4acb",
	'',
	"9351d91c-cb4e-487f-bef2-52ba906d5337",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"dd698289-b2ef-4bfd-8f64-4d5f53402371",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	11,
	39,
	11,
	44,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("dd698289-b2ef-4bfd-8f64-4d5f53402371",
	'',
	"00000000-0000-0000-0000-000000000000",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	11,
	49,
	11,
	58,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("1101653d-a62f-42b2-8c37-8a5afc798aee",
	"383f7b33-2064-4151-b686-97e88a824959",
	"003b30ba-3e77-4c9d-8960-44a142bb9c5d",
	13,
	3,
	'box::eliminate line: 13');
INSERT INTO ACT_AI
	VALUES ("1101653d-a62f-42b2-8c37-8a5afc798aee",
	"21386ef1-a414-4356-9e35-630ee6eff705",
	"b7ecc4fa-fedd-4348-ab0c-1cb069a847ad",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("003b30ba-3e77-4c9d-8960-44a142bb9c5d",
	"383f7b33-2064-4151-b686-97e88a824959",
	"00000000-0000-0000-0000-000000000000",
	14,
	3,
	'box::eliminate line: 14');
INSERT INTO ACT_IF
	VALUES ("003b30ba-3e77-4c9d-8960-44a142bb9c5d",
	"ee0aa3bd-95d5-488b-9101-b564f174069a",
	"5d4706eb-bde6-49bf-8f04-703cde6fe9af",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("46df3fc6-2845-4749-90fd-b44b6c4aa080",
	0,
	0,
	11,
	33,
	36,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_IRF
	VALUES ("46df3fc6-2845-4749-90fd-b44b6c4aa080",
	"7721b7eb-7fa6-4e83-b5c5-994713d7710c");
INSERT INTO V_VAL
	VALUES ("08e7d16b-15b5-4589-9afd-55f9f8879d39",
	0,
	0,
	12,
	13,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_SLR
	VALUES ("08e7d16b-15b5-4589-9afd-55f9f8879d39",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("bdf6935b-fe6f-4bda-8915-c2cc70a7fead",
	0,
	0,
	12,
	22,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_AVL
	VALUES ("bdf6935b-fe6f-4bda-8915-c2cc70a7fead",
	"08e7d16b-15b5-4589-9afd-55f9f8879d39",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("b23cd141-941d-4de5-82da-a6465f08daa8",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_BIN
	VALUES ("b23cd141-941d-4de5-82da-a6465f08daa8",
	"f4a81a73-10e2-4e8b-a7ed-7cd4e6f46608",
	"bdf6935b-fe6f-4bda-8915-c2cc70a7fead",
	'==');
INSERT INTO V_VAL
	VALUES ("d41aca7c-2a01-488e-8646-85b3ac12c8dc",
	0,
	0,
	12,
	37,
	44,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_IRF
	VALUES ("d41aca7c-2a01-488e-8646-85b3ac12c8dc",
	"431486f8-ee46-4de9-9b10-524d8f7d0c1b");
INSERT INTO V_VAL
	VALUES ("f4a81a73-10e2-4e8b-a7ed-7cd4e6f46608",
	0,
	0,
	12,
	46,
	56,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_AVL
	VALUES ("f4a81a73-10e2-4e8b-a7ed-7cd4e6f46608",
	"d41aca7c-2a01-488e-8646-85b3ac12c8dc",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("b7ecc4fa-fedd-4348-ab0c-1cb069a847ad",
	1,
	0,
	13,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_TVL
	VALUES ("b7ecc4fa-fedd-4348-ab0c-1cb069a847ad",
	"211f2c72-9769-4d08-bd72-06c370abd346");
INSERT INTO V_VAL
	VALUES ("170a561f-d7a1-41b6-a947-0197a6e450a2",
	0,
	0,
	13,
	19,
	24,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_ISR
	VALUES ("170a561f-d7a1-41b6-a947-0197a6e450a2",
	"3161d2e2-aedf-4d9c-909d-ee220a8812d4");
INSERT INTO V_VAL
	VALUES ("21386ef1-a414-4356-9e35-630ee6eff705",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_UNY
	VALUES ("21386ef1-a414-4356-9e35-630ee6eff705",
	"170a561f-d7a1-41b6-a947-0197a6e450a2",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("62a03cc6-0eca-4006-a196-3fad21bb5332",
	0,
	0,
	14,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_LIN
	VALUES ("62a03cc6-0eca-4006-a196-3fad21bb5332",
	'1');
INSERT INTO V_VAL
	VALUES ("5d4706eb-bde6-49bf-8f04-703cde6fe9af",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_BIN
	VALUES ("5d4706eb-bde6-49bf-8f04-703cde6fe9af",
	"aaf27f25-03a1-4f16-9482-e41947284ee3",
	"62a03cc6-0eca-4006-a196-3fad21bb5332",
	'==');
INSERT INTO V_VAL
	VALUES ("aaf27f25-03a1-4f16-9482-e41947284ee3",
	0,
	0,
	14,
	13,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"383f7b33-2064-4151-b686-97e88a824959");
INSERT INTO V_TVL
	VALUES ("aaf27f25-03a1-4f16-9482-e41947284ee3",
	"211f2c72-9769-4d08-bd72-06c370abd346");
INSERT INTO V_VAR
	VALUES ("3161d2e2-aedf-4d9c-909d-ee220a8812d4",
	"383f7b33-2064-4151-b686-97e88a824959",
	'loners',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("3161d2e2-aedf-4d9c-909d-ee220a8812d4",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("aa4e81c8-d3c5-46aa-9d6b-94225193be8e",
	11,
	15,
	20,
	"3161d2e2-aedf-4d9c-909d-ee220a8812d4");
INSERT INTO ACT_BLK
	VALUES ("ee0aa3bd-95d5-488b-9101-b564f174069a",
	1,
	0,
	0,
	'',
	'',
	'',
	20,
	5,
	16,
	42,
	0,
	0,
	16,
	47,
	0,
	0,
	0,
	0,
	0,
	"727b1689-2c5e-491d-921d-829a699b13b5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("6148a868-5bc6-40a0-bd59-1e369bceb0ae",
	"ee0aa3bd-95d5-488b-9101-b564f174069a",
	"dc93779a-bd61-4813-8a3f-0b05e4939cea",
	16,
	5,
	'box::eliminate line: 16');
INSERT INTO ACT_SEL
	VALUES ("6148a868-5bc6-40a0-bd59-1e369bceb0ae",
	"4ce6cba4-bda2-4a22-9e72-95387561df40",
	1,
	'one',
	"c7714799-b22a-4e3f-976e-c3496dc7d821");
INSERT INTO ACT_SR
	VALUES ("6148a868-5bc6-40a0-bd59-1e369bceb0ae");
INSERT INTO ACT_LNK
	VALUES ("6813d1a5-fef6-41d9-8186-f5ab1fbb5f67",
	'',
	"6148a868-5bc6-40a0-bd59-1e369bceb0ae",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	16,
	42,
	16,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("dc93779a-bd61-4813-8a3f-0b05e4939cea",
	"ee0aa3bd-95d5-488b-9101-b564f174069a",
	"efaaa2fb-7e6c-4b20-8b95-59ca53960836",
	17,
	5,
	'box::eliminate line: 17');
INSERT INTO ACT_TFM
	VALUES ("dc93779a-bd61-4813-8a3f-0b05e4939cea",
	"a3632caa-a4af-4c7b-8e5d-212826ddcf99",
	"4ce6cba4-bda2-4a22-9e72-95387561df40",
	17,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("efaaa2fb-7e6c-4b20-8b95-59ca53960836",
	"ee0aa3bd-95d5-488b-9101-b564f174069a",
	"ba41c906-6a58-4cec-a8a9-d4e8db1858ac",
	19,
	5,
	'box::eliminate line: 19');
INSERT INTO ACT_AI
	VALUES ("efaaa2fb-7e6c-4b20-8b95-59ca53960836",
	"69db6e35-c41d-46df-a271-44ea1915cc73",
	"34414ea0-1d6f-4e60-b704-9d1936a867a6",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ba41c906-6a58-4cec-a8a9-d4e8db1858ac",
	"ee0aa3bd-95d5-488b-9101-b564f174069a",
	"00000000-0000-0000-0000-000000000000",
	20,
	5,
	'box::eliminate line: 20');
INSERT INTO ACT_BRK
	VALUES ("ba41c906-6a58-4cec-a8a9-d4e8db1858ac");
INSERT INTO V_VAL
	VALUES ("c7714799-b22a-4e3f-976e-c3496dc7d821",
	0,
	0,
	16,
	32,
	39,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ee0aa3bd-95d5-488b-9101-b564f174069a");
INSERT INTO V_IRF
	VALUES ("c7714799-b22a-4e3f-976e-c3496dc7d821",
	"431486f8-ee46-4de9-9b10-524d8f7d0c1b");
INSERT INTO V_VAL
	VALUES ("62688986-bddd-429e-a50a-868d3e7399b4",
	0,
	0,
	17,
	31,
	38,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"ee0aa3bd-95d5-488b-9101-b564f174069a");
INSERT INTO V_IRF
	VALUES ("62688986-bddd-429e-a50a-868d3e7399b4",
	"431486f8-ee46-4de9-9b10-524d8f7d0c1b");
INSERT INTO V_VAL
	VALUES ("72561e55-cf46-4fed-b261-e8a7d4c3f107",
	0,
	0,
	17,
	40,
	50,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ee0aa3bd-95d5-488b-9101-b564f174069a");
INSERT INTO V_AVL
	VALUES ("72561e55-cf46-4fed-b261-e8a7d4c3f107",
	"62688986-bddd-429e-a50a-868d3e7399b4",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_PAR
	VALUES ("72561e55-cf46-4fed-b261-e8a7d4c3f107",
	"dc93779a-bd61-4813-8a3f-0b05e4939cea",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	17,
	18);
INSERT INTO V_VAL
	VALUES ("34414ea0-1d6f-4e60-b704-9d1936a867a6",
	1,
	0,
	19,
	5,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ee0aa3bd-95d5-488b-9101-b564f174069a");
INSERT INTO V_TVL
	VALUES ("34414ea0-1d6f-4e60-b704-9d1936a867a6",
	"8abe66da-f4a5-4fc6-b634-916a3c5b4d4e");
INSERT INTO V_VAL
	VALUES ("69db6e35-c41d-46df-a271-44ea1915cc73",
	0,
	0,
	19,
	19,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"ee0aa3bd-95d5-488b-9101-b564f174069a");
INSERT INTO V_LIN
	VALUES ("69db6e35-c41d-46df-a271-44ea1915cc73",
	'1');
INSERT INTO V_VAR
	VALUES ("4ce6cba4-bda2-4a22-9e72-95387561df40",
	"ee0aa3bd-95d5-488b-9101-b564f174069a",
	'cell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("4ce6cba4-bda2-4a22-9e72-95387561df40",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("dea1e2fa-b2ed-4c37-8505-7de6f4985ebb",
	16,
	16,
	19,
	"4ce6cba4-bda2-4a22-9e72-95387561df40");
INSERT INTO V_LOC
	VALUES ("5a59315f-b166-4c9d-b4c8-661affe2b6f7",
	17,
	5,
	8,
	"4ce6cba4-bda2-4a22-9e72-95387561df40");
INSERT INTO O_NBATTR
	VALUES ("f53a8993-9b73-4be5-b107-ad96fb5601d1",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO O_BATTR
	VALUES ("f53a8993-9b73-4be5-b107-ad96fb5601d1",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO O_ATTR
	VALUES ("f53a8993-9b73-4be5-b107-ad96fb5601d1",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"00000000-0000-0000-0000-000000000000",
	'number',
	'',
	'',
	'number',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("9d8a6960-f06f-46cf-a79e-35c0b8667eac",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO O_BATTR
	VALUES ("9d8a6960-f06f-46cf-a79e-35c0b8667eac",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO O_ATTR
	VALUES ("9d8a6960-f06f-46cf-a79e-35c0b8667eac",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"f53a8993-9b73-4be5-b107-ad96fb5601d1",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"ea4f2014-da78-4798-8130-991e8750cff6",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO O_ID
	VALUES (1,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO O_ID
	VALUES (2,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO SM_ISM
	VALUES ("415f7ffb-d246-4025-9868-5f83c77ba291",
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO SM_SM
	VALUES ("415f7ffb-d246-4025-9868-5f83c77ba291",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("415f7ffb-d246-4025-9868-5f83c77ba291");
INSERT INTO SM_LEVT
	VALUES ("4a74f6cd-a33f-407c-abac-8419734741c7",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("4a74f6cd-a33f-407c-abac-8419734741c7",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("4a74f6cd-a33f-407c-abac-8419734741c7",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000",
	1,
	'update',
	0,
	'',
	'BOX1',
	'');
INSERT INTO SM_LEVT
	VALUES ("4c7c35ce-32c1-44e1-946b-9be559269144",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("4c7c35ce-32c1-44e1-946b-9be559269144",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("4c7c35ce-32c1-44e1-946b-9be559269144",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000",
	2,
	'solved',
	0,
	'',
	'BOX2',
	'');
INSERT INTO SM_STATE
	VALUES ("60db9085-cfae-4bd3-b6bd-f821bcf14d50",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000",
	'solving',
	1,
	0);
INSERT INTO SM_SEME
	VALUES ("60db9085-cfae-4bd3-b6bd-f821bcf14d50",
	"4a74f6cd-a33f-407c-abac-8419734741c7",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("60db9085-cfae-4bd3-b6bd-f821bcf14d50",
	"4c7c35ce-32c1-44e1-946b-9be559269144",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("1f66d8b9-0cb0-4e4c-8d59-d4ecb821f5a3",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"60db9085-cfae-4bd3-b6bd-f821bcf14d50");
INSERT INTO SM_AH
	VALUES ("1f66d8b9-0cb0-4e4c-8d59-d4ecb821f5a3",
	"415f7ffb-d246-4025-9868-5f83c77ba291");
INSERT INTO SM_ACT
	VALUES ("1f66d8b9-0cb0-4e4c-8d59-d4ecb821f5a3",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	1,
	'if ( 100 == self.prune() )
  generate BOX2:solved() to self;
elif ( 100 == self.eliminate() )
  generate BOX2:solved() to self;
else
  select one sequence related by self->SEQUENCE[R1];
  if ( sequence.requests >= 1 )
    sequence.requests = 1;
    b = self;
    generate BOX1:update() to b;
  else
    sequence.requests = 0;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES ("94519cb8-eda7-42dd-9828-6ddbc40b94cf",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"1f66d8b9-0cb0-4e4c-8d59-d4ecb821f5a3");
INSERT INTO ACT_ACT
	VALUES ("94519cb8-eda7-42dd-9828-6ddbc40b94cf",
	'state',
	0,
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'box::solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("6e7e10f3-ce37-4d91-8692-ede1beb78fc0",
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"94519cb8-eda7-42dd-9828-6ddbc40b94cf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("661a2a67-ac5e-4403-8bdf-554522c3db9d",
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'box::solving line: 1');
INSERT INTO ACT_IF
	VALUES ("661a2a67-ac5e-4403-8bdf-554522c3db9d",
	"6417559c-0b56-4cb0-91f4-53fc33fae1f3",
	"f83f1cf6-f18c-442d-a405-a6f4db927b50",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("35ef475f-c602-4b2f-8ea5-3923236d0e5e",
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0",
	"00000000-0000-0000-0000-000000000000",
	3,
	1,
	'box::solving line: 3');
INSERT INTO ACT_EL
	VALUES ("35ef475f-c602-4b2f-8ea5-3923236d0e5e",
	"4287dcda-7820-43c4-8e18-0c669a742276",
	"8eb81471-dd67-4b2a-af8e-84f2504a0f53",
	"661a2a67-ac5e-4403-8bdf-554522c3db9d");
INSERT INTO ACT_SMT
	VALUES ("8d5bbda9-d87b-47df-968c-76aaf03505a5",
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'box::solving line: 5');
INSERT INTO ACT_E
	VALUES ("8d5bbda9-d87b-47df-968c-76aaf03505a5",
	"80ebcd97-2cba-4002-9e85-a1f589750cbf",
	"661a2a67-ac5e-4403-8bdf-554522c3db9d");
INSERT INTO V_VAL
	VALUES ("7becc329-c611-4542-a09e-3aaf34cfbcd1",
	0,
	0,
	1,
	6,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0");
INSERT INTO V_LIN
	VALUES ("7becc329-c611-4542-a09e-3aaf34cfbcd1",
	'100');
INSERT INTO V_VAL
	VALUES ("f83f1cf6-f18c-442d-a405-a6f4db927b50",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0");
INSERT INTO V_BIN
	VALUES ("f83f1cf6-f18c-442d-a405-a6f4db927b50",
	"d7c13dac-0f0e-4549-9bf6-0d91c22b6040",
	"7becc329-c611-4542-a09e-3aaf34cfbcd1",
	'==');
INSERT INTO V_VAL
	VALUES ("d7c13dac-0f0e-4549-9bf6-0d91c22b6040",
	0,
	0,
	1,
	18,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0");
INSERT INTO V_TRV
	VALUES ("d7c13dac-0f0e-4549-9bf6-0d91c22b6040",
	"30f7d1fd-f731-455f-93b4-963d0aa6e745",
	"7457c608-2df8-46bd-ae0b-60432344244d",
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("8acaaa7f-006c-418e-90cb-000592f9a213",
	0,
	0,
	3,
	8,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0");
INSERT INTO V_LIN
	VALUES ("8acaaa7f-006c-418e-90cb-000592f9a213",
	'100');
INSERT INTO V_VAL
	VALUES ("8eb81471-dd67-4b2a-af8e-84f2504a0f53",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0");
INSERT INTO V_BIN
	VALUES ("8eb81471-dd67-4b2a-af8e-84f2504a0f53",
	"8e701304-41d2-475f-9868-46036ba7cf1b",
	"8acaaa7f-006c-418e-90cb-000592f9a213",
	'==');
INSERT INTO V_VAL
	VALUES ("8e701304-41d2-475f-9868-46036ba7cf1b",
	0,
	0,
	3,
	20,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0");
INSERT INTO V_TRV
	VALUES ("8e701304-41d2-475f-9868-46036ba7cf1b",
	"95951fd8-2a86-4a4a-b9aa-8e2e2e1bbd9b",
	"7457c608-2df8-46bd-ae0b-60432344244d",
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("7457c608-2df8-46bd-ae0b-60432344244d",
	"6e7e10f3-ce37-4d91-8692-ede1beb78fc0",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("7457c608-2df8-46bd-ae0b-60432344244d",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("4025c59f-295b-46a1-99fb-b8aafc5d4bef",
	1,
	13,
	16,
	"7457c608-2df8-46bd-ae0b-60432344244d");
INSERT INTO V_LOC
	VALUES ("3e0fc974-5dda-407e-ae7e-84225881b613",
	2,
	29,
	32,
	"7457c608-2df8-46bd-ae0b-60432344244d");
INSERT INTO V_LOC
	VALUES ("ac997874-3d39-4e16-bf6c-4c8abde93d48",
	3,
	15,
	18,
	"7457c608-2df8-46bd-ae0b-60432344244d");
INSERT INTO V_LOC
	VALUES ("e14ed0e0-502c-42f2-a9fd-40945bb58970",
	4,
	29,
	32,
	"7457c608-2df8-46bd-ae0b-60432344244d");
INSERT INTO V_LOC
	VALUES ("2a6fe74d-afff-4294-99ca-59700712433c",
	9,
	9,
	12,
	"7457c608-2df8-46bd-ae0b-60432344244d");
INSERT INTO ACT_BLK
	VALUES ("6417559c-0b56-4cb0-91f4-53fc33fae1f3",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"94519cb8-eda7-42dd-9828-6ddbc40b94cf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9d161544-ff4a-486d-98ad-9556a6374547",
	"6417559c-0b56-4cb0-91f4-53fc33fae1f3",
	"00000000-0000-0000-0000-000000000000",
	2,
	3,
	'box::solving line: 2');
INSERT INTO E_ESS
	VALUES ("9d161544-ff4a-486d-98ad-9556a6374547",
	1,
	0,
	2,
	12,
	2,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("9d161544-ff4a-486d-98ad-9556a6374547");
INSERT INTO E_GSME
	VALUES ("9d161544-ff4a-486d-98ad-9556a6374547",
	"4c7c35ce-32c1-44e1-946b-9be559269144",
	"415f7ffb-d246-4025-9868-5f83c77ba291");
INSERT INTO E_GEN
	VALUES ("9d161544-ff4a-486d-98ad-9556a6374547",
	"7457c608-2df8-46bd-ae0b-60432344244d");
INSERT INTO ACT_BLK
	VALUES ("4287dcda-7820-43c4-8e18-0c669a742276",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"94519cb8-eda7-42dd-9828-6ddbc40b94cf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("a7b8881e-a7be-44d1-8f72-48fb1ae3f4e6",
	"4287dcda-7820-43c4-8e18-0c669a742276",
	"00000000-0000-0000-0000-000000000000",
	4,
	3,
	'box::solving line: 4');
INSERT INTO E_ESS
	VALUES ("a7b8881e-a7be-44d1-8f72-48fb1ae3f4e6",
	1,
	0,
	4,
	12,
	4,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("a7b8881e-a7be-44d1-8f72-48fb1ae3f4e6");
INSERT INTO E_GSME
	VALUES ("a7b8881e-a7be-44d1-8f72-48fb1ae3f4e6",
	"4c7c35ce-32c1-44e1-946b-9be559269144",
	"415f7ffb-d246-4025-9868-5f83c77ba291");
INSERT INTO E_GEN
	VALUES ("a7b8881e-a7be-44d1-8f72-48fb1ae3f4e6",
	"7457c608-2df8-46bd-ae0b-60432344244d");
INSERT INTO ACT_BLK
	VALUES ("80ebcd97-2cba-4002-9e85-a1f589750cbf",
	1,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	6,
	40,
	0,
	0,
	6,
	49,
	0,
	0,
	0,
	0,
	0,
	"94519cb8-eda7-42dd-9828-6ddbc40b94cf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("dc2025d5-2ca9-4a89-8e23-eb659840ac1b",
	"80ebcd97-2cba-4002-9e85-a1f589750cbf",
	"1e52ddf3-c29b-4ad7-9d66-b0d2d4fb4e68",
	6,
	3,
	'box::solving line: 6');
INSERT INTO ACT_SEL
	VALUES ("dc2025d5-2ca9-4a89-8e23-eb659840ac1b",
	"d7b61e75-24e8-4b32-9ef7-98eda8f939b9",
	1,
	'one',
	"6152c1b3-cbf5-4fe7-a465-c312cf78e272");
INSERT INTO ACT_SR
	VALUES ("dc2025d5-2ca9-4a89-8e23-eb659840ac1b");
INSERT INTO ACT_LNK
	VALUES ("b81aeea4-a0c9-4c48-bf8b-67f432ad2f10",
	'',
	"dc2025d5-2ca9-4a89-8e23-eb659840ac1b",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	6,
	40,
	6,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("1e52ddf3-c29b-4ad7-9d66-b0d2d4fb4e68",
	"80ebcd97-2cba-4002-9e85-a1f589750cbf",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'box::solving line: 7');
INSERT INTO ACT_IF
	VALUES ("1e52ddf3-c29b-4ad7-9d66-b0d2d4fb4e68",
	"4dcacb84-8842-4e72-b499-47f9fea5b761",
	"705c3c20-f578-490c-b257-b88996a111b1",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c370e591-b873-44bf-b1dd-cd69aa4c95c7",
	"80ebcd97-2cba-4002-9e85-a1f589750cbf",
	"00000000-0000-0000-0000-000000000000",
	11,
	3,
	'box::solving line: 11');
INSERT INTO ACT_E
	VALUES ("c370e591-b873-44bf-b1dd-cd69aa4c95c7",
	"1ea2f271-c58b-4afa-adb4-3372c58aa7e7",
	"1e52ddf3-c29b-4ad7-9d66-b0d2d4fb4e68");
INSERT INTO V_VAL
	VALUES ("6152c1b3-cbf5-4fe7-a465-c312cf78e272",
	0,
	0,
	6,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"80ebcd97-2cba-4002-9e85-a1f589750cbf");
INSERT INTO V_IRF
	VALUES ("6152c1b3-cbf5-4fe7-a465-c312cf78e272",
	"7457c608-2df8-46bd-ae0b-60432344244d");
INSERT INTO V_VAL
	VALUES ("d0b3324a-f8ca-43e4-9d7d-6fdc2aba69f4",
	0,
	0,
	7,
	8,
	15,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"80ebcd97-2cba-4002-9e85-a1f589750cbf");
INSERT INTO V_IRF
	VALUES ("d0b3324a-f8ca-43e4-9d7d-6fdc2aba69f4",
	"d7b61e75-24e8-4b32-9ef7-98eda8f939b9");
INSERT INTO V_VAL
	VALUES ("37fbbfc6-0c87-41ed-b7c7-4088f38d0ea5",
	0,
	0,
	7,
	17,
	24,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"80ebcd97-2cba-4002-9e85-a1f589750cbf");
INSERT INTO V_AVL
	VALUES ("37fbbfc6-0c87-41ed-b7c7-4088f38d0ea5",
	"d0b3324a-f8ca-43e4-9d7d-6fdc2aba69f4",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("705c3c20-f578-490c-b257-b88996a111b1",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"80ebcd97-2cba-4002-9e85-a1f589750cbf");
INSERT INTO V_BIN
	VALUES ("705c3c20-f578-490c-b257-b88996a111b1",
	"197e236f-cef5-4b4b-b1e6-16dd85c240f5",
	"37fbbfc6-0c87-41ed-b7c7-4088f38d0ea5",
	'>=');
INSERT INTO V_VAL
	VALUES ("197e236f-cef5-4b4b-b1e6-16dd85c240f5",
	0,
	0,
	7,
	29,
	29,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"80ebcd97-2cba-4002-9e85-a1f589750cbf");
INSERT INTO V_LIN
	VALUES ("197e236f-cef5-4b4b-b1e6-16dd85c240f5",
	'1');
INSERT INTO V_VAR
	VALUES ("d7b61e75-24e8-4b32-9ef7-98eda8f939b9",
	"80ebcd97-2cba-4002-9e85-a1f589750cbf",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("d7b61e75-24e8-4b32-9ef7-98eda8f939b9",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("7810f790-7487-4edf-bfb3-5180064d5960",
	6,
	14,
	21,
	"d7b61e75-24e8-4b32-9ef7-98eda8f939b9");
INSERT INTO V_LOC
	VALUES ("67b09b7a-d857-47a0-8913-65f8d1bb708f",
	7,
	8,
	15,
	"d7b61e75-24e8-4b32-9ef7-98eda8f939b9");
INSERT INTO V_LOC
	VALUES ("97f1d429-7b08-4b19-a42a-f42e50dcaa24",
	8,
	5,
	12,
	"d7b61e75-24e8-4b32-9ef7-98eda8f939b9");
INSERT INTO V_LOC
	VALUES ("639d98e1-7cf5-400a-bb2e-67f7fa02e9aa",
	12,
	5,
	12,
	"d7b61e75-24e8-4b32-9ef7-98eda8f939b9");
INSERT INTO ACT_BLK
	VALUES ("4dcacb84-8842-4e72-b499-47f9fea5b761",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"94519cb8-eda7-42dd-9828-6ddbc40b94cf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b1a95b5d-f4cf-4f70-b1f9-5ca8f3d602e1",
	"4dcacb84-8842-4e72-b499-47f9fea5b761",
	"c46f56b2-9c4d-4127-877e-217c5a074632",
	8,
	5,
	'box::solving line: 8');
INSERT INTO ACT_AI
	VALUES ("b1a95b5d-f4cf-4f70-b1f9-5ca8f3d602e1",
	"c01445e9-73a1-4556-acb1-25ba4a5ef3fd",
	"a04e9271-ee0b-4699-b61a-9c6fdf19affa",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c46f56b2-9c4d-4127-877e-217c5a074632",
	"4dcacb84-8842-4e72-b499-47f9fea5b761",
	"ccc9eb1f-8e04-41a5-bea1-7945dca85273",
	9,
	5,
	'box::solving line: 9');
INSERT INTO ACT_AI
	VALUES ("c46f56b2-9c4d-4127-877e-217c5a074632",
	"237274dc-ed3b-42b0-8bfc-b6ea586a08e3",
	"17f4d6c6-9f5c-4aed-81a7-1b358779f01e",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ccc9eb1f-8e04-41a5-bea1-7945dca85273",
	"4dcacb84-8842-4e72-b499-47f9fea5b761",
	"00000000-0000-0000-0000-000000000000",
	10,
	5,
	'box::solving line: 10');
INSERT INTO E_ESS
	VALUES ("ccc9eb1f-8e04-41a5-bea1-7945dca85273",
	1,
	0,
	10,
	14,
	10,
	19,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("ccc9eb1f-8e04-41a5-bea1-7945dca85273");
INSERT INTO E_GSME
	VALUES ("ccc9eb1f-8e04-41a5-bea1-7945dca85273",
	"4a74f6cd-a33f-407c-abac-8419734741c7",
	"415f7ffb-d246-4025-9868-5f83c77ba291");
INSERT INTO E_GEN
	VALUES ("ccc9eb1f-8e04-41a5-bea1-7945dca85273",
	"39c2ad90-eb2b-4a04-bad2-167ee6bd8b15");
INSERT INTO V_VAL
	VALUES ("e220bb73-7126-4adf-8858-72b1086516b0",
	1,
	0,
	8,
	5,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"4dcacb84-8842-4e72-b499-47f9fea5b761");
INSERT INTO V_IRF
	VALUES ("e220bb73-7126-4adf-8858-72b1086516b0",
	"d7b61e75-24e8-4b32-9ef7-98eda8f939b9");
INSERT INTO V_VAL
	VALUES ("a04e9271-ee0b-4699-b61a-9c6fdf19affa",
	1,
	0,
	8,
	14,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4dcacb84-8842-4e72-b499-47f9fea5b761");
INSERT INTO V_AVL
	VALUES ("a04e9271-ee0b-4699-b61a-9c6fdf19affa",
	"e220bb73-7126-4adf-8858-72b1086516b0",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("c01445e9-73a1-4556-acb1-25ba4a5ef3fd",
	0,
	0,
	8,
	25,
	25,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4dcacb84-8842-4e72-b499-47f9fea5b761");
INSERT INTO V_LIN
	VALUES ("c01445e9-73a1-4556-acb1-25ba4a5ef3fd",
	'1');
INSERT INTO V_VAL
	VALUES ("17f4d6c6-9f5c-4aed-81a7-1b358779f01e",
	1,
	1,
	9,
	5,
	5,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"4dcacb84-8842-4e72-b499-47f9fea5b761");
INSERT INTO V_IRF
	VALUES ("17f4d6c6-9f5c-4aed-81a7-1b358779f01e",
	"39c2ad90-eb2b-4a04-bad2-167ee6bd8b15");
INSERT INTO V_VAL
	VALUES ("237274dc-ed3b-42b0-8bfc-b6ea586a08e3",
	0,
	0,
	9,
	9,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"4dcacb84-8842-4e72-b499-47f9fea5b761");
INSERT INTO V_IRF
	VALUES ("237274dc-ed3b-42b0-8bfc-b6ea586a08e3",
	"7457c608-2df8-46bd-ae0b-60432344244d");
INSERT INTO V_VAR
	VALUES ("39c2ad90-eb2b-4a04-bad2-167ee6bd8b15",
	"4dcacb84-8842-4e72-b499-47f9fea5b761",
	'b',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("39c2ad90-eb2b-4a04-bad2-167ee6bd8b15",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("a5ec6eb2-d23d-45af-bcad-46c09d0658ec",
	9,
	5,
	5,
	"39c2ad90-eb2b-4a04-bad2-167ee6bd8b15");
INSERT INTO V_LOC
	VALUES ("c4c7996f-b1e5-4b3e-ab96-ab857ca86065",
	10,
	31,
	31,
	"39c2ad90-eb2b-4a04-bad2-167ee6bd8b15");
INSERT INTO ACT_BLK
	VALUES ("1ea2f271-c58b-4afa-adb4-3372c58aa7e7",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"94519cb8-eda7-42dd-9828-6ddbc40b94cf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("174ae31f-f8bb-4bfb-80be-472d2f66f7b9",
	"1ea2f271-c58b-4afa-adb4-3372c58aa7e7",
	"00000000-0000-0000-0000-000000000000",
	12,
	5,
	'box::solving line: 12');
INSERT INTO ACT_AI
	VALUES ("174ae31f-f8bb-4bfb-80be-472d2f66f7b9",
	"e68fee81-7161-4ca8-a40d-788cbe92917d",
	"fd4ab2ce-15b5-4c44-9984-b777733fc289",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("7923b2ad-fa7d-4c22-9e8a-63267a29c523",
	1,
	0,
	12,
	5,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"1ea2f271-c58b-4afa-adb4-3372c58aa7e7");
INSERT INTO V_IRF
	VALUES ("7923b2ad-fa7d-4c22-9e8a-63267a29c523",
	"d7b61e75-24e8-4b32-9ef7-98eda8f939b9");
INSERT INTO V_VAL
	VALUES ("fd4ab2ce-15b5-4c44-9984-b777733fc289",
	1,
	0,
	12,
	14,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1ea2f271-c58b-4afa-adb4-3372c58aa7e7");
INSERT INTO V_AVL
	VALUES ("fd4ab2ce-15b5-4c44-9984-b777733fc289",
	"7923b2ad-fa7d-4c22-9e8a-63267a29c523",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("e68fee81-7161-4ca8-a40d-788cbe92917d",
	0,
	0,
	12,
	25,
	25,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1ea2f271-c58b-4afa-adb4-3372c58aa7e7");
INSERT INTO V_LIN
	VALUES ("e68fee81-7161-4ca8-a40d-788cbe92917d",
	'0');
INSERT INTO SM_STATE
	VALUES ("1f3071b2-28f5-4255-a715-2166d549cc09",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000",
	'solved',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES ("1f3071b2-28f5-4255-a715-2166d549cc09",
	"4a74f6cd-a33f-407c-abac-8419734741c7",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("1f3071b2-28f5-4255-a715-2166d549cc09",
	"4a74f6cd-a33f-407c-abac-8419734741c7",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EIGN
	VALUES ("1f3071b2-28f5-4255-a715-2166d549cc09",
	"4c7c35ce-32c1-44e1-946b-9be559269144",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("1f3071b2-28f5-4255-a715-2166d549cc09",
	"4c7c35ce-32c1-44e1-946b-9be559269144",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("a54fa2df-830b-45a7-8c28-b2b8068d1b5c",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"1f3071b2-28f5-4255-a715-2166d549cc09");
INSERT INTO SM_AH
	VALUES ("a54fa2df-830b-45a7-8c28-b2b8068d1b5c",
	"415f7ffb-d246-4025-9868-5f83c77ba291");
INSERT INTO SM_ACT
	VALUES ("a54fa2df-830b-45a7-8c28-b2b8068d1b5c",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	1,
	'select one sequence related by self->SEQUENCE[R1];
sequence.solved = true;',
	'');
INSERT INTO ACT_SAB
	VALUES ("ae079277-8512-4a62-8c27-bf3d095fb39a",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"a54fa2df-830b-45a7-8c28-b2b8068d1b5c");
INSERT INTO ACT_ACT
	VALUES ("ae079277-8512-4a62-8c27-bf3d095fb39a",
	'state',
	0,
	"75d1d19e-8c8e-4f7d-9db4-e23a1eb41c28",
	"00000000-0000-0000-0000-000000000000",
	0,
	'box::solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("75d1d19e-8c8e-4f7d-9db4-e23a1eb41c28",
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	1,
	47,
	0,
	0,
	0,
	0,
	0,
	"ae079277-8512-4a62-8c27-bf3d095fb39a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("bb0ec890-192e-4052-8777-09810ed23f1a",
	"75d1d19e-8c8e-4f7d-9db4-e23a1eb41c28",
	"a1953dcf-9b4b-4f54-8890-3d1c61c3d4c0",
	1,
	1,
	'box::solved line: 1');
INSERT INTO ACT_SEL
	VALUES ("bb0ec890-192e-4052-8777-09810ed23f1a",
	"46cd18b7-b637-41c0-b0a4-5b660f374d80",
	1,
	'one',
	"4375ed8d-d62d-47ad-b3c7-d042cb23e426");
INSERT INTO ACT_SR
	VALUES ("bb0ec890-192e-4052-8777-09810ed23f1a");
INSERT INTO ACT_LNK
	VALUES ("1250a94e-18dd-4a14-ab88-abe068ef1cb8",
	'',
	"bb0ec890-192e-4052-8777-09810ed23f1a",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	1,
	38,
	1,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a1953dcf-9b4b-4f54-8890-3d1c61c3d4c0",
	"75d1d19e-8c8e-4f7d-9db4-e23a1eb41c28",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'box::solved line: 2');
INSERT INTO ACT_AI
	VALUES ("a1953dcf-9b4b-4f54-8890-3d1c61c3d4c0",
	"f81c8b38-0287-4f87-ab40-719bb592477d",
	"dd543e8f-1fd4-4174-9ef4-1b394bac050d",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("4375ed8d-d62d-47ad-b3c7-d042cb23e426",
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"75d1d19e-8c8e-4f7d-9db4-e23a1eb41c28");
INSERT INTO V_IRF
	VALUES ("4375ed8d-d62d-47ad-b3c7-d042cb23e426",
	"44cc6a12-8a14-4d94-9386-ab8f2e9e6af0");
INSERT INTO V_VAL
	VALUES ("210c7cc3-d63a-4a74-8422-c449ffc96508",
	1,
	0,
	2,
	1,
	8,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"75d1d19e-8c8e-4f7d-9db4-e23a1eb41c28");
INSERT INTO V_IRF
	VALUES ("210c7cc3-d63a-4a74-8422-c449ffc96508",
	"46cd18b7-b637-41c0-b0a4-5b660f374d80");
INSERT INTO V_VAL
	VALUES ("dd543e8f-1fd4-4174-9ef4-1b394bac050d",
	1,
	0,
	2,
	10,
	15,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"75d1d19e-8c8e-4f7d-9db4-e23a1eb41c28");
INSERT INTO V_AVL
	VALUES ("dd543e8f-1fd4-4174-9ef4-1b394bac050d",
	"210c7cc3-d63a-4a74-8422-c449ffc96508",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"48d19dd8-8465-49b9-b4d0-dd14aa6d653f");
INSERT INTO V_VAL
	VALUES ("f81c8b38-0287-4f87-ab40-719bb592477d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"75d1d19e-8c8e-4f7d-9db4-e23a1eb41c28");
INSERT INTO V_LBO
	VALUES ("f81c8b38-0287-4f87-ab40-719bb592477d",
	'TRUE');
INSERT INTO V_VAR
	VALUES ("46cd18b7-b637-41c0-b0a4-5b660f374d80",
	"75d1d19e-8c8e-4f7d-9db4-e23a1eb41c28",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("46cd18b7-b637-41c0-b0a4-5b660f374d80",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("a8e2c2a3-c539-4a8e-bb9f-7f77c3e0185e",
	1,
	12,
	19,
	"46cd18b7-b637-41c0-b0a4-5b660f374d80");
INSERT INTO V_LOC
	VALUES ("221ec883-58ba-4198-9e53-ae435929a803",
	2,
	1,
	8,
	"46cd18b7-b637-41c0-b0a4-5b660f374d80");
INSERT INTO V_VAR
	VALUES ("44cc6a12-8a14-4d94-9386-ab8f2e9e6af0",
	"75d1d19e-8c8e-4f7d-9db4-e23a1eb41c28",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("44cc6a12-8a14-4d94-9386-ab8f2e9e6af0",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO SM_NSTXN
	VALUES ("3a23977c-462e-4b44-a3e4-b35e1e462d5d",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"60db9085-cfae-4bd3-b6bd-f821bcf14d50",
	"4a74f6cd-a33f-407c-abac-8419734741c7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("86c1869c-9fa9-44b2-a9c8-a07ab6f9c6a0",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"3a23977c-462e-4b44-a3e4-b35e1e462d5d");
INSERT INTO SM_AH
	VALUES ("86c1869c-9fa9-44b2-a9c8-a07ab6f9c6a0",
	"415f7ffb-d246-4025-9868-5f83c77ba291");
INSERT INTO SM_ACT
	VALUES ("86c1869c-9fa9-44b2-a9c8-a07ab6f9c6a0",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("c70ff3e4-d5a4-4765-9803-8c2ef6515e0b",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"86c1869c-9fa9-44b2-a9c8-a07ab6f9c6a0");
INSERT INTO ACT_ACT
	VALUES ("c70ff3e4-d5a4-4765-9803-8c2ef6515e0b",
	'transition',
	0,
	"f5208ee3-cc8e-41a1-9299-bd87dbac968c",
	"00000000-0000-0000-0000-000000000000",
	0,
	'BOX1: update in solving to solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("f5208ee3-cc8e-41a1-9299-bd87dbac968c",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"c70ff3e4-d5a4-4765-9803-8c2ef6515e0b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("3a23977c-462e-4b44-a3e4-b35e1e462d5d",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"60db9085-cfae-4bd3-b6bd-f821bcf14d50",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("f41e33b7-e981-4f14-b695-5ff43c3c8aa9",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"60db9085-cfae-4bd3-b6bd-f821bcf14d50",
	"4c7c35ce-32c1-44e1-946b-9be559269144",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("b8f847ad-6bd8-4a54-af4e-0dacab6b0c45",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"f41e33b7-e981-4f14-b695-5ff43c3c8aa9");
INSERT INTO SM_AH
	VALUES ("b8f847ad-6bd8-4a54-af4e-0dacab6b0c45",
	"415f7ffb-d246-4025-9868-5f83c77ba291");
INSERT INTO SM_ACT
	VALUES ("b8f847ad-6bd8-4a54-af4e-0dacab6b0c45",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("64a8874f-5eee-4d92-a0c5-f40c0c10a624",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"b8f847ad-6bd8-4a54-af4e-0dacab6b0c45");
INSERT INTO ACT_ACT
	VALUES ("64a8874f-5eee-4d92-a0c5-f40c0c10a624",
	'transition',
	0,
	"8c18d6d3-54fa-4cca-ab49-e4e6d6336bd0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'BOX2: solved in solving to solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("8c18d6d3-54fa-4cca-ab49-e4e6d6336bd0",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"64a8874f-5eee-4d92-a0c5-f40c0c10a624",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("f41e33b7-e981-4f14-b695-5ff43c3c8aa9",
	"415f7ffb-d246-4025-9868-5f83c77ba291",
	"1f3071b2-28f5-4255-a715-2166d549cc09",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_OBJ
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	'cell',
	5,
	'CELL',
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO O_TFR
	VALUES ("08064e1a-888f-4d00-a98e-bcce7359c03d",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	'set_given',
	'',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	0,
	'select any cell from instances of CELL
  where ( ( selected.row_number == param.row ) and 
          ( selected.column_number == param.column ) );
cell.answer( answer_digit:param.answer );',
	1,
	'',
	"e7682414-c9d4-490e-84ef-68b46fb9a8f1");
INSERT INTO O_TPARM
	VALUES ("5f6e7249-0d87-41ec-a1c1-63bf136d4fc2",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	'row',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"8268fb51-41c7-4009-acd4-3721c558fbc5",
	'');
INSERT INTO O_TPARM
	VALUES ("8268fb51-41c7-4009-acd4-3721c558fbc5",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	'column',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"60f2c667-c4cc-47e8-86ac-3d2de82335a5",
	'');
INSERT INTO O_TPARM
	VALUES ("60f2c667-c4cc-47e8-86ac-3d2de82335a5",
	"08064e1a-888f-4d00-a98e-bcce7359c03d",
	'answer',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_OPB
	VALUES ("c5a5db4b-1599-484a-abe3-b124df5022dd",
	"08064e1a-888f-4d00-a98e-bcce7359c03d");
INSERT INTO ACT_ACT
	VALUES ("c5a5db4b-1599-484a-abe3-b124df5022dd",
	'class operation',
	0,
	"be518d0c-5427-4783-9209-6ba014f488fb",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cell::set_given',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("be518d0c-5427-4783-9209-6ba014f488fb",
	1,
	0,
	1,
	'',
	'',
	'',
	4,
	1,
	1,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"c5a5db4b-1599-484a-abe3-b124df5022dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b8be15d6-f4a3-446f-9b61-0ba0238c5915",
	"be518d0c-5427-4783-9209-6ba014f488fb",
	"300de2dd-f728-465c-9b5c-2fe5d226d3d9",
	1,
	1,
	'cell::set_given line: 1');
INSERT INTO ACT_FIW
	VALUES ("b8be15d6-f4a3-446f-9b61-0ba0238c5915",
	"b1a3e28b-988b-463e-b04d-f61ee5372af2",
	1,
	'any',
	"9ec06f2d-5e7e-4be9-9058-734686373024",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	1,
	35);
INSERT INTO ACT_SMT
	VALUES ("300de2dd-f728-465c-9b5c-2fe5d226d3d9",
	"be518d0c-5427-4783-9209-6ba014f488fb",
	"00000000-0000-0000-0000-000000000000",
	4,
	1,
	'cell::set_given line: 4');
INSERT INTO ACT_TFM
	VALUES ("300de2dd-f728-465c-9b5c-2fe5d226d3d9",
	"a3632caa-a4af-4c7b-8e5d-212826ddcf99",
	"b1a3e28b-988b-463e-b04d-f61ee5372af2",
	4,
	6,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("c0041eea-6182-4805-80ae-6faa67b09765",
	0,
	0,
	2,
	13,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"be518d0c-5427-4783-9209-6ba014f488fb");
INSERT INTO V_SLR
	VALUES ("c0041eea-6182-4805-80ae-6faa67b09765",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("7fca9932-c100-4bd4-9877-25f9cf109564",
	0,
	0,
	2,
	22,
	31,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"be518d0c-5427-4783-9209-6ba014f488fb");
INSERT INTO V_AVL
	VALUES ("7fca9932-c100-4bd4-9877-25f9cf109564",
	"c0041eea-6182-4805-80ae-6faa67b09765",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548");
INSERT INTO V_VAL
	VALUES ("a1301006-f4ed-49b7-b867-4b0b6b5ac23d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"be518d0c-5427-4783-9209-6ba014f488fb");
INSERT INTO V_BIN
	VALUES ("a1301006-f4ed-49b7-b867-4b0b6b5ac23d",
	"e7bbe9d2-3204-4d24-8187-9e5ac412cdf1",
	"7fca9932-c100-4bd4-9877-25f9cf109564",
	'==');
INSERT INTO V_VAL
	VALUES ("e7bbe9d2-3204-4d24-8187-9e5ac412cdf1",
	0,
	0,
	2,
	42,
	44,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"be518d0c-5427-4783-9209-6ba014f488fb");
INSERT INTO V_PVL
	VALUES ("e7bbe9d2-3204-4d24-8187-9e5ac412cdf1",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"5f6e7249-0d87-41ec-a1c1-63bf136d4fc2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("7f4cd526-69a0-4e08-b432-d314505dc8fd",
	0,
	0,
	3,
	13,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"be518d0c-5427-4783-9209-6ba014f488fb");
INSERT INTO V_SLR
	VALUES ("7f4cd526-69a0-4e08-b432-d314505dc8fd",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("3d45a0dc-06f5-430a-a49c-ad231f28679e",
	0,
	0,
	3,
	22,
	34,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"be518d0c-5427-4783-9209-6ba014f488fb");
INSERT INTO V_AVL
	VALUES ("3d45a0dc-06f5-430a-a49c-ad231f28679e",
	"7f4cd526-69a0-4e08-b432-d314505dc8fd",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05");
INSERT INTO V_VAL
	VALUES ("bf7934ae-6e87-45b8-b5e0-e0e95a1550f8",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"be518d0c-5427-4783-9209-6ba014f488fb");
INSERT INTO V_BIN
	VALUES ("bf7934ae-6e87-45b8-b5e0-e0e95a1550f8",
	"5768bbc2-9b14-496d-a3a5-4f188b414240",
	"3d45a0dc-06f5-430a-a49c-ad231f28679e",
	'==');
INSERT INTO V_VAL
	VALUES ("5768bbc2-9b14-496d-a3a5-4f188b414240",
	0,
	0,
	3,
	45,
	50,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"be518d0c-5427-4783-9209-6ba014f488fb");
INSERT INTO V_PVL
	VALUES ("5768bbc2-9b14-496d-a3a5-4f188b414240",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"8268fb51-41c7-4009-acd4-3721c558fbc5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("9ec06f2d-5e7e-4be9-9058-734686373024",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"be518d0c-5427-4783-9209-6ba014f488fb");
INSERT INTO V_BIN
	VALUES ("9ec06f2d-5e7e-4be9-9058-734686373024",
	"bf7934ae-6e87-45b8-b5e0-e0e95a1550f8",
	"a1301006-f4ed-49b7-b867-4b0b6b5ac23d",
	'and');
INSERT INTO V_VAL
	VALUES ("327a6400-0177-4e50-9ddc-36df7c193344",
	0,
	0,
	4,
	33,
	38,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"be518d0c-5427-4783-9209-6ba014f488fb");
INSERT INTO V_PVL
	VALUES ("327a6400-0177-4e50-9ddc-36df7c193344",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"60f2c667-c4cc-47e8-86ac-3d2de82335a5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_PAR
	VALUES ("327a6400-0177-4e50-9ddc-36df7c193344",
	"300de2dd-f728-465c-9b5c-2fe5d226d3d9",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	4,
	14);
INSERT INTO V_VAR
	VALUES ("b1a3e28b-988b-463e-b04d-f61ee5372af2",
	"be518d0c-5427-4783-9209-6ba014f488fb",
	'cell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("b1a3e28b-988b-463e-b04d-f61ee5372af2",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("61afa348-aca7-476b-9057-cc803b989f2a",
	1,
	12,
	15,
	"b1a3e28b-988b-463e-b04d-f61ee5372af2");
INSERT INTO V_LOC
	VALUES ("82d3bf0e-783d-46e2-914d-5ec9bfb475a2",
	4,
	1,
	4,
	"b1a3e28b-988b-463e-b04d-f61ee5372af2");
INSERT INTO O_TFR
	VALUES ("a3632caa-a4af-4c7b-8e5d-212826ddcf99",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	'answer',
	'',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'// An answer has been found, so remove the eligible
// digits which are now ineligible digits.
select one zerodigit related by self->DIGIT[R9] where ( selected.value == 0 );
if ( not_empty zerodigit )
  unrelate self from zerodigit across R9;
end if;

// Link in the answer.
select any digit from instances of DIGIT 
  where ( selected.value == param.answer_digit );
if ( not_empty digit )
  relate self to digit across R9;
end if;

// Unlink the other digits.  There can be only one answer.
select many ineligibles related by self->ELIGIBLE[R8]
  where ( selected.digit_value != param.answer_digit );
for each ineligible in ineligibles
  // generate ELIGIBLE1:eliminate() to inelible;
  ineligible.eliminate();
end for;',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_TPARM
	VALUES ("4436363e-1aef-487d-8d86-22081898aeb9",
	"a3632caa-a4af-4c7b-8e5d-212826ddcf99",
	'answer_digit',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_OPB
	VALUES ("5608e36c-a10f-454c-81b5-8460b93fe01c",
	"a3632caa-a4af-4c7b-8e5d-212826ddcf99");
INSERT INTO ACT_ACT
	VALUES ("5608e36c-a10f-454c-81b5-8460b93fe01c",
	'operation',
	0,
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cell::answer',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("e7fdd578-ad24-4c2e-829f-9010bd249564",
	1,
	0,
	1,
	'',
	'',
	'',
	18,
	1,
	16,
	42,
	0,
	0,
	16,
	51,
	0,
	0,
	0,
	0,
	0,
	"5608e36c-a10f-454c-81b5-8460b93fe01c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5f605c34-8bb1-48c6-9fb4-75edec691332",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	"34450c93-596f-4d71-bd33-b0c5085bf3f5",
	3,
	1,
	'cell::answer line: 3');
INSERT INTO ACT_SEL
	VALUES ("5f605c34-8bb1-48c6-9fb4-75edec691332",
	"59b66bdf-f669-410f-b26d-a31a191c4e48",
	1,
	'one',
	"96fb0fdb-6a0f-4367-bce6-96c5d41ba2c2");
INSERT INTO ACT_SRW
	VALUES ("5f605c34-8bb1-48c6-9fb4-75edec691332",
	"04f5e178-a3e3-4310-9d0b-40b91b59cd20");
INSERT INTO ACT_LNK
	VALUES ("8bd05a39-e35f-4594-ad58-48b90aa00a9c",
	'',
	"5f605c34-8bb1-48c6-9fb4-75edec691332",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"00000000-0000-0000-0000-000000000000",
	2,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	3,
	39,
	3,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("34450c93-596f-4d71-bd33-b0c5085bf3f5",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	"d42524d3-690e-4125-bd98-20992df63cb0",
	4,
	1,
	'cell::answer line: 4');
INSERT INTO ACT_IF
	VALUES ("34450c93-596f-4d71-bd33-b0c5085bf3f5",
	"1f96098d-f25f-4b3f-8281-35db67231338",
	"0ebdd148-7833-4e17-95a5-cfa9323d21dd",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d42524d3-690e-4125-bd98-20992df63cb0",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	"5b80bc20-df30-43cc-927e-f9092a75b3bd",
	9,
	1,
	'cell::answer line: 9');
INSERT INTO ACT_FIW
	VALUES ("d42524d3-690e-4125-bd98-20992df63cb0",
	"9f2522e6-a216-4ff4-afd0-cf7de97ea59e",
	1,
	'any',
	"cfca880e-00a1-4a25-9e30-06f88c038afd",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	9,
	36);
INSERT INTO ACT_SMT
	VALUES ("5b80bc20-df30-43cc-927e-f9092a75b3bd",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	"4f553f87-7513-4bfc-9d43-5e2897d39277",
	11,
	1,
	'cell::answer line: 11');
INSERT INTO ACT_IF
	VALUES ("5b80bc20-df30-43cc-927e-f9092a75b3bd",
	"ca6c5bfa-7dfe-40ba-9ea0-61dd6390f8e5",
	"48598575-ddf4-4580-ad56-5a8f08eee578",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4f553f87-7513-4bfc-9d43-5e2897d39277",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	"7b2f3938-f99f-4581-878e-25a0f64d143a",
	16,
	1,
	'cell::answer line: 16');
INSERT INTO ACT_SEL
	VALUES ("4f553f87-7513-4bfc-9d43-5e2897d39277",
	"2a6ea6f7-3ff7-4173-816e-708dd836b5e8",
	1,
	'many',
	"f22a59ca-eb0a-483b-bf5c-5f3a8d568bd6");
INSERT INTO ACT_SRW
	VALUES ("4f553f87-7513-4bfc-9d43-5e2897d39277",
	"70f8e643-8337-449c-ba4b-cce032e599f7");
INSERT INTO ACT_LNK
	VALUES ("23a1ffff-898f-4488-a928-0df590ec5df2",
	'',
	"4f553f87-7513-4bfc-9d43-5e2897d39277",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	16,
	42,
	16,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7b2f3938-f99f-4581-878e-25a0f64d143a",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	"00000000-0000-0000-0000-000000000000",
	18,
	1,
	'cell::answer line: 18');
INSERT INTO ACT_FOR
	VALUES ("7b2f3938-f99f-4581-878e-25a0f64d143a",
	"d4fbf6d3-a7fd-4fc3-8dd2-759829774911",
	1,
	"1c10d0cd-36ea-4c0b-8345-c66dca41a638",
	"2a6ea6f7-3ff7-4173-816e-708dd836b5e8",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_VAL
	VALUES ("96fb0fdb-6a0f-4367-bce6-96c5d41ba2c2",
	0,
	0,
	3,
	33,
	36,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_IRF
	VALUES ("96fb0fdb-6a0f-4367-bce6-96c5d41ba2c2",
	"2c6dd143-0339-4d29-afd9-94a2ff0694d1");
INSERT INTO V_VAL
	VALUES ("23393eae-befd-49a7-b8ba-ccdef7ac56ae",
	0,
	0,
	3,
	57,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_SLR
	VALUES ("23393eae-befd-49a7-b8ba-ccdef7ac56ae",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("3d211576-7bc5-497b-bfb7-89519af95487",
	0,
	0,
	3,
	66,
	70,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_AVL
	VALUES ("3d211576-7bc5-497b-bfb7-89519af95487",
	"23393eae-befd-49a7-b8ba-ccdef7ac56ae",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO V_VAL
	VALUES ("04f5e178-a3e3-4310-9d0b-40b91b59cd20",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_BIN
	VALUES ("04f5e178-a3e3-4310-9d0b-40b91b59cd20",
	"e366fb88-370d-48a7-b2a9-32ddefffc910",
	"3d211576-7bc5-497b-bfb7-89519af95487",
	'==');
INSERT INTO V_VAL
	VALUES ("e366fb88-370d-48a7-b2a9-32ddefffc910",
	0,
	0,
	3,
	75,
	75,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_LIN
	VALUES ("e366fb88-370d-48a7-b2a9-32ddefffc910",
	'0');
INSERT INTO V_VAL
	VALUES ("78e770d7-085a-4c79-b757-6b70d099bfe0",
	0,
	0,
	4,
	16,
	24,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_IRF
	VALUES ("78e770d7-085a-4c79-b757-6b70d099bfe0",
	"59b66bdf-f669-410f-b26d-a31a191c4e48");
INSERT INTO V_VAL
	VALUES ("0ebdd148-7833-4e17-95a5-cfa9323d21dd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_UNY
	VALUES ("0ebdd148-7833-4e17-95a5-cfa9323d21dd",
	"78e770d7-085a-4c79-b757-6b70d099bfe0",
	'not_empty');
INSERT INTO V_VAL
	VALUES ("e3e59875-53d6-4bff-8d80-009d1121661f",
	0,
	0,
	10,
	11,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_SLR
	VALUES ("e3e59875-53d6-4bff-8d80-009d1121661f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("902abe19-70e4-41fa-a85f-3af399364483",
	0,
	0,
	10,
	20,
	24,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_AVL
	VALUES ("902abe19-70e4-41fa-a85f-3af399364483",
	"e3e59875-53d6-4bff-8d80-009d1121661f",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO V_VAL
	VALUES ("cfca880e-00a1-4a25-9e30-06f88c038afd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_BIN
	VALUES ("cfca880e-00a1-4a25-9e30-06f88c038afd",
	"e1ae4e09-ec42-4b37-9d81-8f29a9ae235e",
	"902abe19-70e4-41fa-a85f-3af399364483",
	'==');
INSERT INTO V_VAL
	VALUES ("e1ae4e09-ec42-4b37-9d81-8f29a9ae235e",
	0,
	0,
	10,
	35,
	46,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_PVL
	VALUES ("e1ae4e09-ec42-4b37-9d81-8f29a9ae235e",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"4436363e-1aef-487d-8d86-22081898aeb9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("c038223f-788f-449c-8a6c-44321e32ccfb",
	0,
	0,
	11,
	16,
	20,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_IRF
	VALUES ("c038223f-788f-449c-8a6c-44321e32ccfb",
	"9f2522e6-a216-4ff4-afd0-cf7de97ea59e");
INSERT INTO V_VAL
	VALUES ("48598575-ddf4-4580-ad56-5a8f08eee578",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_UNY
	VALUES ("48598575-ddf4-4580-ad56-5a8f08eee578",
	"c038223f-788f-449c-8a6c-44321e32ccfb",
	'not_empty');
INSERT INTO V_VAL
	VALUES ("f22a59ca-eb0a-483b-bf5c-5f3a8d568bd6",
	0,
	0,
	16,
	36,
	39,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_IRF
	VALUES ("f22a59ca-eb0a-483b-bf5c-5f3a8d568bd6",
	"2c6dd143-0339-4d29-afd9-94a2ff0694d1");
INSERT INTO V_VAL
	VALUES ("27a25da8-19b3-4c11-a484-f105d2bcccd7",
	0,
	0,
	17,
	11,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_SLR
	VALUES ("27a25da8-19b3-4c11-a484-f105d2bcccd7",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("f480fa57-5d94-4fcb-a492-f6a38e571f72",
	0,
	0,
	17,
	20,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_AVL
	VALUES ("f480fa57-5d94-4fcb-a492-f6a38e571f72",
	"27a25da8-19b3-4c11-a484-f105d2bcccd7",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("70f8e643-8337-449c-ba4b-cce032e599f7",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_BIN
	VALUES ("70f8e643-8337-449c-ba4b-cce032e599f7",
	"7f8a9396-aa30-4b06-9eea-75611b4e5727",
	"f480fa57-5d94-4fcb-a492-f6a38e571f72",
	'!=');
INSERT INTO V_VAL
	VALUES ("7f8a9396-aa30-4b06-9eea-75611b4e5727",
	0,
	0,
	17,
	41,
	52,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e7fdd578-ad24-4c2e-829f-9010bd249564");
INSERT INTO V_PVL
	VALUES ("7f8a9396-aa30-4b06-9eea-75611b4e5727",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"4436363e-1aef-487d-8d86-22081898aeb9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAR
	VALUES ("59b66bdf-f669-410f-b26d-a31a191c4e48",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	'zerodigit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("59b66bdf-f669-410f-b26d-a31a191c4e48",
	0,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("a4fe727d-68a1-4bdc-ad03-e03b1b7560eb",
	3,
	12,
	20,
	"59b66bdf-f669-410f-b26d-a31a191c4e48");
INSERT INTO V_LOC
	VALUES ("8ff5a4e0-ed21-4bff-ad47-4c6e37ca8d3b",
	5,
	22,
	30,
	"59b66bdf-f669-410f-b26d-a31a191c4e48");
INSERT INTO V_VAR
	VALUES ("2c6dd143-0339-4d29-afd9-94a2ff0694d1",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("2c6dd143-0339-4d29-afd9-94a2ff0694d1",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("09cb8022-e109-4509-8649-4db52cdeb45e",
	5,
	12,
	15,
	"2c6dd143-0339-4d29-afd9-94a2ff0694d1");
INSERT INTO V_LOC
	VALUES ("3ab008ce-09dc-48bc-9c30-a9c4db89cc65",
	12,
	10,
	13,
	"2c6dd143-0339-4d29-afd9-94a2ff0694d1");
INSERT INTO V_VAR
	VALUES ("9f2522e6-a216-4ff4-afd0-cf7de97ea59e",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	'digit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("9f2522e6-a216-4ff4-afd0-cf7de97ea59e",
	0,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("ad740fd2-ddbc-418a-b798-618710c0fb5e",
	9,
	12,
	16,
	"9f2522e6-a216-4ff4-afd0-cf7de97ea59e");
INSERT INTO V_LOC
	VALUES ("c0511338-16f7-4455-a007-54f64571231a",
	12,
	18,
	22,
	"9f2522e6-a216-4ff4-afd0-cf7de97ea59e");
INSERT INTO V_VAR
	VALUES ("2a6ea6f7-3ff7-4173-816e-708dd836b5e8",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	'ineligibles',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("2a6ea6f7-3ff7-4173-816e-708dd836b5e8",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("da7128c0-b89a-4969-9988-5b51b0cab880",
	16,
	13,
	23,
	"2a6ea6f7-3ff7-4173-816e-708dd836b5e8");
INSERT INTO V_LOC
	VALUES ("a6cc36fe-880f-4372-a4f0-7cd4696bf96d",
	18,
	24,
	34,
	"2a6ea6f7-3ff7-4173-816e-708dd836b5e8");
INSERT INTO V_VAR
	VALUES ("1c10d0cd-36ea-4c0b-8345-c66dca41a638",
	"e7fdd578-ad24-4c2e-829f-9010bd249564",
	'ineligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("1c10d0cd-36ea-4c0b-8345-c66dca41a638",
	1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("08346fff-cb03-43af-8ac7-8baa39da7ad9",
	18,
	10,
	19,
	"1c10d0cd-36ea-4c0b-8345-c66dca41a638");
INSERT INTO V_LOC
	VALUES ("aeec5a53-4bf5-4cd9-ad9a-6d743002323c",
	20,
	3,
	12,
	"1c10d0cd-36ea-4c0b-8345-c66dca41a638");
INSERT INTO ACT_BLK
	VALUES ("1f96098d-f25f-4b3f-8281-35db67231338",
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	3,
	0,
	0,
	0,
	0,
	5,
	39,
	0,
	0,
	0,
	0,
	0,
	"5608e36c-a10f-454c-81b5-8460b93fe01c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7a56ed71-80d6-46ef-99d7-1940ce678339",
	"1f96098d-f25f-4b3f-8281-35db67231338",
	"00000000-0000-0000-0000-000000000000",
	5,
	3,
	'cell::answer line: 5');
INSERT INTO ACT_UNR
	VALUES ("7a56ed71-80d6-46ef-99d7-1940ce678339",
	"2c6dd143-0339-4d29-afd9-94a2ff0694d1",
	"59b66bdf-f669-410f-b26d-a31a191c4e48",
	'',
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	5,
	39,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("ca6c5bfa-7dfe-40ba-9ea0-61dd6390f8e5",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	3,
	0,
	0,
	0,
	0,
	12,
	31,
	0,
	0,
	0,
	0,
	0,
	"5608e36c-a10f-454c-81b5-8460b93fe01c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("2fd46eb4-24fa-4ad2-975c-322a0b4ba503",
	"ca6c5bfa-7dfe-40ba-9ea0-61dd6390f8e5",
	"00000000-0000-0000-0000-000000000000",
	12,
	3,
	'cell::answer line: 12');
INSERT INTO ACT_REL
	VALUES ("2fd46eb4-24fa-4ad2-975c-322a0b4ba503",
	"2c6dd143-0339-4d29-afd9-94a2ff0694d1",
	"9f2522e6-a216-4ff4-afd0-cf7de97ea59e",
	'',
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	12,
	31,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("d4fbf6d3-a7fd-4fc3-8dd2-759829774911",
	0,
	0,
	0,
	'',
	'',
	'',
	20,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"5608e36c-a10f-454c-81b5-8460b93fe01c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c500f370-639a-4cfc-8f2b-7e7bcd95e8ba",
	"d4fbf6d3-a7fd-4fc3-8dd2-759829774911",
	"00000000-0000-0000-0000-000000000000",
	20,
	3,
	'cell::answer line: 20');
INSERT INTO ACT_TFM
	VALUES ("c500f370-639a-4cfc-8f2b-7e7bcd95e8ba",
	"d02e6fa1-63a8-45ba-8a60-27232a956e33",
	"1c10d0cd-36ea-4c0b-8345-c66dca41a638",
	20,
	14,
	0,
	0);
INSERT INTO O_TFR
	VALUES ("e7682414-c9d4-490e-84ef-68b46fb9a8f1",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	'score',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	0,
	'select many cells from instances of CELL 
  where ( selected.answer_value != 0 );
score = cardinality cells;

/*#inline
  printf( "Score is:  %d\n", v64_score );
*/

return score;',
	1,
	'',
	"a3632caa-a4af-4c7b-8e5d-212826ddcf99");
INSERT INTO ACT_OPB
	VALUES ("1f629736-fcf3-487c-a0bb-00fdb05a128f",
	"e7682414-c9d4-490e-84ef-68b46fb9a8f1");
INSERT INTO ACT_ACT
	VALUES ("1f629736-fcf3-487c-a0bb-00fdb05a128f",
	'class operation',
	0,
	"3bdd2365-5707-4174-ac10-a5251cc8a728",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cell::score',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("3bdd2365-5707-4174-ac10-a5251cc8a728",
	1,
	0,
	1,
	'',
	'',
	'',
	9,
	1,
	1,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"1f629736-fcf3-487c-a0bb-00fdb05a128f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7b15b27a-7af0-4c00-8055-4b4cbc5651ca",
	"3bdd2365-5707-4174-ac10-a5251cc8a728",
	"f0476411-8c59-42c2-b1bd-58dd6b114729",
	1,
	1,
	'cell::score line: 1');
INSERT INTO ACT_FIW
	VALUES ("7b15b27a-7af0-4c00-8055-4b4cbc5651ca",
	"9e89eaf0-a365-43df-9d73-7bf9dd108d3b",
	1,
	'many',
	"049e3ded-0a1e-474d-bc4d-558517232118",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	1,
	37);
INSERT INTO ACT_SMT
	VALUES ("f0476411-8c59-42c2-b1bd-58dd6b114729",
	"3bdd2365-5707-4174-ac10-a5251cc8a728",
	"b87dd7d1-443d-4c38-b115-ae5d4a95ad40",
	3,
	1,
	'cell::score line: 3');
INSERT INTO ACT_AI
	VALUES ("f0476411-8c59-42c2-b1bd-58dd6b114729",
	"026e41f4-ddfa-43c9-a789-59dee6f2bea6",
	"d1e1c8f5-7237-4c7f-840e-2c3f5d685f9b",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b87dd7d1-443d-4c38-b115-ae5d4a95ad40",
	"3bdd2365-5707-4174-ac10-a5251cc8a728",
	"00000000-0000-0000-0000-000000000000",
	9,
	1,
	'cell::score line: 9');
INSERT INTO ACT_RET
	VALUES ("b87dd7d1-443d-4c38-b115-ae5d4a95ad40",
	"4151c5c3-bb64-43ed-a678-2d28b395cc36");
INSERT INTO V_VAL
	VALUES ("c5a3961f-a605-4eba-b624-caad2857162c",
	0,
	0,
	2,
	11,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"3bdd2365-5707-4174-ac10-a5251cc8a728");
INSERT INTO V_SLR
	VALUES ("c5a3961f-a605-4eba-b624-caad2857162c",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("8b557a20-ae74-46ed-8dea-5c0463802206",
	0,
	0,
	2,
	20,
	31,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3bdd2365-5707-4174-ac10-a5251cc8a728");
INSERT INTO V_AVL
	VALUES ("8b557a20-ae74-46ed-8dea-5c0463802206",
	"c5a3961f-a605-4eba-b624-caad2857162c",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"009f5557-7ee7-4e44-9444-4d92eb448359");
INSERT INTO V_VAL
	VALUES ("049e3ded-0a1e-474d-bc4d-558517232118",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"3bdd2365-5707-4174-ac10-a5251cc8a728");
INSERT INTO V_BIN
	VALUES ("049e3ded-0a1e-474d-bc4d-558517232118",
	"b036e232-cd7b-4e22-8d25-a9d562587b7e",
	"8b557a20-ae74-46ed-8dea-5c0463802206",
	'!=');
INSERT INTO V_VAL
	VALUES ("b036e232-cd7b-4e22-8d25-a9d562587b7e",
	0,
	0,
	2,
	36,
	36,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3bdd2365-5707-4174-ac10-a5251cc8a728");
INSERT INTO V_LIN
	VALUES ("b036e232-cd7b-4e22-8d25-a9d562587b7e",
	'0');
INSERT INTO V_VAL
	VALUES ("d1e1c8f5-7237-4c7f-840e-2c3f5d685f9b",
	1,
	1,
	3,
	1,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3bdd2365-5707-4174-ac10-a5251cc8a728");
INSERT INTO V_TVL
	VALUES ("d1e1c8f5-7237-4c7f-840e-2c3f5d685f9b",
	"5053e5d0-9042-4353-acd3-1bb2fafc2a77");
INSERT INTO V_VAL
	VALUES ("d6f048bc-fab8-4be7-a45d-4f27483016f4",
	0,
	0,
	3,
	21,
	25,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"3bdd2365-5707-4174-ac10-a5251cc8a728");
INSERT INTO V_ISR
	VALUES ("d6f048bc-fab8-4be7-a45d-4f27483016f4",
	"9e89eaf0-a365-43df-9d73-7bf9dd108d3b");
INSERT INTO V_VAL
	VALUES ("026e41f4-ddfa-43c9-a789-59dee6f2bea6",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3bdd2365-5707-4174-ac10-a5251cc8a728");
INSERT INTO V_UNY
	VALUES ("026e41f4-ddfa-43c9-a789-59dee6f2bea6",
	"d6f048bc-fab8-4be7-a45d-4f27483016f4",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("4151c5c3-bb64-43ed-a678-2d28b395cc36",
	0,
	0,
	9,
	8,
	12,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3bdd2365-5707-4174-ac10-a5251cc8a728");
INSERT INTO V_TVL
	VALUES ("4151c5c3-bb64-43ed-a678-2d28b395cc36",
	"5053e5d0-9042-4353-acd3-1bb2fafc2a77");
INSERT INTO V_VAR
	VALUES ("9e89eaf0-a365-43df-9d73-7bf9dd108d3b",
	"3bdd2365-5707-4174-ac10-a5251cc8a728",
	'cells',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("9e89eaf0-a365-43df-9d73-7bf9dd108d3b",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("46ce814a-7dbd-40b6-b900-c7ad130fc9ea",
	1,
	13,
	17,
	"9e89eaf0-a365-43df-9d73-7bf9dd108d3b");
INSERT INTO V_VAR
	VALUES ("5053e5d0-9042-4353-acd3-1bb2fafc2a77",
	"3bdd2365-5707-4174-ac10-a5251cc8a728",
	'score',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("5053e5d0-9042-4353-acd3-1bb2fafc2a77",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("956d1578-ce68-4207-b791-5a5c32baf3e7",
	3,
	1,
	5,
	"5053e5d0-9042-4353-acd3-1bb2fafc2a77");
INSERT INTO V_LOC
	VALUES ("44e75aa9-7ffb-41f7-8b7c-7be6400e4284",
	9,
	8,
	12,
	"5053e5d0-9042-4353-acd3-1bb2fafc2a77");
INSERT INTO O_REF
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	1,
	"b7c46385-7816-4616-9e73-922fad4f4af1",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"c71eb71a-1185-4f96-ad12-9ee546e214e8",
	"8f9517c4-2955-4897-834a-e924e660ce47",
	"53a62320-a206-4d56-a639-c4592f420548",
	"0d8566ad-b8db-4e46-aa41-07aa4e3fe946",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'row',
	'number',
	'R2');
INSERT INTO O_RATTR
	VALUES ("53a62320-a206-4d56-a639-c4592f420548",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"b7c46385-7816-4616-9e73-922fad4f4af1",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	1,
	'number');
INSERT INTO O_ATTR
	VALUES ("53a62320-a206-4d56-a639-c4592f420548",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"00000000-0000-0000-0000-000000000000",
	'row_number',
	'',
	'row_',
	'number',
	1,
	"1a418377-64f4-47d9-aa0e-0773ca94143a",
	'',
	'');
INSERT INTO O_REF
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	1,
	"90e0d09a-7fa5-45f0-ac4f-f519aa651f29",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"5b4c4100-b987-4466-935e-cf1c7446dc95",
	"97f23a8b-ed88-4a25-a47b-ad74722bf424",
	"d132eb18-d364-4962-a2a9-487279251e05",
	"9862fb85-afd9-4480-8a3c-22820f95c648",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'column',
	'number',
	'R3');
INSERT INTO O_RATTR
	VALUES ("d132eb18-d364-4962-a2a9-487279251e05",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"90e0d09a-7fa5-45f0-ac4f-f519aa651f29",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	1,
	'number');
INSERT INTO O_ATTR
	VALUES ("d132eb18-d364-4962-a2a9-487279251e05",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53a62320-a206-4d56-a639-c4592f420548",
	'column_number',
	'',
	'column_',
	'number',
	1,
	"1a418377-64f4-47d9-aa0e-0773ca94143a",
	'',
	'');
INSERT INTO O_REF
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	0,
	"53e80efe-cb6c-4332-b046-1ba6f6005b30",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"d6ffb906-5a1c-4b12-995d-d59a2b860b9b",
	"838d69c7-4354-4e52-ab82-1c85360eb9b8",
	"009f5557-7ee7-4e44-9444-4d92eb448359",
	"aabb1ec0-ef6b-4c55-bfdc-5b1e55cf1151",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'digit',
	'value',
	'R9');
INSERT INTO O_RATTR
	VALUES ("009f5557-7ee7-4e44-9444-4d92eb448359",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	1,
	'value');
INSERT INTO O_ATTR
	VALUES ("009f5557-7ee7-4e44-9444-4d92eb448359",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"d132eb18-d364-4962-a2a9-487279251e05",
	'answer_value',
	'',
	'answer_',
	'value',
	1,
	"1a418377-64f4-47d9-aa0e-0773ca94143a",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("f63c5665-7a1c-41d9-a56f-6588e6d961d6",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO O_BATTR
	VALUES ("f63c5665-7a1c-41d9-a56f-6588e6d961d6",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO O_ATTR
	VALUES ("f63c5665-7a1c-41d9-a56f-6588e6d961d6",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"009f5557-7ee7-4e44-9444-4d92eb448359",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"ea4f2014-da78-4798-8130-991e8750cff6",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO O_OIDA
	VALUES ("53a62320-a206-4d56-a639-c4592f420548",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	0);
INSERT INTO O_OIDA
	VALUES ("d132eb18-d364-4962-a2a9-487279251e05",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	0);
INSERT INTO O_ID
	VALUES (1,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO O_ID
	VALUES (2,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO SM_ISM
	VALUES ("38a56786-b1ce-4525-9ab4-c435268b709d",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO SM_SM
	VALUES ("38a56786-b1ce-4525-9ab4-c435268b709d",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("38a56786-b1ce-4525-9ab4-c435268b709d");
INSERT INTO SM_EVTDI
	VALUES ("f99fa5af-b480-4772-9cb8-0a2fdf9d66a8",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	'digit',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	"b880666e-bcda-4fba-8388-07f062174ca2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVTDI
	VALUES ("a61cf8a0-e77d-4112-be61-cd86d81d977f",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	'digit',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	"56858343-35b4-480e-be0f-3d01e945ea47",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_LEVT
	VALUES ("56858343-35b4-480e-be0f-3d01e945ea47",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("56858343-35b4-480e-be0f-3d01e945ea47",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("56858343-35b4-480e-be0f-3d01e945ea47",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000",
	1,
	'eliminate',
	0,
	'',
	'CELL1',
	'');
INSERT INTO SM_LEVT
	VALUES ("b880666e-bcda-4fba-8388-07f062174ca2",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("b880666e-bcda-4fba-8388-07f062174ca2",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("b880666e-bcda-4fba-8388-07f062174ca2",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000",
	2,
	'answer',
	0,
	'',
	'CELL2',
	'');
INSERT INTO SM_STATE
	VALUES ("1882dec4-d8a0-450d-8a4d-dc904d23c77d",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000",
	'unsolved',
	1,
	0);
INSERT INTO SM_SEME
	VALUES ("1882dec4-d8a0-450d-8a4d-dc904d23c77d",
	"56858343-35b4-480e-be0f-3d01e945ea47",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("1882dec4-d8a0-450d-8a4d-dc904d23c77d",
	"b880666e-bcda-4fba-8388-07f062174ca2",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("4b240b17-174c-4cb3-aeed-43ac0088f874",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"1882dec4-d8a0-450d-8a4d-dc904d23c77d");
INSERT INTO SM_AH
	VALUES ("4b240b17-174c-4cb3-aeed-43ac0088f874",
	"38a56786-b1ce-4525-9ab4-c435268b709d");
INSERT INTO SM_ACT
	VALUES ("4b240b17-174c-4cb3-aeed-43ac0088f874",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	1,
	'// It has been determined that the input digit cannot
// be used in this cell.

// Unlink the eliminated digit.
select any ineligible related by self->ELIGIBLE[R8]
  where ( selected.digit_value == rcvd_evt.digit );
if ( not_empty ineligible )
  select one digit related by ineligible->DIGIT[R8];
  unrelate self from digit across R8 using ineligible;
  // delete object instance ineligible;
  // Inform the row, col and box of the change. 
  // CDS:  Consider polymorphic event here.
  select one row related by self->ROW[R2];
  select one sequence related by row->SEQUENCE[R1];
  if ( not sequence.solved )
    sequence.requests = sequence.requests + 1;
    if ( sequence.requests < 2 )
      generate ROW1:update() to row;
    end if;
  end if;
  select one column related by self->COLUMN[R3];
  select one sequence related by column->SEQUENCE[R1];
  if ( not sequence.solved )
    sequence.requests = sequence.requests + 1;
    if ( sequence.requests < 2 )
      generate COLUMN1:update() to column;
    end if;
  end if;
  select one box related by self->BOX[R4];
  select one sequence related by box->SEQUENCE[R1];
  if ( not sequence.solved )
    sequence.requests = sequence.requests + 1;
    if ( sequence.requests < 2 )
      generate BOX1:update() to box;
    end if;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES ("371eab43-02f8-4274-a8a9-2cae31ad8d2f",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"4b240b17-174c-4cb3-aeed-43ac0088f874");
INSERT INTO ACT_ACT
	VALUES ("371eab43-02f8-4274-a8a9-2cae31ad8d2f",
	'state',
	0,
	"a377f091-201a-4813-a6fa-13c1353a420f",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cell::unsolved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a377f091-201a-4813-a6fa-13c1353a420f",
	1,
	0,
	1,
	'',
	'',
	'',
	7,
	1,
	5,
	40,
	0,
	0,
	5,
	49,
	0,
	0,
	0,
	0,
	0,
	"371eab43-02f8-4274-a8a9-2cae31ad8d2f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("2e03139d-3b88-407a-be8a-b9db52ae42e4",
	"a377f091-201a-4813-a6fa-13c1353a420f",
	"3e1a4737-1982-42ca-9bfa-76b7f8cc94d8",
	5,
	1,
	'cell::unsolved line: 5');
INSERT INTO ACT_SEL
	VALUES ("2e03139d-3b88-407a-be8a-b9db52ae42e4",
	"d1dcb85d-733f-41c2-9d3d-015b96a231eb",
	1,
	'any',
	"335705a0-f5fb-40a1-be7d-e039e7c54635");
INSERT INTO ACT_SRW
	VALUES ("2e03139d-3b88-407a-be8a-b9db52ae42e4",
	"a0a0eed3-bee8-41e9-93e5-7080f3090800");
INSERT INTO ACT_LNK
	VALUES ("46215a0c-f6b1-4e70-8e1d-3847e78abb03",
	'',
	"2e03139d-3b88-407a-be8a-b9db52ae42e4",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	5,
	40,
	5,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("3e1a4737-1982-42ca-9bfa-76b7f8cc94d8",
	"a377f091-201a-4813-a6fa-13c1353a420f",
	"00000000-0000-0000-0000-000000000000",
	7,
	1,
	'cell::unsolved line: 7');
INSERT INTO ACT_IF
	VALUES ("3e1a4737-1982-42ca-9bfa-76b7f8cc94d8",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"5eac3b88-49da-4ba1-925a-98d4bfa48c1e",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("335705a0-f5fb-40a1-be7d-e039e7c54635",
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"a377f091-201a-4813-a6fa-13c1353a420f");
INSERT INTO V_IRF
	VALUES ("335705a0-f5fb-40a1-be7d-e039e7c54635",
	"cb63b2c0-3639-40e1-b82d-00122045cd41");
INSERT INTO V_VAL
	VALUES ("cccfc512-6eee-49a0-9a3d-9d3787d61064",
	0,
	0,
	6,
	11,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"a377f091-201a-4813-a6fa-13c1353a420f");
INSERT INTO V_SLR
	VALUES ("cccfc512-6eee-49a0-9a3d-9d3787d61064",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("5233462f-2795-4661-9cfa-b0bf904fcc29",
	0,
	0,
	6,
	20,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a377f091-201a-4813-a6fa-13c1353a420f");
INSERT INTO V_AVL
	VALUES ("5233462f-2795-4661-9cfa-b0bf904fcc29",
	"cccfc512-6eee-49a0-9a3d-9d3787d61064",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("a0a0eed3-bee8-41e9-93e5-7080f3090800",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"a377f091-201a-4813-a6fa-13c1353a420f");
INSERT INTO V_BIN
	VALUES ("a0a0eed3-bee8-41e9-93e5-7080f3090800",
	"5d8bfa12-d2a6-4495-8a58-ceda90c1003c",
	"5233462f-2795-4661-9cfa-b0bf904fcc29",
	'==');
INSERT INTO V_VAL
	VALUES ("5d8bfa12-d2a6-4495-8a58-ceda90c1003c",
	0,
	0,
	6,
	44,
	48,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a377f091-201a-4813-a6fa-13c1353a420f");
INSERT INTO V_EDV
	VALUES ("5d8bfa12-d2a6-4495-8a58-ceda90c1003c");
INSERT INTO V_EPR
	VALUES ("5d8bfa12-d2a6-4495-8a58-ceda90c1003c",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"a61cf8a0-e77d-4112-be61-cd86d81d977f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("e5539a48-1bda-4579-9cb8-378519ae6d0b",
	0,
	0,
	7,
	16,
	25,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"a377f091-201a-4813-a6fa-13c1353a420f");
INSERT INTO V_IRF
	VALUES ("e5539a48-1bda-4579-9cb8-378519ae6d0b",
	"d1dcb85d-733f-41c2-9d3d-015b96a231eb");
INSERT INTO V_VAL
	VALUES ("5eac3b88-49da-4ba1-925a-98d4bfa48c1e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"a377f091-201a-4813-a6fa-13c1353a420f");
INSERT INTO V_UNY
	VALUES ("5eac3b88-49da-4ba1-925a-98d4bfa48c1e",
	"e5539a48-1bda-4579-9cb8-378519ae6d0b",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("d1dcb85d-733f-41c2-9d3d-015b96a231eb",
	"a377f091-201a-4813-a6fa-13c1353a420f",
	'ineligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("d1dcb85d-733f-41c2-9d3d-015b96a231eb",
	0,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("55a2b8a5-fa6c-42a9-b2c5-056da2ea83c7",
	5,
	12,
	21,
	"d1dcb85d-733f-41c2-9d3d-015b96a231eb");
INSERT INTO V_LOC
	VALUES ("c8858b64-ecdd-4e9d-a92c-985cad5c92cb",
	9,
	44,
	53,
	"d1dcb85d-733f-41c2-9d3d-015b96a231eb");
INSERT INTO V_VAR
	VALUES ("cb63b2c0-3639-40e1-b82d-00122045cd41",
	"a377f091-201a-4813-a6fa-13c1353a420f",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("cb63b2c0-3639-40e1-b82d-00122045cd41",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("2f989d37-4dc9-4da9-ab92-270f703b7a5e",
	9,
	12,
	15,
	"cb63b2c0-3639-40e1-b82d-00122045cd41");
INSERT INTO ACT_BLK
	VALUES ("15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	1,
	0,
	0,
	'',
	'',
	'',
	31,
	3,
	30,
	39,
	0,
	0,
	30,
	48,
	0,
	0,
	0,
	0,
	0,
	"371eab43-02f8-4274-a8a9-2cae31ad8d2f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e16341d3-2eb8-465b-98db-fde873ec2214",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"275dd588-f9e1-4339-93c6-1ada7b649487",
	8,
	3,
	'cell::unsolved line: 8');
INSERT INTO ACT_SEL
	VALUES ("e16341d3-2eb8-465b-98db-fde873ec2214",
	"1e7c1b38-6810-4caf-927d-54735f7210cd",
	1,
	'one',
	"44f402d6-83ee-4785-9178-a52f7d4403f6");
INSERT INTO ACT_SR
	VALUES ("e16341d3-2eb8-465b-98db-fde873ec2214");
INSERT INTO ACT_LNK
	VALUES ("ad4c4b03-842d-470b-87b1-0d7c4515a089",
	'',
	"e16341d3-2eb8-465b-98db-fde873ec2214",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	8,
	43,
	8,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("275dd588-f9e1-4339-93c6-1ada7b649487",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"96144e42-3023-4aae-b664-8b2ec9be713f",
	9,
	3,
	'cell::unsolved line: 9');
INSERT INTO ACT_URU
	VALUES ("275dd588-f9e1-4339-93c6-1ada7b649487",
	"cb63b2c0-3639-40e1-b82d-00122045cd41",
	"1e7c1b38-6810-4caf-927d-54735f7210cd",
	"d1dcb85d-733f-41c2-9d3d-015b96a231eb",
	'',
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	9,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("96144e42-3023-4aae-b664-8b2ec9be713f",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"8e4b58ac-b77b-4e8f-a4fd-6bfa5596d71b",
	13,
	3,
	'cell::unsolved line: 13');
INSERT INTO ACT_SEL
	VALUES ("96144e42-3023-4aae-b664-8b2ec9be713f",
	"498e5bfc-d04f-4c37-92f8-3e789fdf8af9",
	1,
	'one',
	"e92a888b-b458-46f3-9343-538398d589ed");
INSERT INTO ACT_SR
	VALUES ("96144e42-3023-4aae-b664-8b2ec9be713f");
INSERT INTO ACT_LNK
	VALUES ("23b814ad-dbeb-4d6b-b039-cd281925b90a",
	'',
	"96144e42-3023-4aae-b664-8b2ec9be713f",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"00000000-0000-0000-0000-000000000000",
	2,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	13,
	35,
	13,
	39,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8e4b58ac-b77b-4e8f-a4fd-6bfa5596d71b",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"d85826a1-fcea-4aa8-ada8-d06f5faf9441",
	14,
	3,
	'cell::unsolved line: 14');
INSERT INTO ACT_SEL
	VALUES ("8e4b58ac-b77b-4e8f-a4fd-6bfa5596d71b",
	"50f9db44-09c4-4640-82a8-0c4058af9f39",
	1,
	'one',
	"c4c431a6-16b2-41f1-90a1-d08348b76ae8");
INSERT INTO ACT_SR
	VALUES ("8e4b58ac-b77b-4e8f-a4fd-6bfa5596d71b");
INSERT INTO ACT_LNK
	VALUES ("d450691a-9c96-468d-8aa2-4fa74e78d91f",
	'',
	"8e4b58ac-b77b-4e8f-a4fd-6bfa5596d71b",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	14,
	39,
	14,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d85826a1-fcea-4aa8-ada8-d06f5faf9441",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"069eecf8-efa9-437f-92f8-749cc1553749",
	15,
	3,
	'cell::unsolved line: 15');
INSERT INTO ACT_IF
	VALUES ("d85826a1-fcea-4aa8-ada8-d06f5faf9441",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3",
	"1c804040-dede-47c7-ba6f-86a64bd8d2a3",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("069eecf8-efa9-437f-92f8-749cc1553749",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"51c67c71-b58c-4341-8fad-f8b522c17143",
	21,
	3,
	'cell::unsolved line: 21');
INSERT INTO ACT_SEL
	VALUES ("069eecf8-efa9-437f-92f8-749cc1553749",
	"aefba741-125b-45f0-9342-acaa06b76d5b",
	1,
	'one',
	"c37ad205-fa11-42da-bcfb-032472791ec6");
INSERT INTO ACT_SR
	VALUES ("069eecf8-efa9-437f-92f8-749cc1553749");
INSERT INTO ACT_LNK
	VALUES ("4667ae15-2dc1-493b-a97f-579bff104e00",
	'',
	"069eecf8-efa9-437f-92f8-749cc1553749",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"00000000-0000-0000-0000-000000000000",
	2,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	21,
	38,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("51c67c71-b58c-4341-8fad-f8b522c17143",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"ff590d55-3494-48ef-9d68-a93fec5cbb88",
	22,
	3,
	'cell::unsolved line: 22');
INSERT INTO ACT_SEL
	VALUES ("51c67c71-b58c-4341-8fad-f8b522c17143",
	"50f9db44-09c4-4640-82a8-0c4058af9f39",
	0,
	'one',
	"83cd9dca-d212-4fdc-a841-7af8099d25f8");
INSERT INTO ACT_SR
	VALUES ("51c67c71-b58c-4341-8fad-f8b522c17143");
INSERT INTO ACT_LNK
	VALUES ("b0607ad0-e083-4594-9f89-d4e07e82207b",
	'',
	"51c67c71-b58c-4341-8fad-f8b522c17143",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	22,
	42,
	22,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ff590d55-3494-48ef-9d68-a93fec5cbb88",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"486f1d05-7340-43a8-baad-9af350d9c5e3",
	23,
	3,
	'cell::unsolved line: 23');
INSERT INTO ACT_IF
	VALUES ("ff590d55-3494-48ef-9d68-a93fec5cbb88",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3",
	"c7cf59fa-1e9c-43e5-aff2-92941c2085f4",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("486f1d05-7340-43a8-baad-9af350d9c5e3",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"9c5d2a35-df3a-4020-8fe4-5707537b1fbe",
	29,
	3,
	'cell::unsolved line: 29');
INSERT INTO ACT_SEL
	VALUES ("486f1d05-7340-43a8-baad-9af350d9c5e3",
	"0a413279-c022-493b-b164-bc98b195d7a2",
	1,
	'one',
	"406c828b-d4bf-40d7-bf11-f486dc33bf16");
INSERT INTO ACT_SR
	VALUES ("486f1d05-7340-43a8-baad-9af350d9c5e3");
INSERT INTO ACT_LNK
	VALUES ("34b912ea-94d3-473a-b50a-00a8a5e5d54f",
	'',
	"486f1d05-7340-43a8-baad-9af350d9c5e3",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"00000000-0000-0000-0000-000000000000",
	2,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	29,
	35,
	29,
	39,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9c5d2a35-df3a-4020-8fe4-5707537b1fbe",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"3fd8d82f-68ec-488e-80e7-42fdf78075c9",
	30,
	3,
	'cell::unsolved line: 30');
INSERT INTO ACT_SEL
	VALUES ("9c5d2a35-df3a-4020-8fe4-5707537b1fbe",
	"50f9db44-09c4-4640-82a8-0c4058af9f39",
	0,
	'one',
	"c0d09e88-a49d-422f-9049-8c0a97f444a2");
INSERT INTO ACT_SR
	VALUES ("9c5d2a35-df3a-4020-8fe4-5707537b1fbe");
INSERT INTO ACT_LNK
	VALUES ("74a9f567-53e8-42bd-946d-a4c146862ab8",
	'',
	"9c5d2a35-df3a-4020-8fe4-5707537b1fbe",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	30,
	39,
	30,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("3fd8d82f-68ec-488e-80e7-42fdf78075c9",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	"00000000-0000-0000-0000-000000000000",
	31,
	3,
	'cell::unsolved line: 31');
INSERT INTO ACT_IF
	VALUES ("3fd8d82f-68ec-488e-80e7-42fdf78075c9",
	"837f048e-8ffe-47a5-b015-54d79e27bca3",
	"49b5944c-d910-4861-9303-abeb1d3c9b5d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("44f402d6-83ee-4785-9178-a52f7d4403f6",
	0,
	0,
	8,
	31,
	40,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_IRF
	VALUES ("44f402d6-83ee-4785-9178-a52f7d4403f6",
	"d1dcb85d-733f-41c2-9d3d-015b96a231eb");
INSERT INTO V_VAL
	VALUES ("e92a888b-b458-46f3-9343-538398d589ed",
	0,
	0,
	13,
	29,
	32,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_IRF
	VALUES ("e92a888b-b458-46f3-9343-538398d589ed",
	"cb63b2c0-3639-40e1-b82d-00122045cd41");
INSERT INTO V_VAL
	VALUES ("c4c431a6-16b2-41f1-90a1-d08348b76ae8",
	0,
	0,
	14,
	34,
	36,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_IRF
	VALUES ("c4c431a6-16b2-41f1-90a1-d08348b76ae8",
	"498e5bfc-d04f-4c37-92f8-3e789fdf8af9");
INSERT INTO V_VAL
	VALUES ("9fe5e131-93c0-4999-9a49-d58424565cb5",
	0,
	0,
	15,
	12,
	19,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_IRF
	VALUES ("9fe5e131-93c0-4999-9a49-d58424565cb5",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("78802798-a446-4f33-813c-e1530244691c",
	0,
	0,
	15,
	21,
	26,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_AVL
	VALUES ("78802798-a446-4f33-813c-e1530244691c",
	"9fe5e131-93c0-4999-9a49-d58424565cb5",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"48d19dd8-8465-49b9-b4d0-dd14aa6d653f");
INSERT INTO V_VAL
	VALUES ("1c804040-dede-47c7-ba6f-86a64bd8d2a3",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_UNY
	VALUES ("1c804040-dede-47c7-ba6f-86a64bd8d2a3",
	"78802798-a446-4f33-813c-e1530244691c",
	'not');
INSERT INTO V_VAL
	VALUES ("c37ad205-fa11-42da-bcfb-032472791ec6",
	0,
	0,
	21,
	32,
	35,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_IRF
	VALUES ("c37ad205-fa11-42da-bcfb-032472791ec6",
	"cb63b2c0-3639-40e1-b82d-00122045cd41");
INSERT INTO V_VAL
	VALUES ("83cd9dca-d212-4fdc-a841-7af8099d25f8",
	0,
	0,
	22,
	34,
	39,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_IRF
	VALUES ("83cd9dca-d212-4fdc-a841-7af8099d25f8",
	"aefba741-125b-45f0-9342-acaa06b76d5b");
INSERT INTO V_VAL
	VALUES ("51d9027c-e095-4bad-948c-ede0383a7a44",
	0,
	0,
	23,
	12,
	19,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_IRF
	VALUES ("51d9027c-e095-4bad-948c-ede0383a7a44",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("55ecdc37-6cc0-49df-b433-dd5595e6bc79",
	0,
	0,
	23,
	21,
	26,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_AVL
	VALUES ("55ecdc37-6cc0-49df-b433-dd5595e6bc79",
	"51d9027c-e095-4bad-948c-ede0383a7a44",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"48d19dd8-8465-49b9-b4d0-dd14aa6d653f");
INSERT INTO V_VAL
	VALUES ("c7cf59fa-1e9c-43e5-aff2-92941c2085f4",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_UNY
	VALUES ("c7cf59fa-1e9c-43e5-aff2-92941c2085f4",
	"55ecdc37-6cc0-49df-b433-dd5595e6bc79",
	'not');
INSERT INTO V_VAL
	VALUES ("406c828b-d4bf-40d7-bf11-f486dc33bf16",
	0,
	0,
	29,
	29,
	32,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_IRF
	VALUES ("406c828b-d4bf-40d7-bf11-f486dc33bf16",
	"cb63b2c0-3639-40e1-b82d-00122045cd41");
INSERT INTO V_VAL
	VALUES ("c0d09e88-a49d-422f-9049-8c0a97f444a2",
	0,
	0,
	30,
	34,
	36,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_IRF
	VALUES ("c0d09e88-a49d-422f-9049-8c0a97f444a2",
	"0a413279-c022-493b-b164-bc98b195d7a2");
INSERT INTO V_VAL
	VALUES ("155b2107-052a-46a7-954d-d7df34411982",
	0,
	0,
	31,
	12,
	19,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_IRF
	VALUES ("155b2107-052a-46a7-954d-d7df34411982",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("7f1a4828-a801-45ad-b864-1fa8e6463391",
	0,
	0,
	31,
	21,
	26,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_AVL
	VALUES ("7f1a4828-a801-45ad-b864-1fa8e6463391",
	"155b2107-052a-46a7-954d-d7df34411982",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"48d19dd8-8465-49b9-b4d0-dd14aa6d653f");
INSERT INTO V_VAL
	VALUES ("49b5944c-d910-4861-9303-abeb1d3c9b5d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6");
INSERT INTO V_UNY
	VALUES ("49b5944c-d910-4861-9303-abeb1d3c9b5d",
	"7f1a4828-a801-45ad-b864-1fa8e6463391",
	'not');
INSERT INTO V_VAR
	VALUES ("1e7c1b38-6810-4caf-927d-54735f7210cd",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	'digit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("1e7c1b38-6810-4caf-927d-54735f7210cd",
	0,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("39d198c7-25f7-46cc-9cca-517fc1420b08",
	8,
	14,
	18,
	"1e7c1b38-6810-4caf-927d-54735f7210cd");
INSERT INTO V_LOC
	VALUES ("c0175ed0-1d8c-43be-bb6e-3ca5b3cbadf8",
	9,
	22,
	26,
	"1e7c1b38-6810-4caf-927d-54735f7210cd");
INSERT INTO V_VAR
	VALUES ("498e5bfc-d04f-4c37-92f8-3e789fdf8af9",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	'row',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("498e5bfc-d04f-4c37-92f8-3e789fdf8af9",
	0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("8af27bff-c383-4459-aa9a-59a1e866eb5a",
	13,
	14,
	16,
	"498e5bfc-d04f-4c37-92f8-3e789fdf8af9");
INSERT INTO V_LOC
	VALUES ("d0163904-98a6-4418-91af-aa5677365fd1",
	18,
	33,
	35,
	"498e5bfc-d04f-4c37-92f8-3e789fdf8af9");
INSERT INTO V_VAR
	VALUES ("50f9db44-09c4-4640-82a8-0c4058af9f39",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("50f9db44-09c4-4640-82a8-0c4058af9f39",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("34422023-3430-459c-895a-5bf15c55d2ae",
	14,
	14,
	21,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("de5612a5-8353-4d25-8aaf-67b6a75117cb",
	15,
	12,
	19,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("8cbc4f0f-af3a-423b-9328-c4a3214569d1",
	16,
	5,
	12,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("1b5ed955-3db9-4e0e-842e-4533474e9b67",
	16,
	25,
	32,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("2d7d05b4-2181-4194-850e-492f900cccf7",
	17,
	10,
	17,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("961824e4-415a-46dc-858e-514ddac539b3",
	22,
	14,
	21,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("734478d1-9d92-4a91-9e78-3b3a19976e42",
	23,
	12,
	19,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("cc270a57-a0b4-43c0-a69f-2f5dd067f4a5",
	24,
	5,
	12,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("7f590ed2-6be3-462a-9a64-8d0af8f4c1fd",
	24,
	25,
	32,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("158b0464-9456-4709-a1ff-cd45c8c78e50",
	25,
	10,
	17,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("ea2f14ab-f79c-4b5d-a1fc-a32cf58d177f",
	30,
	14,
	21,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("8facf3e4-f039-4ac0-8127-ae8d8c8778df",
	31,
	12,
	19,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("3951ab33-8a2b-4ecb-8276-31835c5c0c89",
	32,
	5,
	12,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("49a8ce2f-43e7-4b54-86db-3f56e2121a36",
	32,
	25,
	32,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_LOC
	VALUES ("dc688122-1dc8-4b48-92fe-b6d22f142b88",
	33,
	10,
	17,
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAR
	VALUES ("aefba741-125b-45f0-9342-acaa06b76d5b",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	'column',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("aefba741-125b-45f0-9342-acaa06b76d5b",
	0,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_LOC
	VALUES ("d57aec99-2926-4b40-b398-87f925b77b7d",
	21,
	14,
	19,
	"aefba741-125b-45f0-9342-acaa06b76d5b");
INSERT INTO V_LOC
	VALUES ("33f90e90-85bd-4e99-a62f-c3d859c93118",
	26,
	36,
	41,
	"aefba741-125b-45f0-9342-acaa06b76d5b");
INSERT INTO V_VAR
	VALUES ("0a413279-c022-493b-b164-bc98b195d7a2",
	"15ea86a2-b3e4-4f77-bd67-c8d7ba8945a6",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("0a413279-c022-493b-b164-bc98b195d7a2",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("c1268260-8950-4dda-a714-8053cabd80bf",
	29,
	14,
	16,
	"0a413279-c022-493b-b164-bc98b195d7a2");
INSERT INTO V_LOC
	VALUES ("9064275f-bec7-49da-81ec-a302487b154c",
	34,
	33,
	35,
	"0a413279-c022-493b-b164-bc98b195d7a2");
INSERT INTO ACT_BLK
	VALUES ("1637f23d-01cf-4d12-88c5-6499a51c5eb3",
	0,
	0,
	0,
	'',
	'',
	'',
	17,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"371eab43-02f8-4274-a8a9-2cae31ad8d2f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("abfe466e-1e92-40fc-b117-3baf4e83aaf9",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3",
	"ecc5b87d-fff3-4a33-92d4-456a5e422799",
	16,
	5,
	'cell::unsolved line: 16');
INSERT INTO ACT_AI
	VALUES ("abfe466e-1e92-40fc-b117-3baf4e83aaf9",
	"24fb855e-bf9a-4152-aef6-44aa4a0f8f20",
	"57eb97ae-d436-4085-ab7f-adc25a377aa2",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ecc5b87d-fff3-4a33-92d4-456a5e422799",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3",
	"00000000-0000-0000-0000-000000000000",
	17,
	5,
	'cell::unsolved line: 17');
INSERT INTO ACT_IF
	VALUES ("ecc5b87d-fff3-4a33-92d4-456a5e422799",
	"5f0d0718-a964-4f44-9fa5-f836685af063",
	"97989744-142f-4cce-bc88-f3f5a58e44a2",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("b0e41a79-565e-40e7-a57e-55715b208930",
	1,
	0,
	16,
	5,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3");
INSERT INTO V_IRF
	VALUES ("b0e41a79-565e-40e7-a57e-55715b208930",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("57eb97ae-d436-4085-ab7f-adc25a377aa2",
	1,
	0,
	16,
	14,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3");
INSERT INTO V_AVL
	VALUES ("57eb97ae-d436-4085-ab7f-adc25a377aa2",
	"b0e41a79-565e-40e7-a57e-55715b208930",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("af168576-0bc1-40ad-8a35-fd8730982aa9",
	0,
	0,
	16,
	25,
	32,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3");
INSERT INTO V_IRF
	VALUES ("af168576-0bc1-40ad-8a35-fd8730982aa9",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("a770c910-f194-42a9-9e67-bbd2776762a0",
	0,
	0,
	16,
	34,
	41,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3");
INSERT INTO V_AVL
	VALUES ("a770c910-f194-42a9-9e67-bbd2776762a0",
	"af168576-0bc1-40ad-8a35-fd8730982aa9",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("24fb855e-bf9a-4152-aef6-44aa4a0f8f20",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3");
INSERT INTO V_BIN
	VALUES ("24fb855e-bf9a-4152-aef6-44aa4a0f8f20",
	"d00ffbf5-f55c-4e34-b78e-f03cdfeb5af2",
	"a770c910-f194-42a9-9e67-bbd2776762a0",
	'+');
INSERT INTO V_VAL
	VALUES ("d00ffbf5-f55c-4e34-b78e-f03cdfeb5af2",
	0,
	0,
	16,
	45,
	45,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3");
INSERT INTO V_LIN
	VALUES ("d00ffbf5-f55c-4e34-b78e-f03cdfeb5af2",
	'1');
INSERT INTO V_VAL
	VALUES ("aa308a92-ae29-4786-9a6f-44b50ab044a4",
	0,
	0,
	17,
	10,
	17,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3");
INSERT INTO V_IRF
	VALUES ("aa308a92-ae29-4786-9a6f-44b50ab044a4",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("fbf89b28-9c9b-4444-9b9d-3991beedaf89",
	0,
	0,
	17,
	19,
	26,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3");
INSERT INTO V_AVL
	VALUES ("fbf89b28-9c9b-4444-9b9d-3991beedaf89",
	"aa308a92-ae29-4786-9a6f-44b50ab044a4",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("97989744-142f-4cce-bc88-f3f5a58e44a2",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3");
INSERT INTO V_BIN
	VALUES ("97989744-142f-4cce-bc88-f3f5a58e44a2",
	"6acb1f5e-2b77-44c7-8d06-62e43472f2fc",
	"fbf89b28-9c9b-4444-9b9d-3991beedaf89",
	'<');
INSERT INTO V_VAL
	VALUES ("6acb1f5e-2b77-44c7-8d06-62e43472f2fc",
	0,
	0,
	17,
	30,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1637f23d-01cf-4d12-88c5-6499a51c5eb3");
INSERT INTO V_LIN
	VALUES ("6acb1f5e-2b77-44c7-8d06-62e43472f2fc",
	'2');
INSERT INTO ACT_BLK
	VALUES ("5f0d0718-a964-4f44-9fa5-f836685af063",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	18,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"371eab43-02f8-4274-a8a9-2cae31ad8d2f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7c502799-452a-4ead-8e45-62bce908fcd8",
	"5f0d0718-a964-4f44-9fa5-f836685af063",
	"00000000-0000-0000-0000-000000000000",
	18,
	7,
	'cell::unsolved line: 18');
INSERT INTO E_ESS
	VALUES ("7c502799-452a-4ead-8e45-62bce908fcd8",
	1,
	0,
	18,
	16,
	18,
	21,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("7c502799-452a-4ead-8e45-62bce908fcd8");
INSERT INTO E_GSME
	VALUES ("7c502799-452a-4ead-8e45-62bce908fcd8",
	"3c0abb69-5aa0-487e-996b-7909858726cf",
	"07fc627f-b641-41fe-a1af-748fb116451e");
INSERT INTO E_GEN
	VALUES ("7c502799-452a-4ead-8e45-62bce908fcd8",
	"498e5bfc-d04f-4c37-92f8-3e789fdf8af9");
INSERT INTO ACT_BLK
	VALUES ("b85a488f-6b2f-434c-a7c8-d4481b1687c3",
	0,
	0,
	0,
	'',
	'',
	'',
	25,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"371eab43-02f8-4274-a8a9-2cae31ad8d2f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c35af423-75f8-4905-8bed-ef3019e7eaae",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3",
	"f615440d-bb35-4d24-84dd-f1f0f4cac0d8",
	24,
	5,
	'cell::unsolved line: 24');
INSERT INTO ACT_AI
	VALUES ("c35af423-75f8-4905-8bed-ef3019e7eaae",
	"32d789c8-d2b7-44f8-8fd9-1365b6e33a64",
	"431181c5-f183-41b0-b8ae-aa8ee836d41e",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f615440d-bb35-4d24-84dd-f1f0f4cac0d8",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3",
	"00000000-0000-0000-0000-000000000000",
	25,
	5,
	'cell::unsolved line: 25');
INSERT INTO ACT_IF
	VALUES ("f615440d-bb35-4d24-84dd-f1f0f4cac0d8",
	"7e0e3063-7c52-4cf3-94e5-0cf8389dd7db",
	"373a3aef-96ee-49f2-ad68-e9fab05af277",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("55d9c6ef-a1a1-4664-a675-400536808ade",
	1,
	0,
	24,
	5,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3");
INSERT INTO V_IRF
	VALUES ("55d9c6ef-a1a1-4664-a675-400536808ade",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("431181c5-f183-41b0-b8ae-aa8ee836d41e",
	1,
	0,
	24,
	14,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3");
INSERT INTO V_AVL
	VALUES ("431181c5-f183-41b0-b8ae-aa8ee836d41e",
	"55d9c6ef-a1a1-4664-a675-400536808ade",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("cc687705-ee23-4289-862f-54318a6bf83a",
	0,
	0,
	24,
	25,
	32,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3");
INSERT INTO V_IRF
	VALUES ("cc687705-ee23-4289-862f-54318a6bf83a",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("356911e5-f0d0-44c1-8e42-6bb4946aa7bf",
	0,
	0,
	24,
	34,
	41,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3");
INSERT INTO V_AVL
	VALUES ("356911e5-f0d0-44c1-8e42-6bb4946aa7bf",
	"cc687705-ee23-4289-862f-54318a6bf83a",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("32d789c8-d2b7-44f8-8fd9-1365b6e33a64",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3");
INSERT INTO V_BIN
	VALUES ("32d789c8-d2b7-44f8-8fd9-1365b6e33a64",
	"3e6f8255-8ec1-4ae6-858d-fff3b1b4f01e",
	"356911e5-f0d0-44c1-8e42-6bb4946aa7bf",
	'+');
INSERT INTO V_VAL
	VALUES ("3e6f8255-8ec1-4ae6-858d-fff3b1b4f01e",
	0,
	0,
	24,
	45,
	45,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3");
INSERT INTO V_LIN
	VALUES ("3e6f8255-8ec1-4ae6-858d-fff3b1b4f01e",
	'1');
INSERT INTO V_VAL
	VALUES ("460dfa57-d0a9-4c43-8be1-2fe8515a98cf",
	0,
	0,
	25,
	10,
	17,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3");
INSERT INTO V_IRF
	VALUES ("460dfa57-d0a9-4c43-8be1-2fe8515a98cf",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("4dcfb7d7-f254-4bd6-8d6b-c2f25ab138f6",
	0,
	0,
	25,
	19,
	26,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3");
INSERT INTO V_AVL
	VALUES ("4dcfb7d7-f254-4bd6-8d6b-c2f25ab138f6",
	"460dfa57-d0a9-4c43-8be1-2fe8515a98cf",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("373a3aef-96ee-49f2-ad68-e9fab05af277",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3");
INSERT INTO V_BIN
	VALUES ("373a3aef-96ee-49f2-ad68-e9fab05af277",
	"9ba27002-7282-43d3-b70f-fe6571697f47",
	"4dcfb7d7-f254-4bd6-8d6b-c2f25ab138f6",
	'<');
INSERT INTO V_VAL
	VALUES ("9ba27002-7282-43d3-b70f-fe6571697f47",
	0,
	0,
	25,
	30,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b85a488f-6b2f-434c-a7c8-d4481b1687c3");
INSERT INTO V_LIN
	VALUES ("9ba27002-7282-43d3-b70f-fe6571697f47",
	'2');
INSERT INTO ACT_BLK
	VALUES ("7e0e3063-7c52-4cf3-94e5-0cf8389dd7db",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	26,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"371eab43-02f8-4274-a8a9-2cae31ad8d2f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("fc51a57f-6d77-4551-bb79-c01c6808f164",
	"7e0e3063-7c52-4cf3-94e5-0cf8389dd7db",
	"00000000-0000-0000-0000-000000000000",
	26,
	7,
	'cell::unsolved line: 26');
INSERT INTO E_ESS
	VALUES ("fc51a57f-6d77-4551-bb79-c01c6808f164",
	1,
	0,
	26,
	16,
	26,
	24,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("fc51a57f-6d77-4551-bb79-c01c6808f164");
INSERT INTO E_GSME
	VALUES ("fc51a57f-6d77-4551-bb79-c01c6808f164",
	"ee87929d-8d33-409c-be82-b312e01b87ec",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2");
INSERT INTO E_GEN
	VALUES ("fc51a57f-6d77-4551-bb79-c01c6808f164",
	"aefba741-125b-45f0-9342-acaa06b76d5b");
INSERT INTO ACT_BLK
	VALUES ("837f048e-8ffe-47a5-b015-54d79e27bca3",
	0,
	0,
	0,
	'',
	'',
	'',
	33,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"371eab43-02f8-4274-a8a9-2cae31ad8d2f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("6369a24c-f01c-4052-84f1-7016b999a795",
	"837f048e-8ffe-47a5-b015-54d79e27bca3",
	"a586d239-1b89-4124-be5b-f851aded1e19",
	32,
	5,
	'cell::unsolved line: 32');
INSERT INTO ACT_AI
	VALUES ("6369a24c-f01c-4052-84f1-7016b999a795",
	"1df68d4a-6638-494a-904f-ff9d05c751df",
	"13eeea72-ae7c-40ca-a561-61698956abc4",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a586d239-1b89-4124-be5b-f851aded1e19",
	"837f048e-8ffe-47a5-b015-54d79e27bca3",
	"00000000-0000-0000-0000-000000000000",
	33,
	5,
	'cell::unsolved line: 33');
INSERT INTO ACT_IF
	VALUES ("a586d239-1b89-4124-be5b-f851aded1e19",
	"92ebbb3e-19fa-425f-abd9-8b794973490d",
	"4b177706-0ec6-439b-9535-bcb1b8f365e4",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("39e37425-de5f-4caf-a83d-d0b47dde93ae",
	1,
	0,
	32,
	5,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"837f048e-8ffe-47a5-b015-54d79e27bca3");
INSERT INTO V_IRF
	VALUES ("39e37425-de5f-4caf-a83d-d0b47dde93ae",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("13eeea72-ae7c-40ca-a561-61698956abc4",
	1,
	0,
	32,
	14,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"837f048e-8ffe-47a5-b015-54d79e27bca3");
INSERT INTO V_AVL
	VALUES ("13eeea72-ae7c-40ca-a561-61698956abc4",
	"39e37425-de5f-4caf-a83d-d0b47dde93ae",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("612b063e-0166-4134-a74b-025ecf77f8ed",
	0,
	0,
	32,
	25,
	32,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"837f048e-8ffe-47a5-b015-54d79e27bca3");
INSERT INTO V_IRF
	VALUES ("612b063e-0166-4134-a74b-025ecf77f8ed",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("70eac950-c647-400c-a311-7cdc977069b6",
	0,
	0,
	32,
	34,
	41,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"837f048e-8ffe-47a5-b015-54d79e27bca3");
INSERT INTO V_AVL
	VALUES ("70eac950-c647-400c-a311-7cdc977069b6",
	"612b063e-0166-4134-a74b-025ecf77f8ed",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("1df68d4a-6638-494a-904f-ff9d05c751df",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"837f048e-8ffe-47a5-b015-54d79e27bca3");
INSERT INTO V_BIN
	VALUES ("1df68d4a-6638-494a-904f-ff9d05c751df",
	"b78d1385-b895-41b1-8e9e-d6837e57bfb4",
	"70eac950-c647-400c-a311-7cdc977069b6",
	'+');
INSERT INTO V_VAL
	VALUES ("b78d1385-b895-41b1-8e9e-d6837e57bfb4",
	0,
	0,
	32,
	45,
	45,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"837f048e-8ffe-47a5-b015-54d79e27bca3");
INSERT INTO V_LIN
	VALUES ("b78d1385-b895-41b1-8e9e-d6837e57bfb4",
	'1');
INSERT INTO V_VAL
	VALUES ("473c2006-3996-4e06-8d3c-a8236a01ee50",
	0,
	0,
	33,
	10,
	17,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"837f048e-8ffe-47a5-b015-54d79e27bca3");
INSERT INTO V_IRF
	VALUES ("473c2006-3996-4e06-8d3c-a8236a01ee50",
	"50f9db44-09c4-4640-82a8-0c4058af9f39");
INSERT INTO V_VAL
	VALUES ("d78071d3-16f3-4208-bfe9-29cac80bba40",
	0,
	0,
	33,
	19,
	26,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"837f048e-8ffe-47a5-b015-54d79e27bca3");
INSERT INTO V_AVL
	VALUES ("d78071d3-16f3-4208-bfe9-29cac80bba40",
	"473c2006-3996-4e06-8d3c-a8236a01ee50",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("4b177706-0ec6-439b-9535-bcb1b8f365e4",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"837f048e-8ffe-47a5-b015-54d79e27bca3");
INSERT INTO V_BIN
	VALUES ("4b177706-0ec6-439b-9535-bcb1b8f365e4",
	"4ebef085-bbc9-440f-b8ce-0d4a87dec860",
	"d78071d3-16f3-4208-bfe9-29cac80bba40",
	'<');
INSERT INTO V_VAL
	VALUES ("4ebef085-bbc9-440f-b8ce-0d4a87dec860",
	0,
	0,
	33,
	30,
	30,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"837f048e-8ffe-47a5-b015-54d79e27bca3");
INSERT INTO V_LIN
	VALUES ("4ebef085-bbc9-440f-b8ce-0d4a87dec860",
	'2');
INSERT INTO ACT_BLK
	VALUES ("92ebbb3e-19fa-425f-abd9-8b794973490d",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	34,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"371eab43-02f8-4274-a8a9-2cae31ad8d2f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("cbda8855-6720-4e1b-970f-35ffbaf3ba4b",
	"92ebbb3e-19fa-425f-abd9-8b794973490d",
	"00000000-0000-0000-0000-000000000000",
	34,
	7,
	'cell::unsolved line: 34');
INSERT INTO E_ESS
	VALUES ("cbda8855-6720-4e1b-970f-35ffbaf3ba4b",
	1,
	0,
	34,
	16,
	34,
	21,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("cbda8855-6720-4e1b-970f-35ffbaf3ba4b");
INSERT INTO E_GSME
	VALUES ("cbda8855-6720-4e1b-970f-35ffbaf3ba4b",
	"4a74f6cd-a33f-407c-abac-8419734741c7",
	"415f7ffb-d246-4025-9868-5f83c77ba291");
INSERT INTO E_GEN
	VALUES ("cbda8855-6720-4e1b-970f-35ffbaf3ba4b",
	"0a413279-c022-493b-b164-bc98b195d7a2");
INSERT INTO SM_STATE
	VALUES ("91c5e5c2-3ee2-4ffb-a6a6-4bb09a98d31d",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000",
	'solved',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES ("91c5e5c2-3ee2-4ffb-a6a6-4bb09a98d31d",
	"56858343-35b4-480e-be0f-3d01e945ea47",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("91c5e5c2-3ee2-4ffb-a6a6-4bb09a98d31d",
	"56858343-35b4-480e-be0f-3d01e945ea47",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EIGN
	VALUES ("91c5e5c2-3ee2-4ffb-a6a6-4bb09a98d31d",
	"b880666e-bcda-4fba-8388-07f062174ca2",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("91c5e5c2-3ee2-4ffb-a6a6-4bb09a98d31d",
	"b880666e-bcda-4fba-8388-07f062174ca2",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("13d75677-ff3a-4049-8dcd-3768ca13364b",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"91c5e5c2-3ee2-4ffb-a6a6-4bb09a98d31d");
INSERT INTO SM_AH
	VALUES ("13d75677-ff3a-4049-8dcd-3768ca13364b",
	"38a56786-b1ce-4525-9ab4-c435268b709d");
INSERT INTO SM_ACT
	VALUES ("13d75677-ff3a-4049-8dcd-3768ca13364b",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	1,
	'// An answer has been found, so remove the eligible
// digits which are now ineligible digits.

// Link in the answer.
// CDS:  Consider selecting across R8 here.
select any digit from instances of DIGIT 
  where ( selected.value == rcvd_evt.digit );
if ( not_empty digit )
  relate self to digit across R9;
end if;

// Unlink the other digits.  There can be only one answer.
select many ineligibles related by self->ELIGIBLE[R8];
for each ineligible in ineligibles
  select one digit related by ineligible->DIGIT[R8];
  unrelate self from digit across R8 using ineligible;
  // delete object instance ineligible;
end for;

// CDS:  Inform the row, col and box that there is a change.',
	'');
INSERT INTO ACT_SAB
	VALUES ("f74b0b9f-cf7d-450e-ab2b-774b3ff415ed",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"13d75677-ff3a-4049-8dcd-3768ca13364b");
INSERT INTO ACT_ACT
	VALUES ("f74b0b9f-cf7d-450e-ab2b-774b3ff415ed",
	'state',
	0,
	"12098d76-f717-4dd2-9f96-e6155fc46954",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cell::solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("12098d76-f717-4dd2-9f96-e6155fc46954",
	1,
	0,
	1,
	'',
	'',
	'',
	14,
	1,
	13,
	42,
	0,
	0,
	13,
	51,
	0,
	0,
	0,
	0,
	0,
	"f74b0b9f-cf7d-450e-ab2b-774b3ff415ed",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("201e9217-a5df-4842-90c6-e3bb7ec4c925",
	"12098d76-f717-4dd2-9f96-e6155fc46954",
	"ec56c8ab-0de4-4e88-9f56-551e401b5ea1",
	6,
	1,
	'cell::solved line: 6');
INSERT INTO ACT_FIW
	VALUES ("201e9217-a5df-4842-90c6-e3bb7ec4c925",
	"b9da6d5a-6daf-49b1-9852-d8c627513403",
	1,
	'any',
	"fe0bbda0-d53b-45a1-9167-6abc286daae2",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	6,
	36);
INSERT INTO ACT_SMT
	VALUES ("ec56c8ab-0de4-4e88-9f56-551e401b5ea1",
	"12098d76-f717-4dd2-9f96-e6155fc46954",
	"5c5d2eed-fce8-4e3f-8924-f99d04ad3cfd",
	8,
	1,
	'cell::solved line: 8');
INSERT INTO ACT_IF
	VALUES ("ec56c8ab-0de4-4e88-9f56-551e401b5ea1",
	"dec9ebd5-53d0-4351-8239-29a5a402c527",
	"85e8e9b6-e9d9-4601-8e52-1c7832dbfe2d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5c5d2eed-fce8-4e3f-8924-f99d04ad3cfd",
	"12098d76-f717-4dd2-9f96-e6155fc46954",
	"0584ea4b-f4be-4292-853e-2063648a064e",
	13,
	1,
	'cell::solved line: 13');
INSERT INTO ACT_SEL
	VALUES ("5c5d2eed-fce8-4e3f-8924-f99d04ad3cfd",
	"f0ed262c-7777-4681-875f-2c849053e5f7",
	1,
	'many',
	"51a6f99a-7f94-4d9d-a444-da017a8076a7");
INSERT INTO ACT_SR
	VALUES ("5c5d2eed-fce8-4e3f-8924-f99d04ad3cfd");
INSERT INTO ACT_LNK
	VALUES ("52a161b2-abaf-4210-995e-f25238ed6909",
	'',
	"5c5d2eed-fce8-4e3f-8924-f99d04ad3cfd",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	13,
	42,
	13,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0584ea4b-f4be-4292-853e-2063648a064e",
	"12098d76-f717-4dd2-9f96-e6155fc46954",
	"00000000-0000-0000-0000-000000000000",
	14,
	1,
	'cell::solved line: 14');
INSERT INTO ACT_FOR
	VALUES ("0584ea4b-f4be-4292-853e-2063648a064e",
	"13dbd403-f69e-4e5b-83d7-f9b5b368e0b5",
	1,
	"a1db0179-ac3b-4ef3-b23d-06828639b1fe",
	"f0ed262c-7777-4681-875f-2c849053e5f7",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_VAL
	VALUES ("513b4d25-42a0-4c12-ae74-804ab5ddb7cd",
	0,
	0,
	7,
	11,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"12098d76-f717-4dd2-9f96-e6155fc46954");
INSERT INTO V_SLR
	VALUES ("513b4d25-42a0-4c12-ae74-804ab5ddb7cd",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("89dd4e2c-2711-4196-9485-0d7d3b2b8c1f",
	0,
	0,
	7,
	20,
	24,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"12098d76-f717-4dd2-9f96-e6155fc46954");
INSERT INTO V_AVL
	VALUES ("89dd4e2c-2711-4196-9485-0d7d3b2b8c1f",
	"513b4d25-42a0-4c12-ae74-804ab5ddb7cd",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO V_VAL
	VALUES ("fe0bbda0-d53b-45a1-9167-6abc286daae2",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"12098d76-f717-4dd2-9f96-e6155fc46954");
INSERT INTO V_BIN
	VALUES ("fe0bbda0-d53b-45a1-9167-6abc286daae2",
	"38c311d0-b306-47fb-91ef-5895eca9e3e4",
	"89dd4e2c-2711-4196-9485-0d7d3b2b8c1f",
	'==');
INSERT INTO V_VAL
	VALUES ("38c311d0-b306-47fb-91ef-5895eca9e3e4",
	0,
	0,
	7,
	38,
	42,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"12098d76-f717-4dd2-9f96-e6155fc46954");
INSERT INTO V_EDV
	VALUES ("38c311d0-b306-47fb-91ef-5895eca9e3e4");
INSERT INTO V_EPR
	VALUES ("38c311d0-b306-47fb-91ef-5895eca9e3e4",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"f99fa5af-b480-4772-9cb8-0a2fdf9d66a8",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("7bcb5b90-92fb-435e-aaf8-d75a45f286f3",
	0,
	0,
	8,
	16,
	20,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"12098d76-f717-4dd2-9f96-e6155fc46954");
INSERT INTO V_IRF
	VALUES ("7bcb5b90-92fb-435e-aaf8-d75a45f286f3",
	"b9da6d5a-6daf-49b1-9852-d8c627513403");
INSERT INTO V_VAL
	VALUES ("85e8e9b6-e9d9-4601-8e52-1c7832dbfe2d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"12098d76-f717-4dd2-9f96-e6155fc46954");
INSERT INTO V_UNY
	VALUES ("85e8e9b6-e9d9-4601-8e52-1c7832dbfe2d",
	"7bcb5b90-92fb-435e-aaf8-d75a45f286f3",
	'not_empty');
INSERT INTO V_VAL
	VALUES ("51a6f99a-7f94-4d9d-a444-da017a8076a7",
	0,
	0,
	13,
	36,
	39,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"12098d76-f717-4dd2-9f96-e6155fc46954");
INSERT INTO V_IRF
	VALUES ("51a6f99a-7f94-4d9d-a444-da017a8076a7",
	"ae5c32ee-660f-4ec8-92a2-d637cf96fbd1");
INSERT INTO V_VAR
	VALUES ("b9da6d5a-6daf-49b1-9852-d8c627513403",
	"12098d76-f717-4dd2-9f96-e6155fc46954",
	'digit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("b9da6d5a-6daf-49b1-9852-d8c627513403",
	0,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("71f6b53e-dee1-4dca-b860-4a73f5c9f2bb",
	6,
	12,
	16,
	"b9da6d5a-6daf-49b1-9852-d8c627513403");
INSERT INTO V_LOC
	VALUES ("4d1b15e5-1286-413a-a60c-6a91ca972198",
	9,
	18,
	22,
	"b9da6d5a-6daf-49b1-9852-d8c627513403");
INSERT INTO V_LOC
	VALUES ("fc5d779e-c740-4f7c-81c5-0c4838cfbab9",
	15,
	14,
	18,
	"b9da6d5a-6daf-49b1-9852-d8c627513403");
INSERT INTO V_LOC
	VALUES ("0ea58021-cef2-443e-8ac1-9b7e338e785f",
	16,
	22,
	26,
	"b9da6d5a-6daf-49b1-9852-d8c627513403");
INSERT INTO V_VAR
	VALUES ("ae5c32ee-660f-4ec8-92a2-d637cf96fbd1",
	"12098d76-f717-4dd2-9f96-e6155fc46954",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("ae5c32ee-660f-4ec8-92a2-d637cf96fbd1",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("c5209188-c06e-457f-b56b-87f33c178954",
	9,
	10,
	13,
	"ae5c32ee-660f-4ec8-92a2-d637cf96fbd1");
INSERT INTO V_LOC
	VALUES ("cee67678-643c-4501-b70c-65579bdb7c24",
	16,
	12,
	15,
	"ae5c32ee-660f-4ec8-92a2-d637cf96fbd1");
INSERT INTO V_VAR
	VALUES ("f0ed262c-7777-4681-875f-2c849053e5f7",
	"12098d76-f717-4dd2-9f96-e6155fc46954",
	'ineligibles',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("f0ed262c-7777-4681-875f-2c849053e5f7",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("f2fca3b8-9853-4a9f-bce2-fd98807ab046",
	13,
	13,
	23,
	"f0ed262c-7777-4681-875f-2c849053e5f7");
INSERT INTO V_LOC
	VALUES ("0c54eb65-2847-448d-b3e5-ce976cf35a85",
	14,
	24,
	34,
	"f0ed262c-7777-4681-875f-2c849053e5f7");
INSERT INTO V_VAR
	VALUES ("a1db0179-ac3b-4ef3-b23d-06828639b1fe",
	"12098d76-f717-4dd2-9f96-e6155fc46954",
	'ineligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("a1db0179-ac3b-4ef3-b23d-06828639b1fe",
	1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("2b2eb38f-6c45-430e-9018-3e01e91cc4bf",
	14,
	10,
	19,
	"a1db0179-ac3b-4ef3-b23d-06828639b1fe");
INSERT INTO V_LOC
	VALUES ("b9c75a9a-5c22-47ba-8fef-60d141295c43",
	16,
	44,
	53,
	"a1db0179-ac3b-4ef3-b23d-06828639b1fe");
INSERT INTO ACT_BLK
	VALUES ("dec9ebd5-53d0-4351-8239-29a5a402c527",
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	0,
	0,
	0,
	0,
	9,
	31,
	0,
	0,
	0,
	0,
	0,
	"f74b0b9f-cf7d-450e-ab2b-774b3ff415ed",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4b611bc7-bedb-4aae-92f4-c02fe4afa78d",
	"dec9ebd5-53d0-4351-8239-29a5a402c527",
	"00000000-0000-0000-0000-000000000000",
	9,
	3,
	'cell::solved line: 9');
INSERT INTO ACT_REL
	VALUES ("4b611bc7-bedb-4aae-92f4-c02fe4afa78d",
	"ae5c32ee-660f-4ec8-92a2-d637cf96fbd1",
	"b9da6d5a-6daf-49b1-9852-d8c627513403",
	'',
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	9,
	31,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("13dbd403-f69e-4e5b-83d7-f9b5b368e0b5",
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	3,
	15,
	43,
	0,
	0,
	16,
	35,
	0,
	0,
	0,
	0,
	0,
	"f74b0b9f-cf7d-450e-ab2b-774b3ff415ed",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("80f5dc0b-b26d-401c-b92e-0a346e7c394a",
	"13dbd403-f69e-4e5b-83d7-f9b5b368e0b5",
	"fe1b06a9-5a3b-462e-9a47-e6d7b597f3f1",
	15,
	3,
	'cell::solved line: 15');
INSERT INTO ACT_SEL
	VALUES ("80f5dc0b-b26d-401c-b92e-0a346e7c394a",
	"b9da6d5a-6daf-49b1-9852-d8c627513403",
	0,
	'one',
	"2daf6d37-4cb2-431a-bd5a-61963b32bca6");
INSERT INTO ACT_SR
	VALUES ("80f5dc0b-b26d-401c-b92e-0a346e7c394a");
INSERT INTO ACT_LNK
	VALUES ("f502dd50-9a45-44c2-b806-4e1051217a53",
	'',
	"80f5dc0b-b26d-401c-b92e-0a346e7c394a",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	15,
	43,
	15,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("fe1b06a9-5a3b-462e-9a47-e6d7b597f3f1",
	"13dbd403-f69e-4e5b-83d7-f9b5b368e0b5",
	"00000000-0000-0000-0000-000000000000",
	16,
	3,
	'cell::solved line: 16');
INSERT INTO ACT_URU
	VALUES ("fe1b06a9-5a3b-462e-9a47-e6d7b597f3f1",
	"ae5c32ee-660f-4ec8-92a2-d637cf96fbd1",
	"b9da6d5a-6daf-49b1-9852-d8c627513403",
	"a1db0179-ac3b-4ef3-b23d-06828639b1fe",
	'',
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	16,
	35,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("2daf6d37-4cb2-431a-bd5a-61963b32bca6",
	0,
	0,
	15,
	31,
	40,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"13dbd403-f69e-4e5b-83d7-f9b5b368e0b5");
INSERT INTO V_IRF
	VALUES ("2daf6d37-4cb2-431a-bd5a-61963b32bca6",
	"a1db0179-ac3b-4ef3-b23d-06828639b1fe");
INSERT INTO SM_NSTXN
	VALUES ("e521c9ef-2856-4add-abd0-578de8f4a5a2",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"1882dec4-d8a0-450d-8a4d-dc904d23c77d",
	"b880666e-bcda-4fba-8388-07f062174ca2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("373a58e8-9dce-453e-b405-88c35d4976c6",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"e521c9ef-2856-4add-abd0-578de8f4a5a2");
INSERT INTO SM_AH
	VALUES ("373a58e8-9dce-453e-b405-88c35d4976c6",
	"38a56786-b1ce-4525-9ab4-c435268b709d");
INSERT INTO SM_ACT
	VALUES ("373a58e8-9dce-453e-b405-88c35d4976c6",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("272b9fb2-2fcd-41f1-b2f7-cd866113e8eb",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"373a58e8-9dce-453e-b405-88c35d4976c6");
INSERT INTO ACT_ACT
	VALUES ("272b9fb2-2fcd-41f1-b2f7-cd866113e8eb",
	'transition',
	0,
	"6573f82b-a159-4f83-b19d-19775349b0ba",
	"00000000-0000-0000-0000-000000000000",
	0,
	'CELL2: answer in unsolved to solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("6573f82b-a159-4f83-b19d-19775349b0ba",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"272b9fb2-2fcd-41f1-b2f7-cd866113e8eb",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("e521c9ef-2856-4add-abd0-578de8f4a5a2",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"91c5e5c2-3ee2-4ffb-a6a6-4bb09a98d31d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("fcbcef97-5c16-4abb-8e4a-0b141069f8e1",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"1882dec4-d8a0-450d-8a4d-dc904d23c77d",
	"56858343-35b4-480e-be0f-3d01e945ea47",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("e79409d3-8f48-4577-8be0-5b6664fdb5bf",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"fcbcef97-5c16-4abb-8e4a-0b141069f8e1");
INSERT INTO SM_AH
	VALUES ("e79409d3-8f48-4577-8be0-5b6664fdb5bf",
	"38a56786-b1ce-4525-9ab4-c435268b709d");
INSERT INTO SM_ACT
	VALUES ("e79409d3-8f48-4577-8be0-5b6664fdb5bf",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("b4a40e1c-6c6a-4abc-bd60-98a3d602f637",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"e79409d3-8f48-4577-8be0-5b6664fdb5bf");
INSERT INTO ACT_ACT
	VALUES ("b4a40e1c-6c6a-4abc-bd60-98a3d602f637",
	'transition',
	0,
	"003efb02-efd9-42b0-8abe-04c77383ac54",
	"00000000-0000-0000-0000-000000000000",
	0,
	'CELL1: eliminate in unsolved to unsolved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("003efb02-efd9-42b0-8abe-04c77383ac54",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"b4a40e1c-6c6a-4abc-bd60-98a3d602f637",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("fcbcef97-5c16-4abb-8e4a-0b141069f8e1",
	"38a56786-b1ce-4525-9ab4-c435268b709d",
	"1882dec4-d8a0-450d-8a4d-dc904d23c77d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_OBJ
	VALUES ("b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	'column',
	3,
	'COLUMN',
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO O_TFR
	VALUES ("477fe3eb-500d-4bd6-b226-d1d06d05d9ea",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	'prune',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	1,
	'// Eliminate eligible digits that match any answer digit for this sequence.

temperature = 0;
select many answerdigits related by self->CELL[R3]->DIGIT[R9] where ( selected.value != 0 );
select many eligibles related by self->CELL[R3]->ELIGIBLE[R8];
for each eligible in eligibles
  for each answerdigit in answerdigits
    if ( eligible.digit_value == answerdigit.value )
      select one opencell related by eligible->CELL[R8];
      if ( opencell.answer_value != eligible.digit_value )
        unrelate answerdigit from opencell across R8 using eligible;
        delete object instance eligible;
        //generate CELL1:eliminate( digit:answerdigit.value ) to opencell;
      end if;
      temperature = 1;
      break;
    end if;
  end for;
end for;
  
select many opencells related by self->CELL[R3]
  where ( selected.answer_value == 0 );
if ( empty opencells )
  temperature = 100;
end if;
for each opencell in opencells
  // Notice if we have the answer now.
  select many eligibles related by opencell->ELIGIBLE[R8];
  c = cardinality eligibles;
  if ( 1 == c )
    select any answer related by opencell->ELIGIBLE[R8];
    opencell.answer( answer_digit:answer.digit_value );
    //generate CELL2:answer( digit:answer.digit_value ) to opencell;
    temperature = 1;
  end if;
end for;

return temperature;
',
	1,
	'',
	"3bc8ba55-c728-4dd2-9472-84165cae4da9");
INSERT INTO ACT_OPB
	VALUES ("eb3cbe69-e45b-4700-82e0-48ec86bc5d5b",
	"477fe3eb-500d-4bd6-b226-d1d06d05d9ea");
INSERT INTO ACT_ACT
	VALUES ("eb3cbe69-e45b-4700-82e0-48ec86bc5d5b",
	'operation',
	0,
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	"00000000-0000-0000-0000-000000000000",
	0,
	'column::prune',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c0699b41-b48e-424f-a7ef-e1106c51a58c",
	1,
	0,
	1,
	'',
	'',
	'',
	38,
	1,
	21,
	40,
	0,
	0,
	21,
	45,
	0,
	0,
	0,
	0,
	0,
	"eb3cbe69-e45b-4700-82e0-48ec86bc5d5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("462e299a-3724-4ac9-83fc-ab957fc70e86",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	"6c874787-9755-42e4-b016-abc13c480396",
	3,
	1,
	'column::prune line: 3');
INSERT INTO ACT_AI
	VALUES ("462e299a-3724-4ac9-83fc-ab957fc70e86",
	"726c62d8-4c68-451f-b0c4-d56d5b23d6a6",
	"f101c0d1-7f37-447b-a6e7-7cd8940f9eb5",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("6c874787-9755-42e4-b016-abc13c480396",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	"a2051200-3a7f-4963-a8f1-63455d6b0d6b",
	4,
	1,
	'column::prune line: 4');
INSERT INTO ACT_SEL
	VALUES ("6c874787-9755-42e4-b016-abc13c480396",
	"03bee816-2173-459e-96cf-a675da7af25c",
	1,
	'many',
	"0c142df1-c140-4beb-9229-d3b4ab9294ed");
INSERT INTO ACT_SRW
	VALUES ("6c874787-9755-42e4-b016-abc13c480396",
	"fa2a28cf-9520-42fd-a0ac-4ac011c94732");
INSERT INTO ACT_LNK
	VALUES ("6d5ab98b-830d-40d9-92a0-8fd45e556d67",
	'',
	"6c874787-9755-42e4-b016-abc13c480396",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"a33982fd-ab08-47b8-b273-4200ccd6daf5",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	4,
	43,
	4,
	48,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("a33982fd-ab08-47b8-b273-4200ccd6daf5",
	'',
	"00000000-0000-0000-0000-000000000000",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"00000000-0000-0000-0000-000000000000",
	2,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	4,
	53,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a2051200-3a7f-4963-a8f1-63455d6b0d6b",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	"7f5ca772-7aff-4f64-bde0-3c35454305c1",
	5,
	1,
	'column::prune line: 5');
INSERT INTO ACT_SEL
	VALUES ("a2051200-3a7f-4963-a8f1-63455d6b0d6b",
	"1155721c-9ac7-48bf-bfc7-4fc188122221",
	1,
	'many',
	"7f50ddb8-99af-4d41-a009-e7ba9e59671e");
INSERT INTO ACT_SR
	VALUES ("a2051200-3a7f-4963-a8f1-63455d6b0d6b");
INSERT INTO ACT_LNK
	VALUES ("3f6a1ecd-fdfe-47c0-b29c-d91cbb4b0156",
	'',
	"a2051200-3a7f-4963-a8f1-63455d6b0d6b",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"7e980954-d8bf-4c74-a29c-ca3588ead55f",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("7e980954-d8bf-4c74-a29c-ca3588ead55f",
	'',
	"00000000-0000-0000-0000-000000000000",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7f5ca772-7aff-4f64-bde0-3c35454305c1",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	"c5ac0f54-bc19-4fd0-98c4-7e99899d577f",
	6,
	1,
	'column::prune line: 6');
INSERT INTO ACT_FOR
	VALUES ("7f5ca772-7aff-4f64-bde0-3c35454305c1",
	"35f579af-dcf5-416f-940e-414e46759bc2",
	1,
	"e94432a6-5272-43de-957d-0c248f0d0e0a",
	"1155721c-9ac7-48bf-bfc7-4fc188122221",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO ACT_SMT
	VALUES ("c5ac0f54-bc19-4fd0-98c4-7e99899d577f",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	"60d1ca0a-930f-416e-886e-1035b956da71",
	21,
	1,
	'column::prune line: 21');
INSERT INTO ACT_SEL
	VALUES ("c5ac0f54-bc19-4fd0-98c4-7e99899d577f",
	"8f00aea7-13ba-4e8f-a0dc-258f3ad56a2f",
	1,
	'many',
	"8bbc86dd-4957-4c25-ae76-d991af3b3e5f");
INSERT INTO ACT_SRW
	VALUES ("c5ac0f54-bc19-4fd0-98c4-7e99899d577f",
	"1a1b3d0e-2938-4de3-9e3c-4f0bec9853b0");
INSERT INTO ACT_LNK
	VALUES ("ef5198f7-3cf8-4a18-adb8-26c8dec6b36f",
	'',
	"c5ac0f54-bc19-4fd0-98c4-7e99899d577f",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"00000000-0000-0000-0000-000000000000",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	21,
	40,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("60d1ca0a-930f-416e-886e-1035b956da71",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	"77ea6c4b-4b05-49f6-9dd8-b4e78da4bf5f",
	23,
	1,
	'column::prune line: 23');
INSERT INTO ACT_IF
	VALUES ("60d1ca0a-930f-416e-886e-1035b956da71",
	"d0108e9c-700c-4850-a894-bbce3688d522",
	"a197d7b8-c6a9-48e6-b3eb-fdea55cd64c0",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("77ea6c4b-4b05-49f6-9dd8-b4e78da4bf5f",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	"6f4b9b68-998f-45a1-8afd-ef43cfb7df27",
	26,
	1,
	'column::prune line: 26');
INSERT INTO ACT_FOR
	VALUES ("77ea6c4b-4b05-49f6-9dd8-b4e78da4bf5f",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb",
	1,
	"4a539d71-2c9c-47c0-b6aa-0cecc343cf3d",
	"8f00aea7-13ba-4e8f-a0dc-258f3ad56a2f",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO ACT_SMT
	VALUES ("6f4b9b68-998f-45a1-8afd-ef43cfb7df27",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	"00000000-0000-0000-0000-000000000000",
	38,
	1,
	'column::prune line: 38');
INSERT INTO ACT_RET
	VALUES ("6f4b9b68-998f-45a1-8afd-ef43cfb7df27",
	"23d5f8b9-198a-47a3-8eac-c6eacf4f5bf9");
INSERT INTO V_VAL
	VALUES ("f101c0d1-7f37-447b-a6e7-7cd8940f9eb5",
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_TVL
	VALUES ("f101c0d1-7f37-447b-a6e7-7cd8940f9eb5",
	"7c05ffc7-7d02-4254-9148-d56878787c13");
INSERT INTO V_VAL
	VALUES ("726c62d8-4c68-451f-b0c4-d56d5b23d6a6",
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_LIN
	VALUES ("726c62d8-4c68-451f-b0c4-d56d5b23d6a6",
	'0');
INSERT INTO V_VAL
	VALUES ("0c142df1-c140-4beb-9229-d3b4ab9294ed",
	0,
	0,
	4,
	37,
	40,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_IRF
	VALUES ("0c142df1-c140-4beb-9229-d3b4ab9294ed",
	"39aec5f6-344e-44ad-8ff5-e0017cad6b0d");
INSERT INTO V_VAL
	VALUES ("68133b6d-bada-445d-a18f-9d692eddc1be",
	0,
	0,
	4,
	71,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_SLR
	VALUES ("68133b6d-bada-445d-a18f-9d692eddc1be",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("5f615501-f84f-4381-a1fa-e86585fd3251",
	0,
	0,
	4,
	80,
	84,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_AVL
	VALUES ("5f615501-f84f-4381-a1fa-e86585fd3251",
	"68133b6d-bada-445d-a18f-9d692eddc1be",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO V_VAL
	VALUES ("fa2a28cf-9520-42fd-a0ac-4ac011c94732",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_BIN
	VALUES ("fa2a28cf-9520-42fd-a0ac-4ac011c94732",
	"fbcb35f3-e0e9-4d13-829d-44563c325105",
	"5f615501-f84f-4381-a1fa-e86585fd3251",
	'!=');
INSERT INTO V_VAL
	VALUES ("fbcb35f3-e0e9-4d13-829d-44563c325105",
	0,
	0,
	4,
	89,
	89,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_LIN
	VALUES ("fbcb35f3-e0e9-4d13-829d-44563c325105",
	'0');
INSERT INTO V_VAL
	VALUES ("7f50ddb8-99af-4d41-a009-e7ba9e59671e",
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_IRF
	VALUES ("7f50ddb8-99af-4d41-a009-e7ba9e59671e",
	"39aec5f6-344e-44ad-8ff5-e0017cad6b0d");
INSERT INTO V_VAL
	VALUES ("8bbc86dd-4957-4c25-ae76-d991af3b3e5f",
	0,
	0,
	21,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_IRF
	VALUES ("8bbc86dd-4957-4c25-ae76-d991af3b3e5f",
	"39aec5f6-344e-44ad-8ff5-e0017cad6b0d");
INSERT INTO V_VAL
	VALUES ("6c1cc7e7-daed-4840-a7a7-5a07a742821f",
	0,
	0,
	22,
	11,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_SLR
	VALUES ("6c1cc7e7-daed-4840-a7a7-5a07a742821f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("59f56f6d-02d2-4c67-87b9-3a505179700f",
	0,
	0,
	22,
	20,
	31,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_AVL
	VALUES ("59f56f6d-02d2-4c67-87b9-3a505179700f",
	"6c1cc7e7-daed-4840-a7a7-5a07a742821f",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"009f5557-7ee7-4e44-9444-4d92eb448359");
INSERT INTO V_VAL
	VALUES ("1a1b3d0e-2938-4de3-9e3c-4f0bec9853b0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_BIN
	VALUES ("1a1b3d0e-2938-4de3-9e3c-4f0bec9853b0",
	"40b3861d-0da2-491a-80e2-d8f1abb3aa84",
	"59f56f6d-02d2-4c67-87b9-3a505179700f",
	'==');
INSERT INTO V_VAL
	VALUES ("40b3861d-0da2-491a-80e2-d8f1abb3aa84",
	0,
	0,
	22,
	36,
	36,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_LIN
	VALUES ("40b3861d-0da2-491a-80e2-d8f1abb3aa84",
	'0');
INSERT INTO V_VAL
	VALUES ("93e37e30-8f7c-418a-8824-950d4b33a1a3",
	0,
	0,
	23,
	12,
	20,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_ISR
	VALUES ("93e37e30-8f7c-418a-8824-950d4b33a1a3",
	"8f00aea7-13ba-4e8f-a0dc-258f3ad56a2f");
INSERT INTO V_VAL
	VALUES ("a197d7b8-c6a9-48e6-b3eb-fdea55cd64c0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_UNY
	VALUES ("a197d7b8-c6a9-48e6-b3eb-fdea55cd64c0",
	"93e37e30-8f7c-418a-8824-950d4b33a1a3",
	'empty');
INSERT INTO V_VAL
	VALUES ("23d5f8b9-198a-47a3-8eac-c6eacf4f5bf9",
	0,
	0,
	38,
	8,
	18,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c");
INSERT INTO V_TVL
	VALUES ("23d5f8b9-198a-47a3-8eac-c6eacf4f5bf9",
	"7c05ffc7-7d02-4254-9148-d56878787c13");
INSERT INTO V_VAR
	VALUES ("7c05ffc7-7d02-4254-9148-d56878787c13",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	'temperature',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("7c05ffc7-7d02-4254-9148-d56878787c13",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("c898a0c3-f1b6-4c19-8e61-2b2a8359504b",
	3,
	1,
	11,
	"7c05ffc7-7d02-4254-9148-d56878787c13");
INSERT INTO V_LOC
	VALUES ("2ae3c0f1-6b6c-4e1d-946a-0f92c2bf9b4c",
	15,
	7,
	17,
	"7c05ffc7-7d02-4254-9148-d56878787c13");
INSERT INTO V_LOC
	VALUES ("3514d132-40bf-4b5a-b514-4226488a489c",
	24,
	3,
	13,
	"7c05ffc7-7d02-4254-9148-d56878787c13");
INSERT INTO V_LOC
	VALUES ("e4d1b49f-0c75-45a1-bd33-c8605b9ddfb9",
	34,
	5,
	15,
	"7c05ffc7-7d02-4254-9148-d56878787c13");
INSERT INTO V_LOC
	VALUES ("9345cf3a-51a2-49ea-82b0-09842a9ec506",
	38,
	8,
	18,
	"7c05ffc7-7d02-4254-9148-d56878787c13");
INSERT INTO V_VAR
	VALUES ("03bee816-2173-459e-96cf-a675da7af25c",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	'answerdigits',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("03bee816-2173-459e-96cf-a675da7af25c",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("909f5828-a14c-48c7-9cfe-3416f8e41fa5",
	4,
	13,
	24,
	"03bee816-2173-459e-96cf-a675da7af25c");
INSERT INTO V_LOC
	VALUES ("a1691310-67ba-419e-bf46-51712c4709b7",
	7,
	27,
	38,
	"03bee816-2173-459e-96cf-a675da7af25c");
INSERT INTO V_VAR
	VALUES ("39aec5f6-344e-44ad-8ff5-e0017cad6b0d",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("39aec5f6-344e-44ad-8ff5-e0017cad6b0d",
	0,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_VAR
	VALUES ("1155721c-9ac7-48bf-bfc7-4fc188122221",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	'eligibles',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("1155721c-9ac7-48bf-bfc7-4fc188122221",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("f6c82715-a4af-4e4a-ac6c-ffbf62215a79",
	5,
	13,
	21,
	"1155721c-9ac7-48bf-bfc7-4fc188122221");
INSERT INTO V_LOC
	VALUES ("5edbbea3-7156-4c6c-bf82-21eae2d28a2f",
	6,
	22,
	30,
	"1155721c-9ac7-48bf-bfc7-4fc188122221");
INSERT INTO V_LOC
	VALUES ("6e91dfc1-2c76-41a4-bc90-d92aea206a54",
	28,
	15,
	23,
	"1155721c-9ac7-48bf-bfc7-4fc188122221");
INSERT INTO V_VAR
	VALUES ("e94432a6-5272-43de-957d-0c248f0d0e0a",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	'eligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("e94432a6-5272-43de-957d-0c248f0d0e0a",
	1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("120df9f6-69e0-4abb-985b-fd6a82e9108f",
	6,
	10,
	17,
	"e94432a6-5272-43de-957d-0c248f0d0e0a");
INSERT INTO V_LOC
	VALUES ("4d153762-2b0f-402a-a92e-ee21497323fa",
	8,
	10,
	17,
	"e94432a6-5272-43de-957d-0c248f0d0e0a");
INSERT INTO V_LOC
	VALUES ("81dc1f62-dd94-4bda-a5cd-c39bafe85bde",
	10,
	37,
	44,
	"e94432a6-5272-43de-957d-0c248f0d0e0a");
INSERT INTO V_LOC
	VALUES ("0cc61cd3-7949-43b6-820e-846ee710aa8f",
	11,
	60,
	67,
	"e94432a6-5272-43de-957d-0c248f0d0e0a");
INSERT INTO V_LOC
	VALUES ("813494a8-9b3f-4349-b1dd-8df84471555e",
	12,
	32,
	39,
	"e94432a6-5272-43de-957d-0c248f0d0e0a");
INSERT INTO V_VAR
	VALUES ("8f00aea7-13ba-4e8f-a0dc-258f3ad56a2f",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	'opencells',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("8f00aea7-13ba-4e8f-a0dc-258f3ad56a2f",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("17a25216-0865-4703-8eac-53209ea8cc8c",
	21,
	13,
	21,
	"8f00aea7-13ba-4e8f-a0dc-258f3ad56a2f");
INSERT INTO V_LOC
	VALUES ("f87bf70d-959b-4861-b592-54f5e216343e",
	26,
	22,
	30,
	"8f00aea7-13ba-4e8f-a0dc-258f3ad56a2f");
INSERT INTO V_VAR
	VALUES ("4a539d71-2c9c-47c0-b6aa-0cecc343cf3d",
	"c0699b41-b48e-424f-a7ef-e1106c51a58c",
	'opencell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("4a539d71-2c9c-47c0-b6aa-0cecc343cf3d",
	1,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("0062b97a-e541-43a4-b1a0-a119a9cd65c2",
	26,
	10,
	17,
	"4a539d71-2c9c-47c0-b6aa-0cecc343cf3d");
INSERT INTO V_LOC
	VALUES ("aa374acf-0090-48e8-b93b-bc1521a25fb9",
	32,
	5,
	12,
	"4a539d71-2c9c-47c0-b6aa-0cecc343cf3d");
INSERT INTO ACT_BLK
	VALUES ("35f579af-dcf5-416f-940e-414e46759bc2",
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"eb3cbe69-e45b-4700-82e0-48ec86bc5d5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("55ce2770-0d03-4666-bfe4-2a80d49cfd9b",
	"35f579af-dcf5-416f-940e-414e46759bc2",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'column::prune line: 7');
INSERT INTO ACT_FOR
	VALUES ("55ce2770-0d03-4666-bfe4-2a80d49cfd9b",
	"abf06a06-4959-4bda-882e-cd97f36a1ad5",
	1,
	"b4115b01-1dce-4745-a97d-8bf7060e76b9",
	"03bee816-2173-459e-96cf-a675da7af25c",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_VAR
	VALUES ("b4115b01-1dce-4745-a97d-8bf7060e76b9",
	"35f579af-dcf5-416f-940e-414e46759bc2",
	'answerdigit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("b4115b01-1dce-4745-a97d-8bf7060e76b9",
	1,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("e35e8511-596e-4904-bef0-48771d2e1e76",
	7,
	12,
	22,
	"b4115b01-1dce-4745-a97d-8bf7060e76b9");
INSERT INTO V_LOC
	VALUES ("26a46aff-bc5b-4b07-aa08-e8a32490f8f0",
	8,
	34,
	44,
	"b4115b01-1dce-4745-a97d-8bf7060e76b9");
INSERT INTO V_LOC
	VALUES ("a7724e69-eb21-41d6-9e31-f0aad15e767e",
	11,
	18,
	28,
	"b4115b01-1dce-4745-a97d-8bf7060e76b9");
INSERT INTO ACT_BLK
	VALUES ("abf06a06-4959-4bda-882e-cd97f36a1ad5",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"eb3cbe69-e45b-4700-82e0-48ec86bc5d5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d4fb6b0c-3454-432c-9e38-78917e41f2a8",
	"abf06a06-4959-4bda-882e-cd97f36a1ad5",
	"00000000-0000-0000-0000-000000000000",
	8,
	5,
	'column::prune line: 8');
INSERT INTO ACT_IF
	VALUES ("d4fb6b0c-3454-432c-9e38-78917e41f2a8",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79",
	"ea0d6420-65a9-4845-a78d-0d5ccc444918",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("bdc93929-32b4-4eed-9446-3774d198a81f",
	0,
	0,
	8,
	10,
	17,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"abf06a06-4959-4bda-882e-cd97f36a1ad5");
INSERT INTO V_IRF
	VALUES ("bdc93929-32b4-4eed-9446-3774d198a81f",
	"e94432a6-5272-43de-957d-0c248f0d0e0a");
INSERT INTO V_VAL
	VALUES ("206cbdab-cbf5-45af-8e3c-d1da6815e118",
	0,
	0,
	8,
	19,
	29,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"abf06a06-4959-4bda-882e-cd97f36a1ad5");
INSERT INTO V_AVL
	VALUES ("206cbdab-cbf5-45af-8e3c-d1da6815e118",
	"bdc93929-32b4-4eed-9446-3774d198a81f",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("ea0d6420-65a9-4845-a78d-0d5ccc444918",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"abf06a06-4959-4bda-882e-cd97f36a1ad5");
INSERT INTO V_BIN
	VALUES ("ea0d6420-65a9-4845-a78d-0d5ccc444918",
	"76490b2e-b828-4854-a2dc-b336745dc2b2",
	"206cbdab-cbf5-45af-8e3c-d1da6815e118",
	'==');
INSERT INTO V_VAL
	VALUES ("160298e4-93b2-4727-936a-bd261eadd8de",
	0,
	0,
	8,
	34,
	44,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"abf06a06-4959-4bda-882e-cd97f36a1ad5");
INSERT INTO V_IRF
	VALUES ("160298e4-93b2-4727-936a-bd261eadd8de",
	"b4115b01-1dce-4745-a97d-8bf7060e76b9");
INSERT INTO V_VAL
	VALUES ("76490b2e-b828-4854-a2dc-b336745dc2b2",
	0,
	0,
	8,
	46,
	50,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"abf06a06-4959-4bda-882e-cd97f36a1ad5");
INSERT INTO V_AVL
	VALUES ("76490b2e-b828-4854-a2dc-b336745dc2b2",
	"160298e4-93b2-4727-936a-bd261eadd8de",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO ACT_BLK
	VALUES ("18eae87f-6ef1-465e-b5aa-4bf1f9be3b79",
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	7,
	9,
	48,
	0,
	0,
	9,
	53,
	0,
	0,
	0,
	0,
	0,
	"eb3cbe69-e45b-4700-82e0-48ec86bc5d5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("922847e0-a723-4705-b087-ad737816c197",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79",
	"73541334-f982-4e98-875a-ac3b7a80a1e1",
	9,
	7,
	'column::prune line: 9');
INSERT INTO ACT_SEL
	VALUES ("922847e0-a723-4705-b087-ad737816c197",
	"68b610ec-85ea-428c-a687-85922811c764",
	1,
	'one',
	"6434a95f-af10-44d7-b402-d88551d86e88");
INSERT INTO ACT_SR
	VALUES ("922847e0-a723-4705-b087-ad737816c197");
INSERT INTO ACT_LNK
	VALUES ("42437659-a915-433e-81e9-ebf56a5b18a3",
	'',
	"922847e0-a723-4705-b087-ad737816c197",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	9,
	48,
	9,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("73541334-f982-4e98-875a-ac3b7a80a1e1",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79",
	"fa3b3793-a9a1-43fc-8742-1b45509b983a",
	10,
	7,
	'column::prune line: 10');
INSERT INTO ACT_IF
	VALUES ("73541334-f982-4e98-875a-ac3b7a80a1e1",
	"7462f8a2-b194-43bc-aac5-d35c6f8e8963",
	"09364984-44db-4608-bb4d-b249bda305ba",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("fa3b3793-a9a1-43fc-8742-1b45509b983a",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79",
	"55170f18-6108-41ce-9698-54925c1a2f01",
	15,
	7,
	'column::prune line: 15');
INSERT INTO ACT_AI
	VALUES ("fa3b3793-a9a1-43fc-8742-1b45509b983a",
	"0379796e-e12c-44e3-8a44-6dd9e276c508",
	"ad4d5a68-4724-47c8-948e-acaa7d741f93",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("55170f18-6108-41ce-9698-54925c1a2f01",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	'column::prune line: 16');
INSERT INTO ACT_BRK
	VALUES ("55170f18-6108-41ce-9698-54925c1a2f01");
INSERT INTO V_VAL
	VALUES ("6434a95f-af10-44d7-b402-d88551d86e88",
	0,
	0,
	9,
	38,
	45,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79");
INSERT INTO V_IRF
	VALUES ("6434a95f-af10-44d7-b402-d88551d86e88",
	"e94432a6-5272-43de-957d-0c248f0d0e0a");
INSERT INTO V_VAL
	VALUES ("30aa7258-7b0f-4760-852f-e46a1ddf9315",
	0,
	0,
	10,
	12,
	19,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79");
INSERT INTO V_IRF
	VALUES ("30aa7258-7b0f-4760-852f-e46a1ddf9315",
	"68b610ec-85ea-428c-a687-85922811c764");
INSERT INTO V_VAL
	VALUES ("cb72ae5d-c074-48ba-b4d2-0f59031524f4",
	0,
	0,
	10,
	21,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79");
INSERT INTO V_AVL
	VALUES ("cb72ae5d-c074-48ba-b4d2-0f59031524f4",
	"30aa7258-7b0f-4760-852f-e46a1ddf9315",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"009f5557-7ee7-4e44-9444-4d92eb448359");
INSERT INTO V_VAL
	VALUES ("09364984-44db-4608-bb4d-b249bda305ba",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79");
INSERT INTO V_BIN
	VALUES ("09364984-44db-4608-bb4d-b249bda305ba",
	"e19e0ff7-9e9d-453b-828f-5b64ca9f962d",
	"cb72ae5d-c074-48ba-b4d2-0f59031524f4",
	'!=');
INSERT INTO V_VAL
	VALUES ("dd4ccf11-848b-4771-b42a-28c549cb5d15",
	0,
	0,
	10,
	37,
	44,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79");
INSERT INTO V_IRF
	VALUES ("dd4ccf11-848b-4771-b42a-28c549cb5d15",
	"e94432a6-5272-43de-957d-0c248f0d0e0a");
INSERT INTO V_VAL
	VALUES ("e19e0ff7-9e9d-453b-828f-5b64ca9f962d",
	0,
	0,
	10,
	46,
	56,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79");
INSERT INTO V_AVL
	VALUES ("e19e0ff7-9e9d-453b-828f-5b64ca9f962d",
	"dd4ccf11-848b-4771-b42a-28c549cb5d15",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("ad4d5a68-4724-47c8-948e-acaa7d741f93",
	1,
	0,
	15,
	7,
	17,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79");
INSERT INTO V_TVL
	VALUES ("ad4d5a68-4724-47c8-948e-acaa7d741f93",
	"7c05ffc7-7d02-4254-9148-d56878787c13");
INSERT INTO V_VAL
	VALUES ("0379796e-e12c-44e3-8a44-6dd9e276c508",
	0,
	0,
	15,
	21,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79");
INSERT INTO V_LIN
	VALUES ("0379796e-e12c-44e3-8a44-6dd9e276c508",
	'1');
INSERT INTO V_VAR
	VALUES ("68b610ec-85ea-428c-a687-85922811c764",
	"18eae87f-6ef1-465e-b5aa-4bf1f9be3b79",
	'opencell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("68b610ec-85ea-428c-a687-85922811c764",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("44af0a10-9b72-474e-8505-44d73700ad3b",
	9,
	18,
	25,
	"68b610ec-85ea-428c-a687-85922811c764");
INSERT INTO V_LOC
	VALUES ("3b5ea3b0-1f43-4d4c-9955-349e9c682f77",
	10,
	12,
	19,
	"68b610ec-85ea-428c-a687-85922811c764");
INSERT INTO V_LOC
	VALUES ("a7e14e4b-6326-4b8e-9b35-5d736bf46680",
	11,
	35,
	42,
	"68b610ec-85ea-428c-a687-85922811c764");
INSERT INTO ACT_BLK
	VALUES ("7462f8a2-b194-43bc-aac5-d35c6f8e8963",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	9,
	0,
	0,
	0,
	0,
	11,
	51,
	0,
	0,
	0,
	0,
	0,
	"eb3cbe69-e45b-4700-82e0-48ec86bc5d5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7c1811b2-9d4e-4154-8ad6-fb3c23ca92e1",
	"7462f8a2-b194-43bc-aac5-d35c6f8e8963",
	"671a6701-3e89-4dc6-81e3-e06a681d51b5",
	11,
	9,
	'column::prune line: 11');
INSERT INTO ACT_URU
	VALUES ("7c1811b2-9d4e-4154-8ad6-fb3c23ca92e1",
	"b4115b01-1dce-4745-a97d-8bf7060e76b9",
	"68b610ec-85ea-428c-a687-85922811c764",
	"e94432a6-5272-43de-957d-0c248f0d0e0a",
	'',
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	11,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("671a6701-3e89-4dc6-81e3-e06a681d51b5",
	"7462f8a2-b194-43bc-aac5-d35c6f8e8963",
	"00000000-0000-0000-0000-000000000000",
	12,
	9,
	'column::prune line: 12');
INSERT INTO ACT_DEL
	VALUES ("671a6701-3e89-4dc6-81e3-e06a681d51b5",
	"e94432a6-5272-43de-957d-0c248f0d0e0a");
INSERT INTO ACT_BLK
	VALUES ("d0108e9c-700c-4850-a894-bbce3688d522",
	0,
	0,
	0,
	'',
	'',
	'',
	24,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"eb3cbe69-e45b-4700-82e0-48ec86bc5d5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5aee7304-4eca-4565-8f44-3946fadc07db",
	"d0108e9c-700c-4850-a894-bbce3688d522",
	"00000000-0000-0000-0000-000000000000",
	24,
	3,
	'column::prune line: 24');
INSERT INTO ACT_AI
	VALUES ("5aee7304-4eca-4565-8f44-3946fadc07db",
	"cc82d262-c50e-433c-a449-afcb8a276c11",
	"babc779a-6eba-4c68-b701-33a8699c840b",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("babc779a-6eba-4c68-b701-33a8699c840b",
	1,
	0,
	24,
	3,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d0108e9c-700c-4850-a894-bbce3688d522");
INSERT INTO V_TVL
	VALUES ("babc779a-6eba-4c68-b701-33a8699c840b",
	"7c05ffc7-7d02-4254-9148-d56878787c13");
INSERT INTO V_VAL
	VALUES ("cc82d262-c50e-433c-a449-afcb8a276c11",
	0,
	0,
	24,
	17,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d0108e9c-700c-4850-a894-bbce3688d522");
INSERT INTO V_LIN
	VALUES ("cc82d262-c50e-433c-a449-afcb8a276c11",
	'100');
INSERT INTO ACT_BLK
	VALUES ("edc72953-bfe6-44a6-a593-ce3f0fec8bdb",
	1,
	0,
	0,
	'',
	'',
	'',
	30,
	3,
	28,
	46,
	0,
	0,
	28,
	55,
	0,
	0,
	0,
	0,
	0,
	"eb3cbe69-e45b-4700-82e0-48ec86bc5d5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5f3c211b-66ff-4488-ba35-8ef974942941",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb",
	"a1376987-abfa-477c-babe-ceed658e6136",
	28,
	3,
	'column::prune line: 28');
INSERT INTO ACT_SEL
	VALUES ("5f3c211b-66ff-4488-ba35-8ef974942941",
	"1155721c-9ac7-48bf-bfc7-4fc188122221",
	0,
	'many',
	"9755a5e5-3d7e-4f31-8cf7-32d0dba84fab");
INSERT INTO ACT_SR
	VALUES ("5f3c211b-66ff-4488-ba35-8ef974942941");
INSERT INTO ACT_LNK
	VALUES ("9df2d5fe-f693-46de-ac18-3703ea9e8e95",
	'',
	"5f3c211b-66ff-4488-ba35-8ef974942941",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	28,
	46,
	28,
	55,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a1376987-abfa-477c-babe-ceed658e6136",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb",
	"2742a693-4728-4ce4-8e56-70df98843fbd",
	29,
	3,
	'column::prune line: 29');
INSERT INTO ACT_AI
	VALUES ("a1376987-abfa-477c-babe-ceed658e6136",
	"1bf46d7a-67f1-48ba-9d7b-1e2c41b9bb46",
	"53b44d0d-224b-4ecd-9f42-8fe9ae96ebe1",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("2742a693-4728-4ce4-8e56-70df98843fbd",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb",
	"00000000-0000-0000-0000-000000000000",
	30,
	3,
	'column::prune line: 30');
INSERT INTO ACT_IF
	VALUES ("2742a693-4728-4ce4-8e56-70df98843fbd",
	"d90c5e12-b500-4b20-b907-20fa0a340e55",
	"27d5809c-39b7-4f95-8da6-097c7f62899a",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("9755a5e5-3d7e-4f31-8cf7-32d0dba84fab",
	0,
	0,
	28,
	36,
	43,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb");
INSERT INTO V_IRF
	VALUES ("9755a5e5-3d7e-4f31-8cf7-32d0dba84fab",
	"4a539d71-2c9c-47c0-b6aa-0cecc343cf3d");
INSERT INTO V_VAL
	VALUES ("53b44d0d-224b-4ecd-9f42-8fe9ae96ebe1",
	1,
	1,
	29,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb");
INSERT INTO V_TVL
	VALUES ("53b44d0d-224b-4ecd-9f42-8fe9ae96ebe1",
	"e34db540-30a4-4c73-9b92-9d45d4ade35a");
INSERT INTO V_VAL
	VALUES ("b5415397-304b-42ff-9ccc-93d56d780278",
	0,
	0,
	29,
	19,
	27,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb");
INSERT INTO V_ISR
	VALUES ("b5415397-304b-42ff-9ccc-93d56d780278",
	"1155721c-9ac7-48bf-bfc7-4fc188122221");
INSERT INTO V_VAL
	VALUES ("1bf46d7a-67f1-48ba-9d7b-1e2c41b9bb46",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb");
INSERT INTO V_UNY
	VALUES ("1bf46d7a-67f1-48ba-9d7b-1e2c41b9bb46",
	"b5415397-304b-42ff-9ccc-93d56d780278",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("12c37ae6-d25d-48a3-8435-7ae2f1bf63b0",
	0,
	0,
	30,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb");
INSERT INTO V_LIN
	VALUES ("12c37ae6-d25d-48a3-8435-7ae2f1bf63b0",
	'1');
INSERT INTO V_VAL
	VALUES ("27d5809c-39b7-4f95-8da6-097c7f62899a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb");
INSERT INTO V_BIN
	VALUES ("27d5809c-39b7-4f95-8da6-097c7f62899a",
	"68a34b75-929e-4288-ac49-78ee032af13e",
	"12c37ae6-d25d-48a3-8435-7ae2f1bf63b0",
	'==');
INSERT INTO V_VAL
	VALUES ("68a34b75-929e-4288-ac49-78ee032af13e",
	0,
	0,
	30,
	13,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb");
INSERT INTO V_TVL
	VALUES ("68a34b75-929e-4288-ac49-78ee032af13e",
	"e34db540-30a4-4c73-9b92-9d45d4ade35a");
INSERT INTO V_VAR
	VALUES ("e34db540-30a4-4c73-9b92-9d45d4ade35a",
	"edc72953-bfe6-44a6-a593-ce3f0fec8bdb",
	'c',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("e34db540-30a4-4c73-9b92-9d45d4ade35a",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("19348a3d-8e93-4f25-9a56-1a225008b9cf",
	29,
	3,
	3,
	"e34db540-30a4-4c73-9b92-9d45d4ade35a");
INSERT INTO V_LOC
	VALUES ("dd32dcda-be9a-4831-9772-818ba5a577b7",
	30,
	13,
	13,
	"e34db540-30a4-4c73-9b92-9d45d4ade35a");
INSERT INTO ACT_BLK
	VALUES ("d90c5e12-b500-4b20-b907-20fa0a340e55",
	1,
	0,
	0,
	'',
	'',
	'',
	34,
	5,
	31,
	44,
	0,
	0,
	31,
	53,
	0,
	0,
	0,
	0,
	0,
	"eb3cbe69-e45b-4700-82e0-48ec86bc5d5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("358f07c3-dcf5-4d2a-9e63-d01f62a76da0",
	"d90c5e12-b500-4b20-b907-20fa0a340e55",
	"b1a09edc-92df-45eb-a049-d7cdcaaf35a0",
	31,
	5,
	'column::prune line: 31');
INSERT INTO ACT_SEL
	VALUES ("358f07c3-dcf5-4d2a-9e63-d01f62a76da0",
	"7812ad78-1d05-4806-a192-48e079bed36f",
	1,
	'any',
	"f34182d0-8449-4584-a38f-b8e1538d5b2f");
INSERT INTO ACT_SR
	VALUES ("358f07c3-dcf5-4d2a-9e63-d01f62a76da0");
INSERT INTO ACT_LNK
	VALUES ("ddd5f72e-47c0-46ea-8ae5-6f9665f0c6a0",
	'',
	"358f07c3-dcf5-4d2a-9e63-d01f62a76da0",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	31,
	44,
	31,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b1a09edc-92df-45eb-a049-d7cdcaaf35a0",
	"d90c5e12-b500-4b20-b907-20fa0a340e55",
	"2d55aa34-3205-4c00-82d7-76510ac5670a",
	32,
	5,
	'column::prune line: 32');
INSERT INTO ACT_TFM
	VALUES ("b1a09edc-92df-45eb-a049-d7cdcaaf35a0",
	"a3632caa-a4af-4c7b-8e5d-212826ddcf99",
	"4a539d71-2c9c-47c0-b6aa-0cecc343cf3d",
	32,
	14,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("2d55aa34-3205-4c00-82d7-76510ac5670a",
	"d90c5e12-b500-4b20-b907-20fa0a340e55",
	"00000000-0000-0000-0000-000000000000",
	34,
	5,
	'column::prune line: 34');
INSERT INTO ACT_AI
	VALUES ("2d55aa34-3205-4c00-82d7-76510ac5670a",
	"56fd4817-985d-40f4-a242-3ffb825c6527",
	"a9431056-baf0-4b32-9cd6-df06c74cfbec",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("f34182d0-8449-4584-a38f-b8e1538d5b2f",
	0,
	0,
	31,
	34,
	41,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"d90c5e12-b500-4b20-b907-20fa0a340e55");
INSERT INTO V_IRF
	VALUES ("f34182d0-8449-4584-a38f-b8e1538d5b2f",
	"4a539d71-2c9c-47c0-b6aa-0cecc343cf3d");
INSERT INTO V_VAL
	VALUES ("0115ab93-a224-4077-9038-42f78871c8cb",
	0,
	0,
	32,
	35,
	40,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"d90c5e12-b500-4b20-b907-20fa0a340e55");
INSERT INTO V_IRF
	VALUES ("0115ab93-a224-4077-9038-42f78871c8cb",
	"7812ad78-1d05-4806-a192-48e079bed36f");
INSERT INTO V_VAL
	VALUES ("c5212771-c0f9-40be-916b-5e9acdf7b67a",
	0,
	0,
	32,
	42,
	52,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d90c5e12-b500-4b20-b907-20fa0a340e55");
INSERT INTO V_AVL
	VALUES ("c5212771-c0f9-40be-916b-5e9acdf7b67a",
	"0115ab93-a224-4077-9038-42f78871c8cb",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_PAR
	VALUES ("c5212771-c0f9-40be-916b-5e9acdf7b67a",
	"b1a09edc-92df-45eb-a049-d7cdcaaf35a0",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	32,
	22);
INSERT INTO V_VAL
	VALUES ("a9431056-baf0-4b32-9cd6-df06c74cfbec",
	1,
	0,
	34,
	5,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d90c5e12-b500-4b20-b907-20fa0a340e55");
INSERT INTO V_TVL
	VALUES ("a9431056-baf0-4b32-9cd6-df06c74cfbec",
	"7c05ffc7-7d02-4254-9148-d56878787c13");
INSERT INTO V_VAL
	VALUES ("56fd4817-985d-40f4-a242-3ffb825c6527",
	0,
	0,
	34,
	19,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d90c5e12-b500-4b20-b907-20fa0a340e55");
INSERT INTO V_LIN
	VALUES ("56fd4817-985d-40f4-a242-3ffb825c6527",
	'1');
INSERT INTO V_VAR
	VALUES ("7812ad78-1d05-4806-a192-48e079bed36f",
	"d90c5e12-b500-4b20-b907-20fa0a340e55",
	'answer',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("7812ad78-1d05-4806-a192-48e079bed36f",
	0,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("58426033-ca97-49e2-881b-7fcdfb93f098",
	31,
	16,
	21,
	"7812ad78-1d05-4806-a192-48e079bed36f");
INSERT INTO V_LOC
	VALUES ("17655f15-a927-40b7-af32-e9af2120c9a4",
	32,
	35,
	40,
	"7812ad78-1d05-4806-a192-48e079bed36f");
INSERT INTO O_TFR
	VALUES ("3bc8ba55-c728-4dd2-9472-84165cae4da9",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	'eliminate',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	1,
	'// Solve by select all eligible digits.  Notice if any eligible digit appears only once.

temperature = 0;
select many eligibles related by self->CELL[R3]->ELIGIBLE[R8];
c = cardinality eligibles;
if ( 9 == c )
  temperature = 100;
else
for each eligible in eligibles
  select many loners related by self->CELL[R3]->ELIGIBLE[R8]
    where ( selected.digit_value == eligible.digit_value );
  c = cardinality loners;
  if ( 1 == c )
    // This is an answer!
    select one cell related by eligible->CELL[R8];
    cell.answer( answer_digit:eligible.digit_value );
    //generate CELL2:answer( digit:eligible.digit_value ) to cell;
    temperature = 1;
    break;
  end if;
end for;
end if;
return temperature;
',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_OPB
	VALUES ("74b6372e-b4cc-4e07-aaa5-af8c00cdd16c",
	"3bc8ba55-c728-4dd2-9472-84165cae4da9");
INSERT INTO ACT_ACT
	VALUES ("74b6372e-b4cc-4e07-aaa5-af8c00cdd16c",
	'operation',
	0,
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	"00000000-0000-0000-0000-000000000000",
	0,
	'column::eliminate',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("32d26a9e-7c68-4182-bec1-3612ed61ea22",
	1,
	0,
	0,
	'',
	'',
	'',
	23,
	1,
	4,
	50,
	0,
	0,
	4,
	59,
	0,
	0,
	0,
	0,
	0,
	"74b6372e-b4cc-4e07-aaa5-af8c00cdd16c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b22b0304-b490-44b7-b9a6-a2043b24bc3f",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	"b3945957-26d5-4979-9309-79a42ad2e3b4",
	3,
	1,
	'column::eliminate line: 3');
INSERT INTO ACT_AI
	VALUES ("b22b0304-b490-44b7-b9a6-a2043b24bc3f",
	"b7ef3f23-66cc-4054-bd19-3eb41e6b6da4",
	"fab7ebcd-7ef4-4b27-b845-59ba5baa5709",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b3945957-26d5-4979-9309-79a42ad2e3b4",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	"61ecc599-7deb-4a26-9eee-771d1c4672fc",
	4,
	1,
	'column::eliminate line: 4');
INSERT INTO ACT_SEL
	VALUES ("b3945957-26d5-4979-9309-79a42ad2e3b4",
	"c86042d6-e3cc-4df6-975a-541ed61508c0",
	1,
	'many',
	"f28d7c5e-c106-4c7a-b15a-f36ff85f05d5");
INSERT INTO ACT_SR
	VALUES ("b3945957-26d5-4979-9309-79a42ad2e3b4");
INSERT INTO ACT_LNK
	VALUES ("ef1b44f6-5988-4295-90e9-7dea757b0e40",
	'',
	"b3945957-26d5-4979-9309-79a42ad2e3b4",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"0c8a3d40-a8ba-4089-bcd8-d9a819f6bf1d",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	4,
	40,
	4,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("0c8a3d40-a8ba-4089-bcd8-d9a819f6bf1d",
	'',
	"00000000-0000-0000-0000-000000000000",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	4,
	50,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("61ecc599-7deb-4a26-9eee-771d1c4672fc",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	"25988e41-4aed-42de-9495-51dd739a3406",
	5,
	1,
	'column::eliminate line: 5');
INSERT INTO ACT_AI
	VALUES ("61ecc599-7deb-4a26-9eee-771d1c4672fc",
	"53ced6d3-8b11-4653-8b0a-5e241c0e8e3c",
	"0d8b6f73-2d72-439f-ac61-d32b20e8689f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("25988e41-4aed-42de-9495-51dd739a3406",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	"2c39464f-2ba3-4b1f-a7f6-2857a034a052",
	6,
	1,
	'column::eliminate line: 6');
INSERT INTO ACT_IF
	VALUES ("25988e41-4aed-42de-9495-51dd739a3406",
	"94bec166-6297-465a-9453-47a1ff6829d1",
	"66f74ba6-d8e5-46d7-8e07-03823714e9a0",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5418eb05-d406-4370-8522-de1c534b30ab",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	"00000000-0000-0000-0000-000000000000",
	8,
	1,
	'column::eliminate line: 8');
INSERT INTO ACT_E
	VALUES ("5418eb05-d406-4370-8522-de1c534b30ab",
	"4eb0f9ea-c909-4816-a6f3-15de9ba55fe8",
	"25988e41-4aed-42de-9495-51dd739a3406");
INSERT INTO ACT_SMT
	VALUES ("2c39464f-2ba3-4b1f-a7f6-2857a034a052",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	"00000000-0000-0000-0000-000000000000",
	23,
	1,
	'column::eliminate line: 23');
INSERT INTO ACT_RET
	VALUES ("2c39464f-2ba3-4b1f-a7f6-2857a034a052",
	"0d972062-e772-49db-8028-59af041965f7");
INSERT INTO V_VAL
	VALUES ("fab7ebcd-7ef4-4b27-b845-59ba5baa5709",
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22");
INSERT INTO V_TVL
	VALUES ("fab7ebcd-7ef4-4b27-b845-59ba5baa5709",
	"ad163ac6-fea3-44e7-988e-ae7d249d52bd");
INSERT INTO V_VAL
	VALUES ("b7ef3f23-66cc-4054-bd19-3eb41e6b6da4",
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22");
INSERT INTO V_LIN
	VALUES ("b7ef3f23-66cc-4054-bd19-3eb41e6b6da4",
	'0');
INSERT INTO V_VAL
	VALUES ("f28d7c5e-c106-4c7a-b15a-f36ff85f05d5",
	0,
	0,
	4,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22");
INSERT INTO V_IRF
	VALUES ("f28d7c5e-c106-4c7a-b15a-f36ff85f05d5",
	"74f9ee15-7b3e-4472-9fab-1a93b22123c1");
INSERT INTO V_VAL
	VALUES ("0d8b6f73-2d72-439f-ac61-d32b20e8689f",
	1,
	1,
	5,
	1,
	1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22");
INSERT INTO V_TVL
	VALUES ("0d8b6f73-2d72-439f-ac61-d32b20e8689f",
	"d7106a16-b3ed-4ff2-beea-442300ed9853");
INSERT INTO V_VAL
	VALUES ("638dddf2-e0c5-47e2-87da-68a801067dcc",
	0,
	0,
	5,
	17,
	25,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22");
INSERT INTO V_ISR
	VALUES ("638dddf2-e0c5-47e2-87da-68a801067dcc",
	"c86042d6-e3cc-4df6-975a-541ed61508c0");
INSERT INTO V_VAL
	VALUES ("53ced6d3-8b11-4653-8b0a-5e241c0e8e3c",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22");
INSERT INTO V_UNY
	VALUES ("53ced6d3-8b11-4653-8b0a-5e241c0e8e3c",
	"638dddf2-e0c5-47e2-87da-68a801067dcc",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("542b79dc-0a0b-4724-bb2c-5a1e3dbd6057",
	0,
	0,
	6,
	6,
	6,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22");
INSERT INTO V_LIN
	VALUES ("542b79dc-0a0b-4724-bb2c-5a1e3dbd6057",
	'9');
INSERT INTO V_VAL
	VALUES ("66f74ba6-d8e5-46d7-8e07-03823714e9a0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22");
INSERT INTO V_BIN
	VALUES ("66f74ba6-d8e5-46d7-8e07-03823714e9a0",
	"6dccc541-f213-4071-b960-f96318f56b2c",
	"542b79dc-0a0b-4724-bb2c-5a1e3dbd6057",
	'==');
INSERT INTO V_VAL
	VALUES ("6dccc541-f213-4071-b960-f96318f56b2c",
	0,
	0,
	6,
	11,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22");
INSERT INTO V_TVL
	VALUES ("6dccc541-f213-4071-b960-f96318f56b2c",
	"d7106a16-b3ed-4ff2-beea-442300ed9853");
INSERT INTO V_VAL
	VALUES ("0d972062-e772-49db-8028-59af041965f7",
	0,
	0,
	23,
	8,
	18,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22");
INSERT INTO V_TVL
	VALUES ("0d972062-e772-49db-8028-59af041965f7",
	"ad163ac6-fea3-44e7-988e-ae7d249d52bd");
INSERT INTO V_VAR
	VALUES ("ad163ac6-fea3-44e7-988e-ae7d249d52bd",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	'temperature',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("ad163ac6-fea3-44e7-988e-ae7d249d52bd",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("021879ff-53bf-48bd-8548-3ba9594d9234",
	3,
	1,
	11,
	"ad163ac6-fea3-44e7-988e-ae7d249d52bd");
INSERT INTO V_LOC
	VALUES ("0dab564e-2f2d-4f68-8650-a5a4c5e40ddc",
	7,
	3,
	13,
	"ad163ac6-fea3-44e7-988e-ae7d249d52bd");
INSERT INTO V_LOC
	VALUES ("6c4437cf-1f49-47ef-9f98-fc7b2a504e70",
	18,
	5,
	15,
	"ad163ac6-fea3-44e7-988e-ae7d249d52bd");
INSERT INTO V_LOC
	VALUES ("6e0c0c39-6d17-4d77-83fc-ada90b5baea3",
	23,
	8,
	18,
	"ad163ac6-fea3-44e7-988e-ae7d249d52bd");
INSERT INTO V_VAR
	VALUES ("c86042d6-e3cc-4df6-975a-541ed61508c0",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	'eligibles',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("c86042d6-e3cc-4df6-975a-541ed61508c0",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("bfed00cd-e365-4186-b8fb-8eff2e76217d",
	4,
	13,
	21,
	"c86042d6-e3cc-4df6-975a-541ed61508c0");
INSERT INTO V_LOC
	VALUES ("54bd3e2a-2460-4a9c-916b-9d149da333bd",
	9,
	22,
	30,
	"c86042d6-e3cc-4df6-975a-541ed61508c0");
INSERT INTO V_VAR
	VALUES ("74f9ee15-7b3e-4472-9fab-1a93b22123c1",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("74f9ee15-7b3e-4472-9fab-1a93b22123c1",
	0,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_VAR
	VALUES ("d7106a16-b3ed-4ff2-beea-442300ed9853",
	"32d26a9e-7c68-4182-bec1-3612ed61ea22",
	'c',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("d7106a16-b3ed-4ff2-beea-442300ed9853",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("1f294888-b6ef-4ebb-ac9a-78908e8c5088",
	5,
	1,
	1,
	"d7106a16-b3ed-4ff2-beea-442300ed9853");
INSERT INTO V_LOC
	VALUES ("dcb556cd-6dac-4540-bd87-ea8706407ce5",
	6,
	11,
	11,
	"d7106a16-b3ed-4ff2-beea-442300ed9853");
INSERT INTO V_LOC
	VALUES ("6469f4f7-3292-4296-83ff-9c3d166fe810",
	12,
	3,
	3,
	"d7106a16-b3ed-4ff2-beea-442300ed9853");
INSERT INTO V_LOC
	VALUES ("bdfb3664-be23-4064-8b60-cfa34abc67f0",
	13,
	13,
	13,
	"d7106a16-b3ed-4ff2-beea-442300ed9853");
INSERT INTO ACT_BLK
	VALUES ("94bec166-6297-465a-9453-47a1ff6829d1",
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"74b6372e-b4cc-4e07-aaa5-af8c00cdd16c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("282ad566-9be5-4506-8252-75fe127f89a7",
	"94bec166-6297-465a-9453-47a1ff6829d1",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'column::eliminate line: 7');
INSERT INTO ACT_AI
	VALUES ("282ad566-9be5-4506-8252-75fe127f89a7",
	"a4078717-9809-4451-8da7-44b991917b2f",
	"d207e15a-9562-4930-81f3-2ff2a992b5dd",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("d207e15a-9562-4930-81f3-2ff2a992b5dd",
	1,
	0,
	7,
	3,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"94bec166-6297-465a-9453-47a1ff6829d1");
INSERT INTO V_TVL
	VALUES ("d207e15a-9562-4930-81f3-2ff2a992b5dd",
	"ad163ac6-fea3-44e7-988e-ae7d249d52bd");
INSERT INTO V_VAL
	VALUES ("a4078717-9809-4451-8da7-44b991917b2f",
	0,
	0,
	7,
	17,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"94bec166-6297-465a-9453-47a1ff6829d1");
INSERT INTO V_LIN
	VALUES ("a4078717-9809-4451-8da7-44b991917b2f",
	'100');
INSERT INTO ACT_BLK
	VALUES ("4eb0f9ea-c909-4816-a6f3-15de9ba55fe8",
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"74b6372e-b4cc-4e07-aaa5-af8c00cdd16c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("11f3d9e8-2ddd-43ed-b30b-632254e4e466",
	"4eb0f9ea-c909-4816-a6f3-15de9ba55fe8",
	"00000000-0000-0000-0000-000000000000",
	9,
	1,
	'column::eliminate line: 9');
INSERT INTO ACT_FOR
	VALUES ("11f3d9e8-2ddd-43ed-b30b-632254e4e466",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b",
	1,
	"207d5af1-d13b-48b8-b849-76f38bc6f230",
	"c86042d6-e3cc-4df6-975a-541ed61508c0",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_VAR
	VALUES ("207d5af1-d13b-48b8-b849-76f38bc6f230",
	"4eb0f9ea-c909-4816-a6f3-15de9ba55fe8",
	'eligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("207d5af1-d13b-48b8-b849-76f38bc6f230",
	1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("862568ca-4245-4c03-9273-f754ed731dad",
	9,
	10,
	17,
	"207d5af1-d13b-48b8-b849-76f38bc6f230");
INSERT INTO V_LOC
	VALUES ("7bdb86b3-aa39-4feb-97eb-736cb59a7400",
	11,
	37,
	44,
	"207d5af1-d13b-48b8-b849-76f38bc6f230");
INSERT INTO V_LOC
	VALUES ("edb6794b-b641-4070-8e34-993a0b7bb7df",
	16,
	31,
	38,
	"207d5af1-d13b-48b8-b849-76f38bc6f230");
INSERT INTO ACT_BLK
	VALUES ("b92b0c08-e1d1-420c-b719-17ab9c933c4b",
	1,
	0,
	1,
	'',
	'',
	'',
	13,
	3,
	10,
	49,
	0,
	0,
	10,
	58,
	0,
	0,
	0,
	0,
	0,
	"74b6372e-b4cc-4e07-aaa5-af8c00cdd16c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ebed1ba6-f21d-4f90-97f0-5d114a1e2dd2",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b",
	"8b127e89-b192-40d4-ae10-9fe534ae09ca",
	10,
	3,
	'column::eliminate line: 10');
INSERT INTO ACT_SEL
	VALUES ("ebed1ba6-f21d-4f90-97f0-5d114a1e2dd2",
	"7a1bb109-0fc1-4172-9fa1-c1cad53d3541",
	1,
	'many',
	"033cba60-1d49-4aa8-bc1d-bb39bff85198");
INSERT INTO ACT_SRW
	VALUES ("ebed1ba6-f21d-4f90-97f0-5d114a1e2dd2",
	"f6084dbf-5d50-4418-8e6a-d458933d0cc8");
INSERT INTO ACT_LNK
	VALUES ("28ad56c4-0f8c-4ed8-bc3f-7bab75e1896d",
	'',
	"ebed1ba6-f21d-4f90-97f0-5d114a1e2dd2",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"8d4cc046-efc8-47a5-849c-92fe458e600a",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	10,
	39,
	10,
	44,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("8d4cc046-efc8-47a5-849c-92fe458e600a",
	'',
	"00000000-0000-0000-0000-000000000000",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	10,
	49,
	10,
	58,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8b127e89-b192-40d4-ae10-9fe534ae09ca",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b",
	"00f7fb65-b5d5-42bc-9a3b-a240d6f717b3",
	12,
	3,
	'column::eliminate line: 12');
INSERT INTO ACT_AI
	VALUES ("8b127e89-b192-40d4-ae10-9fe534ae09ca",
	"63a7e0b0-76a6-482a-ab68-cf71c565ad22",
	"7ff95ef1-9dfe-4b0a-806c-3e47684f3b9a",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("00f7fb65-b5d5-42bc-9a3b-a240d6f717b3",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b",
	"00000000-0000-0000-0000-000000000000",
	13,
	3,
	'column::eliminate line: 13');
INSERT INTO ACT_IF
	VALUES ("00f7fb65-b5d5-42bc-9a3b-a240d6f717b3",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7",
	"d13cefc3-7655-411f-b971-e6209cd82621",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("033cba60-1d49-4aa8-bc1d-bb39bff85198",
	0,
	0,
	10,
	33,
	36,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_IRF
	VALUES ("033cba60-1d49-4aa8-bc1d-bb39bff85198",
	"74f9ee15-7b3e-4472-9fab-1a93b22123c1");
INSERT INTO V_VAL
	VALUES ("6d0c8e47-49f9-4c1c-aff8-7cc12869db7f",
	0,
	0,
	11,
	13,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_SLR
	VALUES ("6d0c8e47-49f9-4c1c-aff8-7cc12869db7f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("89441db9-f72b-4155-a637-b7ab70e4c120",
	0,
	0,
	11,
	22,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_AVL
	VALUES ("89441db9-f72b-4155-a637-b7ab70e4c120",
	"6d0c8e47-49f9-4c1c-aff8-7cc12869db7f",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("f6084dbf-5d50-4418-8e6a-d458933d0cc8",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_BIN
	VALUES ("f6084dbf-5d50-4418-8e6a-d458933d0cc8",
	"ccb453f3-ab04-4dfb-89c6-bd4b34d1cad3",
	"89441db9-f72b-4155-a637-b7ab70e4c120",
	'==');
INSERT INTO V_VAL
	VALUES ("133f9de4-d8c9-40c8-9913-1fb720ff5ac5",
	0,
	0,
	11,
	37,
	44,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_IRF
	VALUES ("133f9de4-d8c9-40c8-9913-1fb720ff5ac5",
	"207d5af1-d13b-48b8-b849-76f38bc6f230");
INSERT INTO V_VAL
	VALUES ("ccb453f3-ab04-4dfb-89c6-bd4b34d1cad3",
	0,
	0,
	11,
	46,
	56,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_AVL
	VALUES ("ccb453f3-ab04-4dfb-89c6-bd4b34d1cad3",
	"133f9de4-d8c9-40c8-9913-1fb720ff5ac5",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("7ff95ef1-9dfe-4b0a-806c-3e47684f3b9a",
	1,
	0,
	12,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_TVL
	VALUES ("7ff95ef1-9dfe-4b0a-806c-3e47684f3b9a",
	"d7106a16-b3ed-4ff2-beea-442300ed9853");
INSERT INTO V_VAL
	VALUES ("7b0777cf-0cc9-45c5-905c-8343c42e52a8",
	0,
	0,
	12,
	19,
	24,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_ISR
	VALUES ("7b0777cf-0cc9-45c5-905c-8343c42e52a8",
	"7a1bb109-0fc1-4172-9fa1-c1cad53d3541");
INSERT INTO V_VAL
	VALUES ("63a7e0b0-76a6-482a-ab68-cf71c565ad22",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_UNY
	VALUES ("63a7e0b0-76a6-482a-ab68-cf71c565ad22",
	"7b0777cf-0cc9-45c5-905c-8343c42e52a8",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("3a28ea21-bf94-4ea4-a7e2-15c4bfcf0dc7",
	0,
	0,
	13,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_LIN
	VALUES ("3a28ea21-bf94-4ea4-a7e2-15c4bfcf0dc7",
	'1');
INSERT INTO V_VAL
	VALUES ("d13cefc3-7655-411f-b971-e6209cd82621",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_BIN
	VALUES ("d13cefc3-7655-411f-b971-e6209cd82621",
	"be7ba23f-870f-4c1b-a7fd-1750cab5d805",
	"3a28ea21-bf94-4ea4-a7e2-15c4bfcf0dc7",
	'==');
INSERT INTO V_VAL
	VALUES ("be7ba23f-870f-4c1b-a7fd-1750cab5d805",
	0,
	0,
	13,
	13,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b");
INSERT INTO V_TVL
	VALUES ("be7ba23f-870f-4c1b-a7fd-1750cab5d805",
	"d7106a16-b3ed-4ff2-beea-442300ed9853");
INSERT INTO V_VAR
	VALUES ("7a1bb109-0fc1-4172-9fa1-c1cad53d3541",
	"b92b0c08-e1d1-420c-b719-17ab9c933c4b",
	'loners',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("7a1bb109-0fc1-4172-9fa1-c1cad53d3541",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("aa306019-c745-4b8b-882e-4584a73248a1",
	10,
	15,
	20,
	"7a1bb109-0fc1-4172-9fa1-c1cad53d3541");
INSERT INTO ACT_BLK
	VALUES ("f82c06d2-7102-432e-9d9a-04728fccb7e7",
	1,
	0,
	0,
	'',
	'',
	'',
	19,
	5,
	15,
	42,
	0,
	0,
	15,
	47,
	0,
	0,
	0,
	0,
	0,
	"74b6372e-b4cc-4e07-aaa5-af8c00cdd16c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7a4e5a94-1cc9-47b6-8a20-17fde4ea853d",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7",
	"45d345a3-8795-4d01-88e5-bf0baabc8407",
	15,
	5,
	'column::eliminate line: 15');
INSERT INTO ACT_SEL
	VALUES ("7a4e5a94-1cc9-47b6-8a20-17fde4ea853d",
	"b7140cd4-9b54-44aa-b3fb-c2430c12b4c5",
	1,
	'one',
	"f2a77a05-a154-4fa7-8dd5-72bbac6f5f9c");
INSERT INTO ACT_SR
	VALUES ("7a4e5a94-1cc9-47b6-8a20-17fde4ea853d");
INSERT INTO ACT_LNK
	VALUES ("ac27a466-7548-4122-a37f-56315a660a4a",
	'',
	"7a4e5a94-1cc9-47b6-8a20-17fde4ea853d",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	15,
	42,
	15,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("45d345a3-8795-4d01-88e5-bf0baabc8407",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7",
	"03ac5164-ab97-4931-8ea5-18c42d921985",
	16,
	5,
	'column::eliminate line: 16');
INSERT INTO ACT_TFM
	VALUES ("45d345a3-8795-4d01-88e5-bf0baabc8407",
	"a3632caa-a4af-4c7b-8e5d-212826ddcf99",
	"b7140cd4-9b54-44aa-b3fb-c2430c12b4c5",
	16,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("03ac5164-ab97-4931-8ea5-18c42d921985",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7",
	"bb06b806-1bd4-4334-acdc-3ee73bcd17c7",
	18,
	5,
	'column::eliminate line: 18');
INSERT INTO ACT_AI
	VALUES ("03ac5164-ab97-4931-8ea5-18c42d921985",
	"cf85f36c-0ed9-4635-b47a-69fcb39b4510",
	"c0919458-ccf5-4902-9bac-ab6d5d213b7f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("bb06b806-1bd4-4334-acdc-3ee73bcd17c7",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7",
	"00000000-0000-0000-0000-000000000000",
	19,
	5,
	'column::eliminate line: 19');
INSERT INTO ACT_BRK
	VALUES ("bb06b806-1bd4-4334-acdc-3ee73bcd17c7");
INSERT INTO V_VAL
	VALUES ("f2a77a05-a154-4fa7-8dd5-72bbac6f5f9c",
	0,
	0,
	15,
	32,
	39,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7");
INSERT INTO V_IRF
	VALUES ("f2a77a05-a154-4fa7-8dd5-72bbac6f5f9c",
	"207d5af1-d13b-48b8-b849-76f38bc6f230");
INSERT INTO V_VAL
	VALUES ("4d05f591-bb6d-477f-a8d6-6ea388f6b1bd",
	0,
	0,
	16,
	31,
	38,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7");
INSERT INTO V_IRF
	VALUES ("4d05f591-bb6d-477f-a8d6-6ea388f6b1bd",
	"207d5af1-d13b-48b8-b849-76f38bc6f230");
INSERT INTO V_VAL
	VALUES ("7b2e7bbf-c6c7-472d-9dd6-4184d62cd2da",
	0,
	0,
	16,
	40,
	50,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7");
INSERT INTO V_AVL
	VALUES ("7b2e7bbf-c6c7-472d-9dd6-4184d62cd2da",
	"4d05f591-bb6d-477f-a8d6-6ea388f6b1bd",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_PAR
	VALUES ("7b2e7bbf-c6c7-472d-9dd6-4184d62cd2da",
	"45d345a3-8795-4d01-88e5-bf0baabc8407",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	16,
	18);
INSERT INTO V_VAL
	VALUES ("c0919458-ccf5-4902-9bac-ab6d5d213b7f",
	1,
	0,
	18,
	5,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7");
INSERT INTO V_TVL
	VALUES ("c0919458-ccf5-4902-9bac-ab6d5d213b7f",
	"ad163ac6-fea3-44e7-988e-ae7d249d52bd");
INSERT INTO V_VAL
	VALUES ("cf85f36c-0ed9-4635-b47a-69fcb39b4510",
	0,
	0,
	18,
	19,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7");
INSERT INTO V_LIN
	VALUES ("cf85f36c-0ed9-4635-b47a-69fcb39b4510",
	'1');
INSERT INTO V_VAR
	VALUES ("b7140cd4-9b54-44aa-b3fb-c2430c12b4c5",
	"f82c06d2-7102-432e-9d9a-04728fccb7e7",
	'cell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("b7140cd4-9b54-44aa-b3fb-c2430c12b4c5",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("a4c77dcc-120d-4473-9b78-bd05d85a91b9",
	15,
	16,
	19,
	"b7140cd4-9b54-44aa-b3fb-c2430c12b4c5");
INSERT INTO V_LOC
	VALUES ("d61fae36-cf3f-4a9d-9cb2-7c561f53cb89",
	16,
	5,
	8,
	"b7140cd4-9b54-44aa-b3fb-c2430c12b4c5");
INSERT INTO O_NBATTR
	VALUES ("90e0d09a-7fa5-45f0-ac4f-f519aa651f29",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO O_BATTR
	VALUES ("90e0d09a-7fa5-45f0-ac4f-f519aa651f29",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO O_ATTR
	VALUES ("90e0d09a-7fa5-45f0-ac4f-f519aa651f29",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	"00000000-0000-0000-0000-000000000000",
	'number',
	'',
	'',
	'number',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("b4b801fb-a013-46a7-a236-07ca7963c923",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO O_BATTR
	VALUES ("b4b801fb-a013-46a7-a236-07ca7963c923",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO O_ATTR
	VALUES ("b4b801fb-a013-46a7-a236-07ca7963c923",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	"90e0d09a-7fa5-45f0-ac4f-f519aa651f29",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"ea4f2014-da78-4798-8130-991e8750cff6",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO O_ID
	VALUES (1,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO O_OIDA
	VALUES ("90e0d09a-7fa5-45f0-ac4f-f519aa651f29",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	1);
INSERT INTO O_ID
	VALUES (2,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO SM_ISM
	VALUES ("191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO SM_SM
	VALUES ("191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("191f3cac-3a11-4a29-a15a-2cf0b5518da2");
INSERT INTO SM_LEVT
	VALUES ("ee87929d-8d33-409c-be82-b312e01b87ec",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("ee87929d-8d33-409c-be82-b312e01b87ec",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("ee87929d-8d33-409c-be82-b312e01b87ec",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000",
	1,
	'update',
	0,
	'',
	'COLUMN1',
	'');
INSERT INTO SM_LEVT
	VALUES ("87fca4be-2420-428e-be5e-4afc33485f64",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("87fca4be-2420-428e-be5e-4afc33485f64",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("87fca4be-2420-428e-be5e-4afc33485f64",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000",
	2,
	'solved',
	0,
	'',
	'COLUMN2',
	'');
INSERT INTO SM_STATE
	VALUES ("607760d9-e4a5-435a-bab4-8c5cefc62a3b",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000",
	'solving',
	1,
	0);
INSERT INTO SM_SEME
	VALUES ("607760d9-e4a5-435a-bab4-8c5cefc62a3b",
	"ee87929d-8d33-409c-be82-b312e01b87ec",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("607760d9-e4a5-435a-bab4-8c5cefc62a3b",
	"87fca4be-2420-428e-be5e-4afc33485f64",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("cc005406-aa07-41cb-8483-dd5d403794d3",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"607760d9-e4a5-435a-bab4-8c5cefc62a3b");
INSERT INTO SM_AH
	VALUES ("cc005406-aa07-41cb-8483-dd5d403794d3",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2");
INSERT INTO SM_ACT
	VALUES ("cc005406-aa07-41cb-8483-dd5d403794d3",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	1,
	'if ( 100 == self.prune() )
  generate COLUMN2:solved() to self;
elif ( 100 == self.eliminate() )
  generate COLUMN2:solved() to self;
else
  select one sequence related by self->SEQUENCE[R1];
  if ( sequence.requests >= 1 )
    sequence.requests = 1;
    c = self;
    generate COLUMN1:update() to c;
  else
    sequence.requests = 0;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES ("05fc18ac-e197-4b15-9e99-a5bb5fbeb2c1",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"cc005406-aa07-41cb-8483-dd5d403794d3");
INSERT INTO ACT_ACT
	VALUES ("05fc18ac-e197-4b15-9e99-a5bb5fbeb2c1",
	'state',
	0,
	"7dab292f-046f-4dd7-b96f-909d29f60775",
	"00000000-0000-0000-0000-000000000000",
	0,
	'column::solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("7dab292f-046f-4dd7-b96f-909d29f60775",
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"05fc18ac-e197-4b15-9e99-a5bb5fbeb2c1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("00eafa07-2527-4b3a-9680-801aeb2e7203",
	"7dab292f-046f-4dd7-b96f-909d29f60775",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'column::solving line: 1');
INSERT INTO ACT_IF
	VALUES ("00eafa07-2527-4b3a-9680-801aeb2e7203",
	"8e6b536c-c94a-4d39-81a5-f620619f0b7f",
	"2902f905-9039-4abb-8884-10c922d8d220",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8d994f46-6bcd-49f1-8869-d8a23d6b50ad",
	"7dab292f-046f-4dd7-b96f-909d29f60775",
	"00000000-0000-0000-0000-000000000000",
	3,
	1,
	'column::solving line: 3');
INSERT INTO ACT_EL
	VALUES ("8d994f46-6bcd-49f1-8869-d8a23d6b50ad",
	"c7d16b7e-bf22-4d1f-ac84-7e188681de22",
	"5fcb714a-2ace-4e8e-879c-928d8563914f",
	"00eafa07-2527-4b3a-9680-801aeb2e7203");
INSERT INTO ACT_SMT
	VALUES ("3ed1eaae-da98-4f01-b38d-9ffc6a1b411d",
	"7dab292f-046f-4dd7-b96f-909d29f60775",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'column::solving line: 5');
INSERT INTO ACT_E
	VALUES ("3ed1eaae-da98-4f01-b38d-9ffc6a1b411d",
	"e15e240d-5e04-483c-9b81-c0699300beea",
	"00eafa07-2527-4b3a-9680-801aeb2e7203");
INSERT INTO V_VAL
	VALUES ("3ee0ac7a-0c44-42e3-94a0-e828690fc596",
	0,
	0,
	1,
	6,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7dab292f-046f-4dd7-b96f-909d29f60775");
INSERT INTO V_LIN
	VALUES ("3ee0ac7a-0c44-42e3-94a0-e828690fc596",
	'100');
INSERT INTO V_VAL
	VALUES ("2902f905-9039-4abb-8884-10c922d8d220",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"7dab292f-046f-4dd7-b96f-909d29f60775");
INSERT INTO V_BIN
	VALUES ("2902f905-9039-4abb-8884-10c922d8d220",
	"5ac2718b-e7da-4742-8e2f-9210980d7900",
	"3ee0ac7a-0c44-42e3-94a0-e828690fc596",
	'==');
INSERT INTO V_VAL
	VALUES ("5ac2718b-e7da-4742-8e2f-9210980d7900",
	0,
	0,
	1,
	18,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7dab292f-046f-4dd7-b96f-909d29f60775");
INSERT INTO V_TRV
	VALUES ("5ac2718b-e7da-4742-8e2f-9210980d7900",
	"477fe3eb-500d-4bd6-b226-d1d06d05d9ea",
	"606df96a-19bc-4f78-bdbc-7bababb6cbba",
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("2e94a538-3278-4228-bb5e-44c4b2b26183",
	0,
	0,
	3,
	8,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7dab292f-046f-4dd7-b96f-909d29f60775");
INSERT INTO V_LIN
	VALUES ("2e94a538-3278-4228-bb5e-44c4b2b26183",
	'100');
INSERT INTO V_VAL
	VALUES ("5fcb714a-2ace-4e8e-879c-928d8563914f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"7dab292f-046f-4dd7-b96f-909d29f60775");
INSERT INTO V_BIN
	VALUES ("5fcb714a-2ace-4e8e-879c-928d8563914f",
	"fa2779cf-2825-4c18-9b1f-d92bdc6b6cc5",
	"2e94a538-3278-4228-bb5e-44c4b2b26183",
	'==');
INSERT INTO V_VAL
	VALUES ("fa2779cf-2825-4c18-9b1f-d92bdc6b6cc5",
	0,
	0,
	3,
	20,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7dab292f-046f-4dd7-b96f-909d29f60775");
INSERT INTO V_TRV
	VALUES ("fa2779cf-2825-4c18-9b1f-d92bdc6b6cc5",
	"3bc8ba55-c728-4dd2-9472-84165cae4da9",
	"606df96a-19bc-4f78-bdbc-7bababb6cbba",
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("606df96a-19bc-4f78-bdbc-7bababb6cbba",
	"7dab292f-046f-4dd7-b96f-909d29f60775",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("606df96a-19bc-4f78-bdbc-7bababb6cbba",
	0,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_LOC
	VALUES ("64af96d8-a14a-4ac9-8512-4ef5708cc225",
	1,
	13,
	16,
	"606df96a-19bc-4f78-bdbc-7bababb6cbba");
INSERT INTO V_LOC
	VALUES ("8d066f04-4b57-4674-a91a-c6eed628e806",
	2,
	32,
	35,
	"606df96a-19bc-4f78-bdbc-7bababb6cbba");
INSERT INTO V_LOC
	VALUES ("12a010a7-3fce-4ea5-9d29-65a8b005da6c",
	3,
	15,
	18,
	"606df96a-19bc-4f78-bdbc-7bababb6cbba");
INSERT INTO V_LOC
	VALUES ("7e6919ce-e9e4-4306-8875-09d2a832ec94",
	4,
	32,
	35,
	"606df96a-19bc-4f78-bdbc-7bababb6cbba");
INSERT INTO V_LOC
	VALUES ("ed2bd1ea-7045-45f2-a423-0d5dc8b73cc0",
	9,
	9,
	12,
	"606df96a-19bc-4f78-bdbc-7bababb6cbba");
INSERT INTO ACT_BLK
	VALUES ("8e6b536c-c94a-4d39-81a5-f620619f0b7f",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"05fc18ac-e197-4b15-9e99-a5bb5fbeb2c1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1ddc7f6b-fc83-43b1-8352-a891faa206dc",
	"8e6b536c-c94a-4d39-81a5-f620619f0b7f",
	"00000000-0000-0000-0000-000000000000",
	2,
	3,
	'column::solving line: 2');
INSERT INTO E_ESS
	VALUES ("1ddc7f6b-fc83-43b1-8352-a891faa206dc",
	1,
	0,
	2,
	12,
	2,
	20,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("1ddc7f6b-fc83-43b1-8352-a891faa206dc");
INSERT INTO E_GSME
	VALUES ("1ddc7f6b-fc83-43b1-8352-a891faa206dc",
	"87fca4be-2420-428e-be5e-4afc33485f64",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2");
INSERT INTO E_GEN
	VALUES ("1ddc7f6b-fc83-43b1-8352-a891faa206dc",
	"606df96a-19bc-4f78-bdbc-7bababb6cbba");
INSERT INTO ACT_BLK
	VALUES ("c7d16b7e-bf22-4d1f-ac84-7e188681de22",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"05fc18ac-e197-4b15-9e99-a5bb5fbeb2c1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1bc3390e-da8a-45c9-88da-d1498cffa120",
	"c7d16b7e-bf22-4d1f-ac84-7e188681de22",
	"00000000-0000-0000-0000-000000000000",
	4,
	3,
	'column::solving line: 4');
INSERT INTO E_ESS
	VALUES ("1bc3390e-da8a-45c9-88da-d1498cffa120",
	1,
	0,
	4,
	12,
	4,
	20,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("1bc3390e-da8a-45c9-88da-d1498cffa120");
INSERT INTO E_GSME
	VALUES ("1bc3390e-da8a-45c9-88da-d1498cffa120",
	"87fca4be-2420-428e-be5e-4afc33485f64",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2");
INSERT INTO E_GEN
	VALUES ("1bc3390e-da8a-45c9-88da-d1498cffa120",
	"606df96a-19bc-4f78-bdbc-7bababb6cbba");
INSERT INTO ACT_BLK
	VALUES ("e15e240d-5e04-483c-9b81-c0699300beea",
	1,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	6,
	40,
	0,
	0,
	6,
	49,
	0,
	0,
	0,
	0,
	0,
	"05fc18ac-e197-4b15-9e99-a5bb5fbeb2c1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3afe9067-9232-402a-b255-9ebd97bb2c55",
	"e15e240d-5e04-483c-9b81-c0699300beea",
	"d6183f71-a8df-4082-a486-2467067d0006",
	6,
	3,
	'column::solving line: 6');
INSERT INTO ACT_SEL
	VALUES ("3afe9067-9232-402a-b255-9ebd97bb2c55",
	"4dd17364-706b-4ed0-aa3f-a6f1c8a76b8f",
	1,
	'one',
	"0fd41399-2059-43cd-9fac-2c438ec6ec50");
INSERT INTO ACT_SR
	VALUES ("3afe9067-9232-402a-b255-9ebd97bb2c55");
INSERT INTO ACT_LNK
	VALUES ("05a767f6-54f8-423b-97ec-6e87aeab1586",
	'',
	"3afe9067-9232-402a-b255-9ebd97bb2c55",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	6,
	40,
	6,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d6183f71-a8df-4082-a486-2467067d0006",
	"e15e240d-5e04-483c-9b81-c0699300beea",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'column::solving line: 7');
INSERT INTO ACT_IF
	VALUES ("d6183f71-a8df-4082-a486-2467067d0006",
	"8d7f9f48-ef2a-4973-95ef-d98d36d0a630",
	"9acd30ee-5ed3-4fee-a50a-5ec77f29d786",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("a05a51b1-6fda-41b3-ac73-d5b0577df454",
	"e15e240d-5e04-483c-9b81-c0699300beea",
	"00000000-0000-0000-0000-000000000000",
	11,
	3,
	'column::solving line: 11');
INSERT INTO ACT_E
	VALUES ("a05a51b1-6fda-41b3-ac73-d5b0577df454",
	"87f7e39a-b0c3-44ad-9ce2-48674d58c124",
	"d6183f71-a8df-4082-a486-2467067d0006");
INSERT INTO V_VAL
	VALUES ("0fd41399-2059-43cd-9fac-2c438ec6ec50",
	0,
	0,
	6,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"e15e240d-5e04-483c-9b81-c0699300beea");
INSERT INTO V_IRF
	VALUES ("0fd41399-2059-43cd-9fac-2c438ec6ec50",
	"606df96a-19bc-4f78-bdbc-7bababb6cbba");
INSERT INTO V_VAL
	VALUES ("3e1021d5-f3fe-48d0-8abf-96895dba283d",
	0,
	0,
	7,
	8,
	15,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"e15e240d-5e04-483c-9b81-c0699300beea");
INSERT INTO V_IRF
	VALUES ("3e1021d5-f3fe-48d0-8abf-96895dba283d",
	"4dd17364-706b-4ed0-aa3f-a6f1c8a76b8f");
INSERT INTO V_VAL
	VALUES ("969f131e-87bf-45ef-846f-4066efc37d25",
	0,
	0,
	7,
	17,
	24,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e15e240d-5e04-483c-9b81-c0699300beea");
INSERT INTO V_AVL
	VALUES ("969f131e-87bf-45ef-846f-4066efc37d25",
	"3e1021d5-f3fe-48d0-8abf-96895dba283d",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("9acd30ee-5ed3-4fee-a50a-5ec77f29d786",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"e15e240d-5e04-483c-9b81-c0699300beea");
INSERT INTO V_BIN
	VALUES ("9acd30ee-5ed3-4fee-a50a-5ec77f29d786",
	"c1bb1cbe-9268-4ebe-af97-685c663563d6",
	"969f131e-87bf-45ef-846f-4066efc37d25",
	'>=');
INSERT INTO V_VAL
	VALUES ("c1bb1cbe-9268-4ebe-af97-685c663563d6",
	0,
	0,
	7,
	29,
	29,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"e15e240d-5e04-483c-9b81-c0699300beea");
INSERT INTO V_LIN
	VALUES ("c1bb1cbe-9268-4ebe-af97-685c663563d6",
	'1');
INSERT INTO V_VAR
	VALUES ("4dd17364-706b-4ed0-aa3f-a6f1c8a76b8f",
	"e15e240d-5e04-483c-9b81-c0699300beea",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("4dd17364-706b-4ed0-aa3f-a6f1c8a76b8f",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("f3d65e99-7ef2-4ce4-9f47-e43cb228c6da",
	6,
	14,
	21,
	"4dd17364-706b-4ed0-aa3f-a6f1c8a76b8f");
INSERT INTO V_LOC
	VALUES ("bea4119b-2ed6-426a-960a-87e65e364c7c",
	7,
	8,
	15,
	"4dd17364-706b-4ed0-aa3f-a6f1c8a76b8f");
INSERT INTO V_LOC
	VALUES ("6594468a-1e19-45ad-8034-34b0eb7bb221",
	8,
	5,
	12,
	"4dd17364-706b-4ed0-aa3f-a6f1c8a76b8f");
INSERT INTO V_LOC
	VALUES ("d4fb2dd9-8f5d-4a78-b73c-fa9eeae382eb",
	12,
	5,
	12,
	"4dd17364-706b-4ed0-aa3f-a6f1c8a76b8f");
INSERT INTO ACT_BLK
	VALUES ("8d7f9f48-ef2a-4973-95ef-d98d36d0a630",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"05fc18ac-e197-4b15-9e99-a5bb5fbeb2c1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("caba471d-60f7-404b-bd3e-277f016a4070",
	"8d7f9f48-ef2a-4973-95ef-d98d36d0a630",
	"9f5ca8a6-fbdb-4daa-b93e-3071f37202e4",
	8,
	5,
	'column::solving line: 8');
INSERT INTO ACT_AI
	VALUES ("caba471d-60f7-404b-bd3e-277f016a4070",
	"59985711-84aa-484b-bfc0-aa1656c44ac9",
	"9f099163-85b3-42ba-92a2-cc5532a56599",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9f5ca8a6-fbdb-4daa-b93e-3071f37202e4",
	"8d7f9f48-ef2a-4973-95ef-d98d36d0a630",
	"279f9c64-0e74-4941-81f0-6424733a7dd0",
	9,
	5,
	'column::solving line: 9');
INSERT INTO ACT_AI
	VALUES ("9f5ca8a6-fbdb-4daa-b93e-3071f37202e4",
	"2c34c8de-82ea-47de-adf4-29a3279d7d1a",
	"f7da753a-1c2f-4e3b-8245-023b1aa7cce6",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("279f9c64-0e74-4941-81f0-6424733a7dd0",
	"8d7f9f48-ef2a-4973-95ef-d98d36d0a630",
	"00000000-0000-0000-0000-000000000000",
	10,
	5,
	'column::solving line: 10');
INSERT INTO E_ESS
	VALUES ("279f9c64-0e74-4941-81f0-6424733a7dd0",
	1,
	0,
	10,
	14,
	10,
	22,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("279f9c64-0e74-4941-81f0-6424733a7dd0");
INSERT INTO E_GSME
	VALUES ("279f9c64-0e74-4941-81f0-6424733a7dd0",
	"ee87929d-8d33-409c-be82-b312e01b87ec",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2");
INSERT INTO E_GEN
	VALUES ("279f9c64-0e74-4941-81f0-6424733a7dd0",
	"4bb852b0-ad17-4139-8e7a-ffd2e1cd6422");
INSERT INTO V_VAL
	VALUES ("17f19194-184f-46bf-82a1-d59d58d72227",
	1,
	0,
	8,
	5,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"8d7f9f48-ef2a-4973-95ef-d98d36d0a630");
INSERT INTO V_IRF
	VALUES ("17f19194-184f-46bf-82a1-d59d58d72227",
	"4dd17364-706b-4ed0-aa3f-a6f1c8a76b8f");
INSERT INTO V_VAL
	VALUES ("9f099163-85b3-42ba-92a2-cc5532a56599",
	1,
	0,
	8,
	14,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"8d7f9f48-ef2a-4973-95ef-d98d36d0a630");
INSERT INTO V_AVL
	VALUES ("9f099163-85b3-42ba-92a2-cc5532a56599",
	"17f19194-184f-46bf-82a1-d59d58d72227",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("59985711-84aa-484b-bfc0-aa1656c44ac9",
	0,
	0,
	8,
	25,
	25,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"8d7f9f48-ef2a-4973-95ef-d98d36d0a630");
INSERT INTO V_LIN
	VALUES ("59985711-84aa-484b-bfc0-aa1656c44ac9",
	'1');
INSERT INTO V_VAL
	VALUES ("f7da753a-1c2f-4e3b-8245-023b1aa7cce6",
	1,
	1,
	9,
	5,
	5,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"8d7f9f48-ef2a-4973-95ef-d98d36d0a630");
INSERT INTO V_IRF
	VALUES ("f7da753a-1c2f-4e3b-8245-023b1aa7cce6",
	"4bb852b0-ad17-4139-8e7a-ffd2e1cd6422");
INSERT INTO V_VAL
	VALUES ("2c34c8de-82ea-47de-adf4-29a3279d7d1a",
	0,
	0,
	9,
	9,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"8d7f9f48-ef2a-4973-95ef-d98d36d0a630");
INSERT INTO V_IRF
	VALUES ("2c34c8de-82ea-47de-adf4-29a3279d7d1a",
	"606df96a-19bc-4f78-bdbc-7bababb6cbba");
INSERT INTO V_VAR
	VALUES ("4bb852b0-ad17-4139-8e7a-ffd2e1cd6422",
	"8d7f9f48-ef2a-4973-95ef-d98d36d0a630",
	'c',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("4bb852b0-ad17-4139-8e7a-ffd2e1cd6422",
	0,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_LOC
	VALUES ("1f7d2d94-e7f5-479f-ab48-cea7b06422be",
	9,
	5,
	5,
	"4bb852b0-ad17-4139-8e7a-ffd2e1cd6422");
INSERT INTO V_LOC
	VALUES ("c3f72f50-18f0-4db5-8175-31f84d5565f3",
	10,
	34,
	34,
	"4bb852b0-ad17-4139-8e7a-ffd2e1cd6422");
INSERT INTO ACT_BLK
	VALUES ("87f7e39a-b0c3-44ad-9ce2-48674d58c124",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"05fc18ac-e197-4b15-9e99-a5bb5fbeb2c1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3d686691-4628-42ef-a00c-07e944ea47ab",
	"87f7e39a-b0c3-44ad-9ce2-48674d58c124",
	"00000000-0000-0000-0000-000000000000",
	12,
	5,
	'column::solving line: 12');
INSERT INTO ACT_AI
	VALUES ("3d686691-4628-42ef-a00c-07e944ea47ab",
	"c64fb7b0-0191-47e0-a1df-41b2180ff926",
	"b4411bc0-8590-4561-b02d-de3e7fbc326b",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("30a6ffc5-7691-4261-ad54-736b0046c3bb",
	1,
	0,
	12,
	5,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"87f7e39a-b0c3-44ad-9ce2-48674d58c124");
INSERT INTO V_IRF
	VALUES ("30a6ffc5-7691-4261-ad54-736b0046c3bb",
	"4dd17364-706b-4ed0-aa3f-a6f1c8a76b8f");
INSERT INTO V_VAL
	VALUES ("b4411bc0-8590-4561-b02d-de3e7fbc326b",
	1,
	0,
	12,
	14,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"87f7e39a-b0c3-44ad-9ce2-48674d58c124");
INSERT INTO V_AVL
	VALUES ("b4411bc0-8590-4561-b02d-de3e7fbc326b",
	"30a6ffc5-7691-4261-ad54-736b0046c3bb",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("c64fb7b0-0191-47e0-a1df-41b2180ff926",
	0,
	0,
	12,
	25,
	25,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"87f7e39a-b0c3-44ad-9ce2-48674d58c124");
INSERT INTO V_LIN
	VALUES ("c64fb7b0-0191-47e0-a1df-41b2180ff926",
	'0');
INSERT INTO SM_STATE
	VALUES ("b3bdd826-6e61-4976-9236-2cbacdc18590",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000",
	'solved',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES ("b3bdd826-6e61-4976-9236-2cbacdc18590",
	"ee87929d-8d33-409c-be82-b312e01b87ec",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("b3bdd826-6e61-4976-9236-2cbacdc18590",
	"ee87929d-8d33-409c-be82-b312e01b87ec",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EIGN
	VALUES ("b3bdd826-6e61-4976-9236-2cbacdc18590",
	"87fca4be-2420-428e-be5e-4afc33485f64",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("b3bdd826-6e61-4976-9236-2cbacdc18590",
	"87fca4be-2420-428e-be5e-4afc33485f64",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("15355f69-e6d6-41db-9a2b-1e5c1cb416e4",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"b3bdd826-6e61-4976-9236-2cbacdc18590");
INSERT INTO SM_AH
	VALUES ("15355f69-e6d6-41db-9a2b-1e5c1cb416e4",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2");
INSERT INTO SM_ACT
	VALUES ("15355f69-e6d6-41db-9a2b-1e5c1cb416e4",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	1,
	'select one sequence related by self->SEQUENCE[R1];
sequence.solved = true;',
	'');
INSERT INTO ACT_SAB
	VALUES ("38bcda70-5126-4422-925e-68552f4087c7",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"15355f69-e6d6-41db-9a2b-1e5c1cb416e4");
INSERT INTO ACT_ACT
	VALUES ("38bcda70-5126-4422-925e-68552f4087c7",
	'state',
	0,
	"f90df0c5-5b3f-4596-ac25-7eceed2bc196",
	"00000000-0000-0000-0000-000000000000",
	0,
	'column::solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("f90df0c5-5b3f-4596-ac25-7eceed2bc196",
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	1,
	47,
	0,
	0,
	0,
	0,
	0,
	"38bcda70-5126-4422-925e-68552f4087c7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c97dc3be-c08f-4e22-a02d-f980215e73ec",
	"f90df0c5-5b3f-4596-ac25-7eceed2bc196",
	"eb197117-14f9-46c0-b3df-64865a56caea",
	1,
	1,
	'column::solved line: 1');
INSERT INTO ACT_SEL
	VALUES ("c97dc3be-c08f-4e22-a02d-f980215e73ec",
	"d761f341-942f-4452-96bc-e7cd93bb4fe1",
	1,
	'one',
	"9feaf692-e633-4e27-b027-1f17f61abe55");
INSERT INTO ACT_SR
	VALUES ("c97dc3be-c08f-4e22-a02d-f980215e73ec");
INSERT INTO ACT_LNK
	VALUES ("301b4185-a52b-4b4c-81ca-a71e7907ac5e",
	'',
	"c97dc3be-c08f-4e22-a02d-f980215e73ec",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	1,
	38,
	1,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("eb197117-14f9-46c0-b3df-64865a56caea",
	"f90df0c5-5b3f-4596-ac25-7eceed2bc196",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'column::solved line: 2');
INSERT INTO ACT_AI
	VALUES ("eb197117-14f9-46c0-b3df-64865a56caea",
	"02699dfa-be22-4548-a467-5980b9eda509",
	"2c4314e0-67b8-43dc-9716-c5c687f40ba9",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("9feaf692-e633-4e27-b027-1f17f61abe55",
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"f90df0c5-5b3f-4596-ac25-7eceed2bc196");
INSERT INTO V_IRF
	VALUES ("9feaf692-e633-4e27-b027-1f17f61abe55",
	"db797f13-2d5b-44a9-8ab7-1ea8dd1f72a1");
INSERT INTO V_VAL
	VALUES ("e19ad1e4-bcdc-4bd6-bb13-119e6d3bb2a2",
	1,
	0,
	2,
	1,
	8,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"f90df0c5-5b3f-4596-ac25-7eceed2bc196");
INSERT INTO V_IRF
	VALUES ("e19ad1e4-bcdc-4bd6-bb13-119e6d3bb2a2",
	"d761f341-942f-4452-96bc-e7cd93bb4fe1");
INSERT INTO V_VAL
	VALUES ("2c4314e0-67b8-43dc-9716-c5c687f40ba9",
	1,
	0,
	2,
	10,
	15,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"f90df0c5-5b3f-4596-ac25-7eceed2bc196");
INSERT INTO V_AVL
	VALUES ("2c4314e0-67b8-43dc-9716-c5c687f40ba9",
	"e19ad1e4-bcdc-4bd6-bb13-119e6d3bb2a2",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"48d19dd8-8465-49b9-b4d0-dd14aa6d653f");
INSERT INTO V_VAL
	VALUES ("02699dfa-be22-4548-a467-5980b9eda509",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"f90df0c5-5b3f-4596-ac25-7eceed2bc196");
INSERT INTO V_LBO
	VALUES ("02699dfa-be22-4548-a467-5980b9eda509",
	'TRUE');
INSERT INTO V_VAR
	VALUES ("d761f341-942f-4452-96bc-e7cd93bb4fe1",
	"f90df0c5-5b3f-4596-ac25-7eceed2bc196",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("d761f341-942f-4452-96bc-e7cd93bb4fe1",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("8f3be024-bb67-4f70-9c52-92cdecdc81d2",
	1,
	12,
	19,
	"d761f341-942f-4452-96bc-e7cd93bb4fe1");
INSERT INTO V_LOC
	VALUES ("3fa46027-bdcb-42e7-83fa-802bbb8e9619",
	2,
	1,
	8,
	"d761f341-942f-4452-96bc-e7cd93bb4fe1");
INSERT INTO V_VAR
	VALUES ("db797f13-2d5b-44a9-8ab7-1ea8dd1f72a1",
	"f90df0c5-5b3f-4596-ac25-7eceed2bc196",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("db797f13-2d5b-44a9-8ab7-1ea8dd1f72a1",
	0,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO SM_NSTXN
	VALUES ("92ef5759-b43a-4ddd-9e24-cc641a9b912a",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"607760d9-e4a5-435a-bab4-8c5cefc62a3b",
	"ee87929d-8d33-409c-be82-b312e01b87ec",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("f70985d2-8b27-4cfc-a033-e1a1e5f6de78",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"92ef5759-b43a-4ddd-9e24-cc641a9b912a");
INSERT INTO SM_AH
	VALUES ("f70985d2-8b27-4cfc-a033-e1a1e5f6de78",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2");
INSERT INTO SM_ACT
	VALUES ("f70985d2-8b27-4cfc-a033-e1a1e5f6de78",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("c5a31db7-35ba-487f-b922-a4c392f8c8a7",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"f70985d2-8b27-4cfc-a033-e1a1e5f6de78");
INSERT INTO ACT_ACT
	VALUES ("c5a31db7-35ba-487f-b922-a4c392f8c8a7",
	'transition',
	0,
	"8cb3f835-4dd8-471c-bf57-099e988462b0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'COLUMN1: update in solving to solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("8cb3f835-4dd8-471c-bf57-099e988462b0",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"c5a31db7-35ba-487f-b922-a4c392f8c8a7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("92ef5759-b43a-4ddd-9e24-cc641a9b912a",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"607760d9-e4a5-435a-bab4-8c5cefc62a3b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("74a3c184-845a-4c6c-9e71-5ab703b3cfca",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"607760d9-e4a5-435a-bab4-8c5cefc62a3b",
	"87fca4be-2420-428e-be5e-4afc33485f64",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("cc64ff52-2cb9-4d82-92e5-decd9a7e19f6",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"74a3c184-845a-4c6c-9e71-5ab703b3cfca");
INSERT INTO SM_AH
	VALUES ("cc64ff52-2cb9-4d82-92e5-decd9a7e19f6",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2");
INSERT INTO SM_ACT
	VALUES ("cc64ff52-2cb9-4d82-92e5-decd9a7e19f6",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("f84788a0-7782-4c1b-9f55-6c4b5f2738c3",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"cc64ff52-2cb9-4d82-92e5-decd9a7e19f6");
INSERT INTO ACT_ACT
	VALUES ("f84788a0-7782-4c1b-9f55-6c4b5f2738c3",
	'transition',
	0,
	"d78293cf-dede-4a49-abd1-e1f52231742a",
	"00000000-0000-0000-0000-000000000000",
	0,
	'COLUMN2: solved in solving to solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("d78293cf-dede-4a49-abd1-e1f52231742a",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f84788a0-7782-4c1b-9f55-6c4b5f2738c3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("74a3c184-845a-4c6c-9e71-5ab703b3cfca",
	"191f3cac-3a11-4a29-a15a-2cf0b5518da2",
	"b3bdd826-6e61-4976-9236-2cbacdc18590",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_OBJ
	VALUES ("8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	'digit',
	6,
	'DIGIT',
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO O_NBATTR
	VALUES ("53e80efe-cb6c-4332-b046-1ba6f6005b30",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO O_BATTR
	VALUES ("53e80efe-cb6c-4332-b046-1ba6f6005b30",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO O_ATTR
	VALUES ("53e80efe-cb6c-4332-b046-1ba6f6005b30",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"00000000-0000-0000-0000-000000000000",
	'value',
	'',
	'',
	'value',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO O_OIDA
	VALUES ("53e80efe-cb6c-4332-b046-1ba6f6005b30",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	0);
INSERT INTO O_ID
	VALUES (1,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO O_ID
	VALUES (2,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO O_OBJ
	VALUES ("7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	'eligible digit',
	7,
	'ELIGIBLE',
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO O_TFR
	VALUES ("d02e6fa1-63a8-45ba-8a60-27232a956e33",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	'eliminate',
	'',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	1,
	'select one digit related by self->DIGIT[R8];
select one cell related by self->CELL[R8];
unrelate cell from digit across R8 using self;',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_OPB
	VALUES ("a14b64a8-735f-4a79-873e-0b44e963dc5b",
	"d02e6fa1-63a8-45ba-8a60-27232a956e33");
INSERT INTO ACT_ACT
	VALUES ("a14b64a8-735f-4a79-873e-0b44e963dc5b",
	'operation',
	0,
	"7d95c90c-424a-452a-bdc4-abb200bc0a5a",
	"00000000-0000-0000-0000-000000000000",
	0,
	'eligible digit::eliminate',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("7d95c90c-424a-452a-bdc4-abb200bc0a5a",
	1,
	0,
	0,
	'',
	'',
	'',
	3,
	1,
	2,
	34,
	0,
	0,
	3,
	33,
	0,
	0,
	0,
	0,
	0,
	"a14b64a8-735f-4a79-873e-0b44e963dc5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("845c629c-6ada-4867-8e69-a5ec0649f862",
	"7d95c90c-424a-452a-bdc4-abb200bc0a5a",
	"8205df73-2a62-4e52-9a64-aaa7a444627f",
	1,
	1,
	'eligible digit::eliminate line: 1');
INSERT INTO ACT_SEL
	VALUES ("845c629c-6ada-4867-8e69-a5ec0649f862",
	"8b07ffd2-ec34-4079-b86e-1606c3554868",
	1,
	'one',
	"08a901c4-30e1-4ddd-b3a4-7b2d1e261467");
INSERT INTO ACT_SR
	VALUES ("845c629c-6ada-4867-8e69-a5ec0649f862");
INSERT INTO ACT_LNK
	VALUES ("f1175807-d5f5-4683-b6cb-a6e60be99e54",
	'',
	"845c629c-6ada-4867-8e69-a5ec0649f862",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	1,
	35,
	1,
	41,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8205df73-2a62-4e52-9a64-aaa7a444627f",
	"7d95c90c-424a-452a-bdc4-abb200bc0a5a",
	"7ca8839b-5f59-46d9-8f3b-210328368440",
	2,
	1,
	'eligible digit::eliminate line: 2');
INSERT INTO ACT_SEL
	VALUES ("8205df73-2a62-4e52-9a64-aaa7a444627f",
	"f23adfc0-7b36-4698-8c2a-b475d0a98564",
	1,
	'one',
	"692390c9-07be-456d-8e59-f8f030569a4f");
INSERT INTO ACT_SR
	VALUES ("8205df73-2a62-4e52-9a64-aaa7a444627f");
INSERT INTO ACT_LNK
	VALUES ("f9ae14bb-f014-443a-bb08-8961e273641d",
	'',
	"8205df73-2a62-4e52-9a64-aaa7a444627f",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	2,
	34,
	2,
	39,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7ca8839b-5f59-46d9-8f3b-210328368440",
	"7d95c90c-424a-452a-bdc4-abb200bc0a5a",
	"00000000-0000-0000-0000-000000000000",
	3,
	1,
	'eligible digit::eliminate line: 3');
INSERT INTO ACT_URU
	VALUES ("7ca8839b-5f59-46d9-8f3b-210328368440",
	"f23adfc0-7b36-4698-8c2a-b475d0a98564",
	"8b07ffd2-ec34-4079-b86e-1606c3554868",
	"c6ba1c06-852a-4813-a39d-8369535ef54a",
	'',
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	3,
	33,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("08a901c4-30e1-4ddd-b3a4-7b2d1e261467",
	0,
	0,
	1,
	29,
	32,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"7d95c90c-424a-452a-bdc4-abb200bc0a5a");
INSERT INTO V_IRF
	VALUES ("08a901c4-30e1-4ddd-b3a4-7b2d1e261467",
	"c6ba1c06-852a-4813-a39d-8369535ef54a");
INSERT INTO V_VAL
	VALUES ("692390c9-07be-456d-8e59-f8f030569a4f",
	0,
	0,
	2,
	28,
	31,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"7d95c90c-424a-452a-bdc4-abb200bc0a5a");
INSERT INTO V_IRF
	VALUES ("692390c9-07be-456d-8e59-f8f030569a4f",
	"c6ba1c06-852a-4813-a39d-8369535ef54a");
INSERT INTO V_VAR
	VALUES ("8b07ffd2-ec34-4079-b86e-1606c3554868",
	"7d95c90c-424a-452a-bdc4-abb200bc0a5a",
	'digit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("8b07ffd2-ec34-4079-b86e-1606c3554868",
	0,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("b374c09b-a275-408e-aa71-373c297cc154",
	1,
	12,
	16,
	"8b07ffd2-ec34-4079-b86e-1606c3554868");
INSERT INTO V_LOC
	VALUES ("3db4e530-c7e2-4f4b-bef0-11b7ea061692",
	3,
	20,
	24,
	"8b07ffd2-ec34-4079-b86e-1606c3554868");
INSERT INTO V_VAR
	VALUES ("c6ba1c06-852a-4813-a39d-8369535ef54a",
	"7d95c90c-424a-452a-bdc4-abb200bc0a5a",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("c6ba1c06-852a-4813-a39d-8369535ef54a",
	0,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("d2601f12-acce-41f8-bb24-7de8f604c7e8",
	3,
	42,
	45,
	"c6ba1c06-852a-4813-a39d-8369535ef54a");
INSERT INTO V_VAR
	VALUES ("f23adfc0-7b36-4698-8c2a-b475d0a98564",
	"7d95c90c-424a-452a-bdc4-abb200bc0a5a",
	'cell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("f23adfc0-7b36-4698-8c2a-b475d0a98564",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("08eb54eb-8d17-44ad-892e-ddd5a4a7f721",
	2,
	12,
	15,
	"f23adfc0-7b36-4698-8c2a-b475d0a98564");
INSERT INTO V_LOC
	VALUES ("fcd2a528-293c-41b9-b4ca-c517f4c6c0e1",
	3,
	10,
	13,
	"f23adfc0-7b36-4698-8c2a-b475d0a98564");
INSERT INTO O_REF
	VALUES ("7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	0,
	"53a62320-a206-4d56-a639-c4592f420548",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"bc9dd594-f2f4-4718-be6c-6256312e19a2",
	"63d41502-a15d-4ab0-b59a-b6d1a1e73f19",
	"e58ec10e-1d0b-445d-b204-277e0e02abc5",
	"e75f50ed-fa55-466b-8aaa-9cd32d1816ee",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'cell',
	'row_number',
	'R8');
INSERT INTO O_RATTR
	VALUES ("e58ec10e-1d0b-445d-b204-277e0e02abc5",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"b7c46385-7816-4616-9e73-922fad4f4af1",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	1,
	'number');
INSERT INTO O_ATTR
	VALUES ("e58ec10e-1d0b-445d-b204-277e0e02abc5",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"00000000-0000-0000-0000-000000000000",
	'row_number',
	'',
	'',
	'row_number',
	2,
	"1a418377-64f4-47d9-aa0e-0773ca94143a",
	'',
	'');
INSERT INTO O_REF
	VALUES ("7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	0,
	"d132eb18-d364-4962-a2a9-487279251e05",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"bc9dd594-f2f4-4718-be6c-6256312e19a2",
	"63d41502-a15d-4ab0-b59a-b6d1a1e73f19",
	"65d0ab1b-befc-4ce0-b04c-fa811d06d4ac",
	"d06c5b8e-2bc8-47c7-ab92-ea9c8f85961b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'cell',
	'column_number',
	'R8');
INSERT INTO O_RATTR
	VALUES ("65d0ab1b-befc-4ce0-b04c-fa811d06d4ac",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"90e0d09a-7fa5-45f0-ac4f-f519aa651f29",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	1,
	'number');
INSERT INTO O_ATTR
	VALUES ("65d0ab1b-befc-4ce0-b04c-fa811d06d4ac",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"e58ec10e-1d0b-445d-b204-277e0e02abc5",
	'column_number',
	'',
	'',
	'column_number',
	2,
	"1a418377-64f4-47d9-aa0e-0773ca94143a",
	'',
	'');
INSERT INTO O_REF
	VALUES ("7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	0,
	"53e80efe-cb6c-4332-b046-1ba6f6005b30",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"bc9dd594-f2f4-4718-be6c-6256312e19a2",
	"c04bc12c-8d28-4e1f-8b30-835e7f55edc6",
	"a460f509-7c57-4f06-af25-d200aed49293",
	"cb07ba48-a5c1-49c4-b9ef-a170a178574f",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'digit',
	'value',
	'R8');
INSERT INTO O_RATTR
	VALUES ("a460f509-7c57-4f06-af25-d200aed49293",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	1,
	'value');
INSERT INTO O_ATTR
	VALUES ("a460f509-7c57-4f06-af25-d200aed49293",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"65d0ab1b-befc-4ce0-b04c-fa811d06d4ac",
	'digit_value',
	'',
	'digit_',
	'value',
	1,
	"1a418377-64f4-47d9-aa0e-0773ca94143a",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO O_OIDA
	VALUES ("e58ec10e-1d0b-445d-b204-277e0e02abc5",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	0);
INSERT INTO O_OIDA
	VALUES ("65d0ab1b-befc-4ce0-b04c-fa811d06d4ac",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	0);
INSERT INTO O_OIDA
	VALUES ("a460f509-7c57-4f06-af25-d200aed49293",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	0);
INSERT INTO O_ID
	VALUES (1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO O_ID
	VALUES (2,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO O_OBJ
	VALUES ("56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	'row',
	2,
	'ROW',
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO O_TFR
	VALUES ("a96f5d87-216f-4cae-a278-9bd89e071d22",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	'eliminate',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	1,
	'// Solve by select all eligible digits.  Notice if any eligible digit appears only once.

temperature = 0;
select many eligibles related by self->CELL[R2]->ELIGIBLE[R8];
c = cardinality eligibles;
if ( 9 == c )
  temperature = 100;
else
for each eligible in eligibles
  select many loners related by self->CELL[R2]->ELIGIBLE[R8]
    where ( selected.digit_value == eligible.digit_value );
  c = cardinality loners;
  if ( 1 == c )
    // This is an answer!
    select one cell related by eligible->CELL[R8];
    cell.answer( answer_digit:eligible.digit_value );
    //generate CELL2:answer( digit:eligible.digit_value ) to cell;
    temperature = 1;
    break;
  end if;
end for;
end if;
return temperature;
',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_OPB
	VALUES ("f63df916-1e70-4a97-bbfc-42682bdba8cc",
	"a96f5d87-216f-4cae-a278-9bd89e071d22");
INSERT INTO ACT_ACT
	VALUES ("f63df916-1e70-4a97-bbfc-42682bdba8cc",
	'operation',
	0,
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	"00000000-0000-0000-0000-000000000000",
	0,
	'row::eliminate',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("7fb322cc-e52f-4068-b546-e657eb637ed3",
	1,
	0,
	0,
	'',
	'',
	'',
	23,
	1,
	4,
	50,
	0,
	0,
	4,
	59,
	0,
	0,
	0,
	0,
	0,
	"f63df916-1e70-4a97-bbfc-42682bdba8cc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("225344da-3472-441e-b68e-d11e191b63d4",
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	"9f32f255-95a1-47f9-98bc-393a20bdb318",
	3,
	1,
	'row::eliminate line: 3');
INSERT INTO ACT_AI
	VALUES ("225344da-3472-441e-b68e-d11e191b63d4",
	"5b6d0291-96f7-45ec-b7dc-66104224bfad",
	"d88acc60-f03c-4211-9baa-727f83143223",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9f32f255-95a1-47f9-98bc-393a20bdb318",
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	"694e306b-99e9-40a3-aae8-a9c97c5a1eed",
	4,
	1,
	'row::eliminate line: 4');
INSERT INTO ACT_SEL
	VALUES ("9f32f255-95a1-47f9-98bc-393a20bdb318",
	"e28d6292-5442-4976-8614-39ab39b2ca2b",
	1,
	'many',
	"12ca5ad2-895f-4e47-b17b-3e8733cb20da");
INSERT INTO ACT_SR
	VALUES ("9f32f255-95a1-47f9-98bc-393a20bdb318");
INSERT INTO ACT_LNK
	VALUES ("48ffde6a-dead-4700-a5a3-5644a62a5fb9",
	'',
	"9f32f255-95a1-47f9-98bc-393a20bdb318",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"8aee94cb-ad7b-41ef-92fc-ab43aed781a6",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	4,
	40,
	4,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("8aee94cb-ad7b-41ef-92fc-ab43aed781a6",
	'',
	"00000000-0000-0000-0000-000000000000",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	4,
	50,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("694e306b-99e9-40a3-aae8-a9c97c5a1eed",
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	"125c40ce-44d2-40c1-9387-2b377d81ab1e",
	5,
	1,
	'row::eliminate line: 5');
INSERT INTO ACT_AI
	VALUES ("694e306b-99e9-40a3-aae8-a9c97c5a1eed",
	"8f7e2aed-755b-4119-a641-edee9938de09",
	"39ed6df4-b1ee-4bc3-90ec-5d03517ca48d",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("125c40ce-44d2-40c1-9387-2b377d81ab1e",
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	"208ddc80-c894-4ad8-a2a1-8f2f2d9b17c4",
	6,
	1,
	'row::eliminate line: 6');
INSERT INTO ACT_IF
	VALUES ("125c40ce-44d2-40c1-9387-2b377d81ab1e",
	"1848015b-0782-45ed-9231-0c83e88ddc34",
	"c1a2ef03-05ef-42c8-aa78-6b2136b55368",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("366ed366-ad5e-4f8c-b5de-3af32ba61d99",
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	"00000000-0000-0000-0000-000000000000",
	8,
	1,
	'row::eliminate line: 8');
INSERT INTO ACT_E
	VALUES ("366ed366-ad5e-4f8c-b5de-3af32ba61d99",
	"14da00f7-485f-4d18-9b7d-e20dfaf5f4d1",
	"125c40ce-44d2-40c1-9387-2b377d81ab1e");
INSERT INTO ACT_SMT
	VALUES ("208ddc80-c894-4ad8-a2a1-8f2f2d9b17c4",
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	"00000000-0000-0000-0000-000000000000",
	23,
	1,
	'row::eliminate line: 23');
INSERT INTO ACT_RET
	VALUES ("208ddc80-c894-4ad8-a2a1-8f2f2d9b17c4",
	"27ba857d-6666-4b38-b948-1c3a499789fc");
INSERT INTO V_VAL
	VALUES ("d88acc60-f03c-4211-9baa-727f83143223",
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7fb322cc-e52f-4068-b546-e657eb637ed3");
INSERT INTO V_TVL
	VALUES ("d88acc60-f03c-4211-9baa-727f83143223",
	"cca0d66f-50e4-4e78-97b8-8a3b8e5a081b");
INSERT INTO V_VAL
	VALUES ("5b6d0291-96f7-45ec-b7dc-66104224bfad",
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7fb322cc-e52f-4068-b546-e657eb637ed3");
INSERT INTO V_LIN
	VALUES ("5b6d0291-96f7-45ec-b7dc-66104224bfad",
	'0');
INSERT INTO V_VAL
	VALUES ("12ca5ad2-895f-4e47-b17b-3e8733cb20da",
	0,
	0,
	4,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"7fb322cc-e52f-4068-b546-e657eb637ed3");
INSERT INTO V_IRF
	VALUES ("12ca5ad2-895f-4e47-b17b-3e8733cb20da",
	"28f35318-65fd-438d-ad19-bc01162326de");
INSERT INTO V_VAL
	VALUES ("39ed6df4-b1ee-4bc3-90ec-5d03517ca48d",
	1,
	1,
	5,
	1,
	1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7fb322cc-e52f-4068-b546-e657eb637ed3");
INSERT INTO V_TVL
	VALUES ("39ed6df4-b1ee-4bc3-90ec-5d03517ca48d",
	"067de1b9-a57a-4721-9074-a18b9826136a");
INSERT INTO V_VAL
	VALUES ("99466ef7-3b2e-4435-9dcc-5056f1c8154f",
	0,
	0,
	5,
	17,
	25,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"7fb322cc-e52f-4068-b546-e657eb637ed3");
INSERT INTO V_ISR
	VALUES ("99466ef7-3b2e-4435-9dcc-5056f1c8154f",
	"e28d6292-5442-4976-8614-39ab39b2ca2b");
INSERT INTO V_VAL
	VALUES ("8f7e2aed-755b-4119-a641-edee9938de09",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7fb322cc-e52f-4068-b546-e657eb637ed3");
INSERT INTO V_UNY
	VALUES ("8f7e2aed-755b-4119-a641-edee9938de09",
	"99466ef7-3b2e-4435-9dcc-5056f1c8154f",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("dac73b20-f431-459b-adb8-1945b162212c",
	0,
	0,
	6,
	6,
	6,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7fb322cc-e52f-4068-b546-e657eb637ed3");
INSERT INTO V_LIN
	VALUES ("dac73b20-f431-459b-adb8-1945b162212c",
	'9');
INSERT INTO V_VAL
	VALUES ("c1a2ef03-05ef-42c8-aa78-6b2136b55368",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"7fb322cc-e52f-4068-b546-e657eb637ed3");
INSERT INTO V_BIN
	VALUES ("c1a2ef03-05ef-42c8-aa78-6b2136b55368",
	"6d39ec46-cf88-4ad1-adc4-a8a142242051",
	"dac73b20-f431-459b-adb8-1945b162212c",
	'==');
INSERT INTO V_VAL
	VALUES ("6d39ec46-cf88-4ad1-adc4-a8a142242051",
	0,
	0,
	6,
	11,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7fb322cc-e52f-4068-b546-e657eb637ed3");
INSERT INTO V_TVL
	VALUES ("6d39ec46-cf88-4ad1-adc4-a8a142242051",
	"067de1b9-a57a-4721-9074-a18b9826136a");
INSERT INTO V_VAL
	VALUES ("27ba857d-6666-4b38-b948-1c3a499789fc",
	0,
	0,
	23,
	8,
	18,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"7fb322cc-e52f-4068-b546-e657eb637ed3");
INSERT INTO V_TVL
	VALUES ("27ba857d-6666-4b38-b948-1c3a499789fc",
	"cca0d66f-50e4-4e78-97b8-8a3b8e5a081b");
INSERT INTO V_VAR
	VALUES ("cca0d66f-50e4-4e78-97b8-8a3b8e5a081b",
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	'temperature',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("cca0d66f-50e4-4e78-97b8-8a3b8e5a081b",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("7629d357-83e3-4d02-bde2-8fb3f90f20c6",
	3,
	1,
	11,
	"cca0d66f-50e4-4e78-97b8-8a3b8e5a081b");
INSERT INTO V_LOC
	VALUES ("bc34bd39-d7f4-42a6-b1ee-70f589963c1b",
	7,
	3,
	13,
	"cca0d66f-50e4-4e78-97b8-8a3b8e5a081b");
INSERT INTO V_LOC
	VALUES ("61fb8fc1-f375-43ca-b29a-252c99cdac24",
	18,
	5,
	15,
	"cca0d66f-50e4-4e78-97b8-8a3b8e5a081b");
INSERT INTO V_LOC
	VALUES ("0f8159f5-32e0-4533-ba5d-d6e87b192291",
	23,
	8,
	18,
	"cca0d66f-50e4-4e78-97b8-8a3b8e5a081b");
INSERT INTO V_VAR
	VALUES ("e28d6292-5442-4976-8614-39ab39b2ca2b",
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	'eligibles',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("e28d6292-5442-4976-8614-39ab39b2ca2b",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("29dc6857-1493-4f74-86df-6f286421bff7",
	4,
	13,
	21,
	"e28d6292-5442-4976-8614-39ab39b2ca2b");
INSERT INTO V_LOC
	VALUES ("f0904203-feb5-49ae-991a-19ca9c6db62d",
	9,
	22,
	30,
	"e28d6292-5442-4976-8614-39ab39b2ca2b");
INSERT INTO V_VAR
	VALUES ("28f35318-65fd-438d-ad19-bc01162326de",
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("28f35318-65fd-438d-ad19-bc01162326de",
	0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_VAR
	VALUES ("067de1b9-a57a-4721-9074-a18b9826136a",
	"7fb322cc-e52f-4068-b546-e657eb637ed3",
	'c',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("067de1b9-a57a-4721-9074-a18b9826136a",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("6d26c5d0-07a8-4a7d-9d12-d5722d22adac",
	5,
	1,
	1,
	"067de1b9-a57a-4721-9074-a18b9826136a");
INSERT INTO V_LOC
	VALUES ("fcb49a4e-6993-479c-a191-0537f2dde8b6",
	6,
	11,
	11,
	"067de1b9-a57a-4721-9074-a18b9826136a");
INSERT INTO V_LOC
	VALUES ("8fa671d3-3673-4f9b-bbd7-3c8911ab1af0",
	12,
	3,
	3,
	"067de1b9-a57a-4721-9074-a18b9826136a");
INSERT INTO V_LOC
	VALUES ("d281fc30-c04a-4d07-b5d7-680c67036e0d",
	13,
	13,
	13,
	"067de1b9-a57a-4721-9074-a18b9826136a");
INSERT INTO ACT_BLK
	VALUES ("1848015b-0782-45ed-9231-0c83e88ddc34",
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f63df916-1e70-4a97-bbfc-42682bdba8cc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5635aa46-89b0-4972-8fc6-72bfa1c541cc",
	"1848015b-0782-45ed-9231-0c83e88ddc34",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'row::eliminate line: 7');
INSERT INTO ACT_AI
	VALUES ("5635aa46-89b0-4972-8fc6-72bfa1c541cc",
	"4b366ca2-21b7-4586-9a85-7faec2f98528",
	"68bfdd50-6da6-437c-a216-20d9d5e3ff08",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("68bfdd50-6da6-437c-a216-20d9d5e3ff08",
	1,
	0,
	7,
	3,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1848015b-0782-45ed-9231-0c83e88ddc34");
INSERT INTO V_TVL
	VALUES ("68bfdd50-6da6-437c-a216-20d9d5e3ff08",
	"cca0d66f-50e4-4e78-97b8-8a3b8e5a081b");
INSERT INTO V_VAL
	VALUES ("4b366ca2-21b7-4586-9a85-7faec2f98528",
	0,
	0,
	7,
	17,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"1848015b-0782-45ed-9231-0c83e88ddc34");
INSERT INTO V_LIN
	VALUES ("4b366ca2-21b7-4586-9a85-7faec2f98528",
	'100');
INSERT INTO ACT_BLK
	VALUES ("14da00f7-485f-4d18-9b7d-e20dfaf5f4d1",
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f63df916-1e70-4a97-bbfc-42682bdba8cc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("232089ed-4632-4b4e-98b8-ff6b9aa83496",
	"14da00f7-485f-4d18-9b7d-e20dfaf5f4d1",
	"00000000-0000-0000-0000-000000000000",
	9,
	1,
	'row::eliminate line: 9');
INSERT INTO ACT_FOR
	VALUES ("232089ed-4632-4b4e-98b8-ff6b9aa83496",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e",
	1,
	"7244d6c4-f523-4328-afe0-a743db5d6652",
	"e28d6292-5442-4976-8614-39ab39b2ca2b",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_VAR
	VALUES ("7244d6c4-f523-4328-afe0-a743db5d6652",
	"14da00f7-485f-4d18-9b7d-e20dfaf5f4d1",
	'eligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("7244d6c4-f523-4328-afe0-a743db5d6652",
	1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("442a3cf5-1c69-4a26-b4db-b11277176052",
	9,
	10,
	17,
	"7244d6c4-f523-4328-afe0-a743db5d6652");
INSERT INTO V_LOC
	VALUES ("371e0557-e940-4013-b3b1-ec3db1c35b7c",
	11,
	37,
	44,
	"7244d6c4-f523-4328-afe0-a743db5d6652");
INSERT INTO V_LOC
	VALUES ("fb04863a-218e-4c79-b99b-40d1f2984816",
	16,
	31,
	38,
	"7244d6c4-f523-4328-afe0-a743db5d6652");
INSERT INTO ACT_BLK
	VALUES ("bb63d9a4-9381-460e-8af6-fb9b5558695e",
	1,
	0,
	1,
	'',
	'',
	'',
	13,
	3,
	10,
	49,
	0,
	0,
	10,
	58,
	0,
	0,
	0,
	0,
	0,
	"f63df916-1e70-4a97-bbfc-42682bdba8cc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("96de4363-9ce8-4c04-a854-87371cbba6a1",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e",
	"172b5dd3-a976-402d-904c-7070bdc258ef",
	10,
	3,
	'row::eliminate line: 10');
INSERT INTO ACT_SEL
	VALUES ("96de4363-9ce8-4c04-a854-87371cbba6a1",
	"5e8addea-e14c-496c-85ae-0534cf918e69",
	1,
	'many',
	"6c86e414-506b-4745-ad56-00aea7ff7457");
INSERT INTO ACT_SRW
	VALUES ("96de4363-9ce8-4c04-a854-87371cbba6a1",
	"dd8300a9-cec5-4620-9891-0cb9ff893a69");
INSERT INTO ACT_LNK
	VALUES ("d46ef6ae-198d-4e58-ac41-6a7fb58c8ae9",
	'',
	"96de4363-9ce8-4c04-a854-87371cbba6a1",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"7781365e-7a8d-46ac-ab2c-45595d61a780",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	10,
	39,
	10,
	44,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("7781365e-7a8d-46ac-ab2c-45595d61a780",
	'',
	"00000000-0000-0000-0000-000000000000",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	10,
	49,
	10,
	58,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("172b5dd3-a976-402d-904c-7070bdc258ef",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e",
	"64c35c15-d887-4a67-af6e-8005169f91a7",
	12,
	3,
	'row::eliminate line: 12');
INSERT INTO ACT_AI
	VALUES ("172b5dd3-a976-402d-904c-7070bdc258ef",
	"7b0660e6-519d-4289-9616-b1333363074d",
	"6f6bd526-67cd-45fa-8ef4-3b9662ce1d58",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("64c35c15-d887-4a67-af6e-8005169f91a7",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e",
	"00000000-0000-0000-0000-000000000000",
	13,
	3,
	'row::eliminate line: 13');
INSERT INTO ACT_IF
	VALUES ("64c35c15-d887-4a67-af6e-8005169f91a7",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b",
	"0ecb2cd0-a3fd-4b2f-aca3-ebb7eb18e1fd",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("6c86e414-506b-4745-ad56-00aea7ff7457",
	0,
	0,
	10,
	33,
	36,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_IRF
	VALUES ("6c86e414-506b-4745-ad56-00aea7ff7457",
	"28f35318-65fd-438d-ad19-bc01162326de");
INSERT INTO V_VAL
	VALUES ("5ae72b8f-72f1-4bd6-87df-fdba48d2d180",
	0,
	0,
	11,
	13,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_SLR
	VALUES ("5ae72b8f-72f1-4bd6-87df-fdba48d2d180",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("40a3afa8-d1ff-49d4-a47e-4d6e11466b8c",
	0,
	0,
	11,
	22,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_AVL
	VALUES ("40a3afa8-d1ff-49d4-a47e-4d6e11466b8c",
	"5ae72b8f-72f1-4bd6-87df-fdba48d2d180",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("dd8300a9-cec5-4620-9891-0cb9ff893a69",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_BIN
	VALUES ("dd8300a9-cec5-4620-9891-0cb9ff893a69",
	"cca2c7d9-ac75-4483-b631-038e025f28f2",
	"40a3afa8-d1ff-49d4-a47e-4d6e11466b8c",
	'==');
INSERT INTO V_VAL
	VALUES ("7f0bec2b-da69-4c7b-ba2a-565816d85d8a",
	0,
	0,
	11,
	37,
	44,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_IRF
	VALUES ("7f0bec2b-da69-4c7b-ba2a-565816d85d8a",
	"7244d6c4-f523-4328-afe0-a743db5d6652");
INSERT INTO V_VAL
	VALUES ("cca2c7d9-ac75-4483-b631-038e025f28f2",
	0,
	0,
	11,
	46,
	56,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_AVL
	VALUES ("cca2c7d9-ac75-4483-b631-038e025f28f2",
	"7f0bec2b-da69-4c7b-ba2a-565816d85d8a",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("6f6bd526-67cd-45fa-8ef4-3b9662ce1d58",
	1,
	0,
	12,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_TVL
	VALUES ("6f6bd526-67cd-45fa-8ef4-3b9662ce1d58",
	"067de1b9-a57a-4721-9074-a18b9826136a");
INSERT INTO V_VAL
	VALUES ("6a1fbe3d-cdda-42d1-883f-fbfc4ec7f193",
	0,
	0,
	12,
	19,
	24,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_ISR
	VALUES ("6a1fbe3d-cdda-42d1-883f-fbfc4ec7f193",
	"5e8addea-e14c-496c-85ae-0534cf918e69");
INSERT INTO V_VAL
	VALUES ("7b0660e6-519d-4289-9616-b1333363074d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_UNY
	VALUES ("7b0660e6-519d-4289-9616-b1333363074d",
	"6a1fbe3d-cdda-42d1-883f-fbfc4ec7f193",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("ca9ea8d8-24d2-4d34-a7e1-fb2383f9d712",
	0,
	0,
	13,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_LIN
	VALUES ("ca9ea8d8-24d2-4d34-a7e1-fb2383f9d712",
	'1');
INSERT INTO V_VAL
	VALUES ("0ecb2cd0-a3fd-4b2f-aca3-ebb7eb18e1fd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_BIN
	VALUES ("0ecb2cd0-a3fd-4b2f-aca3-ebb7eb18e1fd",
	"b3e1523f-51af-4da0-8c4b-6e7ba3bbba25",
	"ca9ea8d8-24d2-4d34-a7e1-fb2383f9d712",
	'==');
INSERT INTO V_VAL
	VALUES ("b3e1523f-51af-4da0-8c4b-6e7ba3bbba25",
	0,
	0,
	13,
	13,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e");
INSERT INTO V_TVL
	VALUES ("b3e1523f-51af-4da0-8c4b-6e7ba3bbba25",
	"067de1b9-a57a-4721-9074-a18b9826136a");
INSERT INTO V_VAR
	VALUES ("5e8addea-e14c-496c-85ae-0534cf918e69",
	"bb63d9a4-9381-460e-8af6-fb9b5558695e",
	'loners',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("5e8addea-e14c-496c-85ae-0534cf918e69",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("10bfce11-ce63-4c48-b7f1-271970bc7be0",
	10,
	15,
	20,
	"5e8addea-e14c-496c-85ae-0534cf918e69");
INSERT INTO ACT_BLK
	VALUES ("934eb67f-c1d6-49d3-99e5-07bda002eb8b",
	1,
	0,
	0,
	'',
	'',
	'',
	19,
	5,
	15,
	42,
	0,
	0,
	15,
	47,
	0,
	0,
	0,
	0,
	0,
	"f63df916-1e70-4a97-bbfc-42682bdba8cc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("fa83e8ad-d291-4e59-96a1-3d1ed3d09c08",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b",
	"848245ed-de2e-4499-86cd-4b319b70b0fa",
	15,
	5,
	'row::eliminate line: 15');
INSERT INTO ACT_SEL
	VALUES ("fa83e8ad-d291-4e59-96a1-3d1ed3d09c08",
	"ea991420-e9fb-4c54-b2a5-17ca7314a2ce",
	1,
	'one',
	"f41002bb-5d23-4b99-89b2-a2bd7b41640f");
INSERT INTO ACT_SR
	VALUES ("fa83e8ad-d291-4e59-96a1-3d1ed3d09c08");
INSERT INTO ACT_LNK
	VALUES ("78ec919b-6bee-456e-aa06-9697134afa92",
	'',
	"fa83e8ad-d291-4e59-96a1-3d1ed3d09c08",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	15,
	42,
	15,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("848245ed-de2e-4499-86cd-4b319b70b0fa",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b",
	"92871f91-662f-4f50-b9bc-cccc562c46ca",
	16,
	5,
	'row::eliminate line: 16');
INSERT INTO ACT_TFM
	VALUES ("848245ed-de2e-4499-86cd-4b319b70b0fa",
	"a3632caa-a4af-4c7b-8e5d-212826ddcf99",
	"ea991420-e9fb-4c54-b2a5-17ca7314a2ce",
	16,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("92871f91-662f-4f50-b9bc-cccc562c46ca",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b",
	"4bf184f5-20f5-4391-9bf5-a9d35c9df7e4",
	18,
	5,
	'row::eliminate line: 18');
INSERT INTO ACT_AI
	VALUES ("92871f91-662f-4f50-b9bc-cccc562c46ca",
	"f8185e9d-d710-4960-845f-3c949149bd9b",
	"1c0bea2a-d770-4a55-a78c-f16094400cfa",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("4bf184f5-20f5-4391-9bf5-a9d35c9df7e4",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b",
	"00000000-0000-0000-0000-000000000000",
	19,
	5,
	'row::eliminate line: 19');
INSERT INTO ACT_BRK
	VALUES ("4bf184f5-20f5-4391-9bf5-a9d35c9df7e4");
INSERT INTO V_VAL
	VALUES ("f41002bb-5d23-4b99-89b2-a2bd7b41640f",
	0,
	0,
	15,
	32,
	39,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b");
INSERT INTO V_IRF
	VALUES ("f41002bb-5d23-4b99-89b2-a2bd7b41640f",
	"7244d6c4-f523-4328-afe0-a743db5d6652");
INSERT INTO V_VAL
	VALUES ("72c8e870-0f25-4478-8edf-c3c434082511",
	0,
	0,
	16,
	31,
	38,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b");
INSERT INTO V_IRF
	VALUES ("72c8e870-0f25-4478-8edf-c3c434082511",
	"7244d6c4-f523-4328-afe0-a743db5d6652");
INSERT INTO V_VAL
	VALUES ("4833907a-7863-41d5-a9be-175960f6990e",
	0,
	0,
	16,
	40,
	50,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b");
INSERT INTO V_AVL
	VALUES ("4833907a-7863-41d5-a9be-175960f6990e",
	"72c8e870-0f25-4478-8edf-c3c434082511",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_PAR
	VALUES ("4833907a-7863-41d5-a9be-175960f6990e",
	"848245ed-de2e-4499-86cd-4b319b70b0fa",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	16,
	18);
INSERT INTO V_VAL
	VALUES ("1c0bea2a-d770-4a55-a78c-f16094400cfa",
	1,
	0,
	18,
	5,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b");
INSERT INTO V_TVL
	VALUES ("1c0bea2a-d770-4a55-a78c-f16094400cfa",
	"cca0d66f-50e4-4e78-97b8-8a3b8e5a081b");
INSERT INTO V_VAL
	VALUES ("f8185e9d-d710-4960-845f-3c949149bd9b",
	0,
	0,
	18,
	19,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b");
INSERT INTO V_LIN
	VALUES ("f8185e9d-d710-4960-845f-3c949149bd9b",
	'1');
INSERT INTO V_VAR
	VALUES ("ea991420-e9fb-4c54-b2a5-17ca7314a2ce",
	"934eb67f-c1d6-49d3-99e5-07bda002eb8b",
	'cell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("ea991420-e9fb-4c54-b2a5-17ca7314a2ce",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("a079b868-14d3-45de-8060-6b72d0309c61",
	15,
	16,
	19,
	"ea991420-e9fb-4c54-b2a5-17ca7314a2ce");
INSERT INTO V_LOC
	VALUES ("ad8b24be-a542-44f7-9bd0-12ea4a3a89c9",
	16,
	5,
	8,
	"ea991420-e9fb-4c54-b2a5-17ca7314a2ce");
INSERT INTO O_TFR
	VALUES ("450e3398-ff08-488c-94ba-b761702968e3",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	'prune',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	1,
	'// Eliminate eligible digits that match any answer digit for this sequence.

temperature = 0;
select many answerdigits related by self->CELL[R2]->DIGIT[R9] where ( selected.value != 0 );
select many eligibles related by self->CELL[R2]->ELIGIBLE[R8];
for each eligible in eligibles
  for each answerdigit in answerdigits
    if ( eligible.digit_value == answerdigit.value )
      select one opencell related by eligible->CELL[R8];
      if ( opencell.answer_value != eligible.digit_value )
        unrelate answerdigit from opencell across R8 using eligible;
        delete object instance eligible;
        //generate CELL1:eliminate( digit:answerdigit.value ) to opencell;
      end if;
      temperature = 1;
      break;
    end if;
  end for;
end for;
  
select many opencells related by self->CELL[R2]
  where ( selected.answer_value == 0 );
if ( empty opencells )
  temperature = 100;
end if;
for each opencell in opencells
  // Notice if we have the answer now.
  select many eligibles related by opencell->ELIGIBLE[R8];
  c = cardinality eligibles;
  if ( 1 == c )
    select any answer related by opencell->ELIGIBLE[R8];
    opencell.answer( answer_digit:answer.digit_value );
    //generate CELL2:answer( digit:answer.digit_value ) to opencell;
    temperature = 1;
  end if;
end for;

return temperature;
',
	1,
	'',
	"a96f5d87-216f-4cae-a278-9bd89e071d22");
INSERT INTO ACT_OPB
	VALUES ("e124ae58-6951-479a-908b-69ca80a29cfc",
	"450e3398-ff08-488c-94ba-b761702968e3");
INSERT INTO ACT_ACT
	VALUES ("e124ae58-6951-479a-908b-69ca80a29cfc",
	'operation',
	0,
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	"00000000-0000-0000-0000-000000000000",
	0,
	'row::prune',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	1,
	0,
	1,
	'',
	'',
	'',
	38,
	1,
	21,
	40,
	0,
	0,
	21,
	45,
	0,
	0,
	0,
	0,
	0,
	"e124ae58-6951-479a-908b-69ca80a29cfc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ce6afa2f-8c27-409d-840b-bc23ded38f03",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	"4cd5d7a5-1597-415d-8c37-0591db743277",
	3,
	1,
	'row::prune line: 3');
INSERT INTO ACT_AI
	VALUES ("ce6afa2f-8c27-409d-840b-bc23ded38f03",
	"d189cc79-a40f-46db-a999-4c9109637466",
	"1ac7fe40-f103-412b-a5c0-d6a08d667c5f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("4cd5d7a5-1597-415d-8c37-0591db743277",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	"950a86b5-4bcf-44b8-9901-302db600466c",
	4,
	1,
	'row::prune line: 4');
INSERT INTO ACT_SEL
	VALUES ("4cd5d7a5-1597-415d-8c37-0591db743277",
	"8856a3ca-5542-4020-bc03-b88dd4f0a0a7",
	1,
	'many',
	"e3824da7-8053-4689-83ca-47fa9791809d");
INSERT INTO ACT_SRW
	VALUES ("4cd5d7a5-1597-415d-8c37-0591db743277",
	"d15ece97-ce83-46e7-8987-a3376bb5e235");
INSERT INTO ACT_LNK
	VALUES ("e9c23455-736d-48aa-b97e-1d9bda201c8d",
	'',
	"4cd5d7a5-1597-415d-8c37-0591db743277",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"9c2c69da-df8b-4e30-b0a2-8161d7c29b3d",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	4,
	43,
	4,
	48,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("9c2c69da-df8b-4e30-b0a2-8161d7c29b3d",
	'',
	"00000000-0000-0000-0000-000000000000",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"00000000-0000-0000-0000-000000000000",
	2,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	4,
	53,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("950a86b5-4bcf-44b8-9901-302db600466c",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	"fa6a0063-4d98-4b6f-96c1-f3f0fb6b78a5",
	5,
	1,
	'row::prune line: 5');
INSERT INTO ACT_SEL
	VALUES ("950a86b5-4bcf-44b8-9901-302db600466c",
	"0c876383-6e63-4555-8d4c-8c1f9f50b05b",
	1,
	'many',
	"da0a6d02-e211-4be0-9a9a-afebe1d3a57b");
INSERT INTO ACT_SR
	VALUES ("950a86b5-4bcf-44b8-9901-302db600466c");
INSERT INTO ACT_LNK
	VALUES ("4c23be79-3f13-46bf-b877-bc129f83407c",
	'',
	"950a86b5-4bcf-44b8-9901-302db600466c",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"96dbcee4-c0db-4311-a5cc-3d86987534e6",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("96dbcee4-c0db-4311-a5cc-3d86987534e6",
	'',
	"00000000-0000-0000-0000-000000000000",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("fa6a0063-4d98-4b6f-96c1-f3f0fb6b78a5",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	"78308e60-bc62-4700-804e-c2c3324c5ad3",
	6,
	1,
	'row::prune line: 6');
INSERT INTO ACT_FOR
	VALUES ("fa6a0063-4d98-4b6f-96c1-f3f0fb6b78a5",
	"97614f3e-8d72-42f9-9c07-d7524dca3a47",
	1,
	"41baba6f-ae58-41d6-affd-81b649dcd6e4",
	"0c876383-6e63-4555-8d4c-8c1f9f50b05b",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO ACT_SMT
	VALUES ("78308e60-bc62-4700-804e-c2c3324c5ad3",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	"25bd703a-0ee2-4d5f-b70e-b4a92c3eb91a",
	21,
	1,
	'row::prune line: 21');
INSERT INTO ACT_SEL
	VALUES ("78308e60-bc62-4700-804e-c2c3324c5ad3",
	"20dc4945-c78e-4d4b-8639-3fc52815bd97",
	1,
	'many',
	"4c27dafa-6c3b-40da-8c42-f2b4da2b5e8c");
INSERT INTO ACT_SRW
	VALUES ("78308e60-bc62-4700-804e-c2c3324c5ad3",
	"278fb5fe-0d75-4604-a1ec-8da4653123bd");
INSERT INTO ACT_LNK
	VALUES ("291269b7-bed1-4719-b5f8-28a8e7dd426f",
	'',
	"78308e60-bc62-4700-804e-c2c3324c5ad3",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"00000000-0000-0000-0000-000000000000",
	3,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	21,
	40,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("25bd703a-0ee2-4d5f-b70e-b4a92c3eb91a",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	"dce8bbcf-1566-4e7e-9b09-db3da7975b0f",
	23,
	1,
	'row::prune line: 23');
INSERT INTO ACT_IF
	VALUES ("25bd703a-0ee2-4d5f-b70e-b4a92c3eb91a",
	"c95f47c8-1023-450a-9ac5-b1a8eb8c1f63",
	"93ec88ee-3371-4d3e-95f9-bf4daaeb875e",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("dce8bbcf-1566-4e7e-9b09-db3da7975b0f",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	"d93c0022-4659-4cef-ac5e-ea36512c085f",
	26,
	1,
	'row::prune line: 26');
INSERT INTO ACT_FOR
	VALUES ("dce8bbcf-1566-4e7e-9b09-db3da7975b0f",
	"4c3df01e-528e-4506-8fe4-e04f85778676",
	1,
	"2c079ca8-812e-45b5-b790-560c18c54359",
	"20dc4945-c78e-4d4b-8639-3fc52815bd97",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO ACT_SMT
	VALUES ("d93c0022-4659-4cef-ac5e-ea36512c085f",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	"00000000-0000-0000-0000-000000000000",
	38,
	1,
	'row::prune line: 38');
INSERT INTO ACT_RET
	VALUES ("d93c0022-4659-4cef-ac5e-ea36512c085f",
	"33213437-a430-4026-8db5-719a8647ed24");
INSERT INTO V_VAL
	VALUES ("1ac7fe40-f103-412b-a5c0-d6a08d667c5f",
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_TVL
	VALUES ("1ac7fe40-f103-412b-a5c0-d6a08d667c5f",
	"a28286d3-f82a-4aae-a531-83df10381d19");
INSERT INTO V_VAL
	VALUES ("d189cc79-a40f-46db-a999-4c9109637466",
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_LIN
	VALUES ("d189cc79-a40f-46db-a999-4c9109637466",
	'0');
INSERT INTO V_VAL
	VALUES ("e3824da7-8053-4689-83ca-47fa9791809d",
	0,
	0,
	4,
	37,
	40,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_IRF
	VALUES ("e3824da7-8053-4689-83ca-47fa9791809d",
	"0833c25c-0e2a-4b50-acbf-942f397c1def");
INSERT INTO V_VAL
	VALUES ("0f389dc6-79cc-4049-bf12-f9837dcc2d9d",
	0,
	0,
	4,
	71,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_SLR
	VALUES ("0f389dc6-79cc-4049-bf12-f9837dcc2d9d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("ab6fbfc9-b9e2-4994-b3dd-646b731ad964",
	0,
	0,
	4,
	80,
	84,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_AVL
	VALUES ("ab6fbfc9-b9e2-4994-b3dd-646b731ad964",
	"0f389dc6-79cc-4049-bf12-f9837dcc2d9d",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO V_VAL
	VALUES ("d15ece97-ce83-46e7-8987-a3376bb5e235",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_BIN
	VALUES ("d15ece97-ce83-46e7-8987-a3376bb5e235",
	"0e5bc492-64fc-40bb-84c3-a1eac788b68a",
	"ab6fbfc9-b9e2-4994-b3dd-646b731ad964",
	'!=');
INSERT INTO V_VAL
	VALUES ("0e5bc492-64fc-40bb-84c3-a1eac788b68a",
	0,
	0,
	4,
	89,
	89,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_LIN
	VALUES ("0e5bc492-64fc-40bb-84c3-a1eac788b68a",
	'0');
INSERT INTO V_VAL
	VALUES ("da0a6d02-e211-4be0-9a9a-afebe1d3a57b",
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_IRF
	VALUES ("da0a6d02-e211-4be0-9a9a-afebe1d3a57b",
	"0833c25c-0e2a-4b50-acbf-942f397c1def");
INSERT INTO V_VAL
	VALUES ("4c27dafa-6c3b-40da-8c42-f2b4da2b5e8c",
	0,
	0,
	21,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_IRF
	VALUES ("4c27dafa-6c3b-40da-8c42-f2b4da2b5e8c",
	"0833c25c-0e2a-4b50-acbf-942f397c1def");
INSERT INTO V_VAL
	VALUES ("20d9e241-71fe-4bc8-94f5-1db1bbe7340e",
	0,
	0,
	22,
	11,
	-1,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_SLR
	VALUES ("20d9e241-71fe-4bc8-94f5-1db1bbe7340e",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("8b9b3c38-3f60-4d6a-ba92-73c0e2c454d1",
	0,
	0,
	22,
	20,
	31,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_AVL
	VALUES ("8b9b3c38-3f60-4d6a-ba92-73c0e2c454d1",
	"20d9e241-71fe-4bc8-94f5-1db1bbe7340e",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"009f5557-7ee7-4e44-9444-4d92eb448359");
INSERT INTO V_VAL
	VALUES ("278fb5fe-0d75-4604-a1ec-8da4653123bd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_BIN
	VALUES ("278fb5fe-0d75-4604-a1ec-8da4653123bd",
	"fb25e907-86d7-400a-b3b7-91c3762d6fe5",
	"8b9b3c38-3f60-4d6a-ba92-73c0e2c454d1",
	'==');
INSERT INTO V_VAL
	VALUES ("fb25e907-86d7-400a-b3b7-91c3762d6fe5",
	0,
	0,
	22,
	36,
	36,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_LIN
	VALUES ("fb25e907-86d7-400a-b3b7-91c3762d6fe5",
	'0');
INSERT INTO V_VAL
	VALUES ("34692c34-be54-4899-9bd8-24d151ac38ea",
	0,
	0,
	23,
	12,
	20,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_ISR
	VALUES ("34692c34-be54-4899-9bd8-24d151ac38ea",
	"20dc4945-c78e-4d4b-8639-3fc52815bd97");
INSERT INTO V_VAL
	VALUES ("93ec88ee-3371-4d3e-95f9-bf4daaeb875e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_UNY
	VALUES ("93ec88ee-3371-4d3e-95f9-bf4daaeb875e",
	"34692c34-be54-4899-9bd8-24d151ac38ea",
	'empty');
INSERT INTO V_VAL
	VALUES ("33213437-a430-4026-8db5-719a8647ed24",
	0,
	0,
	38,
	8,
	18,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64");
INSERT INTO V_TVL
	VALUES ("33213437-a430-4026-8db5-719a8647ed24",
	"a28286d3-f82a-4aae-a531-83df10381d19");
INSERT INTO V_VAR
	VALUES ("a28286d3-f82a-4aae-a531-83df10381d19",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	'temperature',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("a28286d3-f82a-4aae-a531-83df10381d19",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("fa1f9290-cec1-4185-9e6d-4018f0d03827",
	3,
	1,
	11,
	"a28286d3-f82a-4aae-a531-83df10381d19");
INSERT INTO V_LOC
	VALUES ("f32e6863-3f42-42ab-98a8-50354382ebad",
	15,
	7,
	17,
	"a28286d3-f82a-4aae-a531-83df10381d19");
INSERT INTO V_LOC
	VALUES ("34595189-dc1a-4da7-9280-a49d1cb1aadf",
	24,
	3,
	13,
	"a28286d3-f82a-4aae-a531-83df10381d19");
INSERT INTO V_LOC
	VALUES ("21443feb-15c4-44b7-96f8-43042202408d",
	34,
	5,
	15,
	"a28286d3-f82a-4aae-a531-83df10381d19");
INSERT INTO V_LOC
	VALUES ("4b52c556-1e04-48fa-a53f-fd8a648982c2",
	38,
	8,
	18,
	"a28286d3-f82a-4aae-a531-83df10381d19");
INSERT INTO V_VAR
	VALUES ("8856a3ca-5542-4020-bc03-b88dd4f0a0a7",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	'answerdigits',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("8856a3ca-5542-4020-bc03-b88dd4f0a0a7",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("9909eac3-34e5-4491-acfe-89c4158c255f",
	4,
	13,
	24,
	"8856a3ca-5542-4020-bc03-b88dd4f0a0a7");
INSERT INTO V_LOC
	VALUES ("ccf01e19-f49c-48a1-a3a1-1c892d58625d",
	7,
	27,
	38,
	"8856a3ca-5542-4020-bc03-b88dd4f0a0a7");
INSERT INTO V_VAR
	VALUES ("0833c25c-0e2a-4b50-acbf-942f397c1def",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("0833c25c-0e2a-4b50-acbf-942f397c1def",
	0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_VAR
	VALUES ("0c876383-6e63-4555-8d4c-8c1f9f50b05b",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	'eligibles',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("0c876383-6e63-4555-8d4c-8c1f9f50b05b",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("54118107-588a-48be-8fa2-40e17e492d35",
	5,
	13,
	21,
	"0c876383-6e63-4555-8d4c-8c1f9f50b05b");
INSERT INTO V_LOC
	VALUES ("6a7ef3c3-d670-4a6c-a11a-3e0cb691ca12",
	6,
	22,
	30,
	"0c876383-6e63-4555-8d4c-8c1f9f50b05b");
INSERT INTO V_LOC
	VALUES ("28cb583b-3e63-4496-8eb9-8915f549888f",
	28,
	15,
	23,
	"0c876383-6e63-4555-8d4c-8c1f9f50b05b");
INSERT INTO V_VAR
	VALUES ("41baba6f-ae58-41d6-affd-81b649dcd6e4",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	'eligible',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("41baba6f-ae58-41d6-affd-81b649dcd6e4",
	1,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("196228a5-c591-449f-8f9f-0244fe0b4291",
	6,
	10,
	17,
	"41baba6f-ae58-41d6-affd-81b649dcd6e4");
INSERT INTO V_LOC
	VALUES ("473c391b-e253-465c-b3e0-a10a48894784",
	8,
	10,
	17,
	"41baba6f-ae58-41d6-affd-81b649dcd6e4");
INSERT INTO V_LOC
	VALUES ("b3c2d25b-b9c1-4bca-8a74-5e42b060703e",
	10,
	37,
	44,
	"41baba6f-ae58-41d6-affd-81b649dcd6e4");
INSERT INTO V_LOC
	VALUES ("48e85e83-81b4-4d8d-b2c2-962bd406edf9",
	11,
	60,
	67,
	"41baba6f-ae58-41d6-affd-81b649dcd6e4");
INSERT INTO V_LOC
	VALUES ("881f895c-11fe-44ed-8ffc-e474b97049fe",
	12,
	32,
	39,
	"41baba6f-ae58-41d6-affd-81b649dcd6e4");
INSERT INTO V_VAR
	VALUES ("20dc4945-c78e-4d4b-8639-3fc52815bd97",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	'opencells',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("20dc4945-c78e-4d4b-8639-3fc52815bd97",
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("2302d524-4900-4184-915d-7d2b76252a63",
	21,
	13,
	21,
	"20dc4945-c78e-4d4b-8639-3fc52815bd97");
INSERT INTO V_LOC
	VALUES ("2c8a0d42-c43f-4179-b26e-27d64a0596ba",
	26,
	22,
	30,
	"20dc4945-c78e-4d4b-8639-3fc52815bd97");
INSERT INTO V_VAR
	VALUES ("2c079ca8-812e-45b5-b790-560c18c54359",
	"a19de22e-34ab-4d69-bcb7-f3ee6d2bcc64",
	'opencell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("2c079ca8-812e-45b5-b790-560c18c54359",
	1,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("d109feae-2aa5-4588-918a-380229f9c593",
	26,
	10,
	17,
	"2c079ca8-812e-45b5-b790-560c18c54359");
INSERT INTO V_LOC
	VALUES ("bccc1e92-3586-4999-b0f7-28cce44cba31",
	32,
	5,
	12,
	"2c079ca8-812e-45b5-b790-560c18c54359");
INSERT INTO ACT_BLK
	VALUES ("97614f3e-8d72-42f9-9c07-d7524dca3a47",
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"e124ae58-6951-479a-908b-69ca80a29cfc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7c250625-6d44-44f7-a496-07dcf7d8bfef",
	"97614f3e-8d72-42f9-9c07-d7524dca3a47",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'row::prune line: 7');
INSERT INTO ACT_FOR
	VALUES ("7c250625-6d44-44f7-a496-07dcf7d8bfef",
	"d5990fa4-e892-407a-944c-10a6a57bbf31",
	1,
	"67ba930c-6afa-4388-8570-c122ee878444",
	"8856a3ca-5542-4020-bc03-b88dd4f0a0a7",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_VAR
	VALUES ("67ba930c-6afa-4388-8570-c122ee878444",
	"97614f3e-8d72-42f9-9c07-d7524dca3a47",
	'answerdigit',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("67ba930c-6afa-4388-8570-c122ee878444",
	1,
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756");
INSERT INTO V_LOC
	VALUES ("51c1b9a2-b6fc-4759-bd16-464581cb1484",
	7,
	12,
	22,
	"67ba930c-6afa-4388-8570-c122ee878444");
INSERT INTO V_LOC
	VALUES ("d04b0c6c-1ac1-470b-be30-8486fdd388d3",
	8,
	34,
	44,
	"67ba930c-6afa-4388-8570-c122ee878444");
INSERT INTO V_LOC
	VALUES ("15f7ce1c-cc55-4447-9dfe-7d8a556782b4",
	11,
	18,
	28,
	"67ba930c-6afa-4388-8570-c122ee878444");
INSERT INTO ACT_BLK
	VALUES ("d5990fa4-e892-407a-944c-10a6a57bbf31",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"e124ae58-6951-479a-908b-69ca80a29cfc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("a8d9259b-f397-4967-985f-3c98b7159d33",
	"d5990fa4-e892-407a-944c-10a6a57bbf31",
	"00000000-0000-0000-0000-000000000000",
	8,
	5,
	'row::prune line: 8');
INSERT INTO ACT_IF
	VALUES ("a8d9259b-f397-4967-985f-3c98b7159d33",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b",
	"bcb4d5fc-1bb2-4615-8856-7a6c3f8f72c1",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("02c75c3b-a206-4dad-ae57-69a3cc1aaf93",
	0,
	0,
	8,
	10,
	17,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"d5990fa4-e892-407a-944c-10a6a57bbf31");
INSERT INTO V_IRF
	VALUES ("02c75c3b-a206-4dad-ae57-69a3cc1aaf93",
	"41baba6f-ae58-41d6-affd-81b649dcd6e4");
INSERT INTO V_VAL
	VALUES ("e1761b27-cb08-4780-b135-0d6c0d773e9a",
	0,
	0,
	8,
	19,
	29,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d5990fa4-e892-407a-944c-10a6a57bbf31");
INSERT INTO V_AVL
	VALUES ("e1761b27-cb08-4780-b135-0d6c0d773e9a",
	"02c75c3b-a206-4dad-ae57-69a3cc1aaf93",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("bcb4d5fc-1bb2-4615-8856-7a6c3f8f72c1",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"d5990fa4-e892-407a-944c-10a6a57bbf31");
INSERT INTO V_BIN
	VALUES ("bcb4d5fc-1bb2-4615-8856-7a6c3f8f72c1",
	"c698c65a-dc23-4d4e-a57f-87f9d45f68fb",
	"e1761b27-cb08-4780-b135-0d6c0d773e9a",
	'==');
INSERT INTO V_VAL
	VALUES ("cb215729-93a2-4815-aa6f-86e6825bd97e",
	0,
	0,
	8,
	34,
	44,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"d5990fa4-e892-407a-944c-10a6a57bbf31");
INSERT INTO V_IRF
	VALUES ("cb215729-93a2-4815-aa6f-86e6825bd97e",
	"67ba930c-6afa-4388-8570-c122ee878444");
INSERT INTO V_VAL
	VALUES ("c698c65a-dc23-4d4e-a57f-87f9d45f68fb",
	0,
	0,
	8,
	46,
	50,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d5990fa4-e892-407a-944c-10a6a57bbf31");
INSERT INTO V_AVL
	VALUES ("c698c65a-dc23-4d4e-a57f-87f9d45f68fb",
	"cb215729-93a2-4815-aa6f-86e6825bd97e",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"53e80efe-cb6c-4332-b046-1ba6f6005b30");
INSERT INTO ACT_BLK
	VALUES ("692cb8d9-00d9-443a-ba91-b9c26e9e029b",
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	7,
	9,
	48,
	0,
	0,
	9,
	53,
	0,
	0,
	0,
	0,
	0,
	"e124ae58-6951-479a-908b-69ca80a29cfc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("17506b83-9070-4bd3-97bd-f3a260cd34e9",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b",
	"7073a7fe-26c1-4ea9-bea1-ad2cdff9b531",
	9,
	7,
	'row::prune line: 9');
INSERT INTO ACT_SEL
	VALUES ("17506b83-9070-4bd3-97bd-f3a260cd34e9",
	"3ea7fe71-36e2-43b3-b4e1-1be9b9f6fad9",
	1,
	'one',
	"fb55ad33-0874-4cbf-8ad7-882e7297b053");
INSERT INTO ACT_SR
	VALUES ("17506b83-9070-4bd3-97bd-f3a260cd34e9");
INSERT INTO ACT_LNK
	VALUES ("c9e5677a-325f-479f-bc7a-8277405cce87",
	'',
	"17506b83-9070-4bd3-97bd-f3a260cd34e9",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	2,
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	9,
	48,
	9,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7073a7fe-26c1-4ea9-bea1-ad2cdff9b531",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b",
	"9ce0a3c7-d32a-494d-8289-50496b36c2e9",
	10,
	7,
	'row::prune line: 10');
INSERT INTO ACT_IF
	VALUES ("7073a7fe-26c1-4ea9-bea1-ad2cdff9b531",
	"926c22a6-4517-4857-bdcc-38f3f6be5090",
	"e82ba2e0-f623-4fba-8c8c-e575b3dc257f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9ce0a3c7-d32a-494d-8289-50496b36c2e9",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b",
	"b07536d3-f24c-46d5-8bc2-ac1134519933",
	15,
	7,
	'row::prune line: 15');
INSERT INTO ACT_AI
	VALUES ("9ce0a3c7-d32a-494d-8289-50496b36c2e9",
	"c6eff11b-4bcb-45e3-9816-2334c2bfc76d",
	"b22aabce-8752-4e72-bdaa-23f9b75b2fee",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b07536d3-f24c-46d5-8bc2-ac1134519933",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	'row::prune line: 16');
INSERT INTO ACT_BRK
	VALUES ("b07536d3-f24c-46d5-8bc2-ac1134519933");
INSERT INTO V_VAL
	VALUES ("fb55ad33-0874-4cbf-8ad7-882e7297b053",
	0,
	0,
	9,
	38,
	45,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b");
INSERT INTO V_IRF
	VALUES ("fb55ad33-0874-4cbf-8ad7-882e7297b053",
	"41baba6f-ae58-41d6-affd-81b649dcd6e4");
INSERT INTO V_VAL
	VALUES ("216e633a-e85c-4c4e-93b7-675c38ba4d99",
	0,
	0,
	10,
	12,
	19,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b");
INSERT INTO V_IRF
	VALUES ("216e633a-e85c-4c4e-93b7-675c38ba4d99",
	"3ea7fe71-36e2-43b3-b4e1-1be9b9f6fad9");
INSERT INTO V_VAL
	VALUES ("3631beb9-7ab5-4b0a-96dc-5460c0719167",
	0,
	0,
	10,
	21,
	32,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b");
INSERT INTO V_AVL
	VALUES ("3631beb9-7ab5-4b0a-96dc-5460c0719167",
	"216e633a-e85c-4c4e-93b7-675c38ba4d99",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	"009f5557-7ee7-4e44-9444-4d92eb448359");
INSERT INTO V_VAL
	VALUES ("e82ba2e0-f623-4fba-8c8c-e575b3dc257f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b");
INSERT INTO V_BIN
	VALUES ("e82ba2e0-f623-4fba-8c8c-e575b3dc257f",
	"57dfb86d-cc58-4389-94f2-d94594470e97",
	"3631beb9-7ab5-4b0a-96dc-5460c0719167",
	'!=');
INSERT INTO V_VAL
	VALUES ("aa053071-17fd-480c-8304-472f474b64ec",
	0,
	0,
	10,
	37,
	44,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b");
INSERT INTO V_IRF
	VALUES ("aa053071-17fd-480c-8304-472f474b64ec",
	"41baba6f-ae58-41d6-affd-81b649dcd6e4");
INSERT INTO V_VAL
	VALUES ("57dfb86d-cc58-4389-94f2-d94594470e97",
	0,
	0,
	10,
	46,
	56,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b");
INSERT INTO V_AVL
	VALUES ("57dfb86d-cc58-4389-94f2-d94594470e97",
	"aa053071-17fd-480c-8304-472f474b64ec",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_VAL
	VALUES ("b22aabce-8752-4e72-bdaa-23f9b75b2fee",
	1,
	0,
	15,
	7,
	17,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b");
INSERT INTO V_TVL
	VALUES ("b22aabce-8752-4e72-bdaa-23f9b75b2fee",
	"a28286d3-f82a-4aae-a531-83df10381d19");
INSERT INTO V_VAL
	VALUES ("c6eff11b-4bcb-45e3-9816-2334c2bfc76d",
	0,
	0,
	15,
	21,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b");
INSERT INTO V_LIN
	VALUES ("c6eff11b-4bcb-45e3-9816-2334c2bfc76d",
	'1');
INSERT INTO V_VAR
	VALUES ("3ea7fe71-36e2-43b3-b4e1-1be9b9f6fad9",
	"692cb8d9-00d9-443a-ba91-b9c26e9e029b",
	'opencell',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("3ea7fe71-36e2-43b3-b4e1-1be9b9f6fad9",
	0,
	"e488047e-8d3e-455c-a7e9-29120bad505f");
INSERT INTO V_LOC
	VALUES ("b9015683-903e-41c0-9c58-c4bbbf2f36f7",
	9,
	18,
	25,
	"3ea7fe71-36e2-43b3-b4e1-1be9b9f6fad9");
INSERT INTO V_LOC
	VALUES ("199ac730-d990-41e1-b8af-f231f02c76b8",
	10,
	12,
	19,
	"3ea7fe71-36e2-43b3-b4e1-1be9b9f6fad9");
INSERT INTO V_LOC
	VALUES ("eba340e1-653a-4446-94a9-76bf7440be0a",
	11,
	35,
	42,
	"3ea7fe71-36e2-43b3-b4e1-1be9b9f6fad9");
INSERT INTO ACT_BLK
	VALUES ("926c22a6-4517-4857-bdcc-38f3f6be5090",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	9,
	0,
	0,
	0,
	0,
	11,
	51,
	0,
	0,
	0,
	0,
	0,
	"e124ae58-6951-479a-908b-69ca80a29cfc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("bb1ad2c2-d89a-42a7-a555-3849c8d24fde",
	"926c22a6-4517-4857-bdcc-38f3f6be5090",
	"a13d43fc-87d2-45b0-899f-2d8d1781779f",
	11,
	9,
	'row::prune line: 11');
INSERT INTO ACT_URU
	VALUES ("bb1ad2c2-d89a-42a7-a555-3849c8d24fde",
	"67ba930c-6afa-4388-8570-c122ee878444",
	"3ea7fe71-36e2-43b3-b4e1-1be9b9f6fad9",
	"41baba6f-ae58-41d6-affd-81b649dcd6e4",
	'',
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	11,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a13d43fc-87d2-45b0-899f-2d8d1781779f",
	"926c22a6-4517-4857-bdcc-38f3f6be5090",
	"00000000-0000-0000-0000-000000000000",
	12,
	9,
	'row::prune line: 12');
INSERT INTO ACT_DEL
	VALUES ("a13d43fc-87d2-45b0-899f-2d8d1781779f",
	"41baba6f-ae58-41d6-affd-81b649dcd6e4");
INSERT INTO ACT_BLK
	VALUES ("c95f47c8-1023-450a-9ac5-b1a8eb8c1f63",
	0,
	0,
	0,
	'',
	'',
	'',
	24,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"e124ae58-6951-479a-908b-69ca80a29cfc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0ba5a96b-0881-4042-9e30-a85b1d4ca0e5",
	"c95f47c8-1023-450a-9ac5-b1a8eb8c1f63",
	"00000000-0000-0000-0000-000000000000",
	24,
	3,
	'row::prune line: 24');
INSERT INTO ACT_AI
	VALUES ("0ba5a96b-0881-4042-9e30-a85b1d4ca0e5",
	"d0ec63f7-18db-4c78-a49f-fe4889becf02",
	"fd67f8fb-b87c-45eb-b1a4-68468d939089",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("fd67f8fb-b87c-45eb-b1a4-68468d939089",
	1,
	0,
	24,
	3,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c95f47c8-1023-450a-9ac5-b1a8eb8c1f63");
INSERT INTO V_TVL
	VALUES ("fd67f8fb-b87c-45eb-b1a4-68468d939089",
	"a28286d3-f82a-4aae-a531-83df10381d19");
INSERT INTO V_VAL
	VALUES ("d0ec63f7-18db-4c78-a49f-fe4889becf02",
	0,
	0,
	24,
	17,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"c95f47c8-1023-450a-9ac5-b1a8eb8c1f63");
INSERT INTO V_LIN
	VALUES ("d0ec63f7-18db-4c78-a49f-fe4889becf02",
	'100');
INSERT INTO ACT_BLK
	VALUES ("4c3df01e-528e-4506-8fe4-e04f85778676",
	1,
	0,
	0,
	'',
	'',
	'',
	30,
	3,
	28,
	46,
	0,
	0,
	28,
	55,
	0,
	0,
	0,
	0,
	0,
	"e124ae58-6951-479a-908b-69ca80a29cfc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("30cdada3-c1cc-4449-9ca2-0bc34cc0784b",
	"4c3df01e-528e-4506-8fe4-e04f85778676",
	"66bd5948-d2e7-40d3-8d9f-4881c123aa47",
	28,
	3,
	'row::prune line: 28');
INSERT INTO ACT_SEL
	VALUES ("30cdada3-c1cc-4449-9ca2-0bc34cc0784b",
	"0c876383-6e63-4555-8d4c-8c1f9f50b05b",
	0,
	'many',
	"1258cbec-7f70-4b01-8f3b-dd940908f1b3");
INSERT INTO ACT_SR
	VALUES ("30cdada3-c1cc-4449-9ca2-0bc34cc0784b");
INSERT INTO ACT_LNK
	VALUES ("e00b8b93-cdaf-4a81-ac28-9abc79bf7275",
	'',
	"30cdada3-c1cc-4449-9ca2-0bc34cc0784b",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	28,
	46,
	28,
	55,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("66bd5948-d2e7-40d3-8d9f-4881c123aa47",
	"4c3df01e-528e-4506-8fe4-e04f85778676",
	"cc1d0223-d657-40dc-8ca9-83152dccfd0b",
	29,
	3,
	'row::prune line: 29');
INSERT INTO ACT_AI
	VALUES ("66bd5948-d2e7-40d3-8d9f-4881c123aa47",
	"739f6989-b619-40ed-bd28-1dbfb5b19d7a",
	"05e0a073-6506-4ce9-9550-1acd636ffa83",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("cc1d0223-d657-40dc-8ca9-83152dccfd0b",
	"4c3df01e-528e-4506-8fe4-e04f85778676",
	"00000000-0000-0000-0000-000000000000",
	30,
	3,
	'row::prune line: 30');
INSERT INTO ACT_IF
	VALUES ("cc1d0223-d657-40dc-8ca9-83152dccfd0b",
	"f5c9fa5e-92be-484c-ae66-7f66010bc2b9",
	"6dc66d5f-dcdf-4bef-902f-b78bcb187c36",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("1258cbec-7f70-4b01-8f3b-dd940908f1b3",
	0,
	0,
	28,
	36,
	43,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"4c3df01e-528e-4506-8fe4-e04f85778676");
INSERT INTO V_IRF
	VALUES ("1258cbec-7f70-4b01-8f3b-dd940908f1b3",
	"2c079ca8-812e-45b5-b790-560c18c54359");
INSERT INTO V_VAL
	VALUES ("05e0a073-6506-4ce9-9550-1acd636ffa83",
	1,
	1,
	29,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4c3df01e-528e-4506-8fe4-e04f85778676");
INSERT INTO V_TVL
	VALUES ("05e0a073-6506-4ce9-9550-1acd636ffa83",
	"2816e214-4d23-4f35-8242-e92c83055a74");
INSERT INTO V_VAL
	VALUES ("94fbd294-fad4-470b-8fed-4f72f492c724",
	0,
	0,
	29,
	19,
	27,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"4c3df01e-528e-4506-8fe4-e04f85778676");
INSERT INTO V_ISR
	VALUES ("94fbd294-fad4-470b-8fed-4f72f492c724",
	"0c876383-6e63-4555-8d4c-8c1f9f50b05b");
INSERT INTO V_VAL
	VALUES ("739f6989-b619-40ed-bd28-1dbfb5b19d7a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4c3df01e-528e-4506-8fe4-e04f85778676");
INSERT INTO V_UNY
	VALUES ("739f6989-b619-40ed-bd28-1dbfb5b19d7a",
	"94fbd294-fad4-470b-8fed-4f72f492c724",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("11b56821-3f7c-4165-a61a-8d853910bc61",
	0,
	0,
	30,
	8,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4c3df01e-528e-4506-8fe4-e04f85778676");
INSERT INTO V_LIN
	VALUES ("11b56821-3f7c-4165-a61a-8d853910bc61",
	'1');
INSERT INTO V_VAL
	VALUES ("6dc66d5f-dcdf-4bef-902f-b78bcb187c36",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"4c3df01e-528e-4506-8fe4-e04f85778676");
INSERT INTO V_BIN
	VALUES ("6dc66d5f-dcdf-4bef-902f-b78bcb187c36",
	"c6fe04ae-6857-4323-9e8b-e4727e728599",
	"11b56821-3f7c-4165-a61a-8d853910bc61",
	'==');
INSERT INTO V_VAL
	VALUES ("c6fe04ae-6857-4323-9e8b-e4727e728599",
	0,
	0,
	30,
	13,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4c3df01e-528e-4506-8fe4-e04f85778676");
INSERT INTO V_TVL
	VALUES ("c6fe04ae-6857-4323-9e8b-e4727e728599",
	"2816e214-4d23-4f35-8242-e92c83055a74");
INSERT INTO V_VAR
	VALUES ("2816e214-4d23-4f35-8242-e92c83055a74",
	"4c3df01e-528e-4506-8fe4-e04f85778676",
	'c',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("2816e214-4d23-4f35-8242-e92c83055a74",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("c1fb418d-bce9-4eda-a6b3-85fa9707154d",
	29,
	3,
	3,
	"2816e214-4d23-4f35-8242-e92c83055a74");
INSERT INTO V_LOC
	VALUES ("e3cfdb8d-01ac-4663-b390-0ae0ac35f3bb",
	30,
	13,
	13,
	"2816e214-4d23-4f35-8242-e92c83055a74");
INSERT INTO ACT_BLK
	VALUES ("f5c9fa5e-92be-484c-ae66-7f66010bc2b9",
	1,
	0,
	0,
	'',
	'',
	'',
	34,
	5,
	31,
	44,
	0,
	0,
	31,
	53,
	0,
	0,
	0,
	0,
	0,
	"e124ae58-6951-479a-908b-69ca80a29cfc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9b3daca5-2d31-4abb-a758-918f667da312",
	"f5c9fa5e-92be-484c-ae66-7f66010bc2b9",
	"80189f3f-7929-4775-81eb-7827788b6eb2",
	31,
	5,
	'row::prune line: 31');
INSERT INTO ACT_SEL
	VALUES ("9b3daca5-2d31-4abb-a758-918f667da312",
	"3a740ce8-7ccd-4521-a108-5aa5e74bae13",
	1,
	'any',
	"133b4cac-e943-4590-8751-f257005cf69a");
INSERT INTO ACT_SR
	VALUES ("9b3daca5-2d31-4abb-a758-918f667da312");
INSERT INTO ACT_LNK
	VALUES ("bbe302f6-aa34-40ad-b8b1-54c856350ab3",
	'',
	"9b3daca5-2d31-4abb-a758-918f667da312",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"00000000-0000-0000-0000-000000000000",
	3,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	31,
	44,
	31,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("80189f3f-7929-4775-81eb-7827788b6eb2",
	"f5c9fa5e-92be-484c-ae66-7f66010bc2b9",
	"224d02f7-797c-446f-b2d4-c6327b9568a5",
	32,
	5,
	'row::prune line: 32');
INSERT INTO ACT_TFM
	VALUES ("80189f3f-7929-4775-81eb-7827788b6eb2",
	"a3632caa-a4af-4c7b-8e5d-212826ddcf99",
	"2c079ca8-812e-45b5-b790-560c18c54359",
	32,
	14,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("224d02f7-797c-446f-b2d4-c6327b9568a5",
	"f5c9fa5e-92be-484c-ae66-7f66010bc2b9",
	"00000000-0000-0000-0000-000000000000",
	34,
	5,
	'row::prune line: 34');
INSERT INTO ACT_AI
	VALUES ("224d02f7-797c-446f-b2d4-c6327b9568a5",
	"42e6027d-efd5-4fdd-9824-9458fd66e7b5",
	"afb728e2-7b5f-4e14-a130-3b58ab7110d9",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("133b4cac-e943-4590-8751-f257005cf69a",
	0,
	0,
	31,
	34,
	41,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"f5c9fa5e-92be-484c-ae66-7f66010bc2b9");
INSERT INTO V_IRF
	VALUES ("133b4cac-e943-4590-8751-f257005cf69a",
	"2c079ca8-812e-45b5-b790-560c18c54359");
INSERT INTO V_VAL
	VALUES ("1e565993-f5d9-4833-a113-020ff6cfa659",
	0,
	0,
	32,
	35,
	40,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"f5c9fa5e-92be-484c-ae66-7f66010bc2b9");
INSERT INTO V_IRF
	VALUES ("1e565993-f5d9-4833-a113-020ff6cfa659",
	"3a740ce8-7ccd-4521-a108-5aa5e74bae13");
INSERT INTO V_VAL
	VALUES ("537f5003-d51d-4c01-8580-3589b7544c78",
	0,
	0,
	32,
	42,
	52,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"f5c9fa5e-92be-484c-ae66-7f66010bc2b9");
INSERT INTO V_AVL
	VALUES ("537f5003-d51d-4c01-8580-3589b7544c78",
	"1e565993-f5d9-4833-a113-020ff6cfa659",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"a460f509-7c57-4f06-af25-d200aed49293");
INSERT INTO V_PAR
	VALUES ("537f5003-d51d-4c01-8580-3589b7544c78",
	"80189f3f-7929-4775-81eb-7827788b6eb2",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	32,
	22);
INSERT INTO V_VAL
	VALUES ("afb728e2-7b5f-4e14-a130-3b58ab7110d9",
	1,
	0,
	34,
	5,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"f5c9fa5e-92be-484c-ae66-7f66010bc2b9");
INSERT INTO V_TVL
	VALUES ("afb728e2-7b5f-4e14-a130-3b58ab7110d9",
	"a28286d3-f82a-4aae-a531-83df10381d19");
INSERT INTO V_VAL
	VALUES ("42e6027d-efd5-4fdd-9824-9458fd66e7b5",
	0,
	0,
	34,
	19,
	19,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"f5c9fa5e-92be-484c-ae66-7f66010bc2b9");
INSERT INTO V_LIN
	VALUES ("42e6027d-efd5-4fdd-9824-9458fd66e7b5",
	'1');
INSERT INTO V_VAR
	VALUES ("3a740ce8-7ccd-4521-a108-5aa5e74bae13",
	"f5c9fa5e-92be-484c-ae66-7f66010bc2b9",
	'answer',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("3a740ce8-7ccd-4521-a108-5aa5e74bae13",
	0,
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("2d63b0eb-ace0-49ac-b964-7bd823dd0c7f",
	31,
	16,
	21,
	"3a740ce8-7ccd-4521-a108-5aa5e74bae13");
INSERT INTO V_LOC
	VALUES ("027f9193-17af-406b-8e9b-54bdd138fe6e",
	32,
	35,
	40,
	"3a740ce8-7ccd-4521-a108-5aa5e74bae13");
INSERT INTO O_NBATTR
	VALUES ("b7c46385-7816-4616-9e73-922fad4f4af1",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO O_BATTR
	VALUES ("b7c46385-7816-4616-9e73-922fad4f4af1",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO O_ATTR
	VALUES ("b7c46385-7816-4616-9e73-922fad4f4af1",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	"00000000-0000-0000-0000-000000000000",
	'number',
	'',
	'',
	'number',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("eb4f6c86-c547-40bb-a017-7c927a098c1a",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO O_BATTR
	VALUES ("eb4f6c86-c547-40bb-a017-7c927a098c1a",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO O_ATTR
	VALUES ("eb4f6c86-c547-40bb-a017-7c927a098c1a",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	"b7c46385-7816-4616-9e73-922fad4f4af1",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"ea4f2014-da78-4798-8130-991e8750cff6",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO O_ID
	VALUES (1,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO O_OIDA
	VALUES ("b7c46385-7816-4616-9e73-922fad4f4af1",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	1);
INSERT INTO O_ID
	VALUES (2,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO SM_ISM
	VALUES ("07fc627f-b641-41fe-a1af-748fb116451e",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO SM_SM
	VALUES ("07fc627f-b641-41fe-a1af-748fb116451e",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("07fc627f-b641-41fe-a1af-748fb116451e");
INSERT INTO SM_LEVT
	VALUES ("3c0abb69-5aa0-487e-996b-7909858726cf",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("3c0abb69-5aa0-487e-996b-7909858726cf",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("3c0abb69-5aa0-487e-996b-7909858726cf",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000",
	1,
	'update',
	0,
	'',
	'ROW1',
	'');
INSERT INTO SM_LEVT
	VALUES ("e558b971-a37c-428c-abc4-46c4f386c9d4",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("e558b971-a37c-428c-abc4-46c4f386c9d4",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("e558b971-a37c-428c-abc4-46c4f386c9d4",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000",
	2,
	'solved',
	0,
	'',
	'ROW2',
	'');
INSERT INTO SM_STATE
	VALUES ("465b4033-5abb-4745-b767-f08cf6ae6dbe",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000",
	'solving',
	1,
	0);
INSERT INTO SM_SEME
	VALUES ("465b4033-5abb-4745-b767-f08cf6ae6dbe",
	"3c0abb69-5aa0-487e-996b-7909858726cf",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("465b4033-5abb-4745-b767-f08cf6ae6dbe",
	"e558b971-a37c-428c-abc4-46c4f386c9d4",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("65763af2-030a-4029-919d-b0c8cd18ff5d",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"465b4033-5abb-4745-b767-f08cf6ae6dbe");
INSERT INTO SM_AH
	VALUES ("65763af2-030a-4029-919d-b0c8cd18ff5d",
	"07fc627f-b641-41fe-a1af-748fb116451e");
INSERT INTO SM_ACT
	VALUES ("65763af2-030a-4029-919d-b0c8cd18ff5d",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	1,
	'if ( 100 == self.prune() )
  generate ROW2:solved() to self;
elif ( 100 == self.eliminate() )
  generate ROW2:solved() to self;
else
  select one sequence related by self->SEQUENCE[R1];
  if ( sequence.requests >= 1 )
    sequence.requests = 1;
    r = self;
    generate ROW1:update() to r;
  else
    sequence.requests = 0;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES ("49cd6a34-3f58-4220-8038-860e7c82e7e2",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"65763af2-030a-4029-919d-b0c8cd18ff5d");
INSERT INTO ACT_ACT
	VALUES ("49cd6a34-3f58-4220-8038-860e7c82e7e2",
	'state',
	0,
	"f58bf521-a153-4dcc-85dd-eb388eb24815",
	"00000000-0000-0000-0000-000000000000",
	0,
	'row::solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("f58bf521-a153-4dcc-85dd-eb388eb24815",
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"49cd6a34-3f58-4220-8038-860e7c82e7e2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("02fd2d5d-4ed3-4a06-8084-23004f56407f",
	"f58bf521-a153-4dcc-85dd-eb388eb24815",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'row::solving line: 1');
INSERT INTO ACT_IF
	VALUES ("02fd2d5d-4ed3-4a06-8084-23004f56407f",
	"a3e4f320-db91-4f12-817f-0ce23397cb92",
	"51b29f0b-ea56-42b8-bd25-74422e7a5867",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1650cde0-de14-486b-8187-d52ef92596ed",
	"f58bf521-a153-4dcc-85dd-eb388eb24815",
	"00000000-0000-0000-0000-000000000000",
	3,
	1,
	'row::solving line: 3');
INSERT INTO ACT_EL
	VALUES ("1650cde0-de14-486b-8187-d52ef92596ed",
	"f514f306-b040-43a9-b7de-06e02e214de3",
	"1fe5ff18-469f-4b7d-88a4-ef57df20411a",
	"02fd2d5d-4ed3-4a06-8084-23004f56407f");
INSERT INTO ACT_SMT
	VALUES ("635cb8f6-f825-4bab-9022-1167a21f38e6",
	"f58bf521-a153-4dcc-85dd-eb388eb24815",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'row::solving line: 5');
INSERT INTO ACT_E
	VALUES ("635cb8f6-f825-4bab-9022-1167a21f38e6",
	"169de81f-bd42-42b6-88c2-446b9f69e029",
	"02fd2d5d-4ed3-4a06-8084-23004f56407f");
INSERT INTO V_VAL
	VALUES ("479f59a7-690a-4340-95bd-5573f3d5c11d",
	0,
	0,
	1,
	6,
	8,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"f58bf521-a153-4dcc-85dd-eb388eb24815");
INSERT INTO V_LIN
	VALUES ("479f59a7-690a-4340-95bd-5573f3d5c11d",
	'100');
INSERT INTO V_VAL
	VALUES ("51b29f0b-ea56-42b8-bd25-74422e7a5867",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"f58bf521-a153-4dcc-85dd-eb388eb24815");
INSERT INTO V_BIN
	VALUES ("51b29f0b-ea56-42b8-bd25-74422e7a5867",
	"7cdd3044-2e61-425a-97ec-8b1ef5ef8e41",
	"479f59a7-690a-4340-95bd-5573f3d5c11d",
	'==');
INSERT INTO V_VAL
	VALUES ("7cdd3044-2e61-425a-97ec-8b1ef5ef8e41",
	0,
	0,
	1,
	18,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"f58bf521-a153-4dcc-85dd-eb388eb24815");
INSERT INTO V_TRV
	VALUES ("7cdd3044-2e61-425a-97ec-8b1ef5ef8e41",
	"450e3398-ff08-488c-94ba-b761702968e3",
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba",
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("e01c5564-ee9f-421d-a4e7-b508bccb90b9",
	0,
	0,
	3,
	8,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"f58bf521-a153-4dcc-85dd-eb388eb24815");
INSERT INTO V_LIN
	VALUES ("e01c5564-ee9f-421d-a4e7-b508bccb90b9",
	'100');
INSERT INTO V_VAL
	VALUES ("1fe5ff18-469f-4b7d-88a4-ef57df20411a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"f58bf521-a153-4dcc-85dd-eb388eb24815");
INSERT INTO V_BIN
	VALUES ("1fe5ff18-469f-4b7d-88a4-ef57df20411a",
	"3e79183c-a6b5-4e02-800d-66927868d85a",
	"e01c5564-ee9f-421d-a4e7-b508bccb90b9",
	'==');
INSERT INTO V_VAL
	VALUES ("3e79183c-a6b5-4e02-800d-66927868d85a",
	0,
	0,
	3,
	20,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"f58bf521-a153-4dcc-85dd-eb388eb24815");
INSERT INTO V_TRV
	VALUES ("3e79183c-a6b5-4e02-800d-66927868d85a",
	"a96f5d87-216f-4cae-a278-9bd89e071d22",
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba",
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("7902ffc6-3ccf-4f81-afd2-ec67eb7215ba",
	"f58bf521-a153-4dcc-85dd-eb388eb24815",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("7902ffc6-3ccf-4f81-afd2-ec67eb7215ba",
	0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("5e480e5a-1edd-420d-94f3-aff576b02788",
	1,
	13,
	16,
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba");
INSERT INTO V_LOC
	VALUES ("3ecae225-1fe1-4fde-adb7-8d923d761fa5",
	2,
	29,
	32,
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba");
INSERT INTO V_LOC
	VALUES ("82d42039-dfc9-4714-ad7a-0feaa138cf94",
	3,
	15,
	18,
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba");
INSERT INTO V_LOC
	VALUES ("13a0d517-d0ac-47ab-80fa-191e6081c19d",
	4,
	29,
	32,
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba");
INSERT INTO V_LOC
	VALUES ("c2a300f6-66c6-430d-a488-7d71828c7a54",
	9,
	9,
	12,
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba");
INSERT INTO ACT_BLK
	VALUES ("a3e4f320-db91-4f12-817f-0ce23397cb92",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"49cd6a34-3f58-4220-8038-860e7c82e7e2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8f1ababb-bf21-474f-a780-72d7050699c1",
	"a3e4f320-db91-4f12-817f-0ce23397cb92",
	"00000000-0000-0000-0000-000000000000",
	2,
	3,
	'row::solving line: 2');
INSERT INTO E_ESS
	VALUES ("8f1ababb-bf21-474f-a780-72d7050699c1",
	1,
	0,
	2,
	12,
	2,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("8f1ababb-bf21-474f-a780-72d7050699c1");
INSERT INTO E_GSME
	VALUES ("8f1ababb-bf21-474f-a780-72d7050699c1",
	"e558b971-a37c-428c-abc4-46c4f386c9d4",
	"07fc627f-b641-41fe-a1af-748fb116451e");
INSERT INTO E_GEN
	VALUES ("8f1ababb-bf21-474f-a780-72d7050699c1",
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba");
INSERT INTO ACT_BLK
	VALUES ("f514f306-b040-43a9-b7de-06e02e214de3",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"49cd6a34-3f58-4220-8038-860e7c82e7e2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("98db1a44-0ceb-4264-b5ad-d21a5919bf73",
	"f514f306-b040-43a9-b7de-06e02e214de3",
	"00000000-0000-0000-0000-000000000000",
	4,
	3,
	'row::solving line: 4');
INSERT INTO E_ESS
	VALUES ("98db1a44-0ceb-4264-b5ad-d21a5919bf73",
	1,
	0,
	4,
	12,
	4,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("98db1a44-0ceb-4264-b5ad-d21a5919bf73");
INSERT INTO E_GSME
	VALUES ("98db1a44-0ceb-4264-b5ad-d21a5919bf73",
	"e558b971-a37c-428c-abc4-46c4f386c9d4",
	"07fc627f-b641-41fe-a1af-748fb116451e");
INSERT INTO E_GEN
	VALUES ("98db1a44-0ceb-4264-b5ad-d21a5919bf73",
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba");
INSERT INTO ACT_BLK
	VALUES ("169de81f-bd42-42b6-88c2-446b9f69e029",
	1,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	6,
	40,
	0,
	0,
	6,
	49,
	0,
	0,
	0,
	0,
	0,
	"49cd6a34-3f58-4220-8038-860e7c82e7e2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("70a840d6-717e-49e2-a8cc-8cd7583292a0",
	"169de81f-bd42-42b6-88c2-446b9f69e029",
	"f0fd3362-acce-441f-97ae-dfdeb275b453",
	6,
	3,
	'row::solving line: 6');
INSERT INTO ACT_SEL
	VALUES ("70a840d6-717e-49e2-a8cc-8cd7583292a0",
	"72d2e84f-bbf7-4501-9e1f-6fa4e81389bd",
	1,
	'one',
	"b2d3e6dd-5540-423c-a940-6f5732c98bd2");
INSERT INTO ACT_SR
	VALUES ("70a840d6-717e-49e2-a8cc-8cd7583292a0");
INSERT INTO ACT_LNK
	VALUES ("510ab25b-6c48-4c0b-8f4b-f8035f003f3a",
	'',
	"70a840d6-717e-49e2-a8cc-8cd7583292a0",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	6,
	40,
	6,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f0fd3362-acce-441f-97ae-dfdeb275b453",
	"169de81f-bd42-42b6-88c2-446b9f69e029",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'row::solving line: 7');
INSERT INTO ACT_IF
	VALUES ("f0fd3362-acce-441f-97ae-dfdeb275b453",
	"0228cd28-e296-4bfb-872e-44c20f5a0634",
	"36c812d3-d265-4911-8a53-cc92b4791b99",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("83e8a85b-8ef7-4e47-bcf6-6009dd7b6b5d",
	"169de81f-bd42-42b6-88c2-446b9f69e029",
	"00000000-0000-0000-0000-000000000000",
	11,
	3,
	'row::solving line: 11');
INSERT INTO ACT_E
	VALUES ("83e8a85b-8ef7-4e47-bcf6-6009dd7b6b5d",
	"149264f4-1e30-4891-9b08-325089a29076",
	"f0fd3362-acce-441f-97ae-dfdeb275b453");
INSERT INTO V_VAL
	VALUES ("b2d3e6dd-5540-423c-a940-6f5732c98bd2",
	0,
	0,
	6,
	34,
	37,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"169de81f-bd42-42b6-88c2-446b9f69e029");
INSERT INTO V_IRF
	VALUES ("b2d3e6dd-5540-423c-a940-6f5732c98bd2",
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba");
INSERT INTO V_VAL
	VALUES ("8278e6f7-a622-4237-b894-6bcc59c86004",
	0,
	0,
	7,
	8,
	15,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"169de81f-bd42-42b6-88c2-446b9f69e029");
INSERT INTO V_IRF
	VALUES ("8278e6f7-a622-4237-b894-6bcc59c86004",
	"72d2e84f-bbf7-4501-9e1f-6fa4e81389bd");
INSERT INTO V_VAL
	VALUES ("ab14299a-d7b8-45df-8e17-feb79a5a2106",
	0,
	0,
	7,
	17,
	24,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"169de81f-bd42-42b6-88c2-446b9f69e029");
INSERT INTO V_AVL
	VALUES ("ab14299a-d7b8-45df-8e17-feb79a5a2106",
	"8278e6f7-a622-4237-b894-6bcc59c86004",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("36c812d3-d265-4911-8a53-cc92b4791b99",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"169de81f-bd42-42b6-88c2-446b9f69e029");
INSERT INTO V_BIN
	VALUES ("36c812d3-d265-4911-8a53-cc92b4791b99",
	"852ea8b7-0e16-4c98-83cd-61e0fd1cce75",
	"ab14299a-d7b8-45df-8e17-feb79a5a2106",
	'>=');
INSERT INTO V_VAL
	VALUES ("852ea8b7-0e16-4c98-83cd-61e0fd1cce75",
	0,
	0,
	7,
	29,
	29,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"169de81f-bd42-42b6-88c2-446b9f69e029");
INSERT INTO V_LIN
	VALUES ("852ea8b7-0e16-4c98-83cd-61e0fd1cce75",
	'1');
INSERT INTO V_VAR
	VALUES ("72d2e84f-bbf7-4501-9e1f-6fa4e81389bd",
	"169de81f-bd42-42b6-88c2-446b9f69e029",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("72d2e84f-bbf7-4501-9e1f-6fa4e81389bd",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("c02c89de-d335-4f2b-b198-68ff9824fde5",
	6,
	14,
	21,
	"72d2e84f-bbf7-4501-9e1f-6fa4e81389bd");
INSERT INTO V_LOC
	VALUES ("1aa51643-5b6d-4358-8da3-db69c0477cb7",
	7,
	8,
	15,
	"72d2e84f-bbf7-4501-9e1f-6fa4e81389bd");
INSERT INTO V_LOC
	VALUES ("b77fa198-87d2-450b-a769-fcc8c240e221",
	8,
	5,
	12,
	"72d2e84f-bbf7-4501-9e1f-6fa4e81389bd");
INSERT INTO V_LOC
	VALUES ("28572807-4d7d-4c64-9444-9bae10958141",
	12,
	5,
	12,
	"72d2e84f-bbf7-4501-9e1f-6fa4e81389bd");
INSERT INTO ACT_BLK
	VALUES ("0228cd28-e296-4bfb-872e-44c20f5a0634",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"49cd6a34-3f58-4220-8038-860e7c82e7e2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e07f1864-1d12-40e1-be7c-d1f4ed80d72f",
	"0228cd28-e296-4bfb-872e-44c20f5a0634",
	"86aad5e6-8bc0-415d-a4c1-2bfcdacc8957",
	8,
	5,
	'row::solving line: 8');
INSERT INTO ACT_AI
	VALUES ("e07f1864-1d12-40e1-be7c-d1f4ed80d72f",
	"0131a49a-0fd8-44a7-ad03-321f70d521f3",
	"f8251a86-2901-4a79-b404-2b1891f9d003",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("86aad5e6-8bc0-415d-a4c1-2bfcdacc8957",
	"0228cd28-e296-4bfb-872e-44c20f5a0634",
	"d0378d6d-6fa8-49cc-a930-e6dc59d75579",
	9,
	5,
	'row::solving line: 9');
INSERT INTO ACT_AI
	VALUES ("86aad5e6-8bc0-415d-a4c1-2bfcdacc8957",
	"bfe6f4b3-ac34-4517-a1b0-5569cecd1b54",
	"3c3c370e-46dd-4260-9f05-70a04e117724",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d0378d6d-6fa8-49cc-a930-e6dc59d75579",
	"0228cd28-e296-4bfb-872e-44c20f5a0634",
	"00000000-0000-0000-0000-000000000000",
	10,
	5,
	'row::solving line: 10');
INSERT INTO E_ESS
	VALUES ("d0378d6d-6fa8-49cc-a930-e6dc59d75579",
	1,
	0,
	10,
	14,
	10,
	19,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("d0378d6d-6fa8-49cc-a930-e6dc59d75579");
INSERT INTO E_GSME
	VALUES ("d0378d6d-6fa8-49cc-a930-e6dc59d75579",
	"3c0abb69-5aa0-487e-996b-7909858726cf",
	"07fc627f-b641-41fe-a1af-748fb116451e");
INSERT INTO E_GEN
	VALUES ("d0378d6d-6fa8-49cc-a930-e6dc59d75579",
	"e28155ea-16de-4e2a-80c8-b3cb625ee617");
INSERT INTO V_VAL
	VALUES ("b908cc02-907a-4f78-83c3-22c370cec24e",
	1,
	0,
	8,
	5,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"0228cd28-e296-4bfb-872e-44c20f5a0634");
INSERT INTO V_IRF
	VALUES ("b908cc02-907a-4f78-83c3-22c370cec24e",
	"72d2e84f-bbf7-4501-9e1f-6fa4e81389bd");
INSERT INTO V_VAL
	VALUES ("f8251a86-2901-4a79-b404-2b1891f9d003",
	1,
	0,
	8,
	14,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0228cd28-e296-4bfb-872e-44c20f5a0634");
INSERT INTO V_AVL
	VALUES ("f8251a86-2901-4a79-b404-2b1891f9d003",
	"b908cc02-907a-4f78-83c3-22c370cec24e",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("0131a49a-0fd8-44a7-ad03-321f70d521f3",
	0,
	0,
	8,
	25,
	25,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0228cd28-e296-4bfb-872e-44c20f5a0634");
INSERT INTO V_LIN
	VALUES ("0131a49a-0fd8-44a7-ad03-321f70d521f3",
	'1');
INSERT INTO V_VAL
	VALUES ("3c3c370e-46dd-4260-9f05-70a04e117724",
	1,
	1,
	9,
	5,
	5,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"0228cd28-e296-4bfb-872e-44c20f5a0634");
INSERT INTO V_IRF
	VALUES ("3c3c370e-46dd-4260-9f05-70a04e117724",
	"e28155ea-16de-4e2a-80c8-b3cb625ee617");
INSERT INTO V_VAL
	VALUES ("bfe6f4b3-ac34-4517-a1b0-5569cecd1b54",
	0,
	0,
	9,
	9,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"0228cd28-e296-4bfb-872e-44c20f5a0634");
INSERT INTO V_IRF
	VALUES ("bfe6f4b3-ac34-4517-a1b0-5569cecd1b54",
	"7902ffc6-3ccf-4f81-afd2-ec67eb7215ba");
INSERT INTO V_VAR
	VALUES ("e28155ea-16de-4e2a-80c8-b3cb625ee617",
	"0228cd28-e296-4bfb-872e-44c20f5a0634",
	'r',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("e28155ea-16de-4e2a-80c8-b3cb625ee617",
	0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("dcd46e73-25f6-4be1-a17e-a474fd3b8ccb",
	9,
	5,
	5,
	"e28155ea-16de-4e2a-80c8-b3cb625ee617");
INSERT INTO V_LOC
	VALUES ("5ee08deb-c435-45ff-a02f-ba260ca0ec1a",
	10,
	31,
	31,
	"e28155ea-16de-4e2a-80c8-b3cb625ee617");
INSERT INTO ACT_BLK
	VALUES ("149264f4-1e30-4891-9b08-325089a29076",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"49cd6a34-3f58-4220-8038-860e7c82e7e2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("a41cfdd0-eae8-4ac6-b1dd-5d9890f92f41",
	"149264f4-1e30-4891-9b08-325089a29076",
	"00000000-0000-0000-0000-000000000000",
	12,
	5,
	'row::solving line: 12');
INSERT INTO ACT_AI
	VALUES ("a41cfdd0-eae8-4ac6-b1dd-5d9890f92f41",
	"04ecba43-9fb8-4261-9059-75f88799881f",
	"8b8dc918-92fe-40c9-8b0c-ee271ce20af6",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("d644c992-86a1-4a78-8cd5-12e7b8855810",
	1,
	0,
	12,
	5,
	12,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"149264f4-1e30-4891-9b08-325089a29076");
INSERT INTO V_IRF
	VALUES ("d644c992-86a1-4a78-8cd5-12e7b8855810",
	"72d2e84f-bbf7-4501-9e1f-6fa4e81389bd");
INSERT INTO V_VAL
	VALUES ("8b8dc918-92fe-40c9-8b0c-ee271ce20af6",
	1,
	0,
	12,
	14,
	21,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"149264f4-1e30-4891-9b08-325089a29076");
INSERT INTO V_AVL
	VALUES ("8b8dc918-92fe-40c9-8b0c-ee271ce20af6",
	"d644c992-86a1-4a78-8cd5-12e7b8855810",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"1d98774f-c8bd-4c43-8f75-530b0ff40265");
INSERT INTO V_VAL
	VALUES ("04ecba43-9fb8-4261-9059-75f88799881f",
	0,
	0,
	12,
	25,
	25,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"149264f4-1e30-4891-9b08-325089a29076");
INSERT INTO V_LIN
	VALUES ("04ecba43-9fb8-4261-9059-75f88799881f",
	'0');
INSERT INTO SM_STATE
	VALUES ("320ee53c-84f6-4cb9-91a9-b62d50b93f2b",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000",
	'solved',
	3,
	0);
INSERT INTO SM_EIGN
	VALUES ("320ee53c-84f6-4cb9-91a9-b62d50b93f2b",
	"3c0abb69-5aa0-487e-996b-7909858726cf",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("320ee53c-84f6-4cb9-91a9-b62d50b93f2b",
	"3c0abb69-5aa0-487e-996b-7909858726cf",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EIGN
	VALUES ("320ee53c-84f6-4cb9-91a9-b62d50b93f2b",
	"e558b971-a37c-428c-abc4-46c4f386c9d4",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("320ee53c-84f6-4cb9-91a9-b62d50b93f2b",
	"e558b971-a37c-428c-abc4-46c4f386c9d4",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("003598e3-32d5-4bc4-8dd2-3b3d2e640f9d",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"320ee53c-84f6-4cb9-91a9-b62d50b93f2b");
INSERT INTO SM_AH
	VALUES ("003598e3-32d5-4bc4-8dd2-3b3d2e640f9d",
	"07fc627f-b641-41fe-a1af-748fb116451e");
INSERT INTO SM_ACT
	VALUES ("003598e3-32d5-4bc4-8dd2-3b3d2e640f9d",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	1,
	'select one sequence related by self->SEQUENCE[R1];
sequence.solved = true;',
	'');
INSERT INTO ACT_SAB
	VALUES ("a61312bc-1905-474b-8fba-8bef3eec3e40",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"003598e3-32d5-4bc4-8dd2-3b3d2e640f9d");
INSERT INTO ACT_ACT
	VALUES ("a61312bc-1905-474b-8fba-8bef3eec3e40",
	'state',
	0,
	"07487780-6f3f-43c3-9cff-7b95bf6fcd21",
	"00000000-0000-0000-0000-000000000000",
	0,
	'row::solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("07487780-6f3f-43c3-9cff-7b95bf6fcd21",
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	1,
	47,
	0,
	0,
	0,
	0,
	0,
	"a61312bc-1905-474b-8fba-8bef3eec3e40",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e1906083-e746-4ed7-be5c-981fbdaae700",
	"07487780-6f3f-43c3-9cff-7b95bf6fcd21",
	"94df7624-e562-4ca3-9b68-b3ff9104e783",
	1,
	1,
	'row::solved line: 1');
INSERT INTO ACT_SEL
	VALUES ("e1906083-e746-4ed7-be5c-981fbdaae700",
	"fe2b6705-db09-4bde-8441-60fac941617f",
	1,
	'one',
	"fa195585-fd14-414d-963c-e854fa093d4f");
INSERT INTO ACT_SR
	VALUES ("e1906083-e746-4ed7-be5c-981fbdaae700");
INSERT INTO ACT_LNK
	VALUES ("fa3c5b3f-5ef1-45be-82b5-97f6bdebf2e9",
	'',
	"e1906083-e746-4ed7-be5c-981fbdaae700",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	1,
	38,
	1,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("94df7624-e562-4ca3-9b68-b3ff9104e783",
	"07487780-6f3f-43c3-9cff-7b95bf6fcd21",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'row::solved line: 2');
INSERT INTO ACT_AI
	VALUES ("94df7624-e562-4ca3-9b68-b3ff9104e783",
	"9468b99a-ba4e-476c-a1d2-690228314afd",
	"dd2070b5-8129-42cb-b467-707199caae27",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("fa195585-fd14-414d-963c-e854fa093d4f",
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"07487780-6f3f-43c3-9cff-7b95bf6fcd21");
INSERT INTO V_IRF
	VALUES ("fa195585-fd14-414d-963c-e854fa093d4f",
	"49bb1f94-53cd-4452-b04a-d1b98004bee5");
INSERT INTO V_VAL
	VALUES ("dbbc7170-f255-4938-8cb4-59672bf8a155",
	1,
	0,
	2,
	1,
	8,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"07487780-6f3f-43c3-9cff-7b95bf6fcd21");
INSERT INTO V_IRF
	VALUES ("dbbc7170-f255-4938-8cb4-59672bf8a155",
	"fe2b6705-db09-4bde-8441-60fac941617f");
INSERT INTO V_VAL
	VALUES ("dd2070b5-8129-42cb-b467-707199caae27",
	1,
	0,
	2,
	10,
	15,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"07487780-6f3f-43c3-9cff-7b95bf6fcd21");
INSERT INTO V_AVL
	VALUES ("dd2070b5-8129-42cb-b467-707199caae27",
	"dbbc7170-f255-4938-8cb4-59672bf8a155",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"48d19dd8-8465-49b9-b4d0-dd14aa6d653f");
INSERT INTO V_VAL
	VALUES ("9468b99a-ba4e-476c-a1d2-690228314afd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"07487780-6f3f-43c3-9cff-7b95bf6fcd21");
INSERT INTO V_LBO
	VALUES ("9468b99a-ba4e-476c-a1d2-690228314afd",
	'TRUE');
INSERT INTO V_VAR
	VALUES ("fe2b6705-db09-4bde-8441-60fac941617f",
	"07487780-6f3f-43c3-9cff-7b95bf6fcd21",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("fe2b6705-db09-4bde-8441-60fac941617f",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("170ba258-32d8-43e4-a7dc-418b289876e7",
	1,
	12,
	19,
	"fe2b6705-db09-4bde-8441-60fac941617f");
INSERT INTO V_LOC
	VALUES ("54c61b2d-2a24-463c-8cf3-d23ecec7cdc2",
	2,
	1,
	8,
	"fe2b6705-db09-4bde-8441-60fac941617f");
INSERT INTO V_VAR
	VALUES ("49bb1f94-53cd-4452-b04a-d1b98004bee5",
	"07487780-6f3f-43c3-9cff-7b95bf6fcd21",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("49bb1f94-53cd-4452-b04a-d1b98004bee5",
	0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO SM_NSTXN
	VALUES ("7c9c0809-6b87-4f67-b2f8-ecb91e8ab212",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"465b4033-5abb-4745-b767-f08cf6ae6dbe",
	"3c0abb69-5aa0-487e-996b-7909858726cf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("365288e1-bd4a-4471-9827-6b5af17539c5",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"7c9c0809-6b87-4f67-b2f8-ecb91e8ab212");
INSERT INTO SM_AH
	VALUES ("365288e1-bd4a-4471-9827-6b5af17539c5",
	"07fc627f-b641-41fe-a1af-748fb116451e");
INSERT INTO SM_ACT
	VALUES ("365288e1-bd4a-4471-9827-6b5af17539c5",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("3efff77a-b056-4001-950e-bdaec9d1ab9d",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"365288e1-bd4a-4471-9827-6b5af17539c5");
INSERT INTO ACT_ACT
	VALUES ("3efff77a-b056-4001-950e-bdaec9d1ab9d",
	'transition',
	0,
	"789cee9f-e6f8-4a2f-84ce-e64ebbc45a39",
	"00000000-0000-0000-0000-000000000000",
	0,
	'ROW1: update in solving to solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("789cee9f-e6f8-4a2f-84ce-e64ebbc45a39",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"3efff77a-b056-4001-950e-bdaec9d1ab9d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("7c9c0809-6b87-4f67-b2f8-ecb91e8ab212",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"465b4033-5abb-4745-b767-f08cf6ae6dbe",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("f119a1c9-3343-47bd-80fb-068a11d175f8",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"465b4033-5abb-4745-b767-f08cf6ae6dbe",
	"e558b971-a37c-428c-abc4-46c4f386c9d4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("a57d8c99-82b1-4c98-81e0-360d247d9e88",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"f119a1c9-3343-47bd-80fb-068a11d175f8");
INSERT INTO SM_AH
	VALUES ("a57d8c99-82b1-4c98-81e0-360d247d9e88",
	"07fc627f-b641-41fe-a1af-748fb116451e");
INSERT INTO SM_ACT
	VALUES ("a57d8c99-82b1-4c98-81e0-360d247d9e88",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("8898e830-0164-44e6-919d-658e5ff1c8d5",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"a57d8c99-82b1-4c98-81e0-360d247d9e88");
INSERT INTO ACT_ACT
	VALUES ("8898e830-0164-44e6-919d-658e5ff1c8d5",
	'transition',
	0,
	"07119544-4ae0-4dae-93a2-161293161024",
	"00000000-0000-0000-0000-000000000000",
	0,
	'ROW2: solved in solving to solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("07119544-4ae0-4dae-93a2-161293161024",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"8898e830-0164-44e6-919d-658e5ff1c8d5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("f119a1c9-3343-47bd-80fb-068a11d175f8",
	"07fc627f-b641-41fe-a1af-748fb116451e",
	"320ee53c-84f6-4cb9-91a9-b62d50b93f2b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_OBJ
	VALUES ("03ac2337-ce3a-497f-a3de-92a1101b2208",
	'sequence',
	1,
	'SEQUENCE',
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO O_TFR
	VALUES ("a76fd039-37b9-41cc-9e9a-ea4943cde168",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	'solve',
	'',
	"606ca061-c661-4bbf-bb1a-bb2345f5239e",
	0,
	'i = 0;
select many sequences from instances of SEQUENCE;
while ( 25 > i )
  j = 0;
  while ( 25 > j )
    ::display();
    
    select many eligibles from instances of ELIGIBLE;
    count1 = cardinality eligibles;
    count2 = 0;
    
    for each sequence in sequences
      k = sequence.solve_by_pruning();
    end for;
    
    select many eligibles from instances of ELIGIBLE;
    count2 = cardinality eligibles;
    
    if ( ( 81 == CELL::score() ) or ( count1 == count2 ) )
      break;
    end if;

    j = j + 1;
  end while;

  for each sequence in sequences
    k = sequence.solve_by_elimination();
  end for;
  
  if ( 81 == CELL::score() )
    break;
  end if;
  
  i = i + 1;
end while;

/*#inline
printf( "passes:  %d\n", v66_i );
*/',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_OPB
	VALUES ("f53eda61-3539-466b-8069-fa84e94dd930",
	"a76fd039-37b9-41cc-9e9a-ea4943cde168");
INSERT INTO ACT_ACT
	VALUES ("f53eda61-3539-466b-8069-fa84e94dd930",
	'class operation',
	0,
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5",
	"00000000-0000-0000-0000-000000000000",
	0,
	'sequence::solve',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("058f0fc0-305f-4899-82ed-902b3fd2e7c5",
	1,
	0,
	0,
	'',
	'',
	'',
	3,
	1,
	2,
	41,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f53eda61-3539-466b-8069-fa84e94dd930",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("bb44fd59-cf74-4d90-9345-b073cb713496",
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5",
	"89a1178a-6653-452d-8d9a-bd2b6f323aa8",
	1,
	1,
	'sequence::solve line: 1');
INSERT INTO ACT_AI
	VALUES ("bb44fd59-cf74-4d90-9345-b073cb713496",
	"779a92d9-8980-4717-b3a1-63def5810fd2",
	"6f120c48-913c-41b0-a9d4-7f2f34cc129f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("89a1178a-6653-452d-8d9a-bd2b6f323aa8",
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5",
	"2a0fbf79-3c1f-4fd1-bd0d-bb4977a1f2fd",
	2,
	1,
	'sequence::solve line: 2');
INSERT INTO ACT_FIO
	VALUES ("89a1178a-6653-452d-8d9a-bd2b6f323aa8",
	"4cb05384-a855-4801-bc30-6683b7f1b52e",
	1,
	'many',
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	2,
	41);
INSERT INTO ACT_SMT
	VALUES ("2a0fbf79-3c1f-4fd1-bd0d-bb4977a1f2fd",
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5",
	"00000000-0000-0000-0000-000000000000",
	3,
	1,
	'sequence::solve line: 3');
INSERT INTO ACT_WHL
	VALUES ("2a0fbf79-3c1f-4fd1-bd0d-bb4977a1f2fd",
	"f98d5d55-680f-4692-981f-f6020c7f036f",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_VAL
	VALUES ("6f120c48-913c-41b0-a9d4-7f2f34cc129f",
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5");
INSERT INTO V_TVL
	VALUES ("6f120c48-913c-41b0-a9d4-7f2f34cc129f",
	"0ba8ad2f-0d38-40d5-8ee6-d412319a503c");
INSERT INTO V_VAL
	VALUES ("779a92d9-8980-4717-b3a1-63def5810fd2",
	0,
	0,
	1,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5");
INSERT INTO V_LIN
	VALUES ("779a92d9-8980-4717-b3a1-63def5810fd2",
	'0');
INSERT INTO V_VAL
	VALUES ("a6e73f80-9895-4fe8-bb1c-f13e9a64e3b7",
	0,
	0,
	3,
	9,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5");
INSERT INTO V_LIN
	VALUES ("a6e73f80-9895-4fe8-bb1c-f13e9a64e3b7",
	'25');
INSERT INTO V_VAL
	VALUES ("f98d5d55-680f-4692-981f-f6020c7f036f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5");
INSERT INTO V_BIN
	VALUES ("f98d5d55-680f-4692-981f-f6020c7f036f",
	"24cb9c88-c5a1-4d6e-85ab-2f949762682e",
	"a6e73f80-9895-4fe8-bb1c-f13e9a64e3b7",
	'>');
INSERT INTO V_VAL
	VALUES ("24cb9c88-c5a1-4d6e-85ab-2f949762682e",
	0,
	0,
	3,
	14,
	14,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5");
INSERT INTO V_TVL
	VALUES ("24cb9c88-c5a1-4d6e-85ab-2f949762682e",
	"0ba8ad2f-0d38-40d5-8ee6-d412319a503c");
INSERT INTO V_VAR
	VALUES ("0ba8ad2f-0d38-40d5-8ee6-d412319a503c",
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5",
	'i',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("0ba8ad2f-0d38-40d5-8ee6-d412319a503c",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("37f61bc1-1d63-4043-9208-c6cc8fbf6585",
	1,
	1,
	1,
	"0ba8ad2f-0d38-40d5-8ee6-d412319a503c");
INSERT INTO V_LOC
	VALUES ("113f3729-4c26-431c-bdfa-69c4bc08ce95",
	3,
	14,
	14,
	"0ba8ad2f-0d38-40d5-8ee6-d412319a503c");
INSERT INTO V_LOC
	VALUES ("1958d722-121d-4942-b4e3-70ec10c8629e",
	34,
	3,
	3,
	"0ba8ad2f-0d38-40d5-8ee6-d412319a503c");
INSERT INTO V_LOC
	VALUES ("6387de04-5de5-4e96-9988-ff8bedb2c76a",
	34,
	7,
	7,
	"0ba8ad2f-0d38-40d5-8ee6-d412319a503c");
INSERT INTO V_VAR
	VALUES ("4cb05384-a855-4801-bc30-6683b7f1b52e",
	"058f0fc0-305f-4899-82ed-902b3fd2e7c5",
	'sequences',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("4cb05384-a855-4801-bc30-6683b7f1b52e",
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("1fb34519-f765-433e-a427-b67ee8a72799",
	2,
	13,
	21,
	"4cb05384-a855-4801-bc30-6683b7f1b52e");
INSERT INTO V_LOC
	VALUES ("c4391e14-19c8-4d58-85a7-84db3d67849a",
	12,
	26,
	34,
	"4cb05384-a855-4801-bc30-6683b7f1b52e");
INSERT INTO V_LOC
	VALUES ("54a24129-8e32-4b78-923b-850df0f8611a",
	26,
	24,
	32,
	"4cb05384-a855-4801-bc30-6683b7f1b52e");
INSERT INTO ACT_BLK
	VALUES ("4aff7820-763f-43bc-9bd2-55506d78854f",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	34,
	3,
	30,
	14,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f53eda61-3539-466b-8069-fa84e94dd930",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("db0990de-3c4d-4171-ba49-f49e23090df1",
	"4aff7820-763f-43bc-9bd2-55506d78854f",
	"21518dca-05d0-4bf9-b7cf-86ecb8500c95",
	4,
	3,
	'sequence::solve line: 4');
INSERT INTO ACT_AI
	VALUES ("db0990de-3c4d-4171-ba49-f49e23090df1",
	"7d36d8d7-b6a5-4966-8dd2-34d08e630f8a",
	"2313c575-9e60-4a02-8c44-f2c90c7f8200",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("21518dca-05d0-4bf9-b7cf-86ecb8500c95",
	"4aff7820-763f-43bc-9bd2-55506d78854f",
	"2e4c9137-4fe5-46ad-8f83-1f46dd0a043c",
	5,
	3,
	'sequence::solve line: 5');
INSERT INTO ACT_WHL
	VALUES ("21518dca-05d0-4bf9-b7cf-86ecb8500c95",
	"b530d939-4d38-445a-92cc-095c00a50434",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO ACT_SMT
	VALUES ("2e4c9137-4fe5-46ad-8f83-1f46dd0a043c",
	"4aff7820-763f-43bc-9bd2-55506d78854f",
	"24082e70-1e72-49d0-ab4b-bfee93068fc1",
	26,
	3,
	'sequence::solve line: 26');
INSERT INTO ACT_FOR
	VALUES ("2e4c9137-4fe5-46ad-8f83-1f46dd0a043c",
	"d515feaa-0a44-4bd4-918d-0bc5229f8b14",
	1,
	"59d76ff3-856b-4f05-8739-e9e7ef2e45a3",
	"4cb05384-a855-4801-bc30-6683b7f1b52e",
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO ACT_SMT
	VALUES ("24082e70-1e72-49d0-ab4b-bfee93068fc1",
	"4aff7820-763f-43bc-9bd2-55506d78854f",
	"09739270-c377-4873-a1a3-671735712edc",
	30,
	3,
	'sequence::solve line: 30');
INSERT INTO ACT_IF
	VALUES ("24082e70-1e72-49d0-ab4b-bfee93068fc1",
	"190b050e-240e-43d2-9ca3-e4337686df78",
	"b1b8772e-6b74-4ecd-b1e5-b0fa0dce6665",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("09739270-c377-4873-a1a3-671735712edc",
	"4aff7820-763f-43bc-9bd2-55506d78854f",
	"00000000-0000-0000-0000-000000000000",
	34,
	3,
	'sequence::solve line: 34');
INSERT INTO ACT_AI
	VALUES ("09739270-c377-4873-a1a3-671735712edc",
	"aa7ba048-f286-4f5a-bbd2-c512e0187ab4",
	"21ba34ff-ee7c-485a-917a-0ec830c917f2",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("2313c575-9e60-4a02-8c44-f2c90c7f8200",
	1,
	1,
	4,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_TVL
	VALUES ("2313c575-9e60-4a02-8c44-f2c90c7f8200",
	"d25101dd-19b2-435e-a9fc-56a283522879");
INSERT INTO V_VAL
	VALUES ("7d36d8d7-b6a5-4966-8dd2-34d08e630f8a",
	0,
	0,
	4,
	7,
	7,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_LIN
	VALUES ("7d36d8d7-b6a5-4966-8dd2-34d08e630f8a",
	'0');
INSERT INTO V_VAL
	VALUES ("d0ac4f8b-bfb1-4883-b1ce-de235316f3ca",
	0,
	0,
	5,
	11,
	12,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_LIN
	VALUES ("d0ac4f8b-bfb1-4883-b1ce-de235316f3ca",
	'25');
INSERT INTO V_VAL
	VALUES ("b530d939-4d38-445a-92cc-095c00a50434",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_BIN
	VALUES ("b530d939-4d38-445a-92cc-095c00a50434",
	"84134d48-c113-42fe-814f-28ed877a70f7",
	"d0ac4f8b-bfb1-4883-b1ce-de235316f3ca",
	'>');
INSERT INTO V_VAL
	VALUES ("84134d48-c113-42fe-814f-28ed877a70f7",
	0,
	0,
	5,
	16,
	16,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_TVL
	VALUES ("84134d48-c113-42fe-814f-28ed877a70f7",
	"d25101dd-19b2-435e-a9fc-56a283522879");
INSERT INTO V_VAL
	VALUES ("5306eb2f-139d-4595-bf11-44f7499d90fd",
	0,
	0,
	30,
	8,
	9,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_LIN
	VALUES ("5306eb2f-139d-4595-bf11-44f7499d90fd",
	'81');
INSERT INTO V_VAL
	VALUES ("b1b8772e-6b74-4ecd-b1e5-b0fa0dce6665",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_BIN
	VALUES ("b1b8772e-6b74-4ecd-b1e5-b0fa0dce6665",
	"aac715f8-8c3c-4667-93e0-5e6e74857293",
	"5306eb2f-139d-4595-bf11-44f7499d90fd",
	'==');
INSERT INTO V_VAL
	VALUES ("aac715f8-8c3c-4667-93e0-5e6e74857293",
	0,
	0,
	30,
	20,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_TRV
	VALUES ("aac715f8-8c3c-4667-93e0-5e6e74857293",
	"e7682414-c9d4-490e-84ef-68b46fb9a8f1",
	"00000000-0000-0000-0000-000000000000",
	1,
	30,
	14);
INSERT INTO V_VAL
	VALUES ("21ba34ff-ee7c-485a-917a-0ec830c917f2",
	1,
	0,
	34,
	3,
	3,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_TVL
	VALUES ("21ba34ff-ee7c-485a-917a-0ec830c917f2",
	"0ba8ad2f-0d38-40d5-8ee6-d412319a503c");
INSERT INTO V_VAL
	VALUES ("924aaf0c-b0f9-4bbc-a385-e2c2206ff76f",
	0,
	0,
	34,
	7,
	7,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_TVL
	VALUES ("924aaf0c-b0f9-4bbc-a385-e2c2206ff76f",
	"0ba8ad2f-0d38-40d5-8ee6-d412319a503c");
INSERT INTO V_VAL
	VALUES ("aa7ba048-f286-4f5a-bbd2-c512e0187ab4",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_BIN
	VALUES ("aa7ba048-f286-4f5a-bbd2-c512e0187ab4",
	"9f5df809-7a63-4580-bc4b-5248d4a930b7",
	"924aaf0c-b0f9-4bbc-a385-e2c2206ff76f",
	'+');
INSERT INTO V_VAL
	VALUES ("9f5df809-7a63-4580-bc4b-5248d4a930b7",
	0,
	0,
	34,
	11,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"4aff7820-763f-43bc-9bd2-55506d78854f");
INSERT INTO V_LIN
	VALUES ("9f5df809-7a63-4580-bc4b-5248d4a930b7",
	'1');
INSERT INTO V_VAR
	VALUES ("d25101dd-19b2-435e-a9fc-56a283522879",
	"4aff7820-763f-43bc-9bd2-55506d78854f",
	'j',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("d25101dd-19b2-435e-a9fc-56a283522879",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("0bf16a0b-9975-4c42-bf93-c40501ce7a38",
	4,
	3,
	3,
	"d25101dd-19b2-435e-a9fc-56a283522879");
INSERT INTO V_LOC
	VALUES ("a0d0bc5d-20b0-4f28-a20e-bec0d335a916",
	5,
	16,
	16,
	"d25101dd-19b2-435e-a9fc-56a283522879");
INSERT INTO V_LOC
	VALUES ("f7ca26b3-377f-4479-ba92-52986c555669",
	23,
	5,
	5,
	"d25101dd-19b2-435e-a9fc-56a283522879");
INSERT INTO V_LOC
	VALUES ("60ecc8da-dd61-4148-a664-7025ac2a3431",
	23,
	9,
	9,
	"d25101dd-19b2-435e-a9fc-56a283522879");
INSERT INTO V_VAR
	VALUES ("59d76ff3-856b-4f05-8739-e9e7ef2e45a3",
	"4aff7820-763f-43bc-9bd2-55506d78854f",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("59d76ff3-856b-4f05-8739-e9e7ef2e45a3",
	1,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("ccb42466-24d0-457f-83fe-e964e9ed3675",
	26,
	12,
	19,
	"59d76ff3-856b-4f05-8739-e9e7ef2e45a3");
INSERT INTO V_LOC
	VALUES ("34935cf1-43c7-4640-91b7-4227ad1b5b76",
	27,
	9,
	16,
	"59d76ff3-856b-4f05-8739-e9e7ef2e45a3");
INSERT INTO ACT_BLK
	VALUES ("30857bec-80bb-47fb-91b1-11a785d203e7",
	1,
	0,
	0,
	'CELL',
	'',
	'',
	23,
	5,
	19,
	18,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f53eda61-3539-466b-8069-fa84e94dd930",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("11c8eca2-e96c-4fd9-859e-aec07acdded9",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	"85ff14f6-ce98-45b5-93bf-cbd8c8d70e16",
	6,
	5,
	'sequence::solve line: 6');
INSERT INTO ACT_FNC
	VALUES ("11c8eca2-e96c-4fd9-859e-aec07acdded9",
	"ea7999d4-ad63-4a57-abe3-4a8224d30de0",
	6,
	7);
INSERT INTO ACT_SMT
	VALUES ("85ff14f6-ce98-45b5-93bf-cbd8c8d70e16",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	"f7e52d67-7b64-43cc-9cb1-ccb899454480",
	8,
	5,
	'sequence::solve line: 8');
INSERT INTO ACT_FIO
	VALUES ("85ff14f6-ce98-45b5-93bf-cbd8c8d70e16",
	"533b39da-c17d-4895-8364-a0cd33fc81b1",
	1,
	'many',
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	8,
	45);
INSERT INTO ACT_SMT
	VALUES ("f7e52d67-7b64-43cc-9cb1-ccb899454480",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	"02eb863f-032a-4ab3-8b9c-ff6199657c1c",
	9,
	5,
	'sequence::solve line: 9');
INSERT INTO ACT_AI
	VALUES ("f7e52d67-7b64-43cc-9cb1-ccb899454480",
	"56f4a589-ed02-4c5f-a421-4f6ee560242b",
	"307f3ae1-0f9c-415f-9bbc-2db3215a9b73",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("02eb863f-032a-4ab3-8b9c-ff6199657c1c",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	"538eb6f4-3444-464a-8444-8a58130562bf",
	10,
	5,
	'sequence::solve line: 10');
INSERT INTO ACT_AI
	VALUES ("02eb863f-032a-4ab3-8b9c-ff6199657c1c",
	"31aaff54-b69b-4860-a568-048beb4284eb",
	"ab2e365d-af39-4291-b774-6bf5498ed433",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("538eb6f4-3444-464a-8444-8a58130562bf",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	"e1d99fdb-ad1a-4f91-acac-0d8091d90ff3",
	12,
	5,
	'sequence::solve line: 12');
INSERT INTO ACT_FOR
	VALUES ("538eb6f4-3444-464a-8444-8a58130562bf",
	"966a990d-ef8e-4868-9202-ddf84c4b9672",
	1,
	"69445a1d-9efc-4805-92c4-00ca1d6862b3",
	"4cb05384-a855-4801-bc30-6683b7f1b52e",
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO ACT_SMT
	VALUES ("e1d99fdb-ad1a-4f91-acac-0d8091d90ff3",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	"87b3d7f4-78c1-4726-9bf1-4d9034f74b6c",
	16,
	5,
	'sequence::solve line: 16');
INSERT INTO ACT_FIO
	VALUES ("e1d99fdb-ad1a-4f91-acac-0d8091d90ff3",
	"533b39da-c17d-4895-8364-a0cd33fc81b1",
	0,
	'many',
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	16,
	45);
INSERT INTO ACT_SMT
	VALUES ("87b3d7f4-78c1-4726-9bf1-4d9034f74b6c",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	"0c49f6fc-b8d7-459f-a476-e46bdeadb533",
	17,
	5,
	'sequence::solve line: 17');
INSERT INTO ACT_AI
	VALUES ("87b3d7f4-78c1-4726-9bf1-4d9034f74b6c",
	"5b1b2f4f-678a-4252-8c83-f1b6d4167535",
	"9290d542-7f3a-4eb7-ba1b-640137941861",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0c49f6fc-b8d7-459f-a476-e46bdeadb533",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	"167fed2b-0370-4f07-9620-81ba2274a835",
	19,
	5,
	'sequence::solve line: 19');
INSERT INTO ACT_IF
	VALUES ("0c49f6fc-b8d7-459f-a476-e46bdeadb533",
	"5e55e4a3-b27e-4186-8b06-f3c1a80e496e",
	"b82c2f91-c596-47db-b37d-2717613fb8ff",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("167fed2b-0370-4f07-9620-81ba2274a835",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	"00000000-0000-0000-0000-000000000000",
	23,
	5,
	'sequence::solve line: 23');
INSERT INTO ACT_AI
	VALUES ("167fed2b-0370-4f07-9620-81ba2274a835",
	"7992d040-6573-42ec-a078-193160dfb1e5",
	"b7a33234-ceb8-4b96-a3c3-6fe4391e153e",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("307f3ae1-0f9c-415f-9bbc-2db3215a9b73",
	1,
	1,
	9,
	5,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_TVL
	VALUES ("307f3ae1-0f9c-415f-9bbc-2db3215a9b73",
	"ff612d83-7c77-43d7-afdb-d6c49025a2d8");
INSERT INTO V_VAL
	VALUES ("4201282b-2248-4397-9a80-173142390959",
	0,
	0,
	9,
	26,
	34,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_ISR
	VALUES ("4201282b-2248-4397-9a80-173142390959",
	"533b39da-c17d-4895-8364-a0cd33fc81b1");
INSERT INTO V_VAL
	VALUES ("56f4a589-ed02-4c5f-a421-4f6ee560242b",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_UNY
	VALUES ("56f4a589-ed02-4c5f-a421-4f6ee560242b",
	"4201282b-2248-4397-9a80-173142390959",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("ab2e365d-af39-4291-b774-6bf5498ed433",
	1,
	1,
	10,
	5,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_TVL
	VALUES ("ab2e365d-af39-4291-b774-6bf5498ed433",
	"14c7ae30-a408-4afc-971a-f7420d1d45e7");
INSERT INTO V_VAL
	VALUES ("31aaff54-b69b-4860-a568-048beb4284eb",
	0,
	0,
	10,
	14,
	14,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_LIN
	VALUES ("31aaff54-b69b-4860-a568-048beb4284eb",
	'0');
INSERT INTO V_VAL
	VALUES ("9290d542-7f3a-4eb7-ba1b-640137941861",
	1,
	0,
	17,
	5,
	10,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_TVL
	VALUES ("9290d542-7f3a-4eb7-ba1b-640137941861",
	"14c7ae30-a408-4afc-971a-f7420d1d45e7");
INSERT INTO V_VAL
	VALUES ("c2447b56-4862-46a2-8fa6-19c9f2c72ace",
	0,
	0,
	17,
	26,
	34,
	0,
	0,
	0,
	0,
	"bd7c827f-c0a0-4115-8268-33db6654fef9",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_ISR
	VALUES ("c2447b56-4862-46a2-8fa6-19c9f2c72ace",
	"533b39da-c17d-4895-8364-a0cd33fc81b1");
INSERT INTO V_VAL
	VALUES ("5b1b2f4f-678a-4252-8c83-f1b6d4167535",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_UNY
	VALUES ("5b1b2f4f-678a-4252-8c83-f1b6d4167535",
	"c2447b56-4862-46a2-8fa6-19c9f2c72ace",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("70307f37-c453-442c-bf7d-c300813294b1",
	0,
	0,
	19,
	12,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_LIN
	VALUES ("70307f37-c453-442c-bf7d-c300813294b1",
	'81');
INSERT INTO V_VAL
	VALUES ("594c634f-3525-4761-8268-106cb57c6534",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_BIN
	VALUES ("594c634f-3525-4761-8268-106cb57c6534",
	"e957b7be-444f-4b39-800e-a07ab5accfaf",
	"70307f37-c453-442c-bf7d-c300813294b1",
	'==');
INSERT INTO V_VAL
	VALUES ("e957b7be-444f-4b39-800e-a07ab5accfaf",
	0,
	0,
	19,
	24,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_TRV
	VALUES ("e957b7be-444f-4b39-800e-a07ab5accfaf",
	"e7682414-c9d4-490e-84ef-68b46fb9a8f1",
	"00000000-0000-0000-0000-000000000000",
	1,
	19,
	18);
INSERT INTO V_VAL
	VALUES ("d62727af-d06c-4dd7-91ba-41514e4d8cb4",
	0,
	0,
	19,
	39,
	44,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_TVL
	VALUES ("d62727af-d06c-4dd7-91ba-41514e4d8cb4",
	"ff612d83-7c77-43d7-afdb-d6c49025a2d8");
INSERT INTO V_VAL
	VALUES ("bd0bca72-5243-4ddc-ac05-1a8820f22fea",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_BIN
	VALUES ("bd0bca72-5243-4ddc-ac05-1a8820f22fea",
	"f68ca7a3-8a0b-4453-a57f-9cbd4ffca316",
	"d62727af-d06c-4dd7-91ba-41514e4d8cb4",
	'==');
INSERT INTO V_VAL
	VALUES ("f68ca7a3-8a0b-4453-a57f-9cbd4ffca316",
	0,
	0,
	19,
	49,
	54,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_TVL
	VALUES ("f68ca7a3-8a0b-4453-a57f-9cbd4ffca316",
	"14c7ae30-a408-4afc-971a-f7420d1d45e7");
INSERT INTO V_VAL
	VALUES ("b82c2f91-c596-47db-b37d-2717613fb8ff",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_BIN
	VALUES ("b82c2f91-c596-47db-b37d-2717613fb8ff",
	"bd0bca72-5243-4ddc-ac05-1a8820f22fea",
	"594c634f-3525-4761-8268-106cb57c6534",
	'or');
INSERT INTO V_VAL
	VALUES ("b7a33234-ceb8-4b96-a3c3-6fe4391e153e",
	1,
	0,
	23,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_TVL
	VALUES ("b7a33234-ceb8-4b96-a3c3-6fe4391e153e",
	"d25101dd-19b2-435e-a9fc-56a283522879");
INSERT INTO V_VAL
	VALUES ("ddc69878-1866-41a1-804a-2fbcc0bfc069",
	0,
	0,
	23,
	9,
	9,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_TVL
	VALUES ("ddc69878-1866-41a1-804a-2fbcc0bfc069",
	"d25101dd-19b2-435e-a9fc-56a283522879");
INSERT INTO V_VAL
	VALUES ("7992d040-6573-42ec-a078-193160dfb1e5",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_BIN
	VALUES ("7992d040-6573-42ec-a078-193160dfb1e5",
	"c9dfacd5-54d7-4bed-b3ed-451cf18ef8bf",
	"ddc69878-1866-41a1-804a-2fbcc0bfc069",
	'+');
INSERT INTO V_VAL
	VALUES ("c9dfacd5-54d7-4bed-b3ed-451cf18ef8bf",
	0,
	0,
	23,
	13,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"30857bec-80bb-47fb-91b1-11a785d203e7");
INSERT INTO V_LIN
	VALUES ("c9dfacd5-54d7-4bed-b3ed-451cf18ef8bf",
	'1');
INSERT INTO V_VAR
	VALUES ("533b39da-c17d-4895-8364-a0cd33fc81b1",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	'eligibles',
	1,
	"bd7c827f-c0a0-4115-8268-33db6654fef9");
INSERT INTO V_INS
	VALUES ("533b39da-c17d-4895-8364-a0cd33fc81b1",
	"7dfbb9fe-d109-4356-a43c-8a02617ad46a");
INSERT INTO V_LOC
	VALUES ("7fd45e95-2736-459a-9b50-90daca9833a4",
	8,
	17,
	25,
	"533b39da-c17d-4895-8364-a0cd33fc81b1");
INSERT INTO V_LOC
	VALUES ("e789a990-f409-4a00-981a-b57e379dd799",
	16,
	17,
	25,
	"533b39da-c17d-4895-8364-a0cd33fc81b1");
INSERT INTO V_VAR
	VALUES ("ff612d83-7c77-43d7-afdb-d6c49025a2d8",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	'count1',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("ff612d83-7c77-43d7-afdb-d6c49025a2d8",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("9941e75c-ee75-4b26-ba97-47accbaa4c75",
	9,
	5,
	10,
	"ff612d83-7c77-43d7-afdb-d6c49025a2d8");
INSERT INTO V_LOC
	VALUES ("91207983-837a-4771-9423-1a0c476ce4e1",
	19,
	39,
	44,
	"ff612d83-7c77-43d7-afdb-d6c49025a2d8");
INSERT INTO V_VAR
	VALUES ("14c7ae30-a408-4afc-971a-f7420d1d45e7",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	'count2',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("14c7ae30-a408-4afc-971a-f7420d1d45e7",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("1888dcb1-0e98-46c5-9a01-dceba2b7de93",
	10,
	5,
	10,
	"14c7ae30-a408-4afc-971a-f7420d1d45e7");
INSERT INTO V_LOC
	VALUES ("9343d301-cbc5-4783-b52d-5e4dd1ee1a0e",
	17,
	5,
	10,
	"14c7ae30-a408-4afc-971a-f7420d1d45e7");
INSERT INTO V_LOC
	VALUES ("256d934d-e7b4-41d6-b8b8-22787fc77ac4",
	19,
	49,
	54,
	"14c7ae30-a408-4afc-971a-f7420d1d45e7");
INSERT INTO V_VAR
	VALUES ("69445a1d-9efc-4805-92c4-00ca1d6862b3",
	"30857bec-80bb-47fb-91b1-11a785d203e7",
	'sequence',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("69445a1d-9efc-4805-92c4-00ca1d6862b3",
	1,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO V_LOC
	VALUES ("987904e2-5070-4724-8af3-61f2aef0f6cd",
	12,
	14,
	21,
	"69445a1d-9efc-4805-92c4-00ca1d6862b3");
INSERT INTO V_LOC
	VALUES ("637ad09d-3893-45cb-9946-9e11c08c1047",
	13,
	11,
	18,
	"69445a1d-9efc-4805-92c4-00ca1d6862b3");
INSERT INTO ACT_BLK
	VALUES ("966a990d-ef8e-4868-9202-ddf84c4b9672",
	0,
	0,
	0,
	'',
	'',
	'',
	13,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f53eda61-3539-466b-8069-fa84e94dd930",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("139c8a3a-073f-4fb8-a570-f5c7bd71827b",
	"966a990d-ef8e-4868-9202-ddf84c4b9672",
	"00000000-0000-0000-0000-000000000000",
	13,
	7,
	'sequence::solve line: 13');
INSERT INTO ACT_AI
	VALUES ("139c8a3a-073f-4fb8-a570-f5c7bd71827b",
	"4d6d3fad-4872-440e-8301-09fbf8303ef8",
	"2d2ed292-4021-4c3b-adf0-79a67a62ebc4",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("2d2ed292-4021-4c3b-adf0-79a67a62ebc4",
	1,
	1,
	13,
	7,
	7,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"966a990d-ef8e-4868-9202-ddf84c4b9672");
INSERT INTO V_TVL
	VALUES ("2d2ed292-4021-4c3b-adf0-79a67a62ebc4",
	"af5bf1ee-57bb-4299-adec-80267439b43b");
INSERT INTO V_VAL
	VALUES ("4d6d3fad-4872-440e-8301-09fbf8303ef8",
	0,
	0,
	13,
	20,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"966a990d-ef8e-4868-9202-ddf84c4b9672");
INSERT INTO V_TRV
	VALUES ("4d6d3fad-4872-440e-8301-09fbf8303ef8",
	"2f879600-423d-4941-b679-354b28367a87",
	"69445a1d-9efc-4805-92c4-00ca1d6862b3",
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("af5bf1ee-57bb-4299-adec-80267439b43b",
	"966a990d-ef8e-4868-9202-ddf84c4b9672",
	'k',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("af5bf1ee-57bb-4299-adec-80267439b43b",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("7c0ef000-c35d-4c0b-a33e-a1fbae2f95c0",
	13,
	7,
	7,
	"af5bf1ee-57bb-4299-adec-80267439b43b");
INSERT INTO ACT_BLK
	VALUES ("5e55e4a3-b27e-4186-8b06-f3c1a80e496e",
	0,
	0,
	0,
	'',
	'',
	'',
	20,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f53eda61-3539-466b-8069-fa84e94dd930",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("948faa72-2854-485e-a759-aa0298388c46",
	"5e55e4a3-b27e-4186-8b06-f3c1a80e496e",
	"00000000-0000-0000-0000-000000000000",
	20,
	7,
	'sequence::solve line: 20');
INSERT INTO ACT_BRK
	VALUES ("948faa72-2854-485e-a759-aa0298388c46");
INSERT INTO ACT_BLK
	VALUES ("d515feaa-0a44-4bd4-918d-0bc5229f8b14",
	0,
	0,
	0,
	'',
	'',
	'',
	27,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f53eda61-3539-466b-8069-fa84e94dd930",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("146db3f6-7c80-47ef-9251-d0dc801d368a",
	"d515feaa-0a44-4bd4-918d-0bc5229f8b14",
	"00000000-0000-0000-0000-000000000000",
	27,
	5,
	'sequence::solve line: 27');
INSERT INTO ACT_AI
	VALUES ("146db3f6-7c80-47ef-9251-d0dc801d368a",
	"eb13a21e-74de-427f-8b6d-4b14352d3781",
	"de0ef819-407b-42a8-a0d4-2b0fd3b5ea29",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("de0ef819-407b-42a8-a0d4-2b0fd3b5ea29",
	1,
	1,
	27,
	5,
	5,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d515feaa-0a44-4bd4-918d-0bc5229f8b14");
INSERT INTO V_TVL
	VALUES ("de0ef819-407b-42a8-a0d4-2b0fd3b5ea29",
	"14481c00-495c-49f2-b083-a35acadd00ba");
INSERT INTO V_VAL
	VALUES ("eb13a21e-74de-427f-8b6d-4b14352d3781",
	0,
	0,
	27,
	18,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"d515feaa-0a44-4bd4-918d-0bc5229f8b14");
INSERT INTO V_TRV
	VALUES ("eb13a21e-74de-427f-8b6d-4b14352d3781",
	"988ea75b-996b-4e63-bf03-9c9766e885a8",
	"59d76ff3-856b-4f05-8739-e9e7ef2e45a3",
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("14481c00-495c-49f2-b083-a35acadd00ba",
	"d515feaa-0a44-4bd4-918d-0bc5229f8b14",
	'k',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("14481c00-495c-49f2-b083-a35acadd00ba",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("9e1d8c2d-f0ef-4b92-9670-b77413c0a66e",
	27,
	5,
	5,
	"14481c00-495c-49f2-b083-a35acadd00ba");
INSERT INTO ACT_BLK
	VALUES ("190b050e-240e-43d2-9ca3-e4337686df78",
	0,
	0,
	0,
	'',
	'',
	'',
	31,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f53eda61-3539-466b-8069-fa84e94dd930",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("98996435-72d9-412a-944b-fa22773483ee",
	"190b050e-240e-43d2-9ca3-e4337686df78",
	"00000000-0000-0000-0000-000000000000",
	31,
	5,
	'sequence::solve line: 31');
INSERT INTO ACT_BRK
	VALUES ("98996435-72d9-412a-944b-fa22773483ee");
INSERT INTO O_TFR
	VALUES ("988ea75b-996b-4e63-bf03-9c9766e885a8",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	'solve_by_elimination',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	1,
	'temperature = 0;
select one row related by self->ROW[R1];
if ( not_empty row )
  temperature = row.eliminate();
else
  select one column related by self->COLUMN[R1];
  if ( not_empty column )
    temperature = column.eliminate();
  else
    select one box related by self->BOX[R1];
    if ( not_empty box )
      temperature = box.eliminate();
    else
      LOG::LogFailure( message:"could not eliminate related sequence" );
    end if;
  end if;
end if;
return temperature;

',
	1,
	'',
	"a76fd039-37b9-41cc-9e9a-ea4943cde168");
INSERT INTO ACT_OPB
	VALUES ("68756407-230c-42d9-9ead-afaefeba6f34",
	"988ea75b-996b-4e63-bf03-9c9766e885a8");
INSERT INTO ACT_ACT
	VALUES ("68756407-230c-42d9-9ead-afaefeba6f34",
	'operation',
	0,
	"01602ba5-e1f2-4e53-96d2-8a545a451281",
	"00000000-0000-0000-0000-000000000000",
	0,
	'sequence::solve_by_elimination',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("01602ba5-e1f2-4e53-96d2-8a545a451281",
	1,
	0,
	0,
	'',
	'',
	'',
	18,
	1,
	2,
	33,
	0,
	0,
	2,
	37,
	0,
	0,
	0,
	0,
	0,
	"68756407-230c-42d9-9ead-afaefeba6f34",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("6bbd9b60-2b38-4d7f-80c9-b130ba2a6c47",
	"01602ba5-e1f2-4e53-96d2-8a545a451281",
	"67123f7b-e4e9-44f3-a704-09864c32e384",
	1,
	1,
	'sequence::solve_by_elimination line: 1');
INSERT INTO ACT_AI
	VALUES ("6bbd9b60-2b38-4d7f-80c9-b130ba2a6c47",
	"ea8e1fd4-55e3-4560-a1c6-a5c578d36eff",
	"7da52e27-4b9d-4075-9550-21e4294d150b",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("67123f7b-e4e9-44f3-a704-09864c32e384",
	"01602ba5-e1f2-4e53-96d2-8a545a451281",
	"792e4b72-e0de-4b89-b873-73f4db65db77",
	2,
	1,
	'sequence::solve_by_elimination line: 2');
INSERT INTO ACT_SEL
	VALUES ("67123f7b-e4e9-44f3-a704-09864c32e384",
	"03ff11bf-41d1-47b7-89e7-ed4d88ed5f59",
	1,
	'one',
	"b1559a33-fd6c-4765-9c56-47d33283fed0");
INSERT INTO ACT_SR
	VALUES ("67123f7b-e4e9-44f3-a704-09864c32e384");
INSERT INTO ACT_LNK
	VALUES ("59dcb455-f6df-4fd9-8393-3fb6e4939213",
	'',
	"67123f7b-e4e9-44f3-a704-09864c32e384",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	2,
	33,
	2,
	37,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("792e4b72-e0de-4b89-b873-73f4db65db77",
	"01602ba5-e1f2-4e53-96d2-8a545a451281",
	"d81e0d8b-ca99-4f32-ae42-434efb9af45a",
	3,
	1,
	'sequence::solve_by_elimination line: 3');
INSERT INTO ACT_IF
	VALUES ("792e4b72-e0de-4b89-b873-73f4db65db77",
	"9b2c7e7a-6ba7-40e9-afba-47b92dba2436",
	"4da19370-44e1-4ce2-b844-8ac7eba6eb32",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("50675c80-9f1f-424c-bfd8-eb6e334f4e79",
	"01602ba5-e1f2-4e53-96d2-8a545a451281",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'sequence::solve_by_elimination line: 5');
INSERT INTO ACT_E
	VALUES ("50675c80-9f1f-424c-bfd8-eb6e334f4e79",
	"d02420b2-e591-4f90-b136-72efafe37c0d",
	"792e4b72-e0de-4b89-b873-73f4db65db77");
INSERT INTO ACT_SMT
	VALUES ("d81e0d8b-ca99-4f32-ae42-434efb9af45a",
	"01602ba5-e1f2-4e53-96d2-8a545a451281",
	"00000000-0000-0000-0000-000000000000",
	18,
	1,
	'sequence::solve_by_elimination line: 18');
INSERT INTO ACT_RET
	VALUES ("d81e0d8b-ca99-4f32-ae42-434efb9af45a",
	"580a55e3-7288-48bd-8e8b-04edaac4f480");
INSERT INTO V_VAL
	VALUES ("7da52e27-4b9d-4075-9550-21e4294d150b",
	1,
	1,
	1,
	1,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"01602ba5-e1f2-4e53-96d2-8a545a451281");
INSERT INTO V_TVL
	VALUES ("7da52e27-4b9d-4075-9550-21e4294d150b",
	"774cd8ad-4d27-40a9-a90b-3582ab6b26b3");
INSERT INTO V_VAL
	VALUES ("ea8e1fd4-55e3-4560-a1c6-a5c578d36eff",
	0,
	0,
	1,
	15,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"01602ba5-e1f2-4e53-96d2-8a545a451281");
INSERT INTO V_LIN
	VALUES ("ea8e1fd4-55e3-4560-a1c6-a5c578d36eff",
	'0');
INSERT INTO V_VAL
	VALUES ("b1559a33-fd6c-4765-9c56-47d33283fed0",
	0,
	0,
	2,
	27,
	30,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"01602ba5-e1f2-4e53-96d2-8a545a451281");
INSERT INTO V_IRF
	VALUES ("b1559a33-fd6c-4765-9c56-47d33283fed0",
	"300e4d58-5315-486f-b6e8-e1f45ce71383");
INSERT INTO V_VAL
	VALUES ("f5702a35-b019-4c1d-8172-f7781f13ed33",
	0,
	0,
	3,
	16,
	18,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"01602ba5-e1f2-4e53-96d2-8a545a451281");
INSERT INTO V_IRF
	VALUES ("f5702a35-b019-4c1d-8172-f7781f13ed33",
	"03ff11bf-41d1-47b7-89e7-ed4d88ed5f59");
INSERT INTO V_VAL
	VALUES ("4da19370-44e1-4ce2-b844-8ac7eba6eb32",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"01602ba5-e1f2-4e53-96d2-8a545a451281");
INSERT INTO V_UNY
	VALUES ("4da19370-44e1-4ce2-b844-8ac7eba6eb32",
	"f5702a35-b019-4c1d-8172-f7781f13ed33",
	'not_empty');
INSERT INTO V_VAL
	VALUES ("580a55e3-7288-48bd-8e8b-04edaac4f480",
	0,
	0,
	18,
	8,
	18,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"01602ba5-e1f2-4e53-96d2-8a545a451281");
INSERT INTO V_TVL
	VALUES ("580a55e3-7288-48bd-8e8b-04edaac4f480",
	"774cd8ad-4d27-40a9-a90b-3582ab6b26b3");
INSERT INTO V_VAR
	VALUES ("774cd8ad-4d27-40a9-a90b-3582ab6b26b3",
	"01602ba5-e1f2-4e53-96d2-8a545a451281",
	'temperature',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("774cd8ad-4d27-40a9-a90b-3582ab6b26b3",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("61ffdae8-cf3c-456c-a23e-cdeb022c85af",
	1,
	1,
	11,
	"774cd8ad-4d27-40a9-a90b-3582ab6b26b3");
INSERT INTO V_LOC
	VALUES ("c080b2d8-0f3a-4b7a-8e84-a28494d58cf9",
	4,
	3,
	13,
	"774cd8ad-4d27-40a9-a90b-3582ab6b26b3");
INSERT INTO V_LOC
	VALUES ("6547844a-f9e6-4109-b789-ab5c42379ae7",
	8,
	5,
	15,
	"774cd8ad-4d27-40a9-a90b-3582ab6b26b3");
INSERT INTO V_LOC
	VALUES ("4ddc37e3-e93d-4e89-80e2-b318b65ed8dd",
	12,
	7,
	17,
	"774cd8ad-4d27-40a9-a90b-3582ab6b26b3");
INSERT INTO V_LOC
	VALUES ("1d744e9b-6666-4efc-b20c-3b9d5da9597e",
	18,
	8,
	18,
	"774cd8ad-4d27-40a9-a90b-3582ab6b26b3");
INSERT INTO V_VAR
	VALUES ("03ff11bf-41d1-47b7-89e7-ed4d88ed5f59",
	"01602ba5-e1f2-4e53-96d2-8a545a451281",
	'row',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("03ff11bf-41d1-47b7-89e7-ed4d88ed5f59",
	0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("768346e7-0677-4e69-9fbd-0ab1b9efa1cf",
	2,
	12,
	14,
	"03ff11bf-41d1-47b7-89e7-ed4d88ed5f59");
INSERT INTO V_LOC
	VALUES ("2e35bf63-cf78-442f-b375-4321a1b61a0d",
	4,
	17,
	19,
	"03ff11bf-41d1-47b7-89e7-ed4d88ed5f59");
INSERT INTO V_VAR
	VALUES ("300e4d58-5315-486f-b6e8-e1f45ce71383",
	"01602ba5-e1f2-4e53-96d2-8a545a451281",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("300e4d58-5315-486f-b6e8-e1f45ce71383",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO ACT_BLK
	VALUES ("9b2c7e7a-6ba7-40e9-afba-47b92dba2436",
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"68756407-230c-42d9-9ead-afaefeba6f34",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c0084cbc-dca2-43d8-b7b2-939a0d0f242f",
	"9b2c7e7a-6ba7-40e9-afba-47b92dba2436",
	"00000000-0000-0000-0000-000000000000",
	4,
	3,
	'sequence::solve_by_elimination line: 4');
INSERT INTO ACT_AI
	VALUES ("c0084cbc-dca2-43d8-b7b2-939a0d0f242f",
	"8b3607dc-8278-4318-af99-1dfe42759414",
	"f29165bc-e253-45eb-a6ac-b8fe0370a7af",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("f29165bc-e253-45eb-a6ac-b8fe0370a7af",
	1,
	0,
	4,
	3,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9b2c7e7a-6ba7-40e9-afba-47b92dba2436");
INSERT INTO V_TVL
	VALUES ("f29165bc-e253-45eb-a6ac-b8fe0370a7af",
	"774cd8ad-4d27-40a9-a90b-3582ab6b26b3");
INSERT INTO V_VAL
	VALUES ("8b3607dc-8278-4318-af99-1dfe42759414",
	0,
	0,
	4,
	21,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9b2c7e7a-6ba7-40e9-afba-47b92dba2436");
INSERT INTO V_TRV
	VALUES ("8b3607dc-8278-4318-af99-1dfe42759414",
	"a96f5d87-216f-4cae-a278-9bd89e071d22",
	"03ff11bf-41d1-47b7-89e7-ed4d88ed5f59",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("d02420b2-e591-4f90-b136-72efafe37c0d",
	1,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	6,
	38,
	0,
	0,
	6,
	45,
	0,
	0,
	0,
	0,
	0,
	"68756407-230c-42d9-9ead-afaefeba6f34",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4aa2e199-67cb-49e8-aba0-181ba7dc1f21",
	"d02420b2-e591-4f90-b136-72efafe37c0d",
	"0b16da38-f4e5-49e0-b999-0fad1c32690d",
	6,
	3,
	'sequence::solve_by_elimination line: 6');
INSERT INTO ACT_SEL
	VALUES ("4aa2e199-67cb-49e8-aba0-181ba7dc1f21",
	"a3864bc8-163d-4968-a1eb-6e3b83254276",
	1,
	'one',
	"ce9823ec-abff-4a83-a781-07b1a945ce59");
INSERT INTO ACT_SR
	VALUES ("4aa2e199-67cb-49e8-aba0-181ba7dc1f21");
INSERT INTO ACT_LNK
	VALUES ("135b2c52-0cdc-4ade-83ca-a05f8eb24538",
	'',
	"4aa2e199-67cb-49e8-aba0-181ba7dc1f21",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	6,
	38,
	6,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0b16da38-f4e5-49e0-b999-0fad1c32690d",
	"d02420b2-e591-4f90-b136-72efafe37c0d",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'sequence::solve_by_elimination line: 7');
INSERT INTO ACT_IF
	VALUES ("0b16da38-f4e5-49e0-b999-0fad1c32690d",
	"59b734a0-6678-42b5-9ed9-7e1540799229",
	"7c5d4579-82f0-4e1c-bef0-1edb2913c1a0",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("54aa5eea-7a32-4ff5-b0d2-9a81324a973d",
	"d02420b2-e591-4f90-b136-72efafe37c0d",
	"00000000-0000-0000-0000-000000000000",
	9,
	3,
	'sequence::solve_by_elimination line: 9');
INSERT INTO ACT_E
	VALUES ("54aa5eea-7a32-4ff5-b0d2-9a81324a973d",
	"102f6225-5c9e-4f92-8fed-e6a91cbca9e7",
	"0b16da38-f4e5-49e0-b999-0fad1c32690d");
INSERT INTO V_VAL
	VALUES ("ce9823ec-abff-4a83-a781-07b1a945ce59",
	0,
	0,
	6,
	32,
	35,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"d02420b2-e591-4f90-b136-72efafe37c0d");
INSERT INTO V_IRF
	VALUES ("ce9823ec-abff-4a83-a781-07b1a945ce59",
	"300e4d58-5315-486f-b6e8-e1f45ce71383");
INSERT INTO V_VAL
	VALUES ("079c0758-9a59-4019-8a27-eb74fea418e9",
	0,
	0,
	7,
	18,
	23,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"d02420b2-e591-4f90-b136-72efafe37c0d");
INSERT INTO V_IRF
	VALUES ("079c0758-9a59-4019-8a27-eb74fea418e9",
	"a3864bc8-163d-4968-a1eb-6e3b83254276");
INSERT INTO V_VAL
	VALUES ("7c5d4579-82f0-4e1c-bef0-1edb2913c1a0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"d02420b2-e591-4f90-b136-72efafe37c0d");
INSERT INTO V_UNY
	VALUES ("7c5d4579-82f0-4e1c-bef0-1edb2913c1a0",
	"079c0758-9a59-4019-8a27-eb74fea418e9",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("a3864bc8-163d-4968-a1eb-6e3b83254276",
	"d02420b2-e591-4f90-b136-72efafe37c0d",
	'column',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("a3864bc8-163d-4968-a1eb-6e3b83254276",
	0,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_LOC
	VALUES ("a58f256b-06d7-4cea-b3f5-afcea940bf33",
	6,
	14,
	19,
	"a3864bc8-163d-4968-a1eb-6e3b83254276");
INSERT INTO V_LOC
	VALUES ("ca51255f-f46b-4edb-be5d-b89c90542961",
	8,
	19,
	24,
	"a3864bc8-163d-4968-a1eb-6e3b83254276");
INSERT INTO ACT_BLK
	VALUES ("59b734a0-6678-42b5-9ed9-7e1540799229",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"68756407-230c-42d9-9ead-afaefeba6f34",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("aea75ecd-faea-43eb-8ec1-c67e9d9a9389",
	"59b734a0-6678-42b5-9ed9-7e1540799229",
	"00000000-0000-0000-0000-000000000000",
	8,
	5,
	'sequence::solve_by_elimination line: 8');
INSERT INTO ACT_AI
	VALUES ("aea75ecd-faea-43eb-8ec1-c67e9d9a9389",
	"ec7f7d7e-0a12-49ac-9adf-eab87d6960d5",
	"a53a1357-6f84-4f8a-86ef-b26ad7de6e72",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("a53a1357-6f84-4f8a-86ef-b26ad7de6e72",
	1,
	0,
	8,
	5,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"59b734a0-6678-42b5-9ed9-7e1540799229");
INSERT INTO V_TVL
	VALUES ("a53a1357-6f84-4f8a-86ef-b26ad7de6e72",
	"774cd8ad-4d27-40a9-a90b-3582ab6b26b3");
INSERT INTO V_VAL
	VALUES ("ec7f7d7e-0a12-49ac-9adf-eab87d6960d5",
	0,
	0,
	8,
	26,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"59b734a0-6678-42b5-9ed9-7e1540799229");
INSERT INTO V_TRV
	VALUES ("ec7f7d7e-0a12-49ac-9adf-eab87d6960d5",
	"3bc8ba55-c728-4dd2-9472-84165cae4da9",
	"a3864bc8-163d-4968-a1eb-6e3b83254276",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("102f6225-5c9e-4f92-8fed-e6a91cbca9e7",
	1,
	0,
	0,
	'',
	'',
	'',
	13,
	5,
	10,
	37,
	0,
	0,
	10,
	41,
	0,
	0,
	0,
	0,
	0,
	"68756407-230c-42d9-9ead-afaefeba6f34",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b89784c0-1454-4f1f-886b-c5e5bee6cbc6",
	"102f6225-5c9e-4f92-8fed-e6a91cbca9e7",
	"bd1eea2f-60c8-46a0-aa96-8e098e869fa4",
	10,
	5,
	'sequence::solve_by_elimination line: 10');
INSERT INTO ACT_SEL
	VALUES ("b89784c0-1454-4f1f-886b-c5e5bee6cbc6",
	"c1462dab-5892-4928-ad48-53db3bcb185c",
	1,
	'one',
	"b1ef8e92-14f2-4d55-8fcd-63d98a8fafb9");
INSERT INTO ACT_SR
	VALUES ("b89784c0-1454-4f1f-886b-c5e5bee6cbc6");
INSERT INTO ACT_LNK
	VALUES ("49e65f36-78b5-48dd-9b14-06e5d34e67ba",
	'',
	"b89784c0-1454-4f1f-886b-c5e5bee6cbc6",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	10,
	37,
	10,
	41,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("bd1eea2f-60c8-46a0-aa96-8e098e869fa4",
	"102f6225-5c9e-4f92-8fed-e6a91cbca9e7",
	"00000000-0000-0000-0000-000000000000",
	11,
	5,
	'sequence::solve_by_elimination line: 11');
INSERT INTO ACT_IF
	VALUES ("bd1eea2f-60c8-46a0-aa96-8e098e869fa4",
	"93b04e68-6e6d-4aa0-9e94-59ef8a165506",
	"dd0434a5-e494-4af1-b86c-cc8a7519fbb5",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b6d7fed0-74d6-4b33-8a08-3f132d921629",
	"102f6225-5c9e-4f92-8fed-e6a91cbca9e7",
	"00000000-0000-0000-0000-000000000000",
	13,
	5,
	'sequence::solve_by_elimination line: 13');
INSERT INTO ACT_E
	VALUES ("b6d7fed0-74d6-4b33-8a08-3f132d921629",
	"7c62a0c7-2281-4e29-a788-0a282f0d6c2c",
	"bd1eea2f-60c8-46a0-aa96-8e098e869fa4");
INSERT INTO V_VAL
	VALUES ("b1ef8e92-14f2-4d55-8fcd-63d98a8fafb9",
	0,
	0,
	10,
	31,
	34,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"102f6225-5c9e-4f92-8fed-e6a91cbca9e7");
INSERT INTO V_IRF
	VALUES ("b1ef8e92-14f2-4d55-8fcd-63d98a8fafb9",
	"300e4d58-5315-486f-b6e8-e1f45ce71383");
INSERT INTO V_VAL
	VALUES ("ff49c2d3-1eb3-4086-b872-31cb8645397c",
	0,
	0,
	11,
	20,
	22,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"102f6225-5c9e-4f92-8fed-e6a91cbca9e7");
INSERT INTO V_IRF
	VALUES ("ff49c2d3-1eb3-4086-b872-31cb8645397c",
	"c1462dab-5892-4928-ad48-53db3bcb185c");
INSERT INTO V_VAL
	VALUES ("dd0434a5-e494-4af1-b86c-cc8a7519fbb5",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"102f6225-5c9e-4f92-8fed-e6a91cbca9e7");
INSERT INTO V_UNY
	VALUES ("dd0434a5-e494-4af1-b86c-cc8a7519fbb5",
	"ff49c2d3-1eb3-4086-b872-31cb8645397c",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("c1462dab-5892-4928-ad48-53db3bcb185c",
	"102f6225-5c9e-4f92-8fed-e6a91cbca9e7",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("c1462dab-5892-4928-ad48-53db3bcb185c",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("6921a721-2aec-40b6-b434-fa3fdf5ad3d7",
	10,
	16,
	18,
	"c1462dab-5892-4928-ad48-53db3bcb185c");
INSERT INTO V_LOC
	VALUES ("2d8ae5ea-8bee-463f-b647-3e781e00638f",
	12,
	21,
	23,
	"c1462dab-5892-4928-ad48-53db3bcb185c");
INSERT INTO ACT_BLK
	VALUES ("93b04e68-6e6d-4aa0-9e94-59ef8a165506",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"68756407-230c-42d9-9ead-afaefeba6f34",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f3958b75-594a-4fb2-a098-c5dd84b464e3",
	"93b04e68-6e6d-4aa0-9e94-59ef8a165506",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	'sequence::solve_by_elimination line: 12');
INSERT INTO ACT_AI
	VALUES ("f3958b75-594a-4fb2-a098-c5dd84b464e3",
	"1adbaf03-25a4-4733-954c-1c1033e97f5b",
	"c272271e-7af2-4738-a209-0a6f73279e5d",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("c272271e-7af2-4738-a209-0a6f73279e5d",
	1,
	0,
	12,
	7,
	17,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"93b04e68-6e6d-4aa0-9e94-59ef8a165506");
INSERT INTO V_TVL
	VALUES ("c272271e-7af2-4738-a209-0a6f73279e5d",
	"774cd8ad-4d27-40a9-a90b-3582ab6b26b3");
INSERT INTO V_VAL
	VALUES ("1adbaf03-25a4-4733-954c-1c1033e97f5b",
	0,
	0,
	12,
	25,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"93b04e68-6e6d-4aa0-9e94-59ef8a165506");
INSERT INTO V_TRV
	VALUES ("1adbaf03-25a4-4733-954c-1c1033e97f5b",
	"95951fd8-2a86-4a4a-b9aa-8e2e2e1bbd9b",
	"c1462dab-5892-4928-ad48-53db3bcb185c",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("7c62a0c7-2281-4e29-a788-0a282f0d6c2c",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	14,
	7,
	14,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"68756407-230c-42d9-9ead-afaefeba6f34",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("23428665-4404-4e2b-82d9-dd48189ab606",
	"7c62a0c7-2281-4e29-a788-0a282f0d6c2c",
	"00000000-0000-0000-0000-000000000000",
	14,
	7,
	'sequence::solve_by_elimination line: 14');
INSERT INTO ACT_BRG
	VALUES ("23428665-4404-4e2b-82d9-dd48189ab606",
	"ea25943b-c6c2-4423-922c-947a3cd960ad",
	14,
	12,
	14,
	7);
INSERT INTO V_VAL
	VALUES ("f1e211e7-67cf-4259-872e-c6e52b6110c8",
	0,
	0,
	14,
	32,
	68,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"7c62a0c7-2281-4e29-a788-0a282f0d6c2c");
INSERT INTO V_LST
	VALUES ("f1e211e7-67cf-4259-872e-c6e52b6110c8",
	'could not eliminate related sequence');
INSERT INTO V_PAR
	VALUES ("f1e211e7-67cf-4259-872e-c6e52b6110c8",
	"23428665-4404-4e2b-82d9-dd48189ab606",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	14,
	24);
INSERT INTO O_TFR
	VALUES ("2f879600-423d-4941-b679-354b28367a87",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	'solve_by_pruning',
	'',
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	1,
	'temperature = 0;
select one row related by self->ROW[R1];
if ( not_empty row )
  temperature = row.prune();
else
  select one column related by self->COLUMN[R1];
  if ( not_empty column )
    temperature = column.prune();
  else
    select one box related by self->BOX[R1];
    if ( not_empty box )
      temperature = box.prune();
    else
      LOG::LogFailure( message:"could not prune related sequence" );
    end if;
  end if;
end if;
return temperature;

',
	1,
	'',
	"988ea75b-996b-4e63-bf03-9c9766e885a8");
INSERT INTO ACT_OPB
	VALUES ("ad8e0b6d-aaf5-40e8-bb7e-b5396bc23936",
	"2f879600-423d-4941-b679-354b28367a87");
INSERT INTO ACT_ACT
	VALUES ("ad8e0b6d-aaf5-40e8-bb7e-b5396bc23936",
	'operation',
	0,
	"9fc57a03-b726-46ea-90fd-25e4d0e87002",
	"00000000-0000-0000-0000-000000000000",
	0,
	'sequence::solve_by_pruning',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("9fc57a03-b726-46ea-90fd-25e4d0e87002",
	1,
	0,
	0,
	'',
	'',
	'',
	18,
	1,
	2,
	33,
	0,
	0,
	2,
	37,
	0,
	0,
	0,
	0,
	0,
	"ad8e0b6d-aaf5-40e8-bb7e-b5396bc23936",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("bd452e5c-49e0-46b3-a0af-13b954d00511",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002",
	"36753e75-9fc3-48bf-811c-2c5786aeefb4",
	1,
	1,
	'sequence::solve_by_pruning line: 1');
INSERT INTO ACT_AI
	VALUES ("bd452e5c-49e0-46b3-a0af-13b954d00511",
	"809e2842-7f3a-462a-af5a-0671b036a89f",
	"d5faabdc-d5aa-4ebc-895f-b813482af5fc",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("36753e75-9fc3-48bf-811c-2c5786aeefb4",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002",
	"cfc18cd5-f20b-42c0-99b4-3ac03b4df17b",
	2,
	1,
	'sequence::solve_by_pruning line: 2');
INSERT INTO ACT_SEL
	VALUES ("36753e75-9fc3-48bf-811c-2c5786aeefb4",
	"f621bfb3-7aff-4307-b2b8-459dd346686b",
	1,
	'one',
	"f80ccdd1-0c8a-49aa-a248-e033b37e9107");
INSERT INTO ACT_SR
	VALUES ("36753e75-9fc3-48bf-811c-2c5786aeefb4");
INSERT INTO ACT_LNK
	VALUES ("a7c3bc1a-feb5-476e-a87d-e104b4a8ff2b",
	'',
	"36753e75-9fc3-48bf-811c-2c5786aeefb4",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	2,
	33,
	2,
	37,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("cfc18cd5-f20b-42c0-99b4-3ac03b4df17b",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002",
	"987f1e81-85db-4461-a60d-7641542993ea",
	3,
	1,
	'sequence::solve_by_pruning line: 3');
INSERT INTO ACT_IF
	VALUES ("cfc18cd5-f20b-42c0-99b4-3ac03b4df17b",
	"0feafe61-38dd-4df3-92f9-d8149a02c739",
	"7fa8fc30-06bd-4190-b99c-9590464ddb7c",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3d6f3e89-fe25-4cba-a07a-37663325e537",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'sequence::solve_by_pruning line: 5');
INSERT INTO ACT_E
	VALUES ("3d6f3e89-fe25-4cba-a07a-37663325e537",
	"6195b1da-c1db-4141-969d-b3612fdf8197",
	"cfc18cd5-f20b-42c0-99b4-3ac03b4df17b");
INSERT INTO ACT_SMT
	VALUES ("987f1e81-85db-4461-a60d-7641542993ea",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002",
	"00000000-0000-0000-0000-000000000000",
	18,
	1,
	'sequence::solve_by_pruning line: 18');
INSERT INTO ACT_RET
	VALUES ("987f1e81-85db-4461-a60d-7641542993ea",
	"63cf7a19-02a0-45b6-8766-55cbfc965b54");
INSERT INTO V_VAL
	VALUES ("d5faabdc-d5aa-4ebc-895f-b813482af5fc",
	1,
	1,
	1,
	1,
	11,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002");
INSERT INTO V_TVL
	VALUES ("d5faabdc-d5aa-4ebc-895f-b813482af5fc",
	"0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd");
INSERT INTO V_VAL
	VALUES ("809e2842-7f3a-462a-af5a-0671b036a89f",
	0,
	0,
	1,
	15,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002");
INSERT INTO V_LIN
	VALUES ("809e2842-7f3a-462a-af5a-0671b036a89f",
	'0');
INSERT INTO V_VAL
	VALUES ("f80ccdd1-0c8a-49aa-a248-e033b37e9107",
	0,
	0,
	2,
	27,
	30,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002");
INSERT INTO V_IRF
	VALUES ("f80ccdd1-0c8a-49aa-a248-e033b37e9107",
	"47a7c93c-abd8-4465-8f41-2e0fe2bd8dfc");
INSERT INTO V_VAL
	VALUES ("5fba0477-43f6-4878-8c55-c0c2d2f300a5",
	0,
	0,
	3,
	16,
	18,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002");
INSERT INTO V_IRF
	VALUES ("5fba0477-43f6-4878-8c55-c0c2d2f300a5",
	"f621bfb3-7aff-4307-b2b8-459dd346686b");
INSERT INTO V_VAL
	VALUES ("7fa8fc30-06bd-4190-b99c-9590464ddb7c",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002");
INSERT INTO V_UNY
	VALUES ("7fa8fc30-06bd-4190-b99c-9590464ddb7c",
	"5fba0477-43f6-4878-8c55-c0c2d2f300a5",
	'not_empty');
INSERT INTO V_VAL
	VALUES ("63cf7a19-02a0-45b6-8766-55cbfc965b54",
	0,
	0,
	18,
	8,
	18,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002");
INSERT INTO V_TVL
	VALUES ("63cf7a19-02a0-45b6-8766-55cbfc965b54",
	"0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd");
INSERT INTO V_VAR
	VALUES ("0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002",
	'temperature',
	1,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d");
INSERT INTO V_TRN
	VALUES ("0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("26a4210e-1975-4671-ba6a-2834c5582159",
	1,
	1,
	11,
	"0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd");
INSERT INTO V_LOC
	VALUES ("f2d8c101-d259-48c1-965a-a97e53a39548",
	4,
	3,
	13,
	"0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd");
INSERT INTO V_LOC
	VALUES ("8fcd4ba9-4592-474a-9dd8-f25a49f01731",
	8,
	5,
	15,
	"0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd");
INSERT INTO V_LOC
	VALUES ("2b19816b-da0a-4483-b904-31cc131a2167",
	12,
	7,
	17,
	"0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd");
INSERT INTO V_LOC
	VALUES ("b19d4eb9-2f1b-4e3f-b5b8-a3984b464f66",
	18,
	8,
	18,
	"0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd");
INSERT INTO V_VAR
	VALUES ("f621bfb3-7aff-4307-b2b8-459dd346686b",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002",
	'row',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("f621bfb3-7aff-4307-b2b8-459dd346686b",
	0,
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e");
INSERT INTO V_LOC
	VALUES ("fcd25ec0-d39c-49cf-afcb-2a646db82db6",
	2,
	12,
	14,
	"f621bfb3-7aff-4307-b2b8-459dd346686b");
INSERT INTO V_LOC
	VALUES ("969eab16-4fb0-426a-b047-7e1d42c547f6",
	4,
	17,
	19,
	"f621bfb3-7aff-4307-b2b8-459dd346686b");
INSERT INTO V_VAR
	VALUES ("47a7c93c-abd8-4465-8f41-2e0fe2bd8dfc",
	"9fc57a03-b726-46ea-90fd-25e4d0e87002",
	'self',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("47a7c93c-abd8-4465-8f41-2e0fe2bd8dfc",
	0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO ACT_BLK
	VALUES ("0feafe61-38dd-4df3-92f9-d8149a02c739",
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ad8e0b6d-aaf5-40e8-bb7e-b5396bc23936",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7711ab7b-bb7f-485a-ba07-52c7ff6f9984",
	"0feafe61-38dd-4df3-92f9-d8149a02c739",
	"00000000-0000-0000-0000-000000000000",
	4,
	3,
	'sequence::solve_by_pruning line: 4');
INSERT INTO ACT_AI
	VALUES ("7711ab7b-bb7f-485a-ba07-52c7ff6f9984",
	"9999164a-5b9b-412f-9afd-f880a00d7862",
	"47528b1b-b091-403f-972e-4756cd35c475",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("47528b1b-b091-403f-972e-4756cd35c475",
	1,
	0,
	4,
	3,
	13,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0feafe61-38dd-4df3-92f9-d8149a02c739");
INSERT INTO V_TVL
	VALUES ("47528b1b-b091-403f-972e-4756cd35c475",
	"0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd");
INSERT INTO V_VAL
	VALUES ("9999164a-5b9b-412f-9afd-f880a00d7862",
	0,
	0,
	4,
	21,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"0feafe61-38dd-4df3-92f9-d8149a02c739");
INSERT INTO V_TRV
	VALUES ("9999164a-5b9b-412f-9afd-f880a00d7862",
	"450e3398-ff08-488c-94ba-b761702968e3",
	"f621bfb3-7aff-4307-b2b8-459dd346686b",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("6195b1da-c1db-4141-969d-b3612fdf8197",
	1,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	6,
	38,
	0,
	0,
	6,
	45,
	0,
	0,
	0,
	0,
	0,
	"ad8e0b6d-aaf5-40e8-bb7e-b5396bc23936",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("21293d4f-d42e-426e-8703-ae501625e300",
	"6195b1da-c1db-4141-969d-b3612fdf8197",
	"4b165f35-f3d5-4953-b3e5-59936922e0e9",
	6,
	3,
	'sequence::solve_by_pruning line: 6');
INSERT INTO ACT_SEL
	VALUES ("21293d4f-d42e-426e-8703-ae501625e300",
	"c22d220a-05e2-417e-b7a9-a42b41575a00",
	1,
	'one',
	"0f16cc8c-febe-47b8-b55c-7540cef45947");
INSERT INTO ACT_SR
	VALUES ("21293d4f-d42e-426e-8703-ae501625e300");
INSERT INTO ACT_LNK
	VALUES ("f1e778f5-474b-4d6b-96e3-8eb4fca21e44",
	'',
	"21293d4f-d42e-426e-8703-ae501625e300",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	6,
	38,
	6,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("4b165f35-f3d5-4953-b3e5-59936922e0e9",
	"6195b1da-c1db-4141-969d-b3612fdf8197",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'sequence::solve_by_pruning line: 7');
INSERT INTO ACT_IF
	VALUES ("4b165f35-f3d5-4953-b3e5-59936922e0e9",
	"3ec2edac-7add-4553-a901-e2f23bfea3fa",
	"ebb73dfe-1256-4e40-8ec0-cf4e4e1e142e",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("92d8dee4-7bbc-4581-bdf3-1fa7ba8af562",
	"6195b1da-c1db-4141-969d-b3612fdf8197",
	"00000000-0000-0000-0000-000000000000",
	9,
	3,
	'sequence::solve_by_pruning line: 9');
INSERT INTO ACT_E
	VALUES ("92d8dee4-7bbc-4581-bdf3-1fa7ba8af562",
	"8add4d32-a4f0-4e6b-9205-d4512fa227c9",
	"4b165f35-f3d5-4953-b3e5-59936922e0e9");
INSERT INTO V_VAL
	VALUES ("0f16cc8c-febe-47b8-b55c-7540cef45947",
	0,
	0,
	6,
	32,
	35,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"6195b1da-c1db-4141-969d-b3612fdf8197");
INSERT INTO V_IRF
	VALUES ("0f16cc8c-febe-47b8-b55c-7540cef45947",
	"47a7c93c-abd8-4465-8f41-2e0fe2bd8dfc");
INSERT INTO V_VAL
	VALUES ("8fff967d-49c0-4f8e-9e41-a56f18c31ae2",
	0,
	0,
	7,
	18,
	23,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"6195b1da-c1db-4141-969d-b3612fdf8197");
INSERT INTO V_IRF
	VALUES ("8fff967d-49c0-4f8e-9e41-a56f18c31ae2",
	"c22d220a-05e2-417e-b7a9-a42b41575a00");
INSERT INTO V_VAL
	VALUES ("ebb73dfe-1256-4e40-8ec0-cf4e4e1e142e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"6195b1da-c1db-4141-969d-b3612fdf8197");
INSERT INTO V_UNY
	VALUES ("ebb73dfe-1256-4e40-8ec0-cf4e4e1e142e",
	"8fff967d-49c0-4f8e-9e41-a56f18c31ae2",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("c22d220a-05e2-417e-b7a9-a42b41575a00",
	"6195b1da-c1db-4141-969d-b3612fdf8197",
	'column',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("c22d220a-05e2-417e-b7a9-a42b41575a00",
	0,
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5");
INSERT INTO V_LOC
	VALUES ("13f35600-0172-4c9c-854c-6632ea1afeeb",
	6,
	14,
	19,
	"c22d220a-05e2-417e-b7a9-a42b41575a00");
INSERT INTO V_LOC
	VALUES ("1b5f6d1c-25be-452b-aeaa-4dd5e8ddcc46",
	8,
	19,
	24,
	"c22d220a-05e2-417e-b7a9-a42b41575a00");
INSERT INTO ACT_BLK
	VALUES ("3ec2edac-7add-4553-a901-e2f23bfea3fa",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ad8e0b6d-aaf5-40e8-bb7e-b5396bc23936",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c86bcb26-c0f4-4cf0-81ca-730279fc663e",
	"3ec2edac-7add-4553-a901-e2f23bfea3fa",
	"00000000-0000-0000-0000-000000000000",
	8,
	5,
	'sequence::solve_by_pruning line: 8');
INSERT INTO ACT_AI
	VALUES ("c86bcb26-c0f4-4cf0-81ca-730279fc663e",
	"15d4bbf8-ad34-439d-9cf3-fd4df231606e",
	"0e1f228a-7de2-4b81-8ecd-9a8f6aa14e6e",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("0e1f228a-7de2-4b81-8ecd-9a8f6aa14e6e",
	1,
	0,
	8,
	5,
	15,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3ec2edac-7add-4553-a901-e2f23bfea3fa");
INSERT INTO V_TVL
	VALUES ("0e1f228a-7de2-4b81-8ecd-9a8f6aa14e6e",
	"0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd");
INSERT INTO V_VAL
	VALUES ("15d4bbf8-ad34-439d-9cf3-fd4df231606e",
	0,
	0,
	8,
	26,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"3ec2edac-7add-4553-a901-e2f23bfea3fa");
INSERT INTO V_TRV
	VALUES ("15d4bbf8-ad34-439d-9cf3-fd4df231606e",
	"477fe3eb-500d-4bd6-b226-d1d06d05d9ea",
	"c22d220a-05e2-417e-b7a9-a42b41575a00",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("8add4d32-a4f0-4e6b-9205-d4512fa227c9",
	1,
	0,
	0,
	'',
	'',
	'',
	13,
	5,
	10,
	37,
	0,
	0,
	10,
	41,
	0,
	0,
	0,
	0,
	0,
	"ad8e0b6d-aaf5-40e8-bb7e-b5396bc23936",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("a4bb2192-a22c-4c08-85cc-45336cc31a4a",
	"8add4d32-a4f0-4e6b-9205-d4512fa227c9",
	"4fce6f0a-def7-4f94-9f3a-d0ba64f7c52a",
	10,
	5,
	'sequence::solve_by_pruning line: 10');
INSERT INTO ACT_SEL
	VALUES ("a4bb2192-a22c-4c08-85cc-45336cc31a4a",
	"6f9ea09d-1ed1-43cb-b6ef-ce9ecb822f07",
	1,
	'one',
	"85881b75-55c3-4342-b6db-a83f39eb1dc3");
INSERT INTO ACT_SR
	VALUES ("a4bb2192-a22c-4c08-85cc-45336cc31a4a");
INSERT INTO ACT_LNK
	VALUES ("d7ce79e5-4680-45ab-a7d2-4cb554858495",
	'',
	"a4bb2192-a22c-4c08-85cc-45336cc31a4a",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"00000000-0000-0000-0000-000000000000",
	2,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f",
	10,
	37,
	10,
	41,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("4fce6f0a-def7-4f94-9f3a-d0ba64f7c52a",
	"8add4d32-a4f0-4e6b-9205-d4512fa227c9",
	"00000000-0000-0000-0000-000000000000",
	11,
	5,
	'sequence::solve_by_pruning line: 11');
INSERT INTO ACT_IF
	VALUES ("4fce6f0a-def7-4f94-9f3a-d0ba64f7c52a",
	"a3ef72c8-1f2a-4408-a591-790254d85e5b",
	"ebb1848c-3f0d-4b81-b8b6-48c868d354e2",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1dd72bc9-b4f8-4342-9f6f-bd07a1d28f71",
	"8add4d32-a4f0-4e6b-9205-d4512fa227c9",
	"00000000-0000-0000-0000-000000000000",
	13,
	5,
	'sequence::solve_by_pruning line: 13');
INSERT INTO ACT_E
	VALUES ("1dd72bc9-b4f8-4342-9f6f-bd07a1d28f71",
	"aec71c4b-22a3-44a6-a445-00426882f761",
	"4fce6f0a-def7-4f94-9f3a-d0ba64f7c52a");
INSERT INTO V_VAL
	VALUES ("85881b75-55c3-4342-b6db-a83f39eb1dc3",
	0,
	0,
	10,
	31,
	34,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"8add4d32-a4f0-4e6b-9205-d4512fa227c9");
INSERT INTO V_IRF
	VALUES ("85881b75-55c3-4342-b6db-a83f39eb1dc3",
	"47a7c93c-abd8-4465-8f41-2e0fe2bd8dfc");
INSERT INTO V_VAL
	VALUES ("765bcb37-66ce-4bed-aca1-8dfbf8f39263",
	0,
	0,
	11,
	20,
	22,
	0,
	0,
	0,
	0,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa",
	"8add4d32-a4f0-4e6b-9205-d4512fa227c9");
INSERT INTO V_IRF
	VALUES ("765bcb37-66ce-4bed-aca1-8dfbf8f39263",
	"6f9ea09d-1ed1-43cb-b6ef-ce9ecb822f07");
INSERT INTO V_VAL
	VALUES ("ebb1848c-3f0d-4b81-b8b6-48c868d354e2",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	"8add4d32-a4f0-4e6b-9205-d4512fa227c9");
INSERT INTO V_UNY
	VALUES ("ebb1848c-3f0d-4b81-b8b6-48c868d354e2",
	"765bcb37-66ce-4bed-aca1-8dfbf8f39263",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("6f9ea09d-1ed1-43cb-b6ef-ce9ecb822f07",
	"8add4d32-a4f0-4e6b-9205-d4512fa227c9",
	'box',
	1,
	"1a2907d2-496f-482d-ba4d-df818f73d6fa");
INSERT INTO V_INT
	VALUES ("6f9ea09d-1ed1-43cb-b6ef-ce9ecb822f07",
	0,
	"83fd5a00-5820-4fb5-ade7-97f8217b945f");
INSERT INTO V_LOC
	VALUES ("2c89caa0-7265-4998-8274-f455d8a467b7",
	10,
	16,
	18,
	"6f9ea09d-1ed1-43cb-b6ef-ce9ecb822f07");
INSERT INTO V_LOC
	VALUES ("ec317cc9-6d1f-4c71-a0ad-788a6a676c82",
	12,
	21,
	23,
	"6f9ea09d-1ed1-43cb-b6ef-ce9ecb822f07");
INSERT INTO ACT_BLK
	VALUES ("a3ef72c8-1f2a-4408-a591-790254d85e5b",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ad8e0b6d-aaf5-40e8-bb7e-b5396bc23936",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("81d6f761-7d94-48bb-a791-a149cc929808",
	"a3ef72c8-1f2a-4408-a591-790254d85e5b",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	'sequence::solve_by_pruning line: 12');
INSERT INTO ACT_AI
	VALUES ("81d6f761-7d94-48bb-a791-a149cc929808",
	"c7a053e8-b55e-4023-9bd7-d98ad442d194",
	"d928e011-96bc-4f0c-8022-4b3d16efa796",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("d928e011-96bc-4f0c-8022-4b3d16efa796",
	1,
	0,
	12,
	7,
	17,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a3ef72c8-1f2a-4408-a591-790254d85e5b");
INSERT INTO V_TVL
	VALUES ("d928e011-96bc-4f0c-8022-4b3d16efa796",
	"0d9a96f8-2e4f-410d-b8fa-c1ed99de30cd");
INSERT INTO V_VAL
	VALUES ("c7a053e8-b55e-4023-9bd7-d98ad442d194",
	0,
	0,
	12,
	25,
	-1,
	0,
	0,
	0,
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	"a3ef72c8-1f2a-4408-a591-790254d85e5b");
INSERT INTO V_TRV
	VALUES ("c7a053e8-b55e-4023-9bd7-d98ad442d194",
	"30f7d1fd-f731-455f-93b4-963d0aa6e745",
	"6f9ea09d-1ed1-43cb-b6ef-ce9ecb822f07",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("aec71c4b-22a3-44a6-a445-00426882f761",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	14,
	7,
	14,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ad8e0b6d-aaf5-40e8-bb7e-b5396bc23936",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3d0bf22d-1783-492f-a893-3bd145e05892",
	"aec71c4b-22a3-44a6-a445-00426882f761",
	"00000000-0000-0000-0000-000000000000",
	14,
	7,
	'sequence::solve_by_pruning line: 14');
INSERT INTO ACT_BRG
	VALUES ("3d0bf22d-1783-492f-a893-3bd145e05892",
	"ea25943b-c6c2-4423-922c-947a3cd960ad",
	14,
	12,
	14,
	7);
INSERT INTO V_VAL
	VALUES ("2dbecfe4-92bd-468c-9231-612285ea045c",
	0,
	0,
	14,
	32,
	64,
	0,
	0,
	0,
	0,
	"e27a3af8-1f28-4ba6-a876-f718ce67db3c",
	"aec71c4b-22a3-44a6-a445-00426882f761");
INSERT INTO V_LST
	VALUES ("2dbecfe4-92bd-468c-9231-612285ea045c",
	'could not prune related sequence');
INSERT INTO V_PAR
	VALUES ("2dbecfe4-92bd-468c-9231-612285ea045c",
	"3d0bf22d-1783-492f-a893-3bd145e05892",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	14,
	24);
INSERT INTO O_NBATTR
	VALUES ("9ebdc9c2-c4fb-417c-8b51-a6007cc5f2a2",
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO O_BATTR
	VALUES ("9ebdc9c2-c4fb-417c-8b51-a6007cc5f2a2",
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO O_ATTR
	VALUES ("9ebdc9c2-c4fb-417c-8b51-a6007cc5f2a2",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"00000000-0000-0000-0000-000000000000",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"ea4f2014-da78-4798-8130-991e8750cff6",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("48d19dd8-8465-49b9-b4d0-dd14aa6d653f",
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO O_BATTR
	VALUES ("48d19dd8-8465-49b9-b4d0-dd14aa6d653f",
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO O_ATTR
	VALUES ("48d19dd8-8465-49b9-b4d0-dd14aa6d653f",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"9ebdc9c2-c4fb-417c-8b51-a6007cc5f2a2",
	'solved',
	'',
	'',
	'solved',
	0,
	"4e005777-df64-4279-9c02-400e239872b9",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("1d98774f-c8bd-4c43-8f75-530b0ff40265",
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO O_BATTR
	VALUES ("1d98774f-c8bd-4c43-8f75-530b0ff40265",
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO O_ATTR
	VALUES ("1d98774f-c8bd-4c43-8f75-530b0ff40265",
	"03ac2337-ce3a-497f-a3de-92a1101b2208",
	"48d19dd8-8465-49b9-b4d0-dd14aa6d653f",
	'requests',
	'',
	'',
	'requests',
	0,
	"811f1dd7-74f0-407e-b449-939d0de5ee8d",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO O_ID
	VALUES (1,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO O_ID
	VALUES (2,
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO SM_ISM
	VALUES ("0d08100e-6b4d-4cf0-9b6e-4dc31bd909e2",
	"03ac2337-ce3a-497f-a3de-92a1101b2208");
INSERT INTO SM_SM
	VALUES ("0d08100e-6b4d-4cf0-9b6e-4dc31bd909e2",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("0d08100e-6b4d-4cf0-9b6e-4dc31bd909e2");
INSERT INTO SM_LEVT
	VALUES ("fd1f2262-5885-451c-b8f3-8df7fcba6ef1",
	"0d08100e-6b4d-4cf0-9b6e-4dc31bd909e2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("fd1f2262-5885-451c-b8f3-8df7fcba6ef1",
	"0d08100e-6b4d-4cf0-9b6e-4dc31bd909e2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("fd1f2262-5885-451c-b8f3-8df7fcba6ef1",
	"0d08100e-6b4d-4cf0-9b6e-4dc31bd909e2",
	"00000000-0000-0000-0000-000000000000",
	1,
	'update',
	0,
	'',
	'SEQUENCE1',
	'');
INSERT INTO SM_LEVT
	VALUES ("6bc49715-6bb7-45d2-a2af-a0587d7750e0",
	"0d08100e-6b4d-4cf0-9b6e-4dc31bd909e2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("6bc49715-6bb7-45d2-a2af-a0587d7750e0",
	"0d08100e-6b4d-4cf0-9b6e-4dc31bd909e2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("6bc49715-6bb7-45d2-a2af-a0587d7750e0",
	"0d08100e-6b4d-4cf0-9b6e-4dc31bd909e2",
	"00000000-0000-0000-0000-000000000000",
	5,
	'solved',
	0,
	'',
	'SEQUENCE5',
	'');
INSERT INTO R_SUBSUP
	VALUES ("8894c5f7-bffa-4974-ac54-7678f0a478b0");
INSERT INTO R_REL
	VALUES ("8894c5f7-bffa-4974-ac54-7678f0a478b0",
	1,
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO R_SUPER
	VALUES ("03ac2337-ce3a-497f-a3de-92a1101b2208",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"02177cab-7710-46de-8c5a-e70390007257");
INSERT INTO R_RTO
	VALUES ("03ac2337-ce3a-497f-a3de-92a1101b2208",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"02177cab-7710-46de-8c5a-e70390007257",
	-1);
INSERT INTO R_OIR
	VALUES ("03ac2337-ce3a-497f-a3de-92a1101b2208",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"02177cab-7710-46de-8c5a-e70390007257",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SUB
	VALUES ("56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"c48d82af-9cf8-4d31-9439-c92d4a821c0e");
INSERT INTO R_RGO
	VALUES ("56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"c48d82af-9cf8-4d31-9439-c92d4a821c0e");
INSERT INTO R_OIR
	VALUES ("56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"c48d82af-9cf8-4d31-9439-c92d4a821c0e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SUB
	VALUES ("b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"ede511dc-cfdf-46a5-9878-160b09eadee3");
INSERT INTO R_RGO
	VALUES ("b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"ede511dc-cfdf-46a5-9878-160b09eadee3");
INSERT INTO R_OIR
	VALUES ("b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"ede511dc-cfdf-46a5-9878-160b09eadee3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SUB
	VALUES ("83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"0c3d51f1-25e5-435d-ad7c-8fd5fdd8d662");
INSERT INTO R_RGO
	VALUES ("83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"0c3d51f1-25e5-435d-ad7c-8fd5fdd8d662");
INSERT INTO R_OIR
	VALUES ("83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"8894c5f7-bffa-4974-ac54-7678f0a478b0",
	"0c3d51f1-25e5-435d-ad7c-8fd5fdd8d662",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("c9931c97-9acb-4b55-af72-81add52c1825");
INSERT INTO R_REL
	VALUES ("c9931c97-9acb-4b55-af72-81add52c1825",
	2,
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO R_PART
	VALUES ("56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"8f9517c4-2955-4897-834a-e924e660ce47",
	0,
	0,
	'is in');
INSERT INTO O_RTIDA
	VALUES ("b7c46385-7816-4616-9e73-922fad4f4af1",
	"56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	1,
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"8f9517c4-2955-4897-834a-e924e660ce47");
INSERT INTO R_RTO
	VALUES ("56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"8f9517c4-2955-4897-834a-e924e660ce47",
	1);
INSERT INTO R_OIR
	VALUES ("56c54c26-d9b7-409a-83b7-4c701cc02c0e",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"8f9517c4-2955-4897-834a-e924e660ce47",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_FORM
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"c71eb71a-1185-4f96-ad12-9ee546e214e8",
	1,
	0,
	'has');
INSERT INTO R_RGO
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"c71eb71a-1185-4f96-ad12-9ee546e214e8");
INSERT INTO R_OIR
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"c9931c97-9acb-4b55-af72-81add52c1825",
	"c71eb71a-1185-4f96-ad12-9ee546e214e8",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("750a2939-f0a1-475a-a387-d099bd4f6edb");
INSERT INTO R_REL
	VALUES ("750a2939-f0a1-475a-a387-d099bd4f6edb",
	3,
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO R_PART
	VALUES ("b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"97f23a8b-ed88-4a25-a47b-ad74722bf424",
	0,
	0,
	'is in');
INSERT INTO O_RTIDA
	VALUES ("90e0d09a-7fa5-45f0-ac4f-f519aa651f29",
	"b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	1,
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"97f23a8b-ed88-4a25-a47b-ad74722bf424");
INSERT INTO R_RTO
	VALUES ("b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"97f23a8b-ed88-4a25-a47b-ad74722bf424",
	1);
INSERT INTO R_OIR
	VALUES ("b7d2c815-d54e-475a-819c-5d9e6dbc66d5",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"97f23a8b-ed88-4a25-a47b-ad74722bf424",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_FORM
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"5b4c4100-b987-4466-935e-cf1c7446dc95",
	1,
	0,
	'has');
INSERT INTO R_RGO
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"5b4c4100-b987-4466-935e-cf1c7446dc95");
INSERT INTO R_OIR
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"750a2939-f0a1-475a-a387-d099bd4f6edb",
	"5b4c4100-b987-4466-935e-cf1c7446dc95",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("e6cf2b93-d27e-4c83-a459-4307f3d2ce43");
INSERT INTO R_REL
	VALUES ("e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	4,
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO R_PART
	VALUES ("83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"e28c6023-00a6-450c-adc3-0ccb14353a0e",
	0,
	0,
	'is in');
INSERT INTO R_RTO
	VALUES ("83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"e28c6023-00a6-450c-adc3-0ccb14353a0e",
	-1);
INSERT INTO R_OIR
	VALUES ("83fd5a00-5820-4fb5-ade7-97f8217b945f",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"e28c6023-00a6-450c-adc3-0ccb14353a0e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_PART
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"918413df-1a7a-4ac4-b70e-59dae285808e",
	1,
	0,
	'has');
INSERT INTO R_RTO
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"918413df-1a7a-4ac4-b70e-59dae285808e",
	-1);
INSERT INTO R_OIR
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"e6cf2b93-d27e-4c83-a459-4307f3d2ce43",
	"918413df-1a7a-4ac4-b70e-59dae285808e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_ASSOC
	VALUES ("62a93566-2203-4db8-ba18-f7c15ca2072a");
INSERT INTO R_REL
	VALUES ("62a93566-2203-4db8-ba18-f7c15ca2072a",
	8,
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO R_AONE
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"63d41502-a15d-4ab0-b59a-b6d1a1e73f19",
	1,
	1,
	'is eligible for');
INSERT INTO O_RTIDA
	VALUES ("53a62320-a206-4d56-a639-c4592f420548",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	0,
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"63d41502-a15d-4ab0-b59a-b6d1a1e73f19");
INSERT INTO O_RTIDA
	VALUES ("d132eb18-d364-4962-a2a9-487279251e05",
	"e488047e-8d3e-455c-a7e9-29120bad505f",
	0,
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"63d41502-a15d-4ab0-b59a-b6d1a1e73f19");
INSERT INTO R_RTO
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"63d41502-a15d-4ab0-b59a-b6d1a1e73f19",
	0);
INSERT INTO R_OIR
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"63d41502-a15d-4ab0-b59a-b6d1a1e73f19",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_AOTH
	VALUES ("8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"c04bc12c-8d28-4e1f-8b30-835e7f55edc6",
	1,
	1,
	'has eligible');
INSERT INTO O_RTIDA
	VALUES ("53e80efe-cb6c-4332-b046-1ba6f6005b30",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	0,
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"c04bc12c-8d28-4e1f-8b30-835e7f55edc6");
INSERT INTO R_RTO
	VALUES ("8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"c04bc12c-8d28-4e1f-8b30-835e7f55edc6",
	0);
INSERT INTO R_OIR
	VALUES ("8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"c04bc12c-8d28-4e1f-8b30-835e7f55edc6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_ASSR
	VALUES ("7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"bc9dd594-f2f4-4718-be6c-6256312e19a2",
	0);
INSERT INTO R_RGO
	VALUES ("7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"bc9dd594-f2f4-4718-be6c-6256312e19a2");
INSERT INTO R_OIR
	VALUES ("7dfbb9fe-d109-4356-a43c-8a02617ad46a",
	"62a93566-2203-4db8-ba18-f7c15ca2072a",
	"bc9dd594-f2f4-4718-be6c-6256312e19a2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("52e5a3de-5d5d-4eaf-a076-5b96609c9130");
INSERT INTO R_REL
	VALUES ("52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	9,
	'',
	"3d0162a5-1c20-4ddf-8686-ff9d4c06e6a1");
INSERT INTO R_FORM
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"d6ffb906-5a1c-4b12-995d-d59a2b860b9b",
	0,
	1,
	'is answer for');
INSERT INTO R_RGO
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"d6ffb906-5a1c-4b12-995d-d59a2b860b9b");
INSERT INTO R_OIR
	VALUES ("e488047e-8d3e-455c-a7e9-29120bad505f",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"d6ffb906-5a1c-4b12-995d-d59a2b860b9b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_PART
	VALUES ("8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"838d69c7-4354-4e52-ab82-1c85360eb9b8",
	0,
	1,
	'has answer');
INSERT INTO O_RTIDA
	VALUES ("53e80efe-cb6c-4332-b046-1ba6f6005b30",
	"8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	0,
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"838d69c7-4354-4e52-ab82-1c85360eb9b8");
INSERT INTO R_RTO
	VALUES ("8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"838d69c7-4354-4e52-ab82-1c85360eb9b8",
	0);
INSERT INTO R_OIR
	VALUES ("8a59e2de-6f5d-4937-ade5-f1ace45cc756",
	"52e5a3de-5d5d-4eaf-a076-5b96609c9130",
	"838d69c7-4354-4e52-ab82-1c85360eb9b8",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SLD_SDP
	VALUES ("ecb50217-b066-4ecf-a826-866ec62dc0da",
	"a655893d-fe3b-4b0f-b285-cc34425dfefa");
INSERT INTO S_DPK
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	'Datatypes',
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"050ae1c7-4fe8-4036-9266-866162475ade");
INSERT INTO S_DT
	VALUES ("050ae1c7-4fe8-4036-9266-866162475ade",
	"00000000-0000-0000-0000-000000000000",
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("050ae1c7-4fe8-4036-9266-866162475ade",
	0);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"2bce27aa-a40c-4097-806c-bcca0cdac334");
INSERT INTO S_DT
	VALUES ("2bce27aa-a40c-4097-806c-bcca0cdac334",
	"00000000-0000-0000-0000-000000000000",
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("2bce27aa-a40c-4097-806c-bcca0cdac334",
	1);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"c917a3a0-5e13-4d90-ae51-caf66f88e775");
INSERT INTO S_DT
	VALUES ("c917a3a0-5e13-4d90-ae51-caf66f88e775",
	"00000000-0000-0000-0000-000000000000",
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("c917a3a0-5e13-4d90-ae51-caf66f88e775",
	2);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"80dd63f1-9308-4f8a-b38a-fd85188ab47d");
INSERT INTO S_DT
	VALUES ("80dd63f1-9308-4f8a-b38a-fd85188ab47d",
	"00000000-0000-0000-0000-000000000000",
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("80dd63f1-9308-4f8a-b38a-fd85188ab47d",
	3);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"08dd622e-58f4-4c59-80d1-b067316797b1");
INSERT INTO S_DT
	VALUES ("08dd622e-58f4-4c59-80d1-b067316797b1",
	"00000000-0000-0000-0000-000000000000",
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("08dd622e-58f4-4c59-80d1-b067316797b1",
	4);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"65307c11-e2af-4779-9e42-aa3bb3f9d5c3");
INSERT INTO S_DT
	VALUES ("65307c11-e2af-4779-9e42-aa3bb3f9d5c3",
	"00000000-0000-0000-0000-000000000000",
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("65307c11-e2af-4779-9e42-aa3bb3f9d5c3",
	5);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"8d8b769f-e617-4b41-9f14-d3581653f32f");
INSERT INTO S_DT
	VALUES ("8d8b769f-e617-4b41-9f14-d3581653f32f",
	"00000000-0000-0000-0000-000000000000",
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("8d8b769f-e617-4b41-9f14-d3581653f32f",
	6);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"8e0c3427-53b5-4e5e-9341-acbc9cfe5263");
INSERT INTO S_DT
	VALUES ("8e0c3427-53b5-4e5e-9341-acbc9cfe5263",
	"00000000-0000-0000-0000-000000000000",
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("8e0c3427-53b5-4e5e-9341-acbc9cfe5263",
	7);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"2616dc30-6433-4e8f-8b0a-76a77928c045");
INSERT INTO S_DT
	VALUES ("2616dc30-6433-4e8f-8b0a-76a77928c045",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("2616dc30-6433-4e8f-8b0a-76a77928c045",
	8);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"09a6c533-08a7-4b99-9104-408407f90497");
INSERT INTO S_DT
	VALUES ("09a6c533-08a7-4b99-9104-408407f90497",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("09a6c533-08a7-4b99-9104-408407f90497",
	9);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"f0372f26-60f9-4d5e-83cb-46b4c72d3bf6");
INSERT INTO S_DT
	VALUES ("f0372f26-60f9-4d5e-83cb-46b4c72d3bf6",
	"00000000-0000-0000-0000-000000000000",
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("f0372f26-60f9-4d5e-83cb-46b4c72d3bf6",
	10);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"642b0c07-a71d-46d2-be4d-c07e1839c831");
INSERT INTO S_DT
	VALUES ("642b0c07-a71d-46d2-be4d-c07e1839c831",
	"00000000-0000-0000-0000-000000000000",
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("642b0c07-a71d-46d2-be4d-c07e1839c831",
	11);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"4155268d-83fd-47d8-9011-578e0fcc6241");
INSERT INTO S_DT
	VALUES ("4155268d-83fd-47d8-9011-578e0fcc6241",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("4155268d-83fd-47d8-9011-578e0fcc6241",
	12);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"a96a11e8-5278-4837-ba3b-95111a36bcb1");
INSERT INTO S_DT
	VALUES ("a96a11e8-5278-4837-ba3b-95111a36bcb1",
	"00000000-0000-0000-0000-000000000000",
	'component_ref',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("a96a11e8-5278-4837-ba3b-95111a36bcb1",
	13);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"879dbca7-970f-45bd-b4ff-c962a6ff60f0");
INSERT INTO S_DT
	VALUES ("879dbca7-970f-45bd-b4ff-c962a6ff60f0",
	"00000000-0000-0000-0000-000000000000",
	'date',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("879dbca7-970f-45bd-b4ff-c962a6ff60f0",
	"642b0c07-a71d-46d2-be4d-c07e1839c831",
	1);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"9aba0199-0f9f-4da0-a4c4-b495dd26270a");
INSERT INTO S_DT
	VALUES ("9aba0199-0f9f-4da0-a4c4-b495dd26270a",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("9aba0199-0f9f-4da0-a4c4-b495dd26270a",
	"4155268d-83fd-47d8-9011-578e0fcc6241",
	3);
INSERT INTO S_DIP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"31fe606c-d440-4b75-8d55-19809bde6d9b");
INSERT INTO S_DT
	VALUES ("31fe606c-d440-4b75-8d55-19809bde6d9b",
	"00000000-0000-0000-0000-000000000000",
	'timestamp',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("31fe606c-d440-4b75-8d55-19809bde6d9b",
	"642b0c07-a71d-46d2-be4d-c07e1839c831",
	2);
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"050ae1c7-4fe8-4036-9266-866162475ade",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"2bce27aa-a40c-4097-806c-bcca0cdac334",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"c917a3a0-5e13-4d90-ae51-caf66f88e775",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"80dd63f1-9308-4f8a-b38a-fd85188ab47d",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"08dd622e-58f4-4c59-80d1-b067316797b1",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"65307c11-e2af-4779-9e42-aa3bb3f9d5c3",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"8d8b769f-e617-4b41-9f14-d3581653f32f",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"8e0c3427-53b5-4e5e-9341-acbc9cfe5263",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"2616dc30-6433-4e8f-8b0a-76a77928c045",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"09a6c533-08a7-4b99-9104-408407f90497",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"f0372f26-60f9-4d5e-83cb-46b4c72d3bf6",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"642b0c07-a71d-46d2-be4d-c07e1839c831",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"4155268d-83fd-47d8-9011-578e0fcc6241",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"a96a11e8-5278-4837-ba3b-95111a36bcb1",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"879dbca7-970f-45bd-b4ff-c962a6ff60f0",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"9aba0199-0f9f-4da0-a4c4-b495dd26270a",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO SLD_SDINP
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"31fe606c-d440-4b75-8d55-19809bde6d9b",
	"ecb50217-b066-4ecf-a826-866ec62dc0da");
INSERT INTO EP_SPKG
	VALUES ("a655893d-fe3b-4b0f-b285-cc34425dfefa",
	"00000000-0000-0000-0000-000000000000");
