/*----------------------------------------------------------------------------
 * File:  sudoku_ports.c
 *
 * UML Component Port Messages
 * Component Name:  sudoku
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "sudoku_ports.h"
#include "sudoku_classes.h"

