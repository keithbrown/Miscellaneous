/*----------------------------------------------------------------------------
 * File:  sudoku_procedural_ports.h"
 *
 * UML Port Messages (Operations and Signals)
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef SUDOKU_PROCEDURAL_PORTS_H
#define SUDOKU_PROCEDURAL_PORTS_H

#ifdef  __cplusplus
extern "C" {
#endif



#ifdef    __cplusplus
}
#endif
#endif  /* SUDOKU_PROCEDURAL_PORTS_H */
