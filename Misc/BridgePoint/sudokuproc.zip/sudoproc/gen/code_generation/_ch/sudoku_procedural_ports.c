/*----------------------------------------------------------------------------
 * File:  sudoku_procedural_ports.c
 *
 * UML Component Port Messages
 * Component Name:  sudoku_procedural
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "sudoku_procedural_ports.h"
#include "sudoku_procedural_classes.h"

