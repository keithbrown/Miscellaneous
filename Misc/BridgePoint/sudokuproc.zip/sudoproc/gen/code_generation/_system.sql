-- root-types-contained: SystemModel_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.5

INSERT INTO S_SYS
	VALUES (1,
	'sudoproc');
INSERT INTO S_DOM
	VALUES (2,
	'sudoku_procedural',
	'',
	0,
	3,
	1);
INSERT INTO S_DPK
	VALUES (4,
	'Datatypes',
	2,
	0);
INSERT INTO S_DIP
	VALUES (4,
	5);
INSERT INTO S_DT
	VALUES (5,
	2,
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES (5,
	0);
INSERT INTO S_DIP
	VALUES (4,
	6);
INSERT INTO S_DT
	VALUES (6,
	2,
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES (6,
	1);
INSERT INTO S_DIP
	VALUES (4,
	7);
INSERT INTO S_DT
	VALUES (7,
	2,
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES (7,
	2);
INSERT INTO S_DIP
	VALUES (4,
	8);
INSERT INTO S_DT
	VALUES (8,
	2,
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES (8,
	3);
INSERT INTO S_DIP
	VALUES (4,
	9);
INSERT INTO S_DT
	VALUES (9,
	2,
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES (9,
	4);
INSERT INTO S_DIP
	VALUES (4,
	10);
INSERT INTO S_DT
	VALUES (10,
	2,
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES (10,
	5);
INSERT INTO S_DIP
	VALUES (4,
	11);
INSERT INTO S_DT
	VALUES (11,
	2,
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (11,
	6);
INSERT INTO S_DIP
	VALUES (4,
	12);
INSERT INTO S_DT
	VALUES (12,
	2,
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (12,
	7);
INSERT INTO S_DIP
	VALUES (4,
	13);
INSERT INTO S_DT
	VALUES (13,
	2,
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (13,
	8);
INSERT INTO S_DIP
	VALUES (4,
	14);
INSERT INTO S_DT
	VALUES (14,
	2,
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (14,
	9);
INSERT INTO S_DIP
	VALUES (4,
	15);
INSERT INTO S_DT
	VALUES (15,
	2,
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (15,
	10);
INSERT INTO S_DIP
	VALUES (4,
	16);
INSERT INTO S_DT
	VALUES (16,
	2,
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (16,
	11);
INSERT INTO S_DIP
	VALUES (4,
	17);
INSERT INTO S_DT
	VALUES (17,
	2,
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (17,
	12);
INSERT INTO S_DIP
	VALUES (4,
	18);
INSERT INTO S_DT
	VALUES (18,
	2,
	'date',
	'Time as known in the external world. For example, 12 October 1492,
13:25:10. The accuracy of external time is dependent on the architecture and
implementation.',
	'');
INSERT INTO S_UDT
	VALUES (18,
	16,
	1);
INSERT INTO S_DIP
	VALUES (4,
	19);
INSERT INTO S_DT
	VALUES (19,
	2,
	'timestamp',
	' The system clock counts time in ticks. The size of a tick is dependent on the
 architecture and implementation.',
	'');
INSERT INTO S_UDT
	VALUES (19,
	16,
	2);
INSERT INTO S_DIP
	VALUES (4,
	20);
INSERT INTO S_DT
	VALUES (20,
	2,
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES (20,
	17,
	3);
INSERT INTO EP_SPKG
	VALUES (4,
	0);
INSERT INTO S_EEPK
	VALUES (21,
	'External Entities',
	2,
	0);
INSERT INTO S_EEPIP
	VALUES (21);
INSERT INTO PL_EEPID
	VALUES (2,
	21);
INSERT INTO S_EEIP
	VALUES (21,
	22);
INSERT INTO S_EE
	VALUES (22,
	'Time',
	'The Time external entity provides date, timestamp, and timer related operations.',
	'TIM',
	2);
INSERT INTO S_BRG
	VALUES (23,
	22,
	'current_date',
	'',
	0,
	18,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (24,
	22,
	'create_date',
	'',
	0,
	18,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (25,
	24,
	'second',
	7,
	0,
	'',
	26,
	'');
INSERT INTO S_BPARM
	VALUES (27,
	24,
	'minute',
	7,
	0,
	'',
	28,
	'');
INSERT INTO S_BPARM
	VALUES (28,
	24,
	'hour',
	7,
	0,
	'',
	29,
	'');
INSERT INTO S_BPARM
	VALUES (29,
	24,
	'day',
	7,
	0,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (26,
	24,
	'month',
	7,
	0,
	'',
	27,
	'');
INSERT INTO S_BPARM
	VALUES (30,
	24,
	'year',
	7,
	0,
	'',
	25,
	'');
INSERT INTO S_BRG
	VALUES (31,
	22,
	'get_second',
	'',
	0,
	7,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (32,
	31,
	'date',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (33,
	22,
	'get_minute',
	'',
	0,
	7,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (34,
	33,
	'date',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (35,
	22,
	'get_hour',
	'',
	0,
	7,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (36,
	35,
	'date',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (37,
	22,
	'get_day',
	'',
	0,
	7,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (38,
	37,
	'date',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (39,
	22,
	'get_month',
	'',
	0,
	7,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (40,
	39,
	'date',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (41,
	22,
	'get_year',
	'',
	0,
	7,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (42,
	41,
	'date',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (43,
	22,
	'current_clock',
	'',
	0,
	19,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (44,
	22,
	'timer_start',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Returns the instance
handle of the timer.',
	0,
	20,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (45,
	44,
	'microseconds',
	7,
	0,
	'',
	46,
	'');
INSERT INTO S_BPARM
	VALUES (46,
	44,
	'event_inst',
	15,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (47,
	22,
	'timer_start_recurring',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Upon expiration, the
timer will be restarted and fire again in the specified number of microseconds
generating the passed event. This bridge operation returns the instance handle
of the timer.',
	0,
	20,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (48,
	47,
	'microseconds',
	7,
	0,
	'',
	49,
	'');
INSERT INTO S_BPARM
	VALUES (49,
	47,
	'event_inst',
	15,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (50,
	22,
	'timer_remaining_time',
	'Returns the time remaining (in microseconds) for the passed timer instance. If
the timer has expired, a zero value is returned.',
	0,
	7,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (51,
	50,
	'timer_inst_ref',
	20,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (52,
	22,
	'timer_reset_time',
	'This bridge operation attempts to set the passed existing timer to expire in
the specified number of microseconds. If the timer exists (that is, it has not
expired), a TRUE value is returned. If the timer no longer exists, a FALSE value
is returned.',
	0,
	6,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (53,
	52,
	'timer_inst_ref',
	20,
	0,
	'',
	54,
	'');
INSERT INTO S_BPARM
	VALUES (54,
	52,
	'microseconds',
	7,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (55,
	22,
	'timer_add_time',
	'This bridge operation attempts to add the specified number of microseconds to a
passed existing timer. If the timer exists (that is, it has not expired), a TRUE
value is returned. If the timer no longer exists, a FALSE value is returned.',
	0,
	6,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (56,
	55,
	'timer_inst_ref',
	20,
	0,
	'',
	57,
	'');
INSERT INTO S_BPARM
	VALUES (57,
	55,
	'microseconds',
	7,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (58,
	22,
	'timer_cancel',
	'This bridge operation cancels and deletes the passed timer instance. If the 
timer exists (that is, it had not expired), a TRUE value is returned. If the
timer no longer exists, a FALSE value is returned.',
	0,
	6,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (59,
	58,
	'timer_inst_ref',
	20,
	0,
	'',
	0,
	'');
INSERT INTO S_EEIP
	VALUES (21,
	60);
INSERT INTO S_EE
	VALUES (60,
	'Architecture',
	'',
	'ARCH',
	2);
INSERT INTO S_BRG
	VALUES (61,
	60,
	'shutdown',
	'',
	0,
	5,
	'',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES (62,
	61);
INSERT INTO ACT_ACT
	VALUES (62,
	'bridge',
	0,
	63,
	0,
	0,
	'Architecture::shutdown',
	0);
INSERT INTO ACT_BLK
	VALUES (63,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	62,
	0);
INSERT INTO S_EEIP
	VALUES (21,
	64);
INSERT INTO S_EE
	VALUES (64,
	'Logging',
	'',
	'LOG',
	2);
INSERT INTO S_BRG
	VALUES (65,
	64,
	'LogFailure',
	'',
	0,
	5,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (66,
	65,
	'message',
	9,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (67,
	65);
INSERT INTO ACT_ACT
	VALUES (67,
	'bridge',
	0,
	68,
	0,
	0,
	'Logging::LogFailure',
	0);
INSERT INTO ACT_BLK
	VALUES (68,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	67,
	0);
INSERT INTO S_BRG
	VALUES (69,
	64,
	'LogInfo',
	'',
	0,
	5,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (70,
	69,
	'message',
	9,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (71,
	69);
INSERT INTO ACT_ACT
	VALUES (71,
	'bridge',
	0,
	72,
	0,
	0,
	'Logging::LogInfo',
	0);
INSERT INTO ACT_BLK
	VALUES (72,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	71,
	0);
INSERT INTO S_BRG
	VALUES (73,
	64,
	'LogSuccess',
	'',
	0,
	5,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (74,
	73,
	'message',
	9,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (75,
	73);
INSERT INTO ACT_ACT
	VALUES (75,
	'bridge',
	0,
	76,
	0,
	0,
	'Logging::LogSuccess',
	0);
INSERT INTO ACT_BLK
	VALUES (76,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	75,
	0);
INSERT INTO S_EEIP
	VALUES (21,
	77);
INSERT INTO S_EE
	VALUES (77,
	'Non-Volatile Storage',
	'',
	'NVS',
	2);
INSERT INTO S_BRG
	VALUES (78,
	77,
	'version',
	'',
	0,
	7,
	'return 0;',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (79,
	78,
	'first',
	7,
	0,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (80,
	78,
	'second',
	7,
	0,
	'',
	79,
	'');
INSERT INTO ACT_BRB
	VALUES (81,
	78);
INSERT INTO ACT_ACT
	VALUES (81,
	'bridge',
	0,
	82,
	0,
	0,
	'Non-Volatile Storage::version',
	0);
INSERT INTO ACT_BLK
	VALUES (82,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	81,
	0);
INSERT INTO ACT_SMT
	VALUES (83,
	82,
	0,
	1,
	1,
	'Non-Volatile Storage::version line: 1');
INSERT INTO ACT_RET
	VALUES (83,
	84);
INSERT INTO V_VAL
	VALUES (84,
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	82);
INSERT INTO V_LIN
	VALUES (84,
	'0');
INSERT INTO S_BRG
	VALUES (85,
	77,
	'checksum',
	'',
	0,
	7,
	'return 0;',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (86,
	85,
	'first',
	7,
	0,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (87,
	85,
	'second',
	7,
	0,
	'',
	86,
	'');
INSERT INTO ACT_BRB
	VALUES (88,
	85);
INSERT INTO ACT_ACT
	VALUES (88,
	'bridge',
	0,
	89,
	0,
	0,
	'Non-Volatile Storage::checksum',
	0);
INSERT INTO ACT_BLK
	VALUES (89,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	88,
	0);
INSERT INTO ACT_SMT
	VALUES (90,
	89,
	0,
	1,
	1,
	'Non-Volatile Storage::checksum line: 1');
INSERT INTO ACT_RET
	VALUES (90,
	91);
INSERT INTO V_VAL
	VALUES (91,
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	89);
INSERT INTO V_LIN
	VALUES (91,
	'0');
INSERT INTO S_BRG
	VALUES (92,
	77,
	'space_used',
	'',
	0,
	7,
	'return 0;',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES (93,
	92);
INSERT INTO ACT_ACT
	VALUES (93,
	'bridge',
	0,
	94,
	0,
	0,
	'Non-Volatile Storage::space_used',
	0);
INSERT INTO ACT_BLK
	VALUES (94,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	93,
	0);
INSERT INTO ACT_SMT
	VALUES (95,
	94,
	0,
	1,
	1,
	'Non-Volatile Storage::space_used line: 1');
INSERT INTO ACT_RET
	VALUES (95,
	96);
INSERT INTO V_VAL
	VALUES (96,
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	94);
INSERT INTO V_LIN
	VALUES (96,
	'0');
INSERT INTO S_BRG
	VALUES (97,
	77,
	'format',
	'',
	0,
	7,
	'return 0;',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES (98,
	97);
INSERT INTO ACT_ACT
	VALUES (98,
	'bridge',
	0,
	99,
	0,
	0,
	'Non-Volatile Storage::format',
	0);
INSERT INTO ACT_BLK
	VALUES (99,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	98,
	0);
INSERT INTO ACT_SMT
	VALUES (100,
	99,
	0,
	1,
	1,
	'Non-Volatile Storage::format line: 1');
INSERT INTO ACT_RET
	VALUES (100,
	101);
INSERT INTO V_VAL
	VALUES (101,
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	99);
INSERT INTO V_LIN
	VALUES (101,
	'0');
INSERT INTO S_FPK
	VALUES (102,
	'functions',
	2,
	0);
INSERT INTO PL_FPID
	VALUES (102,
	2);
INSERT INTO S_FIP
	VALUES (102,
	103);
INSERT INTO S_SYNC
	VALUES (103,
	2,
	'setup',
	'',
	'// 
// Check to see if any instances are already here.
// This would mean that we have restored from NVS
// or that preexisting instances were defined in data.
//

select any sequence from instances of SEQUENCE;
if ( empty sequence )
  i = NVS::space_used();
  if ( i < 100 )
    i = NVS::format();
    if( i != 0 )
      LOG::LogFailure( message:"Error formatting the NVS." );
    end if;
  end if;

  LOG::LogInfo( message:"Did not find any PEI data, initializing NVS" );
  i = NVS::version( first:1, second:2 );
  i =  NVS::checksum( first:1, second:2 );
  
// Create 9 digits.
i = 9;
while ( 0 < i )
  create object instance digit of DIGIT;
  digit.value = i;
  i = i - 1;
end while;
create object instance digit of DIGIT;
digit.value = 0;


i = 9;
while ( 0 < i )

  // Create the row sequence.
  create object instance sequence of SEQUENCE;
  sequence.solved = false;
  sequence.requests = 0;
  create object instance row of ROW;
  row.number = i;
  relate row to sequence across R1;
  
  // Create the column sequence.
  create object instance sequence of SEQUENCE;
  sequence.solved = false;
  sequence.requests = 0;
  create object instance column of COLUMN;
  column.number = i;
  relate column to sequence across R1;
  
  // Create the box sequence.
  create object instance sequence of SEQUENCE;
  sequence.solved = false;
  sequence.requests = 0;
  create object instance box of BOX;
  box.number = i;
  relate box to sequence across R1;
  
  i = i - 1;
end while;

select many rows from instances of ROW;
for each row in rows
  select many columns from instances of COLUMN;
  for each column in columns;
    create object instance cell of CELL;
    select any digit from instances of DIGIT where ( selected.value == 0 );
    relate cell to digit across R9;
    relate cell to row across R2;
    relate cell to column across R3;
  
    // Link in all 9 digits to each cell.
    select many digits from instances of DIGIT where ( selected.value != 0 );
    for each digit in digits
      create object instance eligible of ELIGIBLE;
      relate digit to cell across R8 using eligible;
    end for;
  end for;
end for;

// Link the cells to the correct boxes.
select many cells from instances of CELL;
for each cell in cells
  if ( ( cell.row_number <= 3 ) and
     ( cell.column_number <= 3 ) )
    select any box from instances of BOX where ( selected.number == 1 );
    relate cell to box across R4;
  elif ( ( cell.row_number <= 3 ) and
     ( ( 4 <= cell.column_number ) and ( cell.column_number <= 6 ) ) )
    select any box from instances of BOX where ( selected.number == 2 );
    relate cell to box across R4;
  elif ( ( cell.row_number <= 3 ) and
     ( 7 <= cell.column_number ) )
    select any box from instances of BOX where ( selected.number == 3 );
    relate cell to box across R4;
  elif ( ( ( 4 <= cell.row_number ) and ( cell.row_number <= 6 ) ) and
     ( cell.column_number <= 3 ) )
    select any box from instances of BOX where ( selected.number == 4 );
    relate cell to box across R4;
  elif ( ( ( 4 <= cell.row_number ) and ( cell.row_number <= 6 ) ) and
     ( ( 4 <= cell.column_number ) and ( cell.column_number <= 6 ) ) )
    select any box from instances of BOX where ( selected.number == 5 );
    relate cell to box across R4;
  elif ( ( ( 4 <= cell.row_number ) and ( cell.row_number <= 6 ) ) and
     ( 7 <= cell.column_number ) )
    select any box from instances of BOX where ( selected.number == 6 );
    relate cell to box across R4;
  elif ( ( 7 <= cell.row_number ) and
     ( cell.column_number <= 3 ) )
    select any box from instances of BOX where ( selected.number == 7 );
    relate cell to box across R4;
  elif ( ( 7 <= cell.row_number ) and
     ( ( 4 <= cell.column_number ) and ( cell.column_number <= 6 ) ) )
    select any box from instances of BOX where ( selected.number == 8 );
    relate cell to box across R4;
  elif ( ( 7 <= cell.row_number ) and
     ( 7 <= cell.column_number ) )
    select any box from instances of BOX where ( selected.number == 9 );
    relate cell to box across R4;
  end if;
end for;

else
  LOG::LogInfo( message:"PEI data found." );
end if;
',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (104,
	103);
INSERT INTO ACT_ACT
	VALUES (104,
	'function',
	0,
	105,
	0,
	0,
	'setup',
	0);
INSERT INTO ACT_BLK
	VALUES (105,
	1,
	0,
	0,
	'',
	'',
	'',
	123,
	1,
	7,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (106,
	105,
	107,
	7,
	1,
	'setup line: 7');
INSERT INTO ACT_FIO
	VALUES (106,
	108,
	1,
	'any',
	109,
	7,
	39);
INSERT INTO ACT_SMT
	VALUES (107,
	105,
	0,
	8,
	1,
	'setup line: 8');
INSERT INTO ACT_IF
	VALUES (107,
	110,
	111,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (112,
	105,
	0,
	123,
	1,
	'setup line: 123');
INSERT INTO ACT_E
	VALUES (112,
	113,
	107);
INSERT INTO V_VAL
	VALUES (114,
	0,
	0,
	8,
	12,
	19,
	0,
	0,
	0,
	0,
	13,
	105);
INSERT INTO V_IRF
	VALUES (114,
	108);
INSERT INTO V_VAL
	VALUES (111,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	105);
INSERT INTO V_UNY
	VALUES (111,
	114,
	'empty');
INSERT INTO V_VAR
	VALUES (108,
	105,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (108,
	0,
	109);
INSERT INTO V_LOC
	VALUES (115,
	7,
	12,
	19,
	108);
INSERT INTO V_LOC
	VALUES (116,
	36,
	26,
	33,
	108);
INSERT INTO V_LOC
	VALUES (117,
	37,
	3,
	10,
	108);
INSERT INTO V_LOC
	VALUES (118,
	38,
	3,
	10,
	108);
INSERT INTO V_LOC
	VALUES (119,
	41,
	17,
	24,
	108);
INSERT INTO V_LOC
	VALUES (120,
	44,
	26,
	33,
	108);
INSERT INTO V_LOC
	VALUES (121,
	45,
	3,
	10,
	108);
INSERT INTO V_LOC
	VALUES (122,
	46,
	3,
	10,
	108);
INSERT INTO V_LOC
	VALUES (123,
	49,
	20,
	27,
	108);
INSERT INTO V_LOC
	VALUES (124,
	52,
	26,
	33,
	108);
INSERT INTO V_LOC
	VALUES (125,
	53,
	3,
	10,
	108);
INSERT INTO V_LOC
	VALUES (126,
	54,
	3,
	10,
	108);
INSERT INTO V_LOC
	VALUES (127,
	57,
	17,
	24,
	108);
INSERT INTO ACT_BLK
	VALUES (110,
	1,
	0,
	0,
	'NVS',
	'',
	'',
	83,
	1,
	82,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (128,
	110,
	129,
	9,
	3,
	'setup line: 9');
INSERT INTO ACT_AI
	VALUES (128,
	130,
	131,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (129,
	110,
	132,
	10,
	3,
	'setup line: 10');
INSERT INTO ACT_IF
	VALUES (129,
	133,
	134,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (132,
	110,
	135,
	17,
	3,
	'setup line: 17');
INSERT INTO ACT_BRG
	VALUES (132,
	69,
	17,
	8,
	17,
	3);
INSERT INTO ACT_SMT
	VALUES (135,
	110,
	136,
	18,
	3,
	'setup line: 18');
INSERT INTO ACT_AI
	VALUES (135,
	137,
	138,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (136,
	110,
	139,
	19,
	3,
	'setup line: 19');
INSERT INTO ACT_AI
	VALUES (136,
	140,
	141,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (139,
	110,
	142,
	22,
	1,
	'setup line: 22');
INSERT INTO ACT_AI
	VALUES (139,
	143,
	144,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (142,
	110,
	145,
	23,
	1,
	'setup line: 23');
INSERT INTO ACT_WHL
	VALUES (142,
	146,
	147);
INSERT INTO ACT_SMT
	VALUES (145,
	110,
	148,
	28,
	1,
	'setup line: 28');
INSERT INTO ACT_CR
	VALUES (145,
	149,
	1,
	150,
	28,
	33);
INSERT INTO ACT_SMT
	VALUES (148,
	110,
	151,
	29,
	1,
	'setup line: 29');
INSERT INTO ACT_AI
	VALUES (148,
	152,
	153,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (151,
	110,
	154,
	32,
	1,
	'setup line: 32');
INSERT INTO ACT_AI
	VALUES (151,
	155,
	156,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (154,
	110,
	157,
	33,
	1,
	'setup line: 33');
INSERT INTO ACT_WHL
	VALUES (154,
	158,
	159);
INSERT INTO ACT_SMT
	VALUES (157,
	110,
	160,
	62,
	1,
	'setup line: 62');
INSERT INTO ACT_FIO
	VALUES (157,
	161,
	1,
	'many',
	162,
	62,
	36);
INSERT INTO ACT_SMT
	VALUES (160,
	110,
	163,
	63,
	1,
	'setup line: 63');
INSERT INTO ACT_FOR
	VALUES (160,
	164,
	1,
	165,
	161,
	162);
INSERT INTO ACT_SMT
	VALUES (163,
	110,
	166,
	82,
	1,
	'setup line: 82');
INSERT INTO ACT_FIO
	VALUES (163,
	167,
	1,
	'many',
	168,
	82,
	37);
INSERT INTO ACT_SMT
	VALUES (166,
	110,
	0,
	83,
	1,
	'setup line: 83');
INSERT INTO ACT_FOR
	VALUES (166,
	169,
	1,
	170,
	167,
	168);
INSERT INTO V_VAL
	VALUES (131,
	1,
	1,
	9,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_TVL
	VALUES (131,
	171);
INSERT INTO V_VAL
	VALUES (130,
	0,
	0,
	9,
	12,
	-1,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_BRV
	VALUES (130,
	92,
	1,
	9,
	7);
INSERT INTO V_VAL
	VALUES (172,
	0,
	0,
	10,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_TVL
	VALUES (172,
	171);
INSERT INTO V_VAL
	VALUES (134,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	110);
INSERT INTO V_BIN
	VALUES (134,
	173,
	172,
	'<');
INSERT INTO V_VAL
	VALUES (173,
	0,
	0,
	10,
	12,
	14,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_LIN
	VALUES (173,
	'100');
INSERT INTO V_VAL
	VALUES (174,
	0,
	0,
	17,
	25,
	68,
	0,
	0,
	0,
	0,
	9,
	110);
INSERT INTO V_LST
	VALUES (174,
	'Did not find any PEI data, initializing NVS');
INSERT INTO V_PAR
	VALUES (174,
	132,
	0,
	'message',
	0,
	17,
	17);
INSERT INTO V_VAL
	VALUES (138,
	1,
	0,
	18,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_TVL
	VALUES (138,
	171);
INSERT INTO V_VAL
	VALUES (137,
	0,
	0,
	18,
	12,
	-1,
	18,
	21,
	18,
	30,
	7,
	110);
INSERT INTO V_BRV
	VALUES (137,
	78,
	1,
	18,
	7);
INSERT INTO V_VAL
	VALUES (175,
	0,
	0,
	18,
	27,
	27,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_LIN
	VALUES (175,
	'1');
INSERT INTO V_PAR
	VALUES (175,
	0,
	137,
	'first',
	176,
	18,
	21);
INSERT INTO V_VAL
	VALUES (176,
	0,
	0,
	18,
	37,
	37,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_LIN
	VALUES (176,
	'2');
INSERT INTO V_PAR
	VALUES (176,
	0,
	137,
	'second',
	0,
	18,
	30);
INSERT INTO V_VAL
	VALUES (141,
	1,
	0,
	19,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_TVL
	VALUES (141,
	171);
INSERT INTO V_VAL
	VALUES (140,
	0,
	0,
	19,
	13,
	-1,
	19,
	23,
	19,
	32,
	7,
	110);
INSERT INTO V_BRV
	VALUES (140,
	85,
	1,
	19,
	8);
INSERT INTO V_VAL
	VALUES (177,
	0,
	0,
	19,
	29,
	29,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_LIN
	VALUES (177,
	'1');
INSERT INTO V_PAR
	VALUES (177,
	0,
	140,
	'first',
	178,
	19,
	23);
INSERT INTO V_VAL
	VALUES (178,
	0,
	0,
	19,
	39,
	39,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_LIN
	VALUES (178,
	'2');
INSERT INTO V_PAR
	VALUES (178,
	0,
	140,
	'second',
	0,
	19,
	32);
INSERT INTO V_VAL
	VALUES (144,
	1,
	0,
	22,
	1,
	1,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_TVL
	VALUES (144,
	171);
INSERT INTO V_VAL
	VALUES (143,
	0,
	0,
	22,
	5,
	5,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_LIN
	VALUES (143,
	'9');
INSERT INTO V_VAL
	VALUES (179,
	0,
	0,
	23,
	9,
	9,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_LIN
	VALUES (179,
	'0');
INSERT INTO V_VAL
	VALUES (146,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	110);
INSERT INTO V_BIN
	VALUES (146,
	180,
	179,
	'<');
INSERT INTO V_VAL
	VALUES (180,
	0,
	0,
	23,
	13,
	13,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_TVL
	VALUES (180,
	171);
INSERT INTO V_VAL
	VALUES (181,
	1,
	0,
	29,
	1,
	5,
	0,
	0,
	0,
	0,
	13,
	110);
INSERT INTO V_IRF
	VALUES (181,
	149);
INSERT INTO V_VAL
	VALUES (153,
	1,
	0,
	29,
	7,
	11,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_AVL
	VALUES (153,
	181,
	150,
	182);
INSERT INTO V_VAL
	VALUES (152,
	0,
	0,
	29,
	15,
	15,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_LIN
	VALUES (152,
	'0');
INSERT INTO V_VAL
	VALUES (156,
	1,
	0,
	32,
	1,
	1,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_TVL
	VALUES (156,
	171);
INSERT INTO V_VAL
	VALUES (155,
	0,
	0,
	32,
	5,
	5,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_LIN
	VALUES (155,
	'9');
INSERT INTO V_VAL
	VALUES (183,
	0,
	0,
	33,
	9,
	9,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_LIN
	VALUES (183,
	'0');
INSERT INTO V_VAL
	VALUES (158,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	110);
INSERT INTO V_BIN
	VALUES (158,
	184,
	183,
	'<');
INSERT INTO V_VAL
	VALUES (184,
	0,
	0,
	33,
	13,
	13,
	0,
	0,
	0,
	0,
	7,
	110);
INSERT INTO V_TVL
	VALUES (184,
	171);
INSERT INTO V_VAR
	VALUES (171,
	110,
	'i',
	1,
	7);
INSERT INTO V_TRN
	VALUES (171,
	0,
	'');
INSERT INTO V_LOC
	VALUES (185,
	9,
	3,
	3,
	171);
INSERT INTO V_LOC
	VALUES (186,
	10,
	8,
	8,
	171);
INSERT INTO V_LOC
	VALUES (187,
	11,
	5,
	5,
	171);
INSERT INTO V_LOC
	VALUES (188,
	12,
	9,
	9,
	171);
INSERT INTO V_LOC
	VALUES (189,
	18,
	3,
	3,
	171);
INSERT INTO V_LOC
	VALUES (190,
	19,
	3,
	3,
	171);
INSERT INTO V_LOC
	VALUES (191,
	22,
	1,
	1,
	171);
INSERT INTO V_LOC
	VALUES (192,
	23,
	13,
	13,
	171);
INSERT INTO V_LOC
	VALUES (193,
	25,
	17,
	17,
	171);
INSERT INTO V_LOC
	VALUES (194,
	26,
	3,
	3,
	171);
INSERT INTO V_LOC
	VALUES (195,
	26,
	7,
	7,
	171);
INSERT INTO V_LOC
	VALUES (196,
	32,
	1,
	1,
	171);
INSERT INTO V_LOC
	VALUES (197,
	33,
	13,
	13,
	171);
INSERT INTO V_LOC
	VALUES (198,
	40,
	16,
	16,
	171);
INSERT INTO V_LOC
	VALUES (199,
	48,
	19,
	19,
	171);
INSERT INTO V_LOC
	VALUES (200,
	56,
	16,
	16,
	171);
INSERT INTO V_LOC
	VALUES (201,
	59,
	3,
	3,
	171);
INSERT INTO V_LOC
	VALUES (202,
	59,
	7,
	7,
	171);
INSERT INTO V_VAR
	VALUES (149,
	110,
	'digit',
	1,
	13);
INSERT INTO V_INT
	VALUES (149,
	0,
	150);
INSERT INTO V_LOC
	VALUES (203,
	28,
	24,
	28,
	149);
INSERT INTO V_LOC
	VALUES (204,
	29,
	1,
	5,
	149);
INSERT INTO V_LOC
	VALUES (205,
	67,
	16,
	20,
	149);
INSERT INTO V_LOC
	VALUES (206,
	68,
	20,
	24,
	149);
INSERT INTO V_LOC
	VALUES (207,
	74,
	14,
	18,
	149);
INSERT INTO V_LOC
	VALUES (208,
	76,
	14,
	18,
	149);
INSERT INTO V_VAR
	VALUES (161,
	110,
	'rows',
	1,
	14);
INSERT INTO V_INS
	VALUES (161,
	162);
INSERT INTO V_LOC
	VALUES (209,
	62,
	13,
	16,
	161);
INSERT INTO V_LOC
	VALUES (210,
	63,
	17,
	20,
	161);
INSERT INTO V_VAR
	VALUES (165,
	110,
	'row',
	1,
	13);
INSERT INTO V_INT
	VALUES (165,
	1,
	162);
INSERT INTO V_LOC
	VALUES (211,
	63,
	10,
	12,
	165);
INSERT INTO V_LOC
	VALUES (212,
	69,
	20,
	22,
	165);
INSERT INTO V_VAR
	VALUES (167,
	110,
	'cells',
	1,
	14);
INSERT INTO V_INS
	VALUES (167,
	168);
INSERT INTO V_LOC
	VALUES (213,
	82,
	13,
	17,
	167);
INSERT INTO V_LOC
	VALUES (214,
	83,
	18,
	22,
	167);
INSERT INTO V_VAR
	VALUES (170,
	110,
	'cell',
	1,
	13);
INSERT INTO V_INT
	VALUES (170,
	1,
	168);
INSERT INTO V_LOC
	VALUES (215,
	83,
	10,
	13,
	170);
INSERT INTO V_LOC
	VALUES (216,
	84,
	10,
	13,
	170);
INSERT INTO V_LOC
	VALUES (217,
	85,
	8,
	11,
	170);
INSERT INTO V_LOC
	VALUES (218,
	87,
	12,
	15,
	170);
INSERT INTO V_LOC
	VALUES (219,
	88,
	12,
	15,
	170);
INSERT INTO V_LOC
	VALUES (220,
	89,
	15,
	18,
	170);
INSERT INTO V_LOC
	VALUES (221,
	89,
	42,
	45,
	170);
INSERT INTO V_LOC
	VALUES (222,
	91,
	12,
	15,
	170);
INSERT INTO V_LOC
	VALUES (223,
	92,
	12,
	15,
	170);
INSERT INTO V_LOC
	VALUES (224,
	93,
	13,
	16,
	170);
INSERT INTO V_LOC
	VALUES (225,
	95,
	12,
	15,
	170);
INSERT INTO V_LOC
	VALUES (226,
	96,
	19,
	22,
	170);
INSERT INTO V_LOC
	VALUES (227,
	96,
	43,
	46,
	170);
INSERT INTO V_LOC
	VALUES (228,
	97,
	8,
	11,
	170);
INSERT INTO V_LOC
	VALUES (229,
	99,
	12,
	15,
	170);
INSERT INTO V_LOC
	VALUES (230,
	100,
	19,
	22,
	170);
INSERT INTO V_LOC
	VALUES (231,
	100,
	43,
	46,
	170);
INSERT INTO V_LOC
	VALUES (232,
	101,
	15,
	18,
	170);
INSERT INTO V_LOC
	VALUES (233,
	101,
	42,
	45,
	170);
INSERT INTO V_LOC
	VALUES (234,
	103,
	12,
	15,
	170);
INSERT INTO V_LOC
	VALUES (235,
	104,
	19,
	22,
	170);
INSERT INTO V_LOC
	VALUES (236,
	104,
	43,
	46,
	170);
INSERT INTO V_LOC
	VALUES (237,
	105,
	13,
	16,
	170);
INSERT INTO V_LOC
	VALUES (238,
	107,
	12,
	15,
	170);
INSERT INTO V_LOC
	VALUES (239,
	108,
	17,
	20,
	170);
INSERT INTO V_LOC
	VALUES (240,
	109,
	8,
	11,
	170);
INSERT INTO V_LOC
	VALUES (241,
	111,
	12,
	15,
	170);
INSERT INTO V_LOC
	VALUES (242,
	112,
	17,
	20,
	170);
INSERT INTO V_LOC
	VALUES (243,
	113,
	15,
	18,
	170);
INSERT INTO V_LOC
	VALUES (244,
	113,
	42,
	45,
	170);
INSERT INTO V_LOC
	VALUES (245,
	115,
	12,
	15,
	170);
INSERT INTO V_LOC
	VALUES (246,
	116,
	17,
	20,
	170);
INSERT INTO V_LOC
	VALUES (247,
	117,
	13,
	16,
	170);
INSERT INTO V_LOC
	VALUES (248,
	119,
	12,
	15,
	170);
INSERT INTO ACT_BLK
	VALUES (133,
	0,
	0,
	0,
	'NVS',
	'',
	'',
	12,
	5,
	11,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (249,
	133,
	250,
	11,
	5,
	'setup line: 11');
INSERT INTO ACT_AI
	VALUES (249,
	251,
	252,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (250,
	133,
	0,
	12,
	5,
	'setup line: 12');
INSERT INTO ACT_IF
	VALUES (250,
	253,
	254,
	0,
	0);
INSERT INTO V_VAL
	VALUES (252,
	1,
	0,
	11,
	5,
	5,
	0,
	0,
	0,
	0,
	7,
	133);
INSERT INTO V_TVL
	VALUES (252,
	171);
INSERT INTO V_VAL
	VALUES (251,
	0,
	0,
	11,
	14,
	-1,
	0,
	0,
	0,
	0,
	7,
	133);
INSERT INTO V_BRV
	VALUES (251,
	97,
	1,
	11,
	9);
INSERT INTO V_VAL
	VALUES (255,
	0,
	0,
	12,
	9,
	9,
	0,
	0,
	0,
	0,
	7,
	133);
INSERT INTO V_TVL
	VALUES (255,
	171);
INSERT INTO V_VAL
	VALUES (254,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	133);
INSERT INTO V_BIN
	VALUES (254,
	256,
	255,
	'!=');
INSERT INTO V_VAL
	VALUES (256,
	0,
	0,
	12,
	14,
	14,
	0,
	0,
	0,
	0,
	7,
	133);
INSERT INTO V_LIN
	VALUES (256,
	'0');
INSERT INTO ACT_BLK
	VALUES (253,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	13,
	7,
	13,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (257,
	253,
	0,
	13,
	7,
	'setup line: 13');
INSERT INTO ACT_BRG
	VALUES (257,
	65,
	13,
	12,
	13,
	7);
INSERT INTO V_VAL
	VALUES (258,
	0,
	0,
	13,
	32,
	57,
	0,
	0,
	0,
	0,
	9,
	253);
INSERT INTO V_LST
	VALUES (258,
	'Error formatting the NVS.');
INSERT INTO V_PAR
	VALUES (258,
	257,
	0,
	'message',
	0,
	13,
	24);
INSERT INTO ACT_BLK
	VALUES (147,
	0,
	0,
	0,
	'',
	'',
	'',
	26,
	3,
	24,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (259,
	147,
	260,
	24,
	3,
	'setup line: 24');
INSERT INTO ACT_CR
	VALUES (259,
	261,
	1,
	150,
	24,
	35);
INSERT INTO ACT_SMT
	VALUES (260,
	147,
	262,
	25,
	3,
	'setup line: 25');
INSERT INTO ACT_AI
	VALUES (260,
	263,
	264,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (262,
	147,
	0,
	26,
	3,
	'setup line: 26');
INSERT INTO ACT_AI
	VALUES (262,
	265,
	266,
	0,
	0);
INSERT INTO V_VAL
	VALUES (267,
	1,
	0,
	25,
	3,
	7,
	0,
	0,
	0,
	0,
	13,
	147);
INSERT INTO V_IRF
	VALUES (267,
	261);
INSERT INTO V_VAL
	VALUES (264,
	1,
	0,
	25,
	9,
	13,
	0,
	0,
	0,
	0,
	7,
	147);
INSERT INTO V_AVL
	VALUES (264,
	267,
	150,
	182);
INSERT INTO V_VAL
	VALUES (263,
	0,
	0,
	25,
	17,
	17,
	0,
	0,
	0,
	0,
	7,
	147);
INSERT INTO V_TVL
	VALUES (263,
	171);
INSERT INTO V_VAL
	VALUES (266,
	1,
	0,
	26,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	147);
INSERT INTO V_TVL
	VALUES (266,
	171);
INSERT INTO V_VAL
	VALUES (268,
	0,
	0,
	26,
	7,
	7,
	0,
	0,
	0,
	0,
	7,
	147);
INSERT INTO V_TVL
	VALUES (268,
	171);
INSERT INTO V_VAL
	VALUES (265,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	147);
INSERT INTO V_BIN
	VALUES (265,
	269,
	268,
	'-');
INSERT INTO V_VAL
	VALUES (269,
	0,
	0,
	26,
	11,
	11,
	0,
	0,
	0,
	0,
	7,
	147);
INSERT INTO V_LIN
	VALUES (269,
	'1');
INSERT INTO V_VAR
	VALUES (261,
	147,
	'digit',
	1,
	13);
INSERT INTO V_INT
	VALUES (261,
	0,
	150);
INSERT INTO V_LOC
	VALUES (270,
	24,
	26,
	30,
	261);
INSERT INTO V_LOC
	VALUES (271,
	25,
	3,
	7,
	261);
INSERT INTO ACT_BLK
	VALUES (159,
	0,
	0,
	0,
	'',
	'',
	'',
	59,
	3,
	55,
	33,
	0,
	0,
	57,
	33,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (272,
	159,
	273,
	36,
	3,
	'setup line: 36');
INSERT INTO ACT_CR
	VALUES (272,
	108,
	0,
	109,
	36,
	38);
INSERT INTO ACT_SMT
	VALUES (273,
	159,
	274,
	37,
	3,
	'setup line: 37');
INSERT INTO ACT_AI
	VALUES (273,
	275,
	276,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (274,
	159,
	277,
	38,
	3,
	'setup line: 38');
INSERT INTO ACT_AI
	VALUES (274,
	278,
	279,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (277,
	159,
	280,
	39,
	3,
	'setup line: 39');
INSERT INTO ACT_CR
	VALUES (277,
	281,
	1,
	162,
	39,
	33);
INSERT INTO ACT_SMT
	VALUES (280,
	159,
	282,
	40,
	3,
	'setup line: 40');
INSERT INTO ACT_AI
	VALUES (280,
	283,
	284,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (282,
	159,
	285,
	41,
	3,
	'setup line: 41');
INSERT INTO ACT_REL
	VALUES (282,
	281,
	108,
	'',
	286,
	41,
	33,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (285,
	159,
	287,
	44,
	3,
	'setup line: 44');
INSERT INTO ACT_CR
	VALUES (285,
	108,
	0,
	109,
	44,
	38);
INSERT INTO ACT_SMT
	VALUES (287,
	159,
	288,
	45,
	3,
	'setup line: 45');
INSERT INTO ACT_AI
	VALUES (287,
	289,
	290,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (288,
	159,
	291,
	46,
	3,
	'setup line: 46');
INSERT INTO ACT_AI
	VALUES (288,
	292,
	293,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (291,
	159,
	294,
	47,
	3,
	'setup line: 47');
INSERT INTO ACT_CR
	VALUES (291,
	295,
	1,
	296,
	47,
	36);
INSERT INTO ACT_SMT
	VALUES (294,
	159,
	297,
	48,
	3,
	'setup line: 48');
INSERT INTO ACT_AI
	VALUES (294,
	298,
	299,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (297,
	159,
	300,
	49,
	3,
	'setup line: 49');
INSERT INTO ACT_REL
	VALUES (297,
	295,
	108,
	'',
	286,
	49,
	36,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (300,
	159,
	301,
	52,
	3,
	'setup line: 52');
INSERT INTO ACT_CR
	VALUES (300,
	108,
	0,
	109,
	52,
	38);
INSERT INTO ACT_SMT
	VALUES (301,
	159,
	302,
	53,
	3,
	'setup line: 53');
INSERT INTO ACT_AI
	VALUES (301,
	303,
	304,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (302,
	159,
	305,
	54,
	3,
	'setup line: 54');
INSERT INTO ACT_AI
	VALUES (302,
	306,
	307,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (305,
	159,
	308,
	55,
	3,
	'setup line: 55');
INSERT INTO ACT_CR
	VALUES (305,
	309,
	1,
	310,
	55,
	33);
INSERT INTO ACT_SMT
	VALUES (308,
	159,
	311,
	56,
	3,
	'setup line: 56');
INSERT INTO ACT_AI
	VALUES (308,
	312,
	313,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (311,
	159,
	314,
	57,
	3,
	'setup line: 57');
INSERT INTO ACT_REL
	VALUES (311,
	309,
	108,
	'',
	286,
	57,
	33,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (314,
	159,
	0,
	59,
	3,
	'setup line: 59');
INSERT INTO ACT_AI
	VALUES (314,
	315,
	316,
	0,
	0);
INSERT INTO V_VAL
	VALUES (317,
	1,
	0,
	37,
	3,
	10,
	0,
	0,
	0,
	0,
	13,
	159);
INSERT INTO V_IRF
	VALUES (317,
	108);
INSERT INTO V_VAL
	VALUES (276,
	1,
	0,
	37,
	12,
	17,
	0,
	0,
	0,
	0,
	6,
	159);
INSERT INTO V_AVL
	VALUES (276,
	317,
	109,
	318);
INSERT INTO V_VAL
	VALUES (275,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	159);
INSERT INTO V_LBO
	VALUES (275,
	'FALSE');
INSERT INTO V_VAL
	VALUES (319,
	1,
	0,
	38,
	3,
	10,
	0,
	0,
	0,
	0,
	13,
	159);
INSERT INTO V_IRF
	VALUES (319,
	108);
INSERT INTO V_VAL
	VALUES (279,
	1,
	0,
	38,
	12,
	19,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_AVL
	VALUES (279,
	319,
	109,
	320);
INSERT INTO V_VAL
	VALUES (278,
	0,
	0,
	38,
	23,
	23,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_LIN
	VALUES (278,
	'0');
INSERT INTO V_VAL
	VALUES (321,
	1,
	0,
	40,
	3,
	5,
	0,
	0,
	0,
	0,
	13,
	159);
INSERT INTO V_IRF
	VALUES (321,
	281);
INSERT INTO V_VAL
	VALUES (284,
	1,
	0,
	40,
	7,
	12,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_AVL
	VALUES (284,
	321,
	162,
	322);
INSERT INTO V_VAL
	VALUES (283,
	0,
	0,
	40,
	16,
	16,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_TVL
	VALUES (283,
	171);
INSERT INTO V_VAL
	VALUES (323,
	1,
	0,
	45,
	3,
	10,
	0,
	0,
	0,
	0,
	13,
	159);
INSERT INTO V_IRF
	VALUES (323,
	108);
INSERT INTO V_VAL
	VALUES (290,
	1,
	0,
	45,
	12,
	17,
	0,
	0,
	0,
	0,
	6,
	159);
INSERT INTO V_AVL
	VALUES (290,
	323,
	109,
	318);
INSERT INTO V_VAL
	VALUES (289,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	159);
INSERT INTO V_LBO
	VALUES (289,
	'FALSE');
INSERT INTO V_VAL
	VALUES (324,
	1,
	0,
	46,
	3,
	10,
	0,
	0,
	0,
	0,
	13,
	159);
INSERT INTO V_IRF
	VALUES (324,
	108);
INSERT INTO V_VAL
	VALUES (293,
	1,
	0,
	46,
	12,
	19,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_AVL
	VALUES (293,
	324,
	109,
	320);
INSERT INTO V_VAL
	VALUES (292,
	0,
	0,
	46,
	23,
	23,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_LIN
	VALUES (292,
	'0');
INSERT INTO V_VAL
	VALUES (325,
	1,
	0,
	48,
	3,
	8,
	0,
	0,
	0,
	0,
	13,
	159);
INSERT INTO V_IRF
	VALUES (325,
	295);
INSERT INTO V_VAL
	VALUES (299,
	1,
	0,
	48,
	10,
	15,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_AVL
	VALUES (299,
	325,
	296,
	326);
INSERT INTO V_VAL
	VALUES (298,
	0,
	0,
	48,
	19,
	19,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_TVL
	VALUES (298,
	171);
INSERT INTO V_VAL
	VALUES (327,
	1,
	0,
	53,
	3,
	10,
	0,
	0,
	0,
	0,
	13,
	159);
INSERT INTO V_IRF
	VALUES (327,
	108);
INSERT INTO V_VAL
	VALUES (304,
	1,
	0,
	53,
	12,
	17,
	0,
	0,
	0,
	0,
	6,
	159);
INSERT INTO V_AVL
	VALUES (304,
	327,
	109,
	318);
INSERT INTO V_VAL
	VALUES (303,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	159);
INSERT INTO V_LBO
	VALUES (303,
	'FALSE');
INSERT INTO V_VAL
	VALUES (328,
	1,
	0,
	54,
	3,
	10,
	0,
	0,
	0,
	0,
	13,
	159);
INSERT INTO V_IRF
	VALUES (328,
	108);
INSERT INTO V_VAL
	VALUES (307,
	1,
	0,
	54,
	12,
	19,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_AVL
	VALUES (307,
	328,
	109,
	320);
INSERT INTO V_VAL
	VALUES (306,
	0,
	0,
	54,
	23,
	23,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_LIN
	VALUES (306,
	'0');
INSERT INTO V_VAL
	VALUES (329,
	1,
	0,
	56,
	3,
	5,
	0,
	0,
	0,
	0,
	13,
	159);
INSERT INTO V_IRF
	VALUES (329,
	309);
INSERT INTO V_VAL
	VALUES (313,
	1,
	0,
	56,
	7,
	12,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_AVL
	VALUES (313,
	329,
	310,
	330);
INSERT INTO V_VAL
	VALUES (312,
	0,
	0,
	56,
	16,
	16,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_TVL
	VALUES (312,
	171);
INSERT INTO V_VAL
	VALUES (316,
	1,
	0,
	59,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_TVL
	VALUES (316,
	171);
INSERT INTO V_VAL
	VALUES (331,
	0,
	0,
	59,
	7,
	7,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_TVL
	VALUES (331,
	171);
INSERT INTO V_VAL
	VALUES (315,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_BIN
	VALUES (315,
	332,
	331,
	'-');
INSERT INTO V_VAL
	VALUES (332,
	0,
	0,
	59,
	11,
	11,
	0,
	0,
	0,
	0,
	7,
	159);
INSERT INTO V_LIN
	VALUES (332,
	'1');
INSERT INTO V_VAR
	VALUES (281,
	159,
	'row',
	1,
	13);
INSERT INTO V_INT
	VALUES (281,
	0,
	162);
INSERT INTO V_LOC
	VALUES (333,
	39,
	26,
	28,
	281);
INSERT INTO V_LOC
	VALUES (334,
	40,
	3,
	5,
	281);
INSERT INTO V_LOC
	VALUES (335,
	41,
	10,
	12,
	281);
INSERT INTO V_VAR
	VALUES (295,
	159,
	'column',
	1,
	13);
INSERT INTO V_INT
	VALUES (295,
	0,
	296);
INSERT INTO V_LOC
	VALUES (336,
	47,
	26,
	31,
	295);
INSERT INTO V_LOC
	VALUES (337,
	48,
	3,
	8,
	295);
INSERT INTO V_LOC
	VALUES (338,
	49,
	10,
	15,
	295);
INSERT INTO V_VAR
	VALUES (309,
	159,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (309,
	0,
	310);
INSERT INTO V_LOC
	VALUES (339,
	55,
	26,
	28,
	309);
INSERT INTO V_LOC
	VALUES (340,
	56,
	3,
	5,
	309);
INSERT INTO V_LOC
	VALUES (341,
	57,
	10,
	12,
	309);
INSERT INTO ACT_BLK
	VALUES (164,
	1,
	0,
	0,
	'',
	'',
	'',
	65,
	3,
	64,
	41,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (342,
	164,
	343,
	64,
	3,
	'setup line: 64');
INSERT INTO ACT_FIO
	VALUES (342,
	344,
	1,
	'many',
	296,
	64,
	41);
INSERT INTO ACT_SMT
	VALUES (343,
	164,
	0,
	65,
	3,
	'setup line: 65');
INSERT INTO ACT_FOR
	VALUES (343,
	345,
	1,
	346,
	344,
	296);
INSERT INTO V_VAR
	VALUES (344,
	164,
	'columns',
	1,
	14);
INSERT INTO V_INS
	VALUES (344,
	296);
INSERT INTO V_LOC
	VALUES (347,
	64,
	15,
	21,
	344);
INSERT INTO V_LOC
	VALUES (348,
	65,
	22,
	28,
	344);
INSERT INTO V_VAR
	VALUES (346,
	164,
	'column',
	1,
	13);
INSERT INTO V_INT
	VALUES (346,
	1,
	296);
INSERT INTO V_LOC
	VALUES (349,
	65,
	12,
	17,
	346);
INSERT INTO V_LOC
	VALUES (350,
	70,
	20,
	25,
	346);
INSERT INTO ACT_BLK
	VALUES (345,
	1,
	0,
	1,
	'',
	'',
	'',
	74,
	5,
	73,
	42,
	0,
	0,
	70,
	34,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (351,
	345,
	352,
	66,
	5,
	'setup line: 66');
INSERT INTO ACT_CR
	VALUES (351,
	353,
	1,
	168,
	66,
	36);
INSERT INTO ACT_SMT
	VALUES (352,
	345,
	354,
	67,
	5,
	'setup line: 67');
INSERT INTO ACT_FIW
	VALUES (352,
	149,
	0,
	'any',
	355,
	150,
	67,
	40);
INSERT INTO ACT_SMT
	VALUES (354,
	345,
	356,
	68,
	5,
	'setup line: 68');
INSERT INTO ACT_REL
	VALUES (354,
	353,
	149,
	'',
	357,
	68,
	33,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (356,
	345,
	358,
	69,
	5,
	'setup line: 69');
INSERT INTO ACT_REL
	VALUES (356,
	353,
	165,
	'',
	359,
	69,
	31,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (358,
	345,
	360,
	70,
	5,
	'setup line: 70');
INSERT INTO ACT_REL
	VALUES (358,
	353,
	346,
	'',
	361,
	70,
	34,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (360,
	345,
	362,
	73,
	5,
	'setup line: 73');
INSERT INTO ACT_FIW
	VALUES (360,
	363,
	1,
	'many',
	364,
	150,
	73,
	42);
INSERT INTO ACT_SMT
	VALUES (362,
	345,
	0,
	74,
	5,
	'setup line: 74');
INSERT INTO ACT_FOR
	VALUES (362,
	365,
	0,
	149,
	363,
	150);
INSERT INTO V_VAL
	VALUES (366,
	0,
	0,
	67,
	54,
	-1,
	0,
	0,
	0,
	0,
	13,
	345);
INSERT INTO V_SLR
	VALUES (366,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (367,
	0,
	0,
	67,
	63,
	67,
	0,
	0,
	0,
	0,
	7,
	345);
INSERT INTO V_AVL
	VALUES (367,
	366,
	150,
	182);
INSERT INTO V_VAL
	VALUES (355,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	345);
INSERT INTO V_BIN
	VALUES (355,
	368,
	367,
	'==');
INSERT INTO V_VAL
	VALUES (368,
	0,
	0,
	67,
	72,
	72,
	0,
	0,
	0,
	0,
	7,
	345);
INSERT INTO V_LIN
	VALUES (368,
	'0');
INSERT INTO V_VAL
	VALUES (369,
	0,
	0,
	73,
	56,
	-1,
	0,
	0,
	0,
	0,
	13,
	345);
INSERT INTO V_SLR
	VALUES (369,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (370,
	0,
	0,
	73,
	65,
	69,
	0,
	0,
	0,
	0,
	7,
	345);
INSERT INTO V_AVL
	VALUES (370,
	369,
	150,
	182);
INSERT INTO V_VAL
	VALUES (364,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	345);
INSERT INTO V_BIN
	VALUES (364,
	371,
	370,
	'!=');
INSERT INTO V_VAL
	VALUES (371,
	0,
	0,
	73,
	74,
	74,
	0,
	0,
	0,
	0,
	7,
	345);
INSERT INTO V_LIN
	VALUES (371,
	'0');
INSERT INTO V_VAR
	VALUES (353,
	345,
	'cell',
	1,
	13);
INSERT INTO V_INT
	VALUES (353,
	0,
	168);
INSERT INTO V_LOC
	VALUES (372,
	66,
	28,
	31,
	353);
INSERT INTO V_LOC
	VALUES (373,
	68,
	12,
	15,
	353);
INSERT INTO V_LOC
	VALUES (374,
	69,
	12,
	15,
	353);
INSERT INTO V_LOC
	VALUES (375,
	70,
	12,
	15,
	353);
INSERT INTO V_LOC
	VALUES (376,
	76,
	23,
	26,
	353);
INSERT INTO V_VAR
	VALUES (363,
	345,
	'digits',
	1,
	14);
INSERT INTO V_INS
	VALUES (363,
	150);
INSERT INTO V_LOC
	VALUES (377,
	73,
	17,
	22,
	363);
INSERT INTO V_LOC
	VALUES (378,
	74,
	23,
	28,
	363);
INSERT INTO ACT_BLK
	VALUES (365,
	0,
	0,
	0,
	'',
	'',
	'',
	76,
	7,
	75,
	42,
	0,
	0,
	76,
	35,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (379,
	365,
	380,
	75,
	7,
	'setup line: 75');
INSERT INTO ACT_CR
	VALUES (379,
	381,
	1,
	382,
	75,
	42);
INSERT INTO ACT_SMT
	VALUES (380,
	365,
	0,
	76,
	7,
	'setup line: 76');
INSERT INTO ACT_RU
	VALUES (380,
	149,
	353,
	381,
	'',
	383,
	76,
	35,
	0,
	0);
INSERT INTO V_VAR
	VALUES (381,
	365,
	'eligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (381,
	0,
	382);
INSERT INTO V_LOC
	VALUES (384,
	75,
	30,
	37,
	381);
INSERT INTO V_LOC
	VALUES (385,
	76,
	44,
	51,
	381);
INSERT INTO ACT_BLK
	VALUES (169,
	0,
	0,
	0,
	'',
	'',
	'',
	116,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (386,
	169,
	0,
	84,
	3,
	'setup line: 84');
INSERT INTO ACT_IF
	VALUES (386,
	387,
	388,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (389,
	169,
	0,
	88,
	3,
	'setup line: 88');
INSERT INTO ACT_EL
	VALUES (389,
	390,
	391,
	386);
INSERT INTO ACT_SMT
	VALUES (392,
	169,
	0,
	92,
	3,
	'setup line: 92');
INSERT INTO ACT_EL
	VALUES (392,
	393,
	394,
	386);
INSERT INTO ACT_SMT
	VALUES (395,
	169,
	0,
	96,
	3,
	'setup line: 96');
INSERT INTO ACT_EL
	VALUES (395,
	396,
	397,
	386);
INSERT INTO ACT_SMT
	VALUES (398,
	169,
	0,
	100,
	3,
	'setup line: 100');
INSERT INTO ACT_EL
	VALUES (398,
	399,
	400,
	386);
INSERT INTO ACT_SMT
	VALUES (401,
	169,
	0,
	104,
	3,
	'setup line: 104');
INSERT INTO ACT_EL
	VALUES (401,
	402,
	403,
	386);
INSERT INTO ACT_SMT
	VALUES (404,
	169,
	0,
	108,
	3,
	'setup line: 108');
INSERT INTO ACT_EL
	VALUES (404,
	405,
	406,
	386);
INSERT INTO ACT_SMT
	VALUES (407,
	169,
	0,
	112,
	3,
	'setup line: 112');
INSERT INTO ACT_EL
	VALUES (407,
	408,
	409,
	386);
INSERT INTO ACT_SMT
	VALUES (410,
	169,
	0,
	116,
	3,
	'setup line: 116');
INSERT INTO ACT_EL
	VALUES (410,
	411,
	412,
	386);
INSERT INTO V_VAL
	VALUES (413,
	0,
	0,
	84,
	10,
	13,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (413,
	170);
INSERT INTO V_VAL
	VALUES (414,
	0,
	0,
	84,
	15,
	24,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (414,
	413,
	168,
	415);
INSERT INTO V_VAL
	VALUES (416,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (416,
	417,
	414,
	'<=');
INSERT INTO V_VAL
	VALUES (417,
	0,
	0,
	84,
	29,
	29,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (417,
	'3');
INSERT INTO V_VAL
	VALUES (418,
	0,
	0,
	85,
	8,
	11,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (418,
	170);
INSERT INTO V_VAL
	VALUES (419,
	0,
	0,
	85,
	13,
	25,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (419,
	418,
	168,
	420);
INSERT INTO V_VAL
	VALUES (421,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (421,
	422,
	419,
	'<=');
INSERT INTO V_VAL
	VALUES (422,
	0,
	0,
	85,
	30,
	30,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (422,
	'3');
INSERT INTO V_VAL
	VALUES (388,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (388,
	421,
	416,
	'and');
INSERT INTO V_VAL
	VALUES (423,
	0,
	0,
	88,
	12,
	15,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (423,
	170);
INSERT INTO V_VAL
	VALUES (424,
	0,
	0,
	88,
	17,
	26,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (424,
	423,
	168,
	415);
INSERT INTO V_VAL
	VALUES (425,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (425,
	426,
	424,
	'<=');
INSERT INTO V_VAL
	VALUES (426,
	0,
	0,
	88,
	31,
	31,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (426,
	'3');
INSERT INTO V_VAL
	VALUES (427,
	0,
	0,
	89,
	10,
	10,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (427,
	'4');
INSERT INTO V_VAL
	VALUES (428,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (428,
	429,
	427,
	'<=');
INSERT INTO V_VAL
	VALUES (430,
	0,
	0,
	89,
	15,
	18,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (430,
	170);
INSERT INTO V_VAL
	VALUES (429,
	0,
	0,
	89,
	20,
	32,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (429,
	430,
	168,
	420);
INSERT INTO V_VAL
	VALUES (431,
	0,
	0,
	89,
	42,
	45,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (431,
	170);
INSERT INTO V_VAL
	VALUES (432,
	0,
	0,
	89,
	47,
	59,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (432,
	431,
	168,
	420);
INSERT INTO V_VAL
	VALUES (433,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (433,
	434,
	432,
	'<=');
INSERT INTO V_VAL
	VALUES (434,
	0,
	0,
	89,
	64,
	64,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (434,
	'6');
INSERT INTO V_VAL
	VALUES (435,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (435,
	433,
	428,
	'and');
INSERT INTO V_VAL
	VALUES (391,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (391,
	435,
	425,
	'and');
INSERT INTO V_VAL
	VALUES (436,
	0,
	0,
	92,
	12,
	15,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (436,
	170);
INSERT INTO V_VAL
	VALUES (437,
	0,
	0,
	92,
	17,
	26,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (437,
	436,
	168,
	415);
INSERT INTO V_VAL
	VALUES (438,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (438,
	439,
	437,
	'<=');
INSERT INTO V_VAL
	VALUES (439,
	0,
	0,
	92,
	31,
	31,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (439,
	'3');
INSERT INTO V_VAL
	VALUES (440,
	0,
	0,
	93,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (440,
	'7');
INSERT INTO V_VAL
	VALUES (441,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (441,
	442,
	440,
	'<=');
INSERT INTO V_VAL
	VALUES (443,
	0,
	0,
	93,
	13,
	16,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (443,
	170);
INSERT INTO V_VAL
	VALUES (442,
	0,
	0,
	93,
	18,
	30,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (442,
	443,
	168,
	420);
INSERT INTO V_VAL
	VALUES (394,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (394,
	441,
	438,
	'and');
INSERT INTO V_VAL
	VALUES (444,
	0,
	0,
	96,
	14,
	14,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (444,
	'4');
INSERT INTO V_VAL
	VALUES (445,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (445,
	446,
	444,
	'<=');
INSERT INTO V_VAL
	VALUES (447,
	0,
	0,
	96,
	19,
	22,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (447,
	170);
INSERT INTO V_VAL
	VALUES (446,
	0,
	0,
	96,
	24,
	33,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (446,
	447,
	168,
	415);
INSERT INTO V_VAL
	VALUES (448,
	0,
	0,
	96,
	43,
	46,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (448,
	170);
INSERT INTO V_VAL
	VALUES (449,
	0,
	0,
	96,
	48,
	57,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (449,
	448,
	168,
	415);
INSERT INTO V_VAL
	VALUES (450,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (450,
	451,
	449,
	'<=');
INSERT INTO V_VAL
	VALUES (451,
	0,
	0,
	96,
	62,
	62,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (451,
	'6');
INSERT INTO V_VAL
	VALUES (452,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (452,
	450,
	445,
	'and');
INSERT INTO V_VAL
	VALUES (453,
	0,
	0,
	97,
	8,
	11,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (453,
	170);
INSERT INTO V_VAL
	VALUES (454,
	0,
	0,
	97,
	13,
	25,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (454,
	453,
	168,
	420);
INSERT INTO V_VAL
	VALUES (455,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (455,
	456,
	454,
	'<=');
INSERT INTO V_VAL
	VALUES (456,
	0,
	0,
	97,
	30,
	30,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (456,
	'3');
INSERT INTO V_VAL
	VALUES (397,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (397,
	455,
	452,
	'and');
INSERT INTO V_VAL
	VALUES (457,
	0,
	0,
	100,
	14,
	14,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (457,
	'4');
INSERT INTO V_VAL
	VALUES (458,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (458,
	459,
	457,
	'<=');
INSERT INTO V_VAL
	VALUES (460,
	0,
	0,
	100,
	19,
	22,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (460,
	170);
INSERT INTO V_VAL
	VALUES (459,
	0,
	0,
	100,
	24,
	33,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (459,
	460,
	168,
	415);
INSERT INTO V_VAL
	VALUES (461,
	0,
	0,
	100,
	43,
	46,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (461,
	170);
INSERT INTO V_VAL
	VALUES (462,
	0,
	0,
	100,
	48,
	57,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (462,
	461,
	168,
	415);
INSERT INTO V_VAL
	VALUES (463,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (463,
	464,
	462,
	'<=');
INSERT INTO V_VAL
	VALUES (464,
	0,
	0,
	100,
	62,
	62,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (464,
	'6');
INSERT INTO V_VAL
	VALUES (465,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (465,
	463,
	458,
	'and');
INSERT INTO V_VAL
	VALUES (466,
	0,
	0,
	101,
	10,
	10,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (466,
	'4');
INSERT INTO V_VAL
	VALUES (467,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (467,
	468,
	466,
	'<=');
INSERT INTO V_VAL
	VALUES (469,
	0,
	0,
	101,
	15,
	18,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (469,
	170);
INSERT INTO V_VAL
	VALUES (468,
	0,
	0,
	101,
	20,
	32,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (468,
	469,
	168,
	420);
INSERT INTO V_VAL
	VALUES (470,
	0,
	0,
	101,
	42,
	45,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (470,
	170);
INSERT INTO V_VAL
	VALUES (471,
	0,
	0,
	101,
	47,
	59,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (471,
	470,
	168,
	420);
INSERT INTO V_VAL
	VALUES (472,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (472,
	473,
	471,
	'<=');
INSERT INTO V_VAL
	VALUES (473,
	0,
	0,
	101,
	64,
	64,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (473,
	'6');
INSERT INTO V_VAL
	VALUES (474,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (474,
	472,
	467,
	'and');
INSERT INTO V_VAL
	VALUES (400,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (400,
	474,
	465,
	'and');
INSERT INTO V_VAL
	VALUES (475,
	0,
	0,
	104,
	14,
	14,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (475,
	'4');
INSERT INTO V_VAL
	VALUES (476,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (476,
	477,
	475,
	'<=');
INSERT INTO V_VAL
	VALUES (478,
	0,
	0,
	104,
	19,
	22,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (478,
	170);
INSERT INTO V_VAL
	VALUES (477,
	0,
	0,
	104,
	24,
	33,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (477,
	478,
	168,
	415);
INSERT INTO V_VAL
	VALUES (479,
	0,
	0,
	104,
	43,
	46,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (479,
	170);
INSERT INTO V_VAL
	VALUES (480,
	0,
	0,
	104,
	48,
	57,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (480,
	479,
	168,
	415);
INSERT INTO V_VAL
	VALUES (481,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (481,
	482,
	480,
	'<=');
INSERT INTO V_VAL
	VALUES (482,
	0,
	0,
	104,
	62,
	62,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (482,
	'6');
INSERT INTO V_VAL
	VALUES (483,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (483,
	481,
	476,
	'and');
INSERT INTO V_VAL
	VALUES (484,
	0,
	0,
	105,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (484,
	'7');
INSERT INTO V_VAL
	VALUES (485,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (485,
	486,
	484,
	'<=');
INSERT INTO V_VAL
	VALUES (487,
	0,
	0,
	105,
	13,
	16,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (487,
	170);
INSERT INTO V_VAL
	VALUES (486,
	0,
	0,
	105,
	18,
	30,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (486,
	487,
	168,
	420);
INSERT INTO V_VAL
	VALUES (403,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (403,
	485,
	483,
	'and');
INSERT INTO V_VAL
	VALUES (488,
	0,
	0,
	108,
	12,
	12,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (488,
	'7');
INSERT INTO V_VAL
	VALUES (489,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (489,
	490,
	488,
	'<=');
INSERT INTO V_VAL
	VALUES (491,
	0,
	0,
	108,
	17,
	20,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (491,
	170);
INSERT INTO V_VAL
	VALUES (490,
	0,
	0,
	108,
	22,
	31,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (490,
	491,
	168,
	415);
INSERT INTO V_VAL
	VALUES (492,
	0,
	0,
	109,
	8,
	11,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (492,
	170);
INSERT INTO V_VAL
	VALUES (493,
	0,
	0,
	109,
	13,
	25,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (493,
	492,
	168,
	420);
INSERT INTO V_VAL
	VALUES (494,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (494,
	495,
	493,
	'<=');
INSERT INTO V_VAL
	VALUES (495,
	0,
	0,
	109,
	30,
	30,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (495,
	'3');
INSERT INTO V_VAL
	VALUES (406,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (406,
	494,
	489,
	'and');
INSERT INTO V_VAL
	VALUES (496,
	0,
	0,
	112,
	12,
	12,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (496,
	'7');
INSERT INTO V_VAL
	VALUES (497,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (497,
	498,
	496,
	'<=');
INSERT INTO V_VAL
	VALUES (499,
	0,
	0,
	112,
	17,
	20,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (499,
	170);
INSERT INTO V_VAL
	VALUES (498,
	0,
	0,
	112,
	22,
	31,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (498,
	499,
	168,
	415);
INSERT INTO V_VAL
	VALUES (500,
	0,
	0,
	113,
	10,
	10,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (500,
	'4');
INSERT INTO V_VAL
	VALUES (501,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (501,
	502,
	500,
	'<=');
INSERT INTO V_VAL
	VALUES (503,
	0,
	0,
	113,
	15,
	18,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (503,
	170);
INSERT INTO V_VAL
	VALUES (502,
	0,
	0,
	113,
	20,
	32,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (502,
	503,
	168,
	420);
INSERT INTO V_VAL
	VALUES (504,
	0,
	0,
	113,
	42,
	45,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (504,
	170);
INSERT INTO V_VAL
	VALUES (505,
	0,
	0,
	113,
	47,
	59,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (505,
	504,
	168,
	420);
INSERT INTO V_VAL
	VALUES (506,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (506,
	507,
	505,
	'<=');
INSERT INTO V_VAL
	VALUES (507,
	0,
	0,
	113,
	64,
	64,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (507,
	'6');
INSERT INTO V_VAL
	VALUES (508,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (508,
	506,
	501,
	'and');
INSERT INTO V_VAL
	VALUES (409,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (409,
	508,
	497,
	'and');
INSERT INTO V_VAL
	VALUES (509,
	0,
	0,
	116,
	12,
	12,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (509,
	'7');
INSERT INTO V_VAL
	VALUES (510,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (510,
	511,
	509,
	'<=');
INSERT INTO V_VAL
	VALUES (512,
	0,
	0,
	116,
	17,
	20,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (512,
	170);
INSERT INTO V_VAL
	VALUES (511,
	0,
	0,
	116,
	22,
	31,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (511,
	512,
	168,
	415);
INSERT INTO V_VAL
	VALUES (513,
	0,
	0,
	117,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_LIN
	VALUES (513,
	'7');
INSERT INTO V_VAL
	VALUES (514,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (514,
	515,
	513,
	'<=');
INSERT INTO V_VAL
	VALUES (516,
	0,
	0,
	117,
	13,
	16,
	0,
	0,
	0,
	0,
	13,
	169);
INSERT INTO V_IRF
	VALUES (516,
	170);
INSERT INTO V_VAL
	VALUES (515,
	0,
	0,
	117,
	18,
	30,
	0,
	0,
	0,
	0,
	7,
	169);
INSERT INTO V_AVL
	VALUES (515,
	516,
	168,
	420);
INSERT INTO V_VAL
	VALUES (412,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	169);
INSERT INTO V_BIN
	VALUES (412,
	514,
	510,
	'and');
INSERT INTO ACT_BLK
	VALUES (387,
	1,
	0,
	1,
	'',
	'',
	'',
	87,
	5,
	86,
	38,
	0,
	0,
	87,
	31,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (517,
	387,
	518,
	86,
	5,
	'setup line: 86');
INSERT INTO ACT_FIW
	VALUES (517,
	519,
	1,
	'any',
	520,
	310,
	86,
	38);
INSERT INTO ACT_SMT
	VALUES (518,
	387,
	0,
	87,
	5,
	'setup line: 87');
INSERT INTO ACT_REL
	VALUES (518,
	170,
	519,
	'',
	521,
	87,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES (522,
	0,
	0,
	86,
	50,
	-1,
	0,
	0,
	0,
	0,
	13,
	387);
INSERT INTO V_SLR
	VALUES (522,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (523,
	0,
	0,
	86,
	59,
	64,
	0,
	0,
	0,
	0,
	7,
	387);
INSERT INTO V_AVL
	VALUES (523,
	522,
	310,
	330);
INSERT INTO V_VAL
	VALUES (520,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	387);
INSERT INTO V_BIN
	VALUES (520,
	524,
	523,
	'==');
INSERT INTO V_VAL
	VALUES (524,
	0,
	0,
	86,
	69,
	69,
	0,
	0,
	0,
	0,
	7,
	387);
INSERT INTO V_LIN
	VALUES (524,
	'1');
INSERT INTO V_VAR
	VALUES (519,
	387,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (519,
	0,
	310);
INSERT INTO V_LOC
	VALUES (525,
	86,
	16,
	18,
	519);
INSERT INTO V_LOC
	VALUES (526,
	87,
	20,
	22,
	519);
INSERT INTO ACT_BLK
	VALUES (390,
	1,
	0,
	1,
	'',
	'',
	'',
	91,
	5,
	90,
	38,
	0,
	0,
	91,
	31,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (527,
	390,
	528,
	90,
	5,
	'setup line: 90');
INSERT INTO ACT_FIW
	VALUES (527,
	529,
	1,
	'any',
	530,
	310,
	90,
	38);
INSERT INTO ACT_SMT
	VALUES (528,
	390,
	0,
	91,
	5,
	'setup line: 91');
INSERT INTO ACT_REL
	VALUES (528,
	170,
	529,
	'',
	521,
	91,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES (531,
	0,
	0,
	90,
	50,
	-1,
	0,
	0,
	0,
	0,
	13,
	390);
INSERT INTO V_SLR
	VALUES (531,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (532,
	0,
	0,
	90,
	59,
	64,
	0,
	0,
	0,
	0,
	7,
	390);
INSERT INTO V_AVL
	VALUES (532,
	531,
	310,
	330);
INSERT INTO V_VAL
	VALUES (530,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	390);
INSERT INTO V_BIN
	VALUES (530,
	533,
	532,
	'==');
INSERT INTO V_VAL
	VALUES (533,
	0,
	0,
	90,
	69,
	69,
	0,
	0,
	0,
	0,
	7,
	390);
INSERT INTO V_LIN
	VALUES (533,
	'2');
INSERT INTO V_VAR
	VALUES (529,
	390,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (529,
	0,
	310);
INSERT INTO V_LOC
	VALUES (534,
	90,
	16,
	18,
	529);
INSERT INTO V_LOC
	VALUES (535,
	91,
	20,
	22,
	529);
INSERT INTO ACT_BLK
	VALUES (393,
	1,
	0,
	1,
	'',
	'',
	'',
	95,
	5,
	94,
	38,
	0,
	0,
	95,
	31,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (536,
	393,
	537,
	94,
	5,
	'setup line: 94');
INSERT INTO ACT_FIW
	VALUES (536,
	538,
	1,
	'any',
	539,
	310,
	94,
	38);
INSERT INTO ACT_SMT
	VALUES (537,
	393,
	0,
	95,
	5,
	'setup line: 95');
INSERT INTO ACT_REL
	VALUES (537,
	170,
	538,
	'',
	521,
	95,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES (540,
	0,
	0,
	94,
	50,
	-1,
	0,
	0,
	0,
	0,
	13,
	393);
INSERT INTO V_SLR
	VALUES (540,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (541,
	0,
	0,
	94,
	59,
	64,
	0,
	0,
	0,
	0,
	7,
	393);
INSERT INTO V_AVL
	VALUES (541,
	540,
	310,
	330);
INSERT INTO V_VAL
	VALUES (539,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	393);
INSERT INTO V_BIN
	VALUES (539,
	542,
	541,
	'==');
INSERT INTO V_VAL
	VALUES (542,
	0,
	0,
	94,
	69,
	69,
	0,
	0,
	0,
	0,
	7,
	393);
INSERT INTO V_LIN
	VALUES (542,
	'3');
INSERT INTO V_VAR
	VALUES (538,
	393,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (538,
	0,
	310);
INSERT INTO V_LOC
	VALUES (543,
	94,
	16,
	18,
	538);
INSERT INTO V_LOC
	VALUES (544,
	95,
	20,
	22,
	538);
INSERT INTO ACT_BLK
	VALUES (396,
	1,
	0,
	1,
	'',
	'',
	'',
	99,
	5,
	98,
	38,
	0,
	0,
	99,
	31,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (545,
	396,
	546,
	98,
	5,
	'setup line: 98');
INSERT INTO ACT_FIW
	VALUES (545,
	547,
	1,
	'any',
	548,
	310,
	98,
	38);
INSERT INTO ACT_SMT
	VALUES (546,
	396,
	0,
	99,
	5,
	'setup line: 99');
INSERT INTO ACT_REL
	VALUES (546,
	170,
	547,
	'',
	521,
	99,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES (549,
	0,
	0,
	98,
	50,
	-1,
	0,
	0,
	0,
	0,
	13,
	396);
INSERT INTO V_SLR
	VALUES (549,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (550,
	0,
	0,
	98,
	59,
	64,
	0,
	0,
	0,
	0,
	7,
	396);
INSERT INTO V_AVL
	VALUES (550,
	549,
	310,
	330);
INSERT INTO V_VAL
	VALUES (548,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	396);
INSERT INTO V_BIN
	VALUES (548,
	551,
	550,
	'==');
INSERT INTO V_VAL
	VALUES (551,
	0,
	0,
	98,
	69,
	69,
	0,
	0,
	0,
	0,
	7,
	396);
INSERT INTO V_LIN
	VALUES (551,
	'4');
INSERT INTO V_VAR
	VALUES (547,
	396,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (547,
	0,
	310);
INSERT INTO V_LOC
	VALUES (552,
	98,
	16,
	18,
	547);
INSERT INTO V_LOC
	VALUES (553,
	99,
	20,
	22,
	547);
INSERT INTO ACT_BLK
	VALUES (399,
	1,
	0,
	1,
	'',
	'',
	'',
	103,
	5,
	102,
	38,
	0,
	0,
	103,
	31,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (554,
	399,
	555,
	102,
	5,
	'setup line: 102');
INSERT INTO ACT_FIW
	VALUES (554,
	556,
	1,
	'any',
	557,
	310,
	102,
	38);
INSERT INTO ACT_SMT
	VALUES (555,
	399,
	0,
	103,
	5,
	'setup line: 103');
INSERT INTO ACT_REL
	VALUES (555,
	170,
	556,
	'',
	521,
	103,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES (558,
	0,
	0,
	102,
	50,
	-1,
	0,
	0,
	0,
	0,
	13,
	399);
INSERT INTO V_SLR
	VALUES (558,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (559,
	0,
	0,
	102,
	59,
	64,
	0,
	0,
	0,
	0,
	7,
	399);
INSERT INTO V_AVL
	VALUES (559,
	558,
	310,
	330);
INSERT INTO V_VAL
	VALUES (557,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	399);
INSERT INTO V_BIN
	VALUES (557,
	560,
	559,
	'==');
INSERT INTO V_VAL
	VALUES (560,
	0,
	0,
	102,
	69,
	69,
	0,
	0,
	0,
	0,
	7,
	399);
INSERT INTO V_LIN
	VALUES (560,
	'5');
INSERT INTO V_VAR
	VALUES (556,
	399,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (556,
	0,
	310);
INSERT INTO V_LOC
	VALUES (561,
	102,
	16,
	18,
	556);
INSERT INTO V_LOC
	VALUES (562,
	103,
	20,
	22,
	556);
INSERT INTO ACT_BLK
	VALUES (402,
	1,
	0,
	1,
	'',
	'',
	'',
	107,
	5,
	106,
	38,
	0,
	0,
	107,
	31,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (563,
	402,
	564,
	106,
	5,
	'setup line: 106');
INSERT INTO ACT_FIW
	VALUES (563,
	565,
	1,
	'any',
	566,
	310,
	106,
	38);
INSERT INTO ACT_SMT
	VALUES (564,
	402,
	0,
	107,
	5,
	'setup line: 107');
INSERT INTO ACT_REL
	VALUES (564,
	170,
	565,
	'',
	521,
	107,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES (567,
	0,
	0,
	106,
	50,
	-1,
	0,
	0,
	0,
	0,
	13,
	402);
INSERT INTO V_SLR
	VALUES (567,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (568,
	0,
	0,
	106,
	59,
	64,
	0,
	0,
	0,
	0,
	7,
	402);
INSERT INTO V_AVL
	VALUES (568,
	567,
	310,
	330);
INSERT INTO V_VAL
	VALUES (566,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	402);
INSERT INTO V_BIN
	VALUES (566,
	569,
	568,
	'==');
INSERT INTO V_VAL
	VALUES (569,
	0,
	0,
	106,
	69,
	69,
	0,
	0,
	0,
	0,
	7,
	402);
INSERT INTO V_LIN
	VALUES (569,
	'6');
INSERT INTO V_VAR
	VALUES (565,
	402,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (565,
	0,
	310);
INSERT INTO V_LOC
	VALUES (570,
	106,
	16,
	18,
	565);
INSERT INTO V_LOC
	VALUES (571,
	107,
	20,
	22,
	565);
INSERT INTO ACT_BLK
	VALUES (405,
	1,
	0,
	1,
	'',
	'',
	'',
	111,
	5,
	110,
	38,
	0,
	0,
	111,
	31,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (572,
	405,
	573,
	110,
	5,
	'setup line: 110');
INSERT INTO ACT_FIW
	VALUES (572,
	574,
	1,
	'any',
	575,
	310,
	110,
	38);
INSERT INTO ACT_SMT
	VALUES (573,
	405,
	0,
	111,
	5,
	'setup line: 111');
INSERT INTO ACT_REL
	VALUES (573,
	170,
	574,
	'',
	521,
	111,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES (576,
	0,
	0,
	110,
	50,
	-1,
	0,
	0,
	0,
	0,
	13,
	405);
INSERT INTO V_SLR
	VALUES (576,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (577,
	0,
	0,
	110,
	59,
	64,
	0,
	0,
	0,
	0,
	7,
	405);
INSERT INTO V_AVL
	VALUES (577,
	576,
	310,
	330);
INSERT INTO V_VAL
	VALUES (575,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	405);
INSERT INTO V_BIN
	VALUES (575,
	578,
	577,
	'==');
INSERT INTO V_VAL
	VALUES (578,
	0,
	0,
	110,
	69,
	69,
	0,
	0,
	0,
	0,
	7,
	405);
INSERT INTO V_LIN
	VALUES (578,
	'7');
INSERT INTO V_VAR
	VALUES (574,
	405,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (574,
	0,
	310);
INSERT INTO V_LOC
	VALUES (579,
	110,
	16,
	18,
	574);
INSERT INTO V_LOC
	VALUES (580,
	111,
	20,
	22,
	574);
INSERT INTO ACT_BLK
	VALUES (408,
	1,
	0,
	1,
	'',
	'',
	'',
	115,
	5,
	114,
	38,
	0,
	0,
	115,
	31,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (581,
	408,
	582,
	114,
	5,
	'setup line: 114');
INSERT INTO ACT_FIW
	VALUES (581,
	583,
	1,
	'any',
	584,
	310,
	114,
	38);
INSERT INTO ACT_SMT
	VALUES (582,
	408,
	0,
	115,
	5,
	'setup line: 115');
INSERT INTO ACT_REL
	VALUES (582,
	170,
	583,
	'',
	521,
	115,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES (585,
	0,
	0,
	114,
	50,
	-1,
	0,
	0,
	0,
	0,
	13,
	408);
INSERT INTO V_SLR
	VALUES (585,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (586,
	0,
	0,
	114,
	59,
	64,
	0,
	0,
	0,
	0,
	7,
	408);
INSERT INTO V_AVL
	VALUES (586,
	585,
	310,
	330);
INSERT INTO V_VAL
	VALUES (584,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	408);
INSERT INTO V_BIN
	VALUES (584,
	587,
	586,
	'==');
INSERT INTO V_VAL
	VALUES (587,
	0,
	0,
	114,
	69,
	69,
	0,
	0,
	0,
	0,
	7,
	408);
INSERT INTO V_LIN
	VALUES (587,
	'8');
INSERT INTO V_VAR
	VALUES (583,
	408,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (583,
	0,
	310);
INSERT INTO V_LOC
	VALUES (588,
	114,
	16,
	18,
	583);
INSERT INTO V_LOC
	VALUES (589,
	115,
	20,
	22,
	583);
INSERT INTO ACT_BLK
	VALUES (411,
	1,
	0,
	1,
	'',
	'',
	'',
	119,
	5,
	118,
	38,
	0,
	0,
	119,
	31,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (590,
	411,
	591,
	118,
	5,
	'setup line: 118');
INSERT INTO ACT_FIW
	VALUES (590,
	592,
	1,
	'any',
	593,
	310,
	118,
	38);
INSERT INTO ACT_SMT
	VALUES (591,
	411,
	0,
	119,
	5,
	'setup line: 119');
INSERT INTO ACT_REL
	VALUES (591,
	170,
	592,
	'',
	521,
	119,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES (594,
	0,
	0,
	118,
	50,
	-1,
	0,
	0,
	0,
	0,
	13,
	411);
INSERT INTO V_SLR
	VALUES (594,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (595,
	0,
	0,
	118,
	59,
	64,
	0,
	0,
	0,
	0,
	7,
	411);
INSERT INTO V_AVL
	VALUES (595,
	594,
	310,
	330);
INSERT INTO V_VAL
	VALUES (593,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	411);
INSERT INTO V_BIN
	VALUES (593,
	596,
	595,
	'==');
INSERT INTO V_VAL
	VALUES (596,
	0,
	0,
	118,
	69,
	69,
	0,
	0,
	0,
	0,
	7,
	411);
INSERT INTO V_LIN
	VALUES (596,
	'9');
INSERT INTO V_VAR
	VALUES (592,
	411,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (592,
	0,
	310);
INSERT INTO V_LOC
	VALUES (597,
	118,
	16,
	18,
	592);
INSERT INTO V_LOC
	VALUES (598,
	119,
	20,
	22,
	592);
INSERT INTO ACT_BLK
	VALUES (113,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	124,
	3,
	124,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (599,
	113,
	0,
	124,
	3,
	'setup line: 124');
INSERT INTO ACT_BRG
	VALUES (599,
	69,
	124,
	8,
	124,
	3);
INSERT INTO V_VAL
	VALUES (600,
	0,
	0,
	124,
	25,
	40,
	0,
	0,
	0,
	0,
	9,
	113);
INSERT INTO V_LST
	VALUES (600,
	'PEI data found.');
INSERT INTO V_PAR
	VALUES (600,
	599,
	0,
	'message',
	0,
	124,
	17);
INSERT INTO S_FIP
	VALUES (102,
	601);
INSERT INTO S_SYNC
	VALUES (601,
	2,
	'setz1_given',
	'',
	'

CELL::set_given( row:1, column:3, answer:9 );
CELL::set_given( row:1, column:4, answer:3 );
CELL::set_given( row:1, column:9, answer:5 );

CELL::set_given( row:2, column:4, answer:5 );
CELL::set_given( row:2, column:5, answer:1 );
CELL::set_given( row:2, column:6, answer:4 );
CELL::set_given( row:2, column:8, answer:7 );

CELL::set_given( row:3, column:1, answer:1 );
CELL::set_given( row:3, column:2, answer:5 );
CELL::set_given( row:3, column:3, answer:6 );
CELL::set_given( row:3, column:8, answer:8 );

CELL::set_given( row:4, column:1, answer:9 );
CELL::set_given( row:4, column:5, answer:8 );
CELL::set_given( row:4, column:9, answer:1 );

CELL::set_given( row:5, column:1, answer:7 );
CELL::set_given( row:5, column:4, answer:9 );
CELL::set_given( row:5, column:6, answer:5 );
CELL::set_given( row:5, column:9, answer:2 );

CELL::set_given( row:6, column:1, answer:5 );
CELL::set_given( row:6, column:5, answer:3 );
CELL::set_given( row:6, column:9, answer:9 );

CELL::set_given( row:7, column:2, answer:2 );
CELL::set_given( row:7, column:7, answer:4 );
CELL::set_given( row:7, column:8, answer:1 );
CELL::set_given( row:7, column:9, answer:7 );

CELL::set_given( row:8, column:2, answer:4 );
CELL::set_given( row:8, column:4, answer:1 );
CELL::set_given( row:8, column:5, answer:5 );
CELL::set_given( row:8, column:6, answer:6 );

CELL::set_given( row:9, column:1, answer:3 );
CELL::set_given( row:9, column:6, answer:7 );
CELL::set_given( row:9, column:7, answer:5 );

',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (602,
	601);
INSERT INTO ACT_ACT
	VALUES (602,
	'function',
	0,
	603,
	0,
	0,
	'setz1_given',
	0);
INSERT INTO ACT_BLK
	VALUES (603,
	0,
	0,
	0,
	'CELL',
	'',
	'',
	42,
	1,
	42,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	602,
	0);
INSERT INTO ACT_SMT
	VALUES (604,
	603,
	605,
	3,
	1,
	'setz1_given line: 3');
INSERT INTO ACT_TFM
	VALUES (604,
	606,
	0,
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES (605,
	603,
	607,
	4,
	1,
	'setz1_given line: 4');
INSERT INTO ACT_TFM
	VALUES (605,
	606,
	0,
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES (607,
	603,
	608,
	5,
	1,
	'setz1_given line: 5');
INSERT INTO ACT_TFM
	VALUES (607,
	606,
	0,
	5,
	7,
	5,
	1);
INSERT INTO ACT_SMT
	VALUES (608,
	603,
	609,
	7,
	1,
	'setz1_given line: 7');
INSERT INTO ACT_TFM
	VALUES (608,
	606,
	0,
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES (609,
	603,
	610,
	8,
	1,
	'setz1_given line: 8');
INSERT INTO ACT_TFM
	VALUES (609,
	606,
	0,
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES (610,
	603,
	611,
	9,
	1,
	'setz1_given line: 9');
INSERT INTO ACT_TFM
	VALUES (610,
	606,
	0,
	9,
	7,
	9,
	1);
INSERT INTO ACT_SMT
	VALUES (611,
	603,
	612,
	10,
	1,
	'setz1_given line: 10');
INSERT INTO ACT_TFM
	VALUES (611,
	606,
	0,
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES (612,
	603,
	613,
	12,
	1,
	'setz1_given line: 12');
INSERT INTO ACT_TFM
	VALUES (612,
	606,
	0,
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES (613,
	603,
	614,
	13,
	1,
	'setz1_given line: 13');
INSERT INTO ACT_TFM
	VALUES (613,
	606,
	0,
	13,
	7,
	13,
	1);
INSERT INTO ACT_SMT
	VALUES (614,
	603,
	615,
	14,
	1,
	'setz1_given line: 14');
INSERT INTO ACT_TFM
	VALUES (614,
	606,
	0,
	14,
	7,
	14,
	1);
INSERT INTO ACT_SMT
	VALUES (615,
	603,
	616,
	15,
	1,
	'setz1_given line: 15');
INSERT INTO ACT_TFM
	VALUES (615,
	606,
	0,
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES (616,
	603,
	617,
	17,
	1,
	'setz1_given line: 17');
INSERT INTO ACT_TFM
	VALUES (616,
	606,
	0,
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES (617,
	603,
	618,
	18,
	1,
	'setz1_given line: 18');
INSERT INTO ACT_TFM
	VALUES (617,
	606,
	0,
	18,
	7,
	18,
	1);
INSERT INTO ACT_SMT
	VALUES (618,
	603,
	619,
	19,
	1,
	'setz1_given line: 19');
INSERT INTO ACT_TFM
	VALUES (618,
	606,
	0,
	19,
	7,
	19,
	1);
INSERT INTO ACT_SMT
	VALUES (619,
	603,
	620,
	21,
	1,
	'setz1_given line: 21');
INSERT INTO ACT_TFM
	VALUES (619,
	606,
	0,
	21,
	7,
	21,
	1);
INSERT INTO ACT_SMT
	VALUES (620,
	603,
	621,
	22,
	1,
	'setz1_given line: 22');
INSERT INTO ACT_TFM
	VALUES (620,
	606,
	0,
	22,
	7,
	22,
	1);
INSERT INTO ACT_SMT
	VALUES (621,
	603,
	622,
	23,
	1,
	'setz1_given line: 23');
INSERT INTO ACT_TFM
	VALUES (621,
	606,
	0,
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES (622,
	603,
	623,
	24,
	1,
	'setz1_given line: 24');
INSERT INTO ACT_TFM
	VALUES (622,
	606,
	0,
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES (623,
	603,
	624,
	26,
	1,
	'setz1_given line: 26');
INSERT INTO ACT_TFM
	VALUES (623,
	606,
	0,
	26,
	7,
	26,
	1);
INSERT INTO ACT_SMT
	VALUES (624,
	603,
	625,
	27,
	1,
	'setz1_given line: 27');
INSERT INTO ACT_TFM
	VALUES (624,
	606,
	0,
	27,
	7,
	27,
	1);
INSERT INTO ACT_SMT
	VALUES (625,
	603,
	626,
	28,
	1,
	'setz1_given line: 28');
INSERT INTO ACT_TFM
	VALUES (625,
	606,
	0,
	28,
	7,
	28,
	1);
INSERT INTO ACT_SMT
	VALUES (626,
	603,
	627,
	30,
	1,
	'setz1_given line: 30');
INSERT INTO ACT_TFM
	VALUES (626,
	606,
	0,
	30,
	7,
	30,
	1);
INSERT INTO ACT_SMT
	VALUES (627,
	603,
	628,
	31,
	1,
	'setz1_given line: 31');
INSERT INTO ACT_TFM
	VALUES (627,
	606,
	0,
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES (628,
	603,
	629,
	32,
	1,
	'setz1_given line: 32');
INSERT INTO ACT_TFM
	VALUES (628,
	606,
	0,
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES (629,
	603,
	630,
	33,
	1,
	'setz1_given line: 33');
INSERT INTO ACT_TFM
	VALUES (629,
	606,
	0,
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES (630,
	603,
	631,
	35,
	1,
	'setz1_given line: 35');
INSERT INTO ACT_TFM
	VALUES (630,
	606,
	0,
	35,
	7,
	35,
	1);
INSERT INTO ACT_SMT
	VALUES (631,
	603,
	632,
	36,
	1,
	'setz1_given line: 36');
INSERT INTO ACT_TFM
	VALUES (631,
	606,
	0,
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES (632,
	603,
	633,
	37,
	1,
	'setz1_given line: 37');
INSERT INTO ACT_TFM
	VALUES (632,
	606,
	0,
	37,
	7,
	37,
	1);
INSERT INTO ACT_SMT
	VALUES (633,
	603,
	634,
	38,
	1,
	'setz1_given line: 38');
INSERT INTO ACT_TFM
	VALUES (633,
	606,
	0,
	38,
	7,
	38,
	1);
INSERT INTO ACT_SMT
	VALUES (634,
	603,
	635,
	40,
	1,
	'setz1_given line: 40');
INSERT INTO ACT_TFM
	VALUES (634,
	606,
	0,
	40,
	7,
	40,
	1);
INSERT INTO ACT_SMT
	VALUES (635,
	603,
	636,
	41,
	1,
	'setz1_given line: 41');
INSERT INTO ACT_TFM
	VALUES (635,
	606,
	0,
	41,
	7,
	41,
	1);
INSERT INTO ACT_SMT
	VALUES (636,
	603,
	0,
	42,
	1,
	'setz1_given line: 42');
INSERT INTO ACT_TFM
	VALUES (636,
	606,
	0,
	42,
	7,
	42,
	1);
INSERT INTO V_VAL
	VALUES (637,
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (637,
	'1');
INSERT INTO V_PAR
	VALUES (637,
	604,
	0,
	'row',
	638,
	3,
	18);
INSERT INTO V_VAL
	VALUES (638,
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (638,
	'3');
INSERT INTO V_PAR
	VALUES (638,
	604,
	0,
	'column',
	639,
	3,
	25);
INSERT INTO V_VAL
	VALUES (639,
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (639,
	'9');
INSERT INTO V_PAR
	VALUES (639,
	604,
	0,
	'answer',
	0,
	3,
	35);
INSERT INTO V_VAL
	VALUES (640,
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (640,
	'1');
INSERT INTO V_PAR
	VALUES (640,
	605,
	0,
	'row',
	641,
	4,
	18);
INSERT INTO V_VAL
	VALUES (641,
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (641,
	'4');
INSERT INTO V_PAR
	VALUES (641,
	605,
	0,
	'column',
	642,
	4,
	25);
INSERT INTO V_VAL
	VALUES (642,
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (642,
	'3');
INSERT INTO V_PAR
	VALUES (642,
	605,
	0,
	'answer',
	0,
	4,
	35);
INSERT INTO V_VAL
	VALUES (643,
	0,
	0,
	5,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (643,
	'1');
INSERT INTO V_PAR
	VALUES (643,
	607,
	0,
	'row',
	644,
	5,
	18);
INSERT INTO V_VAL
	VALUES (644,
	0,
	0,
	5,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (644,
	'9');
INSERT INTO V_PAR
	VALUES (644,
	607,
	0,
	'column',
	645,
	5,
	25);
INSERT INTO V_VAL
	VALUES (645,
	0,
	0,
	5,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (645,
	'5');
INSERT INTO V_PAR
	VALUES (645,
	607,
	0,
	'answer',
	0,
	5,
	35);
INSERT INTO V_VAL
	VALUES (646,
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (646,
	'2');
INSERT INTO V_PAR
	VALUES (646,
	608,
	0,
	'row',
	647,
	7,
	18);
INSERT INTO V_VAL
	VALUES (647,
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (647,
	'4');
INSERT INTO V_PAR
	VALUES (647,
	608,
	0,
	'column',
	648,
	7,
	25);
INSERT INTO V_VAL
	VALUES (648,
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (648,
	'5');
INSERT INTO V_PAR
	VALUES (648,
	608,
	0,
	'answer',
	0,
	7,
	35);
INSERT INTO V_VAL
	VALUES (649,
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (649,
	'2');
INSERT INTO V_PAR
	VALUES (649,
	609,
	0,
	'row',
	650,
	8,
	18);
INSERT INTO V_VAL
	VALUES (650,
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (650,
	'5');
INSERT INTO V_PAR
	VALUES (650,
	609,
	0,
	'column',
	651,
	8,
	25);
INSERT INTO V_VAL
	VALUES (651,
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (651,
	'1');
INSERT INTO V_PAR
	VALUES (651,
	609,
	0,
	'answer',
	0,
	8,
	35);
INSERT INTO V_VAL
	VALUES (652,
	0,
	0,
	9,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (652,
	'2');
INSERT INTO V_PAR
	VALUES (652,
	610,
	0,
	'row',
	653,
	9,
	18);
INSERT INTO V_VAL
	VALUES (653,
	0,
	0,
	9,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (653,
	'6');
INSERT INTO V_PAR
	VALUES (653,
	610,
	0,
	'column',
	654,
	9,
	25);
INSERT INTO V_VAL
	VALUES (654,
	0,
	0,
	9,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (654,
	'4');
INSERT INTO V_PAR
	VALUES (654,
	610,
	0,
	'answer',
	0,
	9,
	35);
INSERT INTO V_VAL
	VALUES (655,
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (655,
	'2');
INSERT INTO V_PAR
	VALUES (655,
	611,
	0,
	'row',
	656,
	10,
	18);
INSERT INTO V_VAL
	VALUES (656,
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (656,
	'8');
INSERT INTO V_PAR
	VALUES (656,
	611,
	0,
	'column',
	657,
	10,
	25);
INSERT INTO V_VAL
	VALUES (657,
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (657,
	'7');
INSERT INTO V_PAR
	VALUES (657,
	611,
	0,
	'answer',
	0,
	10,
	35);
INSERT INTO V_VAL
	VALUES (658,
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (658,
	'3');
INSERT INTO V_PAR
	VALUES (658,
	612,
	0,
	'row',
	659,
	12,
	18);
INSERT INTO V_VAL
	VALUES (659,
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (659,
	'1');
INSERT INTO V_PAR
	VALUES (659,
	612,
	0,
	'column',
	660,
	12,
	25);
INSERT INTO V_VAL
	VALUES (660,
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (660,
	'1');
INSERT INTO V_PAR
	VALUES (660,
	612,
	0,
	'answer',
	0,
	12,
	35);
INSERT INTO V_VAL
	VALUES (661,
	0,
	0,
	13,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (661,
	'3');
INSERT INTO V_PAR
	VALUES (661,
	613,
	0,
	'row',
	662,
	13,
	18);
INSERT INTO V_VAL
	VALUES (662,
	0,
	0,
	13,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (662,
	'2');
INSERT INTO V_PAR
	VALUES (662,
	613,
	0,
	'column',
	663,
	13,
	25);
INSERT INTO V_VAL
	VALUES (663,
	0,
	0,
	13,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (663,
	'5');
INSERT INTO V_PAR
	VALUES (663,
	613,
	0,
	'answer',
	0,
	13,
	35);
INSERT INTO V_VAL
	VALUES (664,
	0,
	0,
	14,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (664,
	'3');
INSERT INTO V_PAR
	VALUES (664,
	614,
	0,
	'row',
	665,
	14,
	18);
INSERT INTO V_VAL
	VALUES (665,
	0,
	0,
	14,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (665,
	'3');
INSERT INTO V_PAR
	VALUES (665,
	614,
	0,
	'column',
	666,
	14,
	25);
INSERT INTO V_VAL
	VALUES (666,
	0,
	0,
	14,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (666,
	'6');
INSERT INTO V_PAR
	VALUES (666,
	614,
	0,
	'answer',
	0,
	14,
	35);
INSERT INTO V_VAL
	VALUES (667,
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (667,
	'3');
INSERT INTO V_PAR
	VALUES (667,
	615,
	0,
	'row',
	668,
	15,
	18);
INSERT INTO V_VAL
	VALUES (668,
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (668,
	'8');
INSERT INTO V_PAR
	VALUES (668,
	615,
	0,
	'column',
	669,
	15,
	25);
INSERT INTO V_VAL
	VALUES (669,
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (669,
	'8');
INSERT INTO V_PAR
	VALUES (669,
	615,
	0,
	'answer',
	0,
	15,
	35);
INSERT INTO V_VAL
	VALUES (670,
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (670,
	'4');
INSERT INTO V_PAR
	VALUES (670,
	616,
	0,
	'row',
	671,
	17,
	18);
INSERT INTO V_VAL
	VALUES (671,
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (671,
	'1');
INSERT INTO V_PAR
	VALUES (671,
	616,
	0,
	'column',
	672,
	17,
	25);
INSERT INTO V_VAL
	VALUES (672,
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (672,
	'9');
INSERT INTO V_PAR
	VALUES (672,
	616,
	0,
	'answer',
	0,
	17,
	35);
INSERT INTO V_VAL
	VALUES (673,
	0,
	0,
	18,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (673,
	'4');
INSERT INTO V_PAR
	VALUES (673,
	617,
	0,
	'row',
	674,
	18,
	18);
INSERT INTO V_VAL
	VALUES (674,
	0,
	0,
	18,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (674,
	'5');
INSERT INTO V_PAR
	VALUES (674,
	617,
	0,
	'column',
	675,
	18,
	25);
INSERT INTO V_VAL
	VALUES (675,
	0,
	0,
	18,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (675,
	'8');
INSERT INTO V_PAR
	VALUES (675,
	617,
	0,
	'answer',
	0,
	18,
	35);
INSERT INTO V_VAL
	VALUES (676,
	0,
	0,
	19,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (676,
	'4');
INSERT INTO V_PAR
	VALUES (676,
	618,
	0,
	'row',
	677,
	19,
	18);
INSERT INTO V_VAL
	VALUES (677,
	0,
	0,
	19,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (677,
	'9');
INSERT INTO V_PAR
	VALUES (677,
	618,
	0,
	'column',
	678,
	19,
	25);
INSERT INTO V_VAL
	VALUES (678,
	0,
	0,
	19,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (678,
	'1');
INSERT INTO V_PAR
	VALUES (678,
	618,
	0,
	'answer',
	0,
	19,
	35);
INSERT INTO V_VAL
	VALUES (679,
	0,
	0,
	21,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (679,
	'5');
INSERT INTO V_PAR
	VALUES (679,
	619,
	0,
	'row',
	680,
	21,
	18);
INSERT INTO V_VAL
	VALUES (680,
	0,
	0,
	21,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (680,
	'1');
INSERT INTO V_PAR
	VALUES (680,
	619,
	0,
	'column',
	681,
	21,
	25);
INSERT INTO V_VAL
	VALUES (681,
	0,
	0,
	21,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (681,
	'7');
INSERT INTO V_PAR
	VALUES (681,
	619,
	0,
	'answer',
	0,
	21,
	35);
INSERT INTO V_VAL
	VALUES (682,
	0,
	0,
	22,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (682,
	'5');
INSERT INTO V_PAR
	VALUES (682,
	620,
	0,
	'row',
	683,
	22,
	18);
INSERT INTO V_VAL
	VALUES (683,
	0,
	0,
	22,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (683,
	'4');
INSERT INTO V_PAR
	VALUES (683,
	620,
	0,
	'column',
	684,
	22,
	25);
INSERT INTO V_VAL
	VALUES (684,
	0,
	0,
	22,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (684,
	'9');
INSERT INTO V_PAR
	VALUES (684,
	620,
	0,
	'answer',
	0,
	22,
	35);
INSERT INTO V_VAL
	VALUES (685,
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (685,
	'5');
INSERT INTO V_PAR
	VALUES (685,
	621,
	0,
	'row',
	686,
	23,
	18);
INSERT INTO V_VAL
	VALUES (686,
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (686,
	'6');
INSERT INTO V_PAR
	VALUES (686,
	621,
	0,
	'column',
	687,
	23,
	25);
INSERT INTO V_VAL
	VALUES (687,
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (687,
	'5');
INSERT INTO V_PAR
	VALUES (687,
	621,
	0,
	'answer',
	0,
	23,
	35);
INSERT INTO V_VAL
	VALUES (688,
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (688,
	'5');
INSERT INTO V_PAR
	VALUES (688,
	622,
	0,
	'row',
	689,
	24,
	18);
INSERT INTO V_VAL
	VALUES (689,
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (689,
	'9');
INSERT INTO V_PAR
	VALUES (689,
	622,
	0,
	'column',
	690,
	24,
	25);
INSERT INTO V_VAL
	VALUES (690,
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (690,
	'2');
INSERT INTO V_PAR
	VALUES (690,
	622,
	0,
	'answer',
	0,
	24,
	35);
INSERT INTO V_VAL
	VALUES (691,
	0,
	0,
	26,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (691,
	'6');
INSERT INTO V_PAR
	VALUES (691,
	623,
	0,
	'row',
	692,
	26,
	18);
INSERT INTO V_VAL
	VALUES (692,
	0,
	0,
	26,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (692,
	'1');
INSERT INTO V_PAR
	VALUES (692,
	623,
	0,
	'column',
	693,
	26,
	25);
INSERT INTO V_VAL
	VALUES (693,
	0,
	0,
	26,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (693,
	'5');
INSERT INTO V_PAR
	VALUES (693,
	623,
	0,
	'answer',
	0,
	26,
	35);
INSERT INTO V_VAL
	VALUES (694,
	0,
	0,
	27,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (694,
	'6');
INSERT INTO V_PAR
	VALUES (694,
	624,
	0,
	'row',
	695,
	27,
	18);
INSERT INTO V_VAL
	VALUES (695,
	0,
	0,
	27,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (695,
	'5');
INSERT INTO V_PAR
	VALUES (695,
	624,
	0,
	'column',
	696,
	27,
	25);
INSERT INTO V_VAL
	VALUES (696,
	0,
	0,
	27,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (696,
	'3');
INSERT INTO V_PAR
	VALUES (696,
	624,
	0,
	'answer',
	0,
	27,
	35);
INSERT INTO V_VAL
	VALUES (697,
	0,
	0,
	28,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (697,
	'6');
INSERT INTO V_PAR
	VALUES (697,
	625,
	0,
	'row',
	698,
	28,
	18);
INSERT INTO V_VAL
	VALUES (698,
	0,
	0,
	28,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (698,
	'9');
INSERT INTO V_PAR
	VALUES (698,
	625,
	0,
	'column',
	699,
	28,
	25);
INSERT INTO V_VAL
	VALUES (699,
	0,
	0,
	28,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (699,
	'9');
INSERT INTO V_PAR
	VALUES (699,
	625,
	0,
	'answer',
	0,
	28,
	35);
INSERT INTO V_VAL
	VALUES (700,
	0,
	0,
	30,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (700,
	'7');
INSERT INTO V_PAR
	VALUES (700,
	626,
	0,
	'row',
	701,
	30,
	18);
INSERT INTO V_VAL
	VALUES (701,
	0,
	0,
	30,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (701,
	'2');
INSERT INTO V_PAR
	VALUES (701,
	626,
	0,
	'column',
	702,
	30,
	25);
INSERT INTO V_VAL
	VALUES (702,
	0,
	0,
	30,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (702,
	'2');
INSERT INTO V_PAR
	VALUES (702,
	626,
	0,
	'answer',
	0,
	30,
	35);
INSERT INTO V_VAL
	VALUES (703,
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (703,
	'7');
INSERT INTO V_PAR
	VALUES (703,
	627,
	0,
	'row',
	704,
	31,
	18);
INSERT INTO V_VAL
	VALUES (704,
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (704,
	'7');
INSERT INTO V_PAR
	VALUES (704,
	627,
	0,
	'column',
	705,
	31,
	25);
INSERT INTO V_VAL
	VALUES (705,
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (705,
	'4');
INSERT INTO V_PAR
	VALUES (705,
	627,
	0,
	'answer',
	0,
	31,
	35);
INSERT INTO V_VAL
	VALUES (706,
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (706,
	'7');
INSERT INTO V_PAR
	VALUES (706,
	628,
	0,
	'row',
	707,
	32,
	18);
INSERT INTO V_VAL
	VALUES (707,
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (707,
	'8');
INSERT INTO V_PAR
	VALUES (707,
	628,
	0,
	'column',
	708,
	32,
	25);
INSERT INTO V_VAL
	VALUES (708,
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (708,
	'1');
INSERT INTO V_PAR
	VALUES (708,
	628,
	0,
	'answer',
	0,
	32,
	35);
INSERT INTO V_VAL
	VALUES (709,
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (709,
	'7');
INSERT INTO V_PAR
	VALUES (709,
	629,
	0,
	'row',
	710,
	33,
	18);
INSERT INTO V_VAL
	VALUES (710,
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (710,
	'9');
INSERT INTO V_PAR
	VALUES (710,
	629,
	0,
	'column',
	711,
	33,
	25);
INSERT INTO V_VAL
	VALUES (711,
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (711,
	'7');
INSERT INTO V_PAR
	VALUES (711,
	629,
	0,
	'answer',
	0,
	33,
	35);
INSERT INTO V_VAL
	VALUES (712,
	0,
	0,
	35,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (712,
	'8');
INSERT INTO V_PAR
	VALUES (712,
	630,
	0,
	'row',
	713,
	35,
	18);
INSERT INTO V_VAL
	VALUES (713,
	0,
	0,
	35,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (713,
	'2');
INSERT INTO V_PAR
	VALUES (713,
	630,
	0,
	'column',
	714,
	35,
	25);
INSERT INTO V_VAL
	VALUES (714,
	0,
	0,
	35,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (714,
	'4');
INSERT INTO V_PAR
	VALUES (714,
	630,
	0,
	'answer',
	0,
	35,
	35);
INSERT INTO V_VAL
	VALUES (715,
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (715,
	'8');
INSERT INTO V_PAR
	VALUES (715,
	631,
	0,
	'row',
	716,
	36,
	18);
INSERT INTO V_VAL
	VALUES (716,
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (716,
	'4');
INSERT INTO V_PAR
	VALUES (716,
	631,
	0,
	'column',
	717,
	36,
	25);
INSERT INTO V_VAL
	VALUES (717,
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (717,
	'1');
INSERT INTO V_PAR
	VALUES (717,
	631,
	0,
	'answer',
	0,
	36,
	35);
INSERT INTO V_VAL
	VALUES (718,
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (718,
	'8');
INSERT INTO V_PAR
	VALUES (718,
	632,
	0,
	'row',
	719,
	37,
	18);
INSERT INTO V_VAL
	VALUES (719,
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (719,
	'5');
INSERT INTO V_PAR
	VALUES (719,
	632,
	0,
	'column',
	720,
	37,
	25);
INSERT INTO V_VAL
	VALUES (720,
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (720,
	'5');
INSERT INTO V_PAR
	VALUES (720,
	632,
	0,
	'answer',
	0,
	37,
	35);
INSERT INTO V_VAL
	VALUES (721,
	0,
	0,
	38,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (721,
	'8');
INSERT INTO V_PAR
	VALUES (721,
	633,
	0,
	'row',
	722,
	38,
	18);
INSERT INTO V_VAL
	VALUES (722,
	0,
	0,
	38,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (722,
	'6');
INSERT INTO V_PAR
	VALUES (722,
	633,
	0,
	'column',
	723,
	38,
	25);
INSERT INTO V_VAL
	VALUES (723,
	0,
	0,
	38,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (723,
	'6');
INSERT INTO V_PAR
	VALUES (723,
	633,
	0,
	'answer',
	0,
	38,
	35);
INSERT INTO V_VAL
	VALUES (724,
	0,
	0,
	40,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (724,
	'9');
INSERT INTO V_PAR
	VALUES (724,
	634,
	0,
	'row',
	725,
	40,
	18);
INSERT INTO V_VAL
	VALUES (725,
	0,
	0,
	40,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (725,
	'1');
INSERT INTO V_PAR
	VALUES (725,
	634,
	0,
	'column',
	726,
	40,
	25);
INSERT INTO V_VAL
	VALUES (726,
	0,
	0,
	40,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (726,
	'3');
INSERT INTO V_PAR
	VALUES (726,
	634,
	0,
	'answer',
	0,
	40,
	35);
INSERT INTO V_VAL
	VALUES (727,
	0,
	0,
	41,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (727,
	'9');
INSERT INTO V_PAR
	VALUES (727,
	635,
	0,
	'row',
	728,
	41,
	18);
INSERT INTO V_VAL
	VALUES (728,
	0,
	0,
	41,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (728,
	'6');
INSERT INTO V_PAR
	VALUES (728,
	635,
	0,
	'column',
	729,
	41,
	25);
INSERT INTO V_VAL
	VALUES (729,
	0,
	0,
	41,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (729,
	'7');
INSERT INTO V_PAR
	VALUES (729,
	635,
	0,
	'answer',
	0,
	41,
	35);
INSERT INTO V_VAL
	VALUES (730,
	0,
	0,
	42,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (730,
	'9');
INSERT INTO V_PAR
	VALUES (730,
	636,
	0,
	'row',
	731,
	42,
	18);
INSERT INTO V_VAL
	VALUES (731,
	0,
	0,
	42,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (731,
	'7');
INSERT INTO V_PAR
	VALUES (731,
	636,
	0,
	'column',
	732,
	42,
	25);
INSERT INTO V_VAL
	VALUES (732,
	0,
	0,
	42,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	603);
INSERT INTO V_LIN
	VALUES (732,
	'5');
INSERT INTO V_PAR
	VALUES (732,
	636,
	0,
	'answer',
	0,
	42,
	35);
INSERT INTO S_FIP
	VALUES (102,
	733);
INSERT INTO S_SYNC
	VALUES (733,
	2,
	'display',
	'',
	'i = 1;
//#inline
//   printf( "\n|---+---+---+---+---+---+---+---+---|\n" );
// 

while ( i <= 9 )
  j = 1;
  //#inline
//   printf( "|" );
//   

  while ( j <= 9 )
    select any cell from instances of CELL
      where ( ( selected.row_number == i ) and ( selected.column_number == j ) );
    a = cell.answer_value;
    //#inline
//     if ( 0 == v59_a )
//       printf( "   |" );
//     else
//       printf( " %d |", v59_a );
//     

    j = j + 1;
  end while;  
  //#inline
//   printf( "\n|---+---+---+---+---+---+---+---+---|\n" );
//   

  i = i + 1;
end while;',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (734,
	733);
INSERT INTO ACT_ACT
	VALUES (734,
	'function',
	0,
	735,
	0,
	0,
	'display',
	0);
INSERT INTO ACT_BLK
	VALUES (735,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	734,
	0);
INSERT INTO ACT_SMT
	VALUES (736,
	735,
	737,
	1,
	1,
	'display line: 1');
INSERT INTO ACT_AI
	VALUES (736,
	738,
	739,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (737,
	735,
	0,
	5,
	1,
	'display line: 5');
INSERT INTO ACT_WHL
	VALUES (737,
	740,
	741);
INSERT INTO V_VAL
	VALUES (739,
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	7,
	735);
INSERT INTO V_TVL
	VALUES (739,
	742);
INSERT INTO V_VAL
	VALUES (738,
	0,
	0,
	1,
	5,
	5,
	0,
	0,
	0,
	0,
	7,
	735);
INSERT INTO V_LIN
	VALUES (738,
	'1');
INSERT INTO V_VAL
	VALUES (743,
	0,
	0,
	5,
	9,
	9,
	0,
	0,
	0,
	0,
	7,
	735);
INSERT INTO V_TVL
	VALUES (743,
	742);
INSERT INTO V_VAL
	VALUES (740,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	735);
INSERT INTO V_BIN
	VALUES (740,
	744,
	743,
	'<=');
INSERT INTO V_VAL
	VALUES (744,
	0,
	0,
	5,
	14,
	14,
	0,
	0,
	0,
	0,
	7,
	735);
INSERT INTO V_LIN
	VALUES (744,
	'9');
INSERT INTO V_VAR
	VALUES (742,
	735,
	'i',
	1,
	7);
INSERT INTO V_TRN
	VALUES (742,
	0,
	'');
INSERT INTO V_LOC
	VALUES (745,
	1,
	1,
	1,
	742);
INSERT INTO V_LOC
	VALUES (746,
	5,
	9,
	9,
	742);
INSERT INTO V_LOC
	VALUES (747,
	12,
	40,
	40,
	742);
INSERT INTO V_LOC
	VALUES (748,
	25,
	3,
	3,
	742);
INSERT INTO V_LOC
	VALUES (749,
	25,
	7,
	7,
	742);
INSERT INTO ACT_BLK
	VALUES (741,
	0,
	0,
	0,
	'',
	'',
	'',
	25,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	734,
	0);
INSERT INTO ACT_SMT
	VALUES (750,
	741,
	751,
	6,
	3,
	'display line: 6');
INSERT INTO ACT_AI
	VALUES (750,
	752,
	753,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (751,
	741,
	754,
	10,
	3,
	'display line: 10');
INSERT INTO ACT_WHL
	VALUES (751,
	755,
	756);
INSERT INTO ACT_SMT
	VALUES (754,
	741,
	0,
	25,
	3,
	'display line: 25');
INSERT INTO ACT_AI
	VALUES (754,
	757,
	758,
	0,
	0);
INSERT INTO V_VAL
	VALUES (753,
	1,
	1,
	6,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	741);
INSERT INTO V_TVL
	VALUES (753,
	759);
INSERT INTO V_VAL
	VALUES (752,
	0,
	0,
	6,
	7,
	7,
	0,
	0,
	0,
	0,
	7,
	741);
INSERT INTO V_LIN
	VALUES (752,
	'1');
INSERT INTO V_VAL
	VALUES (760,
	0,
	0,
	10,
	11,
	11,
	0,
	0,
	0,
	0,
	7,
	741);
INSERT INTO V_TVL
	VALUES (760,
	759);
INSERT INTO V_VAL
	VALUES (755,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	741);
INSERT INTO V_BIN
	VALUES (755,
	761,
	760,
	'<=');
INSERT INTO V_VAL
	VALUES (761,
	0,
	0,
	10,
	16,
	16,
	0,
	0,
	0,
	0,
	7,
	741);
INSERT INTO V_LIN
	VALUES (761,
	'9');
INSERT INTO V_VAL
	VALUES (758,
	1,
	0,
	25,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	741);
INSERT INTO V_TVL
	VALUES (758,
	742);
INSERT INTO V_VAL
	VALUES (762,
	0,
	0,
	25,
	7,
	7,
	0,
	0,
	0,
	0,
	7,
	741);
INSERT INTO V_TVL
	VALUES (762,
	742);
INSERT INTO V_VAL
	VALUES (757,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	741);
INSERT INTO V_BIN
	VALUES (757,
	763,
	762,
	'+');
INSERT INTO V_VAL
	VALUES (763,
	0,
	0,
	25,
	11,
	11,
	0,
	0,
	0,
	0,
	7,
	741);
INSERT INTO V_LIN
	VALUES (763,
	'1');
INSERT INTO V_VAR
	VALUES (759,
	741,
	'j',
	1,
	7);
INSERT INTO V_TRN
	VALUES (759,
	0,
	'');
INSERT INTO V_LOC
	VALUES (764,
	6,
	3,
	3,
	759);
INSERT INTO V_LOC
	VALUES (765,
	10,
	11,
	11,
	759);
INSERT INTO V_LOC
	VALUES (766,
	12,
	76,
	76,
	759);
INSERT INTO V_LOC
	VALUES (767,
	20,
	5,
	5,
	759);
INSERT INTO V_LOC
	VALUES (768,
	20,
	9,
	9,
	759);
INSERT INTO ACT_BLK
	VALUES (756,
	1,
	0,
	1,
	'',
	'',
	'',
	20,
	5,
	11,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	734,
	0);
INSERT INTO ACT_SMT
	VALUES (769,
	756,
	770,
	11,
	5,
	'display line: 11');
INSERT INTO ACT_FIW
	VALUES (769,
	771,
	1,
	'any',
	772,
	168,
	11,
	39);
INSERT INTO ACT_SMT
	VALUES (770,
	756,
	773,
	13,
	5,
	'display line: 13');
INSERT INTO ACT_AI
	VALUES (770,
	774,
	775,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (773,
	756,
	0,
	20,
	5,
	'display line: 20');
INSERT INTO ACT_AI
	VALUES (773,
	776,
	777,
	0,
	0);
INSERT INTO V_VAL
	VALUES (778,
	0,
	0,
	12,
	17,
	-1,
	0,
	0,
	0,
	0,
	13,
	756);
INSERT INTO V_SLR
	VALUES (778,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (779,
	0,
	0,
	12,
	26,
	35,
	0,
	0,
	0,
	0,
	7,
	756);
INSERT INTO V_AVL
	VALUES (779,
	778,
	168,
	415);
INSERT INTO V_VAL
	VALUES (780,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	756);
INSERT INTO V_BIN
	VALUES (780,
	781,
	779,
	'==');
INSERT INTO V_VAL
	VALUES (781,
	0,
	0,
	12,
	40,
	40,
	0,
	0,
	0,
	0,
	7,
	756);
INSERT INTO V_TVL
	VALUES (781,
	742);
INSERT INTO V_VAL
	VALUES (782,
	0,
	0,
	12,
	50,
	-1,
	0,
	0,
	0,
	0,
	13,
	756);
INSERT INTO V_SLR
	VALUES (782,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (783,
	0,
	0,
	12,
	59,
	71,
	0,
	0,
	0,
	0,
	7,
	756);
INSERT INTO V_AVL
	VALUES (783,
	782,
	168,
	420);
INSERT INTO V_VAL
	VALUES (784,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	756);
INSERT INTO V_BIN
	VALUES (784,
	785,
	783,
	'==');
INSERT INTO V_VAL
	VALUES (785,
	0,
	0,
	12,
	76,
	76,
	0,
	0,
	0,
	0,
	7,
	756);
INSERT INTO V_TVL
	VALUES (785,
	759);
INSERT INTO V_VAL
	VALUES (772,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	756);
INSERT INTO V_BIN
	VALUES (772,
	784,
	780,
	'and');
INSERT INTO V_VAL
	VALUES (775,
	1,
	1,
	13,
	5,
	5,
	0,
	0,
	0,
	0,
	7,
	756);
INSERT INTO V_TVL
	VALUES (775,
	786);
INSERT INTO V_VAL
	VALUES (787,
	0,
	0,
	13,
	9,
	12,
	0,
	0,
	0,
	0,
	13,
	756);
INSERT INTO V_IRF
	VALUES (787,
	771);
INSERT INTO V_VAL
	VALUES (774,
	0,
	0,
	13,
	14,
	25,
	0,
	0,
	0,
	0,
	7,
	756);
INSERT INTO V_AVL
	VALUES (774,
	787,
	168,
	788);
INSERT INTO V_VAL
	VALUES (777,
	1,
	0,
	20,
	5,
	5,
	0,
	0,
	0,
	0,
	7,
	756);
INSERT INTO V_TVL
	VALUES (777,
	759);
INSERT INTO V_VAL
	VALUES (789,
	0,
	0,
	20,
	9,
	9,
	0,
	0,
	0,
	0,
	7,
	756);
INSERT INTO V_TVL
	VALUES (789,
	759);
INSERT INTO V_VAL
	VALUES (776,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	756);
INSERT INTO V_BIN
	VALUES (776,
	790,
	789,
	'+');
INSERT INTO V_VAL
	VALUES (790,
	0,
	0,
	20,
	13,
	13,
	0,
	0,
	0,
	0,
	7,
	756);
INSERT INTO V_LIN
	VALUES (790,
	'1');
INSERT INTO V_VAR
	VALUES (771,
	756,
	'cell',
	1,
	13);
INSERT INTO V_INT
	VALUES (771,
	0,
	168);
INSERT INTO V_LOC
	VALUES (791,
	11,
	16,
	19,
	771);
INSERT INTO V_LOC
	VALUES (792,
	13,
	9,
	12,
	771);
INSERT INTO V_VAR
	VALUES (786,
	756,
	'a',
	1,
	7);
INSERT INTO V_TRN
	VALUES (786,
	0,
	'');
INSERT INTO V_LOC
	VALUES (793,
	13,
	5,
	5,
	786);
INSERT INTO S_FIP
	VALUES (102,
	794);
INSERT INTO S_SYNC
	VALUES (794,
	2,
	'solve',
	'',
	'score = CELL::score();
::display();

SEQUENCE::solve();

score = CELL::score();
if ( 81 == score )
  LOG::LogSuccess( message:"solved the puzzle" );
else
  LOG::LogFailure( message:"failed to solved the puzzle" );
end if;
::display();',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (795,
	794);
INSERT INTO ACT_ACT
	VALUES (795,
	'function',
	0,
	796,
	0,
	0,
	'solve',
	0);
INSERT INTO ACT_BLK
	VALUES (796,
	0,
	0,
	0,
	'CELL',
	'',
	'',
	12,
	1,
	6,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	795,
	0);
INSERT INTO ACT_SMT
	VALUES (797,
	796,
	798,
	1,
	1,
	'solve line: 1');
INSERT INTO ACT_AI
	VALUES (797,
	799,
	800,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (798,
	796,
	801,
	2,
	1,
	'solve line: 2');
INSERT INTO ACT_FNC
	VALUES (798,
	733,
	2,
	3);
INSERT INTO ACT_SMT
	VALUES (801,
	796,
	802,
	4,
	1,
	'solve line: 4');
INSERT INTO ACT_TFM
	VALUES (801,
	803,
	0,
	4,
	11,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES (802,
	796,
	804,
	6,
	1,
	'solve line: 6');
INSERT INTO ACT_AI
	VALUES (802,
	805,
	806,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (804,
	796,
	807,
	7,
	1,
	'solve line: 7');
INSERT INTO ACT_IF
	VALUES (804,
	808,
	809,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (810,
	796,
	0,
	9,
	1,
	'solve line: 9');
INSERT INTO ACT_E
	VALUES (810,
	811,
	804);
INSERT INTO ACT_SMT
	VALUES (807,
	796,
	0,
	12,
	1,
	'solve line: 12');
INSERT INTO ACT_FNC
	VALUES (807,
	733,
	12,
	3);
INSERT INTO V_VAL
	VALUES (800,
	1,
	1,
	1,
	1,
	5,
	0,
	0,
	0,
	0,
	7,
	796);
INSERT INTO V_TVL
	VALUES (800,
	812);
INSERT INTO V_VAL
	VALUES (799,
	0,
	0,
	1,
	15,
	-1,
	0,
	0,
	0,
	0,
	7,
	796);
INSERT INTO V_TRV
	VALUES (799,
	813,
	0,
	1,
	1,
	9);
INSERT INTO V_VAL
	VALUES (806,
	1,
	0,
	6,
	1,
	5,
	0,
	0,
	0,
	0,
	7,
	796);
INSERT INTO V_TVL
	VALUES (806,
	812);
INSERT INTO V_VAL
	VALUES (805,
	0,
	0,
	6,
	15,
	-1,
	0,
	0,
	0,
	0,
	7,
	796);
INSERT INTO V_TRV
	VALUES (805,
	813,
	0,
	1,
	6,
	9);
INSERT INTO V_VAL
	VALUES (814,
	0,
	0,
	7,
	6,
	7,
	0,
	0,
	0,
	0,
	7,
	796);
INSERT INTO V_LIN
	VALUES (814,
	'81');
INSERT INTO V_VAL
	VALUES (809,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	796);
INSERT INTO V_BIN
	VALUES (809,
	815,
	814,
	'==');
INSERT INTO V_VAL
	VALUES (815,
	0,
	0,
	7,
	12,
	16,
	0,
	0,
	0,
	0,
	7,
	796);
INSERT INTO V_TVL
	VALUES (815,
	812);
INSERT INTO V_VAR
	VALUES (812,
	796,
	'score',
	1,
	7);
INSERT INTO V_TRN
	VALUES (812,
	0,
	'');
INSERT INTO V_LOC
	VALUES (816,
	1,
	1,
	5,
	812);
INSERT INTO V_LOC
	VALUES (817,
	6,
	1,
	5,
	812);
INSERT INTO V_LOC
	VALUES (818,
	7,
	12,
	16,
	812);
INSERT INTO ACT_BLK
	VALUES (808,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	8,
	3,
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	795,
	0);
INSERT INTO ACT_SMT
	VALUES (819,
	808,
	0,
	8,
	3,
	'solve line: 8');
INSERT INTO ACT_BRG
	VALUES (819,
	73,
	8,
	8,
	8,
	3);
INSERT INTO V_VAL
	VALUES (820,
	0,
	0,
	8,
	28,
	45,
	0,
	0,
	0,
	0,
	9,
	808);
INSERT INTO V_LST
	VALUES (820,
	'solved the puzzle');
INSERT INTO V_PAR
	VALUES (820,
	819,
	0,
	'message',
	0,
	8,
	20);
INSERT INTO ACT_BLK
	VALUES (811,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	10,
	3,
	10,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	795,
	0);
INSERT INTO ACT_SMT
	VALUES (821,
	811,
	0,
	10,
	3,
	'solve line: 10');
INSERT INTO ACT_BRG
	VALUES (821,
	65,
	10,
	8,
	10,
	3);
INSERT INTO V_VAL
	VALUES (822,
	0,
	0,
	10,
	28,
	55,
	0,
	0,
	0,
	0,
	9,
	811);
INSERT INTO V_LST
	VALUES (822,
	'failed to solved the puzzle');
INSERT INTO V_PAR
	VALUES (822,
	821,
	0,
	'message',
	0,
	10,
	20);
INSERT INTO S_FIP
	VALUES (102,
	823);
INSERT INTO S_SYNC
	VALUES (823,
	2,
	'setz2_given',
	'',
	'
CELL::set_given( row:1, column:2, answer:6 );
CELL::set_given( row:1, column:4, answer:1 );
CELL::set_given( row:1, column:6, answer:4 );
CELL::set_given( row:1, column:8, answer:5 );

CELL::set_given( row:2, column:3, answer:8 );
CELL::set_given( row:2, column:4, answer:3 );
CELL::set_given( row:2, column:6, answer:5 );
CELL::set_given( row:2, column:7, answer:6 );

CELL::set_given( row:3, column:1, answer:2 );
CELL::set_given( row:3, column:9, answer:1 );

CELL::set_given( row:4, column:1, answer:8 );
CELL::set_given( row:4, column:4, answer:4 );
CELL::set_given( row:4, column:6, answer:7 );
CELL::set_given( row:4, column:9, answer:6 );

CELL::set_given( row:5, column:3, answer:6 );
CELL::set_given( row:5, column:7, answer:3 );

CELL::set_given( row:6, column:1, answer:7 );
CELL::set_given( row:6, column:4, answer:9 );
CELL::set_given( row:6, column:6, answer:1 );
CELL::set_given( row:6, column:9, answer:4 );

CELL::set_given( row:7, column:1, answer:5 );
CELL::set_given( row:7, column:9, answer:2 );

CELL::set_given( row:8, column:3, answer:7 );
CELL::set_given( row:8, column:4, answer:2 );
CELL::set_given( row:8, column:6, answer:6 );
CELL::set_given( row:8, column:7, answer:9 );

CELL::set_given( row:9, column:2, answer:4 );
CELL::set_given( row:9, column:4, answer:5 );
CELL::set_given( row:9, column:6, answer:8 );
CELL::set_given( row:9, column:8, answer:7 );

// This is extra.  Should not need this.
CELL::set_given( row:8, column:1, answer:3 );
',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (824,
	823);
INSERT INTO ACT_ACT
	VALUES (824,
	'function',
	0,
	825,
	0,
	0,
	'setz2_given',
	0);
INSERT INTO ACT_BLK
	VALUES (825,
	0,
	0,
	0,
	'CELL',
	'',
	'',
	42,
	1,
	42,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	824,
	0);
INSERT INTO ACT_SMT
	VALUES (826,
	825,
	827,
	2,
	1,
	'setz2_given line: 2');
INSERT INTO ACT_TFM
	VALUES (826,
	606,
	0,
	2,
	7,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (827,
	825,
	828,
	3,
	1,
	'setz2_given line: 3');
INSERT INTO ACT_TFM
	VALUES (827,
	606,
	0,
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES (828,
	825,
	829,
	4,
	1,
	'setz2_given line: 4');
INSERT INTO ACT_TFM
	VALUES (828,
	606,
	0,
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES (829,
	825,
	830,
	5,
	1,
	'setz2_given line: 5');
INSERT INTO ACT_TFM
	VALUES (829,
	606,
	0,
	5,
	7,
	5,
	1);
INSERT INTO ACT_SMT
	VALUES (830,
	825,
	831,
	7,
	1,
	'setz2_given line: 7');
INSERT INTO ACT_TFM
	VALUES (830,
	606,
	0,
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES (831,
	825,
	832,
	8,
	1,
	'setz2_given line: 8');
INSERT INTO ACT_TFM
	VALUES (831,
	606,
	0,
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES (832,
	825,
	833,
	9,
	1,
	'setz2_given line: 9');
INSERT INTO ACT_TFM
	VALUES (832,
	606,
	0,
	9,
	7,
	9,
	1);
INSERT INTO ACT_SMT
	VALUES (833,
	825,
	834,
	10,
	1,
	'setz2_given line: 10');
INSERT INTO ACT_TFM
	VALUES (833,
	606,
	0,
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES (834,
	825,
	835,
	12,
	1,
	'setz2_given line: 12');
INSERT INTO ACT_TFM
	VALUES (834,
	606,
	0,
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES (835,
	825,
	836,
	13,
	1,
	'setz2_given line: 13');
INSERT INTO ACT_TFM
	VALUES (835,
	606,
	0,
	13,
	7,
	13,
	1);
INSERT INTO ACT_SMT
	VALUES (836,
	825,
	837,
	15,
	1,
	'setz2_given line: 15');
INSERT INTO ACT_TFM
	VALUES (836,
	606,
	0,
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES (837,
	825,
	838,
	16,
	1,
	'setz2_given line: 16');
INSERT INTO ACT_TFM
	VALUES (837,
	606,
	0,
	16,
	7,
	16,
	1);
INSERT INTO ACT_SMT
	VALUES (838,
	825,
	839,
	17,
	1,
	'setz2_given line: 17');
INSERT INTO ACT_TFM
	VALUES (838,
	606,
	0,
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES (839,
	825,
	840,
	18,
	1,
	'setz2_given line: 18');
INSERT INTO ACT_TFM
	VALUES (839,
	606,
	0,
	18,
	7,
	18,
	1);
INSERT INTO ACT_SMT
	VALUES (840,
	825,
	841,
	20,
	1,
	'setz2_given line: 20');
INSERT INTO ACT_TFM
	VALUES (840,
	606,
	0,
	20,
	7,
	20,
	1);
INSERT INTO ACT_SMT
	VALUES (841,
	825,
	842,
	21,
	1,
	'setz2_given line: 21');
INSERT INTO ACT_TFM
	VALUES (841,
	606,
	0,
	21,
	7,
	21,
	1);
INSERT INTO ACT_SMT
	VALUES (842,
	825,
	843,
	23,
	1,
	'setz2_given line: 23');
INSERT INTO ACT_TFM
	VALUES (842,
	606,
	0,
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES (843,
	825,
	844,
	24,
	1,
	'setz2_given line: 24');
INSERT INTO ACT_TFM
	VALUES (843,
	606,
	0,
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES (844,
	825,
	845,
	25,
	1,
	'setz2_given line: 25');
INSERT INTO ACT_TFM
	VALUES (844,
	606,
	0,
	25,
	7,
	25,
	1);
INSERT INTO ACT_SMT
	VALUES (845,
	825,
	846,
	26,
	1,
	'setz2_given line: 26');
INSERT INTO ACT_TFM
	VALUES (845,
	606,
	0,
	26,
	7,
	26,
	1);
INSERT INTO ACT_SMT
	VALUES (846,
	825,
	847,
	28,
	1,
	'setz2_given line: 28');
INSERT INTO ACT_TFM
	VALUES (846,
	606,
	0,
	28,
	7,
	28,
	1);
INSERT INTO ACT_SMT
	VALUES (847,
	825,
	848,
	29,
	1,
	'setz2_given line: 29');
INSERT INTO ACT_TFM
	VALUES (847,
	606,
	0,
	29,
	7,
	29,
	1);
INSERT INTO ACT_SMT
	VALUES (848,
	825,
	849,
	31,
	1,
	'setz2_given line: 31');
INSERT INTO ACT_TFM
	VALUES (848,
	606,
	0,
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES (849,
	825,
	850,
	32,
	1,
	'setz2_given line: 32');
INSERT INTO ACT_TFM
	VALUES (849,
	606,
	0,
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES (850,
	825,
	851,
	33,
	1,
	'setz2_given line: 33');
INSERT INTO ACT_TFM
	VALUES (850,
	606,
	0,
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES (851,
	825,
	852,
	34,
	1,
	'setz2_given line: 34');
INSERT INTO ACT_TFM
	VALUES (851,
	606,
	0,
	34,
	7,
	34,
	1);
INSERT INTO ACT_SMT
	VALUES (852,
	825,
	853,
	36,
	1,
	'setz2_given line: 36');
INSERT INTO ACT_TFM
	VALUES (852,
	606,
	0,
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES (853,
	825,
	854,
	37,
	1,
	'setz2_given line: 37');
INSERT INTO ACT_TFM
	VALUES (853,
	606,
	0,
	37,
	7,
	37,
	1);
INSERT INTO ACT_SMT
	VALUES (854,
	825,
	855,
	38,
	1,
	'setz2_given line: 38');
INSERT INTO ACT_TFM
	VALUES (854,
	606,
	0,
	38,
	7,
	38,
	1);
INSERT INTO ACT_SMT
	VALUES (855,
	825,
	856,
	39,
	1,
	'setz2_given line: 39');
INSERT INTO ACT_TFM
	VALUES (855,
	606,
	0,
	39,
	7,
	39,
	1);
INSERT INTO ACT_SMT
	VALUES (856,
	825,
	0,
	42,
	1,
	'setz2_given line: 42');
INSERT INTO ACT_TFM
	VALUES (856,
	606,
	0,
	42,
	7,
	42,
	1);
INSERT INTO V_VAL
	VALUES (857,
	0,
	0,
	2,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (857,
	'1');
INSERT INTO V_PAR
	VALUES (857,
	826,
	0,
	'row',
	858,
	2,
	18);
INSERT INTO V_VAL
	VALUES (858,
	0,
	0,
	2,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (858,
	'2');
INSERT INTO V_PAR
	VALUES (858,
	826,
	0,
	'column',
	859,
	2,
	25);
INSERT INTO V_VAL
	VALUES (859,
	0,
	0,
	2,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (859,
	'6');
INSERT INTO V_PAR
	VALUES (859,
	826,
	0,
	'answer',
	0,
	2,
	35);
INSERT INTO V_VAL
	VALUES (860,
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (860,
	'1');
INSERT INTO V_PAR
	VALUES (860,
	827,
	0,
	'row',
	861,
	3,
	18);
INSERT INTO V_VAL
	VALUES (861,
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (861,
	'4');
INSERT INTO V_PAR
	VALUES (861,
	827,
	0,
	'column',
	862,
	3,
	25);
INSERT INTO V_VAL
	VALUES (862,
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (862,
	'1');
INSERT INTO V_PAR
	VALUES (862,
	827,
	0,
	'answer',
	0,
	3,
	35);
INSERT INTO V_VAL
	VALUES (863,
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (863,
	'1');
INSERT INTO V_PAR
	VALUES (863,
	828,
	0,
	'row',
	864,
	4,
	18);
INSERT INTO V_VAL
	VALUES (864,
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (864,
	'6');
INSERT INTO V_PAR
	VALUES (864,
	828,
	0,
	'column',
	865,
	4,
	25);
INSERT INTO V_VAL
	VALUES (865,
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (865,
	'4');
INSERT INTO V_PAR
	VALUES (865,
	828,
	0,
	'answer',
	0,
	4,
	35);
INSERT INTO V_VAL
	VALUES (866,
	0,
	0,
	5,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (866,
	'1');
INSERT INTO V_PAR
	VALUES (866,
	829,
	0,
	'row',
	867,
	5,
	18);
INSERT INTO V_VAL
	VALUES (867,
	0,
	0,
	5,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (867,
	'8');
INSERT INTO V_PAR
	VALUES (867,
	829,
	0,
	'column',
	868,
	5,
	25);
INSERT INTO V_VAL
	VALUES (868,
	0,
	0,
	5,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (868,
	'5');
INSERT INTO V_PAR
	VALUES (868,
	829,
	0,
	'answer',
	0,
	5,
	35);
INSERT INTO V_VAL
	VALUES (869,
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (869,
	'2');
INSERT INTO V_PAR
	VALUES (869,
	830,
	0,
	'row',
	870,
	7,
	18);
INSERT INTO V_VAL
	VALUES (870,
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (870,
	'3');
INSERT INTO V_PAR
	VALUES (870,
	830,
	0,
	'column',
	871,
	7,
	25);
INSERT INTO V_VAL
	VALUES (871,
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (871,
	'8');
INSERT INTO V_PAR
	VALUES (871,
	830,
	0,
	'answer',
	0,
	7,
	35);
INSERT INTO V_VAL
	VALUES (872,
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (872,
	'2');
INSERT INTO V_PAR
	VALUES (872,
	831,
	0,
	'row',
	873,
	8,
	18);
INSERT INTO V_VAL
	VALUES (873,
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (873,
	'4');
INSERT INTO V_PAR
	VALUES (873,
	831,
	0,
	'column',
	874,
	8,
	25);
INSERT INTO V_VAL
	VALUES (874,
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (874,
	'3');
INSERT INTO V_PAR
	VALUES (874,
	831,
	0,
	'answer',
	0,
	8,
	35);
INSERT INTO V_VAL
	VALUES (875,
	0,
	0,
	9,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (875,
	'2');
INSERT INTO V_PAR
	VALUES (875,
	832,
	0,
	'row',
	876,
	9,
	18);
INSERT INTO V_VAL
	VALUES (876,
	0,
	0,
	9,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (876,
	'6');
INSERT INTO V_PAR
	VALUES (876,
	832,
	0,
	'column',
	877,
	9,
	25);
INSERT INTO V_VAL
	VALUES (877,
	0,
	0,
	9,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (877,
	'5');
INSERT INTO V_PAR
	VALUES (877,
	832,
	0,
	'answer',
	0,
	9,
	35);
INSERT INTO V_VAL
	VALUES (878,
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (878,
	'2');
INSERT INTO V_PAR
	VALUES (878,
	833,
	0,
	'row',
	879,
	10,
	18);
INSERT INTO V_VAL
	VALUES (879,
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (879,
	'7');
INSERT INTO V_PAR
	VALUES (879,
	833,
	0,
	'column',
	880,
	10,
	25);
INSERT INTO V_VAL
	VALUES (880,
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (880,
	'6');
INSERT INTO V_PAR
	VALUES (880,
	833,
	0,
	'answer',
	0,
	10,
	35);
INSERT INTO V_VAL
	VALUES (881,
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (881,
	'3');
INSERT INTO V_PAR
	VALUES (881,
	834,
	0,
	'row',
	882,
	12,
	18);
INSERT INTO V_VAL
	VALUES (882,
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (882,
	'1');
INSERT INTO V_PAR
	VALUES (882,
	834,
	0,
	'column',
	883,
	12,
	25);
INSERT INTO V_VAL
	VALUES (883,
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (883,
	'2');
INSERT INTO V_PAR
	VALUES (883,
	834,
	0,
	'answer',
	0,
	12,
	35);
INSERT INTO V_VAL
	VALUES (884,
	0,
	0,
	13,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (884,
	'3');
INSERT INTO V_PAR
	VALUES (884,
	835,
	0,
	'row',
	885,
	13,
	18);
INSERT INTO V_VAL
	VALUES (885,
	0,
	0,
	13,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (885,
	'9');
INSERT INTO V_PAR
	VALUES (885,
	835,
	0,
	'column',
	886,
	13,
	25);
INSERT INTO V_VAL
	VALUES (886,
	0,
	0,
	13,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (886,
	'1');
INSERT INTO V_PAR
	VALUES (886,
	835,
	0,
	'answer',
	0,
	13,
	35);
INSERT INTO V_VAL
	VALUES (887,
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (887,
	'4');
INSERT INTO V_PAR
	VALUES (887,
	836,
	0,
	'row',
	888,
	15,
	18);
INSERT INTO V_VAL
	VALUES (888,
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (888,
	'1');
INSERT INTO V_PAR
	VALUES (888,
	836,
	0,
	'column',
	889,
	15,
	25);
INSERT INTO V_VAL
	VALUES (889,
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (889,
	'8');
INSERT INTO V_PAR
	VALUES (889,
	836,
	0,
	'answer',
	0,
	15,
	35);
INSERT INTO V_VAL
	VALUES (890,
	0,
	0,
	16,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (890,
	'4');
INSERT INTO V_PAR
	VALUES (890,
	837,
	0,
	'row',
	891,
	16,
	18);
INSERT INTO V_VAL
	VALUES (891,
	0,
	0,
	16,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (891,
	'4');
INSERT INTO V_PAR
	VALUES (891,
	837,
	0,
	'column',
	892,
	16,
	25);
INSERT INTO V_VAL
	VALUES (892,
	0,
	0,
	16,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (892,
	'4');
INSERT INTO V_PAR
	VALUES (892,
	837,
	0,
	'answer',
	0,
	16,
	35);
INSERT INTO V_VAL
	VALUES (893,
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (893,
	'4');
INSERT INTO V_PAR
	VALUES (893,
	838,
	0,
	'row',
	894,
	17,
	18);
INSERT INTO V_VAL
	VALUES (894,
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (894,
	'6');
INSERT INTO V_PAR
	VALUES (894,
	838,
	0,
	'column',
	895,
	17,
	25);
INSERT INTO V_VAL
	VALUES (895,
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (895,
	'7');
INSERT INTO V_PAR
	VALUES (895,
	838,
	0,
	'answer',
	0,
	17,
	35);
INSERT INTO V_VAL
	VALUES (896,
	0,
	0,
	18,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (896,
	'4');
INSERT INTO V_PAR
	VALUES (896,
	839,
	0,
	'row',
	897,
	18,
	18);
INSERT INTO V_VAL
	VALUES (897,
	0,
	0,
	18,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (897,
	'9');
INSERT INTO V_PAR
	VALUES (897,
	839,
	0,
	'column',
	898,
	18,
	25);
INSERT INTO V_VAL
	VALUES (898,
	0,
	0,
	18,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (898,
	'6');
INSERT INTO V_PAR
	VALUES (898,
	839,
	0,
	'answer',
	0,
	18,
	35);
INSERT INTO V_VAL
	VALUES (899,
	0,
	0,
	20,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (899,
	'5');
INSERT INTO V_PAR
	VALUES (899,
	840,
	0,
	'row',
	900,
	20,
	18);
INSERT INTO V_VAL
	VALUES (900,
	0,
	0,
	20,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (900,
	'3');
INSERT INTO V_PAR
	VALUES (900,
	840,
	0,
	'column',
	901,
	20,
	25);
INSERT INTO V_VAL
	VALUES (901,
	0,
	0,
	20,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (901,
	'6');
INSERT INTO V_PAR
	VALUES (901,
	840,
	0,
	'answer',
	0,
	20,
	35);
INSERT INTO V_VAL
	VALUES (902,
	0,
	0,
	21,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (902,
	'5');
INSERT INTO V_PAR
	VALUES (902,
	841,
	0,
	'row',
	903,
	21,
	18);
INSERT INTO V_VAL
	VALUES (903,
	0,
	0,
	21,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (903,
	'7');
INSERT INTO V_PAR
	VALUES (903,
	841,
	0,
	'column',
	904,
	21,
	25);
INSERT INTO V_VAL
	VALUES (904,
	0,
	0,
	21,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (904,
	'3');
INSERT INTO V_PAR
	VALUES (904,
	841,
	0,
	'answer',
	0,
	21,
	35);
INSERT INTO V_VAL
	VALUES (905,
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (905,
	'6');
INSERT INTO V_PAR
	VALUES (905,
	842,
	0,
	'row',
	906,
	23,
	18);
INSERT INTO V_VAL
	VALUES (906,
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (906,
	'1');
INSERT INTO V_PAR
	VALUES (906,
	842,
	0,
	'column',
	907,
	23,
	25);
INSERT INTO V_VAL
	VALUES (907,
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (907,
	'7');
INSERT INTO V_PAR
	VALUES (907,
	842,
	0,
	'answer',
	0,
	23,
	35);
INSERT INTO V_VAL
	VALUES (908,
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (908,
	'6');
INSERT INTO V_PAR
	VALUES (908,
	843,
	0,
	'row',
	909,
	24,
	18);
INSERT INTO V_VAL
	VALUES (909,
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (909,
	'4');
INSERT INTO V_PAR
	VALUES (909,
	843,
	0,
	'column',
	910,
	24,
	25);
INSERT INTO V_VAL
	VALUES (910,
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (910,
	'9');
INSERT INTO V_PAR
	VALUES (910,
	843,
	0,
	'answer',
	0,
	24,
	35);
INSERT INTO V_VAL
	VALUES (911,
	0,
	0,
	25,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (911,
	'6');
INSERT INTO V_PAR
	VALUES (911,
	844,
	0,
	'row',
	912,
	25,
	18);
INSERT INTO V_VAL
	VALUES (912,
	0,
	0,
	25,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (912,
	'6');
INSERT INTO V_PAR
	VALUES (912,
	844,
	0,
	'column',
	913,
	25,
	25);
INSERT INTO V_VAL
	VALUES (913,
	0,
	0,
	25,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (913,
	'1');
INSERT INTO V_PAR
	VALUES (913,
	844,
	0,
	'answer',
	0,
	25,
	35);
INSERT INTO V_VAL
	VALUES (914,
	0,
	0,
	26,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (914,
	'6');
INSERT INTO V_PAR
	VALUES (914,
	845,
	0,
	'row',
	915,
	26,
	18);
INSERT INTO V_VAL
	VALUES (915,
	0,
	0,
	26,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (915,
	'9');
INSERT INTO V_PAR
	VALUES (915,
	845,
	0,
	'column',
	916,
	26,
	25);
INSERT INTO V_VAL
	VALUES (916,
	0,
	0,
	26,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (916,
	'4');
INSERT INTO V_PAR
	VALUES (916,
	845,
	0,
	'answer',
	0,
	26,
	35);
INSERT INTO V_VAL
	VALUES (917,
	0,
	0,
	28,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (917,
	'7');
INSERT INTO V_PAR
	VALUES (917,
	846,
	0,
	'row',
	918,
	28,
	18);
INSERT INTO V_VAL
	VALUES (918,
	0,
	0,
	28,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (918,
	'1');
INSERT INTO V_PAR
	VALUES (918,
	846,
	0,
	'column',
	919,
	28,
	25);
INSERT INTO V_VAL
	VALUES (919,
	0,
	0,
	28,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (919,
	'5');
INSERT INTO V_PAR
	VALUES (919,
	846,
	0,
	'answer',
	0,
	28,
	35);
INSERT INTO V_VAL
	VALUES (920,
	0,
	0,
	29,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (920,
	'7');
INSERT INTO V_PAR
	VALUES (920,
	847,
	0,
	'row',
	921,
	29,
	18);
INSERT INTO V_VAL
	VALUES (921,
	0,
	0,
	29,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (921,
	'9');
INSERT INTO V_PAR
	VALUES (921,
	847,
	0,
	'column',
	922,
	29,
	25);
INSERT INTO V_VAL
	VALUES (922,
	0,
	0,
	29,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (922,
	'2');
INSERT INTO V_PAR
	VALUES (922,
	847,
	0,
	'answer',
	0,
	29,
	35);
INSERT INTO V_VAL
	VALUES (923,
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (923,
	'8');
INSERT INTO V_PAR
	VALUES (923,
	848,
	0,
	'row',
	924,
	31,
	18);
INSERT INTO V_VAL
	VALUES (924,
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (924,
	'3');
INSERT INTO V_PAR
	VALUES (924,
	848,
	0,
	'column',
	925,
	31,
	25);
INSERT INTO V_VAL
	VALUES (925,
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (925,
	'7');
INSERT INTO V_PAR
	VALUES (925,
	848,
	0,
	'answer',
	0,
	31,
	35);
INSERT INTO V_VAL
	VALUES (926,
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (926,
	'8');
INSERT INTO V_PAR
	VALUES (926,
	849,
	0,
	'row',
	927,
	32,
	18);
INSERT INTO V_VAL
	VALUES (927,
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (927,
	'4');
INSERT INTO V_PAR
	VALUES (927,
	849,
	0,
	'column',
	928,
	32,
	25);
INSERT INTO V_VAL
	VALUES (928,
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (928,
	'2');
INSERT INTO V_PAR
	VALUES (928,
	849,
	0,
	'answer',
	0,
	32,
	35);
INSERT INTO V_VAL
	VALUES (929,
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (929,
	'8');
INSERT INTO V_PAR
	VALUES (929,
	850,
	0,
	'row',
	930,
	33,
	18);
INSERT INTO V_VAL
	VALUES (930,
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (930,
	'6');
INSERT INTO V_PAR
	VALUES (930,
	850,
	0,
	'column',
	931,
	33,
	25);
INSERT INTO V_VAL
	VALUES (931,
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (931,
	'6');
INSERT INTO V_PAR
	VALUES (931,
	850,
	0,
	'answer',
	0,
	33,
	35);
INSERT INTO V_VAL
	VALUES (932,
	0,
	0,
	34,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (932,
	'8');
INSERT INTO V_PAR
	VALUES (932,
	851,
	0,
	'row',
	933,
	34,
	18);
INSERT INTO V_VAL
	VALUES (933,
	0,
	0,
	34,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (933,
	'7');
INSERT INTO V_PAR
	VALUES (933,
	851,
	0,
	'column',
	934,
	34,
	25);
INSERT INTO V_VAL
	VALUES (934,
	0,
	0,
	34,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (934,
	'9');
INSERT INTO V_PAR
	VALUES (934,
	851,
	0,
	'answer',
	0,
	34,
	35);
INSERT INTO V_VAL
	VALUES (935,
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (935,
	'9');
INSERT INTO V_PAR
	VALUES (935,
	852,
	0,
	'row',
	936,
	36,
	18);
INSERT INTO V_VAL
	VALUES (936,
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (936,
	'2');
INSERT INTO V_PAR
	VALUES (936,
	852,
	0,
	'column',
	937,
	36,
	25);
INSERT INTO V_VAL
	VALUES (937,
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (937,
	'4');
INSERT INTO V_PAR
	VALUES (937,
	852,
	0,
	'answer',
	0,
	36,
	35);
INSERT INTO V_VAL
	VALUES (938,
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (938,
	'9');
INSERT INTO V_PAR
	VALUES (938,
	853,
	0,
	'row',
	939,
	37,
	18);
INSERT INTO V_VAL
	VALUES (939,
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (939,
	'4');
INSERT INTO V_PAR
	VALUES (939,
	853,
	0,
	'column',
	940,
	37,
	25);
INSERT INTO V_VAL
	VALUES (940,
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (940,
	'5');
INSERT INTO V_PAR
	VALUES (940,
	853,
	0,
	'answer',
	0,
	37,
	35);
INSERT INTO V_VAL
	VALUES (941,
	0,
	0,
	38,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (941,
	'9');
INSERT INTO V_PAR
	VALUES (941,
	854,
	0,
	'row',
	942,
	38,
	18);
INSERT INTO V_VAL
	VALUES (942,
	0,
	0,
	38,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (942,
	'6');
INSERT INTO V_PAR
	VALUES (942,
	854,
	0,
	'column',
	943,
	38,
	25);
INSERT INTO V_VAL
	VALUES (943,
	0,
	0,
	38,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (943,
	'8');
INSERT INTO V_PAR
	VALUES (943,
	854,
	0,
	'answer',
	0,
	38,
	35);
INSERT INTO V_VAL
	VALUES (944,
	0,
	0,
	39,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (944,
	'9');
INSERT INTO V_PAR
	VALUES (944,
	855,
	0,
	'row',
	945,
	39,
	18);
INSERT INTO V_VAL
	VALUES (945,
	0,
	0,
	39,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (945,
	'8');
INSERT INTO V_PAR
	VALUES (945,
	855,
	0,
	'column',
	946,
	39,
	25);
INSERT INTO V_VAL
	VALUES (946,
	0,
	0,
	39,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (946,
	'7');
INSERT INTO V_PAR
	VALUES (946,
	855,
	0,
	'answer',
	0,
	39,
	35);
INSERT INTO V_VAL
	VALUES (947,
	0,
	0,
	42,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (947,
	'8');
INSERT INTO V_PAR
	VALUES (947,
	856,
	0,
	'row',
	948,
	42,
	18);
INSERT INTO V_VAL
	VALUES (948,
	0,
	0,
	42,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (948,
	'1');
INSERT INTO V_PAR
	VALUES (948,
	856,
	0,
	'column',
	949,
	42,
	25);
INSERT INTO V_VAL
	VALUES (949,
	0,
	0,
	42,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	825);
INSERT INTO V_LIN
	VALUES (949,
	'3');
INSERT INTO V_PAR
	VALUES (949,
	856,
	0,
	'answer',
	0,
	42,
	35);
INSERT INTO S_FIP
	VALUES (102,
	950);
INSERT INTO S_SYNC
	VALUES (950,
	2,
	'setz3_given',
	'',
	'
CELL::set_given( row:1, column:2, answer:9 );
CELL::set_given( row:1, column:5, answer:6 );
CELL::set_given( row:1, column:6, answer:5 );

CELL::set_given( row:2, column:4, answer:3 );
CELL::set_given( row:2, column:7, answer:4 );
CELL::set_given( row:2, column:8, answer:9 );

CELL::set_given( row:3, column:2, answer:8 );
CELL::set_given( row:3, column:3, answer:3 );
CELL::set_given( row:3, column:7, answer:2 );

CELL::set_given( row:4, column:1, answer:3 );
CELL::set_given( row:4, column:4, answer:8 );
CELL::set_given( row:4, column:6, answer:4 );
CELL::set_given( row:4, column:9, answer:6 );

CELL::set_given( row:5, column:1, answer:1 );
CELL::set_given( row:5, column:9, answer:7 );

CELL::set_given( row:6, column:1, answer:5 );
CELL::set_given( row:6, column:4, answer:2 );
CELL::set_given( row:6, column:6, answer:3 );
CELL::set_given( row:6, column:9, answer:9 );

CELL::set_given( row:7, column:3, answer:4 );
CELL::set_given( row:7, column:7, answer:6 );
CELL::set_given( row:7, column:8, answer:1 );

CELL::set_given( row:8, column:2, answer:2 );
CELL::set_given( row:8, column:3, answer:7 );
CELL::set_given( row:8, column:6, answer:6 );

CELL::set_given( row:9, column:4, answer:9 );
CELL::set_given( row:9, column:5, answer:3 );
CELL::set_given( row:9, column:8, answer:8 );',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (951,
	950);
INSERT INTO ACT_ACT
	VALUES (951,
	'function',
	0,
	952,
	0,
	0,
	'setz3_given',
	0);
INSERT INTO ACT_BLK
	VALUES (952,
	0,
	0,
	0,
	'CELL',
	'',
	'',
	37,
	1,
	37,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	951,
	0);
INSERT INTO ACT_SMT
	VALUES (953,
	952,
	954,
	2,
	1,
	'setz3_given line: 2');
INSERT INTO ACT_TFM
	VALUES (953,
	606,
	0,
	2,
	7,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (954,
	952,
	955,
	3,
	1,
	'setz3_given line: 3');
INSERT INTO ACT_TFM
	VALUES (954,
	606,
	0,
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES (955,
	952,
	956,
	4,
	1,
	'setz3_given line: 4');
INSERT INTO ACT_TFM
	VALUES (955,
	606,
	0,
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES (956,
	952,
	957,
	6,
	1,
	'setz3_given line: 6');
INSERT INTO ACT_TFM
	VALUES (956,
	606,
	0,
	6,
	7,
	6,
	1);
INSERT INTO ACT_SMT
	VALUES (957,
	952,
	958,
	7,
	1,
	'setz3_given line: 7');
INSERT INTO ACT_TFM
	VALUES (957,
	606,
	0,
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES (958,
	952,
	959,
	8,
	1,
	'setz3_given line: 8');
INSERT INTO ACT_TFM
	VALUES (958,
	606,
	0,
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES (959,
	952,
	960,
	10,
	1,
	'setz3_given line: 10');
INSERT INTO ACT_TFM
	VALUES (959,
	606,
	0,
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES (960,
	952,
	961,
	11,
	1,
	'setz3_given line: 11');
INSERT INTO ACT_TFM
	VALUES (960,
	606,
	0,
	11,
	7,
	11,
	1);
INSERT INTO ACT_SMT
	VALUES (961,
	952,
	962,
	12,
	1,
	'setz3_given line: 12');
INSERT INTO ACT_TFM
	VALUES (961,
	606,
	0,
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES (962,
	952,
	963,
	14,
	1,
	'setz3_given line: 14');
INSERT INTO ACT_TFM
	VALUES (962,
	606,
	0,
	14,
	7,
	14,
	1);
INSERT INTO ACT_SMT
	VALUES (963,
	952,
	964,
	15,
	1,
	'setz3_given line: 15');
INSERT INTO ACT_TFM
	VALUES (963,
	606,
	0,
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES (964,
	952,
	965,
	16,
	1,
	'setz3_given line: 16');
INSERT INTO ACT_TFM
	VALUES (964,
	606,
	0,
	16,
	7,
	16,
	1);
INSERT INTO ACT_SMT
	VALUES (965,
	952,
	966,
	17,
	1,
	'setz3_given line: 17');
INSERT INTO ACT_TFM
	VALUES (965,
	606,
	0,
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES (966,
	952,
	967,
	19,
	1,
	'setz3_given line: 19');
INSERT INTO ACT_TFM
	VALUES (966,
	606,
	0,
	19,
	7,
	19,
	1);
INSERT INTO ACT_SMT
	VALUES (967,
	952,
	968,
	20,
	1,
	'setz3_given line: 20');
INSERT INTO ACT_TFM
	VALUES (967,
	606,
	0,
	20,
	7,
	20,
	1);
INSERT INTO ACT_SMT
	VALUES (968,
	952,
	969,
	22,
	1,
	'setz3_given line: 22');
INSERT INTO ACT_TFM
	VALUES (968,
	606,
	0,
	22,
	7,
	22,
	1);
INSERT INTO ACT_SMT
	VALUES (969,
	952,
	970,
	23,
	1,
	'setz3_given line: 23');
INSERT INTO ACT_TFM
	VALUES (969,
	606,
	0,
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES (970,
	952,
	971,
	24,
	1,
	'setz3_given line: 24');
INSERT INTO ACT_TFM
	VALUES (970,
	606,
	0,
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES (971,
	952,
	972,
	25,
	1,
	'setz3_given line: 25');
INSERT INTO ACT_TFM
	VALUES (971,
	606,
	0,
	25,
	7,
	25,
	1);
INSERT INTO ACT_SMT
	VALUES (972,
	952,
	973,
	27,
	1,
	'setz3_given line: 27');
INSERT INTO ACT_TFM
	VALUES (972,
	606,
	0,
	27,
	7,
	27,
	1);
INSERT INTO ACT_SMT
	VALUES (973,
	952,
	974,
	28,
	1,
	'setz3_given line: 28');
INSERT INTO ACT_TFM
	VALUES (973,
	606,
	0,
	28,
	7,
	28,
	1);
INSERT INTO ACT_SMT
	VALUES (974,
	952,
	975,
	29,
	1,
	'setz3_given line: 29');
INSERT INTO ACT_TFM
	VALUES (974,
	606,
	0,
	29,
	7,
	29,
	1);
INSERT INTO ACT_SMT
	VALUES (975,
	952,
	976,
	31,
	1,
	'setz3_given line: 31');
INSERT INTO ACT_TFM
	VALUES (975,
	606,
	0,
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES (976,
	952,
	977,
	32,
	1,
	'setz3_given line: 32');
INSERT INTO ACT_TFM
	VALUES (976,
	606,
	0,
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES (977,
	952,
	978,
	33,
	1,
	'setz3_given line: 33');
INSERT INTO ACT_TFM
	VALUES (977,
	606,
	0,
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES (978,
	952,
	979,
	35,
	1,
	'setz3_given line: 35');
INSERT INTO ACT_TFM
	VALUES (978,
	606,
	0,
	35,
	7,
	35,
	1);
INSERT INTO ACT_SMT
	VALUES (979,
	952,
	980,
	36,
	1,
	'setz3_given line: 36');
INSERT INTO ACT_TFM
	VALUES (979,
	606,
	0,
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES (980,
	952,
	0,
	37,
	1,
	'setz3_given line: 37');
INSERT INTO ACT_TFM
	VALUES (980,
	606,
	0,
	37,
	7,
	37,
	1);
INSERT INTO V_VAL
	VALUES (981,
	0,
	0,
	2,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (981,
	'1');
INSERT INTO V_PAR
	VALUES (981,
	953,
	0,
	'row',
	982,
	2,
	18);
INSERT INTO V_VAL
	VALUES (982,
	0,
	0,
	2,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (982,
	'2');
INSERT INTO V_PAR
	VALUES (982,
	953,
	0,
	'column',
	983,
	2,
	25);
INSERT INTO V_VAL
	VALUES (983,
	0,
	0,
	2,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (983,
	'9');
INSERT INTO V_PAR
	VALUES (983,
	953,
	0,
	'answer',
	0,
	2,
	35);
INSERT INTO V_VAL
	VALUES (984,
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (984,
	'1');
INSERT INTO V_PAR
	VALUES (984,
	954,
	0,
	'row',
	985,
	3,
	18);
INSERT INTO V_VAL
	VALUES (985,
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (985,
	'5');
INSERT INTO V_PAR
	VALUES (985,
	954,
	0,
	'column',
	986,
	3,
	25);
INSERT INTO V_VAL
	VALUES (986,
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (986,
	'6');
INSERT INTO V_PAR
	VALUES (986,
	954,
	0,
	'answer',
	0,
	3,
	35);
INSERT INTO V_VAL
	VALUES (987,
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (987,
	'1');
INSERT INTO V_PAR
	VALUES (987,
	955,
	0,
	'row',
	988,
	4,
	18);
INSERT INTO V_VAL
	VALUES (988,
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (988,
	'6');
INSERT INTO V_PAR
	VALUES (988,
	955,
	0,
	'column',
	989,
	4,
	25);
INSERT INTO V_VAL
	VALUES (989,
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (989,
	'5');
INSERT INTO V_PAR
	VALUES (989,
	955,
	0,
	'answer',
	0,
	4,
	35);
INSERT INTO V_VAL
	VALUES (990,
	0,
	0,
	6,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (990,
	'2');
INSERT INTO V_PAR
	VALUES (990,
	956,
	0,
	'row',
	991,
	6,
	18);
INSERT INTO V_VAL
	VALUES (991,
	0,
	0,
	6,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (991,
	'4');
INSERT INTO V_PAR
	VALUES (991,
	956,
	0,
	'column',
	992,
	6,
	25);
INSERT INTO V_VAL
	VALUES (992,
	0,
	0,
	6,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (992,
	'3');
INSERT INTO V_PAR
	VALUES (992,
	956,
	0,
	'answer',
	0,
	6,
	35);
INSERT INTO V_VAL
	VALUES (993,
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (993,
	'2');
INSERT INTO V_PAR
	VALUES (993,
	957,
	0,
	'row',
	994,
	7,
	18);
INSERT INTO V_VAL
	VALUES (994,
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (994,
	'7');
INSERT INTO V_PAR
	VALUES (994,
	957,
	0,
	'column',
	995,
	7,
	25);
INSERT INTO V_VAL
	VALUES (995,
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (995,
	'4');
INSERT INTO V_PAR
	VALUES (995,
	957,
	0,
	'answer',
	0,
	7,
	35);
INSERT INTO V_VAL
	VALUES (996,
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (996,
	'2');
INSERT INTO V_PAR
	VALUES (996,
	958,
	0,
	'row',
	997,
	8,
	18);
INSERT INTO V_VAL
	VALUES (997,
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (997,
	'8');
INSERT INTO V_PAR
	VALUES (997,
	958,
	0,
	'column',
	998,
	8,
	25);
INSERT INTO V_VAL
	VALUES (998,
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (998,
	'9');
INSERT INTO V_PAR
	VALUES (998,
	958,
	0,
	'answer',
	0,
	8,
	35);
INSERT INTO V_VAL
	VALUES (999,
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (999,
	'3');
INSERT INTO V_PAR
	VALUES (999,
	959,
	0,
	'row',
	1000,
	10,
	18);
INSERT INTO V_VAL
	VALUES (1000,
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1000,
	'2');
INSERT INTO V_PAR
	VALUES (1000,
	959,
	0,
	'column',
	1001,
	10,
	25);
INSERT INTO V_VAL
	VALUES (1001,
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1001,
	'8');
INSERT INTO V_PAR
	VALUES (1001,
	959,
	0,
	'answer',
	0,
	10,
	35);
INSERT INTO V_VAL
	VALUES (1002,
	0,
	0,
	11,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1002,
	'3');
INSERT INTO V_PAR
	VALUES (1002,
	960,
	0,
	'row',
	1003,
	11,
	18);
INSERT INTO V_VAL
	VALUES (1003,
	0,
	0,
	11,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1003,
	'3');
INSERT INTO V_PAR
	VALUES (1003,
	960,
	0,
	'column',
	1004,
	11,
	25);
INSERT INTO V_VAL
	VALUES (1004,
	0,
	0,
	11,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1004,
	'3');
INSERT INTO V_PAR
	VALUES (1004,
	960,
	0,
	'answer',
	0,
	11,
	35);
INSERT INTO V_VAL
	VALUES (1005,
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1005,
	'3');
INSERT INTO V_PAR
	VALUES (1005,
	961,
	0,
	'row',
	1006,
	12,
	18);
INSERT INTO V_VAL
	VALUES (1006,
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1006,
	'7');
INSERT INTO V_PAR
	VALUES (1006,
	961,
	0,
	'column',
	1007,
	12,
	25);
INSERT INTO V_VAL
	VALUES (1007,
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1007,
	'2');
INSERT INTO V_PAR
	VALUES (1007,
	961,
	0,
	'answer',
	0,
	12,
	35);
INSERT INTO V_VAL
	VALUES (1008,
	0,
	0,
	14,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1008,
	'4');
INSERT INTO V_PAR
	VALUES (1008,
	962,
	0,
	'row',
	1009,
	14,
	18);
INSERT INTO V_VAL
	VALUES (1009,
	0,
	0,
	14,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1009,
	'1');
INSERT INTO V_PAR
	VALUES (1009,
	962,
	0,
	'column',
	1010,
	14,
	25);
INSERT INTO V_VAL
	VALUES (1010,
	0,
	0,
	14,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1010,
	'3');
INSERT INTO V_PAR
	VALUES (1010,
	962,
	0,
	'answer',
	0,
	14,
	35);
INSERT INTO V_VAL
	VALUES (1011,
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1011,
	'4');
INSERT INTO V_PAR
	VALUES (1011,
	963,
	0,
	'row',
	1012,
	15,
	18);
INSERT INTO V_VAL
	VALUES (1012,
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1012,
	'4');
INSERT INTO V_PAR
	VALUES (1012,
	963,
	0,
	'column',
	1013,
	15,
	25);
INSERT INTO V_VAL
	VALUES (1013,
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1013,
	'8');
INSERT INTO V_PAR
	VALUES (1013,
	963,
	0,
	'answer',
	0,
	15,
	35);
INSERT INTO V_VAL
	VALUES (1014,
	0,
	0,
	16,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1014,
	'4');
INSERT INTO V_PAR
	VALUES (1014,
	964,
	0,
	'row',
	1015,
	16,
	18);
INSERT INTO V_VAL
	VALUES (1015,
	0,
	0,
	16,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1015,
	'6');
INSERT INTO V_PAR
	VALUES (1015,
	964,
	0,
	'column',
	1016,
	16,
	25);
INSERT INTO V_VAL
	VALUES (1016,
	0,
	0,
	16,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1016,
	'4');
INSERT INTO V_PAR
	VALUES (1016,
	964,
	0,
	'answer',
	0,
	16,
	35);
INSERT INTO V_VAL
	VALUES (1017,
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1017,
	'4');
INSERT INTO V_PAR
	VALUES (1017,
	965,
	0,
	'row',
	1018,
	17,
	18);
INSERT INTO V_VAL
	VALUES (1018,
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1018,
	'9');
INSERT INTO V_PAR
	VALUES (1018,
	965,
	0,
	'column',
	1019,
	17,
	25);
INSERT INTO V_VAL
	VALUES (1019,
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1019,
	'6');
INSERT INTO V_PAR
	VALUES (1019,
	965,
	0,
	'answer',
	0,
	17,
	35);
INSERT INTO V_VAL
	VALUES (1020,
	0,
	0,
	19,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1020,
	'5');
INSERT INTO V_PAR
	VALUES (1020,
	966,
	0,
	'row',
	1021,
	19,
	18);
INSERT INTO V_VAL
	VALUES (1021,
	0,
	0,
	19,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1021,
	'1');
INSERT INTO V_PAR
	VALUES (1021,
	966,
	0,
	'column',
	1022,
	19,
	25);
INSERT INTO V_VAL
	VALUES (1022,
	0,
	0,
	19,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1022,
	'1');
INSERT INTO V_PAR
	VALUES (1022,
	966,
	0,
	'answer',
	0,
	19,
	35);
INSERT INTO V_VAL
	VALUES (1023,
	0,
	0,
	20,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1023,
	'5');
INSERT INTO V_PAR
	VALUES (1023,
	967,
	0,
	'row',
	1024,
	20,
	18);
INSERT INTO V_VAL
	VALUES (1024,
	0,
	0,
	20,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1024,
	'9');
INSERT INTO V_PAR
	VALUES (1024,
	967,
	0,
	'column',
	1025,
	20,
	25);
INSERT INTO V_VAL
	VALUES (1025,
	0,
	0,
	20,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1025,
	'7');
INSERT INTO V_PAR
	VALUES (1025,
	967,
	0,
	'answer',
	0,
	20,
	35);
INSERT INTO V_VAL
	VALUES (1026,
	0,
	0,
	22,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1026,
	'6');
INSERT INTO V_PAR
	VALUES (1026,
	968,
	0,
	'row',
	1027,
	22,
	18);
INSERT INTO V_VAL
	VALUES (1027,
	0,
	0,
	22,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1027,
	'1');
INSERT INTO V_PAR
	VALUES (1027,
	968,
	0,
	'column',
	1028,
	22,
	25);
INSERT INTO V_VAL
	VALUES (1028,
	0,
	0,
	22,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1028,
	'5');
INSERT INTO V_PAR
	VALUES (1028,
	968,
	0,
	'answer',
	0,
	22,
	35);
INSERT INTO V_VAL
	VALUES (1029,
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1029,
	'6');
INSERT INTO V_PAR
	VALUES (1029,
	969,
	0,
	'row',
	1030,
	23,
	18);
INSERT INTO V_VAL
	VALUES (1030,
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1030,
	'4');
INSERT INTO V_PAR
	VALUES (1030,
	969,
	0,
	'column',
	1031,
	23,
	25);
INSERT INTO V_VAL
	VALUES (1031,
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1031,
	'2');
INSERT INTO V_PAR
	VALUES (1031,
	969,
	0,
	'answer',
	0,
	23,
	35);
INSERT INTO V_VAL
	VALUES (1032,
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1032,
	'6');
INSERT INTO V_PAR
	VALUES (1032,
	970,
	0,
	'row',
	1033,
	24,
	18);
INSERT INTO V_VAL
	VALUES (1033,
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1033,
	'6');
INSERT INTO V_PAR
	VALUES (1033,
	970,
	0,
	'column',
	1034,
	24,
	25);
INSERT INTO V_VAL
	VALUES (1034,
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1034,
	'3');
INSERT INTO V_PAR
	VALUES (1034,
	970,
	0,
	'answer',
	0,
	24,
	35);
INSERT INTO V_VAL
	VALUES (1035,
	0,
	0,
	25,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1035,
	'6');
INSERT INTO V_PAR
	VALUES (1035,
	971,
	0,
	'row',
	1036,
	25,
	18);
INSERT INTO V_VAL
	VALUES (1036,
	0,
	0,
	25,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1036,
	'9');
INSERT INTO V_PAR
	VALUES (1036,
	971,
	0,
	'column',
	1037,
	25,
	25);
INSERT INTO V_VAL
	VALUES (1037,
	0,
	0,
	25,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1037,
	'9');
INSERT INTO V_PAR
	VALUES (1037,
	971,
	0,
	'answer',
	0,
	25,
	35);
INSERT INTO V_VAL
	VALUES (1038,
	0,
	0,
	27,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1038,
	'7');
INSERT INTO V_PAR
	VALUES (1038,
	972,
	0,
	'row',
	1039,
	27,
	18);
INSERT INTO V_VAL
	VALUES (1039,
	0,
	0,
	27,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1039,
	'3');
INSERT INTO V_PAR
	VALUES (1039,
	972,
	0,
	'column',
	1040,
	27,
	25);
INSERT INTO V_VAL
	VALUES (1040,
	0,
	0,
	27,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1040,
	'4');
INSERT INTO V_PAR
	VALUES (1040,
	972,
	0,
	'answer',
	0,
	27,
	35);
INSERT INTO V_VAL
	VALUES (1041,
	0,
	0,
	28,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1041,
	'7');
INSERT INTO V_PAR
	VALUES (1041,
	973,
	0,
	'row',
	1042,
	28,
	18);
INSERT INTO V_VAL
	VALUES (1042,
	0,
	0,
	28,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1042,
	'7');
INSERT INTO V_PAR
	VALUES (1042,
	973,
	0,
	'column',
	1043,
	28,
	25);
INSERT INTO V_VAL
	VALUES (1043,
	0,
	0,
	28,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1043,
	'6');
INSERT INTO V_PAR
	VALUES (1043,
	973,
	0,
	'answer',
	0,
	28,
	35);
INSERT INTO V_VAL
	VALUES (1044,
	0,
	0,
	29,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1044,
	'7');
INSERT INTO V_PAR
	VALUES (1044,
	974,
	0,
	'row',
	1045,
	29,
	18);
INSERT INTO V_VAL
	VALUES (1045,
	0,
	0,
	29,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1045,
	'8');
INSERT INTO V_PAR
	VALUES (1045,
	974,
	0,
	'column',
	1046,
	29,
	25);
INSERT INTO V_VAL
	VALUES (1046,
	0,
	0,
	29,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1046,
	'1');
INSERT INTO V_PAR
	VALUES (1046,
	974,
	0,
	'answer',
	0,
	29,
	35);
INSERT INTO V_VAL
	VALUES (1047,
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1047,
	'8');
INSERT INTO V_PAR
	VALUES (1047,
	975,
	0,
	'row',
	1048,
	31,
	18);
INSERT INTO V_VAL
	VALUES (1048,
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1048,
	'2');
INSERT INTO V_PAR
	VALUES (1048,
	975,
	0,
	'column',
	1049,
	31,
	25);
INSERT INTO V_VAL
	VALUES (1049,
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1049,
	'2');
INSERT INTO V_PAR
	VALUES (1049,
	975,
	0,
	'answer',
	0,
	31,
	35);
INSERT INTO V_VAL
	VALUES (1050,
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1050,
	'8');
INSERT INTO V_PAR
	VALUES (1050,
	976,
	0,
	'row',
	1051,
	32,
	18);
INSERT INTO V_VAL
	VALUES (1051,
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1051,
	'3');
INSERT INTO V_PAR
	VALUES (1051,
	976,
	0,
	'column',
	1052,
	32,
	25);
INSERT INTO V_VAL
	VALUES (1052,
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1052,
	'7');
INSERT INTO V_PAR
	VALUES (1052,
	976,
	0,
	'answer',
	0,
	32,
	35);
INSERT INTO V_VAL
	VALUES (1053,
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1053,
	'8');
INSERT INTO V_PAR
	VALUES (1053,
	977,
	0,
	'row',
	1054,
	33,
	18);
INSERT INTO V_VAL
	VALUES (1054,
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1054,
	'6');
INSERT INTO V_PAR
	VALUES (1054,
	977,
	0,
	'column',
	1055,
	33,
	25);
INSERT INTO V_VAL
	VALUES (1055,
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1055,
	'6');
INSERT INTO V_PAR
	VALUES (1055,
	977,
	0,
	'answer',
	0,
	33,
	35);
INSERT INTO V_VAL
	VALUES (1056,
	0,
	0,
	35,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1056,
	'9');
INSERT INTO V_PAR
	VALUES (1056,
	978,
	0,
	'row',
	1057,
	35,
	18);
INSERT INTO V_VAL
	VALUES (1057,
	0,
	0,
	35,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1057,
	'4');
INSERT INTO V_PAR
	VALUES (1057,
	978,
	0,
	'column',
	1058,
	35,
	25);
INSERT INTO V_VAL
	VALUES (1058,
	0,
	0,
	35,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1058,
	'9');
INSERT INTO V_PAR
	VALUES (1058,
	978,
	0,
	'answer',
	0,
	35,
	35);
INSERT INTO V_VAL
	VALUES (1059,
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1059,
	'9');
INSERT INTO V_PAR
	VALUES (1059,
	979,
	0,
	'row',
	1060,
	36,
	18);
INSERT INTO V_VAL
	VALUES (1060,
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1060,
	'5');
INSERT INTO V_PAR
	VALUES (1060,
	979,
	0,
	'column',
	1061,
	36,
	25);
INSERT INTO V_VAL
	VALUES (1061,
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1061,
	'3');
INSERT INTO V_PAR
	VALUES (1061,
	979,
	0,
	'answer',
	0,
	36,
	35);
INSERT INTO V_VAL
	VALUES (1062,
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1062,
	'9');
INSERT INTO V_PAR
	VALUES (1062,
	980,
	0,
	'row',
	1063,
	37,
	18);
INSERT INTO V_VAL
	VALUES (1063,
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1063,
	'8');
INSERT INTO V_PAR
	VALUES (1063,
	980,
	0,
	'column',
	1064,
	37,
	25);
INSERT INTO V_VAL
	VALUES (1064,
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	952);
INSERT INTO V_LIN
	VALUES (1064,
	'8');
INSERT INTO V_PAR
	VALUES (1064,
	980,
	0,
	'answer',
	0,
	37,
	35);
INSERT INTO S_FIP
	VALUES (102,
	1065);
INSERT INTO S_SYNC
	VALUES (1065,
	2,
	'setz4_spectrum',
	'',
	'
CELL::set_given( row:1, column:5, answer:8 );
CELL::set_given( row:1, column:6, answer:3 );
CELL::set_given( row:1, column:7, answer:4 );

CELL::set_given( row:2, column:1, answer:3 );
CELL::set_given( row:2, column:6, answer:4 );
CELL::set_given( row:2, column:7, answer:8 );
CELL::set_given( row:2, column:8, answer:2 );
CELL::set_given( row:2, column:9, answer:1 );

CELL::set_given( row:3, column:1, answer:7 );

CELL::set_given( row:4, column:3, answer:9 );
CELL::set_given( row:4, column:4, answer:4 );
CELL::set_given( row:4, column:6, answer:1 );
CELL::set_given( row:4, column:8, answer:8 );
CELL::set_given( row:4, column:9, answer:3 );


CELL::set_given( row:6, column:1, answer:4 );
CELL::set_given( row:6, column:2, answer:6 );
CELL::set_given( row:6, column:4, answer:5 );
CELL::set_given( row:6, column:6, answer:7 );
CELL::set_given( row:6, column:7, answer:1 );

CELL::set_given( row:7, column:9, answer:7 );

CELL::set_given( row:8, column:1, answer:1 );
CELL::set_given( row:8, column:2, answer:2 );
CELL::set_given( row:8, column:3, answer:5 );
CELL::set_given( row:8, column:4, answer:3 );
CELL::set_given( row:8, column:9, answer:9 );

CELL::set_given( row:9, column:3, answer:7 );
CELL::set_given( row:9, column:4, answer:2 );
CELL::set_given( row:9, column:5, answer:4 );',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (1066,
	1065);
INSERT INTO ACT_ACT
	VALUES (1066,
	'function',
	0,
	1067,
	0,
	0,
	'setz4_spectrum',
	0);
INSERT INTO ACT_BLK
	VALUES (1067,
	0,
	0,
	0,
	'CELL',
	'',
	'',
	37,
	1,
	37,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1066,
	0);
INSERT INTO ACT_SMT
	VALUES (1068,
	1067,
	1069,
	2,
	1,
	'setz4_spectrum line: 2');
INSERT INTO ACT_TFM
	VALUES (1068,
	606,
	0,
	2,
	7,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (1069,
	1067,
	1070,
	3,
	1,
	'setz4_spectrum line: 3');
INSERT INTO ACT_TFM
	VALUES (1069,
	606,
	0,
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES (1070,
	1067,
	1071,
	4,
	1,
	'setz4_spectrum line: 4');
INSERT INTO ACT_TFM
	VALUES (1070,
	606,
	0,
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES (1071,
	1067,
	1072,
	6,
	1,
	'setz4_spectrum line: 6');
INSERT INTO ACT_TFM
	VALUES (1071,
	606,
	0,
	6,
	7,
	6,
	1);
INSERT INTO ACT_SMT
	VALUES (1072,
	1067,
	1073,
	7,
	1,
	'setz4_spectrum line: 7');
INSERT INTO ACT_TFM
	VALUES (1072,
	606,
	0,
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES (1073,
	1067,
	1074,
	8,
	1,
	'setz4_spectrum line: 8');
INSERT INTO ACT_TFM
	VALUES (1073,
	606,
	0,
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES (1074,
	1067,
	1075,
	9,
	1,
	'setz4_spectrum line: 9');
INSERT INTO ACT_TFM
	VALUES (1074,
	606,
	0,
	9,
	7,
	9,
	1);
INSERT INTO ACT_SMT
	VALUES (1075,
	1067,
	1076,
	10,
	1,
	'setz4_spectrum line: 10');
INSERT INTO ACT_TFM
	VALUES (1075,
	606,
	0,
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES (1076,
	1067,
	1077,
	12,
	1,
	'setz4_spectrum line: 12');
INSERT INTO ACT_TFM
	VALUES (1076,
	606,
	0,
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES (1077,
	1067,
	1078,
	14,
	1,
	'setz4_spectrum line: 14');
INSERT INTO ACT_TFM
	VALUES (1077,
	606,
	0,
	14,
	7,
	14,
	1);
INSERT INTO ACT_SMT
	VALUES (1078,
	1067,
	1079,
	15,
	1,
	'setz4_spectrum line: 15');
INSERT INTO ACT_TFM
	VALUES (1078,
	606,
	0,
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES (1079,
	1067,
	1080,
	16,
	1,
	'setz4_spectrum line: 16');
INSERT INTO ACT_TFM
	VALUES (1079,
	606,
	0,
	16,
	7,
	16,
	1);
INSERT INTO ACT_SMT
	VALUES (1080,
	1067,
	1081,
	17,
	1,
	'setz4_spectrum line: 17');
INSERT INTO ACT_TFM
	VALUES (1080,
	606,
	0,
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES (1081,
	1067,
	1082,
	18,
	1,
	'setz4_spectrum line: 18');
INSERT INTO ACT_TFM
	VALUES (1081,
	606,
	0,
	18,
	7,
	18,
	1);
INSERT INTO ACT_SMT
	VALUES (1082,
	1067,
	1083,
	21,
	1,
	'setz4_spectrum line: 21');
INSERT INTO ACT_TFM
	VALUES (1082,
	606,
	0,
	21,
	7,
	21,
	1);
INSERT INTO ACT_SMT
	VALUES (1083,
	1067,
	1084,
	22,
	1,
	'setz4_spectrum line: 22');
INSERT INTO ACT_TFM
	VALUES (1083,
	606,
	0,
	22,
	7,
	22,
	1);
INSERT INTO ACT_SMT
	VALUES (1084,
	1067,
	1085,
	23,
	1,
	'setz4_spectrum line: 23');
INSERT INTO ACT_TFM
	VALUES (1084,
	606,
	0,
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES (1085,
	1067,
	1086,
	24,
	1,
	'setz4_spectrum line: 24');
INSERT INTO ACT_TFM
	VALUES (1085,
	606,
	0,
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES (1086,
	1067,
	1087,
	25,
	1,
	'setz4_spectrum line: 25');
INSERT INTO ACT_TFM
	VALUES (1086,
	606,
	0,
	25,
	7,
	25,
	1);
INSERT INTO ACT_SMT
	VALUES (1087,
	1067,
	1088,
	27,
	1,
	'setz4_spectrum line: 27');
INSERT INTO ACT_TFM
	VALUES (1087,
	606,
	0,
	27,
	7,
	27,
	1);
INSERT INTO ACT_SMT
	VALUES (1088,
	1067,
	1089,
	29,
	1,
	'setz4_spectrum line: 29');
INSERT INTO ACT_TFM
	VALUES (1088,
	606,
	0,
	29,
	7,
	29,
	1);
INSERT INTO ACT_SMT
	VALUES (1089,
	1067,
	1090,
	30,
	1,
	'setz4_spectrum line: 30');
INSERT INTO ACT_TFM
	VALUES (1089,
	606,
	0,
	30,
	7,
	30,
	1);
INSERT INTO ACT_SMT
	VALUES (1090,
	1067,
	1091,
	31,
	1,
	'setz4_spectrum line: 31');
INSERT INTO ACT_TFM
	VALUES (1090,
	606,
	0,
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES (1091,
	1067,
	1092,
	32,
	1,
	'setz4_spectrum line: 32');
INSERT INTO ACT_TFM
	VALUES (1091,
	606,
	0,
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES (1092,
	1067,
	1093,
	33,
	1,
	'setz4_spectrum line: 33');
INSERT INTO ACT_TFM
	VALUES (1092,
	606,
	0,
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES (1093,
	1067,
	1094,
	35,
	1,
	'setz4_spectrum line: 35');
INSERT INTO ACT_TFM
	VALUES (1093,
	606,
	0,
	35,
	7,
	35,
	1);
INSERT INTO ACT_SMT
	VALUES (1094,
	1067,
	1095,
	36,
	1,
	'setz4_spectrum line: 36');
INSERT INTO ACT_TFM
	VALUES (1094,
	606,
	0,
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES (1095,
	1067,
	0,
	37,
	1,
	'setz4_spectrum line: 37');
INSERT INTO ACT_TFM
	VALUES (1095,
	606,
	0,
	37,
	7,
	37,
	1);
INSERT INTO V_VAL
	VALUES (1096,
	0,
	0,
	2,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1096,
	'1');
INSERT INTO V_PAR
	VALUES (1096,
	1068,
	0,
	'row',
	1097,
	2,
	18);
INSERT INTO V_VAL
	VALUES (1097,
	0,
	0,
	2,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1097,
	'5');
INSERT INTO V_PAR
	VALUES (1097,
	1068,
	0,
	'column',
	1098,
	2,
	25);
INSERT INTO V_VAL
	VALUES (1098,
	0,
	0,
	2,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1098,
	'8');
INSERT INTO V_PAR
	VALUES (1098,
	1068,
	0,
	'answer',
	0,
	2,
	35);
INSERT INTO V_VAL
	VALUES (1099,
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1099,
	'1');
INSERT INTO V_PAR
	VALUES (1099,
	1069,
	0,
	'row',
	1100,
	3,
	18);
INSERT INTO V_VAL
	VALUES (1100,
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1100,
	'6');
INSERT INTO V_PAR
	VALUES (1100,
	1069,
	0,
	'column',
	1101,
	3,
	25);
INSERT INTO V_VAL
	VALUES (1101,
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1101,
	'3');
INSERT INTO V_PAR
	VALUES (1101,
	1069,
	0,
	'answer',
	0,
	3,
	35);
INSERT INTO V_VAL
	VALUES (1102,
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1102,
	'1');
INSERT INTO V_PAR
	VALUES (1102,
	1070,
	0,
	'row',
	1103,
	4,
	18);
INSERT INTO V_VAL
	VALUES (1103,
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1103,
	'7');
INSERT INTO V_PAR
	VALUES (1103,
	1070,
	0,
	'column',
	1104,
	4,
	25);
INSERT INTO V_VAL
	VALUES (1104,
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1104,
	'4');
INSERT INTO V_PAR
	VALUES (1104,
	1070,
	0,
	'answer',
	0,
	4,
	35);
INSERT INTO V_VAL
	VALUES (1105,
	0,
	0,
	6,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1105,
	'2');
INSERT INTO V_PAR
	VALUES (1105,
	1071,
	0,
	'row',
	1106,
	6,
	18);
INSERT INTO V_VAL
	VALUES (1106,
	0,
	0,
	6,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1106,
	'1');
INSERT INTO V_PAR
	VALUES (1106,
	1071,
	0,
	'column',
	1107,
	6,
	25);
INSERT INTO V_VAL
	VALUES (1107,
	0,
	0,
	6,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1107,
	'3');
INSERT INTO V_PAR
	VALUES (1107,
	1071,
	0,
	'answer',
	0,
	6,
	35);
INSERT INTO V_VAL
	VALUES (1108,
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1108,
	'2');
INSERT INTO V_PAR
	VALUES (1108,
	1072,
	0,
	'row',
	1109,
	7,
	18);
INSERT INTO V_VAL
	VALUES (1109,
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1109,
	'6');
INSERT INTO V_PAR
	VALUES (1109,
	1072,
	0,
	'column',
	1110,
	7,
	25);
INSERT INTO V_VAL
	VALUES (1110,
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1110,
	'4');
INSERT INTO V_PAR
	VALUES (1110,
	1072,
	0,
	'answer',
	0,
	7,
	35);
INSERT INTO V_VAL
	VALUES (1111,
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1111,
	'2');
INSERT INTO V_PAR
	VALUES (1111,
	1073,
	0,
	'row',
	1112,
	8,
	18);
INSERT INTO V_VAL
	VALUES (1112,
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1112,
	'7');
INSERT INTO V_PAR
	VALUES (1112,
	1073,
	0,
	'column',
	1113,
	8,
	25);
INSERT INTO V_VAL
	VALUES (1113,
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1113,
	'8');
INSERT INTO V_PAR
	VALUES (1113,
	1073,
	0,
	'answer',
	0,
	8,
	35);
INSERT INTO V_VAL
	VALUES (1114,
	0,
	0,
	9,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1114,
	'2');
INSERT INTO V_PAR
	VALUES (1114,
	1074,
	0,
	'row',
	1115,
	9,
	18);
INSERT INTO V_VAL
	VALUES (1115,
	0,
	0,
	9,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1115,
	'8');
INSERT INTO V_PAR
	VALUES (1115,
	1074,
	0,
	'column',
	1116,
	9,
	25);
INSERT INTO V_VAL
	VALUES (1116,
	0,
	0,
	9,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1116,
	'2');
INSERT INTO V_PAR
	VALUES (1116,
	1074,
	0,
	'answer',
	0,
	9,
	35);
INSERT INTO V_VAL
	VALUES (1117,
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1117,
	'2');
INSERT INTO V_PAR
	VALUES (1117,
	1075,
	0,
	'row',
	1118,
	10,
	18);
INSERT INTO V_VAL
	VALUES (1118,
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1118,
	'9');
INSERT INTO V_PAR
	VALUES (1118,
	1075,
	0,
	'column',
	1119,
	10,
	25);
INSERT INTO V_VAL
	VALUES (1119,
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1119,
	'1');
INSERT INTO V_PAR
	VALUES (1119,
	1075,
	0,
	'answer',
	0,
	10,
	35);
INSERT INTO V_VAL
	VALUES (1120,
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1120,
	'3');
INSERT INTO V_PAR
	VALUES (1120,
	1076,
	0,
	'row',
	1121,
	12,
	18);
INSERT INTO V_VAL
	VALUES (1121,
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1121,
	'1');
INSERT INTO V_PAR
	VALUES (1121,
	1076,
	0,
	'column',
	1122,
	12,
	25);
INSERT INTO V_VAL
	VALUES (1122,
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1122,
	'7');
INSERT INTO V_PAR
	VALUES (1122,
	1076,
	0,
	'answer',
	0,
	12,
	35);
INSERT INTO V_VAL
	VALUES (1123,
	0,
	0,
	14,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1123,
	'4');
INSERT INTO V_PAR
	VALUES (1123,
	1077,
	0,
	'row',
	1124,
	14,
	18);
INSERT INTO V_VAL
	VALUES (1124,
	0,
	0,
	14,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1124,
	'3');
INSERT INTO V_PAR
	VALUES (1124,
	1077,
	0,
	'column',
	1125,
	14,
	25);
INSERT INTO V_VAL
	VALUES (1125,
	0,
	0,
	14,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1125,
	'9');
INSERT INTO V_PAR
	VALUES (1125,
	1077,
	0,
	'answer',
	0,
	14,
	35);
INSERT INTO V_VAL
	VALUES (1126,
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1126,
	'4');
INSERT INTO V_PAR
	VALUES (1126,
	1078,
	0,
	'row',
	1127,
	15,
	18);
INSERT INTO V_VAL
	VALUES (1127,
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1127,
	'4');
INSERT INTO V_PAR
	VALUES (1127,
	1078,
	0,
	'column',
	1128,
	15,
	25);
INSERT INTO V_VAL
	VALUES (1128,
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1128,
	'4');
INSERT INTO V_PAR
	VALUES (1128,
	1078,
	0,
	'answer',
	0,
	15,
	35);
INSERT INTO V_VAL
	VALUES (1129,
	0,
	0,
	16,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1129,
	'4');
INSERT INTO V_PAR
	VALUES (1129,
	1079,
	0,
	'row',
	1130,
	16,
	18);
INSERT INTO V_VAL
	VALUES (1130,
	0,
	0,
	16,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1130,
	'6');
INSERT INTO V_PAR
	VALUES (1130,
	1079,
	0,
	'column',
	1131,
	16,
	25);
INSERT INTO V_VAL
	VALUES (1131,
	0,
	0,
	16,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1131,
	'1');
INSERT INTO V_PAR
	VALUES (1131,
	1079,
	0,
	'answer',
	0,
	16,
	35);
INSERT INTO V_VAL
	VALUES (1132,
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1132,
	'4');
INSERT INTO V_PAR
	VALUES (1132,
	1080,
	0,
	'row',
	1133,
	17,
	18);
INSERT INTO V_VAL
	VALUES (1133,
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1133,
	'8');
INSERT INTO V_PAR
	VALUES (1133,
	1080,
	0,
	'column',
	1134,
	17,
	25);
INSERT INTO V_VAL
	VALUES (1134,
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1134,
	'8');
INSERT INTO V_PAR
	VALUES (1134,
	1080,
	0,
	'answer',
	0,
	17,
	35);
INSERT INTO V_VAL
	VALUES (1135,
	0,
	0,
	18,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1135,
	'4');
INSERT INTO V_PAR
	VALUES (1135,
	1081,
	0,
	'row',
	1136,
	18,
	18);
INSERT INTO V_VAL
	VALUES (1136,
	0,
	0,
	18,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1136,
	'9');
INSERT INTO V_PAR
	VALUES (1136,
	1081,
	0,
	'column',
	1137,
	18,
	25);
INSERT INTO V_VAL
	VALUES (1137,
	0,
	0,
	18,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1137,
	'3');
INSERT INTO V_PAR
	VALUES (1137,
	1081,
	0,
	'answer',
	0,
	18,
	35);
INSERT INTO V_VAL
	VALUES (1138,
	0,
	0,
	21,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1138,
	'6');
INSERT INTO V_PAR
	VALUES (1138,
	1082,
	0,
	'row',
	1139,
	21,
	18);
INSERT INTO V_VAL
	VALUES (1139,
	0,
	0,
	21,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1139,
	'1');
INSERT INTO V_PAR
	VALUES (1139,
	1082,
	0,
	'column',
	1140,
	21,
	25);
INSERT INTO V_VAL
	VALUES (1140,
	0,
	0,
	21,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1140,
	'4');
INSERT INTO V_PAR
	VALUES (1140,
	1082,
	0,
	'answer',
	0,
	21,
	35);
INSERT INTO V_VAL
	VALUES (1141,
	0,
	0,
	22,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1141,
	'6');
INSERT INTO V_PAR
	VALUES (1141,
	1083,
	0,
	'row',
	1142,
	22,
	18);
INSERT INTO V_VAL
	VALUES (1142,
	0,
	0,
	22,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1142,
	'2');
INSERT INTO V_PAR
	VALUES (1142,
	1083,
	0,
	'column',
	1143,
	22,
	25);
INSERT INTO V_VAL
	VALUES (1143,
	0,
	0,
	22,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1143,
	'6');
INSERT INTO V_PAR
	VALUES (1143,
	1083,
	0,
	'answer',
	0,
	22,
	35);
INSERT INTO V_VAL
	VALUES (1144,
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1144,
	'6');
INSERT INTO V_PAR
	VALUES (1144,
	1084,
	0,
	'row',
	1145,
	23,
	18);
INSERT INTO V_VAL
	VALUES (1145,
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1145,
	'4');
INSERT INTO V_PAR
	VALUES (1145,
	1084,
	0,
	'column',
	1146,
	23,
	25);
INSERT INTO V_VAL
	VALUES (1146,
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1146,
	'5');
INSERT INTO V_PAR
	VALUES (1146,
	1084,
	0,
	'answer',
	0,
	23,
	35);
INSERT INTO V_VAL
	VALUES (1147,
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1147,
	'6');
INSERT INTO V_PAR
	VALUES (1147,
	1085,
	0,
	'row',
	1148,
	24,
	18);
INSERT INTO V_VAL
	VALUES (1148,
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1148,
	'6');
INSERT INTO V_PAR
	VALUES (1148,
	1085,
	0,
	'column',
	1149,
	24,
	25);
INSERT INTO V_VAL
	VALUES (1149,
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1149,
	'7');
INSERT INTO V_PAR
	VALUES (1149,
	1085,
	0,
	'answer',
	0,
	24,
	35);
INSERT INTO V_VAL
	VALUES (1150,
	0,
	0,
	25,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1150,
	'6');
INSERT INTO V_PAR
	VALUES (1150,
	1086,
	0,
	'row',
	1151,
	25,
	18);
INSERT INTO V_VAL
	VALUES (1151,
	0,
	0,
	25,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1151,
	'7');
INSERT INTO V_PAR
	VALUES (1151,
	1086,
	0,
	'column',
	1152,
	25,
	25);
INSERT INTO V_VAL
	VALUES (1152,
	0,
	0,
	25,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1152,
	'1');
INSERT INTO V_PAR
	VALUES (1152,
	1086,
	0,
	'answer',
	0,
	25,
	35);
INSERT INTO V_VAL
	VALUES (1153,
	0,
	0,
	27,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1153,
	'7');
INSERT INTO V_PAR
	VALUES (1153,
	1087,
	0,
	'row',
	1154,
	27,
	18);
INSERT INTO V_VAL
	VALUES (1154,
	0,
	0,
	27,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1154,
	'9');
INSERT INTO V_PAR
	VALUES (1154,
	1087,
	0,
	'column',
	1155,
	27,
	25);
INSERT INTO V_VAL
	VALUES (1155,
	0,
	0,
	27,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1155,
	'7');
INSERT INTO V_PAR
	VALUES (1155,
	1087,
	0,
	'answer',
	0,
	27,
	35);
INSERT INTO V_VAL
	VALUES (1156,
	0,
	0,
	29,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1156,
	'8');
INSERT INTO V_PAR
	VALUES (1156,
	1088,
	0,
	'row',
	1157,
	29,
	18);
INSERT INTO V_VAL
	VALUES (1157,
	0,
	0,
	29,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1157,
	'1');
INSERT INTO V_PAR
	VALUES (1157,
	1088,
	0,
	'column',
	1158,
	29,
	25);
INSERT INTO V_VAL
	VALUES (1158,
	0,
	0,
	29,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1158,
	'1');
INSERT INTO V_PAR
	VALUES (1158,
	1088,
	0,
	'answer',
	0,
	29,
	35);
INSERT INTO V_VAL
	VALUES (1159,
	0,
	0,
	30,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1159,
	'8');
INSERT INTO V_PAR
	VALUES (1159,
	1089,
	0,
	'row',
	1160,
	30,
	18);
INSERT INTO V_VAL
	VALUES (1160,
	0,
	0,
	30,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1160,
	'2');
INSERT INTO V_PAR
	VALUES (1160,
	1089,
	0,
	'column',
	1161,
	30,
	25);
INSERT INTO V_VAL
	VALUES (1161,
	0,
	0,
	30,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1161,
	'2');
INSERT INTO V_PAR
	VALUES (1161,
	1089,
	0,
	'answer',
	0,
	30,
	35);
INSERT INTO V_VAL
	VALUES (1162,
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1162,
	'8');
INSERT INTO V_PAR
	VALUES (1162,
	1090,
	0,
	'row',
	1163,
	31,
	18);
INSERT INTO V_VAL
	VALUES (1163,
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1163,
	'3');
INSERT INTO V_PAR
	VALUES (1163,
	1090,
	0,
	'column',
	1164,
	31,
	25);
INSERT INTO V_VAL
	VALUES (1164,
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1164,
	'5');
INSERT INTO V_PAR
	VALUES (1164,
	1090,
	0,
	'answer',
	0,
	31,
	35);
INSERT INTO V_VAL
	VALUES (1165,
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1165,
	'8');
INSERT INTO V_PAR
	VALUES (1165,
	1091,
	0,
	'row',
	1166,
	32,
	18);
INSERT INTO V_VAL
	VALUES (1166,
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1166,
	'4');
INSERT INTO V_PAR
	VALUES (1166,
	1091,
	0,
	'column',
	1167,
	32,
	25);
INSERT INTO V_VAL
	VALUES (1167,
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1167,
	'3');
INSERT INTO V_PAR
	VALUES (1167,
	1091,
	0,
	'answer',
	0,
	32,
	35);
INSERT INTO V_VAL
	VALUES (1168,
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1168,
	'8');
INSERT INTO V_PAR
	VALUES (1168,
	1092,
	0,
	'row',
	1169,
	33,
	18);
INSERT INTO V_VAL
	VALUES (1169,
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1169,
	'9');
INSERT INTO V_PAR
	VALUES (1169,
	1092,
	0,
	'column',
	1170,
	33,
	25);
INSERT INTO V_VAL
	VALUES (1170,
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1170,
	'9');
INSERT INTO V_PAR
	VALUES (1170,
	1092,
	0,
	'answer',
	0,
	33,
	35);
INSERT INTO V_VAL
	VALUES (1171,
	0,
	0,
	35,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1171,
	'9');
INSERT INTO V_PAR
	VALUES (1171,
	1093,
	0,
	'row',
	1172,
	35,
	18);
INSERT INTO V_VAL
	VALUES (1172,
	0,
	0,
	35,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1172,
	'3');
INSERT INTO V_PAR
	VALUES (1172,
	1093,
	0,
	'column',
	1173,
	35,
	25);
INSERT INTO V_VAL
	VALUES (1173,
	0,
	0,
	35,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1173,
	'7');
INSERT INTO V_PAR
	VALUES (1173,
	1093,
	0,
	'answer',
	0,
	35,
	35);
INSERT INTO V_VAL
	VALUES (1174,
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1174,
	'9');
INSERT INTO V_PAR
	VALUES (1174,
	1094,
	0,
	'row',
	1175,
	36,
	18);
INSERT INTO V_VAL
	VALUES (1175,
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1175,
	'4');
INSERT INTO V_PAR
	VALUES (1175,
	1094,
	0,
	'column',
	1176,
	36,
	25);
INSERT INTO V_VAL
	VALUES (1176,
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1176,
	'2');
INSERT INTO V_PAR
	VALUES (1176,
	1094,
	0,
	'answer',
	0,
	36,
	35);
INSERT INTO V_VAL
	VALUES (1177,
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1177,
	'9');
INSERT INTO V_PAR
	VALUES (1177,
	1095,
	0,
	'row',
	1178,
	37,
	18);
INSERT INTO V_VAL
	VALUES (1178,
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1178,
	'5');
INSERT INTO V_PAR
	VALUES (1178,
	1095,
	0,
	'column',
	1179,
	37,
	25);
INSERT INTO V_VAL
	VALUES (1179,
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	7,
	1067);
INSERT INTO V_LIN
	VALUES (1179,
	'4');
INSERT INTO V_PAR
	VALUES (1179,
	1095,
	0,
	'answer',
	0,
	37,
	35);
INSERT INTO S_FIP
	VALUES (102,
	1180);
INSERT INTO S_SYNC
	VALUES (1180,
	2,
	'test',
	'',
	'// Run the puzzles we know about.
::setz4_spectrum();
::solve();
::cleanup();

//
// ::setup();
// ::setz2_given();
// ::solve();
// ::cleanup();
// 
// ::setup();
// ::setz4_spectrum();
// ::solve();
// ::cleanup();
// 

',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (1181,
	1180);
INSERT INTO ACT_ACT
	VALUES (1181,
	'function',
	0,
	1182,
	0,
	0,
	'test',
	0);
INSERT INTO ACT_BLK
	VALUES (1182,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1181,
	0);
INSERT INTO ACT_SMT
	VALUES (1183,
	1182,
	1184,
	2,
	1,
	'test line: 2');
INSERT INTO ACT_FNC
	VALUES (1183,
	1065,
	2,
	3);
INSERT INTO ACT_SMT
	VALUES (1184,
	1182,
	1185,
	3,
	1,
	'test line: 3');
INSERT INTO ACT_FNC
	VALUES (1184,
	794,
	3,
	3);
INSERT INTO ACT_SMT
	VALUES (1185,
	1182,
	0,
	4,
	1,
	'test line: 4');
INSERT INTO ACT_FNC
	VALUES (1185,
	1186,
	4,
	3);
INSERT INTO S_FIP
	VALUES (102,
	1186);
INSERT INTO S_SYNC
	VALUES (1186,
	2,
	'cleanup',
	'',
	'
// Clean up any and all eligible digits.
select many eligibles from instances of ELIGIBLE;
for each eligible in eligibles
  select one cell related by eligible->CELL[R8];
  select one digit related by eligible->DIGIT[R8];
  unrelate cell from digit across R8 using eligible;
  delete object instance eligible;
end for;

// Unrelate the answers.
select many cells from instances of CELL;
for each cell in cells
  select one digit related by cell->DIGIT[R9];
  if ( not_empty digit )
    unrelate cell from digit across R9;
  end if;
end for;

// Delete the digits.
select many digits from instances of DIGIT;
for each digit in digits
  delete object instance digit;
end for;

// Unrelate/delete the cells from the rows, columns and boxes.
// Unrelate/delete the sequences.
// Delete the cells while unrelating the boxes.
select many rows from instances of ROW;
for each row in rows
  select many cells related by row->CELL[R2];
  for each cell in cells
    unrelate row from cell across R2;
  end for;
  select one sequence related by row->SEQUENCE[R1];
  delete object instance sequence;
  delete object instance row;
end for;  
select many columns from instances of COLUMN;
for each column in columns
  select many cells related by column->CELL[R3];
  for each cell in cells
    unrelate column from cell across R3;
  end for;
  select one sequence related by column->SEQUENCE[R1];
  delete object instance sequence;
  delete object instance column;
end for;  
select many boxes from instances of BOX;
for each box in boxes
  select many cells related by box->CELL[R4];
  for each cell in cells
    unrelate box from cell across R4;
    delete object instance cell;
  end for;
  select one sequence related by box->SEQUENCE[R1];
  delete object instance sequence;
  delete object instance box;
end for;  
',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (1187,
	1186);
INSERT INTO ACT_ACT
	VALUES (1187,
	'function',
	0,
	1188,
	0,
	0,
	'cleanup',
	0);
INSERT INTO ACT_BLK
	VALUES (1188,
	1,
	0,
	0,
	'',
	'',
	'',
	50,
	1,
	49,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1189,
	1188,
	1190,
	3,
	1,
	'cleanup line: 3');
INSERT INTO ACT_FIO
	VALUES (1189,
	1191,
	1,
	'many',
	382,
	3,
	41);
INSERT INTO ACT_SMT
	VALUES (1190,
	1188,
	1192,
	4,
	1,
	'cleanup line: 4');
INSERT INTO ACT_FOR
	VALUES (1190,
	1193,
	1,
	1194,
	1191,
	382);
INSERT INTO ACT_SMT
	VALUES (1192,
	1188,
	1195,
	12,
	1,
	'cleanup line: 12');
INSERT INTO ACT_FIO
	VALUES (1192,
	1196,
	1,
	'many',
	168,
	12,
	37);
INSERT INTO ACT_SMT
	VALUES (1195,
	1188,
	1197,
	13,
	1,
	'cleanup line: 13');
INSERT INTO ACT_FOR
	VALUES (1195,
	1198,
	1,
	1199,
	1196,
	168);
INSERT INTO ACT_SMT
	VALUES (1197,
	1188,
	1200,
	21,
	1,
	'cleanup line: 21');
INSERT INTO ACT_FIO
	VALUES (1197,
	1201,
	1,
	'many',
	150,
	21,
	38);
INSERT INTO ACT_SMT
	VALUES (1200,
	1188,
	1202,
	22,
	1,
	'cleanup line: 22');
INSERT INTO ACT_FOR
	VALUES (1200,
	1203,
	1,
	1204,
	1201,
	150);
INSERT INTO ACT_SMT
	VALUES (1202,
	1188,
	1205,
	29,
	1,
	'cleanup line: 29');
INSERT INTO ACT_FIO
	VALUES (1202,
	1206,
	1,
	'many',
	162,
	29,
	36);
INSERT INTO ACT_SMT
	VALUES (1205,
	1188,
	1207,
	30,
	1,
	'cleanup line: 30');
INSERT INTO ACT_FOR
	VALUES (1205,
	1208,
	1,
	1209,
	1206,
	162);
INSERT INTO ACT_SMT
	VALUES (1207,
	1188,
	1210,
	39,
	1,
	'cleanup line: 39');
INSERT INTO ACT_FIO
	VALUES (1207,
	1211,
	1,
	'many',
	296,
	39,
	39);
INSERT INTO ACT_SMT
	VALUES (1210,
	1188,
	1212,
	40,
	1,
	'cleanup line: 40');
INSERT INTO ACT_FOR
	VALUES (1210,
	1213,
	1,
	1214,
	1211,
	296);
INSERT INTO ACT_SMT
	VALUES (1212,
	1188,
	1215,
	49,
	1,
	'cleanup line: 49');
INSERT INTO ACT_FIO
	VALUES (1212,
	1216,
	1,
	'many',
	310,
	49,
	37);
INSERT INTO ACT_SMT
	VALUES (1215,
	1188,
	0,
	50,
	1,
	'cleanup line: 50');
INSERT INTO ACT_FOR
	VALUES (1215,
	1217,
	1,
	1218,
	1216,
	310);
INSERT INTO V_VAR
	VALUES (1191,
	1188,
	'eligibles',
	1,
	14);
INSERT INTO V_INS
	VALUES (1191,
	382);
INSERT INTO V_LOC
	VALUES (1219,
	3,
	13,
	21,
	1191);
INSERT INTO V_LOC
	VALUES (1220,
	4,
	22,
	30,
	1191);
INSERT INTO V_VAR
	VALUES (1194,
	1188,
	'eligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (1194,
	1,
	382);
INSERT INTO V_LOC
	VALUES (1221,
	4,
	10,
	17,
	1194);
INSERT INTO V_LOC
	VALUES (1222,
	7,
	44,
	51,
	1194);
INSERT INTO V_LOC
	VALUES (1223,
	8,
	26,
	33,
	1194);
INSERT INTO V_VAR
	VALUES (1196,
	1188,
	'cells',
	1,
	14);
INSERT INTO V_INS
	VALUES (1196,
	168);
INSERT INTO V_LOC
	VALUES (1224,
	12,
	13,
	17,
	1196);
INSERT INTO V_LOC
	VALUES (1225,
	13,
	18,
	22,
	1196);
INSERT INTO V_LOC
	VALUES (1226,
	31,
	15,
	19,
	1196);
INSERT INTO V_LOC
	VALUES (1227,
	32,
	20,
	24,
	1196);
INSERT INTO V_LOC
	VALUES (1228,
	41,
	15,
	19,
	1196);
INSERT INTO V_LOC
	VALUES (1229,
	42,
	20,
	24,
	1196);
INSERT INTO V_LOC
	VALUES (1230,
	51,
	15,
	19,
	1196);
INSERT INTO V_LOC
	VALUES (1231,
	52,
	20,
	24,
	1196);
INSERT INTO V_VAR
	VALUES (1199,
	1188,
	'cell',
	1,
	13);
INSERT INTO V_INT
	VALUES (1199,
	0,
	168);
INSERT INTO V_LOC
	VALUES (1232,
	13,
	10,
	13,
	1199);
INSERT INTO V_LOC
	VALUES (1233,
	16,
	14,
	17,
	1199);
INSERT INTO V_LOC
	VALUES (1234,
	32,
	12,
	15,
	1199);
INSERT INTO V_LOC
	VALUES (1235,
	33,
	23,
	26,
	1199);
INSERT INTO V_LOC
	VALUES (1236,
	42,
	12,
	15,
	1199);
INSERT INTO V_LOC
	VALUES (1237,
	43,
	26,
	29,
	1199);
INSERT INTO V_LOC
	VALUES (1238,
	52,
	12,
	15,
	1199);
INSERT INTO V_LOC
	VALUES (1239,
	53,
	23,
	26,
	1199);
INSERT INTO V_LOC
	VALUES (1240,
	54,
	28,
	31,
	1199);
INSERT INTO V_VAR
	VALUES (1201,
	1188,
	'digits',
	1,
	14);
INSERT INTO V_INS
	VALUES (1201,
	150);
INSERT INTO V_LOC
	VALUES (1241,
	21,
	13,
	18,
	1201);
INSERT INTO V_LOC
	VALUES (1242,
	22,
	19,
	24,
	1201);
INSERT INTO V_VAR
	VALUES (1204,
	1188,
	'digit',
	1,
	13);
INSERT INTO V_INT
	VALUES (1204,
	1,
	150);
INSERT INTO V_LOC
	VALUES (1243,
	22,
	10,
	14,
	1204);
INSERT INTO V_LOC
	VALUES (1244,
	23,
	26,
	30,
	1204);
INSERT INTO V_VAR
	VALUES (1206,
	1188,
	'rows',
	1,
	14);
INSERT INTO V_INS
	VALUES (1206,
	162);
INSERT INTO V_LOC
	VALUES (1245,
	29,
	13,
	16,
	1206);
INSERT INTO V_LOC
	VALUES (1246,
	30,
	17,
	20,
	1206);
INSERT INTO V_VAR
	VALUES (1209,
	1188,
	'row',
	1,
	13);
INSERT INTO V_INT
	VALUES (1209,
	1,
	162);
INSERT INTO V_LOC
	VALUES (1247,
	30,
	10,
	12,
	1209);
INSERT INTO V_LOC
	VALUES (1248,
	33,
	14,
	16,
	1209);
INSERT INTO V_LOC
	VALUES (1249,
	37,
	26,
	28,
	1209);
INSERT INTO V_VAR
	VALUES (1211,
	1188,
	'columns',
	1,
	14);
INSERT INTO V_INS
	VALUES (1211,
	296);
INSERT INTO V_LOC
	VALUES (1250,
	39,
	13,
	19,
	1211);
INSERT INTO V_LOC
	VALUES (1251,
	40,
	20,
	26,
	1211);
INSERT INTO V_VAR
	VALUES (1214,
	1188,
	'column',
	1,
	13);
INSERT INTO V_INT
	VALUES (1214,
	1,
	296);
INSERT INTO V_LOC
	VALUES (1252,
	40,
	10,
	15,
	1214);
INSERT INTO V_LOC
	VALUES (1253,
	43,
	14,
	19,
	1214);
INSERT INTO V_LOC
	VALUES (1254,
	47,
	26,
	31,
	1214);
INSERT INTO V_VAR
	VALUES (1216,
	1188,
	'boxes',
	1,
	14);
INSERT INTO V_INS
	VALUES (1216,
	310);
INSERT INTO V_LOC
	VALUES (1255,
	49,
	13,
	17,
	1216);
INSERT INTO V_LOC
	VALUES (1256,
	50,
	17,
	21,
	1216);
INSERT INTO V_VAR
	VALUES (1218,
	1188,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (1218,
	1,
	310);
INSERT INTO V_LOC
	VALUES (1257,
	50,
	10,
	12,
	1218);
INSERT INTO V_LOC
	VALUES (1258,
	53,
	14,
	16,
	1218);
INSERT INTO V_LOC
	VALUES (1259,
	58,
	26,
	28,
	1218);
INSERT INTO ACT_BLK
	VALUES (1193,
	1,
	0,
	0,
	'',
	'',
	'',
	8,
	3,
	6,
	41,
	0,
	0,
	7,
	35,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1260,
	1193,
	1261,
	5,
	3,
	'cleanup line: 5');
INSERT INTO ACT_SEL
	VALUES (1260,
	1262,
	1,
	'one',
	1263);
INSERT INTO ACT_SR
	VALUES (1260);
INSERT INTO ACT_LNK
	VALUES (1264,
	'',
	1260,
	383,
	0,
	2,
	168,
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1261,
	1193,
	1265,
	6,
	3,
	'cleanup line: 6');
INSERT INTO ACT_SEL
	VALUES (1261,
	1266,
	1,
	'one',
	1267);
INSERT INTO ACT_SR
	VALUES (1261);
INSERT INTO ACT_LNK
	VALUES (1268,
	'',
	1261,
	383,
	0,
	2,
	150,
	6,
	41,
	6,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1265,
	1193,
	1269,
	7,
	3,
	'cleanup line: 7');
INSERT INTO ACT_URU
	VALUES (1265,
	1262,
	1266,
	1194,
	'',
	383,
	7,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1269,
	1193,
	0,
	8,
	3,
	'cleanup line: 8');
INSERT INTO ACT_DEL
	VALUES (1269,
	1194);
INSERT INTO V_VAL
	VALUES (1263,
	0,
	0,
	5,
	30,
	37,
	0,
	0,
	0,
	0,
	13,
	1193);
INSERT INTO V_IRF
	VALUES (1263,
	1194);
INSERT INTO V_VAL
	VALUES (1267,
	0,
	0,
	6,
	31,
	38,
	0,
	0,
	0,
	0,
	13,
	1193);
INSERT INTO V_IRF
	VALUES (1267,
	1194);
INSERT INTO V_VAR
	VALUES (1262,
	1193,
	'cell',
	1,
	13);
INSERT INTO V_INT
	VALUES (1262,
	0,
	168);
INSERT INTO V_LOC
	VALUES (1270,
	5,
	14,
	17,
	1262);
INSERT INTO V_LOC
	VALUES (1271,
	7,
	12,
	15,
	1262);
INSERT INTO V_VAR
	VALUES (1266,
	1193,
	'digit',
	1,
	13);
INSERT INTO V_INT
	VALUES (1266,
	0,
	150);
INSERT INTO V_LOC
	VALUES (1272,
	6,
	14,
	18,
	1266);
INSERT INTO V_LOC
	VALUES (1273,
	7,
	22,
	26,
	1266);
INSERT INTO ACT_BLK
	VALUES (1198,
	1,
	0,
	0,
	'',
	'',
	'',
	15,
	3,
	14,
	37,
	0,
	0,
	14,
	43,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1274,
	1198,
	1275,
	14,
	3,
	'cleanup line: 14');
INSERT INTO ACT_SEL
	VALUES (1274,
	1276,
	1,
	'one',
	1277);
INSERT INTO ACT_SR
	VALUES (1274);
INSERT INTO ACT_LNK
	VALUES (1278,
	'',
	1274,
	357,
	0,
	2,
	150,
	14,
	37,
	14,
	43,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1275,
	1198,
	0,
	15,
	3,
	'cleanup line: 15');
INSERT INTO ACT_IF
	VALUES (1275,
	1279,
	1280,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1277,
	0,
	0,
	14,
	31,
	34,
	0,
	0,
	0,
	0,
	13,
	1198);
INSERT INTO V_IRF
	VALUES (1277,
	1199);
INSERT INTO V_VAL
	VALUES (1281,
	0,
	0,
	15,
	18,
	22,
	0,
	0,
	0,
	0,
	13,
	1198);
INSERT INTO V_IRF
	VALUES (1281,
	1276);
INSERT INTO V_VAL
	VALUES (1280,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1198);
INSERT INTO V_UNY
	VALUES (1280,
	1281,
	'not_empty');
INSERT INTO V_VAR
	VALUES (1276,
	1198,
	'digit',
	1,
	13);
INSERT INTO V_INT
	VALUES (1276,
	0,
	150);
INSERT INTO V_LOC
	VALUES (1282,
	14,
	14,
	18,
	1276);
INSERT INTO V_LOC
	VALUES (1283,
	16,
	24,
	28,
	1276);
INSERT INTO ACT_BLK
	VALUES (1279,
	0,
	0,
	0,
	'',
	'',
	'',
	16,
	5,
	0,
	0,
	0,
	0,
	16,
	37,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1284,
	1279,
	0,
	16,
	5,
	'cleanup line: 16');
INSERT INTO ACT_UNR
	VALUES (1284,
	1199,
	1276,
	'',
	357,
	16,
	37,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (1203,
	0,
	0,
	0,
	'',
	'',
	'',
	23,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1285,
	1203,
	0,
	23,
	3,
	'cleanup line: 23');
INSERT INTO ACT_DEL
	VALUES (1285,
	1204);
INSERT INTO ACT_BLK
	VALUES (1208,
	1,
	0,
	0,
	'',
	'',
	'',
	37,
	3,
	35,
	39,
	0,
	0,
	35,
	48,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1286,
	1208,
	1287,
	31,
	3,
	'cleanup line: 31');
INSERT INTO ACT_SEL
	VALUES (1286,
	1196,
	0,
	'many',
	1288);
INSERT INTO ACT_SR
	VALUES (1286);
INSERT INTO ACT_LNK
	VALUES (1289,
	'',
	1286,
	359,
	0,
	3,
	168,
	31,
	37,
	31,
	42,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1287,
	1208,
	1290,
	32,
	3,
	'cleanup line: 32');
INSERT INTO ACT_FOR
	VALUES (1287,
	1291,
	0,
	1199,
	1196,
	168);
INSERT INTO ACT_SMT
	VALUES (1290,
	1208,
	1292,
	35,
	3,
	'cleanup line: 35');
INSERT INTO ACT_SEL
	VALUES (1290,
	1293,
	1,
	'one',
	1294);
INSERT INTO ACT_SR
	VALUES (1290);
INSERT INTO ACT_LNK
	VALUES (1295,
	'',
	1290,
	286,
	0,
	2,
	109,
	35,
	39,
	35,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1292,
	1208,
	1296,
	36,
	3,
	'cleanup line: 36');
INSERT INTO ACT_DEL
	VALUES (1292,
	1293);
INSERT INTO ACT_SMT
	VALUES (1296,
	1208,
	0,
	37,
	3,
	'cleanup line: 37');
INSERT INTO ACT_DEL
	VALUES (1296,
	1209);
INSERT INTO V_VAL
	VALUES (1288,
	0,
	0,
	31,
	32,
	34,
	0,
	0,
	0,
	0,
	13,
	1208);
INSERT INTO V_IRF
	VALUES (1288,
	1209);
INSERT INTO V_VAL
	VALUES (1294,
	0,
	0,
	35,
	34,
	36,
	0,
	0,
	0,
	0,
	13,
	1208);
INSERT INTO V_IRF
	VALUES (1294,
	1209);
INSERT INTO V_VAR
	VALUES (1293,
	1208,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (1293,
	0,
	109);
INSERT INTO V_LOC
	VALUES (1297,
	35,
	14,
	21,
	1293);
INSERT INTO V_LOC
	VALUES (1298,
	36,
	26,
	33,
	1293);
INSERT INTO ACT_BLK
	VALUES (1291,
	0,
	0,
	0,
	'',
	'',
	'',
	33,
	5,
	0,
	0,
	0,
	0,
	33,
	35,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1299,
	1291,
	0,
	33,
	5,
	'cleanup line: 33');
INSERT INTO ACT_UNR
	VALUES (1299,
	1209,
	1199,
	'',
	359,
	33,
	35,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (1213,
	1,
	0,
	0,
	'',
	'',
	'',
	47,
	3,
	45,
	42,
	0,
	0,
	45,
	51,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1300,
	1213,
	1301,
	41,
	3,
	'cleanup line: 41');
INSERT INTO ACT_SEL
	VALUES (1300,
	1196,
	0,
	'many',
	1302);
INSERT INTO ACT_SR
	VALUES (1300);
INSERT INTO ACT_LNK
	VALUES (1303,
	'',
	1300,
	361,
	0,
	3,
	168,
	41,
	40,
	41,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1301,
	1213,
	1304,
	42,
	3,
	'cleanup line: 42');
INSERT INTO ACT_FOR
	VALUES (1301,
	1305,
	0,
	1199,
	1196,
	168);
INSERT INTO ACT_SMT
	VALUES (1304,
	1213,
	1306,
	45,
	3,
	'cleanup line: 45');
INSERT INTO ACT_SEL
	VALUES (1304,
	1307,
	1,
	'one',
	1308);
INSERT INTO ACT_SR
	VALUES (1304);
INSERT INTO ACT_LNK
	VALUES (1309,
	'',
	1304,
	286,
	0,
	2,
	109,
	45,
	42,
	45,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1306,
	1213,
	1310,
	46,
	3,
	'cleanup line: 46');
INSERT INTO ACT_DEL
	VALUES (1306,
	1307);
INSERT INTO ACT_SMT
	VALUES (1310,
	1213,
	0,
	47,
	3,
	'cleanup line: 47');
INSERT INTO ACT_DEL
	VALUES (1310,
	1214);
INSERT INTO V_VAL
	VALUES (1302,
	0,
	0,
	41,
	32,
	37,
	0,
	0,
	0,
	0,
	13,
	1213);
INSERT INTO V_IRF
	VALUES (1302,
	1214);
INSERT INTO V_VAL
	VALUES (1308,
	0,
	0,
	45,
	34,
	39,
	0,
	0,
	0,
	0,
	13,
	1213);
INSERT INTO V_IRF
	VALUES (1308,
	1214);
INSERT INTO V_VAR
	VALUES (1307,
	1213,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (1307,
	0,
	109);
INSERT INTO V_LOC
	VALUES (1311,
	45,
	14,
	21,
	1307);
INSERT INTO V_LOC
	VALUES (1312,
	46,
	26,
	33,
	1307);
INSERT INTO ACT_BLK
	VALUES (1305,
	0,
	0,
	0,
	'',
	'',
	'',
	43,
	5,
	0,
	0,
	0,
	0,
	43,
	38,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1313,
	1305,
	0,
	43,
	5,
	'cleanup line: 43');
INSERT INTO ACT_UNR
	VALUES (1313,
	1214,
	1199,
	'',
	361,
	43,
	38,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (1217,
	1,
	0,
	0,
	'',
	'',
	'',
	58,
	3,
	56,
	39,
	0,
	0,
	56,
	48,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1314,
	1217,
	1315,
	51,
	3,
	'cleanup line: 51');
INSERT INTO ACT_SEL
	VALUES (1314,
	1196,
	0,
	'many',
	1316);
INSERT INTO ACT_SR
	VALUES (1314);
INSERT INTO ACT_LNK
	VALUES (1317,
	'',
	1314,
	521,
	0,
	3,
	168,
	51,
	37,
	51,
	42,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1315,
	1217,
	1318,
	52,
	3,
	'cleanup line: 52');
INSERT INTO ACT_FOR
	VALUES (1315,
	1319,
	0,
	1199,
	1196,
	168);
INSERT INTO ACT_SMT
	VALUES (1318,
	1217,
	1320,
	56,
	3,
	'cleanup line: 56');
INSERT INTO ACT_SEL
	VALUES (1318,
	1321,
	1,
	'one',
	1322);
INSERT INTO ACT_SR
	VALUES (1318);
INSERT INTO ACT_LNK
	VALUES (1323,
	'',
	1318,
	286,
	0,
	2,
	109,
	56,
	39,
	56,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1320,
	1217,
	1324,
	57,
	3,
	'cleanup line: 57');
INSERT INTO ACT_DEL
	VALUES (1320,
	1321);
INSERT INTO ACT_SMT
	VALUES (1324,
	1217,
	0,
	58,
	3,
	'cleanup line: 58');
INSERT INTO ACT_DEL
	VALUES (1324,
	1218);
INSERT INTO V_VAL
	VALUES (1316,
	0,
	0,
	51,
	32,
	34,
	0,
	0,
	0,
	0,
	13,
	1217);
INSERT INTO V_IRF
	VALUES (1316,
	1218);
INSERT INTO V_VAL
	VALUES (1322,
	0,
	0,
	56,
	34,
	36,
	0,
	0,
	0,
	0,
	13,
	1217);
INSERT INTO V_IRF
	VALUES (1322,
	1218);
INSERT INTO V_VAR
	VALUES (1321,
	1217,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (1321,
	0,
	109);
INSERT INTO V_LOC
	VALUES (1325,
	56,
	14,
	21,
	1321);
INSERT INTO V_LOC
	VALUES (1326,
	57,
	26,
	33,
	1321);
INSERT INTO ACT_BLK
	VALUES (1319,
	0,
	0,
	0,
	'',
	'',
	'',
	54,
	5,
	0,
	0,
	0,
	0,
	53,
	35,
	0,
	0,
	0,
	0,
	0,
	1187,
	0);
INSERT INTO ACT_SMT
	VALUES (1327,
	1319,
	1328,
	53,
	5,
	'cleanup line: 53');
INSERT INTO ACT_UNR
	VALUES (1327,
	1218,
	1199,
	'',
	521,
	53,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1328,
	1319,
	0,
	54,
	5,
	'cleanup line: 54');
INSERT INTO ACT_DEL
	VALUES (1328,
	1199);
INSERT INTO S_FIP
	VALUES (102,
	1329);
INSERT INTO S_SYNC
	VALUES (1329,
	2,
	'xit',
	'',
	'::cleanup();
ARCH::shutdown();',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (1330,
	1329);
INSERT INTO ACT_ACT
	VALUES (1330,
	'function',
	0,
	1331,
	0,
	0,
	'xit',
	0);
INSERT INTO ACT_BLK
	VALUES (1331,
	0,
	0,
	0,
	'ARCH',
	'',
	'',
	2,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1330,
	0);
INSERT INTO ACT_SMT
	VALUES (1332,
	1331,
	1333,
	1,
	1,
	'xit line: 1');
INSERT INTO ACT_FNC
	VALUES (1332,
	1186,
	1,
	3);
INSERT INTO ACT_SMT
	VALUES (1333,
	1331,
	0,
	2,
	1,
	'xit line: 2');
INSERT INTO ACT_BRG
	VALUES (1333,
	61,
	2,
	7,
	2,
	1);
INSERT INTO S_FIP
	VALUES (102,
	1334);
INSERT INTO S_SYNC
	VALUES (1334,
	2,
	'cort',
	'',
	'',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (1335,
	1334);
INSERT INTO ACT_ACT
	VALUES (1335,
	'function',
	0,
	1336,
	0,
	0,
	'cort',
	0);
INSERT INTO ACT_BLK
	VALUES (1336,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1335,
	0);
INSERT INTO S_FIP
	VALUES (102,
	1337);
INSERT INTO S_SYNC
	VALUES (1337,
	2,
	'solve_concurrently',
	'',
	'score = CELL::score();
::display();

select any row from instances of ROW;
generate ROW1:update() to row;',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (1338,
	1337);
INSERT INTO ACT_ACT
	VALUES (1338,
	'function',
	0,
	1339,
	0,
	0,
	'solve_concurrently',
	0);
INSERT INTO ACT_BLK
	VALUES (1339,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	5,
	1,
	4,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1338,
	0);
INSERT INTO ACT_SMT
	VALUES (1340,
	1339,
	1341,
	1,
	1,
	'solve_concurrently line: 1');
INSERT INTO ACT_AI
	VALUES (1340,
	1342,
	1343,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1341,
	1339,
	1344,
	2,
	1,
	'solve_concurrently line: 2');
INSERT INTO ACT_FNC
	VALUES (1341,
	733,
	2,
	3);
INSERT INTO ACT_SMT
	VALUES (1344,
	1339,
	1345,
	4,
	1,
	'solve_concurrently line: 4');
INSERT INTO ACT_FIO
	VALUES (1344,
	1346,
	1,
	'any',
	162,
	4,
	34);
INSERT INTO ACT_SMT
	VALUES (1345,
	1339,
	0,
	5,
	1,
	'solve_concurrently line: 5');
INSERT INTO E_ESS
	VALUES (1345,
	1,
	0,
	5,
	10,
	5,
	15,
	4,
	34,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1345);
INSERT INTO E_GSME
	VALUES (1345,
	1347,
	1348);
INSERT INTO E_GEN
	VALUES (1345,
	1346);
INSERT INTO V_VAL
	VALUES (1343,
	1,
	1,
	1,
	1,
	5,
	0,
	0,
	0,
	0,
	7,
	1339);
INSERT INTO V_TVL
	VALUES (1343,
	1349);
INSERT INTO V_VAL
	VALUES (1342,
	0,
	0,
	1,
	15,
	-1,
	0,
	0,
	0,
	0,
	7,
	1339);
INSERT INTO V_TRV
	VALUES (1342,
	813,
	0,
	1,
	1,
	9);
INSERT INTO V_VAR
	VALUES (1349,
	1339,
	'score',
	1,
	7);
INSERT INTO V_TRN
	VALUES (1349,
	0,
	'');
INSERT INTO V_LOC
	VALUES (1350,
	1,
	1,
	5,
	1349);
INSERT INTO V_VAR
	VALUES (1346,
	1339,
	'row',
	1,
	13);
INSERT INTO V_INT
	VALUES (1346,
	0,
	162);
INSERT INTO V_LOC
	VALUES (1351,
	4,
	12,
	14,
	1346);
INSERT INTO V_LOC
	VALUES (1352,
	5,
	27,
	29,
	1346);
INSERT INTO S_FIP
	VALUES (102,
	1353);
INSERT INTO S_SYNC
	VALUES (1353,
	2,
	'check',
	'',
	'score = CELL::score();
if ( 81 == score )
  LOG::LogSuccess( message:"solved the puzzle" );
else
  LOG::LogFailure( message:"failed to solved the puzzle" );
end if;
::display();',
	5,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (1354,
	1353);
INSERT INTO ACT_ACT
	VALUES (1354,
	'function',
	0,
	1355,
	0,
	0,
	'check',
	0);
INSERT INTO ACT_BLK
	VALUES (1355,
	0,
	0,
	0,
	'CELL',
	'',
	'',
	7,
	1,
	1,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1354,
	0);
INSERT INTO ACT_SMT
	VALUES (1356,
	1355,
	1357,
	1,
	1,
	'check line: 1');
INSERT INTO ACT_AI
	VALUES (1356,
	1358,
	1359,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1357,
	1355,
	1360,
	2,
	1,
	'check line: 2');
INSERT INTO ACT_IF
	VALUES (1357,
	1361,
	1362,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1363,
	1355,
	0,
	4,
	1,
	'check line: 4');
INSERT INTO ACT_E
	VALUES (1363,
	1364,
	1357);
INSERT INTO ACT_SMT
	VALUES (1360,
	1355,
	0,
	7,
	1,
	'check line: 7');
INSERT INTO ACT_FNC
	VALUES (1360,
	733,
	7,
	3);
INSERT INTO V_VAL
	VALUES (1359,
	1,
	1,
	1,
	1,
	5,
	0,
	0,
	0,
	0,
	7,
	1355);
INSERT INTO V_TVL
	VALUES (1359,
	1365);
INSERT INTO V_VAL
	VALUES (1358,
	0,
	0,
	1,
	15,
	-1,
	0,
	0,
	0,
	0,
	7,
	1355);
INSERT INTO V_TRV
	VALUES (1358,
	813,
	0,
	1,
	1,
	9);
INSERT INTO V_VAL
	VALUES (1366,
	0,
	0,
	2,
	6,
	7,
	0,
	0,
	0,
	0,
	7,
	1355);
INSERT INTO V_LIN
	VALUES (1366,
	'81');
INSERT INTO V_VAL
	VALUES (1362,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1355);
INSERT INTO V_BIN
	VALUES (1362,
	1367,
	1366,
	'==');
INSERT INTO V_VAL
	VALUES (1367,
	0,
	0,
	2,
	12,
	16,
	0,
	0,
	0,
	0,
	7,
	1355);
INSERT INTO V_TVL
	VALUES (1367,
	1365);
INSERT INTO V_VAR
	VALUES (1365,
	1355,
	'score',
	1,
	7);
INSERT INTO V_TRN
	VALUES (1365,
	0,
	'');
INSERT INTO V_LOC
	VALUES (1368,
	1,
	1,
	5,
	1365);
INSERT INTO V_LOC
	VALUES (1369,
	2,
	12,
	16,
	1365);
INSERT INTO ACT_BLK
	VALUES (1361,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	3,
	3,
	3,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1354,
	0);
INSERT INTO ACT_SMT
	VALUES (1370,
	1361,
	0,
	3,
	3,
	'check line: 3');
INSERT INTO ACT_BRG
	VALUES (1370,
	73,
	3,
	8,
	3,
	3);
INSERT INTO V_VAL
	VALUES (1371,
	0,
	0,
	3,
	28,
	45,
	0,
	0,
	0,
	0,
	9,
	1361);
INSERT INTO V_LST
	VALUES (1371,
	'solved the puzzle');
INSERT INTO V_PAR
	VALUES (1371,
	1370,
	0,
	'message',
	0,
	3,
	20);
INSERT INTO ACT_BLK
	VALUES (1364,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	5,
	3,
	5,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1354,
	0);
INSERT INTO ACT_SMT
	VALUES (1372,
	1364,
	0,
	5,
	3,
	'check line: 5');
INSERT INTO ACT_BRG
	VALUES (1372,
	65,
	5,
	8,
	5,
	3);
INSERT INTO V_VAL
	VALUES (1373,
	0,
	0,
	5,
	28,
	55,
	0,
	0,
	0,
	0,
	9,
	1364);
INSERT INTO V_LST
	VALUES (1373,
	'failed to solved the puzzle');
INSERT INTO V_PAR
	VALUES (1373,
	1372,
	0,
	'message',
	0,
	5,
	20);
INSERT INTO S_SID
	VALUES (2,
	1374);
INSERT INTO S_SS
	VALUES (1374,
	'sudoku',
	'',
	'',
	0,
	2,
	0);
INSERT INTO O_OBJ
	VALUES (310,
	'box',
	4,
	'BOX',
	'',
	1374);
INSERT INTO O_TFR
	VALUES (1375,
	310,
	'prune',
	'',
	7,
	1,
	'// Cut off eligible digits that match any answer digit for this sequence.

temperature = 0;
select many answerdigits related by self->CELL[R4]->DIGIT[R9] where ( selected.value != 0 );
select many eligibles related by self->CELL[R4]->ELIGIBLE[R8];
for each eligible in eligibles
  for each answerdigit in answerdigits
    if ( eligible.digit_value == answerdigit.value )
      select one opencell related by eligible->CELL[R8];
      if ( opencell.answer_value != eligible.digit_value )
        unrelate answerdigit from opencell across R8 using eligible;
        delete object instance eligible;
        // generate CELL1:eliminate( digit:answerdigit.value ) to opencell;
      end if;
      temperature = 1;
      break;
    end if;
  end for;
end for;
  
select many opencells related by self->CELL[R4]
  where ( selected.answer_value == 0 );
if ( empty opencells )
  temperature = 100;
end if;
for each opencell in opencells
  // Notice if we have the answer now.
  select many eligibles related by opencell->ELIGIBLE[R8];
  c = cardinality eligibles;
  if ( 1 == c )
    select any answer related by opencell->ELIGIBLE[R8];
    opencell.answer( answer_digit:answer.digit_value );
    // generate CELL2:answer( digit:answer.digit_value ) to opencell;
    temperature = 1;
  end if;
end for;

return temperature;
',
	1,
	'',
	1376);
INSERT INTO ACT_OPB
	VALUES (1377,
	1375);
INSERT INTO ACT_ACT
	VALUES (1377,
	'operation',
	0,
	1378,
	0,
	0,
	'box::prune',
	0);
INSERT INTO ACT_BLK
	VALUES (1378,
	1,
	0,
	1,
	'',
	'',
	'',
	38,
	1,
	21,
	40,
	0,
	0,
	21,
	45,
	0,
	0,
	0,
	0,
	0,
	1377,
	0);
INSERT INTO ACT_SMT
	VALUES (1379,
	1378,
	1380,
	3,
	1,
	'box::prune line: 3');
INSERT INTO ACT_AI
	VALUES (1379,
	1381,
	1382,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1380,
	1378,
	1383,
	4,
	1,
	'box::prune line: 4');
INSERT INTO ACT_SEL
	VALUES (1380,
	1384,
	1,
	'many',
	1385);
INSERT INTO ACT_SRW
	VALUES (1380,
	1386);
INSERT INTO ACT_LNK
	VALUES (1387,
	'',
	1380,
	521,
	1388,
	3,
	168,
	4,
	43,
	4,
	48,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (1388,
	'',
	0,
	357,
	0,
	2,
	150,
	4,
	53,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1383,
	1378,
	1389,
	5,
	1,
	'box::prune line: 5');
INSERT INTO ACT_SEL
	VALUES (1383,
	1390,
	1,
	'many',
	1391);
INSERT INTO ACT_SR
	VALUES (1383);
INSERT INTO ACT_LNK
	VALUES (1392,
	'',
	1383,
	521,
	1393,
	3,
	168,
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (1393,
	'',
	0,
	383,
	0,
	3,
	382,
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1389,
	1378,
	1394,
	6,
	1,
	'box::prune line: 6');
INSERT INTO ACT_FOR
	VALUES (1389,
	1395,
	1,
	1396,
	1390,
	382);
INSERT INTO ACT_SMT
	VALUES (1394,
	1378,
	1397,
	21,
	1,
	'box::prune line: 21');
INSERT INTO ACT_SEL
	VALUES (1394,
	1398,
	1,
	'many',
	1399);
INSERT INTO ACT_SRW
	VALUES (1394,
	1400);
INSERT INTO ACT_LNK
	VALUES (1401,
	'',
	1394,
	521,
	0,
	3,
	168,
	21,
	40,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1397,
	1378,
	1402,
	23,
	1,
	'box::prune line: 23');
INSERT INTO ACT_IF
	VALUES (1397,
	1403,
	1404,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1402,
	1378,
	1405,
	26,
	1,
	'box::prune line: 26');
INSERT INTO ACT_FOR
	VALUES (1402,
	1406,
	1,
	1407,
	1398,
	168);
INSERT INTO ACT_SMT
	VALUES (1405,
	1378,
	0,
	38,
	1,
	'box::prune line: 38');
INSERT INTO ACT_RET
	VALUES (1405,
	1408);
INSERT INTO V_VAL
	VALUES (1382,
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	7,
	1378);
INSERT INTO V_TVL
	VALUES (1382,
	1409);
INSERT INTO V_VAL
	VALUES (1381,
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	7,
	1378);
INSERT INTO V_LIN
	VALUES (1381,
	'0');
INSERT INTO V_VAL
	VALUES (1385,
	0,
	0,
	4,
	37,
	40,
	0,
	0,
	0,
	0,
	13,
	1378);
INSERT INTO V_IRF
	VALUES (1385,
	1410);
INSERT INTO V_VAL
	VALUES (1411,
	0,
	0,
	4,
	71,
	-1,
	0,
	0,
	0,
	0,
	13,
	1378);
INSERT INTO V_SLR
	VALUES (1411,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1412,
	0,
	0,
	4,
	80,
	84,
	0,
	0,
	0,
	0,
	7,
	1378);
INSERT INTO V_AVL
	VALUES (1412,
	1411,
	150,
	182);
INSERT INTO V_VAL
	VALUES (1386,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1378);
INSERT INTO V_BIN
	VALUES (1386,
	1413,
	1412,
	'!=');
INSERT INTO V_VAL
	VALUES (1413,
	0,
	0,
	4,
	89,
	89,
	0,
	0,
	0,
	0,
	7,
	1378);
INSERT INTO V_LIN
	VALUES (1413,
	'0');
INSERT INTO V_VAL
	VALUES (1391,
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	1378);
INSERT INTO V_IRF
	VALUES (1391,
	1410);
INSERT INTO V_VAL
	VALUES (1399,
	0,
	0,
	21,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	1378);
INSERT INTO V_IRF
	VALUES (1399,
	1410);
INSERT INTO V_VAL
	VALUES (1414,
	0,
	0,
	22,
	11,
	-1,
	0,
	0,
	0,
	0,
	13,
	1378);
INSERT INTO V_SLR
	VALUES (1414,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1415,
	0,
	0,
	22,
	20,
	31,
	0,
	0,
	0,
	0,
	7,
	1378);
INSERT INTO V_AVL
	VALUES (1415,
	1414,
	168,
	788);
INSERT INTO V_VAL
	VALUES (1400,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1378);
INSERT INTO V_BIN
	VALUES (1400,
	1416,
	1415,
	'==');
INSERT INTO V_VAL
	VALUES (1416,
	0,
	0,
	22,
	36,
	36,
	0,
	0,
	0,
	0,
	7,
	1378);
INSERT INTO V_LIN
	VALUES (1416,
	'0');
INSERT INTO V_VAL
	VALUES (1417,
	0,
	0,
	23,
	12,
	20,
	0,
	0,
	0,
	0,
	14,
	1378);
INSERT INTO V_ISR
	VALUES (1417,
	1398);
INSERT INTO V_VAL
	VALUES (1404,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1378);
INSERT INTO V_UNY
	VALUES (1404,
	1417,
	'empty');
INSERT INTO V_VAL
	VALUES (1408,
	0,
	0,
	38,
	8,
	18,
	0,
	0,
	0,
	0,
	7,
	1378);
INSERT INTO V_TVL
	VALUES (1408,
	1409);
INSERT INTO V_VAR
	VALUES (1409,
	1378,
	'temperature',
	1,
	7);
INSERT INTO V_TRN
	VALUES (1409,
	0,
	'');
INSERT INTO V_LOC
	VALUES (1418,
	3,
	1,
	11,
	1409);
INSERT INTO V_LOC
	VALUES (1419,
	15,
	7,
	17,
	1409);
INSERT INTO V_LOC
	VALUES (1420,
	24,
	3,
	13,
	1409);
INSERT INTO V_LOC
	VALUES (1421,
	34,
	5,
	15,
	1409);
INSERT INTO V_LOC
	VALUES (1422,
	38,
	8,
	18,
	1409);
INSERT INTO V_VAR
	VALUES (1384,
	1378,
	'answerdigits',
	1,
	14);
INSERT INTO V_INS
	VALUES (1384,
	150);
INSERT INTO V_LOC
	VALUES (1423,
	4,
	13,
	24,
	1384);
INSERT INTO V_LOC
	VALUES (1424,
	7,
	27,
	38,
	1384);
INSERT INTO V_VAR
	VALUES (1410,
	1378,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (1410,
	0,
	310);
INSERT INTO V_VAR
	VALUES (1390,
	1378,
	'eligibles',
	1,
	14);
INSERT INTO V_INS
	VALUES (1390,
	382);
INSERT INTO V_LOC
	VALUES (1425,
	5,
	13,
	21,
	1390);
INSERT INTO V_LOC
	VALUES (1426,
	6,
	22,
	30,
	1390);
INSERT INTO V_LOC
	VALUES (1427,
	28,
	15,
	23,
	1390);
INSERT INTO V_VAR
	VALUES (1396,
	1378,
	'eligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (1396,
	1,
	382);
INSERT INTO V_LOC
	VALUES (1428,
	6,
	10,
	17,
	1396);
INSERT INTO V_LOC
	VALUES (1429,
	8,
	10,
	17,
	1396);
INSERT INTO V_LOC
	VALUES (1430,
	10,
	37,
	44,
	1396);
INSERT INTO V_LOC
	VALUES (1431,
	11,
	60,
	67,
	1396);
INSERT INTO V_LOC
	VALUES (1432,
	12,
	32,
	39,
	1396);
INSERT INTO V_VAR
	VALUES (1398,
	1378,
	'opencells',
	1,
	14);
INSERT INTO V_INS
	VALUES (1398,
	168);
INSERT INTO V_LOC
	VALUES (1433,
	21,
	13,
	21,
	1398);
INSERT INTO V_LOC
	VALUES (1434,
	26,
	22,
	30,
	1398);
INSERT INTO V_VAR
	VALUES (1407,
	1378,
	'opencell',
	1,
	13);
INSERT INTO V_INT
	VALUES (1407,
	1,
	168);
INSERT INTO V_LOC
	VALUES (1435,
	26,
	10,
	17,
	1407);
INSERT INTO V_LOC
	VALUES (1436,
	32,
	5,
	12,
	1407);
INSERT INTO ACT_BLK
	VALUES (1395,
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1377,
	0);
INSERT INTO ACT_SMT
	VALUES (1437,
	1395,
	0,
	7,
	3,
	'box::prune line: 7');
INSERT INTO ACT_FOR
	VALUES (1437,
	1438,
	1,
	1439,
	1384,
	150);
INSERT INTO V_VAR
	VALUES (1439,
	1395,
	'answerdigit',
	1,
	13);
INSERT INTO V_INT
	VALUES (1439,
	1,
	150);
INSERT INTO V_LOC
	VALUES (1440,
	7,
	12,
	22,
	1439);
INSERT INTO V_LOC
	VALUES (1441,
	8,
	34,
	44,
	1439);
INSERT INTO V_LOC
	VALUES (1442,
	11,
	18,
	28,
	1439);
INSERT INTO ACT_BLK
	VALUES (1438,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1377,
	0);
INSERT INTO ACT_SMT
	VALUES (1443,
	1438,
	0,
	8,
	5,
	'box::prune line: 8');
INSERT INTO ACT_IF
	VALUES (1443,
	1444,
	1445,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1446,
	0,
	0,
	8,
	10,
	17,
	0,
	0,
	0,
	0,
	13,
	1438);
INSERT INTO V_IRF
	VALUES (1446,
	1396);
INSERT INTO V_VAL
	VALUES (1447,
	0,
	0,
	8,
	19,
	29,
	0,
	0,
	0,
	0,
	7,
	1438);
INSERT INTO V_AVL
	VALUES (1447,
	1446,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (1445,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1438);
INSERT INTO V_BIN
	VALUES (1445,
	1449,
	1447,
	'==');
INSERT INTO V_VAL
	VALUES (1450,
	0,
	0,
	8,
	34,
	44,
	0,
	0,
	0,
	0,
	13,
	1438);
INSERT INTO V_IRF
	VALUES (1450,
	1439);
INSERT INTO V_VAL
	VALUES (1449,
	0,
	0,
	8,
	46,
	50,
	0,
	0,
	0,
	0,
	7,
	1438);
INSERT INTO V_AVL
	VALUES (1449,
	1450,
	150,
	182);
INSERT INTO ACT_BLK
	VALUES (1444,
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	7,
	9,
	48,
	0,
	0,
	9,
	53,
	0,
	0,
	0,
	0,
	0,
	1377,
	0);
INSERT INTO ACT_SMT
	VALUES (1451,
	1444,
	1452,
	9,
	7,
	'box::prune line: 9');
INSERT INTO ACT_SEL
	VALUES (1451,
	1453,
	1,
	'one',
	1454);
INSERT INTO ACT_SR
	VALUES (1451);
INSERT INTO ACT_LNK
	VALUES (1455,
	'',
	1451,
	383,
	0,
	2,
	168,
	9,
	48,
	9,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1452,
	1444,
	1456,
	10,
	7,
	'box::prune line: 10');
INSERT INTO ACT_IF
	VALUES (1452,
	1457,
	1458,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1456,
	1444,
	1459,
	15,
	7,
	'box::prune line: 15');
INSERT INTO ACT_AI
	VALUES (1456,
	1460,
	1461,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1459,
	1444,
	0,
	16,
	7,
	'box::prune line: 16');
INSERT INTO ACT_BRK
	VALUES (1459);
INSERT INTO V_VAL
	VALUES (1454,
	0,
	0,
	9,
	38,
	45,
	0,
	0,
	0,
	0,
	13,
	1444);
INSERT INTO V_IRF
	VALUES (1454,
	1396);
INSERT INTO V_VAL
	VALUES (1462,
	0,
	0,
	10,
	12,
	19,
	0,
	0,
	0,
	0,
	13,
	1444);
INSERT INTO V_IRF
	VALUES (1462,
	1453);
INSERT INTO V_VAL
	VALUES (1463,
	0,
	0,
	10,
	21,
	32,
	0,
	0,
	0,
	0,
	7,
	1444);
INSERT INTO V_AVL
	VALUES (1463,
	1462,
	168,
	788);
INSERT INTO V_VAL
	VALUES (1458,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1444);
INSERT INTO V_BIN
	VALUES (1458,
	1464,
	1463,
	'!=');
INSERT INTO V_VAL
	VALUES (1465,
	0,
	0,
	10,
	37,
	44,
	0,
	0,
	0,
	0,
	13,
	1444);
INSERT INTO V_IRF
	VALUES (1465,
	1396);
INSERT INTO V_VAL
	VALUES (1464,
	0,
	0,
	10,
	46,
	56,
	0,
	0,
	0,
	0,
	7,
	1444);
INSERT INTO V_AVL
	VALUES (1464,
	1465,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (1461,
	1,
	0,
	15,
	7,
	17,
	0,
	0,
	0,
	0,
	7,
	1444);
INSERT INTO V_TVL
	VALUES (1461,
	1409);
INSERT INTO V_VAL
	VALUES (1460,
	0,
	0,
	15,
	21,
	21,
	0,
	0,
	0,
	0,
	7,
	1444);
INSERT INTO V_LIN
	VALUES (1460,
	'1');
INSERT INTO V_VAR
	VALUES (1453,
	1444,
	'opencell',
	1,
	13);
INSERT INTO V_INT
	VALUES (1453,
	0,
	168);
INSERT INTO V_LOC
	VALUES (1466,
	9,
	18,
	25,
	1453);
INSERT INTO V_LOC
	VALUES (1467,
	10,
	12,
	19,
	1453);
INSERT INTO V_LOC
	VALUES (1468,
	11,
	35,
	42,
	1453);
INSERT INTO ACT_BLK
	VALUES (1457,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	9,
	0,
	0,
	0,
	0,
	11,
	51,
	0,
	0,
	0,
	0,
	0,
	1377,
	0);
INSERT INTO ACT_SMT
	VALUES (1469,
	1457,
	1470,
	11,
	9,
	'box::prune line: 11');
INSERT INTO ACT_URU
	VALUES (1469,
	1439,
	1453,
	1396,
	'',
	383,
	11,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1470,
	1457,
	0,
	12,
	9,
	'box::prune line: 12');
INSERT INTO ACT_DEL
	VALUES (1470,
	1396);
INSERT INTO ACT_BLK
	VALUES (1403,
	0,
	0,
	0,
	'',
	'',
	'',
	24,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1377,
	0);
INSERT INTO ACT_SMT
	VALUES (1471,
	1403,
	0,
	24,
	3,
	'box::prune line: 24');
INSERT INTO ACT_AI
	VALUES (1471,
	1472,
	1473,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1473,
	1,
	0,
	24,
	3,
	13,
	0,
	0,
	0,
	0,
	7,
	1403);
INSERT INTO V_TVL
	VALUES (1473,
	1409);
INSERT INTO V_VAL
	VALUES (1472,
	0,
	0,
	24,
	17,
	19,
	0,
	0,
	0,
	0,
	7,
	1403);
INSERT INTO V_LIN
	VALUES (1472,
	'100');
INSERT INTO ACT_BLK
	VALUES (1406,
	1,
	0,
	0,
	'',
	'',
	'',
	30,
	3,
	28,
	46,
	0,
	0,
	28,
	55,
	0,
	0,
	0,
	0,
	0,
	1377,
	0);
INSERT INTO ACT_SMT
	VALUES (1474,
	1406,
	1475,
	28,
	3,
	'box::prune line: 28');
INSERT INTO ACT_SEL
	VALUES (1474,
	1390,
	0,
	'many',
	1476);
INSERT INTO ACT_SR
	VALUES (1474);
INSERT INTO ACT_LNK
	VALUES (1477,
	'',
	1474,
	383,
	0,
	3,
	382,
	28,
	46,
	28,
	55,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1475,
	1406,
	1478,
	29,
	3,
	'box::prune line: 29');
INSERT INTO ACT_AI
	VALUES (1475,
	1479,
	1480,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1478,
	1406,
	0,
	30,
	3,
	'box::prune line: 30');
INSERT INTO ACT_IF
	VALUES (1478,
	1481,
	1482,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1476,
	0,
	0,
	28,
	36,
	43,
	0,
	0,
	0,
	0,
	13,
	1406);
INSERT INTO V_IRF
	VALUES (1476,
	1407);
INSERT INTO V_VAL
	VALUES (1480,
	1,
	1,
	29,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	1406);
INSERT INTO V_TVL
	VALUES (1480,
	1483);
INSERT INTO V_VAL
	VALUES (1484,
	0,
	0,
	29,
	19,
	27,
	0,
	0,
	0,
	0,
	14,
	1406);
INSERT INTO V_ISR
	VALUES (1484,
	1390);
INSERT INTO V_VAL
	VALUES (1479,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	1406);
INSERT INTO V_UNY
	VALUES (1479,
	1484,
	'cardinality');
INSERT INTO V_VAL
	VALUES (1485,
	0,
	0,
	30,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	1406);
INSERT INTO V_LIN
	VALUES (1485,
	'1');
INSERT INTO V_VAL
	VALUES (1482,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1406);
INSERT INTO V_BIN
	VALUES (1482,
	1486,
	1485,
	'==');
INSERT INTO V_VAL
	VALUES (1486,
	0,
	0,
	30,
	13,
	13,
	0,
	0,
	0,
	0,
	7,
	1406);
INSERT INTO V_TVL
	VALUES (1486,
	1483);
INSERT INTO V_VAR
	VALUES (1483,
	1406,
	'c',
	1,
	7);
INSERT INTO V_TRN
	VALUES (1483,
	0,
	'');
INSERT INTO V_LOC
	VALUES (1487,
	29,
	3,
	3,
	1483);
INSERT INTO V_LOC
	VALUES (1488,
	30,
	13,
	13,
	1483);
INSERT INTO ACT_BLK
	VALUES (1481,
	1,
	0,
	0,
	'',
	'',
	'',
	34,
	5,
	31,
	44,
	0,
	0,
	31,
	53,
	0,
	0,
	0,
	0,
	0,
	1377,
	0);
INSERT INTO ACT_SMT
	VALUES (1489,
	1481,
	1490,
	31,
	5,
	'box::prune line: 31');
INSERT INTO ACT_SEL
	VALUES (1489,
	1491,
	1,
	'any',
	1492);
INSERT INTO ACT_SR
	VALUES (1489);
INSERT INTO ACT_LNK
	VALUES (1493,
	'',
	1489,
	383,
	0,
	3,
	382,
	31,
	44,
	31,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1490,
	1481,
	1494,
	32,
	5,
	'box::prune line: 32');
INSERT INTO ACT_TFM
	VALUES (1490,
	1495,
	1407,
	32,
	14,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1494,
	1481,
	0,
	34,
	5,
	'box::prune line: 34');
INSERT INTO ACT_AI
	VALUES (1494,
	1496,
	1497,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1492,
	0,
	0,
	31,
	34,
	41,
	0,
	0,
	0,
	0,
	13,
	1481);
INSERT INTO V_IRF
	VALUES (1492,
	1407);
INSERT INTO V_VAL
	VALUES (1498,
	0,
	0,
	32,
	35,
	40,
	0,
	0,
	0,
	0,
	13,
	1481);
INSERT INTO V_IRF
	VALUES (1498,
	1491);
INSERT INTO V_VAL
	VALUES (1499,
	0,
	0,
	32,
	42,
	52,
	0,
	0,
	0,
	0,
	7,
	1481);
INSERT INTO V_AVL
	VALUES (1499,
	1498,
	382,
	1448);
INSERT INTO V_PAR
	VALUES (1499,
	1490,
	0,
	'answer_digit',
	0,
	32,
	22);
INSERT INTO V_VAL
	VALUES (1497,
	1,
	0,
	34,
	5,
	15,
	0,
	0,
	0,
	0,
	7,
	1481);
INSERT INTO V_TVL
	VALUES (1497,
	1409);
INSERT INTO V_VAL
	VALUES (1496,
	0,
	0,
	34,
	19,
	19,
	0,
	0,
	0,
	0,
	7,
	1481);
INSERT INTO V_LIN
	VALUES (1496,
	'1');
INSERT INTO V_VAR
	VALUES (1491,
	1481,
	'answer',
	1,
	13);
INSERT INTO V_INT
	VALUES (1491,
	0,
	382);
INSERT INTO V_LOC
	VALUES (1500,
	31,
	16,
	21,
	1491);
INSERT INTO V_LOC
	VALUES (1501,
	32,
	35,
	40,
	1491);
INSERT INTO O_TFR
	VALUES (1376,
	310,
	'eliminate',
	'',
	7,
	1,
	'// Solve by selecting eligible digits.
// Notice if any eligible digit appears only once.

temperature = 0;
select many eligibles related by self->CELL[R4]->ELIGIBLE[R8];
c = cardinality eligibles;
if ( 9 == c )
  temperature = 100;
else
for each eligible in eligibles
  select many loners related by self->CELL[R4]->ELIGIBLE[R8]
    where ( selected.digit_value == eligible.digit_value );
  c = cardinality loners;
  if ( 1 == c )
    // This is an answer!
    select one cell related by eligible->CELL[R8];
    cell.answer( answer_digit:eligible.digit_value );
    // generate CELL2:answer( digit:eligible.digit_value ) to cell;
    temperature = 1;
    break;
  end if;
end for;
end if;
return temperature;',
	1,
	'',
	0);
INSERT INTO ACT_OPB
	VALUES (1502,
	1376);
INSERT INTO ACT_ACT
	VALUES (1502,
	'operation',
	0,
	1503,
	0,
	0,
	'box::eliminate',
	0);
INSERT INTO ACT_BLK
	VALUES (1503,
	1,
	0,
	0,
	'',
	'',
	'',
	24,
	1,
	5,
	50,
	0,
	0,
	5,
	59,
	0,
	0,
	0,
	0,
	0,
	1502,
	0);
INSERT INTO ACT_SMT
	VALUES (1504,
	1503,
	1505,
	4,
	1,
	'box::eliminate line: 4');
INSERT INTO ACT_AI
	VALUES (1504,
	1506,
	1507,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1505,
	1503,
	1508,
	5,
	1,
	'box::eliminate line: 5');
INSERT INTO ACT_SEL
	VALUES (1505,
	1509,
	1,
	'many',
	1510);
INSERT INTO ACT_SR
	VALUES (1505);
INSERT INTO ACT_LNK
	VALUES (1511,
	'',
	1505,
	521,
	1512,
	3,
	168,
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (1512,
	'',
	0,
	383,
	0,
	3,
	382,
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1508,
	1503,
	1513,
	6,
	1,
	'box::eliminate line: 6');
INSERT INTO ACT_AI
	VALUES (1508,
	1514,
	1515,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1513,
	1503,
	1516,
	7,
	1,
	'box::eliminate line: 7');
INSERT INTO ACT_IF
	VALUES (1513,
	1517,
	1518,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1519,
	1503,
	0,
	9,
	1,
	'box::eliminate line: 9');
INSERT INTO ACT_E
	VALUES (1519,
	1520,
	1513);
INSERT INTO ACT_SMT
	VALUES (1516,
	1503,
	0,
	24,
	1,
	'box::eliminate line: 24');
INSERT INTO ACT_RET
	VALUES (1516,
	1521);
INSERT INTO V_VAL
	VALUES (1507,
	1,
	1,
	4,
	1,
	11,
	0,
	0,
	0,
	0,
	7,
	1503);
INSERT INTO V_TVL
	VALUES (1507,
	1522);
INSERT INTO V_VAL
	VALUES (1506,
	0,
	0,
	4,
	15,
	15,
	0,
	0,
	0,
	0,
	7,
	1503);
INSERT INTO V_LIN
	VALUES (1506,
	'0');
INSERT INTO V_VAL
	VALUES (1510,
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	1503);
INSERT INTO V_IRF
	VALUES (1510,
	1523);
INSERT INTO V_VAL
	VALUES (1515,
	1,
	1,
	6,
	1,
	1,
	0,
	0,
	0,
	0,
	7,
	1503);
INSERT INTO V_TVL
	VALUES (1515,
	1524);
INSERT INTO V_VAL
	VALUES (1525,
	0,
	0,
	6,
	17,
	25,
	0,
	0,
	0,
	0,
	14,
	1503);
INSERT INTO V_ISR
	VALUES (1525,
	1509);
INSERT INTO V_VAL
	VALUES (1514,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	1503);
INSERT INTO V_UNY
	VALUES (1514,
	1525,
	'cardinality');
INSERT INTO V_VAL
	VALUES (1526,
	0,
	0,
	7,
	6,
	6,
	0,
	0,
	0,
	0,
	7,
	1503);
INSERT INTO V_LIN
	VALUES (1526,
	'9');
INSERT INTO V_VAL
	VALUES (1518,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1503);
INSERT INTO V_BIN
	VALUES (1518,
	1527,
	1526,
	'==');
INSERT INTO V_VAL
	VALUES (1527,
	0,
	0,
	7,
	11,
	11,
	0,
	0,
	0,
	0,
	7,
	1503);
INSERT INTO V_TVL
	VALUES (1527,
	1524);
INSERT INTO V_VAL
	VALUES (1521,
	0,
	0,
	24,
	8,
	18,
	0,
	0,
	0,
	0,
	7,
	1503);
INSERT INTO V_TVL
	VALUES (1521,
	1522);
INSERT INTO V_VAR
	VALUES (1522,
	1503,
	'temperature',
	1,
	7);
INSERT INTO V_TRN
	VALUES (1522,
	0,
	'');
INSERT INTO V_LOC
	VALUES (1528,
	4,
	1,
	11,
	1522);
INSERT INTO V_LOC
	VALUES (1529,
	8,
	3,
	13,
	1522);
INSERT INTO V_LOC
	VALUES (1530,
	19,
	5,
	15,
	1522);
INSERT INTO V_LOC
	VALUES (1531,
	24,
	8,
	18,
	1522);
INSERT INTO V_VAR
	VALUES (1509,
	1503,
	'eligibles',
	1,
	14);
INSERT INTO V_INS
	VALUES (1509,
	382);
INSERT INTO V_LOC
	VALUES (1532,
	5,
	13,
	21,
	1509);
INSERT INTO V_LOC
	VALUES (1533,
	10,
	22,
	30,
	1509);
INSERT INTO V_VAR
	VALUES (1523,
	1503,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (1523,
	0,
	310);
INSERT INTO V_VAR
	VALUES (1524,
	1503,
	'c',
	1,
	7);
INSERT INTO V_TRN
	VALUES (1524,
	0,
	'');
INSERT INTO V_LOC
	VALUES (1534,
	6,
	1,
	1,
	1524);
INSERT INTO V_LOC
	VALUES (1535,
	7,
	11,
	11,
	1524);
INSERT INTO V_LOC
	VALUES (1536,
	13,
	3,
	3,
	1524);
INSERT INTO V_LOC
	VALUES (1537,
	14,
	13,
	13,
	1524);
INSERT INTO ACT_BLK
	VALUES (1517,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1502,
	0);
INSERT INTO ACT_SMT
	VALUES (1538,
	1517,
	0,
	8,
	3,
	'box::eliminate line: 8');
INSERT INTO ACT_AI
	VALUES (1538,
	1539,
	1540,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1540,
	1,
	0,
	8,
	3,
	13,
	0,
	0,
	0,
	0,
	7,
	1517);
INSERT INTO V_TVL
	VALUES (1540,
	1522);
INSERT INTO V_VAL
	VALUES (1539,
	0,
	0,
	8,
	17,
	19,
	0,
	0,
	0,
	0,
	7,
	1517);
INSERT INTO V_LIN
	VALUES (1539,
	'100');
INSERT INTO ACT_BLK
	VALUES (1520,
	0,
	0,
	0,
	'',
	'',
	'',
	10,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1502,
	0);
INSERT INTO ACT_SMT
	VALUES (1541,
	1520,
	0,
	10,
	1,
	'box::eliminate line: 10');
INSERT INTO ACT_FOR
	VALUES (1541,
	1542,
	1,
	1543,
	1509,
	382);
INSERT INTO V_VAR
	VALUES (1543,
	1520,
	'eligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (1543,
	1,
	382);
INSERT INTO V_LOC
	VALUES (1544,
	10,
	10,
	17,
	1543);
INSERT INTO V_LOC
	VALUES (1545,
	12,
	37,
	44,
	1543);
INSERT INTO V_LOC
	VALUES (1546,
	17,
	31,
	38,
	1543);
INSERT INTO ACT_BLK
	VALUES (1542,
	1,
	0,
	1,
	'',
	'',
	'',
	14,
	3,
	11,
	49,
	0,
	0,
	11,
	58,
	0,
	0,
	0,
	0,
	0,
	1502,
	0);
INSERT INTO ACT_SMT
	VALUES (1547,
	1542,
	1548,
	11,
	3,
	'box::eliminate line: 11');
INSERT INTO ACT_SEL
	VALUES (1547,
	1549,
	1,
	'many',
	1550);
INSERT INTO ACT_SRW
	VALUES (1547,
	1551);
INSERT INTO ACT_LNK
	VALUES (1552,
	'',
	1547,
	521,
	1553,
	3,
	168,
	11,
	39,
	11,
	44,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (1553,
	'',
	0,
	383,
	0,
	3,
	382,
	11,
	49,
	11,
	58,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1548,
	1542,
	1554,
	13,
	3,
	'box::eliminate line: 13');
INSERT INTO ACT_AI
	VALUES (1548,
	1555,
	1556,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1554,
	1542,
	0,
	14,
	3,
	'box::eliminate line: 14');
INSERT INTO ACT_IF
	VALUES (1554,
	1557,
	1558,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1550,
	0,
	0,
	11,
	33,
	36,
	0,
	0,
	0,
	0,
	13,
	1542);
INSERT INTO V_IRF
	VALUES (1550,
	1523);
INSERT INTO V_VAL
	VALUES (1559,
	0,
	0,
	12,
	13,
	-1,
	0,
	0,
	0,
	0,
	13,
	1542);
INSERT INTO V_SLR
	VALUES (1559,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1560,
	0,
	0,
	12,
	22,
	32,
	0,
	0,
	0,
	0,
	7,
	1542);
INSERT INTO V_AVL
	VALUES (1560,
	1559,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (1551,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1542);
INSERT INTO V_BIN
	VALUES (1551,
	1561,
	1560,
	'==');
INSERT INTO V_VAL
	VALUES (1562,
	0,
	0,
	12,
	37,
	44,
	0,
	0,
	0,
	0,
	13,
	1542);
INSERT INTO V_IRF
	VALUES (1562,
	1543);
INSERT INTO V_VAL
	VALUES (1561,
	0,
	0,
	12,
	46,
	56,
	0,
	0,
	0,
	0,
	7,
	1542);
INSERT INTO V_AVL
	VALUES (1561,
	1562,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (1556,
	1,
	0,
	13,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	1542);
INSERT INTO V_TVL
	VALUES (1556,
	1524);
INSERT INTO V_VAL
	VALUES (1563,
	0,
	0,
	13,
	19,
	24,
	0,
	0,
	0,
	0,
	14,
	1542);
INSERT INTO V_ISR
	VALUES (1563,
	1549);
INSERT INTO V_VAL
	VALUES (1555,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	1542);
INSERT INTO V_UNY
	VALUES (1555,
	1563,
	'cardinality');
INSERT INTO V_VAL
	VALUES (1564,
	0,
	0,
	14,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	1542);
INSERT INTO V_LIN
	VALUES (1564,
	'1');
INSERT INTO V_VAL
	VALUES (1558,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1542);
INSERT INTO V_BIN
	VALUES (1558,
	1565,
	1564,
	'==');
INSERT INTO V_VAL
	VALUES (1565,
	0,
	0,
	14,
	13,
	13,
	0,
	0,
	0,
	0,
	7,
	1542);
INSERT INTO V_TVL
	VALUES (1565,
	1524);
INSERT INTO V_VAR
	VALUES (1549,
	1542,
	'loners',
	1,
	14);
INSERT INTO V_INS
	VALUES (1549,
	382);
INSERT INTO V_LOC
	VALUES (1566,
	11,
	15,
	20,
	1549);
INSERT INTO ACT_BLK
	VALUES (1557,
	1,
	0,
	0,
	'',
	'',
	'',
	20,
	5,
	16,
	42,
	0,
	0,
	16,
	47,
	0,
	0,
	0,
	0,
	0,
	1502,
	0);
INSERT INTO ACT_SMT
	VALUES (1567,
	1557,
	1568,
	16,
	5,
	'box::eliminate line: 16');
INSERT INTO ACT_SEL
	VALUES (1567,
	1569,
	1,
	'one',
	1570);
INSERT INTO ACT_SR
	VALUES (1567);
INSERT INTO ACT_LNK
	VALUES (1571,
	'',
	1567,
	383,
	0,
	2,
	168,
	16,
	42,
	16,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1568,
	1557,
	1572,
	17,
	5,
	'box::eliminate line: 17');
INSERT INTO ACT_TFM
	VALUES (1568,
	1495,
	1569,
	17,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1572,
	1557,
	1573,
	19,
	5,
	'box::eliminate line: 19');
INSERT INTO ACT_AI
	VALUES (1572,
	1574,
	1575,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1573,
	1557,
	0,
	20,
	5,
	'box::eliminate line: 20');
INSERT INTO ACT_BRK
	VALUES (1573);
INSERT INTO V_VAL
	VALUES (1570,
	0,
	0,
	16,
	32,
	39,
	0,
	0,
	0,
	0,
	13,
	1557);
INSERT INTO V_IRF
	VALUES (1570,
	1543);
INSERT INTO V_VAL
	VALUES (1576,
	0,
	0,
	17,
	31,
	38,
	0,
	0,
	0,
	0,
	13,
	1557);
INSERT INTO V_IRF
	VALUES (1576,
	1543);
INSERT INTO V_VAL
	VALUES (1577,
	0,
	0,
	17,
	40,
	50,
	0,
	0,
	0,
	0,
	7,
	1557);
INSERT INTO V_AVL
	VALUES (1577,
	1576,
	382,
	1448);
INSERT INTO V_PAR
	VALUES (1577,
	1568,
	0,
	'answer_digit',
	0,
	17,
	18);
INSERT INTO V_VAL
	VALUES (1575,
	1,
	0,
	19,
	5,
	15,
	0,
	0,
	0,
	0,
	7,
	1557);
INSERT INTO V_TVL
	VALUES (1575,
	1522);
INSERT INTO V_VAL
	VALUES (1574,
	0,
	0,
	19,
	19,
	19,
	0,
	0,
	0,
	0,
	7,
	1557);
INSERT INTO V_LIN
	VALUES (1574,
	'1');
INSERT INTO V_VAR
	VALUES (1569,
	1557,
	'cell',
	1,
	13);
INSERT INTO V_INT
	VALUES (1569,
	0,
	168);
INSERT INTO V_LOC
	VALUES (1578,
	16,
	16,
	19,
	1569);
INSERT INTO V_LOC
	VALUES (1579,
	17,
	5,
	8,
	1569);
INSERT INTO O_NBATTR
	VALUES (330,
	310);
INSERT INTO O_BATTR
	VALUES (330,
	310);
INSERT INTO O_ATTR
	VALUES (330,
	310,
	0,
	'number',
	'',
	'',
	'number',
	0,
	7,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1580,
	310);
INSERT INTO O_BATTR
	VALUES (1580,
	310);
INSERT INTO O_ATTR
	VALUES (1580,
	310,
	330,
	'current_state',
	'',
	'',
	'current_state',
	0,
	11,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	310);
INSERT INTO O_ID
	VALUES (1,
	310);
INSERT INTO O_ID
	VALUES (2,
	310);
INSERT INTO SM_ISM
	VALUES (1581,
	310);
INSERT INTO SM_SM
	VALUES (1581,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (1581);
INSERT INTO SM_LEVT
	VALUES (1582,
	1581,
	0);
INSERT INTO SM_SEVT
	VALUES (1582,
	1581,
	0);
INSERT INTO SM_EVT
	VALUES (1582,
	1581,
	0,
	1,
	'update',
	0,
	'',
	'BOX1',
	'');
INSERT INTO SM_LEVT
	VALUES (1583,
	1581,
	0);
INSERT INTO SM_SEVT
	VALUES (1583,
	1581,
	0);
INSERT INTO SM_EVT
	VALUES (1583,
	1581,
	0,
	2,
	'solved',
	0,
	'',
	'BOX2',
	'');
INSERT INTO SM_STATE
	VALUES (1584,
	1581,
	0,
	'solving',
	1,
	0);
INSERT INTO SM_SEME
	VALUES (1584,
	1582,
	1581,
	0);
INSERT INTO SM_SEME
	VALUES (1584,
	1583,
	1581,
	0);
INSERT INTO SM_MOAH
	VALUES (1585,
	1581,
	1584);
INSERT INTO SM_AH
	VALUES (1585,
	1581);
INSERT INTO SM_ACT
	VALUES (1585,
	1581,
	1,
	'if ( 100 == self.prune() )
  generate BOX2:solved() to self;
elif ( 100 == self.eliminate() )
  generate BOX2:solved() to self;
else
  select one sequence related by self->SEQUENCE[R1];
  if ( sequence.requests >= 1 )
    sequence.requests = 1;
    b = self;
    generate BOX1:update() to b;
  else
    sequence.requests = 0;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES (1586,
	1581,
	1585);
INSERT INTO ACT_ACT
	VALUES (1586,
	'state',
	0,
	1587,
	0,
	0,
	'box::solving',
	0);
INSERT INTO ACT_BLK
	VALUES (1587,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1586,
	0);
INSERT INTO ACT_SMT
	VALUES (1588,
	1587,
	0,
	1,
	1,
	'box::solving line: 1');
INSERT INTO ACT_IF
	VALUES (1588,
	1589,
	1590,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1591,
	1587,
	0,
	3,
	1,
	'box::solving line: 3');
INSERT INTO ACT_EL
	VALUES (1591,
	1592,
	1593,
	1588);
INSERT INTO ACT_SMT
	VALUES (1594,
	1587,
	0,
	5,
	1,
	'box::solving line: 5');
INSERT INTO ACT_E
	VALUES (1594,
	1595,
	1588);
INSERT INTO V_VAL
	VALUES (1596,
	0,
	0,
	1,
	6,
	8,
	0,
	0,
	0,
	0,
	7,
	1587);
INSERT INTO V_LIN
	VALUES (1596,
	'100');
INSERT INTO V_VAL
	VALUES (1590,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1587);
INSERT INTO V_BIN
	VALUES (1590,
	1597,
	1596,
	'==');
INSERT INTO V_VAL
	VALUES (1597,
	0,
	0,
	1,
	18,
	-1,
	0,
	0,
	0,
	0,
	7,
	1587);
INSERT INTO V_TRV
	VALUES (1597,
	1375,
	1598,
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1599,
	0,
	0,
	3,
	8,
	10,
	0,
	0,
	0,
	0,
	7,
	1587);
INSERT INTO V_LIN
	VALUES (1599,
	'100');
INSERT INTO V_VAL
	VALUES (1593,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1587);
INSERT INTO V_BIN
	VALUES (1593,
	1600,
	1599,
	'==');
INSERT INTO V_VAL
	VALUES (1600,
	0,
	0,
	3,
	20,
	-1,
	0,
	0,
	0,
	0,
	7,
	1587);
INSERT INTO V_TRV
	VALUES (1600,
	1376,
	1598,
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES (1598,
	1587,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (1598,
	0,
	310);
INSERT INTO V_LOC
	VALUES (1601,
	1,
	13,
	16,
	1598);
INSERT INTO V_LOC
	VALUES (1602,
	2,
	29,
	32,
	1598);
INSERT INTO V_LOC
	VALUES (1603,
	3,
	15,
	18,
	1598);
INSERT INTO V_LOC
	VALUES (1604,
	4,
	29,
	32,
	1598);
INSERT INTO V_LOC
	VALUES (1605,
	9,
	9,
	12,
	1598);
INSERT INTO ACT_BLK
	VALUES (1589,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1586,
	0);
INSERT INTO ACT_SMT
	VALUES (1606,
	1589,
	0,
	2,
	3,
	'box::solving line: 2');
INSERT INTO E_ESS
	VALUES (1606,
	1,
	0,
	2,
	12,
	2,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1606);
INSERT INTO E_GSME
	VALUES (1606,
	1583,
	1581);
INSERT INTO E_GEN
	VALUES (1606,
	1598);
INSERT INTO ACT_BLK
	VALUES (1592,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1586,
	0);
INSERT INTO ACT_SMT
	VALUES (1607,
	1592,
	0,
	4,
	3,
	'box::solving line: 4');
INSERT INTO E_ESS
	VALUES (1607,
	1,
	0,
	4,
	12,
	4,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1607);
INSERT INTO E_GSME
	VALUES (1607,
	1583,
	1581);
INSERT INTO E_GEN
	VALUES (1607,
	1598);
INSERT INTO ACT_BLK
	VALUES (1595,
	1,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	6,
	40,
	0,
	0,
	6,
	49,
	0,
	0,
	0,
	0,
	0,
	1586,
	0);
INSERT INTO ACT_SMT
	VALUES (1608,
	1595,
	1609,
	6,
	3,
	'box::solving line: 6');
INSERT INTO ACT_SEL
	VALUES (1608,
	1610,
	1,
	'one',
	1611);
INSERT INTO ACT_SR
	VALUES (1608);
INSERT INTO ACT_LNK
	VALUES (1612,
	'',
	1608,
	286,
	0,
	2,
	109,
	6,
	40,
	6,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1609,
	1595,
	0,
	7,
	3,
	'box::solving line: 7');
INSERT INTO ACT_IF
	VALUES (1609,
	1613,
	1614,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1615,
	1595,
	0,
	11,
	3,
	'box::solving line: 11');
INSERT INTO ACT_E
	VALUES (1615,
	1616,
	1609);
INSERT INTO V_VAL
	VALUES (1611,
	0,
	0,
	6,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	1595);
INSERT INTO V_IRF
	VALUES (1611,
	1598);
INSERT INTO V_VAL
	VALUES (1617,
	0,
	0,
	7,
	8,
	15,
	0,
	0,
	0,
	0,
	13,
	1595);
INSERT INTO V_IRF
	VALUES (1617,
	1610);
INSERT INTO V_VAL
	VALUES (1618,
	0,
	0,
	7,
	17,
	24,
	0,
	0,
	0,
	0,
	7,
	1595);
INSERT INTO V_AVL
	VALUES (1618,
	1617,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1614,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1595);
INSERT INTO V_BIN
	VALUES (1614,
	1619,
	1618,
	'>=');
INSERT INTO V_VAL
	VALUES (1619,
	0,
	0,
	7,
	29,
	29,
	0,
	0,
	0,
	0,
	7,
	1595);
INSERT INTO V_LIN
	VALUES (1619,
	'1');
INSERT INTO V_VAR
	VALUES (1610,
	1595,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (1610,
	0,
	109);
INSERT INTO V_LOC
	VALUES (1620,
	6,
	14,
	21,
	1610);
INSERT INTO V_LOC
	VALUES (1621,
	7,
	8,
	15,
	1610);
INSERT INTO V_LOC
	VALUES (1622,
	8,
	5,
	12,
	1610);
INSERT INTO V_LOC
	VALUES (1623,
	12,
	5,
	12,
	1610);
INSERT INTO ACT_BLK
	VALUES (1613,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1586,
	0);
INSERT INTO ACT_SMT
	VALUES (1624,
	1613,
	1625,
	8,
	5,
	'box::solving line: 8');
INSERT INTO ACT_AI
	VALUES (1624,
	1626,
	1627,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1625,
	1613,
	1628,
	9,
	5,
	'box::solving line: 9');
INSERT INTO ACT_AI
	VALUES (1625,
	1629,
	1630,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1628,
	1613,
	0,
	10,
	5,
	'box::solving line: 10');
INSERT INTO E_ESS
	VALUES (1628,
	1,
	0,
	10,
	14,
	10,
	19,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1628);
INSERT INTO E_GSME
	VALUES (1628,
	1582,
	1581);
INSERT INTO E_GEN
	VALUES (1628,
	1631);
INSERT INTO V_VAL
	VALUES (1632,
	1,
	0,
	8,
	5,
	12,
	0,
	0,
	0,
	0,
	13,
	1613);
INSERT INTO V_IRF
	VALUES (1632,
	1610);
INSERT INTO V_VAL
	VALUES (1627,
	1,
	0,
	8,
	14,
	21,
	0,
	0,
	0,
	0,
	7,
	1613);
INSERT INTO V_AVL
	VALUES (1627,
	1632,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1626,
	0,
	0,
	8,
	25,
	25,
	0,
	0,
	0,
	0,
	7,
	1613);
INSERT INTO V_LIN
	VALUES (1626,
	'1');
INSERT INTO V_VAL
	VALUES (1630,
	1,
	1,
	9,
	5,
	5,
	0,
	0,
	0,
	0,
	13,
	1613);
INSERT INTO V_IRF
	VALUES (1630,
	1631);
INSERT INTO V_VAL
	VALUES (1629,
	0,
	0,
	9,
	9,
	12,
	0,
	0,
	0,
	0,
	13,
	1613);
INSERT INTO V_IRF
	VALUES (1629,
	1598);
INSERT INTO V_VAR
	VALUES (1631,
	1613,
	'b',
	1,
	13);
INSERT INTO V_INT
	VALUES (1631,
	0,
	310);
INSERT INTO V_LOC
	VALUES (1633,
	9,
	5,
	5,
	1631);
INSERT INTO V_LOC
	VALUES (1634,
	10,
	31,
	31,
	1631);
INSERT INTO ACT_BLK
	VALUES (1616,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1586,
	0);
INSERT INTO ACT_SMT
	VALUES (1635,
	1616,
	0,
	12,
	5,
	'box::solving line: 12');
INSERT INTO ACT_AI
	VALUES (1635,
	1636,
	1637,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1638,
	1,
	0,
	12,
	5,
	12,
	0,
	0,
	0,
	0,
	13,
	1616);
INSERT INTO V_IRF
	VALUES (1638,
	1610);
INSERT INTO V_VAL
	VALUES (1637,
	1,
	0,
	12,
	14,
	21,
	0,
	0,
	0,
	0,
	7,
	1616);
INSERT INTO V_AVL
	VALUES (1637,
	1638,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1636,
	0,
	0,
	12,
	25,
	25,
	0,
	0,
	0,
	0,
	7,
	1616);
INSERT INTO V_LIN
	VALUES (1636,
	'0');
INSERT INTO SM_STATE
	VALUES (1639,
	1581,
	0,
	'solved',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES (1639,
	1582,
	1581,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (1639,
	1582,
	1581,
	0);
INSERT INTO SM_EIGN
	VALUES (1639,
	1583,
	1581,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (1639,
	1583,
	1581,
	0);
INSERT INTO SM_MOAH
	VALUES (1640,
	1581,
	1639);
INSERT INTO SM_AH
	VALUES (1640,
	1581);
INSERT INTO SM_ACT
	VALUES (1640,
	1581,
	1,
	'select one sequence related by self->SEQUENCE[R1];
sequence.solved = true;',
	'');
INSERT INTO ACT_SAB
	VALUES (1641,
	1581,
	1640);
INSERT INTO ACT_ACT
	VALUES (1641,
	'state',
	0,
	1642,
	0,
	0,
	'box::solved',
	0);
INSERT INTO ACT_BLK
	VALUES (1642,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	1,
	47,
	0,
	0,
	0,
	0,
	0,
	1641,
	0);
INSERT INTO ACT_SMT
	VALUES (1643,
	1642,
	1644,
	1,
	1,
	'box::solved line: 1');
INSERT INTO ACT_SEL
	VALUES (1643,
	1645,
	1,
	'one',
	1646);
INSERT INTO ACT_SR
	VALUES (1643);
INSERT INTO ACT_LNK
	VALUES (1647,
	'',
	1643,
	286,
	0,
	2,
	109,
	1,
	38,
	1,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1644,
	1642,
	0,
	2,
	1,
	'box::solved line: 2');
INSERT INTO ACT_AI
	VALUES (1644,
	1648,
	1649,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1646,
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	13,
	1642);
INSERT INTO V_IRF
	VALUES (1646,
	1650);
INSERT INTO V_VAL
	VALUES (1651,
	1,
	0,
	2,
	1,
	8,
	0,
	0,
	0,
	0,
	13,
	1642);
INSERT INTO V_IRF
	VALUES (1651,
	1645);
INSERT INTO V_VAL
	VALUES (1649,
	1,
	0,
	2,
	10,
	15,
	0,
	0,
	0,
	0,
	6,
	1642);
INSERT INTO V_AVL
	VALUES (1649,
	1651,
	109,
	318);
INSERT INTO V_VAL
	VALUES (1648,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1642);
INSERT INTO V_LBO
	VALUES (1648,
	'TRUE');
INSERT INTO V_VAR
	VALUES (1645,
	1642,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (1645,
	0,
	109);
INSERT INTO V_LOC
	VALUES (1652,
	1,
	12,
	19,
	1645);
INSERT INTO V_LOC
	VALUES (1653,
	2,
	1,
	8,
	1645);
INSERT INTO V_VAR
	VALUES (1650,
	1642,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (1650,
	0,
	310);
INSERT INTO SM_NSTXN
	VALUES (1654,
	1581,
	1584,
	1582,
	0);
INSERT INTO SM_TAH
	VALUES (1655,
	1581,
	1654);
INSERT INTO SM_AH
	VALUES (1655,
	1581);
INSERT INTO SM_ACT
	VALUES (1655,
	1581,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (1656,
	1581,
	1655);
INSERT INTO ACT_ACT
	VALUES (1656,
	'transition',
	0,
	1657,
	0,
	0,
	'BOX1: update in solving to solving',
	0);
INSERT INTO ACT_BLK
	VALUES (1657,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1656,
	0);
INSERT INTO SM_TXN
	VALUES (1654,
	1581,
	1584,
	0);
INSERT INTO SM_NSTXN
	VALUES (1658,
	1581,
	1584,
	1583,
	0);
INSERT INTO SM_TAH
	VALUES (1659,
	1581,
	1658);
INSERT INTO SM_AH
	VALUES (1659,
	1581);
INSERT INTO SM_ACT
	VALUES (1659,
	1581,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (1660,
	1581,
	1659);
INSERT INTO ACT_ACT
	VALUES (1660,
	'transition',
	0,
	1661,
	0,
	0,
	'BOX2: solved in solving to solved',
	0);
INSERT INTO ACT_BLK
	VALUES (1661,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1660,
	0);
INSERT INTO SM_TXN
	VALUES (1658,
	1581,
	1639,
	0);
INSERT INTO O_OBJ
	VALUES (168,
	'cell',
	5,
	'CELL',
	'',
	1374);
INSERT INTO O_TFR
	VALUES (606,
	168,
	'set_given',
	'',
	5,
	0,
	'select any cell from instances of CELL
  where ( ( selected.row_number == param.row ) and 
          ( selected.column_number == param.column ) );
cell.answer( answer_digit:param.answer );',
	1,
	'',
	813);
INSERT INTO O_TPARM
	VALUES (1662,
	606,
	'row',
	7,
	0,
	'',
	1663,
	'');
INSERT INTO O_TPARM
	VALUES (1663,
	606,
	'column',
	7,
	0,
	'',
	1664,
	'');
INSERT INTO O_TPARM
	VALUES (1664,
	606,
	'answer',
	7,
	0,
	'',
	0,
	'');
INSERT INTO ACT_OPB
	VALUES (1665,
	606);
INSERT INTO ACT_ACT
	VALUES (1665,
	'class operation',
	0,
	1666,
	0,
	0,
	'cell::set_given',
	0);
INSERT INTO ACT_BLK
	VALUES (1666,
	1,
	0,
	1,
	'',
	'',
	'',
	4,
	1,
	1,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1665,
	0);
INSERT INTO ACT_SMT
	VALUES (1667,
	1666,
	1668,
	1,
	1,
	'cell::set_given line: 1');
INSERT INTO ACT_FIW
	VALUES (1667,
	1669,
	1,
	'any',
	1670,
	168,
	1,
	35);
INSERT INTO ACT_SMT
	VALUES (1668,
	1666,
	0,
	4,
	1,
	'cell::set_given line: 4');
INSERT INTO ACT_TFM
	VALUES (1668,
	1495,
	1669,
	4,
	6,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1671,
	0,
	0,
	2,
	13,
	-1,
	0,
	0,
	0,
	0,
	13,
	1666);
INSERT INTO V_SLR
	VALUES (1671,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1672,
	0,
	0,
	2,
	22,
	31,
	0,
	0,
	0,
	0,
	7,
	1666);
INSERT INTO V_AVL
	VALUES (1672,
	1671,
	168,
	415);
INSERT INTO V_VAL
	VALUES (1673,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1666);
INSERT INTO V_BIN
	VALUES (1673,
	1674,
	1672,
	'==');
INSERT INTO V_VAL
	VALUES (1674,
	0,
	0,
	2,
	42,
	44,
	0,
	0,
	0,
	0,
	7,
	1666);
INSERT INTO V_PVL
	VALUES (1674,
	0,
	0,
	1662,
	0);
INSERT INTO V_VAL
	VALUES (1675,
	0,
	0,
	3,
	13,
	-1,
	0,
	0,
	0,
	0,
	13,
	1666);
INSERT INTO V_SLR
	VALUES (1675,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1676,
	0,
	0,
	3,
	22,
	34,
	0,
	0,
	0,
	0,
	7,
	1666);
INSERT INTO V_AVL
	VALUES (1676,
	1675,
	168,
	420);
INSERT INTO V_VAL
	VALUES (1677,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1666);
INSERT INTO V_BIN
	VALUES (1677,
	1678,
	1676,
	'==');
INSERT INTO V_VAL
	VALUES (1678,
	0,
	0,
	3,
	45,
	50,
	0,
	0,
	0,
	0,
	7,
	1666);
INSERT INTO V_PVL
	VALUES (1678,
	0,
	0,
	1663,
	0);
INSERT INTO V_VAL
	VALUES (1670,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1666);
INSERT INTO V_BIN
	VALUES (1670,
	1677,
	1673,
	'and');
INSERT INTO V_VAL
	VALUES (1679,
	0,
	0,
	4,
	33,
	38,
	0,
	0,
	0,
	0,
	7,
	1666);
INSERT INTO V_PVL
	VALUES (1679,
	0,
	0,
	1664,
	0);
INSERT INTO V_PAR
	VALUES (1679,
	1668,
	0,
	'answer_digit',
	0,
	4,
	14);
INSERT INTO V_VAR
	VALUES (1669,
	1666,
	'cell',
	1,
	13);
INSERT INTO V_INT
	VALUES (1669,
	0,
	168);
INSERT INTO V_LOC
	VALUES (1680,
	1,
	12,
	15,
	1669);
INSERT INTO V_LOC
	VALUES (1681,
	4,
	1,
	4,
	1669);
INSERT INTO O_TFR
	VALUES (1495,
	168,
	'answer',
	'',
	5,
	1,
	'// An answer has been found, so remove the eligible
// digits which are now ineligible digits.
select one zerodigit related by self->DIGIT[R9] where ( selected.value == 0 );
if ( not_empty zerodigit )
  unrelate self from zerodigit across R9;
end if;

// Link in the answer.
select any digit from instances of DIGIT 
  where ( selected.value == param.answer_digit );
if ( not_empty digit )
  relate self to digit across R9;
end if;

// Unlink the other digits.  There can be only one answer.
select many ineligibles related by self->ELIGIBLE[R8]
  where ( selected.digit_value != param.answer_digit );
for each ineligible in ineligibles
  select one digit related by ineligible->DIGIT[R8];
  unrelate self from digit across R8 using ineligible;
  delete object instance ineligible;
end for;',
	1,
	'',
	0);
INSERT INTO O_TPARM
	VALUES (1682,
	1495,
	'answer_digit',
	7,
	0,
	'',
	0,
	'');
INSERT INTO ACT_OPB
	VALUES (1683,
	1495);
INSERT INTO ACT_ACT
	VALUES (1683,
	'operation',
	0,
	1684,
	0,
	0,
	'cell::answer',
	0);
INSERT INTO ACT_BLK
	VALUES (1684,
	1,
	0,
	1,
	'',
	'',
	'',
	18,
	1,
	16,
	42,
	0,
	0,
	16,
	51,
	0,
	0,
	0,
	0,
	0,
	1683,
	0);
INSERT INTO ACT_SMT
	VALUES (1685,
	1684,
	1686,
	3,
	1,
	'cell::answer line: 3');
INSERT INTO ACT_SEL
	VALUES (1685,
	1687,
	1,
	'one',
	1688);
INSERT INTO ACT_SRW
	VALUES (1685,
	1689);
INSERT INTO ACT_LNK
	VALUES (1690,
	'',
	1685,
	357,
	0,
	2,
	150,
	3,
	39,
	3,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1686,
	1684,
	1691,
	4,
	1,
	'cell::answer line: 4');
INSERT INTO ACT_IF
	VALUES (1686,
	1692,
	1693,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1691,
	1684,
	1694,
	9,
	1,
	'cell::answer line: 9');
INSERT INTO ACT_FIW
	VALUES (1691,
	1695,
	1,
	'any',
	1696,
	150,
	9,
	36);
INSERT INTO ACT_SMT
	VALUES (1694,
	1684,
	1697,
	11,
	1,
	'cell::answer line: 11');
INSERT INTO ACT_IF
	VALUES (1694,
	1698,
	1699,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1697,
	1684,
	1700,
	16,
	1,
	'cell::answer line: 16');
INSERT INTO ACT_SEL
	VALUES (1697,
	1701,
	1,
	'many',
	1702);
INSERT INTO ACT_SRW
	VALUES (1697,
	1703);
INSERT INTO ACT_LNK
	VALUES (1704,
	'',
	1697,
	383,
	0,
	3,
	382,
	16,
	42,
	16,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1700,
	1684,
	0,
	18,
	1,
	'cell::answer line: 18');
INSERT INTO ACT_FOR
	VALUES (1700,
	1705,
	1,
	1706,
	1701,
	382);
INSERT INTO V_VAL
	VALUES (1688,
	0,
	0,
	3,
	33,
	36,
	0,
	0,
	0,
	0,
	13,
	1684);
INSERT INTO V_IRF
	VALUES (1688,
	1707);
INSERT INTO V_VAL
	VALUES (1708,
	0,
	0,
	3,
	57,
	-1,
	0,
	0,
	0,
	0,
	13,
	1684);
INSERT INTO V_SLR
	VALUES (1708,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1709,
	0,
	0,
	3,
	66,
	70,
	0,
	0,
	0,
	0,
	7,
	1684);
INSERT INTO V_AVL
	VALUES (1709,
	1708,
	150,
	182);
INSERT INTO V_VAL
	VALUES (1689,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1684);
INSERT INTO V_BIN
	VALUES (1689,
	1710,
	1709,
	'==');
INSERT INTO V_VAL
	VALUES (1710,
	0,
	0,
	3,
	75,
	75,
	0,
	0,
	0,
	0,
	7,
	1684);
INSERT INTO V_LIN
	VALUES (1710,
	'0');
INSERT INTO V_VAL
	VALUES (1711,
	0,
	0,
	4,
	16,
	24,
	0,
	0,
	0,
	0,
	13,
	1684);
INSERT INTO V_IRF
	VALUES (1711,
	1687);
INSERT INTO V_VAL
	VALUES (1693,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1684);
INSERT INTO V_UNY
	VALUES (1693,
	1711,
	'not_empty');
INSERT INTO V_VAL
	VALUES (1712,
	0,
	0,
	10,
	11,
	-1,
	0,
	0,
	0,
	0,
	13,
	1684);
INSERT INTO V_SLR
	VALUES (1712,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1713,
	0,
	0,
	10,
	20,
	24,
	0,
	0,
	0,
	0,
	7,
	1684);
INSERT INTO V_AVL
	VALUES (1713,
	1712,
	150,
	182);
INSERT INTO V_VAL
	VALUES (1696,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1684);
INSERT INTO V_BIN
	VALUES (1696,
	1714,
	1713,
	'==');
INSERT INTO V_VAL
	VALUES (1714,
	0,
	0,
	10,
	35,
	46,
	0,
	0,
	0,
	0,
	7,
	1684);
INSERT INTO V_PVL
	VALUES (1714,
	0,
	0,
	1682,
	0);
INSERT INTO V_VAL
	VALUES (1715,
	0,
	0,
	11,
	16,
	20,
	0,
	0,
	0,
	0,
	13,
	1684);
INSERT INTO V_IRF
	VALUES (1715,
	1695);
INSERT INTO V_VAL
	VALUES (1699,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1684);
INSERT INTO V_UNY
	VALUES (1699,
	1715,
	'not_empty');
INSERT INTO V_VAL
	VALUES (1702,
	0,
	0,
	16,
	36,
	39,
	0,
	0,
	0,
	0,
	13,
	1684);
INSERT INTO V_IRF
	VALUES (1702,
	1707);
INSERT INTO V_VAL
	VALUES (1716,
	0,
	0,
	17,
	11,
	-1,
	0,
	0,
	0,
	0,
	13,
	1684);
INSERT INTO V_SLR
	VALUES (1716,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1717,
	0,
	0,
	17,
	20,
	30,
	0,
	0,
	0,
	0,
	7,
	1684);
INSERT INTO V_AVL
	VALUES (1717,
	1716,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (1703,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1684);
INSERT INTO V_BIN
	VALUES (1703,
	1718,
	1717,
	'!=');
INSERT INTO V_VAL
	VALUES (1718,
	0,
	0,
	17,
	41,
	52,
	0,
	0,
	0,
	0,
	7,
	1684);
INSERT INTO V_PVL
	VALUES (1718,
	0,
	0,
	1682,
	0);
INSERT INTO V_VAR
	VALUES (1687,
	1684,
	'zerodigit',
	1,
	13);
INSERT INTO V_INT
	VALUES (1687,
	0,
	150);
INSERT INTO V_LOC
	VALUES (1719,
	3,
	12,
	20,
	1687);
INSERT INTO V_LOC
	VALUES (1720,
	5,
	22,
	30,
	1687);
INSERT INTO V_VAR
	VALUES (1707,
	1684,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (1707,
	0,
	168);
INSERT INTO V_LOC
	VALUES (1721,
	5,
	12,
	15,
	1707);
INSERT INTO V_LOC
	VALUES (1722,
	12,
	10,
	13,
	1707);
INSERT INTO V_LOC
	VALUES (1723,
	20,
	12,
	15,
	1707);
INSERT INTO V_VAR
	VALUES (1695,
	1684,
	'digit',
	1,
	13);
INSERT INTO V_INT
	VALUES (1695,
	0,
	150);
INSERT INTO V_LOC
	VALUES (1724,
	9,
	12,
	16,
	1695);
INSERT INTO V_LOC
	VALUES (1725,
	12,
	18,
	22,
	1695);
INSERT INTO V_LOC
	VALUES (1726,
	19,
	14,
	18,
	1695);
INSERT INTO V_LOC
	VALUES (1727,
	20,
	22,
	26,
	1695);
INSERT INTO V_VAR
	VALUES (1701,
	1684,
	'ineligibles',
	1,
	14);
INSERT INTO V_INS
	VALUES (1701,
	382);
INSERT INTO V_LOC
	VALUES (1728,
	16,
	13,
	23,
	1701);
INSERT INTO V_LOC
	VALUES (1729,
	18,
	24,
	34,
	1701);
INSERT INTO V_VAR
	VALUES (1706,
	1684,
	'ineligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (1706,
	1,
	382);
INSERT INTO V_LOC
	VALUES (1730,
	18,
	10,
	19,
	1706);
INSERT INTO V_LOC
	VALUES (1731,
	20,
	44,
	53,
	1706);
INSERT INTO V_LOC
	VALUES (1732,
	21,
	26,
	35,
	1706);
INSERT INTO ACT_BLK
	VALUES (1692,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	3,
	0,
	0,
	0,
	0,
	5,
	39,
	0,
	0,
	0,
	0,
	0,
	1683,
	0);
INSERT INTO ACT_SMT
	VALUES (1733,
	1692,
	0,
	5,
	3,
	'cell::answer line: 5');
INSERT INTO ACT_UNR
	VALUES (1733,
	1707,
	1687,
	'',
	357,
	5,
	39,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (1698,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	3,
	0,
	0,
	0,
	0,
	12,
	31,
	0,
	0,
	0,
	0,
	0,
	1683,
	0);
INSERT INTO ACT_SMT
	VALUES (1734,
	1698,
	0,
	12,
	3,
	'cell::answer line: 12');
INSERT INTO ACT_REL
	VALUES (1734,
	1707,
	1695,
	'',
	357,
	12,
	31,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (1705,
	1,
	0,
	0,
	'',
	'',
	'',
	21,
	3,
	19,
	43,
	0,
	0,
	20,
	35,
	0,
	0,
	0,
	0,
	0,
	1683,
	0);
INSERT INTO ACT_SMT
	VALUES (1735,
	1705,
	1736,
	19,
	3,
	'cell::answer line: 19');
INSERT INTO ACT_SEL
	VALUES (1735,
	1695,
	0,
	'one',
	1737);
INSERT INTO ACT_SR
	VALUES (1735);
INSERT INTO ACT_LNK
	VALUES (1738,
	'',
	1735,
	383,
	0,
	2,
	150,
	19,
	43,
	19,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1736,
	1705,
	1739,
	20,
	3,
	'cell::answer line: 20');
INSERT INTO ACT_URU
	VALUES (1736,
	1707,
	1695,
	1706,
	'',
	383,
	20,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1739,
	1705,
	0,
	21,
	3,
	'cell::answer line: 21');
INSERT INTO ACT_DEL
	VALUES (1739,
	1706);
INSERT INTO V_VAL
	VALUES (1737,
	0,
	0,
	19,
	31,
	40,
	0,
	0,
	0,
	0,
	13,
	1705);
INSERT INTO V_IRF
	VALUES (1737,
	1706);
INSERT INTO O_TFR
	VALUES (813,
	168,
	'score',
	'',
	7,
	0,
	'select many cells from instances of CELL 
  where ( selected.answer_value != 0 );
score = cardinality cells;

//#inline
//   printf( "Score is:  %d\n", v234_score );
// 


return score;',
	1,
	'',
	1495);
INSERT INTO ACT_OPB
	VALUES (1740,
	813);
INSERT INTO ACT_ACT
	VALUES (1740,
	'class operation',
	0,
	1741,
	0,
	0,
	'cell::score',
	0);
INSERT INTO ACT_BLK
	VALUES (1741,
	1,
	0,
	1,
	'',
	'',
	'',
	9,
	1,
	1,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1740,
	0);
INSERT INTO ACT_SMT
	VALUES (1742,
	1741,
	1743,
	1,
	1,
	'cell::score line: 1');
INSERT INTO ACT_FIW
	VALUES (1742,
	1744,
	1,
	'many',
	1745,
	168,
	1,
	37);
INSERT INTO ACT_SMT
	VALUES (1743,
	1741,
	1746,
	3,
	1,
	'cell::score line: 3');
INSERT INTO ACT_AI
	VALUES (1743,
	1747,
	1748,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1746,
	1741,
	0,
	9,
	1,
	'cell::score line: 9');
INSERT INTO ACT_RET
	VALUES (1746,
	1749);
INSERT INTO V_VAL
	VALUES (1750,
	0,
	0,
	2,
	11,
	-1,
	0,
	0,
	0,
	0,
	13,
	1741);
INSERT INTO V_SLR
	VALUES (1750,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1751,
	0,
	0,
	2,
	20,
	31,
	0,
	0,
	0,
	0,
	7,
	1741);
INSERT INTO V_AVL
	VALUES (1751,
	1750,
	168,
	788);
INSERT INTO V_VAL
	VALUES (1745,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1741);
INSERT INTO V_BIN
	VALUES (1745,
	1752,
	1751,
	'!=');
INSERT INTO V_VAL
	VALUES (1752,
	0,
	0,
	2,
	36,
	36,
	0,
	0,
	0,
	0,
	7,
	1741);
INSERT INTO V_LIN
	VALUES (1752,
	'0');
INSERT INTO V_VAL
	VALUES (1748,
	1,
	1,
	3,
	1,
	5,
	0,
	0,
	0,
	0,
	7,
	1741);
INSERT INTO V_TVL
	VALUES (1748,
	1753);
INSERT INTO V_VAL
	VALUES (1754,
	0,
	0,
	3,
	21,
	25,
	0,
	0,
	0,
	0,
	14,
	1741);
INSERT INTO V_ISR
	VALUES (1754,
	1744);
INSERT INTO V_VAL
	VALUES (1747,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	1741);
INSERT INTO V_UNY
	VALUES (1747,
	1754,
	'cardinality');
INSERT INTO V_VAL
	VALUES (1749,
	0,
	0,
	9,
	8,
	12,
	0,
	0,
	0,
	0,
	7,
	1741);
INSERT INTO V_TVL
	VALUES (1749,
	1753);
INSERT INTO V_VAR
	VALUES (1744,
	1741,
	'cells',
	1,
	14);
INSERT INTO V_INS
	VALUES (1744,
	168);
INSERT INTO V_LOC
	VALUES (1755,
	1,
	13,
	17,
	1744);
INSERT INTO V_VAR
	VALUES (1753,
	1741,
	'score',
	1,
	7);
INSERT INTO V_TRN
	VALUES (1753,
	0,
	'');
INSERT INTO V_LOC
	VALUES (1756,
	3,
	1,
	5,
	1753);
INSERT INTO V_LOC
	VALUES (1757,
	9,
	8,
	12,
	1753);
INSERT INTO O_REF
	VALUES (168,
	162,
	1,
	322,
	359,
	1758,
	1759,
	415,
	1760,
	0,
	0,
	'',
	'row',
	'number',
	'R2');
INSERT INTO O_RATTR
	VALUES (415,
	168,
	322,
	162,
	1,
	'number');
INSERT INTO O_ATTR
	VALUES (415,
	168,
	0,
	'row_number',
	'',
	'row_',
	'number',
	1,
	12,
	'',
	'');
INSERT INTO O_REF
	VALUES (168,
	296,
	1,
	326,
	361,
	1761,
	1762,
	420,
	1763,
	0,
	0,
	'',
	'column',
	'number',
	'R3');
INSERT INTO O_RATTR
	VALUES (420,
	168,
	326,
	296,
	1,
	'number');
INSERT INTO O_ATTR
	VALUES (420,
	168,
	415,
	'column_number',
	'',
	'column_',
	'number',
	1,
	12,
	'',
	'');
INSERT INTO O_REF
	VALUES (168,
	150,
	0,
	182,
	357,
	1764,
	1765,
	788,
	1766,
	0,
	0,
	'',
	'digit',
	'value',
	'R9');
INSERT INTO O_RATTR
	VALUES (788,
	168,
	182,
	150,
	1,
	'value');
INSERT INTO O_ATTR
	VALUES (788,
	168,
	420,
	'answer_value',
	'',
	'answer_',
	'value',
	1,
	12,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1767,
	168);
INSERT INTO O_BATTR
	VALUES (1767,
	168);
INSERT INTO O_ATTR
	VALUES (1767,
	168,
	788,
	'current_state',
	'',
	'',
	'current_state',
	0,
	11,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	168);
INSERT INTO O_OIDA
	VALUES (415,
	168,
	0);
INSERT INTO O_OIDA
	VALUES (420,
	168,
	0);
INSERT INTO O_ID
	VALUES (1,
	168);
INSERT INTO O_ID
	VALUES (2,
	168);
INSERT INTO SM_ISM
	VALUES (1768,
	168);
INSERT INTO SM_SM
	VALUES (1768,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (1768);
INSERT INTO SM_EVTDI
	VALUES (1769,
	1768,
	'digit',
	'',
	7,
	'',
	1770,
	0);
INSERT INTO SM_EVTDI
	VALUES (1771,
	1768,
	'digit',
	'',
	7,
	'',
	1772,
	0);
INSERT INTO SM_LEVT
	VALUES (1772,
	1768,
	0);
INSERT INTO SM_SEVT
	VALUES (1772,
	1768,
	0);
INSERT INTO SM_EVT
	VALUES (1772,
	1768,
	0,
	1,
	'eliminate',
	0,
	'',
	'CELL1',
	'');
INSERT INTO SM_LEVT
	VALUES (1770,
	1768,
	0);
INSERT INTO SM_SEVT
	VALUES (1770,
	1768,
	0);
INSERT INTO SM_EVT
	VALUES (1770,
	1768,
	0,
	2,
	'answer',
	0,
	'',
	'CELL2',
	'');
INSERT INTO SM_STATE
	VALUES (1773,
	1768,
	0,
	'unsolved',
	1,
	0);
INSERT INTO SM_SEME
	VALUES (1773,
	1772,
	1768,
	0);
INSERT INTO SM_SEME
	VALUES (1773,
	1770,
	1768,
	0);
INSERT INTO SM_MOAH
	VALUES (1774,
	1768,
	1773);
INSERT INTO SM_AH
	VALUES (1774,
	1768);
INSERT INTO SM_ACT
	VALUES (1774,
	1768,
	1,
	'// It has been determined that the input digit cannot
// be used in this cell.

// Unlink the eliminated digit.
select any ineligible related by self->ELIGIBLE[R8]
  where ( selected.digit_value == rcvd_evt.digit );
if ( not_empty ineligible )
  select one digit related by ineligible->DIGIT[R8];
  unrelate self from digit across R8 using ineligible;
  // delete object instance ineligible;
  // Inform the row, col and box of the change. 
  // CDS:  Consider polymorphic event here.
  select one row related by self->ROW[R2];
  select one sequence related by row->SEQUENCE[R1];
  if ( not sequence.solved )
    sequence.requests = sequence.requests + 1;
    if ( sequence.requests < 2 )
      generate ROW1:update() to row;
    end if;
  end if;
  select one column related by self->COLUMN[R3];
  select one sequence related by column->SEQUENCE[R1];
  if ( not sequence.solved )
    sequence.requests = sequence.requests + 1;
    if ( sequence.requests < 2 )
      generate COLUMN1:update() to column;
    end if;
  end if;
  select one box related by self->BOX[R4];
  select one sequence related by box->SEQUENCE[R1];
  if ( not sequence.solved )
    sequence.requests = sequence.requests + 1;
    if ( sequence.requests < 2 )
      generate BOX1:update() to box;
    end if;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES (1775,
	1768,
	1774);
INSERT INTO ACT_ACT
	VALUES (1775,
	'state',
	0,
	1776,
	0,
	0,
	'cell::unsolved',
	0);
INSERT INTO ACT_BLK
	VALUES (1776,
	1,
	0,
	1,
	'',
	'',
	'',
	7,
	1,
	5,
	40,
	0,
	0,
	5,
	49,
	0,
	0,
	0,
	0,
	0,
	1775,
	0);
INSERT INTO ACT_SMT
	VALUES (1777,
	1776,
	1778,
	5,
	1,
	'cell::unsolved line: 5');
INSERT INTO ACT_SEL
	VALUES (1777,
	1779,
	1,
	'any',
	1780);
INSERT INTO ACT_SRW
	VALUES (1777,
	1781);
INSERT INTO ACT_LNK
	VALUES (1782,
	'',
	1777,
	383,
	0,
	3,
	382,
	5,
	40,
	5,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1778,
	1776,
	0,
	7,
	1,
	'cell::unsolved line: 7');
INSERT INTO ACT_IF
	VALUES (1778,
	1783,
	1784,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1780,
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	1776);
INSERT INTO V_IRF
	VALUES (1780,
	1785);
INSERT INTO V_VAL
	VALUES (1786,
	0,
	0,
	6,
	11,
	-1,
	0,
	0,
	0,
	0,
	13,
	1776);
INSERT INTO V_SLR
	VALUES (1786,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1787,
	0,
	0,
	6,
	20,
	30,
	0,
	0,
	0,
	0,
	7,
	1776);
INSERT INTO V_AVL
	VALUES (1787,
	1786,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (1781,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1776);
INSERT INTO V_BIN
	VALUES (1781,
	1788,
	1787,
	'==');
INSERT INTO V_VAL
	VALUES (1788,
	0,
	0,
	6,
	44,
	48,
	0,
	0,
	0,
	0,
	7,
	1776);
INSERT INTO V_EDV
	VALUES (1788);
INSERT INTO V_EPR
	VALUES (1788,
	1768,
	1771,
	0);
INSERT INTO V_VAL
	VALUES (1789,
	0,
	0,
	7,
	16,
	25,
	0,
	0,
	0,
	0,
	13,
	1776);
INSERT INTO V_IRF
	VALUES (1789,
	1779);
INSERT INTO V_VAL
	VALUES (1784,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1776);
INSERT INTO V_UNY
	VALUES (1784,
	1789,
	'not_empty');
INSERT INTO V_VAR
	VALUES (1779,
	1776,
	'ineligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (1779,
	0,
	382);
INSERT INTO V_LOC
	VALUES (1790,
	5,
	12,
	21,
	1779);
INSERT INTO V_LOC
	VALUES (1791,
	9,
	44,
	53,
	1779);
INSERT INTO V_VAR
	VALUES (1785,
	1776,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (1785,
	0,
	168);
INSERT INTO V_LOC
	VALUES (1792,
	9,
	12,
	15,
	1785);
INSERT INTO ACT_BLK
	VALUES (1783,
	1,
	0,
	0,
	'',
	'',
	'',
	31,
	3,
	30,
	39,
	0,
	0,
	30,
	48,
	0,
	0,
	0,
	0,
	0,
	1775,
	0);
INSERT INTO ACT_SMT
	VALUES (1793,
	1783,
	1794,
	8,
	3,
	'cell::unsolved line: 8');
INSERT INTO ACT_SEL
	VALUES (1793,
	1795,
	1,
	'one',
	1796);
INSERT INTO ACT_SR
	VALUES (1793);
INSERT INTO ACT_LNK
	VALUES (1797,
	'',
	1793,
	383,
	0,
	2,
	150,
	8,
	43,
	8,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1794,
	1783,
	1798,
	9,
	3,
	'cell::unsolved line: 9');
INSERT INTO ACT_URU
	VALUES (1794,
	1785,
	1795,
	1779,
	'',
	383,
	9,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1798,
	1783,
	1799,
	13,
	3,
	'cell::unsolved line: 13');
INSERT INTO ACT_SEL
	VALUES (1798,
	1800,
	1,
	'one',
	1801);
INSERT INTO ACT_SR
	VALUES (1798);
INSERT INTO ACT_LNK
	VALUES (1802,
	'',
	1798,
	359,
	0,
	2,
	162,
	13,
	35,
	13,
	39,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1799,
	1783,
	1803,
	14,
	3,
	'cell::unsolved line: 14');
INSERT INTO ACT_SEL
	VALUES (1799,
	1804,
	1,
	'one',
	1805);
INSERT INTO ACT_SR
	VALUES (1799);
INSERT INTO ACT_LNK
	VALUES (1806,
	'',
	1799,
	286,
	0,
	2,
	109,
	14,
	39,
	14,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1803,
	1783,
	1807,
	15,
	3,
	'cell::unsolved line: 15');
INSERT INTO ACT_IF
	VALUES (1803,
	1808,
	1809,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1807,
	1783,
	1810,
	21,
	3,
	'cell::unsolved line: 21');
INSERT INTO ACT_SEL
	VALUES (1807,
	1811,
	1,
	'one',
	1812);
INSERT INTO ACT_SR
	VALUES (1807);
INSERT INTO ACT_LNK
	VALUES (1813,
	'',
	1807,
	361,
	0,
	2,
	296,
	21,
	38,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1810,
	1783,
	1814,
	22,
	3,
	'cell::unsolved line: 22');
INSERT INTO ACT_SEL
	VALUES (1810,
	1804,
	0,
	'one',
	1815);
INSERT INTO ACT_SR
	VALUES (1810);
INSERT INTO ACT_LNK
	VALUES (1816,
	'',
	1810,
	286,
	0,
	2,
	109,
	22,
	42,
	22,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1814,
	1783,
	1817,
	23,
	3,
	'cell::unsolved line: 23');
INSERT INTO ACT_IF
	VALUES (1814,
	1818,
	1819,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1817,
	1783,
	1820,
	29,
	3,
	'cell::unsolved line: 29');
INSERT INTO ACT_SEL
	VALUES (1817,
	1821,
	1,
	'one',
	1822);
INSERT INTO ACT_SR
	VALUES (1817);
INSERT INTO ACT_LNK
	VALUES (1823,
	'',
	1817,
	521,
	0,
	2,
	310,
	29,
	35,
	29,
	39,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1820,
	1783,
	1824,
	30,
	3,
	'cell::unsolved line: 30');
INSERT INTO ACT_SEL
	VALUES (1820,
	1804,
	0,
	'one',
	1825);
INSERT INTO ACT_SR
	VALUES (1820);
INSERT INTO ACT_LNK
	VALUES (1826,
	'',
	1820,
	286,
	0,
	2,
	109,
	30,
	39,
	30,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1824,
	1783,
	0,
	31,
	3,
	'cell::unsolved line: 31');
INSERT INTO ACT_IF
	VALUES (1824,
	1827,
	1828,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1796,
	0,
	0,
	8,
	31,
	40,
	0,
	0,
	0,
	0,
	13,
	1783);
INSERT INTO V_IRF
	VALUES (1796,
	1779);
INSERT INTO V_VAL
	VALUES (1801,
	0,
	0,
	13,
	29,
	32,
	0,
	0,
	0,
	0,
	13,
	1783);
INSERT INTO V_IRF
	VALUES (1801,
	1785);
INSERT INTO V_VAL
	VALUES (1805,
	0,
	0,
	14,
	34,
	36,
	0,
	0,
	0,
	0,
	13,
	1783);
INSERT INTO V_IRF
	VALUES (1805,
	1800);
INSERT INTO V_VAL
	VALUES (1829,
	0,
	0,
	15,
	12,
	19,
	0,
	0,
	0,
	0,
	13,
	1783);
INSERT INTO V_IRF
	VALUES (1829,
	1804);
INSERT INTO V_VAL
	VALUES (1830,
	0,
	0,
	15,
	21,
	26,
	0,
	0,
	0,
	0,
	6,
	1783);
INSERT INTO V_AVL
	VALUES (1830,
	1829,
	109,
	318);
INSERT INTO V_VAL
	VALUES (1809,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1783);
INSERT INTO V_UNY
	VALUES (1809,
	1830,
	'not');
INSERT INTO V_VAL
	VALUES (1812,
	0,
	0,
	21,
	32,
	35,
	0,
	0,
	0,
	0,
	13,
	1783);
INSERT INTO V_IRF
	VALUES (1812,
	1785);
INSERT INTO V_VAL
	VALUES (1815,
	0,
	0,
	22,
	34,
	39,
	0,
	0,
	0,
	0,
	13,
	1783);
INSERT INTO V_IRF
	VALUES (1815,
	1811);
INSERT INTO V_VAL
	VALUES (1831,
	0,
	0,
	23,
	12,
	19,
	0,
	0,
	0,
	0,
	13,
	1783);
INSERT INTO V_IRF
	VALUES (1831,
	1804);
INSERT INTO V_VAL
	VALUES (1832,
	0,
	0,
	23,
	21,
	26,
	0,
	0,
	0,
	0,
	6,
	1783);
INSERT INTO V_AVL
	VALUES (1832,
	1831,
	109,
	318);
INSERT INTO V_VAL
	VALUES (1819,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1783);
INSERT INTO V_UNY
	VALUES (1819,
	1832,
	'not');
INSERT INTO V_VAL
	VALUES (1822,
	0,
	0,
	29,
	29,
	32,
	0,
	0,
	0,
	0,
	13,
	1783);
INSERT INTO V_IRF
	VALUES (1822,
	1785);
INSERT INTO V_VAL
	VALUES (1825,
	0,
	0,
	30,
	34,
	36,
	0,
	0,
	0,
	0,
	13,
	1783);
INSERT INTO V_IRF
	VALUES (1825,
	1821);
INSERT INTO V_VAL
	VALUES (1833,
	0,
	0,
	31,
	12,
	19,
	0,
	0,
	0,
	0,
	13,
	1783);
INSERT INTO V_IRF
	VALUES (1833,
	1804);
INSERT INTO V_VAL
	VALUES (1834,
	0,
	0,
	31,
	21,
	26,
	0,
	0,
	0,
	0,
	6,
	1783);
INSERT INTO V_AVL
	VALUES (1834,
	1833,
	109,
	318);
INSERT INTO V_VAL
	VALUES (1828,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1783);
INSERT INTO V_UNY
	VALUES (1828,
	1834,
	'not');
INSERT INTO V_VAR
	VALUES (1795,
	1783,
	'digit',
	1,
	13);
INSERT INTO V_INT
	VALUES (1795,
	0,
	150);
INSERT INTO V_LOC
	VALUES (1835,
	8,
	14,
	18,
	1795);
INSERT INTO V_LOC
	VALUES (1836,
	9,
	22,
	26,
	1795);
INSERT INTO V_VAR
	VALUES (1800,
	1783,
	'row',
	1,
	13);
INSERT INTO V_INT
	VALUES (1800,
	0,
	162);
INSERT INTO V_LOC
	VALUES (1837,
	13,
	14,
	16,
	1800);
INSERT INTO V_LOC
	VALUES (1838,
	18,
	33,
	35,
	1800);
INSERT INTO V_VAR
	VALUES (1804,
	1783,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (1804,
	0,
	109);
INSERT INTO V_LOC
	VALUES (1839,
	14,
	14,
	21,
	1804);
INSERT INTO V_LOC
	VALUES (1840,
	15,
	12,
	19,
	1804);
INSERT INTO V_LOC
	VALUES (1841,
	16,
	5,
	12,
	1804);
INSERT INTO V_LOC
	VALUES (1842,
	16,
	25,
	32,
	1804);
INSERT INTO V_LOC
	VALUES (1843,
	17,
	10,
	17,
	1804);
INSERT INTO V_LOC
	VALUES (1844,
	22,
	14,
	21,
	1804);
INSERT INTO V_LOC
	VALUES (1845,
	23,
	12,
	19,
	1804);
INSERT INTO V_LOC
	VALUES (1846,
	24,
	5,
	12,
	1804);
INSERT INTO V_LOC
	VALUES (1847,
	24,
	25,
	32,
	1804);
INSERT INTO V_LOC
	VALUES (1848,
	25,
	10,
	17,
	1804);
INSERT INTO V_LOC
	VALUES (1849,
	30,
	14,
	21,
	1804);
INSERT INTO V_LOC
	VALUES (1850,
	31,
	12,
	19,
	1804);
INSERT INTO V_LOC
	VALUES (1851,
	32,
	5,
	12,
	1804);
INSERT INTO V_LOC
	VALUES (1852,
	32,
	25,
	32,
	1804);
INSERT INTO V_LOC
	VALUES (1853,
	33,
	10,
	17,
	1804);
INSERT INTO V_VAR
	VALUES (1811,
	1783,
	'column',
	1,
	13);
INSERT INTO V_INT
	VALUES (1811,
	0,
	296);
INSERT INTO V_LOC
	VALUES (1854,
	21,
	14,
	19,
	1811);
INSERT INTO V_LOC
	VALUES (1855,
	26,
	36,
	41,
	1811);
INSERT INTO V_VAR
	VALUES (1821,
	1783,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (1821,
	0,
	310);
INSERT INTO V_LOC
	VALUES (1856,
	29,
	14,
	16,
	1821);
INSERT INTO V_LOC
	VALUES (1857,
	34,
	33,
	35,
	1821);
INSERT INTO ACT_BLK
	VALUES (1808,
	0,
	0,
	0,
	'',
	'',
	'',
	17,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1775,
	0);
INSERT INTO ACT_SMT
	VALUES (1858,
	1808,
	1859,
	16,
	5,
	'cell::unsolved line: 16');
INSERT INTO ACT_AI
	VALUES (1858,
	1860,
	1861,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1859,
	1808,
	0,
	17,
	5,
	'cell::unsolved line: 17');
INSERT INTO ACT_IF
	VALUES (1859,
	1862,
	1863,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1864,
	1,
	0,
	16,
	5,
	12,
	0,
	0,
	0,
	0,
	13,
	1808);
INSERT INTO V_IRF
	VALUES (1864,
	1804);
INSERT INTO V_VAL
	VALUES (1861,
	1,
	0,
	16,
	14,
	21,
	0,
	0,
	0,
	0,
	7,
	1808);
INSERT INTO V_AVL
	VALUES (1861,
	1864,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1865,
	0,
	0,
	16,
	25,
	32,
	0,
	0,
	0,
	0,
	13,
	1808);
INSERT INTO V_IRF
	VALUES (1865,
	1804);
INSERT INTO V_VAL
	VALUES (1866,
	0,
	0,
	16,
	34,
	41,
	0,
	0,
	0,
	0,
	7,
	1808);
INSERT INTO V_AVL
	VALUES (1866,
	1865,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1860,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	1808);
INSERT INTO V_BIN
	VALUES (1860,
	1867,
	1866,
	'+');
INSERT INTO V_VAL
	VALUES (1867,
	0,
	0,
	16,
	45,
	45,
	0,
	0,
	0,
	0,
	7,
	1808);
INSERT INTO V_LIN
	VALUES (1867,
	'1');
INSERT INTO V_VAL
	VALUES (1868,
	0,
	0,
	17,
	10,
	17,
	0,
	0,
	0,
	0,
	13,
	1808);
INSERT INTO V_IRF
	VALUES (1868,
	1804);
INSERT INTO V_VAL
	VALUES (1869,
	0,
	0,
	17,
	19,
	26,
	0,
	0,
	0,
	0,
	7,
	1808);
INSERT INTO V_AVL
	VALUES (1869,
	1868,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1863,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1808);
INSERT INTO V_BIN
	VALUES (1863,
	1870,
	1869,
	'<');
INSERT INTO V_VAL
	VALUES (1870,
	0,
	0,
	17,
	30,
	30,
	0,
	0,
	0,
	0,
	7,
	1808);
INSERT INTO V_LIN
	VALUES (1870,
	'2');
INSERT INTO ACT_BLK
	VALUES (1862,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	18,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1775,
	0);
INSERT INTO ACT_SMT
	VALUES (1871,
	1862,
	0,
	18,
	7,
	'cell::unsolved line: 18');
INSERT INTO E_ESS
	VALUES (1871,
	1,
	0,
	18,
	16,
	18,
	21,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1871);
INSERT INTO E_GSME
	VALUES (1871,
	1347,
	1348);
INSERT INTO E_GEN
	VALUES (1871,
	1800);
INSERT INTO ACT_BLK
	VALUES (1818,
	0,
	0,
	0,
	'',
	'',
	'',
	25,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1775,
	0);
INSERT INTO ACT_SMT
	VALUES (1872,
	1818,
	1873,
	24,
	5,
	'cell::unsolved line: 24');
INSERT INTO ACT_AI
	VALUES (1872,
	1874,
	1875,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1873,
	1818,
	0,
	25,
	5,
	'cell::unsolved line: 25');
INSERT INTO ACT_IF
	VALUES (1873,
	1876,
	1877,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1878,
	1,
	0,
	24,
	5,
	12,
	0,
	0,
	0,
	0,
	13,
	1818);
INSERT INTO V_IRF
	VALUES (1878,
	1804);
INSERT INTO V_VAL
	VALUES (1875,
	1,
	0,
	24,
	14,
	21,
	0,
	0,
	0,
	0,
	7,
	1818);
INSERT INTO V_AVL
	VALUES (1875,
	1878,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1879,
	0,
	0,
	24,
	25,
	32,
	0,
	0,
	0,
	0,
	13,
	1818);
INSERT INTO V_IRF
	VALUES (1879,
	1804);
INSERT INTO V_VAL
	VALUES (1880,
	0,
	0,
	24,
	34,
	41,
	0,
	0,
	0,
	0,
	7,
	1818);
INSERT INTO V_AVL
	VALUES (1880,
	1879,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1874,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	1818);
INSERT INTO V_BIN
	VALUES (1874,
	1881,
	1880,
	'+');
INSERT INTO V_VAL
	VALUES (1881,
	0,
	0,
	24,
	45,
	45,
	0,
	0,
	0,
	0,
	7,
	1818);
INSERT INTO V_LIN
	VALUES (1881,
	'1');
INSERT INTO V_VAL
	VALUES (1882,
	0,
	0,
	25,
	10,
	17,
	0,
	0,
	0,
	0,
	13,
	1818);
INSERT INTO V_IRF
	VALUES (1882,
	1804);
INSERT INTO V_VAL
	VALUES (1883,
	0,
	0,
	25,
	19,
	26,
	0,
	0,
	0,
	0,
	7,
	1818);
INSERT INTO V_AVL
	VALUES (1883,
	1882,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1877,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1818);
INSERT INTO V_BIN
	VALUES (1877,
	1884,
	1883,
	'<');
INSERT INTO V_VAL
	VALUES (1884,
	0,
	0,
	25,
	30,
	30,
	0,
	0,
	0,
	0,
	7,
	1818);
INSERT INTO V_LIN
	VALUES (1884,
	'2');
INSERT INTO ACT_BLK
	VALUES (1876,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	26,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1775,
	0);
INSERT INTO ACT_SMT
	VALUES (1885,
	1876,
	0,
	26,
	7,
	'cell::unsolved line: 26');
INSERT INTO E_ESS
	VALUES (1885,
	1,
	0,
	26,
	16,
	26,
	24,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1885);
INSERT INTO E_GSME
	VALUES (1885,
	1886,
	1887);
INSERT INTO E_GEN
	VALUES (1885,
	1811);
INSERT INTO ACT_BLK
	VALUES (1827,
	0,
	0,
	0,
	'',
	'',
	'',
	33,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1775,
	0);
INSERT INTO ACT_SMT
	VALUES (1888,
	1827,
	1889,
	32,
	5,
	'cell::unsolved line: 32');
INSERT INTO ACT_AI
	VALUES (1888,
	1890,
	1891,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1889,
	1827,
	0,
	33,
	5,
	'cell::unsolved line: 33');
INSERT INTO ACT_IF
	VALUES (1889,
	1892,
	1893,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1894,
	1,
	0,
	32,
	5,
	12,
	0,
	0,
	0,
	0,
	13,
	1827);
INSERT INTO V_IRF
	VALUES (1894,
	1804);
INSERT INTO V_VAL
	VALUES (1891,
	1,
	0,
	32,
	14,
	21,
	0,
	0,
	0,
	0,
	7,
	1827);
INSERT INTO V_AVL
	VALUES (1891,
	1894,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1895,
	0,
	0,
	32,
	25,
	32,
	0,
	0,
	0,
	0,
	13,
	1827);
INSERT INTO V_IRF
	VALUES (1895,
	1804);
INSERT INTO V_VAL
	VALUES (1896,
	0,
	0,
	32,
	34,
	41,
	0,
	0,
	0,
	0,
	7,
	1827);
INSERT INTO V_AVL
	VALUES (1896,
	1895,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1890,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	1827);
INSERT INTO V_BIN
	VALUES (1890,
	1897,
	1896,
	'+');
INSERT INTO V_VAL
	VALUES (1897,
	0,
	0,
	32,
	45,
	45,
	0,
	0,
	0,
	0,
	7,
	1827);
INSERT INTO V_LIN
	VALUES (1897,
	'1');
INSERT INTO V_VAL
	VALUES (1898,
	0,
	0,
	33,
	10,
	17,
	0,
	0,
	0,
	0,
	13,
	1827);
INSERT INTO V_IRF
	VALUES (1898,
	1804);
INSERT INTO V_VAL
	VALUES (1899,
	0,
	0,
	33,
	19,
	26,
	0,
	0,
	0,
	0,
	7,
	1827);
INSERT INTO V_AVL
	VALUES (1899,
	1898,
	109,
	320);
INSERT INTO V_VAL
	VALUES (1893,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1827);
INSERT INTO V_BIN
	VALUES (1893,
	1900,
	1899,
	'<');
INSERT INTO V_VAL
	VALUES (1900,
	0,
	0,
	33,
	30,
	30,
	0,
	0,
	0,
	0,
	7,
	1827);
INSERT INTO V_LIN
	VALUES (1900,
	'2');
INSERT INTO ACT_BLK
	VALUES (1892,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	34,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1775,
	0);
INSERT INTO ACT_SMT
	VALUES (1901,
	1892,
	0,
	34,
	7,
	'cell::unsolved line: 34');
INSERT INTO E_ESS
	VALUES (1901,
	1,
	0,
	34,
	16,
	34,
	21,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1901);
INSERT INTO E_GSME
	VALUES (1901,
	1582,
	1581);
INSERT INTO E_GEN
	VALUES (1901,
	1821);
INSERT INTO SM_STATE
	VALUES (1902,
	1768,
	0,
	'solved',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES (1902,
	1772,
	1768,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (1902,
	1772,
	1768,
	0);
INSERT INTO SM_EIGN
	VALUES (1902,
	1770,
	1768,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (1902,
	1770,
	1768,
	0);
INSERT INTO SM_MOAH
	VALUES (1903,
	1768,
	1902);
INSERT INTO SM_AH
	VALUES (1903,
	1768);
INSERT INTO SM_ACT
	VALUES (1903,
	1768,
	1,
	'// An answer has been found, so remove the eligible
// digits which are now ineligible digits.

// Link in the answer.
// CDS:  Consider selecting across R8 here.
select any digit from instances of DIGIT 
  where ( selected.value == rcvd_evt.digit );
if ( not_empty digit )
  relate self to digit across R9;
end if;

// Unlink the other digits.  There can be only one answer.
select many ineligibles related by self->ELIGIBLE[R8];
for each ineligible in ineligibles
  select one digit related by ineligible->DIGIT[R8];
  unrelate self from digit across R8 using ineligible;
  // delete object instance ineligible;
end for;

// CDS:  Inform the row, col and box that there is a change.',
	'');
INSERT INTO ACT_SAB
	VALUES (1904,
	1768,
	1903);
INSERT INTO ACT_ACT
	VALUES (1904,
	'state',
	0,
	1905,
	0,
	0,
	'cell::solved',
	0);
INSERT INTO ACT_BLK
	VALUES (1905,
	1,
	0,
	1,
	'',
	'',
	'',
	14,
	1,
	13,
	42,
	0,
	0,
	13,
	51,
	0,
	0,
	0,
	0,
	0,
	1904,
	0);
INSERT INTO ACT_SMT
	VALUES (1906,
	1905,
	1907,
	6,
	1,
	'cell::solved line: 6');
INSERT INTO ACT_FIW
	VALUES (1906,
	1908,
	1,
	'any',
	1909,
	150,
	6,
	36);
INSERT INTO ACT_SMT
	VALUES (1907,
	1905,
	1910,
	8,
	1,
	'cell::solved line: 8');
INSERT INTO ACT_IF
	VALUES (1907,
	1911,
	1912,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1910,
	1905,
	1913,
	13,
	1,
	'cell::solved line: 13');
INSERT INTO ACT_SEL
	VALUES (1910,
	1914,
	1,
	'many',
	1915);
INSERT INTO ACT_SR
	VALUES (1910);
INSERT INTO ACT_LNK
	VALUES (1916,
	'',
	1910,
	383,
	0,
	3,
	382,
	13,
	42,
	13,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1913,
	1905,
	0,
	14,
	1,
	'cell::solved line: 14');
INSERT INTO ACT_FOR
	VALUES (1913,
	1917,
	1,
	1918,
	1914,
	382);
INSERT INTO V_VAL
	VALUES (1919,
	0,
	0,
	7,
	11,
	-1,
	0,
	0,
	0,
	0,
	13,
	1905);
INSERT INTO V_SLR
	VALUES (1919,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1920,
	0,
	0,
	7,
	20,
	24,
	0,
	0,
	0,
	0,
	7,
	1905);
INSERT INTO V_AVL
	VALUES (1920,
	1919,
	150,
	182);
INSERT INTO V_VAL
	VALUES (1909,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1905);
INSERT INTO V_BIN
	VALUES (1909,
	1921,
	1920,
	'==');
INSERT INTO V_VAL
	VALUES (1921,
	0,
	0,
	7,
	38,
	42,
	0,
	0,
	0,
	0,
	7,
	1905);
INSERT INTO V_EDV
	VALUES (1921);
INSERT INTO V_EPR
	VALUES (1921,
	1768,
	1769,
	0);
INSERT INTO V_VAL
	VALUES (1922,
	0,
	0,
	8,
	16,
	20,
	0,
	0,
	0,
	0,
	13,
	1905);
INSERT INTO V_IRF
	VALUES (1922,
	1908);
INSERT INTO V_VAL
	VALUES (1912,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1905);
INSERT INTO V_UNY
	VALUES (1912,
	1922,
	'not_empty');
INSERT INTO V_VAL
	VALUES (1915,
	0,
	0,
	13,
	36,
	39,
	0,
	0,
	0,
	0,
	13,
	1905);
INSERT INTO V_IRF
	VALUES (1915,
	1923);
INSERT INTO V_VAR
	VALUES (1908,
	1905,
	'digit',
	1,
	13);
INSERT INTO V_INT
	VALUES (1908,
	0,
	150);
INSERT INTO V_LOC
	VALUES (1924,
	6,
	12,
	16,
	1908);
INSERT INTO V_LOC
	VALUES (1925,
	9,
	18,
	22,
	1908);
INSERT INTO V_LOC
	VALUES (1926,
	15,
	14,
	18,
	1908);
INSERT INTO V_LOC
	VALUES (1927,
	16,
	22,
	26,
	1908);
INSERT INTO V_VAR
	VALUES (1923,
	1905,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (1923,
	0,
	168);
INSERT INTO V_LOC
	VALUES (1928,
	9,
	10,
	13,
	1923);
INSERT INTO V_LOC
	VALUES (1929,
	16,
	12,
	15,
	1923);
INSERT INTO V_VAR
	VALUES (1914,
	1905,
	'ineligibles',
	1,
	14);
INSERT INTO V_INS
	VALUES (1914,
	382);
INSERT INTO V_LOC
	VALUES (1930,
	13,
	13,
	23,
	1914);
INSERT INTO V_LOC
	VALUES (1931,
	14,
	24,
	34,
	1914);
INSERT INTO V_VAR
	VALUES (1918,
	1905,
	'ineligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (1918,
	1,
	382);
INSERT INTO V_LOC
	VALUES (1932,
	14,
	10,
	19,
	1918);
INSERT INTO V_LOC
	VALUES (1933,
	16,
	44,
	53,
	1918);
INSERT INTO ACT_BLK
	VALUES (1911,
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	0,
	0,
	0,
	0,
	9,
	31,
	0,
	0,
	0,
	0,
	0,
	1904,
	0);
INSERT INTO ACT_SMT
	VALUES (1934,
	1911,
	0,
	9,
	3,
	'cell::solved line: 9');
INSERT INTO ACT_REL
	VALUES (1934,
	1923,
	1908,
	'',
	357,
	9,
	31,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (1917,
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	3,
	15,
	43,
	0,
	0,
	16,
	35,
	0,
	0,
	0,
	0,
	0,
	1904,
	0);
INSERT INTO ACT_SMT
	VALUES (1935,
	1917,
	1936,
	15,
	3,
	'cell::solved line: 15');
INSERT INTO ACT_SEL
	VALUES (1935,
	1908,
	0,
	'one',
	1937);
INSERT INTO ACT_SR
	VALUES (1935);
INSERT INTO ACT_LNK
	VALUES (1938,
	'',
	1935,
	383,
	0,
	2,
	150,
	15,
	43,
	15,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1936,
	1917,
	0,
	16,
	3,
	'cell::solved line: 16');
INSERT INTO ACT_URU
	VALUES (1936,
	1923,
	1908,
	1918,
	'',
	383,
	16,
	35,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1937,
	0,
	0,
	15,
	31,
	40,
	0,
	0,
	0,
	0,
	13,
	1917);
INSERT INTO V_IRF
	VALUES (1937,
	1918);
INSERT INTO SM_NSTXN
	VALUES (1939,
	1768,
	1773,
	1770,
	0);
INSERT INTO SM_TAH
	VALUES (1940,
	1768,
	1939);
INSERT INTO SM_AH
	VALUES (1940,
	1768);
INSERT INTO SM_ACT
	VALUES (1940,
	1768,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (1941,
	1768,
	1940);
INSERT INTO ACT_ACT
	VALUES (1941,
	'transition',
	0,
	1942,
	0,
	0,
	'CELL2: answer in unsolved to solved',
	0);
INSERT INTO ACT_BLK
	VALUES (1942,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1941,
	0);
INSERT INTO SM_TXN
	VALUES (1939,
	1768,
	1902,
	0);
INSERT INTO SM_NSTXN
	VALUES (1943,
	1768,
	1773,
	1772,
	0);
INSERT INTO SM_TAH
	VALUES (1944,
	1768,
	1943);
INSERT INTO SM_AH
	VALUES (1944,
	1768);
INSERT INTO SM_ACT
	VALUES (1944,
	1768,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (1945,
	1768,
	1944);
INSERT INTO ACT_ACT
	VALUES (1945,
	'transition',
	0,
	1946,
	0,
	0,
	'CELL1: eliminate in unsolved to unsolved',
	0);
INSERT INTO ACT_BLK
	VALUES (1946,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1945,
	0);
INSERT INTO SM_TXN
	VALUES (1943,
	1768,
	1773,
	0);
INSERT INTO O_OBJ
	VALUES (296,
	'column',
	3,
	'COLUMN',
	'',
	1374);
INSERT INTO O_TFR
	VALUES (1947,
	296,
	'prune',
	'',
	7,
	1,
	'// Eliminate eligible digits that match any answer digit for this sequence.

temperature = 0;
select many answerdigits related by self->CELL[R3]->DIGIT[R9] where ( selected.value != 0 );
select many eligibles related by self->CELL[R3]->ELIGIBLE[R8];
for each eligible in eligibles
  for each answerdigit in answerdigits
    if ( eligible.digit_value == answerdigit.value )
      select one opencell related by eligible->CELL[R8];
      if ( opencell.answer_value != eligible.digit_value )
        unrelate answerdigit from opencell across R8 using eligible;
        delete object instance eligible;
        // generate CELL1:eliminate( digit:answerdigit.value ) to opencell;
      end if;
      temperature = 1;
      break;
    end if;
  end for;
end for;
  
select many opencells related by self->CELL[R3]
  where ( selected.answer_value == 0 );
if ( empty opencells )
  temperature = 100;
end if;
for each opencell in opencells
  // Notice if we have the answer now.
  select many eligibles related by opencell->ELIGIBLE[R8];
  c = cardinality eligibles;
  if ( 1 == c )
    select any answer related by opencell->ELIGIBLE[R8];
    opencell.answer( answer_digit:answer.digit_value );
    // generate CELL2:answer( digit:answer.digit_value ) to opencell;
    temperature = 1;
  end if;
end for;

return temperature;
',
	1,
	'',
	1948);
INSERT INTO ACT_OPB
	VALUES (1949,
	1947);
INSERT INTO ACT_ACT
	VALUES (1949,
	'operation',
	0,
	1950,
	0,
	0,
	'column::prune',
	0);
INSERT INTO ACT_BLK
	VALUES (1950,
	1,
	0,
	1,
	'',
	'',
	'',
	38,
	1,
	21,
	40,
	0,
	0,
	21,
	45,
	0,
	0,
	0,
	0,
	0,
	1949,
	0);
INSERT INTO ACT_SMT
	VALUES (1951,
	1950,
	1952,
	3,
	1,
	'column::prune line: 3');
INSERT INTO ACT_AI
	VALUES (1951,
	1953,
	1954,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1952,
	1950,
	1955,
	4,
	1,
	'column::prune line: 4');
INSERT INTO ACT_SEL
	VALUES (1952,
	1956,
	1,
	'many',
	1957);
INSERT INTO ACT_SRW
	VALUES (1952,
	1958);
INSERT INTO ACT_LNK
	VALUES (1959,
	'',
	1952,
	361,
	1960,
	3,
	168,
	4,
	43,
	4,
	48,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (1960,
	'',
	0,
	357,
	0,
	2,
	150,
	4,
	53,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1955,
	1950,
	1961,
	5,
	1,
	'column::prune line: 5');
INSERT INTO ACT_SEL
	VALUES (1955,
	1962,
	1,
	'many',
	1963);
INSERT INTO ACT_SR
	VALUES (1955);
INSERT INTO ACT_LNK
	VALUES (1964,
	'',
	1955,
	361,
	1965,
	3,
	168,
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (1965,
	'',
	0,
	383,
	0,
	3,
	382,
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1961,
	1950,
	1966,
	6,
	1,
	'column::prune line: 6');
INSERT INTO ACT_FOR
	VALUES (1961,
	1967,
	1,
	1968,
	1962,
	382);
INSERT INTO ACT_SMT
	VALUES (1966,
	1950,
	1969,
	21,
	1,
	'column::prune line: 21');
INSERT INTO ACT_SEL
	VALUES (1966,
	1970,
	1,
	'many',
	1971);
INSERT INTO ACT_SRW
	VALUES (1966,
	1972);
INSERT INTO ACT_LNK
	VALUES (1973,
	'',
	1966,
	361,
	0,
	3,
	168,
	21,
	40,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1969,
	1950,
	1974,
	23,
	1,
	'column::prune line: 23');
INSERT INTO ACT_IF
	VALUES (1969,
	1975,
	1976,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1974,
	1950,
	1977,
	26,
	1,
	'column::prune line: 26');
INSERT INTO ACT_FOR
	VALUES (1974,
	1978,
	1,
	1979,
	1970,
	168);
INSERT INTO ACT_SMT
	VALUES (1977,
	1950,
	0,
	38,
	1,
	'column::prune line: 38');
INSERT INTO ACT_RET
	VALUES (1977,
	1980);
INSERT INTO V_VAL
	VALUES (1954,
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	7,
	1950);
INSERT INTO V_TVL
	VALUES (1954,
	1981);
INSERT INTO V_VAL
	VALUES (1953,
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	7,
	1950);
INSERT INTO V_LIN
	VALUES (1953,
	'0');
INSERT INTO V_VAL
	VALUES (1957,
	0,
	0,
	4,
	37,
	40,
	0,
	0,
	0,
	0,
	13,
	1950);
INSERT INTO V_IRF
	VALUES (1957,
	1982);
INSERT INTO V_VAL
	VALUES (1983,
	0,
	0,
	4,
	71,
	-1,
	0,
	0,
	0,
	0,
	13,
	1950);
INSERT INTO V_SLR
	VALUES (1983,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1984,
	0,
	0,
	4,
	80,
	84,
	0,
	0,
	0,
	0,
	7,
	1950);
INSERT INTO V_AVL
	VALUES (1984,
	1983,
	150,
	182);
INSERT INTO V_VAL
	VALUES (1958,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1950);
INSERT INTO V_BIN
	VALUES (1958,
	1985,
	1984,
	'!=');
INSERT INTO V_VAL
	VALUES (1985,
	0,
	0,
	4,
	89,
	89,
	0,
	0,
	0,
	0,
	7,
	1950);
INSERT INTO V_LIN
	VALUES (1985,
	'0');
INSERT INTO V_VAL
	VALUES (1963,
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	1950);
INSERT INTO V_IRF
	VALUES (1963,
	1982);
INSERT INTO V_VAL
	VALUES (1971,
	0,
	0,
	21,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	1950);
INSERT INTO V_IRF
	VALUES (1971,
	1982);
INSERT INTO V_VAL
	VALUES (1986,
	0,
	0,
	22,
	11,
	-1,
	0,
	0,
	0,
	0,
	13,
	1950);
INSERT INTO V_SLR
	VALUES (1986,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1987,
	0,
	0,
	22,
	20,
	31,
	0,
	0,
	0,
	0,
	7,
	1950);
INSERT INTO V_AVL
	VALUES (1987,
	1986,
	168,
	788);
INSERT INTO V_VAL
	VALUES (1972,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1950);
INSERT INTO V_BIN
	VALUES (1972,
	1988,
	1987,
	'==');
INSERT INTO V_VAL
	VALUES (1988,
	0,
	0,
	22,
	36,
	36,
	0,
	0,
	0,
	0,
	7,
	1950);
INSERT INTO V_LIN
	VALUES (1988,
	'0');
INSERT INTO V_VAL
	VALUES (1989,
	0,
	0,
	23,
	12,
	20,
	0,
	0,
	0,
	0,
	14,
	1950);
INSERT INTO V_ISR
	VALUES (1989,
	1970);
INSERT INTO V_VAL
	VALUES (1976,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1950);
INSERT INTO V_UNY
	VALUES (1976,
	1989,
	'empty');
INSERT INTO V_VAL
	VALUES (1980,
	0,
	0,
	38,
	8,
	18,
	0,
	0,
	0,
	0,
	7,
	1950);
INSERT INTO V_TVL
	VALUES (1980,
	1981);
INSERT INTO V_VAR
	VALUES (1981,
	1950,
	'temperature',
	1,
	7);
INSERT INTO V_TRN
	VALUES (1981,
	0,
	'');
INSERT INTO V_LOC
	VALUES (1990,
	3,
	1,
	11,
	1981);
INSERT INTO V_LOC
	VALUES (1991,
	15,
	7,
	17,
	1981);
INSERT INTO V_LOC
	VALUES (1992,
	24,
	3,
	13,
	1981);
INSERT INTO V_LOC
	VALUES (1993,
	34,
	5,
	15,
	1981);
INSERT INTO V_LOC
	VALUES (1994,
	38,
	8,
	18,
	1981);
INSERT INTO V_VAR
	VALUES (1956,
	1950,
	'answerdigits',
	1,
	14);
INSERT INTO V_INS
	VALUES (1956,
	150);
INSERT INTO V_LOC
	VALUES (1995,
	4,
	13,
	24,
	1956);
INSERT INTO V_LOC
	VALUES (1996,
	7,
	27,
	38,
	1956);
INSERT INTO V_VAR
	VALUES (1982,
	1950,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (1982,
	0,
	296);
INSERT INTO V_VAR
	VALUES (1962,
	1950,
	'eligibles',
	1,
	14);
INSERT INTO V_INS
	VALUES (1962,
	382);
INSERT INTO V_LOC
	VALUES (1997,
	5,
	13,
	21,
	1962);
INSERT INTO V_LOC
	VALUES (1998,
	6,
	22,
	30,
	1962);
INSERT INTO V_LOC
	VALUES (1999,
	28,
	15,
	23,
	1962);
INSERT INTO V_VAR
	VALUES (1968,
	1950,
	'eligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (1968,
	1,
	382);
INSERT INTO V_LOC
	VALUES (2000,
	6,
	10,
	17,
	1968);
INSERT INTO V_LOC
	VALUES (2001,
	8,
	10,
	17,
	1968);
INSERT INTO V_LOC
	VALUES (2002,
	10,
	37,
	44,
	1968);
INSERT INTO V_LOC
	VALUES (2003,
	11,
	60,
	67,
	1968);
INSERT INTO V_LOC
	VALUES (2004,
	12,
	32,
	39,
	1968);
INSERT INTO V_VAR
	VALUES (1970,
	1950,
	'opencells',
	1,
	14);
INSERT INTO V_INS
	VALUES (1970,
	168);
INSERT INTO V_LOC
	VALUES (2005,
	21,
	13,
	21,
	1970);
INSERT INTO V_LOC
	VALUES (2006,
	26,
	22,
	30,
	1970);
INSERT INTO V_VAR
	VALUES (1979,
	1950,
	'opencell',
	1,
	13);
INSERT INTO V_INT
	VALUES (1979,
	1,
	168);
INSERT INTO V_LOC
	VALUES (2007,
	26,
	10,
	17,
	1979);
INSERT INTO V_LOC
	VALUES (2008,
	32,
	5,
	12,
	1979);
INSERT INTO ACT_BLK
	VALUES (1967,
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1949,
	0);
INSERT INTO ACT_SMT
	VALUES (2009,
	1967,
	0,
	7,
	3,
	'column::prune line: 7');
INSERT INTO ACT_FOR
	VALUES (2009,
	2010,
	1,
	2011,
	1956,
	150);
INSERT INTO V_VAR
	VALUES (2011,
	1967,
	'answerdigit',
	1,
	13);
INSERT INTO V_INT
	VALUES (2011,
	1,
	150);
INSERT INTO V_LOC
	VALUES (2012,
	7,
	12,
	22,
	2011);
INSERT INTO V_LOC
	VALUES (2013,
	8,
	34,
	44,
	2011);
INSERT INTO V_LOC
	VALUES (2014,
	11,
	18,
	28,
	2011);
INSERT INTO ACT_BLK
	VALUES (2010,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1949,
	0);
INSERT INTO ACT_SMT
	VALUES (2015,
	2010,
	0,
	8,
	5,
	'column::prune line: 8');
INSERT INTO ACT_IF
	VALUES (2015,
	2016,
	2017,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2018,
	0,
	0,
	8,
	10,
	17,
	0,
	0,
	0,
	0,
	13,
	2010);
INSERT INTO V_IRF
	VALUES (2018,
	1968);
INSERT INTO V_VAL
	VALUES (2019,
	0,
	0,
	8,
	19,
	29,
	0,
	0,
	0,
	0,
	7,
	2010);
INSERT INTO V_AVL
	VALUES (2019,
	2018,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (2017,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2010);
INSERT INTO V_BIN
	VALUES (2017,
	2020,
	2019,
	'==');
INSERT INTO V_VAL
	VALUES (2021,
	0,
	0,
	8,
	34,
	44,
	0,
	0,
	0,
	0,
	13,
	2010);
INSERT INTO V_IRF
	VALUES (2021,
	2011);
INSERT INTO V_VAL
	VALUES (2020,
	0,
	0,
	8,
	46,
	50,
	0,
	0,
	0,
	0,
	7,
	2010);
INSERT INTO V_AVL
	VALUES (2020,
	2021,
	150,
	182);
INSERT INTO ACT_BLK
	VALUES (2016,
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	7,
	9,
	48,
	0,
	0,
	9,
	53,
	0,
	0,
	0,
	0,
	0,
	1949,
	0);
INSERT INTO ACT_SMT
	VALUES (2022,
	2016,
	2023,
	9,
	7,
	'column::prune line: 9');
INSERT INTO ACT_SEL
	VALUES (2022,
	2024,
	1,
	'one',
	2025);
INSERT INTO ACT_SR
	VALUES (2022);
INSERT INTO ACT_LNK
	VALUES (2026,
	'',
	2022,
	383,
	0,
	2,
	168,
	9,
	48,
	9,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2023,
	2016,
	2027,
	10,
	7,
	'column::prune line: 10');
INSERT INTO ACT_IF
	VALUES (2023,
	2028,
	2029,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2027,
	2016,
	2030,
	15,
	7,
	'column::prune line: 15');
INSERT INTO ACT_AI
	VALUES (2027,
	2031,
	2032,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2030,
	2016,
	0,
	16,
	7,
	'column::prune line: 16');
INSERT INTO ACT_BRK
	VALUES (2030);
INSERT INTO V_VAL
	VALUES (2025,
	0,
	0,
	9,
	38,
	45,
	0,
	0,
	0,
	0,
	13,
	2016);
INSERT INTO V_IRF
	VALUES (2025,
	1968);
INSERT INTO V_VAL
	VALUES (2033,
	0,
	0,
	10,
	12,
	19,
	0,
	0,
	0,
	0,
	13,
	2016);
INSERT INTO V_IRF
	VALUES (2033,
	2024);
INSERT INTO V_VAL
	VALUES (2034,
	0,
	0,
	10,
	21,
	32,
	0,
	0,
	0,
	0,
	7,
	2016);
INSERT INTO V_AVL
	VALUES (2034,
	2033,
	168,
	788);
INSERT INTO V_VAL
	VALUES (2029,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2016);
INSERT INTO V_BIN
	VALUES (2029,
	2035,
	2034,
	'!=');
INSERT INTO V_VAL
	VALUES (2036,
	0,
	0,
	10,
	37,
	44,
	0,
	0,
	0,
	0,
	13,
	2016);
INSERT INTO V_IRF
	VALUES (2036,
	1968);
INSERT INTO V_VAL
	VALUES (2035,
	0,
	0,
	10,
	46,
	56,
	0,
	0,
	0,
	0,
	7,
	2016);
INSERT INTO V_AVL
	VALUES (2035,
	2036,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (2032,
	1,
	0,
	15,
	7,
	17,
	0,
	0,
	0,
	0,
	7,
	2016);
INSERT INTO V_TVL
	VALUES (2032,
	1981);
INSERT INTO V_VAL
	VALUES (2031,
	0,
	0,
	15,
	21,
	21,
	0,
	0,
	0,
	0,
	7,
	2016);
INSERT INTO V_LIN
	VALUES (2031,
	'1');
INSERT INTO V_VAR
	VALUES (2024,
	2016,
	'opencell',
	1,
	13);
INSERT INTO V_INT
	VALUES (2024,
	0,
	168);
INSERT INTO V_LOC
	VALUES (2037,
	9,
	18,
	25,
	2024);
INSERT INTO V_LOC
	VALUES (2038,
	10,
	12,
	19,
	2024);
INSERT INTO V_LOC
	VALUES (2039,
	11,
	35,
	42,
	2024);
INSERT INTO ACT_BLK
	VALUES (2028,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	9,
	0,
	0,
	0,
	0,
	11,
	51,
	0,
	0,
	0,
	0,
	0,
	1949,
	0);
INSERT INTO ACT_SMT
	VALUES (2040,
	2028,
	2041,
	11,
	9,
	'column::prune line: 11');
INSERT INTO ACT_URU
	VALUES (2040,
	2011,
	2024,
	1968,
	'',
	383,
	11,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2041,
	2028,
	0,
	12,
	9,
	'column::prune line: 12');
INSERT INTO ACT_DEL
	VALUES (2041,
	1968);
INSERT INTO ACT_BLK
	VALUES (1975,
	0,
	0,
	0,
	'',
	'',
	'',
	24,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1949,
	0);
INSERT INTO ACT_SMT
	VALUES (2042,
	1975,
	0,
	24,
	3,
	'column::prune line: 24');
INSERT INTO ACT_AI
	VALUES (2042,
	2043,
	2044,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2044,
	1,
	0,
	24,
	3,
	13,
	0,
	0,
	0,
	0,
	7,
	1975);
INSERT INTO V_TVL
	VALUES (2044,
	1981);
INSERT INTO V_VAL
	VALUES (2043,
	0,
	0,
	24,
	17,
	19,
	0,
	0,
	0,
	0,
	7,
	1975);
INSERT INTO V_LIN
	VALUES (2043,
	'100');
INSERT INTO ACT_BLK
	VALUES (1978,
	1,
	0,
	0,
	'',
	'',
	'',
	30,
	3,
	28,
	46,
	0,
	0,
	28,
	55,
	0,
	0,
	0,
	0,
	0,
	1949,
	0);
INSERT INTO ACT_SMT
	VALUES (2045,
	1978,
	2046,
	28,
	3,
	'column::prune line: 28');
INSERT INTO ACT_SEL
	VALUES (2045,
	1962,
	0,
	'many',
	2047);
INSERT INTO ACT_SR
	VALUES (2045);
INSERT INTO ACT_LNK
	VALUES (2048,
	'',
	2045,
	383,
	0,
	3,
	382,
	28,
	46,
	28,
	55,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2046,
	1978,
	2049,
	29,
	3,
	'column::prune line: 29');
INSERT INTO ACT_AI
	VALUES (2046,
	2050,
	2051,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2049,
	1978,
	0,
	30,
	3,
	'column::prune line: 30');
INSERT INTO ACT_IF
	VALUES (2049,
	2052,
	2053,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2047,
	0,
	0,
	28,
	36,
	43,
	0,
	0,
	0,
	0,
	13,
	1978);
INSERT INTO V_IRF
	VALUES (2047,
	1979);
INSERT INTO V_VAL
	VALUES (2051,
	1,
	1,
	29,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	1978);
INSERT INTO V_TVL
	VALUES (2051,
	2054);
INSERT INTO V_VAL
	VALUES (2055,
	0,
	0,
	29,
	19,
	27,
	0,
	0,
	0,
	0,
	14,
	1978);
INSERT INTO V_ISR
	VALUES (2055,
	1962);
INSERT INTO V_VAL
	VALUES (2050,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	1978);
INSERT INTO V_UNY
	VALUES (2050,
	2055,
	'cardinality');
INSERT INTO V_VAL
	VALUES (2056,
	0,
	0,
	30,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	1978);
INSERT INTO V_LIN
	VALUES (2056,
	'1');
INSERT INTO V_VAL
	VALUES (2053,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	1978);
INSERT INTO V_BIN
	VALUES (2053,
	2057,
	2056,
	'==');
INSERT INTO V_VAL
	VALUES (2057,
	0,
	0,
	30,
	13,
	13,
	0,
	0,
	0,
	0,
	7,
	1978);
INSERT INTO V_TVL
	VALUES (2057,
	2054);
INSERT INTO V_VAR
	VALUES (2054,
	1978,
	'c',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2054,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2058,
	29,
	3,
	3,
	2054);
INSERT INTO V_LOC
	VALUES (2059,
	30,
	13,
	13,
	2054);
INSERT INTO ACT_BLK
	VALUES (2052,
	1,
	0,
	0,
	'',
	'',
	'',
	34,
	5,
	31,
	44,
	0,
	0,
	31,
	53,
	0,
	0,
	0,
	0,
	0,
	1949,
	0);
INSERT INTO ACT_SMT
	VALUES (2060,
	2052,
	2061,
	31,
	5,
	'column::prune line: 31');
INSERT INTO ACT_SEL
	VALUES (2060,
	2062,
	1,
	'any',
	2063);
INSERT INTO ACT_SR
	VALUES (2060);
INSERT INTO ACT_LNK
	VALUES (2064,
	'',
	2060,
	383,
	0,
	3,
	382,
	31,
	44,
	31,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2061,
	2052,
	2065,
	32,
	5,
	'column::prune line: 32');
INSERT INTO ACT_TFM
	VALUES (2061,
	1495,
	1979,
	32,
	14,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2065,
	2052,
	0,
	34,
	5,
	'column::prune line: 34');
INSERT INTO ACT_AI
	VALUES (2065,
	2066,
	2067,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2063,
	0,
	0,
	31,
	34,
	41,
	0,
	0,
	0,
	0,
	13,
	2052);
INSERT INTO V_IRF
	VALUES (2063,
	1979);
INSERT INTO V_VAL
	VALUES (2068,
	0,
	0,
	32,
	35,
	40,
	0,
	0,
	0,
	0,
	13,
	2052);
INSERT INTO V_IRF
	VALUES (2068,
	2062);
INSERT INTO V_VAL
	VALUES (2069,
	0,
	0,
	32,
	42,
	52,
	0,
	0,
	0,
	0,
	7,
	2052);
INSERT INTO V_AVL
	VALUES (2069,
	2068,
	382,
	1448);
INSERT INTO V_PAR
	VALUES (2069,
	2061,
	0,
	'answer_digit',
	0,
	32,
	22);
INSERT INTO V_VAL
	VALUES (2067,
	1,
	0,
	34,
	5,
	15,
	0,
	0,
	0,
	0,
	7,
	2052);
INSERT INTO V_TVL
	VALUES (2067,
	1981);
INSERT INTO V_VAL
	VALUES (2066,
	0,
	0,
	34,
	19,
	19,
	0,
	0,
	0,
	0,
	7,
	2052);
INSERT INTO V_LIN
	VALUES (2066,
	'1');
INSERT INTO V_VAR
	VALUES (2062,
	2052,
	'answer',
	1,
	13);
INSERT INTO V_INT
	VALUES (2062,
	0,
	382);
INSERT INTO V_LOC
	VALUES (2070,
	31,
	16,
	21,
	2062);
INSERT INTO V_LOC
	VALUES (2071,
	32,
	35,
	40,
	2062);
INSERT INTO O_TFR
	VALUES (1948,
	296,
	'eliminate',
	'',
	7,
	1,
	'// Solve by select all eligible digits.  Notice if any eligible digit appears only once.

temperature = 0;
select many eligibles related by self->CELL[R3]->ELIGIBLE[R8];
c = cardinality eligibles;
if ( 9 == c )
  temperature = 100;
else
for each eligible in eligibles
  select many loners related by self->CELL[R3]->ELIGIBLE[R8]
    where ( selected.digit_value == eligible.digit_value );
  c = cardinality loners;
  if ( 1 == c )
    // This is an answer!
    select one cell related by eligible->CELL[R8];
    cell.answer( answer_digit:eligible.digit_value );
    // generate CELL2:answer( digit:eligible.digit_value ) to cell;
    temperature = 1;
    break;
  end if;
end for;
end if;
return temperature;
',
	1,
	'',
	0);
INSERT INTO ACT_OPB
	VALUES (2072,
	1948);
INSERT INTO ACT_ACT
	VALUES (2072,
	'operation',
	0,
	2073,
	0,
	0,
	'column::eliminate',
	0);
INSERT INTO ACT_BLK
	VALUES (2073,
	1,
	0,
	0,
	'',
	'',
	'',
	23,
	1,
	4,
	50,
	0,
	0,
	4,
	59,
	0,
	0,
	0,
	0,
	0,
	2072,
	0);
INSERT INTO ACT_SMT
	VALUES (2074,
	2073,
	2075,
	3,
	1,
	'column::eliminate line: 3');
INSERT INTO ACT_AI
	VALUES (2074,
	2076,
	2077,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2075,
	2073,
	2078,
	4,
	1,
	'column::eliminate line: 4');
INSERT INTO ACT_SEL
	VALUES (2075,
	2079,
	1,
	'many',
	2080);
INSERT INTO ACT_SR
	VALUES (2075);
INSERT INTO ACT_LNK
	VALUES (2081,
	'',
	2075,
	361,
	2082,
	3,
	168,
	4,
	40,
	4,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (2082,
	'',
	0,
	383,
	0,
	3,
	382,
	4,
	50,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2078,
	2073,
	2083,
	5,
	1,
	'column::eliminate line: 5');
INSERT INTO ACT_AI
	VALUES (2078,
	2084,
	2085,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2083,
	2073,
	2086,
	6,
	1,
	'column::eliminate line: 6');
INSERT INTO ACT_IF
	VALUES (2083,
	2087,
	2088,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2089,
	2073,
	0,
	8,
	1,
	'column::eliminate line: 8');
INSERT INTO ACT_E
	VALUES (2089,
	2090,
	2083);
INSERT INTO ACT_SMT
	VALUES (2086,
	2073,
	0,
	23,
	1,
	'column::eliminate line: 23');
INSERT INTO ACT_RET
	VALUES (2086,
	2091);
INSERT INTO V_VAL
	VALUES (2077,
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	7,
	2073);
INSERT INTO V_TVL
	VALUES (2077,
	2092);
INSERT INTO V_VAL
	VALUES (2076,
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	7,
	2073);
INSERT INTO V_LIN
	VALUES (2076,
	'0');
INSERT INTO V_VAL
	VALUES (2080,
	0,
	0,
	4,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	2073);
INSERT INTO V_IRF
	VALUES (2080,
	2093);
INSERT INTO V_VAL
	VALUES (2085,
	1,
	1,
	5,
	1,
	1,
	0,
	0,
	0,
	0,
	7,
	2073);
INSERT INTO V_TVL
	VALUES (2085,
	2094);
INSERT INTO V_VAL
	VALUES (2095,
	0,
	0,
	5,
	17,
	25,
	0,
	0,
	0,
	0,
	14,
	2073);
INSERT INTO V_ISR
	VALUES (2095,
	2079);
INSERT INTO V_VAL
	VALUES (2084,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	2073);
INSERT INTO V_UNY
	VALUES (2084,
	2095,
	'cardinality');
INSERT INTO V_VAL
	VALUES (2096,
	0,
	0,
	6,
	6,
	6,
	0,
	0,
	0,
	0,
	7,
	2073);
INSERT INTO V_LIN
	VALUES (2096,
	'9');
INSERT INTO V_VAL
	VALUES (2088,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2073);
INSERT INTO V_BIN
	VALUES (2088,
	2097,
	2096,
	'==');
INSERT INTO V_VAL
	VALUES (2097,
	0,
	0,
	6,
	11,
	11,
	0,
	0,
	0,
	0,
	7,
	2073);
INSERT INTO V_TVL
	VALUES (2097,
	2094);
INSERT INTO V_VAL
	VALUES (2091,
	0,
	0,
	23,
	8,
	18,
	0,
	0,
	0,
	0,
	7,
	2073);
INSERT INTO V_TVL
	VALUES (2091,
	2092);
INSERT INTO V_VAR
	VALUES (2092,
	2073,
	'temperature',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2092,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2098,
	3,
	1,
	11,
	2092);
INSERT INTO V_LOC
	VALUES (2099,
	7,
	3,
	13,
	2092);
INSERT INTO V_LOC
	VALUES (2100,
	18,
	5,
	15,
	2092);
INSERT INTO V_LOC
	VALUES (2101,
	23,
	8,
	18,
	2092);
INSERT INTO V_VAR
	VALUES (2079,
	2073,
	'eligibles',
	1,
	14);
INSERT INTO V_INS
	VALUES (2079,
	382);
INSERT INTO V_LOC
	VALUES (2102,
	4,
	13,
	21,
	2079);
INSERT INTO V_LOC
	VALUES (2103,
	9,
	22,
	30,
	2079);
INSERT INTO V_VAR
	VALUES (2093,
	2073,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (2093,
	0,
	296);
INSERT INTO V_VAR
	VALUES (2094,
	2073,
	'c',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2094,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2104,
	5,
	1,
	1,
	2094);
INSERT INTO V_LOC
	VALUES (2105,
	6,
	11,
	11,
	2094);
INSERT INTO V_LOC
	VALUES (2106,
	12,
	3,
	3,
	2094);
INSERT INTO V_LOC
	VALUES (2107,
	13,
	13,
	13,
	2094);
INSERT INTO ACT_BLK
	VALUES (2087,
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2072,
	0);
INSERT INTO ACT_SMT
	VALUES (2108,
	2087,
	0,
	7,
	3,
	'column::eliminate line: 7');
INSERT INTO ACT_AI
	VALUES (2108,
	2109,
	2110,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2110,
	1,
	0,
	7,
	3,
	13,
	0,
	0,
	0,
	0,
	7,
	2087);
INSERT INTO V_TVL
	VALUES (2110,
	2092);
INSERT INTO V_VAL
	VALUES (2109,
	0,
	0,
	7,
	17,
	19,
	0,
	0,
	0,
	0,
	7,
	2087);
INSERT INTO V_LIN
	VALUES (2109,
	'100');
INSERT INTO ACT_BLK
	VALUES (2090,
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2072,
	0);
INSERT INTO ACT_SMT
	VALUES (2111,
	2090,
	0,
	9,
	1,
	'column::eliminate line: 9');
INSERT INTO ACT_FOR
	VALUES (2111,
	2112,
	1,
	2113,
	2079,
	382);
INSERT INTO V_VAR
	VALUES (2113,
	2090,
	'eligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (2113,
	1,
	382);
INSERT INTO V_LOC
	VALUES (2114,
	9,
	10,
	17,
	2113);
INSERT INTO V_LOC
	VALUES (2115,
	11,
	37,
	44,
	2113);
INSERT INTO V_LOC
	VALUES (2116,
	16,
	31,
	38,
	2113);
INSERT INTO ACT_BLK
	VALUES (2112,
	1,
	0,
	1,
	'',
	'',
	'',
	13,
	3,
	10,
	49,
	0,
	0,
	10,
	58,
	0,
	0,
	0,
	0,
	0,
	2072,
	0);
INSERT INTO ACT_SMT
	VALUES (2117,
	2112,
	2118,
	10,
	3,
	'column::eliminate line: 10');
INSERT INTO ACT_SEL
	VALUES (2117,
	2119,
	1,
	'many',
	2120);
INSERT INTO ACT_SRW
	VALUES (2117,
	2121);
INSERT INTO ACT_LNK
	VALUES (2122,
	'',
	2117,
	361,
	2123,
	3,
	168,
	10,
	39,
	10,
	44,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (2123,
	'',
	0,
	383,
	0,
	3,
	382,
	10,
	49,
	10,
	58,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2118,
	2112,
	2124,
	12,
	3,
	'column::eliminate line: 12');
INSERT INTO ACT_AI
	VALUES (2118,
	2125,
	2126,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2124,
	2112,
	0,
	13,
	3,
	'column::eliminate line: 13');
INSERT INTO ACT_IF
	VALUES (2124,
	2127,
	2128,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2120,
	0,
	0,
	10,
	33,
	36,
	0,
	0,
	0,
	0,
	13,
	2112);
INSERT INTO V_IRF
	VALUES (2120,
	2093);
INSERT INTO V_VAL
	VALUES (2129,
	0,
	0,
	11,
	13,
	-1,
	0,
	0,
	0,
	0,
	13,
	2112);
INSERT INTO V_SLR
	VALUES (2129,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2130,
	0,
	0,
	11,
	22,
	32,
	0,
	0,
	0,
	0,
	7,
	2112);
INSERT INTO V_AVL
	VALUES (2130,
	2129,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (2121,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2112);
INSERT INTO V_BIN
	VALUES (2121,
	2131,
	2130,
	'==');
INSERT INTO V_VAL
	VALUES (2132,
	0,
	0,
	11,
	37,
	44,
	0,
	0,
	0,
	0,
	13,
	2112);
INSERT INTO V_IRF
	VALUES (2132,
	2113);
INSERT INTO V_VAL
	VALUES (2131,
	0,
	0,
	11,
	46,
	56,
	0,
	0,
	0,
	0,
	7,
	2112);
INSERT INTO V_AVL
	VALUES (2131,
	2132,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (2126,
	1,
	0,
	12,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	2112);
INSERT INTO V_TVL
	VALUES (2126,
	2094);
INSERT INTO V_VAL
	VALUES (2133,
	0,
	0,
	12,
	19,
	24,
	0,
	0,
	0,
	0,
	14,
	2112);
INSERT INTO V_ISR
	VALUES (2133,
	2119);
INSERT INTO V_VAL
	VALUES (2125,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	2112);
INSERT INTO V_UNY
	VALUES (2125,
	2133,
	'cardinality');
INSERT INTO V_VAL
	VALUES (2134,
	0,
	0,
	13,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	2112);
INSERT INTO V_LIN
	VALUES (2134,
	'1');
INSERT INTO V_VAL
	VALUES (2128,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2112);
INSERT INTO V_BIN
	VALUES (2128,
	2135,
	2134,
	'==');
INSERT INTO V_VAL
	VALUES (2135,
	0,
	0,
	13,
	13,
	13,
	0,
	0,
	0,
	0,
	7,
	2112);
INSERT INTO V_TVL
	VALUES (2135,
	2094);
INSERT INTO V_VAR
	VALUES (2119,
	2112,
	'loners',
	1,
	14);
INSERT INTO V_INS
	VALUES (2119,
	382);
INSERT INTO V_LOC
	VALUES (2136,
	10,
	15,
	20,
	2119);
INSERT INTO ACT_BLK
	VALUES (2127,
	1,
	0,
	0,
	'',
	'',
	'',
	19,
	5,
	15,
	42,
	0,
	0,
	15,
	47,
	0,
	0,
	0,
	0,
	0,
	2072,
	0);
INSERT INTO ACT_SMT
	VALUES (2137,
	2127,
	2138,
	15,
	5,
	'column::eliminate line: 15');
INSERT INTO ACT_SEL
	VALUES (2137,
	2139,
	1,
	'one',
	2140);
INSERT INTO ACT_SR
	VALUES (2137);
INSERT INTO ACT_LNK
	VALUES (2141,
	'',
	2137,
	383,
	0,
	2,
	168,
	15,
	42,
	15,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2138,
	2127,
	2142,
	16,
	5,
	'column::eliminate line: 16');
INSERT INTO ACT_TFM
	VALUES (2138,
	1495,
	2139,
	16,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2142,
	2127,
	2143,
	18,
	5,
	'column::eliminate line: 18');
INSERT INTO ACT_AI
	VALUES (2142,
	2144,
	2145,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2143,
	2127,
	0,
	19,
	5,
	'column::eliminate line: 19');
INSERT INTO ACT_BRK
	VALUES (2143);
INSERT INTO V_VAL
	VALUES (2140,
	0,
	0,
	15,
	32,
	39,
	0,
	0,
	0,
	0,
	13,
	2127);
INSERT INTO V_IRF
	VALUES (2140,
	2113);
INSERT INTO V_VAL
	VALUES (2146,
	0,
	0,
	16,
	31,
	38,
	0,
	0,
	0,
	0,
	13,
	2127);
INSERT INTO V_IRF
	VALUES (2146,
	2113);
INSERT INTO V_VAL
	VALUES (2147,
	0,
	0,
	16,
	40,
	50,
	0,
	0,
	0,
	0,
	7,
	2127);
INSERT INTO V_AVL
	VALUES (2147,
	2146,
	382,
	1448);
INSERT INTO V_PAR
	VALUES (2147,
	2138,
	0,
	'answer_digit',
	0,
	16,
	18);
INSERT INTO V_VAL
	VALUES (2145,
	1,
	0,
	18,
	5,
	15,
	0,
	0,
	0,
	0,
	7,
	2127);
INSERT INTO V_TVL
	VALUES (2145,
	2092);
INSERT INTO V_VAL
	VALUES (2144,
	0,
	0,
	18,
	19,
	19,
	0,
	0,
	0,
	0,
	7,
	2127);
INSERT INTO V_LIN
	VALUES (2144,
	'1');
INSERT INTO V_VAR
	VALUES (2139,
	2127,
	'cell',
	1,
	13);
INSERT INTO V_INT
	VALUES (2139,
	0,
	168);
INSERT INTO V_LOC
	VALUES (2148,
	15,
	16,
	19,
	2139);
INSERT INTO V_LOC
	VALUES (2149,
	16,
	5,
	8,
	2139);
INSERT INTO O_NBATTR
	VALUES (326,
	296);
INSERT INTO O_BATTR
	VALUES (326,
	296);
INSERT INTO O_ATTR
	VALUES (326,
	296,
	0,
	'number',
	'',
	'',
	'number',
	0,
	7,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (2150,
	296);
INSERT INTO O_BATTR
	VALUES (2150,
	296);
INSERT INTO O_ATTR
	VALUES (2150,
	296,
	326,
	'current_state',
	'',
	'',
	'current_state',
	0,
	11,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	296);
INSERT INTO O_ID
	VALUES (1,
	296);
INSERT INTO O_OIDA
	VALUES (326,
	296,
	1);
INSERT INTO O_ID
	VALUES (2,
	296);
INSERT INTO SM_ISM
	VALUES (1887,
	296);
INSERT INTO SM_SM
	VALUES (1887,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (1887);
INSERT INTO SM_LEVT
	VALUES (1886,
	1887,
	0);
INSERT INTO SM_SEVT
	VALUES (1886,
	1887,
	0);
INSERT INTO SM_EVT
	VALUES (1886,
	1887,
	0,
	1,
	'update',
	0,
	'',
	'COLUMN1',
	'');
INSERT INTO SM_LEVT
	VALUES (2151,
	1887,
	0);
INSERT INTO SM_SEVT
	VALUES (2151,
	1887,
	0);
INSERT INTO SM_EVT
	VALUES (2151,
	1887,
	0,
	2,
	'solved',
	0,
	'',
	'COLUMN2',
	'');
INSERT INTO SM_STATE
	VALUES (2152,
	1887,
	0,
	'solving',
	1,
	0);
INSERT INTO SM_SEME
	VALUES (2152,
	1886,
	1887,
	0);
INSERT INTO SM_SEME
	VALUES (2152,
	2151,
	1887,
	0);
INSERT INTO SM_MOAH
	VALUES (2153,
	1887,
	2152);
INSERT INTO SM_AH
	VALUES (2153,
	1887);
INSERT INTO SM_ACT
	VALUES (2153,
	1887,
	1,
	'if ( 100 == self.prune() )
  generate COLUMN2:solved() to self;
elif ( 100 == self.eliminate() )
  generate COLUMN2:solved() to self;
else
  select one sequence related by self->SEQUENCE[R1];
  if ( sequence.requests >= 1 )
    sequence.requests = 1;
    c = self;
    generate COLUMN1:update() to c;
  else
    sequence.requests = 0;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES (2154,
	1887,
	2153);
INSERT INTO ACT_ACT
	VALUES (2154,
	'state',
	0,
	2155,
	0,
	0,
	'column::solving',
	0);
INSERT INTO ACT_BLK
	VALUES (2155,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2154,
	0);
INSERT INTO ACT_SMT
	VALUES (2156,
	2155,
	0,
	1,
	1,
	'column::solving line: 1');
INSERT INTO ACT_IF
	VALUES (2156,
	2157,
	2158,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2159,
	2155,
	0,
	3,
	1,
	'column::solving line: 3');
INSERT INTO ACT_EL
	VALUES (2159,
	2160,
	2161,
	2156);
INSERT INTO ACT_SMT
	VALUES (2162,
	2155,
	0,
	5,
	1,
	'column::solving line: 5');
INSERT INTO ACT_E
	VALUES (2162,
	2163,
	2156);
INSERT INTO V_VAL
	VALUES (2164,
	0,
	0,
	1,
	6,
	8,
	0,
	0,
	0,
	0,
	7,
	2155);
INSERT INTO V_LIN
	VALUES (2164,
	'100');
INSERT INTO V_VAL
	VALUES (2158,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2155);
INSERT INTO V_BIN
	VALUES (2158,
	2165,
	2164,
	'==');
INSERT INTO V_VAL
	VALUES (2165,
	0,
	0,
	1,
	18,
	-1,
	0,
	0,
	0,
	0,
	7,
	2155);
INSERT INTO V_TRV
	VALUES (2165,
	1947,
	2166,
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2167,
	0,
	0,
	3,
	8,
	10,
	0,
	0,
	0,
	0,
	7,
	2155);
INSERT INTO V_LIN
	VALUES (2167,
	'100');
INSERT INTO V_VAL
	VALUES (2161,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2155);
INSERT INTO V_BIN
	VALUES (2161,
	2168,
	2167,
	'==');
INSERT INTO V_VAL
	VALUES (2168,
	0,
	0,
	3,
	20,
	-1,
	0,
	0,
	0,
	0,
	7,
	2155);
INSERT INTO V_TRV
	VALUES (2168,
	1948,
	2166,
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES (2166,
	2155,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (2166,
	0,
	296);
INSERT INTO V_LOC
	VALUES (2169,
	1,
	13,
	16,
	2166);
INSERT INTO V_LOC
	VALUES (2170,
	2,
	32,
	35,
	2166);
INSERT INTO V_LOC
	VALUES (2171,
	3,
	15,
	18,
	2166);
INSERT INTO V_LOC
	VALUES (2172,
	4,
	32,
	35,
	2166);
INSERT INTO V_LOC
	VALUES (2173,
	9,
	9,
	12,
	2166);
INSERT INTO ACT_BLK
	VALUES (2157,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2154,
	0);
INSERT INTO ACT_SMT
	VALUES (2174,
	2157,
	0,
	2,
	3,
	'column::solving line: 2');
INSERT INTO E_ESS
	VALUES (2174,
	1,
	0,
	2,
	12,
	2,
	20,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2174);
INSERT INTO E_GSME
	VALUES (2174,
	2151,
	1887);
INSERT INTO E_GEN
	VALUES (2174,
	2166);
INSERT INTO ACT_BLK
	VALUES (2160,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2154,
	0);
INSERT INTO ACT_SMT
	VALUES (2175,
	2160,
	0,
	4,
	3,
	'column::solving line: 4');
INSERT INTO E_ESS
	VALUES (2175,
	1,
	0,
	4,
	12,
	4,
	20,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2175);
INSERT INTO E_GSME
	VALUES (2175,
	2151,
	1887);
INSERT INTO E_GEN
	VALUES (2175,
	2166);
INSERT INTO ACT_BLK
	VALUES (2163,
	1,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	6,
	40,
	0,
	0,
	6,
	49,
	0,
	0,
	0,
	0,
	0,
	2154,
	0);
INSERT INTO ACT_SMT
	VALUES (2176,
	2163,
	2177,
	6,
	3,
	'column::solving line: 6');
INSERT INTO ACT_SEL
	VALUES (2176,
	2178,
	1,
	'one',
	2179);
INSERT INTO ACT_SR
	VALUES (2176);
INSERT INTO ACT_LNK
	VALUES (2180,
	'',
	2176,
	286,
	0,
	2,
	109,
	6,
	40,
	6,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2177,
	2163,
	0,
	7,
	3,
	'column::solving line: 7');
INSERT INTO ACT_IF
	VALUES (2177,
	2181,
	2182,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2183,
	2163,
	0,
	11,
	3,
	'column::solving line: 11');
INSERT INTO ACT_E
	VALUES (2183,
	2184,
	2177);
INSERT INTO V_VAL
	VALUES (2179,
	0,
	0,
	6,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	2163);
INSERT INTO V_IRF
	VALUES (2179,
	2166);
INSERT INTO V_VAL
	VALUES (2185,
	0,
	0,
	7,
	8,
	15,
	0,
	0,
	0,
	0,
	13,
	2163);
INSERT INTO V_IRF
	VALUES (2185,
	2178);
INSERT INTO V_VAL
	VALUES (2186,
	0,
	0,
	7,
	17,
	24,
	0,
	0,
	0,
	0,
	7,
	2163);
INSERT INTO V_AVL
	VALUES (2186,
	2185,
	109,
	320);
INSERT INTO V_VAL
	VALUES (2182,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2163);
INSERT INTO V_BIN
	VALUES (2182,
	2187,
	2186,
	'>=');
INSERT INTO V_VAL
	VALUES (2187,
	0,
	0,
	7,
	29,
	29,
	0,
	0,
	0,
	0,
	7,
	2163);
INSERT INTO V_LIN
	VALUES (2187,
	'1');
INSERT INTO V_VAR
	VALUES (2178,
	2163,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (2178,
	0,
	109);
INSERT INTO V_LOC
	VALUES (2188,
	6,
	14,
	21,
	2178);
INSERT INTO V_LOC
	VALUES (2189,
	7,
	8,
	15,
	2178);
INSERT INTO V_LOC
	VALUES (2190,
	8,
	5,
	12,
	2178);
INSERT INTO V_LOC
	VALUES (2191,
	12,
	5,
	12,
	2178);
INSERT INTO ACT_BLK
	VALUES (2181,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2154,
	0);
INSERT INTO ACT_SMT
	VALUES (2192,
	2181,
	2193,
	8,
	5,
	'column::solving line: 8');
INSERT INTO ACT_AI
	VALUES (2192,
	2194,
	2195,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2193,
	2181,
	2196,
	9,
	5,
	'column::solving line: 9');
INSERT INTO ACT_AI
	VALUES (2193,
	2197,
	2198,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2196,
	2181,
	0,
	10,
	5,
	'column::solving line: 10');
INSERT INTO E_ESS
	VALUES (2196,
	1,
	0,
	10,
	14,
	10,
	22,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2196);
INSERT INTO E_GSME
	VALUES (2196,
	1886,
	1887);
INSERT INTO E_GEN
	VALUES (2196,
	2199);
INSERT INTO V_VAL
	VALUES (2200,
	1,
	0,
	8,
	5,
	12,
	0,
	0,
	0,
	0,
	13,
	2181);
INSERT INTO V_IRF
	VALUES (2200,
	2178);
INSERT INTO V_VAL
	VALUES (2195,
	1,
	0,
	8,
	14,
	21,
	0,
	0,
	0,
	0,
	7,
	2181);
INSERT INTO V_AVL
	VALUES (2195,
	2200,
	109,
	320);
INSERT INTO V_VAL
	VALUES (2194,
	0,
	0,
	8,
	25,
	25,
	0,
	0,
	0,
	0,
	7,
	2181);
INSERT INTO V_LIN
	VALUES (2194,
	'1');
INSERT INTO V_VAL
	VALUES (2198,
	1,
	1,
	9,
	5,
	5,
	0,
	0,
	0,
	0,
	13,
	2181);
INSERT INTO V_IRF
	VALUES (2198,
	2199);
INSERT INTO V_VAL
	VALUES (2197,
	0,
	0,
	9,
	9,
	12,
	0,
	0,
	0,
	0,
	13,
	2181);
INSERT INTO V_IRF
	VALUES (2197,
	2166);
INSERT INTO V_VAR
	VALUES (2199,
	2181,
	'c',
	1,
	13);
INSERT INTO V_INT
	VALUES (2199,
	0,
	296);
INSERT INTO V_LOC
	VALUES (2201,
	9,
	5,
	5,
	2199);
INSERT INTO V_LOC
	VALUES (2202,
	10,
	34,
	34,
	2199);
INSERT INTO ACT_BLK
	VALUES (2184,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2154,
	0);
INSERT INTO ACT_SMT
	VALUES (2203,
	2184,
	0,
	12,
	5,
	'column::solving line: 12');
INSERT INTO ACT_AI
	VALUES (2203,
	2204,
	2205,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2206,
	1,
	0,
	12,
	5,
	12,
	0,
	0,
	0,
	0,
	13,
	2184);
INSERT INTO V_IRF
	VALUES (2206,
	2178);
INSERT INTO V_VAL
	VALUES (2205,
	1,
	0,
	12,
	14,
	21,
	0,
	0,
	0,
	0,
	7,
	2184);
INSERT INTO V_AVL
	VALUES (2205,
	2206,
	109,
	320);
INSERT INTO V_VAL
	VALUES (2204,
	0,
	0,
	12,
	25,
	25,
	0,
	0,
	0,
	0,
	7,
	2184);
INSERT INTO V_LIN
	VALUES (2204,
	'0');
INSERT INTO SM_STATE
	VALUES (2207,
	1887,
	0,
	'solved',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES (2207,
	1886,
	1887,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2207,
	1886,
	1887,
	0);
INSERT INTO SM_EIGN
	VALUES (2207,
	2151,
	1887,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2207,
	2151,
	1887,
	0);
INSERT INTO SM_MOAH
	VALUES (2208,
	1887,
	2207);
INSERT INTO SM_AH
	VALUES (2208,
	1887);
INSERT INTO SM_ACT
	VALUES (2208,
	1887,
	1,
	'select one sequence related by self->SEQUENCE[R1];
sequence.solved = true;',
	'');
INSERT INTO ACT_SAB
	VALUES (2209,
	1887,
	2208);
INSERT INTO ACT_ACT
	VALUES (2209,
	'state',
	0,
	2210,
	0,
	0,
	'column::solved',
	0);
INSERT INTO ACT_BLK
	VALUES (2210,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	1,
	47,
	0,
	0,
	0,
	0,
	0,
	2209,
	0);
INSERT INTO ACT_SMT
	VALUES (2211,
	2210,
	2212,
	1,
	1,
	'column::solved line: 1');
INSERT INTO ACT_SEL
	VALUES (2211,
	2213,
	1,
	'one',
	2214);
INSERT INTO ACT_SR
	VALUES (2211);
INSERT INTO ACT_LNK
	VALUES (2215,
	'',
	2211,
	286,
	0,
	2,
	109,
	1,
	38,
	1,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2212,
	2210,
	0,
	2,
	1,
	'column::solved line: 2');
INSERT INTO ACT_AI
	VALUES (2212,
	2216,
	2217,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2214,
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	13,
	2210);
INSERT INTO V_IRF
	VALUES (2214,
	2218);
INSERT INTO V_VAL
	VALUES (2219,
	1,
	0,
	2,
	1,
	8,
	0,
	0,
	0,
	0,
	13,
	2210);
INSERT INTO V_IRF
	VALUES (2219,
	2213);
INSERT INTO V_VAL
	VALUES (2217,
	1,
	0,
	2,
	10,
	15,
	0,
	0,
	0,
	0,
	6,
	2210);
INSERT INTO V_AVL
	VALUES (2217,
	2219,
	109,
	318);
INSERT INTO V_VAL
	VALUES (2216,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2210);
INSERT INTO V_LBO
	VALUES (2216,
	'TRUE');
INSERT INTO V_VAR
	VALUES (2213,
	2210,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (2213,
	0,
	109);
INSERT INTO V_LOC
	VALUES (2220,
	1,
	12,
	19,
	2213);
INSERT INTO V_LOC
	VALUES (2221,
	2,
	1,
	8,
	2213);
INSERT INTO V_VAR
	VALUES (2218,
	2210,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (2218,
	0,
	296);
INSERT INTO SM_NSTXN
	VALUES (2222,
	1887,
	2152,
	1886,
	0);
INSERT INTO SM_TAH
	VALUES (2223,
	1887,
	2222);
INSERT INTO SM_AH
	VALUES (2223,
	1887);
INSERT INTO SM_ACT
	VALUES (2223,
	1887,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (2224,
	1887,
	2223);
INSERT INTO ACT_ACT
	VALUES (2224,
	'transition',
	0,
	2225,
	0,
	0,
	'COLUMN1: update in solving to solving',
	0);
INSERT INTO ACT_BLK
	VALUES (2225,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2224,
	0);
INSERT INTO SM_TXN
	VALUES (2222,
	1887,
	2152,
	0);
INSERT INTO SM_NSTXN
	VALUES (2226,
	1887,
	2152,
	2151,
	0);
INSERT INTO SM_TAH
	VALUES (2227,
	1887,
	2226);
INSERT INTO SM_AH
	VALUES (2227,
	1887);
INSERT INTO SM_ACT
	VALUES (2227,
	1887,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (2228,
	1887,
	2227);
INSERT INTO ACT_ACT
	VALUES (2228,
	'transition',
	0,
	2229,
	0,
	0,
	'COLUMN2: solved in solving to solved',
	0);
INSERT INTO ACT_BLK
	VALUES (2229,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2228,
	0);
INSERT INTO SM_TXN
	VALUES (2226,
	1887,
	2207,
	0);
INSERT INTO O_OBJ
	VALUES (150,
	'digit',
	6,
	'DIGIT',
	'',
	1374);
INSERT INTO O_NBATTR
	VALUES (182,
	150);
INSERT INTO O_BATTR
	VALUES (182,
	150);
INSERT INTO O_ATTR
	VALUES (182,
	150,
	0,
	'value',
	'',
	'',
	'value',
	0,
	7,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	150);
INSERT INTO O_OIDA
	VALUES (182,
	150,
	0);
INSERT INTO O_ID
	VALUES (1,
	150);
INSERT INTO O_ID
	VALUES (2,
	150);
INSERT INTO O_OBJ
	VALUES (382,
	'eligible digit',
	7,
	'ELIGIBLE',
	'',
	1374);
INSERT INTO O_REF
	VALUES (382,
	168,
	0,
	415,
	383,
	2230,
	2231,
	2232,
	2233,
	0,
	0,
	'',
	'cell',
	'row_number',
	'R8');
INSERT INTO O_RATTR
	VALUES (2232,
	382,
	322,
	162,
	1,
	'number');
INSERT INTO O_ATTR
	VALUES (2232,
	382,
	0,
	'row_number',
	'',
	'',
	'row_number',
	2,
	12,
	'',
	'');
INSERT INTO O_REF
	VALUES (382,
	168,
	0,
	420,
	383,
	2230,
	2231,
	2234,
	2235,
	0,
	0,
	'',
	'cell',
	'column_number',
	'R8');
INSERT INTO O_RATTR
	VALUES (2234,
	382,
	326,
	296,
	1,
	'number');
INSERT INTO O_ATTR
	VALUES (2234,
	382,
	2232,
	'column_number',
	'',
	'',
	'column_number',
	2,
	12,
	'',
	'');
INSERT INTO O_REF
	VALUES (382,
	150,
	0,
	182,
	383,
	2230,
	2236,
	1448,
	2237,
	0,
	0,
	'',
	'digit',
	'value',
	'R8');
INSERT INTO O_RATTR
	VALUES (1448,
	382,
	182,
	150,
	1,
	'value');
INSERT INTO O_ATTR
	VALUES (1448,
	382,
	2234,
	'digit_value',
	'',
	'digit_',
	'value',
	1,
	12,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	382);
INSERT INTO O_OIDA
	VALUES (2232,
	382,
	0);
INSERT INTO O_OIDA
	VALUES (2234,
	382,
	0);
INSERT INTO O_OIDA
	VALUES (1448,
	382,
	0);
INSERT INTO O_ID
	VALUES (1,
	382);
INSERT INTO O_ID
	VALUES (2,
	382);
INSERT INTO O_OBJ
	VALUES (162,
	'row',
	2,
	'ROW',
	'',
	1374);
INSERT INTO O_TFR
	VALUES (2238,
	162,
	'eliminate',
	'',
	7,
	1,
	'// Solve by select all eligible digits.  Notice if any eligible digit appears only once.

temperature = 0;
select many eligibles related by self->CELL[R2]->ELIGIBLE[R8];
c = cardinality eligibles;
if ( 9 == c )
  temperature = 100;
else
for each eligible in eligibles
  select many loners related by self->CELL[R2]->ELIGIBLE[R8]
    where ( selected.digit_value == eligible.digit_value );
  c = cardinality loners;
  if ( 1 == c )
    // This is an answer!
    select one cell related by eligible->CELL[R8];
    cell.answer( answer_digit:eligible.digit_value );
    // generate CELL2:answer( digit:eligible.digit_value ) to cell;
    temperature = 1;
    break;
  end if;
end for;
end if;
return temperature;
',
	1,
	'',
	0);
INSERT INTO ACT_OPB
	VALUES (2239,
	2238);
INSERT INTO ACT_ACT
	VALUES (2239,
	'operation',
	0,
	2240,
	0,
	0,
	'row::eliminate',
	0);
INSERT INTO ACT_BLK
	VALUES (2240,
	1,
	0,
	0,
	'',
	'',
	'',
	23,
	1,
	4,
	50,
	0,
	0,
	4,
	59,
	0,
	0,
	0,
	0,
	0,
	2239,
	0);
INSERT INTO ACT_SMT
	VALUES (2241,
	2240,
	2242,
	3,
	1,
	'row::eliminate line: 3');
INSERT INTO ACT_AI
	VALUES (2241,
	2243,
	2244,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2242,
	2240,
	2245,
	4,
	1,
	'row::eliminate line: 4');
INSERT INTO ACT_SEL
	VALUES (2242,
	2246,
	1,
	'many',
	2247);
INSERT INTO ACT_SR
	VALUES (2242);
INSERT INTO ACT_LNK
	VALUES (2248,
	'',
	2242,
	359,
	2249,
	3,
	168,
	4,
	40,
	4,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (2249,
	'',
	0,
	383,
	0,
	3,
	382,
	4,
	50,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2245,
	2240,
	2250,
	5,
	1,
	'row::eliminate line: 5');
INSERT INTO ACT_AI
	VALUES (2245,
	2251,
	2252,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2250,
	2240,
	2253,
	6,
	1,
	'row::eliminate line: 6');
INSERT INTO ACT_IF
	VALUES (2250,
	2254,
	2255,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2256,
	2240,
	0,
	8,
	1,
	'row::eliminate line: 8');
INSERT INTO ACT_E
	VALUES (2256,
	2257,
	2250);
INSERT INTO ACT_SMT
	VALUES (2253,
	2240,
	0,
	23,
	1,
	'row::eliminate line: 23');
INSERT INTO ACT_RET
	VALUES (2253,
	2258);
INSERT INTO V_VAL
	VALUES (2244,
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	7,
	2240);
INSERT INTO V_TVL
	VALUES (2244,
	2259);
INSERT INTO V_VAL
	VALUES (2243,
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	7,
	2240);
INSERT INTO V_LIN
	VALUES (2243,
	'0');
INSERT INTO V_VAL
	VALUES (2247,
	0,
	0,
	4,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	2240);
INSERT INTO V_IRF
	VALUES (2247,
	2260);
INSERT INTO V_VAL
	VALUES (2252,
	1,
	1,
	5,
	1,
	1,
	0,
	0,
	0,
	0,
	7,
	2240);
INSERT INTO V_TVL
	VALUES (2252,
	2261);
INSERT INTO V_VAL
	VALUES (2262,
	0,
	0,
	5,
	17,
	25,
	0,
	0,
	0,
	0,
	14,
	2240);
INSERT INTO V_ISR
	VALUES (2262,
	2246);
INSERT INTO V_VAL
	VALUES (2251,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	2240);
INSERT INTO V_UNY
	VALUES (2251,
	2262,
	'cardinality');
INSERT INTO V_VAL
	VALUES (2263,
	0,
	0,
	6,
	6,
	6,
	0,
	0,
	0,
	0,
	7,
	2240);
INSERT INTO V_LIN
	VALUES (2263,
	'9');
INSERT INTO V_VAL
	VALUES (2255,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2240);
INSERT INTO V_BIN
	VALUES (2255,
	2264,
	2263,
	'==');
INSERT INTO V_VAL
	VALUES (2264,
	0,
	0,
	6,
	11,
	11,
	0,
	0,
	0,
	0,
	7,
	2240);
INSERT INTO V_TVL
	VALUES (2264,
	2261);
INSERT INTO V_VAL
	VALUES (2258,
	0,
	0,
	23,
	8,
	18,
	0,
	0,
	0,
	0,
	7,
	2240);
INSERT INTO V_TVL
	VALUES (2258,
	2259);
INSERT INTO V_VAR
	VALUES (2259,
	2240,
	'temperature',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2259,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2265,
	3,
	1,
	11,
	2259);
INSERT INTO V_LOC
	VALUES (2266,
	7,
	3,
	13,
	2259);
INSERT INTO V_LOC
	VALUES (2267,
	18,
	5,
	15,
	2259);
INSERT INTO V_LOC
	VALUES (2268,
	23,
	8,
	18,
	2259);
INSERT INTO V_VAR
	VALUES (2246,
	2240,
	'eligibles',
	1,
	14);
INSERT INTO V_INS
	VALUES (2246,
	382);
INSERT INTO V_LOC
	VALUES (2269,
	4,
	13,
	21,
	2246);
INSERT INTO V_LOC
	VALUES (2270,
	9,
	22,
	30,
	2246);
INSERT INTO V_VAR
	VALUES (2260,
	2240,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (2260,
	0,
	162);
INSERT INTO V_VAR
	VALUES (2261,
	2240,
	'c',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2261,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2271,
	5,
	1,
	1,
	2261);
INSERT INTO V_LOC
	VALUES (2272,
	6,
	11,
	11,
	2261);
INSERT INTO V_LOC
	VALUES (2273,
	12,
	3,
	3,
	2261);
INSERT INTO V_LOC
	VALUES (2274,
	13,
	13,
	13,
	2261);
INSERT INTO ACT_BLK
	VALUES (2254,
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2239,
	0);
INSERT INTO ACT_SMT
	VALUES (2275,
	2254,
	0,
	7,
	3,
	'row::eliminate line: 7');
INSERT INTO ACT_AI
	VALUES (2275,
	2276,
	2277,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2277,
	1,
	0,
	7,
	3,
	13,
	0,
	0,
	0,
	0,
	7,
	2254);
INSERT INTO V_TVL
	VALUES (2277,
	2259);
INSERT INTO V_VAL
	VALUES (2276,
	0,
	0,
	7,
	17,
	19,
	0,
	0,
	0,
	0,
	7,
	2254);
INSERT INTO V_LIN
	VALUES (2276,
	'100');
INSERT INTO ACT_BLK
	VALUES (2257,
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2239,
	0);
INSERT INTO ACT_SMT
	VALUES (2278,
	2257,
	0,
	9,
	1,
	'row::eliminate line: 9');
INSERT INTO ACT_FOR
	VALUES (2278,
	2279,
	1,
	2280,
	2246,
	382);
INSERT INTO V_VAR
	VALUES (2280,
	2257,
	'eligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (2280,
	1,
	382);
INSERT INTO V_LOC
	VALUES (2281,
	9,
	10,
	17,
	2280);
INSERT INTO V_LOC
	VALUES (2282,
	11,
	37,
	44,
	2280);
INSERT INTO V_LOC
	VALUES (2283,
	16,
	31,
	38,
	2280);
INSERT INTO ACT_BLK
	VALUES (2279,
	1,
	0,
	1,
	'',
	'',
	'',
	13,
	3,
	10,
	49,
	0,
	0,
	10,
	58,
	0,
	0,
	0,
	0,
	0,
	2239,
	0);
INSERT INTO ACT_SMT
	VALUES (2284,
	2279,
	2285,
	10,
	3,
	'row::eliminate line: 10');
INSERT INTO ACT_SEL
	VALUES (2284,
	2286,
	1,
	'many',
	2287);
INSERT INTO ACT_SRW
	VALUES (2284,
	2288);
INSERT INTO ACT_LNK
	VALUES (2289,
	'',
	2284,
	359,
	2290,
	3,
	168,
	10,
	39,
	10,
	44,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (2290,
	'',
	0,
	383,
	0,
	3,
	382,
	10,
	49,
	10,
	58,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2285,
	2279,
	2291,
	12,
	3,
	'row::eliminate line: 12');
INSERT INTO ACT_AI
	VALUES (2285,
	2292,
	2293,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2291,
	2279,
	0,
	13,
	3,
	'row::eliminate line: 13');
INSERT INTO ACT_IF
	VALUES (2291,
	2294,
	2295,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2287,
	0,
	0,
	10,
	33,
	36,
	0,
	0,
	0,
	0,
	13,
	2279);
INSERT INTO V_IRF
	VALUES (2287,
	2260);
INSERT INTO V_VAL
	VALUES (2296,
	0,
	0,
	11,
	13,
	-1,
	0,
	0,
	0,
	0,
	13,
	2279);
INSERT INTO V_SLR
	VALUES (2296,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2297,
	0,
	0,
	11,
	22,
	32,
	0,
	0,
	0,
	0,
	7,
	2279);
INSERT INTO V_AVL
	VALUES (2297,
	2296,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (2288,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2279);
INSERT INTO V_BIN
	VALUES (2288,
	2298,
	2297,
	'==');
INSERT INTO V_VAL
	VALUES (2299,
	0,
	0,
	11,
	37,
	44,
	0,
	0,
	0,
	0,
	13,
	2279);
INSERT INTO V_IRF
	VALUES (2299,
	2280);
INSERT INTO V_VAL
	VALUES (2298,
	0,
	0,
	11,
	46,
	56,
	0,
	0,
	0,
	0,
	7,
	2279);
INSERT INTO V_AVL
	VALUES (2298,
	2299,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (2293,
	1,
	0,
	12,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	2279);
INSERT INTO V_TVL
	VALUES (2293,
	2261);
INSERT INTO V_VAL
	VALUES (2300,
	0,
	0,
	12,
	19,
	24,
	0,
	0,
	0,
	0,
	14,
	2279);
INSERT INTO V_ISR
	VALUES (2300,
	2286);
INSERT INTO V_VAL
	VALUES (2292,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	2279);
INSERT INTO V_UNY
	VALUES (2292,
	2300,
	'cardinality');
INSERT INTO V_VAL
	VALUES (2301,
	0,
	0,
	13,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	2279);
INSERT INTO V_LIN
	VALUES (2301,
	'1');
INSERT INTO V_VAL
	VALUES (2295,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2279);
INSERT INTO V_BIN
	VALUES (2295,
	2302,
	2301,
	'==');
INSERT INTO V_VAL
	VALUES (2302,
	0,
	0,
	13,
	13,
	13,
	0,
	0,
	0,
	0,
	7,
	2279);
INSERT INTO V_TVL
	VALUES (2302,
	2261);
INSERT INTO V_VAR
	VALUES (2286,
	2279,
	'loners',
	1,
	14);
INSERT INTO V_INS
	VALUES (2286,
	382);
INSERT INTO V_LOC
	VALUES (2303,
	10,
	15,
	20,
	2286);
INSERT INTO ACT_BLK
	VALUES (2294,
	1,
	0,
	0,
	'',
	'',
	'',
	19,
	5,
	15,
	42,
	0,
	0,
	15,
	47,
	0,
	0,
	0,
	0,
	0,
	2239,
	0);
INSERT INTO ACT_SMT
	VALUES (2304,
	2294,
	2305,
	15,
	5,
	'row::eliminate line: 15');
INSERT INTO ACT_SEL
	VALUES (2304,
	2306,
	1,
	'one',
	2307);
INSERT INTO ACT_SR
	VALUES (2304);
INSERT INTO ACT_LNK
	VALUES (2308,
	'',
	2304,
	383,
	0,
	2,
	168,
	15,
	42,
	15,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2305,
	2294,
	2309,
	16,
	5,
	'row::eliminate line: 16');
INSERT INTO ACT_TFM
	VALUES (2305,
	1495,
	2306,
	16,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2309,
	2294,
	2310,
	18,
	5,
	'row::eliminate line: 18');
INSERT INTO ACT_AI
	VALUES (2309,
	2311,
	2312,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2310,
	2294,
	0,
	19,
	5,
	'row::eliminate line: 19');
INSERT INTO ACT_BRK
	VALUES (2310);
INSERT INTO V_VAL
	VALUES (2307,
	0,
	0,
	15,
	32,
	39,
	0,
	0,
	0,
	0,
	13,
	2294);
INSERT INTO V_IRF
	VALUES (2307,
	2280);
INSERT INTO V_VAL
	VALUES (2313,
	0,
	0,
	16,
	31,
	38,
	0,
	0,
	0,
	0,
	13,
	2294);
INSERT INTO V_IRF
	VALUES (2313,
	2280);
INSERT INTO V_VAL
	VALUES (2314,
	0,
	0,
	16,
	40,
	50,
	0,
	0,
	0,
	0,
	7,
	2294);
INSERT INTO V_AVL
	VALUES (2314,
	2313,
	382,
	1448);
INSERT INTO V_PAR
	VALUES (2314,
	2305,
	0,
	'answer_digit',
	0,
	16,
	18);
INSERT INTO V_VAL
	VALUES (2312,
	1,
	0,
	18,
	5,
	15,
	0,
	0,
	0,
	0,
	7,
	2294);
INSERT INTO V_TVL
	VALUES (2312,
	2259);
INSERT INTO V_VAL
	VALUES (2311,
	0,
	0,
	18,
	19,
	19,
	0,
	0,
	0,
	0,
	7,
	2294);
INSERT INTO V_LIN
	VALUES (2311,
	'1');
INSERT INTO V_VAR
	VALUES (2306,
	2294,
	'cell',
	1,
	13);
INSERT INTO V_INT
	VALUES (2306,
	0,
	168);
INSERT INTO V_LOC
	VALUES (2315,
	15,
	16,
	19,
	2306);
INSERT INTO V_LOC
	VALUES (2316,
	16,
	5,
	8,
	2306);
INSERT INTO O_TFR
	VALUES (2317,
	162,
	'prune',
	'',
	7,
	1,
	'// Eliminate eligible digits that match any answer digit for this sequence.

temperature = 0;
select many answerdigits related by self->CELL[R2]->DIGIT[R9] where ( selected.value != 0 );
select many eligibles related by self->CELL[R2]->ELIGIBLE[R8];
for each eligible in eligibles
  for each answerdigit in answerdigits
    if ( eligible.digit_value == answerdigit.value )
      select one opencell related by eligible->CELL[R8];
      if ( opencell.answer_value != eligible.digit_value )
        unrelate answerdigit from opencell across R8 using eligible;
        delete object instance eligible;
        // generate CELL1:eliminate( digit:answerdigit.value ) to opencell;
      end if;
      temperature = 1;
      break;
    end if;
  end for;
end for;
  
select many opencells related by self->CELL[R2]
  where ( selected.answer_value == 0 );
if ( empty opencells )
  temperature = 100;
end if;
for each opencell in opencells
  // Notice if we have the answer now.
  select many eligibles related by opencell->ELIGIBLE[R8];
  c = cardinality eligibles;
  if ( 1 == c )
    select any answer related by opencell->ELIGIBLE[R8];
    opencell.answer( answer_digit:answer.digit_value );
    // generate CELL2:answer( digit:answer.digit_value ) to opencell;
    temperature = 1;
  end if;
end for;

return temperature;
',
	1,
	'',
	2238);
INSERT INTO ACT_OPB
	VALUES (2318,
	2317);
INSERT INTO ACT_ACT
	VALUES (2318,
	'operation',
	0,
	2319,
	0,
	0,
	'row::prune',
	0);
INSERT INTO ACT_BLK
	VALUES (2319,
	1,
	0,
	1,
	'',
	'',
	'',
	38,
	1,
	21,
	40,
	0,
	0,
	21,
	45,
	0,
	0,
	0,
	0,
	0,
	2318,
	0);
INSERT INTO ACT_SMT
	VALUES (2320,
	2319,
	2321,
	3,
	1,
	'row::prune line: 3');
INSERT INTO ACT_AI
	VALUES (2320,
	2322,
	2323,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2321,
	2319,
	2324,
	4,
	1,
	'row::prune line: 4');
INSERT INTO ACT_SEL
	VALUES (2321,
	2325,
	1,
	'many',
	2326);
INSERT INTO ACT_SRW
	VALUES (2321,
	2327);
INSERT INTO ACT_LNK
	VALUES (2328,
	'',
	2321,
	359,
	2329,
	3,
	168,
	4,
	43,
	4,
	48,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (2329,
	'',
	0,
	357,
	0,
	2,
	150,
	4,
	53,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2324,
	2319,
	2330,
	5,
	1,
	'row::prune line: 5');
INSERT INTO ACT_SEL
	VALUES (2324,
	2331,
	1,
	'many',
	2332);
INSERT INTO ACT_SR
	VALUES (2324);
INSERT INTO ACT_LNK
	VALUES (2333,
	'',
	2324,
	359,
	2334,
	3,
	168,
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES (2334,
	'',
	0,
	383,
	0,
	3,
	382,
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2330,
	2319,
	2335,
	6,
	1,
	'row::prune line: 6');
INSERT INTO ACT_FOR
	VALUES (2330,
	2336,
	1,
	2337,
	2331,
	382);
INSERT INTO ACT_SMT
	VALUES (2335,
	2319,
	2338,
	21,
	1,
	'row::prune line: 21');
INSERT INTO ACT_SEL
	VALUES (2335,
	2339,
	1,
	'many',
	2340);
INSERT INTO ACT_SRW
	VALUES (2335,
	2341);
INSERT INTO ACT_LNK
	VALUES (2342,
	'',
	2335,
	359,
	0,
	3,
	168,
	21,
	40,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2338,
	2319,
	2343,
	23,
	1,
	'row::prune line: 23');
INSERT INTO ACT_IF
	VALUES (2338,
	2344,
	2345,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2343,
	2319,
	2346,
	26,
	1,
	'row::prune line: 26');
INSERT INTO ACT_FOR
	VALUES (2343,
	2347,
	1,
	2348,
	2339,
	168);
INSERT INTO ACT_SMT
	VALUES (2346,
	2319,
	0,
	38,
	1,
	'row::prune line: 38');
INSERT INTO ACT_RET
	VALUES (2346,
	2349);
INSERT INTO V_VAL
	VALUES (2323,
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	7,
	2319);
INSERT INTO V_TVL
	VALUES (2323,
	2350);
INSERT INTO V_VAL
	VALUES (2322,
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	7,
	2319);
INSERT INTO V_LIN
	VALUES (2322,
	'0');
INSERT INTO V_VAL
	VALUES (2326,
	0,
	0,
	4,
	37,
	40,
	0,
	0,
	0,
	0,
	13,
	2319);
INSERT INTO V_IRF
	VALUES (2326,
	2351);
INSERT INTO V_VAL
	VALUES (2352,
	0,
	0,
	4,
	71,
	-1,
	0,
	0,
	0,
	0,
	13,
	2319);
INSERT INTO V_SLR
	VALUES (2352,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2353,
	0,
	0,
	4,
	80,
	84,
	0,
	0,
	0,
	0,
	7,
	2319);
INSERT INTO V_AVL
	VALUES (2353,
	2352,
	150,
	182);
INSERT INTO V_VAL
	VALUES (2327,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2319);
INSERT INTO V_BIN
	VALUES (2327,
	2354,
	2353,
	'!=');
INSERT INTO V_VAL
	VALUES (2354,
	0,
	0,
	4,
	89,
	89,
	0,
	0,
	0,
	0,
	7,
	2319);
INSERT INTO V_LIN
	VALUES (2354,
	'0');
INSERT INTO V_VAL
	VALUES (2332,
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	2319);
INSERT INTO V_IRF
	VALUES (2332,
	2351);
INSERT INTO V_VAL
	VALUES (2340,
	0,
	0,
	21,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	2319);
INSERT INTO V_IRF
	VALUES (2340,
	2351);
INSERT INTO V_VAL
	VALUES (2355,
	0,
	0,
	22,
	11,
	-1,
	0,
	0,
	0,
	0,
	13,
	2319);
INSERT INTO V_SLR
	VALUES (2355,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2356,
	0,
	0,
	22,
	20,
	31,
	0,
	0,
	0,
	0,
	7,
	2319);
INSERT INTO V_AVL
	VALUES (2356,
	2355,
	168,
	788);
INSERT INTO V_VAL
	VALUES (2341,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2319);
INSERT INTO V_BIN
	VALUES (2341,
	2357,
	2356,
	'==');
INSERT INTO V_VAL
	VALUES (2357,
	0,
	0,
	22,
	36,
	36,
	0,
	0,
	0,
	0,
	7,
	2319);
INSERT INTO V_LIN
	VALUES (2357,
	'0');
INSERT INTO V_VAL
	VALUES (2358,
	0,
	0,
	23,
	12,
	20,
	0,
	0,
	0,
	0,
	14,
	2319);
INSERT INTO V_ISR
	VALUES (2358,
	2339);
INSERT INTO V_VAL
	VALUES (2345,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2319);
INSERT INTO V_UNY
	VALUES (2345,
	2358,
	'empty');
INSERT INTO V_VAL
	VALUES (2349,
	0,
	0,
	38,
	8,
	18,
	0,
	0,
	0,
	0,
	7,
	2319);
INSERT INTO V_TVL
	VALUES (2349,
	2350);
INSERT INTO V_VAR
	VALUES (2350,
	2319,
	'temperature',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2350,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2359,
	3,
	1,
	11,
	2350);
INSERT INTO V_LOC
	VALUES (2360,
	15,
	7,
	17,
	2350);
INSERT INTO V_LOC
	VALUES (2361,
	24,
	3,
	13,
	2350);
INSERT INTO V_LOC
	VALUES (2362,
	34,
	5,
	15,
	2350);
INSERT INTO V_LOC
	VALUES (2363,
	38,
	8,
	18,
	2350);
INSERT INTO V_VAR
	VALUES (2325,
	2319,
	'answerdigits',
	1,
	14);
INSERT INTO V_INS
	VALUES (2325,
	150);
INSERT INTO V_LOC
	VALUES (2364,
	4,
	13,
	24,
	2325);
INSERT INTO V_LOC
	VALUES (2365,
	7,
	27,
	38,
	2325);
INSERT INTO V_VAR
	VALUES (2351,
	2319,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (2351,
	0,
	162);
INSERT INTO V_VAR
	VALUES (2331,
	2319,
	'eligibles',
	1,
	14);
INSERT INTO V_INS
	VALUES (2331,
	382);
INSERT INTO V_LOC
	VALUES (2366,
	5,
	13,
	21,
	2331);
INSERT INTO V_LOC
	VALUES (2367,
	6,
	22,
	30,
	2331);
INSERT INTO V_LOC
	VALUES (2368,
	28,
	15,
	23,
	2331);
INSERT INTO V_VAR
	VALUES (2337,
	2319,
	'eligible',
	1,
	13);
INSERT INTO V_INT
	VALUES (2337,
	1,
	382);
INSERT INTO V_LOC
	VALUES (2369,
	6,
	10,
	17,
	2337);
INSERT INTO V_LOC
	VALUES (2370,
	8,
	10,
	17,
	2337);
INSERT INTO V_LOC
	VALUES (2371,
	10,
	37,
	44,
	2337);
INSERT INTO V_LOC
	VALUES (2372,
	11,
	60,
	67,
	2337);
INSERT INTO V_LOC
	VALUES (2373,
	12,
	32,
	39,
	2337);
INSERT INTO V_VAR
	VALUES (2339,
	2319,
	'opencells',
	1,
	14);
INSERT INTO V_INS
	VALUES (2339,
	168);
INSERT INTO V_LOC
	VALUES (2374,
	21,
	13,
	21,
	2339);
INSERT INTO V_LOC
	VALUES (2375,
	26,
	22,
	30,
	2339);
INSERT INTO V_VAR
	VALUES (2348,
	2319,
	'opencell',
	1,
	13);
INSERT INTO V_INT
	VALUES (2348,
	1,
	168);
INSERT INTO V_LOC
	VALUES (2376,
	26,
	10,
	17,
	2348);
INSERT INTO V_LOC
	VALUES (2377,
	32,
	5,
	12,
	2348);
INSERT INTO ACT_BLK
	VALUES (2336,
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2318,
	0);
INSERT INTO ACT_SMT
	VALUES (2378,
	2336,
	0,
	7,
	3,
	'row::prune line: 7');
INSERT INTO ACT_FOR
	VALUES (2378,
	2379,
	1,
	2380,
	2325,
	150);
INSERT INTO V_VAR
	VALUES (2380,
	2336,
	'answerdigit',
	1,
	13);
INSERT INTO V_INT
	VALUES (2380,
	1,
	150);
INSERT INTO V_LOC
	VALUES (2381,
	7,
	12,
	22,
	2380);
INSERT INTO V_LOC
	VALUES (2382,
	8,
	34,
	44,
	2380);
INSERT INTO V_LOC
	VALUES (2383,
	11,
	18,
	28,
	2380);
INSERT INTO ACT_BLK
	VALUES (2379,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2318,
	0);
INSERT INTO ACT_SMT
	VALUES (2384,
	2379,
	0,
	8,
	5,
	'row::prune line: 8');
INSERT INTO ACT_IF
	VALUES (2384,
	2385,
	2386,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2387,
	0,
	0,
	8,
	10,
	17,
	0,
	0,
	0,
	0,
	13,
	2379);
INSERT INTO V_IRF
	VALUES (2387,
	2337);
INSERT INTO V_VAL
	VALUES (2388,
	0,
	0,
	8,
	19,
	29,
	0,
	0,
	0,
	0,
	7,
	2379);
INSERT INTO V_AVL
	VALUES (2388,
	2387,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (2386,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2379);
INSERT INTO V_BIN
	VALUES (2386,
	2389,
	2388,
	'==');
INSERT INTO V_VAL
	VALUES (2390,
	0,
	0,
	8,
	34,
	44,
	0,
	0,
	0,
	0,
	13,
	2379);
INSERT INTO V_IRF
	VALUES (2390,
	2380);
INSERT INTO V_VAL
	VALUES (2389,
	0,
	0,
	8,
	46,
	50,
	0,
	0,
	0,
	0,
	7,
	2379);
INSERT INTO V_AVL
	VALUES (2389,
	2390,
	150,
	182);
INSERT INTO ACT_BLK
	VALUES (2385,
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	7,
	9,
	48,
	0,
	0,
	9,
	53,
	0,
	0,
	0,
	0,
	0,
	2318,
	0);
INSERT INTO ACT_SMT
	VALUES (2391,
	2385,
	2392,
	9,
	7,
	'row::prune line: 9');
INSERT INTO ACT_SEL
	VALUES (2391,
	2393,
	1,
	'one',
	2394);
INSERT INTO ACT_SR
	VALUES (2391);
INSERT INTO ACT_LNK
	VALUES (2395,
	'',
	2391,
	383,
	0,
	2,
	168,
	9,
	48,
	9,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2392,
	2385,
	2396,
	10,
	7,
	'row::prune line: 10');
INSERT INTO ACT_IF
	VALUES (2392,
	2397,
	2398,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2396,
	2385,
	2399,
	15,
	7,
	'row::prune line: 15');
INSERT INTO ACT_AI
	VALUES (2396,
	2400,
	2401,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2399,
	2385,
	0,
	16,
	7,
	'row::prune line: 16');
INSERT INTO ACT_BRK
	VALUES (2399);
INSERT INTO V_VAL
	VALUES (2394,
	0,
	0,
	9,
	38,
	45,
	0,
	0,
	0,
	0,
	13,
	2385);
INSERT INTO V_IRF
	VALUES (2394,
	2337);
INSERT INTO V_VAL
	VALUES (2402,
	0,
	0,
	10,
	12,
	19,
	0,
	0,
	0,
	0,
	13,
	2385);
INSERT INTO V_IRF
	VALUES (2402,
	2393);
INSERT INTO V_VAL
	VALUES (2403,
	0,
	0,
	10,
	21,
	32,
	0,
	0,
	0,
	0,
	7,
	2385);
INSERT INTO V_AVL
	VALUES (2403,
	2402,
	168,
	788);
INSERT INTO V_VAL
	VALUES (2398,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2385);
INSERT INTO V_BIN
	VALUES (2398,
	2404,
	2403,
	'!=');
INSERT INTO V_VAL
	VALUES (2405,
	0,
	0,
	10,
	37,
	44,
	0,
	0,
	0,
	0,
	13,
	2385);
INSERT INTO V_IRF
	VALUES (2405,
	2337);
INSERT INTO V_VAL
	VALUES (2404,
	0,
	0,
	10,
	46,
	56,
	0,
	0,
	0,
	0,
	7,
	2385);
INSERT INTO V_AVL
	VALUES (2404,
	2405,
	382,
	1448);
INSERT INTO V_VAL
	VALUES (2401,
	1,
	0,
	15,
	7,
	17,
	0,
	0,
	0,
	0,
	7,
	2385);
INSERT INTO V_TVL
	VALUES (2401,
	2350);
INSERT INTO V_VAL
	VALUES (2400,
	0,
	0,
	15,
	21,
	21,
	0,
	0,
	0,
	0,
	7,
	2385);
INSERT INTO V_LIN
	VALUES (2400,
	'1');
INSERT INTO V_VAR
	VALUES (2393,
	2385,
	'opencell',
	1,
	13);
INSERT INTO V_INT
	VALUES (2393,
	0,
	168);
INSERT INTO V_LOC
	VALUES (2406,
	9,
	18,
	25,
	2393);
INSERT INTO V_LOC
	VALUES (2407,
	10,
	12,
	19,
	2393);
INSERT INTO V_LOC
	VALUES (2408,
	11,
	35,
	42,
	2393);
INSERT INTO ACT_BLK
	VALUES (2397,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	9,
	0,
	0,
	0,
	0,
	11,
	51,
	0,
	0,
	0,
	0,
	0,
	2318,
	0);
INSERT INTO ACT_SMT
	VALUES (2409,
	2397,
	2410,
	11,
	9,
	'row::prune line: 11');
INSERT INTO ACT_URU
	VALUES (2409,
	2380,
	2393,
	2337,
	'',
	383,
	11,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2410,
	2397,
	0,
	12,
	9,
	'row::prune line: 12');
INSERT INTO ACT_DEL
	VALUES (2410,
	2337);
INSERT INTO ACT_BLK
	VALUES (2344,
	0,
	0,
	0,
	'',
	'',
	'',
	24,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2318,
	0);
INSERT INTO ACT_SMT
	VALUES (2411,
	2344,
	0,
	24,
	3,
	'row::prune line: 24');
INSERT INTO ACT_AI
	VALUES (2411,
	2412,
	2413,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2413,
	1,
	0,
	24,
	3,
	13,
	0,
	0,
	0,
	0,
	7,
	2344);
INSERT INTO V_TVL
	VALUES (2413,
	2350);
INSERT INTO V_VAL
	VALUES (2412,
	0,
	0,
	24,
	17,
	19,
	0,
	0,
	0,
	0,
	7,
	2344);
INSERT INTO V_LIN
	VALUES (2412,
	'100');
INSERT INTO ACT_BLK
	VALUES (2347,
	1,
	0,
	0,
	'',
	'',
	'',
	30,
	3,
	28,
	46,
	0,
	0,
	28,
	55,
	0,
	0,
	0,
	0,
	0,
	2318,
	0);
INSERT INTO ACT_SMT
	VALUES (2414,
	2347,
	2415,
	28,
	3,
	'row::prune line: 28');
INSERT INTO ACT_SEL
	VALUES (2414,
	2331,
	0,
	'many',
	2416);
INSERT INTO ACT_SR
	VALUES (2414);
INSERT INTO ACT_LNK
	VALUES (2417,
	'',
	2414,
	383,
	0,
	3,
	382,
	28,
	46,
	28,
	55,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2415,
	2347,
	2418,
	29,
	3,
	'row::prune line: 29');
INSERT INTO ACT_AI
	VALUES (2415,
	2419,
	2420,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2418,
	2347,
	0,
	30,
	3,
	'row::prune line: 30');
INSERT INTO ACT_IF
	VALUES (2418,
	2421,
	2422,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2416,
	0,
	0,
	28,
	36,
	43,
	0,
	0,
	0,
	0,
	13,
	2347);
INSERT INTO V_IRF
	VALUES (2416,
	2348);
INSERT INTO V_VAL
	VALUES (2420,
	1,
	1,
	29,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	2347);
INSERT INTO V_TVL
	VALUES (2420,
	2423);
INSERT INTO V_VAL
	VALUES (2424,
	0,
	0,
	29,
	19,
	27,
	0,
	0,
	0,
	0,
	14,
	2347);
INSERT INTO V_ISR
	VALUES (2424,
	2331);
INSERT INTO V_VAL
	VALUES (2419,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	2347);
INSERT INTO V_UNY
	VALUES (2419,
	2424,
	'cardinality');
INSERT INTO V_VAL
	VALUES (2425,
	0,
	0,
	30,
	8,
	8,
	0,
	0,
	0,
	0,
	7,
	2347);
INSERT INTO V_LIN
	VALUES (2425,
	'1');
INSERT INTO V_VAL
	VALUES (2422,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2347);
INSERT INTO V_BIN
	VALUES (2422,
	2426,
	2425,
	'==');
INSERT INTO V_VAL
	VALUES (2426,
	0,
	0,
	30,
	13,
	13,
	0,
	0,
	0,
	0,
	7,
	2347);
INSERT INTO V_TVL
	VALUES (2426,
	2423);
INSERT INTO V_VAR
	VALUES (2423,
	2347,
	'c',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2423,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2427,
	29,
	3,
	3,
	2423);
INSERT INTO V_LOC
	VALUES (2428,
	30,
	13,
	13,
	2423);
INSERT INTO ACT_BLK
	VALUES (2421,
	1,
	0,
	0,
	'',
	'',
	'',
	34,
	5,
	31,
	44,
	0,
	0,
	31,
	53,
	0,
	0,
	0,
	0,
	0,
	2318,
	0);
INSERT INTO ACT_SMT
	VALUES (2429,
	2421,
	2430,
	31,
	5,
	'row::prune line: 31');
INSERT INTO ACT_SEL
	VALUES (2429,
	2431,
	1,
	'any',
	2432);
INSERT INTO ACT_SR
	VALUES (2429);
INSERT INTO ACT_LNK
	VALUES (2433,
	'',
	2429,
	383,
	0,
	3,
	382,
	31,
	44,
	31,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2430,
	2421,
	2434,
	32,
	5,
	'row::prune line: 32');
INSERT INTO ACT_TFM
	VALUES (2430,
	1495,
	2348,
	32,
	14,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2434,
	2421,
	0,
	34,
	5,
	'row::prune line: 34');
INSERT INTO ACT_AI
	VALUES (2434,
	2435,
	2436,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2432,
	0,
	0,
	31,
	34,
	41,
	0,
	0,
	0,
	0,
	13,
	2421);
INSERT INTO V_IRF
	VALUES (2432,
	2348);
INSERT INTO V_VAL
	VALUES (2437,
	0,
	0,
	32,
	35,
	40,
	0,
	0,
	0,
	0,
	13,
	2421);
INSERT INTO V_IRF
	VALUES (2437,
	2431);
INSERT INTO V_VAL
	VALUES (2438,
	0,
	0,
	32,
	42,
	52,
	0,
	0,
	0,
	0,
	7,
	2421);
INSERT INTO V_AVL
	VALUES (2438,
	2437,
	382,
	1448);
INSERT INTO V_PAR
	VALUES (2438,
	2430,
	0,
	'answer_digit',
	0,
	32,
	22);
INSERT INTO V_VAL
	VALUES (2436,
	1,
	0,
	34,
	5,
	15,
	0,
	0,
	0,
	0,
	7,
	2421);
INSERT INTO V_TVL
	VALUES (2436,
	2350);
INSERT INTO V_VAL
	VALUES (2435,
	0,
	0,
	34,
	19,
	19,
	0,
	0,
	0,
	0,
	7,
	2421);
INSERT INTO V_LIN
	VALUES (2435,
	'1');
INSERT INTO V_VAR
	VALUES (2431,
	2421,
	'answer',
	1,
	13);
INSERT INTO V_INT
	VALUES (2431,
	0,
	382);
INSERT INTO V_LOC
	VALUES (2439,
	31,
	16,
	21,
	2431);
INSERT INTO V_LOC
	VALUES (2440,
	32,
	35,
	40,
	2431);
INSERT INTO O_NBATTR
	VALUES (322,
	162);
INSERT INTO O_BATTR
	VALUES (322,
	162);
INSERT INTO O_ATTR
	VALUES (322,
	162,
	0,
	'number',
	'',
	'',
	'number',
	0,
	7,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (2441,
	162);
INSERT INTO O_BATTR
	VALUES (2441,
	162);
INSERT INTO O_ATTR
	VALUES (2441,
	162,
	322,
	'current_state',
	'',
	'',
	'current_state',
	0,
	11,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	162);
INSERT INTO O_ID
	VALUES (1,
	162);
INSERT INTO O_OIDA
	VALUES (322,
	162,
	1);
INSERT INTO O_ID
	VALUES (2,
	162);
INSERT INTO SM_ISM
	VALUES (1348,
	162);
INSERT INTO SM_SM
	VALUES (1348,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (1348);
INSERT INTO SM_LEVT
	VALUES (1347,
	1348,
	0);
INSERT INTO SM_SEVT
	VALUES (1347,
	1348,
	0);
INSERT INTO SM_EVT
	VALUES (1347,
	1348,
	0,
	1,
	'update',
	0,
	'',
	'ROW1',
	'');
INSERT INTO SM_LEVT
	VALUES (2442,
	1348,
	0);
INSERT INTO SM_SEVT
	VALUES (2442,
	1348,
	0);
INSERT INTO SM_EVT
	VALUES (2442,
	1348,
	0,
	2,
	'solved',
	0,
	'',
	'ROW2',
	'');
INSERT INTO SM_STATE
	VALUES (2443,
	1348,
	0,
	'solving',
	1,
	0);
INSERT INTO SM_SEME
	VALUES (2443,
	1347,
	1348,
	0);
INSERT INTO SM_SEME
	VALUES (2443,
	2442,
	1348,
	0);
INSERT INTO SM_MOAH
	VALUES (2444,
	1348,
	2443);
INSERT INTO SM_AH
	VALUES (2444,
	1348);
INSERT INTO SM_ACT
	VALUES (2444,
	1348,
	1,
	'if ( 100 == self.prune() )
  generate ROW2:solved() to self;
elif ( 100 == self.eliminate() )
  generate ROW2:solved() to self;
else
  select one sequence related by self->SEQUENCE[R1];
  if ( sequence.requests >= 1 )
    sequence.requests = 1;
    r = self;
    generate ROW1:update() to r;
  else
    sequence.requests = 0;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES (2445,
	1348,
	2444);
INSERT INTO ACT_ACT
	VALUES (2445,
	'state',
	0,
	2446,
	0,
	0,
	'row::solving',
	0);
INSERT INTO ACT_BLK
	VALUES (2446,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2445,
	0);
INSERT INTO ACT_SMT
	VALUES (2447,
	2446,
	0,
	1,
	1,
	'row::solving line: 1');
INSERT INTO ACT_IF
	VALUES (2447,
	2448,
	2449,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2450,
	2446,
	0,
	3,
	1,
	'row::solving line: 3');
INSERT INTO ACT_EL
	VALUES (2450,
	2451,
	2452,
	2447);
INSERT INTO ACT_SMT
	VALUES (2453,
	2446,
	0,
	5,
	1,
	'row::solving line: 5');
INSERT INTO ACT_E
	VALUES (2453,
	2454,
	2447);
INSERT INTO V_VAL
	VALUES (2455,
	0,
	0,
	1,
	6,
	8,
	0,
	0,
	0,
	0,
	7,
	2446);
INSERT INTO V_LIN
	VALUES (2455,
	'100');
INSERT INTO V_VAL
	VALUES (2449,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2446);
INSERT INTO V_BIN
	VALUES (2449,
	2456,
	2455,
	'==');
INSERT INTO V_VAL
	VALUES (2456,
	0,
	0,
	1,
	18,
	-1,
	0,
	0,
	0,
	0,
	7,
	2446);
INSERT INTO V_TRV
	VALUES (2456,
	2317,
	2457,
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2458,
	0,
	0,
	3,
	8,
	10,
	0,
	0,
	0,
	0,
	7,
	2446);
INSERT INTO V_LIN
	VALUES (2458,
	'100');
INSERT INTO V_VAL
	VALUES (2452,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2446);
INSERT INTO V_BIN
	VALUES (2452,
	2459,
	2458,
	'==');
INSERT INTO V_VAL
	VALUES (2459,
	0,
	0,
	3,
	20,
	-1,
	0,
	0,
	0,
	0,
	7,
	2446);
INSERT INTO V_TRV
	VALUES (2459,
	2238,
	2457,
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES (2457,
	2446,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (2457,
	0,
	162);
INSERT INTO V_LOC
	VALUES (2460,
	1,
	13,
	16,
	2457);
INSERT INTO V_LOC
	VALUES (2461,
	2,
	29,
	32,
	2457);
INSERT INTO V_LOC
	VALUES (2462,
	3,
	15,
	18,
	2457);
INSERT INTO V_LOC
	VALUES (2463,
	4,
	29,
	32,
	2457);
INSERT INTO V_LOC
	VALUES (2464,
	9,
	9,
	12,
	2457);
INSERT INTO ACT_BLK
	VALUES (2448,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2445,
	0);
INSERT INTO ACT_SMT
	VALUES (2465,
	2448,
	0,
	2,
	3,
	'row::solving line: 2');
INSERT INTO E_ESS
	VALUES (2465,
	1,
	0,
	2,
	12,
	2,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2465);
INSERT INTO E_GSME
	VALUES (2465,
	2442,
	1348);
INSERT INTO E_GEN
	VALUES (2465,
	2457);
INSERT INTO ACT_BLK
	VALUES (2451,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2445,
	0);
INSERT INTO ACT_SMT
	VALUES (2466,
	2451,
	0,
	4,
	3,
	'row::solving line: 4');
INSERT INTO E_ESS
	VALUES (2466,
	1,
	0,
	4,
	12,
	4,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2466);
INSERT INTO E_GSME
	VALUES (2466,
	2442,
	1348);
INSERT INTO E_GEN
	VALUES (2466,
	2457);
INSERT INTO ACT_BLK
	VALUES (2454,
	1,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	6,
	40,
	0,
	0,
	6,
	49,
	0,
	0,
	0,
	0,
	0,
	2445,
	0);
INSERT INTO ACT_SMT
	VALUES (2467,
	2454,
	2468,
	6,
	3,
	'row::solving line: 6');
INSERT INTO ACT_SEL
	VALUES (2467,
	2469,
	1,
	'one',
	2470);
INSERT INTO ACT_SR
	VALUES (2467);
INSERT INTO ACT_LNK
	VALUES (2471,
	'',
	2467,
	286,
	0,
	2,
	109,
	6,
	40,
	6,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2468,
	2454,
	0,
	7,
	3,
	'row::solving line: 7');
INSERT INTO ACT_IF
	VALUES (2468,
	2472,
	2473,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2474,
	2454,
	0,
	11,
	3,
	'row::solving line: 11');
INSERT INTO ACT_E
	VALUES (2474,
	2475,
	2468);
INSERT INTO V_VAL
	VALUES (2470,
	0,
	0,
	6,
	34,
	37,
	0,
	0,
	0,
	0,
	13,
	2454);
INSERT INTO V_IRF
	VALUES (2470,
	2457);
INSERT INTO V_VAL
	VALUES (2476,
	0,
	0,
	7,
	8,
	15,
	0,
	0,
	0,
	0,
	13,
	2454);
INSERT INTO V_IRF
	VALUES (2476,
	2469);
INSERT INTO V_VAL
	VALUES (2477,
	0,
	0,
	7,
	17,
	24,
	0,
	0,
	0,
	0,
	7,
	2454);
INSERT INTO V_AVL
	VALUES (2477,
	2476,
	109,
	320);
INSERT INTO V_VAL
	VALUES (2473,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2454);
INSERT INTO V_BIN
	VALUES (2473,
	2478,
	2477,
	'>=');
INSERT INTO V_VAL
	VALUES (2478,
	0,
	0,
	7,
	29,
	29,
	0,
	0,
	0,
	0,
	7,
	2454);
INSERT INTO V_LIN
	VALUES (2478,
	'1');
INSERT INTO V_VAR
	VALUES (2469,
	2454,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (2469,
	0,
	109);
INSERT INTO V_LOC
	VALUES (2479,
	6,
	14,
	21,
	2469);
INSERT INTO V_LOC
	VALUES (2480,
	7,
	8,
	15,
	2469);
INSERT INTO V_LOC
	VALUES (2481,
	8,
	5,
	12,
	2469);
INSERT INTO V_LOC
	VALUES (2482,
	12,
	5,
	12,
	2469);
INSERT INTO ACT_BLK
	VALUES (2472,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2445,
	0);
INSERT INTO ACT_SMT
	VALUES (2483,
	2472,
	2484,
	8,
	5,
	'row::solving line: 8');
INSERT INTO ACT_AI
	VALUES (2483,
	2485,
	2486,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2484,
	2472,
	2487,
	9,
	5,
	'row::solving line: 9');
INSERT INTO ACT_AI
	VALUES (2484,
	2488,
	2489,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2487,
	2472,
	0,
	10,
	5,
	'row::solving line: 10');
INSERT INTO E_ESS
	VALUES (2487,
	1,
	0,
	10,
	14,
	10,
	19,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2487);
INSERT INTO E_GSME
	VALUES (2487,
	1347,
	1348);
INSERT INTO E_GEN
	VALUES (2487,
	2490);
INSERT INTO V_VAL
	VALUES (2491,
	1,
	0,
	8,
	5,
	12,
	0,
	0,
	0,
	0,
	13,
	2472);
INSERT INTO V_IRF
	VALUES (2491,
	2469);
INSERT INTO V_VAL
	VALUES (2486,
	1,
	0,
	8,
	14,
	21,
	0,
	0,
	0,
	0,
	7,
	2472);
INSERT INTO V_AVL
	VALUES (2486,
	2491,
	109,
	320);
INSERT INTO V_VAL
	VALUES (2485,
	0,
	0,
	8,
	25,
	25,
	0,
	0,
	0,
	0,
	7,
	2472);
INSERT INTO V_LIN
	VALUES (2485,
	'1');
INSERT INTO V_VAL
	VALUES (2489,
	1,
	1,
	9,
	5,
	5,
	0,
	0,
	0,
	0,
	13,
	2472);
INSERT INTO V_IRF
	VALUES (2489,
	2490);
INSERT INTO V_VAL
	VALUES (2488,
	0,
	0,
	9,
	9,
	12,
	0,
	0,
	0,
	0,
	13,
	2472);
INSERT INTO V_IRF
	VALUES (2488,
	2457);
INSERT INTO V_VAR
	VALUES (2490,
	2472,
	'r',
	1,
	13);
INSERT INTO V_INT
	VALUES (2490,
	0,
	162);
INSERT INTO V_LOC
	VALUES (2492,
	9,
	5,
	5,
	2490);
INSERT INTO V_LOC
	VALUES (2493,
	10,
	31,
	31,
	2490);
INSERT INTO ACT_BLK
	VALUES (2475,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2445,
	0);
INSERT INTO ACT_SMT
	VALUES (2494,
	2475,
	0,
	12,
	5,
	'row::solving line: 12');
INSERT INTO ACT_AI
	VALUES (2494,
	2495,
	2496,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2497,
	1,
	0,
	12,
	5,
	12,
	0,
	0,
	0,
	0,
	13,
	2475);
INSERT INTO V_IRF
	VALUES (2497,
	2469);
INSERT INTO V_VAL
	VALUES (2496,
	1,
	0,
	12,
	14,
	21,
	0,
	0,
	0,
	0,
	7,
	2475);
INSERT INTO V_AVL
	VALUES (2496,
	2497,
	109,
	320);
INSERT INTO V_VAL
	VALUES (2495,
	0,
	0,
	12,
	25,
	25,
	0,
	0,
	0,
	0,
	7,
	2475);
INSERT INTO V_LIN
	VALUES (2495,
	'0');
INSERT INTO SM_STATE
	VALUES (2498,
	1348,
	0,
	'solved',
	3,
	0);
INSERT INTO SM_EIGN
	VALUES (2498,
	1347,
	1348,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2498,
	1347,
	1348,
	0);
INSERT INTO SM_EIGN
	VALUES (2498,
	2442,
	1348,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2498,
	2442,
	1348,
	0);
INSERT INTO SM_MOAH
	VALUES (2499,
	1348,
	2498);
INSERT INTO SM_AH
	VALUES (2499,
	1348);
INSERT INTO SM_ACT
	VALUES (2499,
	1348,
	1,
	'select one sequence related by self->SEQUENCE[R1];
sequence.solved = true;',
	'');
INSERT INTO ACT_SAB
	VALUES (2500,
	1348,
	2499);
INSERT INTO ACT_ACT
	VALUES (2500,
	'state',
	0,
	2501,
	0,
	0,
	'row::solved',
	0);
INSERT INTO ACT_BLK
	VALUES (2501,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	1,
	47,
	0,
	0,
	0,
	0,
	0,
	2500,
	0);
INSERT INTO ACT_SMT
	VALUES (2502,
	2501,
	2503,
	1,
	1,
	'row::solved line: 1');
INSERT INTO ACT_SEL
	VALUES (2502,
	2504,
	1,
	'one',
	2505);
INSERT INTO ACT_SR
	VALUES (2502);
INSERT INTO ACT_LNK
	VALUES (2506,
	'',
	2502,
	286,
	0,
	2,
	109,
	1,
	38,
	1,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2503,
	2501,
	0,
	2,
	1,
	'row::solved line: 2');
INSERT INTO ACT_AI
	VALUES (2503,
	2507,
	2508,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2505,
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	13,
	2501);
INSERT INTO V_IRF
	VALUES (2505,
	2509);
INSERT INTO V_VAL
	VALUES (2510,
	1,
	0,
	2,
	1,
	8,
	0,
	0,
	0,
	0,
	13,
	2501);
INSERT INTO V_IRF
	VALUES (2510,
	2504);
INSERT INTO V_VAL
	VALUES (2508,
	1,
	0,
	2,
	10,
	15,
	0,
	0,
	0,
	0,
	6,
	2501);
INSERT INTO V_AVL
	VALUES (2508,
	2510,
	109,
	318);
INSERT INTO V_VAL
	VALUES (2507,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2501);
INSERT INTO V_LBO
	VALUES (2507,
	'TRUE');
INSERT INTO V_VAR
	VALUES (2504,
	2501,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (2504,
	0,
	109);
INSERT INTO V_LOC
	VALUES (2511,
	1,
	12,
	19,
	2504);
INSERT INTO V_LOC
	VALUES (2512,
	2,
	1,
	8,
	2504);
INSERT INTO V_VAR
	VALUES (2509,
	2501,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (2509,
	0,
	162);
INSERT INTO SM_NSTXN
	VALUES (2513,
	1348,
	2443,
	1347,
	0);
INSERT INTO SM_TAH
	VALUES (2514,
	1348,
	2513);
INSERT INTO SM_AH
	VALUES (2514,
	1348);
INSERT INTO SM_ACT
	VALUES (2514,
	1348,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (2515,
	1348,
	2514);
INSERT INTO ACT_ACT
	VALUES (2515,
	'transition',
	0,
	2516,
	0,
	0,
	'ROW1: update in solving to solving',
	0);
INSERT INTO ACT_BLK
	VALUES (2516,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2515,
	0);
INSERT INTO SM_TXN
	VALUES (2513,
	1348,
	2443,
	0);
INSERT INTO SM_NSTXN
	VALUES (2517,
	1348,
	2443,
	2442,
	0);
INSERT INTO SM_TAH
	VALUES (2518,
	1348,
	2517);
INSERT INTO SM_AH
	VALUES (2518,
	1348);
INSERT INTO SM_ACT
	VALUES (2518,
	1348,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (2519,
	1348,
	2518);
INSERT INTO ACT_ACT
	VALUES (2519,
	'transition',
	0,
	2520,
	0,
	0,
	'ROW2: solved in solving to solved',
	0);
INSERT INTO ACT_BLK
	VALUES (2520,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2519,
	0);
INSERT INTO SM_TXN
	VALUES (2517,
	1348,
	2498,
	0);
INSERT INTO O_OBJ
	VALUES (109,
	'sequence',
	1,
	'SEQUENCE',
	'',
	1374);
INSERT INTO O_TFR
	VALUES (803,
	109,
	'solve',
	'',
	5,
	0,
	'i = 0;
select many sequences from instances of SEQUENCE;
while ( 25 > i )
  j = 0;
  while ( 25 > j )
    ::display();
    
    select many eligibles from instances of ELIGIBLE;
    count1 = cardinality eligibles;
    count2 = 0;
    
    for each sequence in sequences
      k = sequence.solve_by_pruning();
    end for;
    
    select many eligibles from instances of ELIGIBLE;
    count2 = cardinality eligibles;
    
    if ( ( 81 == CELL::score() ) or ( count1 == count2 ) )
      break;
    end if;

    j = j + 1;
  end while;

  for each sequence in sequences
    k = sequence.solve_by_elimination();
  end for;
  
  if ( 81 == CELL::score() )
    break;
  end if;
  
  i = i + 1;
end while;

//#inline
// printf( "passes:  %d\n", v324_i );
// 
',
	1,
	'',
	0);
INSERT INTO ACT_OPB
	VALUES (2521,
	803);
INSERT INTO ACT_ACT
	VALUES (2521,
	'class operation',
	0,
	2522,
	0,
	0,
	'sequence::solve',
	0);
INSERT INTO ACT_BLK
	VALUES (2522,
	1,
	0,
	0,
	'',
	'',
	'',
	3,
	1,
	2,
	41,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2521,
	0);
INSERT INTO ACT_SMT
	VALUES (2523,
	2522,
	2524,
	1,
	1,
	'sequence::solve line: 1');
INSERT INTO ACT_AI
	VALUES (2523,
	2525,
	2526,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2524,
	2522,
	2527,
	2,
	1,
	'sequence::solve line: 2');
INSERT INTO ACT_FIO
	VALUES (2524,
	2528,
	1,
	'many',
	109,
	2,
	41);
INSERT INTO ACT_SMT
	VALUES (2527,
	2522,
	0,
	3,
	1,
	'sequence::solve line: 3');
INSERT INTO ACT_WHL
	VALUES (2527,
	2529,
	2530);
INSERT INTO V_VAL
	VALUES (2526,
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	7,
	2522);
INSERT INTO V_TVL
	VALUES (2526,
	2531);
INSERT INTO V_VAL
	VALUES (2525,
	0,
	0,
	1,
	5,
	5,
	0,
	0,
	0,
	0,
	7,
	2522);
INSERT INTO V_LIN
	VALUES (2525,
	'0');
INSERT INTO V_VAL
	VALUES (2532,
	0,
	0,
	3,
	9,
	10,
	0,
	0,
	0,
	0,
	7,
	2522);
INSERT INTO V_LIN
	VALUES (2532,
	'25');
INSERT INTO V_VAL
	VALUES (2529,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2522);
INSERT INTO V_BIN
	VALUES (2529,
	2533,
	2532,
	'>');
INSERT INTO V_VAL
	VALUES (2533,
	0,
	0,
	3,
	14,
	14,
	0,
	0,
	0,
	0,
	7,
	2522);
INSERT INTO V_TVL
	VALUES (2533,
	2531);
INSERT INTO V_VAR
	VALUES (2531,
	2522,
	'i',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2531,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2534,
	1,
	1,
	1,
	2531);
INSERT INTO V_LOC
	VALUES (2535,
	3,
	14,
	14,
	2531);
INSERT INTO V_LOC
	VALUES (2536,
	34,
	3,
	3,
	2531);
INSERT INTO V_LOC
	VALUES (2537,
	34,
	7,
	7,
	2531);
INSERT INTO V_VAR
	VALUES (2528,
	2522,
	'sequences',
	1,
	14);
INSERT INTO V_INS
	VALUES (2528,
	109);
INSERT INTO V_LOC
	VALUES (2538,
	2,
	13,
	21,
	2528);
INSERT INTO V_LOC
	VALUES (2539,
	12,
	26,
	34,
	2528);
INSERT INTO V_LOC
	VALUES (2540,
	26,
	24,
	32,
	2528);
INSERT INTO ACT_BLK
	VALUES (2530,
	0,
	0,
	0,
	'CELL',
	'',
	'',
	34,
	3,
	30,
	14,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2521,
	0);
INSERT INTO ACT_SMT
	VALUES (2541,
	2530,
	2542,
	4,
	3,
	'sequence::solve line: 4');
INSERT INTO ACT_AI
	VALUES (2541,
	2543,
	2544,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2542,
	2530,
	2545,
	5,
	3,
	'sequence::solve line: 5');
INSERT INTO ACT_WHL
	VALUES (2542,
	2546,
	2547);
INSERT INTO ACT_SMT
	VALUES (2545,
	2530,
	2548,
	26,
	3,
	'sequence::solve line: 26');
INSERT INTO ACT_FOR
	VALUES (2545,
	2549,
	1,
	2550,
	2528,
	109);
INSERT INTO ACT_SMT
	VALUES (2548,
	2530,
	2551,
	30,
	3,
	'sequence::solve line: 30');
INSERT INTO ACT_IF
	VALUES (2548,
	2552,
	2553,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2551,
	2530,
	0,
	34,
	3,
	'sequence::solve line: 34');
INSERT INTO ACT_AI
	VALUES (2551,
	2554,
	2555,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2544,
	1,
	1,
	4,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	2530);
INSERT INTO V_TVL
	VALUES (2544,
	2556);
INSERT INTO V_VAL
	VALUES (2543,
	0,
	0,
	4,
	7,
	7,
	0,
	0,
	0,
	0,
	7,
	2530);
INSERT INTO V_LIN
	VALUES (2543,
	'0');
INSERT INTO V_VAL
	VALUES (2557,
	0,
	0,
	5,
	11,
	12,
	0,
	0,
	0,
	0,
	7,
	2530);
INSERT INTO V_LIN
	VALUES (2557,
	'25');
INSERT INTO V_VAL
	VALUES (2546,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2530);
INSERT INTO V_BIN
	VALUES (2546,
	2558,
	2557,
	'>');
INSERT INTO V_VAL
	VALUES (2558,
	0,
	0,
	5,
	16,
	16,
	0,
	0,
	0,
	0,
	7,
	2530);
INSERT INTO V_TVL
	VALUES (2558,
	2556);
INSERT INTO V_VAL
	VALUES (2559,
	0,
	0,
	30,
	8,
	9,
	0,
	0,
	0,
	0,
	7,
	2530);
INSERT INTO V_LIN
	VALUES (2559,
	'81');
INSERT INTO V_VAL
	VALUES (2553,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2530);
INSERT INTO V_BIN
	VALUES (2553,
	2560,
	2559,
	'==');
INSERT INTO V_VAL
	VALUES (2560,
	0,
	0,
	30,
	20,
	-1,
	0,
	0,
	0,
	0,
	7,
	2530);
INSERT INTO V_TRV
	VALUES (2560,
	813,
	0,
	1,
	30,
	14);
INSERT INTO V_VAL
	VALUES (2555,
	1,
	0,
	34,
	3,
	3,
	0,
	0,
	0,
	0,
	7,
	2530);
INSERT INTO V_TVL
	VALUES (2555,
	2531);
INSERT INTO V_VAL
	VALUES (2561,
	0,
	0,
	34,
	7,
	7,
	0,
	0,
	0,
	0,
	7,
	2530);
INSERT INTO V_TVL
	VALUES (2561,
	2531);
INSERT INTO V_VAL
	VALUES (2554,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	2530);
INSERT INTO V_BIN
	VALUES (2554,
	2562,
	2561,
	'+');
INSERT INTO V_VAL
	VALUES (2562,
	0,
	0,
	34,
	11,
	11,
	0,
	0,
	0,
	0,
	7,
	2530);
INSERT INTO V_LIN
	VALUES (2562,
	'1');
INSERT INTO V_VAR
	VALUES (2556,
	2530,
	'j',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2556,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2563,
	4,
	3,
	3,
	2556);
INSERT INTO V_LOC
	VALUES (2564,
	5,
	16,
	16,
	2556);
INSERT INTO V_LOC
	VALUES (2565,
	23,
	5,
	5,
	2556);
INSERT INTO V_LOC
	VALUES (2566,
	23,
	9,
	9,
	2556);
INSERT INTO V_VAR
	VALUES (2550,
	2530,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (2550,
	1,
	109);
INSERT INTO V_LOC
	VALUES (2567,
	26,
	12,
	19,
	2550);
INSERT INTO V_LOC
	VALUES (2568,
	27,
	9,
	16,
	2550);
INSERT INTO ACT_BLK
	VALUES (2547,
	1,
	0,
	0,
	'CELL',
	'',
	'',
	23,
	5,
	19,
	18,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2521,
	0);
INSERT INTO ACT_SMT
	VALUES (2569,
	2547,
	2570,
	6,
	5,
	'sequence::solve line: 6');
INSERT INTO ACT_FNC
	VALUES (2569,
	733,
	6,
	7);
INSERT INTO ACT_SMT
	VALUES (2570,
	2547,
	2571,
	8,
	5,
	'sequence::solve line: 8');
INSERT INTO ACT_FIO
	VALUES (2570,
	2572,
	1,
	'many',
	382,
	8,
	45);
INSERT INTO ACT_SMT
	VALUES (2571,
	2547,
	2573,
	9,
	5,
	'sequence::solve line: 9');
INSERT INTO ACT_AI
	VALUES (2571,
	2574,
	2575,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2573,
	2547,
	2576,
	10,
	5,
	'sequence::solve line: 10');
INSERT INTO ACT_AI
	VALUES (2573,
	2577,
	2578,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2576,
	2547,
	2579,
	12,
	5,
	'sequence::solve line: 12');
INSERT INTO ACT_FOR
	VALUES (2576,
	2580,
	1,
	2581,
	2528,
	109);
INSERT INTO ACT_SMT
	VALUES (2579,
	2547,
	2582,
	16,
	5,
	'sequence::solve line: 16');
INSERT INTO ACT_FIO
	VALUES (2579,
	2572,
	0,
	'many',
	382,
	16,
	45);
INSERT INTO ACT_SMT
	VALUES (2582,
	2547,
	2583,
	17,
	5,
	'sequence::solve line: 17');
INSERT INTO ACT_AI
	VALUES (2582,
	2584,
	2585,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2583,
	2547,
	2586,
	19,
	5,
	'sequence::solve line: 19');
INSERT INTO ACT_IF
	VALUES (2583,
	2587,
	2588,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2586,
	2547,
	0,
	23,
	5,
	'sequence::solve line: 23');
INSERT INTO ACT_AI
	VALUES (2586,
	2589,
	2590,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2575,
	1,
	1,
	9,
	5,
	10,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_TVL
	VALUES (2575,
	2591);
INSERT INTO V_VAL
	VALUES (2592,
	0,
	0,
	9,
	26,
	34,
	0,
	0,
	0,
	0,
	14,
	2547);
INSERT INTO V_ISR
	VALUES (2592,
	2572);
INSERT INTO V_VAL
	VALUES (2574,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_UNY
	VALUES (2574,
	2592,
	'cardinality');
INSERT INTO V_VAL
	VALUES (2578,
	1,
	1,
	10,
	5,
	10,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_TVL
	VALUES (2578,
	2593);
INSERT INTO V_VAL
	VALUES (2577,
	0,
	0,
	10,
	14,
	14,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_LIN
	VALUES (2577,
	'0');
INSERT INTO V_VAL
	VALUES (2585,
	1,
	0,
	17,
	5,
	10,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_TVL
	VALUES (2585,
	2593);
INSERT INTO V_VAL
	VALUES (2594,
	0,
	0,
	17,
	26,
	34,
	0,
	0,
	0,
	0,
	14,
	2547);
INSERT INTO V_ISR
	VALUES (2594,
	2572);
INSERT INTO V_VAL
	VALUES (2584,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_UNY
	VALUES (2584,
	2594,
	'cardinality');
INSERT INTO V_VAL
	VALUES (2595,
	0,
	0,
	19,
	12,
	13,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_LIN
	VALUES (2595,
	'81');
INSERT INTO V_VAL
	VALUES (2596,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2547);
INSERT INTO V_BIN
	VALUES (2596,
	2597,
	2595,
	'==');
INSERT INTO V_VAL
	VALUES (2597,
	0,
	0,
	19,
	24,
	-1,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_TRV
	VALUES (2597,
	813,
	0,
	1,
	19,
	18);
INSERT INTO V_VAL
	VALUES (2598,
	0,
	0,
	19,
	39,
	44,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_TVL
	VALUES (2598,
	2591);
INSERT INTO V_VAL
	VALUES (2599,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2547);
INSERT INTO V_BIN
	VALUES (2599,
	2600,
	2598,
	'==');
INSERT INTO V_VAL
	VALUES (2600,
	0,
	0,
	19,
	49,
	54,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_TVL
	VALUES (2600,
	2593);
INSERT INTO V_VAL
	VALUES (2588,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2547);
INSERT INTO V_BIN
	VALUES (2588,
	2599,
	2596,
	'or');
INSERT INTO V_VAL
	VALUES (2590,
	1,
	0,
	23,
	5,
	5,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_TVL
	VALUES (2590,
	2556);
INSERT INTO V_VAL
	VALUES (2601,
	0,
	0,
	23,
	9,
	9,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_TVL
	VALUES (2601,
	2556);
INSERT INTO V_VAL
	VALUES (2589,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_BIN
	VALUES (2589,
	2602,
	2601,
	'+');
INSERT INTO V_VAL
	VALUES (2602,
	0,
	0,
	23,
	13,
	13,
	0,
	0,
	0,
	0,
	7,
	2547);
INSERT INTO V_LIN
	VALUES (2602,
	'1');
INSERT INTO V_VAR
	VALUES (2572,
	2547,
	'eligibles',
	1,
	14);
INSERT INTO V_INS
	VALUES (2572,
	382);
INSERT INTO V_LOC
	VALUES (2603,
	8,
	17,
	25,
	2572);
INSERT INTO V_LOC
	VALUES (2604,
	16,
	17,
	25,
	2572);
INSERT INTO V_VAR
	VALUES (2591,
	2547,
	'count1',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2591,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2605,
	9,
	5,
	10,
	2591);
INSERT INTO V_LOC
	VALUES (2606,
	19,
	39,
	44,
	2591);
INSERT INTO V_VAR
	VALUES (2593,
	2547,
	'count2',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2593,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2607,
	10,
	5,
	10,
	2593);
INSERT INTO V_LOC
	VALUES (2608,
	17,
	5,
	10,
	2593);
INSERT INTO V_LOC
	VALUES (2609,
	19,
	49,
	54,
	2593);
INSERT INTO V_VAR
	VALUES (2581,
	2547,
	'sequence',
	1,
	13);
INSERT INTO V_INT
	VALUES (2581,
	1,
	109);
INSERT INTO V_LOC
	VALUES (2610,
	12,
	14,
	21,
	2581);
INSERT INTO V_LOC
	VALUES (2611,
	13,
	11,
	18,
	2581);
INSERT INTO ACT_BLK
	VALUES (2580,
	0,
	0,
	0,
	'',
	'',
	'',
	13,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2521,
	0);
INSERT INTO ACT_SMT
	VALUES (2612,
	2580,
	0,
	13,
	7,
	'sequence::solve line: 13');
INSERT INTO ACT_AI
	VALUES (2612,
	2613,
	2614,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2614,
	1,
	1,
	13,
	7,
	7,
	0,
	0,
	0,
	0,
	7,
	2580);
INSERT INTO V_TVL
	VALUES (2614,
	2615);
INSERT INTO V_VAL
	VALUES (2613,
	0,
	0,
	13,
	20,
	-1,
	0,
	0,
	0,
	0,
	7,
	2580);
INSERT INTO V_TRV
	VALUES (2613,
	2616,
	2581,
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES (2615,
	2580,
	'k',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2615,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2617,
	13,
	7,
	7,
	2615);
INSERT INTO ACT_BLK
	VALUES (2587,
	0,
	0,
	0,
	'',
	'',
	'',
	20,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2521,
	0);
INSERT INTO ACT_SMT
	VALUES (2618,
	2587,
	0,
	20,
	7,
	'sequence::solve line: 20');
INSERT INTO ACT_BRK
	VALUES (2618);
INSERT INTO ACT_BLK
	VALUES (2549,
	0,
	0,
	0,
	'',
	'',
	'',
	27,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2521,
	0);
INSERT INTO ACT_SMT
	VALUES (2619,
	2549,
	0,
	27,
	5,
	'sequence::solve line: 27');
INSERT INTO ACT_AI
	VALUES (2619,
	2620,
	2621,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2621,
	1,
	1,
	27,
	5,
	5,
	0,
	0,
	0,
	0,
	7,
	2549);
INSERT INTO V_TVL
	VALUES (2621,
	2622);
INSERT INTO V_VAL
	VALUES (2620,
	0,
	0,
	27,
	18,
	-1,
	0,
	0,
	0,
	0,
	7,
	2549);
INSERT INTO V_TRV
	VALUES (2620,
	2623,
	2550,
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES (2622,
	2549,
	'k',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2622,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2624,
	27,
	5,
	5,
	2622);
INSERT INTO ACT_BLK
	VALUES (2552,
	0,
	0,
	0,
	'',
	'',
	'',
	31,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2521,
	0);
INSERT INTO ACT_SMT
	VALUES (2625,
	2552,
	0,
	31,
	5,
	'sequence::solve line: 31');
INSERT INTO ACT_BRK
	VALUES (2625);
INSERT INTO O_TFR
	VALUES (2623,
	109,
	'solve_by_elimination',
	'',
	7,
	1,
	'temperature = 0;
select one row related by self->ROW[R1];
if ( not_empty row )
  temperature = row.eliminate();
else
  select one column related by self->COLUMN[R1];
  if ( not_empty column )
    temperature = column.eliminate();
  else
    select one box related by self->BOX[R1];
    if ( not_empty box )
      temperature = box.eliminate();
    else
      LOG::LogFailure( message:"could not eliminate related sequence" );
    end if;
  end if;
end if;
return temperature;

',
	1,
	'',
	803);
INSERT INTO ACT_OPB
	VALUES (2626,
	2623);
INSERT INTO ACT_ACT
	VALUES (2626,
	'operation',
	0,
	2627,
	0,
	0,
	'sequence::solve_by_elimination',
	0);
INSERT INTO ACT_BLK
	VALUES (2627,
	1,
	0,
	0,
	'',
	'',
	'',
	18,
	1,
	2,
	33,
	0,
	0,
	2,
	37,
	0,
	0,
	0,
	0,
	0,
	2626,
	0);
INSERT INTO ACT_SMT
	VALUES (2628,
	2627,
	2629,
	1,
	1,
	'sequence::solve_by_elimination line: 1');
INSERT INTO ACT_AI
	VALUES (2628,
	2630,
	2631,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2629,
	2627,
	2632,
	2,
	1,
	'sequence::solve_by_elimination line: 2');
INSERT INTO ACT_SEL
	VALUES (2629,
	2633,
	1,
	'one',
	2634);
INSERT INTO ACT_SR
	VALUES (2629);
INSERT INTO ACT_LNK
	VALUES (2635,
	'',
	2629,
	286,
	0,
	2,
	162,
	2,
	33,
	2,
	37,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2632,
	2627,
	2636,
	3,
	1,
	'sequence::solve_by_elimination line: 3');
INSERT INTO ACT_IF
	VALUES (2632,
	2637,
	2638,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2639,
	2627,
	0,
	5,
	1,
	'sequence::solve_by_elimination line: 5');
INSERT INTO ACT_E
	VALUES (2639,
	2640,
	2632);
INSERT INTO ACT_SMT
	VALUES (2636,
	2627,
	0,
	18,
	1,
	'sequence::solve_by_elimination line: 18');
INSERT INTO ACT_RET
	VALUES (2636,
	2641);
INSERT INTO V_VAL
	VALUES (2631,
	1,
	1,
	1,
	1,
	11,
	0,
	0,
	0,
	0,
	7,
	2627);
INSERT INTO V_TVL
	VALUES (2631,
	2642);
INSERT INTO V_VAL
	VALUES (2630,
	0,
	0,
	1,
	15,
	15,
	0,
	0,
	0,
	0,
	7,
	2627);
INSERT INTO V_LIN
	VALUES (2630,
	'0');
INSERT INTO V_VAL
	VALUES (2634,
	0,
	0,
	2,
	27,
	30,
	0,
	0,
	0,
	0,
	13,
	2627);
INSERT INTO V_IRF
	VALUES (2634,
	2643);
INSERT INTO V_VAL
	VALUES (2644,
	0,
	0,
	3,
	16,
	18,
	0,
	0,
	0,
	0,
	13,
	2627);
INSERT INTO V_IRF
	VALUES (2644,
	2633);
INSERT INTO V_VAL
	VALUES (2638,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2627);
INSERT INTO V_UNY
	VALUES (2638,
	2644,
	'not_empty');
INSERT INTO V_VAL
	VALUES (2641,
	0,
	0,
	18,
	8,
	18,
	0,
	0,
	0,
	0,
	7,
	2627);
INSERT INTO V_TVL
	VALUES (2641,
	2642);
INSERT INTO V_VAR
	VALUES (2642,
	2627,
	'temperature',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2642,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2645,
	1,
	1,
	11,
	2642);
INSERT INTO V_LOC
	VALUES (2646,
	4,
	3,
	13,
	2642);
INSERT INTO V_LOC
	VALUES (2647,
	8,
	5,
	15,
	2642);
INSERT INTO V_LOC
	VALUES (2648,
	12,
	7,
	17,
	2642);
INSERT INTO V_LOC
	VALUES (2649,
	18,
	8,
	18,
	2642);
INSERT INTO V_VAR
	VALUES (2633,
	2627,
	'row',
	1,
	13);
INSERT INTO V_INT
	VALUES (2633,
	0,
	162);
INSERT INTO V_LOC
	VALUES (2650,
	2,
	12,
	14,
	2633);
INSERT INTO V_LOC
	VALUES (2651,
	4,
	17,
	19,
	2633);
INSERT INTO V_VAR
	VALUES (2643,
	2627,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (2643,
	0,
	109);
INSERT INTO ACT_BLK
	VALUES (2637,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2626,
	0);
INSERT INTO ACT_SMT
	VALUES (2652,
	2637,
	0,
	4,
	3,
	'sequence::solve_by_elimination line: 4');
INSERT INTO ACT_AI
	VALUES (2652,
	2653,
	2654,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2654,
	1,
	0,
	4,
	3,
	13,
	0,
	0,
	0,
	0,
	7,
	2637);
INSERT INTO V_TVL
	VALUES (2654,
	2642);
INSERT INTO V_VAL
	VALUES (2653,
	0,
	0,
	4,
	21,
	-1,
	0,
	0,
	0,
	0,
	7,
	2637);
INSERT INTO V_TRV
	VALUES (2653,
	2238,
	2633,
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2640,
	1,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	6,
	38,
	0,
	0,
	6,
	45,
	0,
	0,
	0,
	0,
	0,
	2626,
	0);
INSERT INTO ACT_SMT
	VALUES (2655,
	2640,
	2656,
	6,
	3,
	'sequence::solve_by_elimination line: 6');
INSERT INTO ACT_SEL
	VALUES (2655,
	2657,
	1,
	'one',
	2658);
INSERT INTO ACT_SR
	VALUES (2655);
INSERT INTO ACT_LNK
	VALUES (2659,
	'',
	2655,
	286,
	0,
	2,
	296,
	6,
	38,
	6,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2656,
	2640,
	0,
	7,
	3,
	'sequence::solve_by_elimination line: 7');
INSERT INTO ACT_IF
	VALUES (2656,
	2660,
	2661,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2662,
	2640,
	0,
	9,
	3,
	'sequence::solve_by_elimination line: 9');
INSERT INTO ACT_E
	VALUES (2662,
	2663,
	2656);
INSERT INTO V_VAL
	VALUES (2658,
	0,
	0,
	6,
	32,
	35,
	0,
	0,
	0,
	0,
	13,
	2640);
INSERT INTO V_IRF
	VALUES (2658,
	2643);
INSERT INTO V_VAL
	VALUES (2664,
	0,
	0,
	7,
	18,
	23,
	0,
	0,
	0,
	0,
	13,
	2640);
INSERT INTO V_IRF
	VALUES (2664,
	2657);
INSERT INTO V_VAL
	VALUES (2661,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2640);
INSERT INTO V_UNY
	VALUES (2661,
	2664,
	'not_empty');
INSERT INTO V_VAR
	VALUES (2657,
	2640,
	'column',
	1,
	13);
INSERT INTO V_INT
	VALUES (2657,
	0,
	296);
INSERT INTO V_LOC
	VALUES (2665,
	6,
	14,
	19,
	2657);
INSERT INTO V_LOC
	VALUES (2666,
	8,
	19,
	24,
	2657);
INSERT INTO ACT_BLK
	VALUES (2660,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2626,
	0);
INSERT INTO ACT_SMT
	VALUES (2667,
	2660,
	0,
	8,
	5,
	'sequence::solve_by_elimination line: 8');
INSERT INTO ACT_AI
	VALUES (2667,
	2668,
	2669,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2669,
	1,
	0,
	8,
	5,
	15,
	0,
	0,
	0,
	0,
	7,
	2660);
INSERT INTO V_TVL
	VALUES (2669,
	2642);
INSERT INTO V_VAL
	VALUES (2668,
	0,
	0,
	8,
	26,
	-1,
	0,
	0,
	0,
	0,
	7,
	2660);
INSERT INTO V_TRV
	VALUES (2668,
	1948,
	2657,
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2663,
	1,
	0,
	0,
	'',
	'',
	'',
	13,
	5,
	10,
	37,
	0,
	0,
	10,
	41,
	0,
	0,
	0,
	0,
	0,
	2626,
	0);
INSERT INTO ACT_SMT
	VALUES (2670,
	2663,
	2671,
	10,
	5,
	'sequence::solve_by_elimination line: 10');
INSERT INTO ACT_SEL
	VALUES (2670,
	2672,
	1,
	'one',
	2673);
INSERT INTO ACT_SR
	VALUES (2670);
INSERT INTO ACT_LNK
	VALUES (2674,
	'',
	2670,
	286,
	0,
	2,
	310,
	10,
	37,
	10,
	41,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2671,
	2663,
	0,
	11,
	5,
	'sequence::solve_by_elimination line: 11');
INSERT INTO ACT_IF
	VALUES (2671,
	2675,
	2676,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2677,
	2663,
	0,
	13,
	5,
	'sequence::solve_by_elimination line: 13');
INSERT INTO ACT_E
	VALUES (2677,
	2678,
	2671);
INSERT INTO V_VAL
	VALUES (2673,
	0,
	0,
	10,
	31,
	34,
	0,
	0,
	0,
	0,
	13,
	2663);
INSERT INTO V_IRF
	VALUES (2673,
	2643);
INSERT INTO V_VAL
	VALUES (2679,
	0,
	0,
	11,
	20,
	22,
	0,
	0,
	0,
	0,
	13,
	2663);
INSERT INTO V_IRF
	VALUES (2679,
	2672);
INSERT INTO V_VAL
	VALUES (2676,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2663);
INSERT INTO V_UNY
	VALUES (2676,
	2679,
	'not_empty');
INSERT INTO V_VAR
	VALUES (2672,
	2663,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (2672,
	0,
	310);
INSERT INTO V_LOC
	VALUES (2680,
	10,
	16,
	18,
	2672);
INSERT INTO V_LOC
	VALUES (2681,
	12,
	21,
	23,
	2672);
INSERT INTO ACT_BLK
	VALUES (2675,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2626,
	0);
INSERT INTO ACT_SMT
	VALUES (2682,
	2675,
	0,
	12,
	7,
	'sequence::solve_by_elimination line: 12');
INSERT INTO ACT_AI
	VALUES (2682,
	2683,
	2684,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2684,
	1,
	0,
	12,
	7,
	17,
	0,
	0,
	0,
	0,
	7,
	2675);
INSERT INTO V_TVL
	VALUES (2684,
	2642);
INSERT INTO V_VAL
	VALUES (2683,
	0,
	0,
	12,
	25,
	-1,
	0,
	0,
	0,
	0,
	7,
	2675);
INSERT INTO V_TRV
	VALUES (2683,
	1376,
	2672,
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2678,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	14,
	7,
	14,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2626,
	0);
INSERT INTO ACT_SMT
	VALUES (2685,
	2678,
	0,
	14,
	7,
	'sequence::solve_by_elimination line: 14');
INSERT INTO ACT_BRG
	VALUES (2685,
	65,
	14,
	12,
	14,
	7);
INSERT INTO V_VAL
	VALUES (2686,
	0,
	0,
	14,
	32,
	68,
	0,
	0,
	0,
	0,
	9,
	2678);
INSERT INTO V_LST
	VALUES (2686,
	'could not eliminate related sequence');
INSERT INTO V_PAR
	VALUES (2686,
	2685,
	0,
	'message',
	0,
	14,
	24);
INSERT INTO O_TFR
	VALUES (2616,
	109,
	'solve_by_pruning',
	'',
	7,
	1,
	'temperature = 0;
select one row related by self->ROW[R1];
if ( not_empty row )
  temperature = row.prune();
else
  select one column related by self->COLUMN[R1];
  if ( not_empty column )
    temperature = column.prune();
  else
    select one box related by self->BOX[R1];
    if ( not_empty box )
      temperature = box.prune();
    else
      LOG::LogFailure( message:"could not prune related sequence" );
    end if;
  end if;
end if;
return temperature;

',
	1,
	'',
	2623);
INSERT INTO ACT_OPB
	VALUES (2687,
	2616);
INSERT INTO ACT_ACT
	VALUES (2687,
	'operation',
	0,
	2688,
	0,
	0,
	'sequence::solve_by_pruning',
	0);
INSERT INTO ACT_BLK
	VALUES (2688,
	1,
	0,
	0,
	'',
	'',
	'',
	18,
	1,
	2,
	33,
	0,
	0,
	2,
	37,
	0,
	0,
	0,
	0,
	0,
	2687,
	0);
INSERT INTO ACT_SMT
	VALUES (2689,
	2688,
	2690,
	1,
	1,
	'sequence::solve_by_pruning line: 1');
INSERT INTO ACT_AI
	VALUES (2689,
	2691,
	2692,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2690,
	2688,
	2693,
	2,
	1,
	'sequence::solve_by_pruning line: 2');
INSERT INTO ACT_SEL
	VALUES (2690,
	2694,
	1,
	'one',
	2695);
INSERT INTO ACT_SR
	VALUES (2690);
INSERT INTO ACT_LNK
	VALUES (2696,
	'',
	2690,
	286,
	0,
	2,
	162,
	2,
	33,
	2,
	37,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2693,
	2688,
	2697,
	3,
	1,
	'sequence::solve_by_pruning line: 3');
INSERT INTO ACT_IF
	VALUES (2693,
	2698,
	2699,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2700,
	2688,
	0,
	5,
	1,
	'sequence::solve_by_pruning line: 5');
INSERT INTO ACT_E
	VALUES (2700,
	2701,
	2693);
INSERT INTO ACT_SMT
	VALUES (2697,
	2688,
	0,
	18,
	1,
	'sequence::solve_by_pruning line: 18');
INSERT INTO ACT_RET
	VALUES (2697,
	2702);
INSERT INTO V_VAL
	VALUES (2692,
	1,
	1,
	1,
	1,
	11,
	0,
	0,
	0,
	0,
	7,
	2688);
INSERT INTO V_TVL
	VALUES (2692,
	2703);
INSERT INTO V_VAL
	VALUES (2691,
	0,
	0,
	1,
	15,
	15,
	0,
	0,
	0,
	0,
	7,
	2688);
INSERT INTO V_LIN
	VALUES (2691,
	'0');
INSERT INTO V_VAL
	VALUES (2695,
	0,
	0,
	2,
	27,
	30,
	0,
	0,
	0,
	0,
	13,
	2688);
INSERT INTO V_IRF
	VALUES (2695,
	2704);
INSERT INTO V_VAL
	VALUES (2705,
	0,
	0,
	3,
	16,
	18,
	0,
	0,
	0,
	0,
	13,
	2688);
INSERT INTO V_IRF
	VALUES (2705,
	2694);
INSERT INTO V_VAL
	VALUES (2699,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2688);
INSERT INTO V_UNY
	VALUES (2699,
	2705,
	'not_empty');
INSERT INTO V_VAL
	VALUES (2702,
	0,
	0,
	18,
	8,
	18,
	0,
	0,
	0,
	0,
	7,
	2688);
INSERT INTO V_TVL
	VALUES (2702,
	2703);
INSERT INTO V_VAR
	VALUES (2703,
	2688,
	'temperature',
	1,
	7);
INSERT INTO V_TRN
	VALUES (2703,
	0,
	'');
INSERT INTO V_LOC
	VALUES (2706,
	1,
	1,
	11,
	2703);
INSERT INTO V_LOC
	VALUES (2707,
	4,
	3,
	13,
	2703);
INSERT INTO V_LOC
	VALUES (2708,
	8,
	5,
	15,
	2703);
INSERT INTO V_LOC
	VALUES (2709,
	12,
	7,
	17,
	2703);
INSERT INTO V_LOC
	VALUES (2710,
	18,
	8,
	18,
	2703);
INSERT INTO V_VAR
	VALUES (2694,
	2688,
	'row',
	1,
	13);
INSERT INTO V_INT
	VALUES (2694,
	0,
	162);
INSERT INTO V_LOC
	VALUES (2711,
	2,
	12,
	14,
	2694);
INSERT INTO V_LOC
	VALUES (2712,
	4,
	17,
	19,
	2694);
INSERT INTO V_VAR
	VALUES (2704,
	2688,
	'self',
	1,
	13);
INSERT INTO V_INT
	VALUES (2704,
	0,
	109);
INSERT INTO ACT_BLK
	VALUES (2698,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2687,
	0);
INSERT INTO ACT_SMT
	VALUES (2713,
	2698,
	0,
	4,
	3,
	'sequence::solve_by_pruning line: 4');
INSERT INTO ACT_AI
	VALUES (2713,
	2714,
	2715,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2715,
	1,
	0,
	4,
	3,
	13,
	0,
	0,
	0,
	0,
	7,
	2698);
INSERT INTO V_TVL
	VALUES (2715,
	2703);
INSERT INTO V_VAL
	VALUES (2714,
	0,
	0,
	4,
	21,
	-1,
	0,
	0,
	0,
	0,
	7,
	2698);
INSERT INTO V_TRV
	VALUES (2714,
	2317,
	2694,
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2701,
	1,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	6,
	38,
	0,
	0,
	6,
	45,
	0,
	0,
	0,
	0,
	0,
	2687,
	0);
INSERT INTO ACT_SMT
	VALUES (2716,
	2701,
	2717,
	6,
	3,
	'sequence::solve_by_pruning line: 6');
INSERT INTO ACT_SEL
	VALUES (2716,
	2718,
	1,
	'one',
	2719);
INSERT INTO ACT_SR
	VALUES (2716);
INSERT INTO ACT_LNK
	VALUES (2720,
	'',
	2716,
	286,
	0,
	2,
	296,
	6,
	38,
	6,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2717,
	2701,
	0,
	7,
	3,
	'sequence::solve_by_pruning line: 7');
INSERT INTO ACT_IF
	VALUES (2717,
	2721,
	2722,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2723,
	2701,
	0,
	9,
	3,
	'sequence::solve_by_pruning line: 9');
INSERT INTO ACT_E
	VALUES (2723,
	2724,
	2717);
INSERT INTO V_VAL
	VALUES (2719,
	0,
	0,
	6,
	32,
	35,
	0,
	0,
	0,
	0,
	13,
	2701);
INSERT INTO V_IRF
	VALUES (2719,
	2704);
INSERT INTO V_VAL
	VALUES (2725,
	0,
	0,
	7,
	18,
	23,
	0,
	0,
	0,
	0,
	13,
	2701);
INSERT INTO V_IRF
	VALUES (2725,
	2718);
INSERT INTO V_VAL
	VALUES (2722,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2701);
INSERT INTO V_UNY
	VALUES (2722,
	2725,
	'not_empty');
INSERT INTO V_VAR
	VALUES (2718,
	2701,
	'column',
	1,
	13);
INSERT INTO V_INT
	VALUES (2718,
	0,
	296);
INSERT INTO V_LOC
	VALUES (2726,
	6,
	14,
	19,
	2718);
INSERT INTO V_LOC
	VALUES (2727,
	8,
	19,
	24,
	2718);
INSERT INTO ACT_BLK
	VALUES (2721,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2687,
	0);
INSERT INTO ACT_SMT
	VALUES (2728,
	2721,
	0,
	8,
	5,
	'sequence::solve_by_pruning line: 8');
INSERT INTO ACT_AI
	VALUES (2728,
	2729,
	2730,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2730,
	1,
	0,
	8,
	5,
	15,
	0,
	0,
	0,
	0,
	7,
	2721);
INSERT INTO V_TVL
	VALUES (2730,
	2703);
INSERT INTO V_VAL
	VALUES (2729,
	0,
	0,
	8,
	26,
	-1,
	0,
	0,
	0,
	0,
	7,
	2721);
INSERT INTO V_TRV
	VALUES (2729,
	1947,
	2718,
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2724,
	1,
	0,
	0,
	'',
	'',
	'',
	13,
	5,
	10,
	37,
	0,
	0,
	10,
	41,
	0,
	0,
	0,
	0,
	0,
	2687,
	0);
INSERT INTO ACT_SMT
	VALUES (2731,
	2724,
	2732,
	10,
	5,
	'sequence::solve_by_pruning line: 10');
INSERT INTO ACT_SEL
	VALUES (2731,
	2733,
	1,
	'one',
	2734);
INSERT INTO ACT_SR
	VALUES (2731);
INSERT INTO ACT_LNK
	VALUES (2735,
	'',
	2731,
	286,
	0,
	2,
	310,
	10,
	37,
	10,
	41,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2732,
	2724,
	0,
	11,
	5,
	'sequence::solve_by_pruning line: 11');
INSERT INTO ACT_IF
	VALUES (2732,
	2736,
	2737,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2738,
	2724,
	0,
	13,
	5,
	'sequence::solve_by_pruning line: 13');
INSERT INTO ACT_E
	VALUES (2738,
	2739,
	2732);
INSERT INTO V_VAL
	VALUES (2734,
	0,
	0,
	10,
	31,
	34,
	0,
	0,
	0,
	0,
	13,
	2724);
INSERT INTO V_IRF
	VALUES (2734,
	2704);
INSERT INTO V_VAL
	VALUES (2740,
	0,
	0,
	11,
	20,
	22,
	0,
	0,
	0,
	0,
	13,
	2724);
INSERT INTO V_IRF
	VALUES (2740,
	2733);
INSERT INTO V_VAL
	VALUES (2737,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	6,
	2724);
INSERT INTO V_UNY
	VALUES (2737,
	2740,
	'not_empty');
INSERT INTO V_VAR
	VALUES (2733,
	2724,
	'box',
	1,
	13);
INSERT INTO V_INT
	VALUES (2733,
	0,
	310);
INSERT INTO V_LOC
	VALUES (2741,
	10,
	16,
	18,
	2733);
INSERT INTO V_LOC
	VALUES (2742,
	12,
	21,
	23,
	2733);
INSERT INTO ACT_BLK
	VALUES (2736,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2687,
	0);
INSERT INTO ACT_SMT
	VALUES (2743,
	2736,
	0,
	12,
	7,
	'sequence::solve_by_pruning line: 12');
INSERT INTO ACT_AI
	VALUES (2743,
	2744,
	2745,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2745,
	1,
	0,
	12,
	7,
	17,
	0,
	0,
	0,
	0,
	7,
	2736);
INSERT INTO V_TVL
	VALUES (2745,
	2703);
INSERT INTO V_VAL
	VALUES (2744,
	0,
	0,
	12,
	25,
	-1,
	0,
	0,
	0,
	0,
	7,
	2736);
INSERT INTO V_TRV
	VALUES (2744,
	1375,
	2733,
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2739,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	14,
	7,
	14,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2687,
	0);
INSERT INTO ACT_SMT
	VALUES (2746,
	2739,
	0,
	14,
	7,
	'sequence::solve_by_pruning line: 14');
INSERT INTO ACT_BRG
	VALUES (2746,
	65,
	14,
	12,
	14,
	7);
INSERT INTO V_VAL
	VALUES (2747,
	0,
	0,
	14,
	32,
	64,
	0,
	0,
	0,
	0,
	9,
	2739);
INSERT INTO V_LST
	VALUES (2747,
	'could not prune related sequence');
INSERT INTO V_PAR
	VALUES (2747,
	2746,
	0,
	'message',
	0,
	14,
	24);
INSERT INTO O_NBATTR
	VALUES (2748,
	109);
INSERT INTO O_BATTR
	VALUES (2748,
	109);
INSERT INTO O_ATTR
	VALUES (2748,
	109,
	0,
	'current_state',
	'',
	'',
	'current_state',
	0,
	11,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (318,
	109);
INSERT INTO O_BATTR
	VALUES (318,
	109);
INSERT INTO O_ATTR
	VALUES (318,
	109,
	2748,
	'solved',
	'',
	'',
	'solved',
	0,
	6,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (320,
	109);
INSERT INTO O_BATTR
	VALUES (320,
	109);
INSERT INTO O_ATTR
	VALUES (320,
	109,
	318,
	'requests',
	'',
	'',
	'requests',
	0,
	7,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	109);
INSERT INTO O_ID
	VALUES (1,
	109);
INSERT INTO O_ID
	VALUES (2,
	109);
INSERT INTO SM_ISM
	VALUES (2749,
	109);
INSERT INTO SM_SM
	VALUES (2749,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (2749);
INSERT INTO SM_LEVT
	VALUES (2750,
	2749,
	0);
INSERT INTO SM_SEVT
	VALUES (2750,
	2749,
	0);
INSERT INTO SM_EVT
	VALUES (2750,
	2749,
	0,
	1,
	'update',
	0,
	'',
	'SEQUENCE1',
	'');
INSERT INTO SM_LEVT
	VALUES (2751,
	2749,
	0);
INSERT INTO SM_SEVT
	VALUES (2751,
	2749,
	0);
INSERT INTO SM_EVT
	VALUES (2751,
	2749,
	0,
	5,
	'solved',
	0,
	'',
	'SEQUENCE5',
	'');
INSERT INTO R_SUBSUP
	VALUES (286);
INSERT INTO R_REL
	VALUES (286,
	1,
	'',
	1374);
INSERT INTO R_SUPER
	VALUES (109,
	286,
	2752);
INSERT INTO R_RTO
	VALUES (109,
	286,
	2752,
	-1);
INSERT INTO R_OIR
	VALUES (109,
	286,
	2752,
	0);
INSERT INTO R_SUB
	VALUES (162,
	286,
	2753);
INSERT INTO R_RGO
	VALUES (162,
	286,
	2753);
INSERT INTO R_OIR
	VALUES (162,
	286,
	2753,
	0);
INSERT INTO R_SUB
	VALUES (296,
	286,
	2754);
INSERT INTO R_RGO
	VALUES (296,
	286,
	2754);
INSERT INTO R_OIR
	VALUES (296,
	286,
	2754,
	0);
INSERT INTO R_SUB
	VALUES (310,
	286,
	2755);
INSERT INTO R_RGO
	VALUES (310,
	286,
	2755);
INSERT INTO R_OIR
	VALUES (310,
	286,
	2755,
	0);
INSERT INTO R_SIMP
	VALUES (359);
INSERT INTO R_REL
	VALUES (359,
	2,
	'',
	1374);
INSERT INTO R_PART
	VALUES (162,
	359,
	1759,
	0,
	0,
	'is in');
INSERT INTO O_RTIDA
	VALUES (322,
	162,
	1,
	359,
	1759);
INSERT INTO R_RTO
	VALUES (162,
	359,
	1759,
	1);
INSERT INTO R_OIR
	VALUES (162,
	359,
	1759,
	0);
INSERT INTO R_FORM
	VALUES (168,
	359,
	1758,
	1,
	0,
	'has');
INSERT INTO R_RGO
	VALUES (168,
	359,
	1758);
INSERT INTO R_OIR
	VALUES (168,
	359,
	1758,
	0);
INSERT INTO R_SIMP
	VALUES (361);
INSERT INTO R_REL
	VALUES (361,
	3,
	'',
	1374);
INSERT INTO R_PART
	VALUES (296,
	361,
	1762,
	0,
	0,
	'is in');
INSERT INTO O_RTIDA
	VALUES (326,
	296,
	1,
	361,
	1762);
INSERT INTO R_RTO
	VALUES (296,
	361,
	1762,
	1);
INSERT INTO R_OIR
	VALUES (296,
	361,
	1762,
	0);
INSERT INTO R_FORM
	VALUES (168,
	361,
	1761,
	1,
	0,
	'has');
INSERT INTO R_RGO
	VALUES (168,
	361,
	1761);
INSERT INTO R_OIR
	VALUES (168,
	361,
	1761,
	0);
INSERT INTO R_SIMP
	VALUES (521);
INSERT INTO R_REL
	VALUES (521,
	4,
	'',
	1374);
INSERT INTO R_PART
	VALUES (310,
	521,
	2756,
	0,
	0,
	'is in');
INSERT INTO R_RTO
	VALUES (310,
	521,
	2756,
	-1);
INSERT INTO R_OIR
	VALUES (310,
	521,
	2756,
	0);
INSERT INTO R_PART
	VALUES (168,
	521,
	2757,
	1,
	0,
	'has');
INSERT INTO R_RTO
	VALUES (168,
	521,
	2757,
	-1);
INSERT INTO R_OIR
	VALUES (168,
	521,
	2757,
	0);
INSERT INTO R_ASSOC
	VALUES (383);
INSERT INTO R_REL
	VALUES (383,
	8,
	'',
	1374);
INSERT INTO R_AONE
	VALUES (168,
	383,
	2231,
	1,
	1,
	'is eligible for');
INSERT INTO O_RTIDA
	VALUES (415,
	168,
	0,
	383,
	2231);
INSERT INTO O_RTIDA
	VALUES (420,
	168,
	0,
	383,
	2231);
INSERT INTO R_RTO
	VALUES (168,
	383,
	2231,
	0);
INSERT INTO R_OIR
	VALUES (168,
	383,
	2231,
	0);
INSERT INTO R_AOTH
	VALUES (150,
	383,
	2236,
	1,
	1,
	'has eligible');
INSERT INTO O_RTIDA
	VALUES (182,
	150,
	0,
	383,
	2236);
INSERT INTO R_RTO
	VALUES (150,
	383,
	2236,
	0);
INSERT INTO R_OIR
	VALUES (150,
	383,
	2236,
	0);
INSERT INTO R_ASSR
	VALUES (382,
	383,
	2230,
	0);
INSERT INTO R_RGO
	VALUES (382,
	383,
	2230);
INSERT INTO R_OIR
	VALUES (382,
	383,
	2230,
	0);
INSERT INTO R_SIMP
	VALUES (357);
INSERT INTO R_REL
	VALUES (357,
	9,
	'',
	1374);
INSERT INTO R_FORM
	VALUES (168,
	357,
	1764,
	1,
	1,
	'is answer for');
INSERT INTO R_RGO
	VALUES (168,
	357,
	1764);
INSERT INTO R_OIR
	VALUES (168,
	357,
	1764,
	0);
INSERT INTO R_PART
	VALUES (150,
	357,
	1765,
	0,
	1,
	'has answer');
INSERT INTO O_RTIDA
	VALUES (182,
	150,
	0,
	357,
	1765);
INSERT INTO R_RTO
	VALUES (150,
	357,
	1765,
	0);
INSERT INTO R_OIR
	VALUES (150,
	357,
	1765,
	0);
INSERT INTO SLD_SDP
	VALUES (1,
	2758);
INSERT INTO S_DPK
	VALUES (2758,
	'Datatypes',
	0,
	0);
INSERT INTO S_DIP
	VALUES (2758,
	2759);
INSERT INTO S_DT
	VALUES (2759,
	0,
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2759,
	0);
INSERT INTO S_DIP
	VALUES (2758,
	2760);
INSERT INTO S_DT
	VALUES (2760,
	0,
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2760,
	1);
INSERT INTO S_DIP
	VALUES (2758,
	2761);
INSERT INTO S_DT
	VALUES (2761,
	0,
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2761,
	2);
INSERT INTO S_DIP
	VALUES (2758,
	2762);
INSERT INTO S_DT
	VALUES (2762,
	0,
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2762,
	3);
INSERT INTO S_DIP
	VALUES (2758,
	2763);
INSERT INTO S_DT
	VALUES (2763,
	0,
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2763,
	4);
INSERT INTO S_DIP
	VALUES (2758,
	2764);
INSERT INTO S_DT
	VALUES (2764,
	0,
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2764,
	5);
INSERT INTO S_DIP
	VALUES (2758,
	2765);
INSERT INTO S_DT
	VALUES (2765,
	0,
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2765,
	6);
INSERT INTO S_DIP
	VALUES (2758,
	2766);
INSERT INTO S_DT
	VALUES (2766,
	0,
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2766,
	7);
INSERT INTO S_DIP
	VALUES (2758,
	2767);
INSERT INTO S_DT
	VALUES (2767,
	0,
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2767,
	8);
INSERT INTO S_DIP
	VALUES (2758,
	2768);
INSERT INTO S_DT
	VALUES (2768,
	0,
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2768,
	9);
INSERT INTO S_DIP
	VALUES (2758,
	2769);
INSERT INTO S_DT
	VALUES (2769,
	0,
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2769,
	10);
INSERT INTO S_DIP
	VALUES (2758,
	2770);
INSERT INTO S_DT
	VALUES (2770,
	0,
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2770,
	11);
INSERT INTO S_DIP
	VALUES (2758,
	2771);
INSERT INTO S_DT
	VALUES (2771,
	0,
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2771,
	12);
INSERT INTO S_DIP
	VALUES (2758,
	2772);
INSERT INTO S_DT
	VALUES (2772,
	0,
	'component_ref',
	'',
	'');
INSERT INTO S_CDT
	VALUES (2772,
	13);
INSERT INTO S_DIP
	VALUES (2758,
	2773);
INSERT INTO S_DT
	VALUES (2773,
	0,
	'date',
	'',
	'');
INSERT INTO S_UDT
	VALUES (2773,
	2770,
	1);
INSERT INTO S_DIP
	VALUES (2758,
	2774);
INSERT INTO S_DT
	VALUES (2774,
	0,
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES (2774,
	2771,
	3);
INSERT INTO S_DIP
	VALUES (2758,
	2775);
INSERT INTO S_DT
	VALUES (2775,
	0,
	'timestamp',
	'',
	'');
INSERT INTO S_UDT
	VALUES (2775,
	2770,
	2);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2759,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2760,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2761,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2762,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2763,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2764,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2765,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2766,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2767,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2768,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2769,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2770,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2771,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2772,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2773,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2774,
	1);
INSERT INTO SLD_SDINP
	VALUES (2758,
	2775,
	1);
INSERT INTO EP_SPKG
	VALUES (2758,
	0);
