-- root-types-contained: SystemModel_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.5

INSERT INTO S_SYS
	VALUES ("65c95f29-dab4-4f47-a406-60806c54ea6f",
	'sudoproc');
INSERT INTO S_DOM
	VALUES ("abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'sudoku_procedural',
	'',
	0,
	"00000000-0000-0000-0000-000000000001",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO S_DPK
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	'Datatypes',
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"a8899e12-301b-4e3c-949d-1f327b45833d");
INSERT INTO S_DT
	VALUES ("a8899e12-301b-4e3c-949d-1f327b45833d",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("a8899e12-301b-4e3c-949d-1f327b45833d",
	0);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"3876b01a-6790-4345-8746-a6082de715ab");
INSERT INTO S_DT
	VALUES ("3876b01a-6790-4345-8746-a6082de715ab",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("3876b01a-6790-4345-8746-a6082de715ab",
	1);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO S_DT
	VALUES ("25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	2);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"1e70f274-28c6-4446-b69d-f6bf8ea45d20");
INSERT INTO S_DT
	VALUES ("1e70f274-28c6-4446-b69d-f6bf8ea45d20",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("1e70f274-28c6-4446-b69d-f6bf8ea45d20",
	3);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f");
INSERT INTO S_DT
	VALUES ("f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	4);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"66a9fd03-27ad-4a38-80ec-2edfc2ce39b6");
INSERT INTO S_DT
	VALUES ("66a9fd03-27ad-4a38-80ec-2edfc2ce39b6",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("66a9fd03-27ad-4a38-80ec-2edfc2ce39b6",
	5);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"65468da2-1083-4089-81cf-f2430c0ade46");
INSERT INTO S_DT
	VALUES ("65468da2-1083-4089-81cf-f2430c0ade46",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("65468da2-1083-4089-81cf-f2430c0ade46",
	6);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"1d4138ff-0b11-4c15-ba60-a919d89e9e3d");
INSERT INTO S_DT
	VALUES ("1d4138ff-0b11-4c15-ba60-a919d89e9e3d",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("1d4138ff-0b11-4c15-ba60-a919d89e9e3d",
	7);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO S_DT
	VALUES ("52f78114-d517-42f3-8a73-167976a7916c",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("52f78114-d517-42f3-8a73-167976a7916c",
	8);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO S_DT
	VALUES ("53668123-e048-4263-8bc4-caf552d5730a",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("53668123-e048-4263-8bc4-caf552d5730a",
	9);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"fc95f94f-df72-48fe-ac67-e8eb645f6762");
INSERT INTO S_DT
	VALUES ("fc95f94f-df72-48fe-ac67-e8eb645f6762",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("fc95f94f-df72-48fe-ac67-e8eb645f6762",
	10);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"e008a992-5d3b-4a52-a1a7-67c9ec0927e0");
INSERT INTO S_DT
	VALUES ("e008a992-5d3b-4a52-a1a7-67c9ec0927e0",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("e008a992-5d3b-4a52-a1a7-67c9ec0927e0",
	11);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"c27c75cd-59cc-49cc-b045-a30a483560e0");
INSERT INTO S_DT
	VALUES ("c27c75cd-59cc-49cc-b045-a30a483560e0",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("c27c75cd-59cc-49cc-b045-a30a483560e0",
	12);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"2a7d1a79-0883-463f-b7b5-3119ffdb71dd");
INSERT INTO S_DT
	VALUES ("2a7d1a79-0883-463f-b7b5-3119ffdb71dd",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'date',
	'Time as known in the external world. For example, 12 October 1492,
13:25:10. The accuracy of external time is dependent on the architecture and
implementation.',
	'');
INSERT INTO S_UDT
	VALUES ("2a7d1a79-0883-463f-b7b5-3119ffdb71dd",
	"e008a992-5d3b-4a52-a1a7-67c9ec0927e0",
	1);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"7211707b-4f3f-4c9a-b06c-27b9e733b34e");
INSERT INTO S_DT
	VALUES ("7211707b-4f3f-4c9a-b06c-27b9e733b34e",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'timestamp',
	' The system clock counts time in ticks. The size of a tick is dependent on the
 architecture and implementation.',
	'');
INSERT INTO S_UDT
	VALUES ("7211707b-4f3f-4c9a-b06c-27b9e733b34e",
	"e008a992-5d3b-4a52-a1a7-67c9ec0927e0",
	2);
INSERT INTO S_DIP
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"8a854b39-7da8-4858-9e46-9a7b734d878a");
INSERT INTO S_DT
	VALUES ("8a854b39-7da8-4858-9e46-9a7b734d878a",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("8a854b39-7da8-4858-9e46-9a7b734d878a",
	"c27c75cd-59cc-49cc-b045-a30a483560e0",
	3);
INSERT INTO EP_SPKG
	VALUES ("2f26f602-7aa9-4877-9a8b-9209e479b1c9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_EEPK
	VALUES ("93da0673-edd5-4588-a6f2-c9f0b9cf994e",
	'External Entities',
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_EEPIP
	VALUES ("93da0673-edd5-4588-a6f2-c9f0b9cf994e");
INSERT INTO PL_EEPID
	VALUES ("abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	"93da0673-edd5-4588-a6f2-c9f0b9cf994e");
INSERT INTO S_EEIP
	VALUES ("93da0673-edd5-4588-a6f2-c9f0b9cf994e",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e");
INSERT INTO S_EE
	VALUES ("f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'Time',
	'The Time external entity provides date, timestamp, and timer related operations.',
	'TIM',
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b");
INSERT INTO S_BRG
	VALUES ("5c7841ff-5850-4998-98ac-59ca9e34ec12",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'current_date',
	'',
	0,
	"2a7d1a79-0883-463f-b7b5-3119ffdb71dd",
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES ("4c6dd793-1da0-4660-8d78-58ceb3ebedc3",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'create_date',
	'',
	0,
	"2a7d1a79-0883-463f-b7b5-3119ffdb71dd",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("53e74bce-45ed-4a6f-89e0-1d2774f587d1",
	"4c6dd793-1da0-4660-8d78-58ceb3ebedc3",
	'second',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"b4479cd9-997b-47a5-87aa-ad262ee00229",
	'');
INSERT INTO S_BPARM
	VALUES ("b650ab69-26f2-4a3e-b5cc-27a8d2f2283c",
	"4c6dd793-1da0-4660-8d78-58ceb3ebedc3",
	'minute',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"3aede982-5ff9-4d64-abd8-0318ee2b45d5",
	'');
INSERT INTO S_BPARM
	VALUES ("3aede982-5ff9-4d64-abd8-0318ee2b45d5",
	"4c6dd793-1da0-4660-8d78-58ceb3ebedc3",
	'hour',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"5f144cc4-782f-4c1b-9640-3a13e7ace140",
	'');
INSERT INTO S_BPARM
	VALUES ("5f144cc4-782f-4c1b-9640-3a13e7ace140",
	"4c6dd793-1da0-4660-8d78-58ceb3ebedc3",
	'day',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BPARM
	VALUES ("b4479cd9-997b-47a5-87aa-ad262ee00229",
	"4c6dd793-1da0-4660-8d78-58ceb3ebedc3",
	'month',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"b650ab69-26f2-4a3e-b5cc-27a8d2f2283c",
	'');
INSERT INTO S_BPARM
	VALUES ("b74c0cc0-7b7d-4012-aefd-6bf7eea73ae6",
	"4c6dd793-1da0-4660-8d78-58ceb3ebedc3",
	'year',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"53e74bce-45ed-4a6f-89e0-1d2774f587d1",
	'');
INSERT INTO S_BRG
	VALUES ("472d1d28-f499-47c2-afdb-30d71fc371e5",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'get_second',
	'',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("f507e6a7-c458-40df-92b8-4d00a58b4266",
	"472d1d28-f499-47c2-afdb-30d71fc371e5",
	'date',
	"2a7d1a79-0883-463f-b7b5-3119ffdb71dd",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("6d8f67ab-ac30-438c-bda4-c471b5963bbf",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'get_minute',
	'',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("162610f4-abdb-4d3d-9ac2-f98d7e7d0781",
	"6d8f67ab-ac30-438c-bda4-c471b5963bbf",
	'date',
	"2a7d1a79-0883-463f-b7b5-3119ffdb71dd",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("dbbf6b32-9cef-4b52-9cb1-e0095f424c57",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'get_hour',
	'',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("817123c4-2b58-482e-bf59-3d7b52f8a1d7",
	"dbbf6b32-9cef-4b52-9cb1-e0095f424c57",
	'date',
	"2a7d1a79-0883-463f-b7b5-3119ffdb71dd",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("b2861640-69be-4f37-870f-789fec8b8112",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'get_day',
	'',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("6d35855f-660b-4c07-8922-e92709a04bb2",
	"b2861640-69be-4f37-870f-789fec8b8112",
	'date',
	"2a7d1a79-0883-463f-b7b5-3119ffdb71dd",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("e1dfef9f-c67e-4d44-9e39-1706452eb4f5",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'get_month',
	'',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("b3baa552-b307-4933-b64d-5864c7cc1bf4",
	"e1dfef9f-c67e-4d44-9e39-1706452eb4f5",
	'date',
	"2a7d1a79-0883-463f-b7b5-3119ffdb71dd",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("b0238e53-a2a4-46ef-a3f8-4bc5aa343295",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'get_year',
	'',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("ebd40cdd-2454-46b9-ba30-2cbeb2f809fb",
	"b0238e53-a2a4-46ef-a3f8-4bc5aa343295",
	'date',
	"2a7d1a79-0883-463f-b7b5-3119ffdb71dd",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("43f5a931-054e-4d71-b6dd-4cdd6e36cb58",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'current_clock',
	'',
	0,
	"7211707b-4f3f-4c9a-b06c-27b9e733b34e",
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES ("7fdd81a3-9ea8-4ca1-b31f-5b3551b365df",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'timer_start',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Returns the instance
handle of the timer.',
	0,
	"8a854b39-7da8-4858-9e46-9a7b734d878a",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("f4a7a220-4df8-4265-8ae6-02f17233df0b",
	"7fdd81a3-9ea8-4ca1-b31f-5b3551b365df",
	'microseconds',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"2963b832-7362-41b7-a888-d006187aa3d4",
	'');
INSERT INTO S_BPARM
	VALUES ("2963b832-7362-41b7-a888-d006187aa3d4",
	"7fdd81a3-9ea8-4ca1-b31f-5b3551b365df",
	'event_inst',
	"fc95f94f-df72-48fe-ac67-e8eb645f6762",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("d8b86c58-aa16-4f8c-9255-f02abec55572",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'timer_start_recurring',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Upon expiration, the
timer will be restarted and fire again in the specified number of microseconds
generating the passed event. This bridge operation returns the instance handle
of the timer.',
	0,
	"8a854b39-7da8-4858-9e46-9a7b734d878a",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("6d4345e4-fb8b-4e98-80db-641c15229561",
	"d8b86c58-aa16-4f8c-9255-f02abec55572",
	'microseconds',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"d02678f2-42d9-4a89-a54d-5e70f0dc9c4a",
	'');
INSERT INTO S_BPARM
	VALUES ("d02678f2-42d9-4a89-a54d-5e70f0dc9c4a",
	"d8b86c58-aa16-4f8c-9255-f02abec55572",
	'event_inst',
	"fc95f94f-df72-48fe-ac67-e8eb645f6762",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("53d048ec-d346-490f-b243-2dbbb8233a7c",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'timer_remaining_time',
	'Returns the time remaining (in microseconds) for the passed timer instance. If
the timer has expired, a zero value is returned.',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("d02e0d8b-de98-4b60-b971-c8ff40c8121c",
	"53d048ec-d346-490f-b243-2dbbb8233a7c",
	'timer_inst_ref',
	"8a854b39-7da8-4858-9e46-9a7b734d878a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("96829fcb-3e0b-439a-8a7f-ca21a8092145",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'timer_reset_time',
	'This bridge operation attempts to set the passed existing timer to expire in
the specified number of microseconds. If the timer exists (that is, it has not
expired), a TRUE value is returned. If the timer no longer exists, a FALSE value
is returned.',
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("df3196a7-af9f-4b9e-9442-5d12ac464d56",
	"96829fcb-3e0b-439a-8a7f-ca21a8092145",
	'timer_inst_ref',
	"8a854b39-7da8-4858-9e46-9a7b734d878a",
	0,
	'',
	"15a7419a-fa5f-4ed9-89b0-572d57f5ac95",
	'');
INSERT INTO S_BPARM
	VALUES ("15a7419a-fa5f-4ed9-89b0-572d57f5ac95",
	"96829fcb-3e0b-439a-8a7f-ca21a8092145",
	'microseconds',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("b7f9e2c6-9f8d-4641-b80e-519f97c799a6",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'timer_add_time',
	'This bridge operation attempts to add the specified number of microseconds to a
passed existing timer. If the timer exists (that is, it has not expired), a TRUE
value is returned. If the timer no longer exists, a FALSE value is returned.',
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("4b95a1b8-18fc-4c5c-abb0-a8e9540e5325",
	"b7f9e2c6-9f8d-4641-b80e-519f97c799a6",
	'timer_inst_ref',
	"8a854b39-7da8-4858-9e46-9a7b734d878a",
	0,
	'',
	"8b569696-0b24-409a-9195-129b6c9ed459",
	'');
INSERT INTO S_BPARM
	VALUES ("8b569696-0b24-409a-9195-129b6c9ed459",
	"b7f9e2c6-9f8d-4641-b80e-519f97c799a6",
	'microseconds',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BRG
	VALUES ("335d472d-3d86-4fb7-bb8f-b2836e708a16",
	"f0303c95-f95f-40a4-8eaa-0ead21f25a9e",
	'timer_cancel',
	'This bridge operation cancels and deletes the passed timer instance. If the 
timer exists (that is, it had not expired), a TRUE value is returned. If the
timer no longer exists, a FALSE value is returned.',
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES ("f4a0c82d-4df0-496a-9b58-a5a8fc457659",
	"335d472d-3d86-4fb7-bb8f-b2836e708a16",
	'timer_inst_ref',
	"8a854b39-7da8-4858-9e46-9a7b734d878a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_EEIP
	VALUES ("93da0673-edd5-4588-a6f2-c9f0b9cf994e",
	"3206a2ca-e37f-4cda-9f88-b487f98ecf75");
INSERT INTO S_EE
	VALUES ("3206a2ca-e37f-4cda-9f88-b487f98ecf75",
	'Architecture',
	'',
	'ARCH',
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b");
INSERT INTO S_BRG
	VALUES ("d10f74d7-601e-47c5-bb4b-22a3137290e3",
	"3206a2ca-e37f-4cda-9f88-b487f98ecf75",
	'shutdown',
	'',
	0,
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	'',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES ("b5c05bd0-ab51-495c-87a4-3d6318f67256",
	"d10f74d7-601e-47c5-bb4b-22a3137290e3");
INSERT INTO ACT_ACT
	VALUES ("b5c05bd0-ab51-495c-87a4-3d6318f67256",
	'bridge',
	0,
	"57bd8ccb-ba29-4fd6-918b-89514e681cc5",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Architecture::shutdown',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("57bd8ccb-ba29-4fd6-918b-89514e681cc5",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"b5c05bd0-ab51-495c-87a4-3d6318f67256",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_EEIP
	VALUES ("93da0673-edd5-4588-a6f2-c9f0b9cf994e",
	"9ee0285c-826f-4a5e-817d-cc26cbfc6cee");
INSERT INTO S_EE
	VALUES ("9ee0285c-826f-4a5e-817d-cc26cbfc6cee",
	'Logging',
	'',
	'LOG',
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b");
INSERT INTO S_BRG
	VALUES ("f598b35c-392f-4d82-90a7-a4f0d9281584",
	"9ee0285c-826f-4a5e-817d-cc26cbfc6cee",
	'LogFailure',
	'',
	0,
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("01828231-2bc2-465e-a1cc-17112e3eebec",
	"f598b35c-392f-4d82-90a7-a4f0d9281584",
	'message',
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("642ebc38-c656-40a0-a2c6-463246880ae8",
	"f598b35c-392f-4d82-90a7-a4f0d9281584");
INSERT INTO ACT_ACT
	VALUES ("642ebc38-c656-40a0-a2c6-463246880ae8",
	'bridge',
	0,
	"d496aaae-34f5-4da8-8049-e382cc614345",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogFailure',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("d496aaae-34f5-4da8-8049-e382cc614345",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"642ebc38-c656-40a0-a2c6-463246880ae8",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("fcecd865-72da-4176-a9bd-ae415b51a1ff",
	"9ee0285c-826f-4a5e-817d-cc26cbfc6cee",
	'LogInfo',
	'',
	0,
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("ce4c266d-da44-4c26-a85a-85b27e351dad",
	"fcecd865-72da-4176-a9bd-ae415b51a1ff",
	'message',
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("989c6524-4b6d-4f20-95ab-715ff6894301",
	"fcecd865-72da-4176-a9bd-ae415b51a1ff");
INSERT INTO ACT_ACT
	VALUES ("989c6524-4b6d-4f20-95ab-715ff6894301",
	'bridge',
	0,
	"7fae65f8-4f27-4672-b73f-0c716c2a4713",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogInfo',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("7fae65f8-4f27-4672-b73f-0c716c2a4713",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"989c6524-4b6d-4f20-95ab-715ff6894301",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("15f7937e-f6a0-46c4-88b5-c74594313811",
	"9ee0285c-826f-4a5e-817d-cc26cbfc6cee",
	'LogSuccess',
	'',
	0,
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("5efe33a9-f342-4067-bef8-d8aa396d86ec",
	"15f7937e-f6a0-46c4-88b5-c74594313811",
	'message',
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("8a5ca8a2-6277-41cc-b616-cbab57f134c0",
	"15f7937e-f6a0-46c4-88b5-c74594313811");
INSERT INTO ACT_ACT
	VALUES ("8a5ca8a2-6277-41cc-b616-cbab57f134c0",
	'bridge',
	0,
	"51a53f49-2600-4d76-a5ef-96a8058bfef5",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogSuccess',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("51a53f49-2600-4d76-a5ef-96a8058bfef5",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"8a5ca8a2-6277-41cc-b616-cbab57f134c0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_EEIP
	VALUES ("93da0673-edd5-4588-a6f2-c9f0b9cf994e",
	"12e0a6c2-a41a-4850-874f-003eb892d95c");
INSERT INTO S_EE
	VALUES ("12e0a6c2-a41a-4850-874f-003eb892d95c",
	'Non-Volatile Storage',
	'',
	'NVS',
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b");
INSERT INTO S_BRG
	VALUES ("2ca594d3-fef0-4107-9845-9cc3a8c75c53",
	"12e0a6c2-a41a-4850-874f-003eb892d95c",
	'version',
	'',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'return 0;',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("13b9a863-861d-4391-9b38-600f39937f6d",
	"2ca594d3-fef0-4107-9845-9cc3a8c75c53",
	'first',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BPARM
	VALUES ("cee9f3b6-06a0-4191-81d9-f31d63a9db6a",
	"2ca594d3-fef0-4107-9845-9cc3a8c75c53",
	'second',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"13b9a863-861d-4391-9b38-600f39937f6d",
	'');
INSERT INTO ACT_BRB
	VALUES ("1f7bef5a-dda1-40fc-a713-f879567316a2",
	"2ca594d3-fef0-4107-9845-9cc3a8c75c53");
INSERT INTO ACT_ACT
	VALUES ("1f7bef5a-dda1-40fc-a713-f879567316a2",
	'bridge',
	0,
	"d5611ada-d21d-4975-a72e-cc12e159d122",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Non-Volatile Storage::version',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("d5611ada-d21d-4975-a72e-cc12e159d122",
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"1f7bef5a-dda1-40fc-a713-f879567316a2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ddc3ae9b-ff02-45d2-82c3-388e9ecc9d4a",
	"d5611ada-d21d-4975-a72e-cc12e159d122",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'Non-Volatile Storage::version line: 1');
INSERT INTO ACT_RET
	VALUES ("ddc3ae9b-ff02-45d2-82c3-388e9ecc9d4a",
	"f36afc7e-bf04-4394-a4c6-87065f17a41a");
INSERT INTO V_VAL
	VALUES ("f36afc7e-bf04-4394-a4c6-87065f17a41a",
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d5611ada-d21d-4975-a72e-cc12e159d122");
INSERT INTO V_LIN
	VALUES ("f36afc7e-bf04-4394-a4c6-87065f17a41a",
	'0');
INSERT INTO S_BRG
	VALUES ("06f826bd-af3c-4624-8d2d-d3858b34a6c8",
	"12e0a6c2-a41a-4850-874f-003eb892d95c",
	'checksum',
	'',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'return 0;',
	1,
	'');
INSERT INTO S_BPARM
	VALUES ("d1043f3e-e5ef-45b8-acab-5590d732890e",
	"06f826bd-af3c-4624-8d2d-d3858b34a6c8",
	'first',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BPARM
	VALUES ("738f2f75-81a7-40e1-b1cb-afa49ce03f6b",
	"06f826bd-af3c-4624-8d2d-d3858b34a6c8",
	'second',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"d1043f3e-e5ef-45b8-acab-5590d732890e",
	'');
INSERT INTO ACT_BRB
	VALUES ("39674b33-af70-472d-851f-3ffa153a95a9",
	"06f826bd-af3c-4624-8d2d-d3858b34a6c8");
INSERT INTO ACT_ACT
	VALUES ("39674b33-af70-472d-851f-3ffa153a95a9",
	'bridge',
	0,
	"69dcdfbe-5290-4fe3-b800-e7f33fcbd296",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Non-Volatile Storage::checksum',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("69dcdfbe-5290-4fe3-b800-e7f33fcbd296",
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"39674b33-af70-472d-851f-3ffa153a95a9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("00b4d4ce-1ea0-4617-bbe4-afdda96830aa",
	"69dcdfbe-5290-4fe3-b800-e7f33fcbd296",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'Non-Volatile Storage::checksum line: 1');
INSERT INTO ACT_RET
	VALUES ("00b4d4ce-1ea0-4617-bbe4-afdda96830aa",
	"c11f1405-f73c-4a3c-83de-d6cce50ee466");
INSERT INTO V_VAL
	VALUES ("c11f1405-f73c-4a3c-83de-d6cce50ee466",
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"69dcdfbe-5290-4fe3-b800-e7f33fcbd296");
INSERT INTO V_LIN
	VALUES ("c11f1405-f73c-4a3c-83de-d6cce50ee466",
	'0');
INSERT INTO S_BRG
	VALUES ("4c24a9f3-0479-450b-8f8c-cb6001790a57",
	"12e0a6c2-a41a-4850-874f-003eb892d95c",
	'space_used',
	'',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'return 0;',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES ("514d2083-a029-4ce4-b64f-2b1e2be4174e",
	"4c24a9f3-0479-450b-8f8c-cb6001790a57");
INSERT INTO ACT_ACT
	VALUES ("514d2083-a029-4ce4-b64f-2b1e2be4174e",
	'bridge',
	0,
	"c70bd56d-876f-434a-92cf-ed951ee03781",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Non-Volatile Storage::space_used',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c70bd56d-876f-434a-92cf-ed951ee03781",
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"514d2083-a029-4ce4-b64f-2b1e2be4174e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("afbab4f6-92be-4ccb-994d-457b803e42cf",
	"c70bd56d-876f-434a-92cf-ed951ee03781",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'Non-Volatile Storage::space_used line: 1');
INSERT INTO ACT_RET
	VALUES ("afbab4f6-92be-4ccb-994d-457b803e42cf",
	"dc84ff8d-164c-4d1f-9479-d25c8f15726c");
INSERT INTO V_VAL
	VALUES ("dc84ff8d-164c-4d1f-9479-d25c8f15726c",
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c70bd56d-876f-434a-92cf-ed951ee03781");
INSERT INTO V_LIN
	VALUES ("dc84ff8d-164c-4d1f-9479-d25c8f15726c",
	'0');
INSERT INTO S_BRG
	VALUES ("67455258-154c-43e8-9707-54c4e94d82b8",
	"12e0a6c2-a41a-4850-874f-003eb892d95c",
	'format',
	'',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'return 0;',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES ("dc2a8ab1-c294-4bfc-8eac-8f216db38f15",
	"67455258-154c-43e8-9707-54c4e94d82b8");
INSERT INTO ACT_ACT
	VALUES ("dc2a8ab1-c294-4bfc-8eac-8f216db38f15",
	'bridge',
	0,
	"a72f878c-9e35-48f1-ac2a-bc1a469914d0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Non-Volatile Storage::format',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a72f878c-9e35-48f1-ac2a-bc1a469914d0",
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"dc2a8ab1-c294-4bfc-8eac-8f216db38f15",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3b314dcf-3bd3-415d-aefd-8c7d68f666bc",
	"a72f878c-9e35-48f1-ac2a-bc1a469914d0",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'Non-Volatile Storage::format line: 1');
INSERT INTO ACT_RET
	VALUES ("3b314dcf-3bd3-415d-aefd-8c7d68f666bc",
	"d1189167-cf20-47cd-bb7b-3a7bf11176cb");
INSERT INTO V_VAL
	VALUES ("d1189167-cf20-47cd-bb7b-3a7bf11176cb",
	0,
	0,
	1,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"a72f878c-9e35-48f1-ac2a-bc1a469914d0");
INSERT INTO V_LIN
	VALUES ("d1189167-cf20-47cd-bb7b-3a7bf11176cb",
	'0');
INSERT INTO S_FPK
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	'functions',
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PL_FPID
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b");
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"481ba5a4-6cf3-4444-ab97-cf3d0239e62f");
INSERT INTO S_SYNC
	VALUES ("481ba5a4-6cf3-4444-ab97-cf3d0239e62f",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'setup',
	'',
	'// 
// Check to see if any instances are already here.
// This would mean that we have restored from NVS
// or that preexisting instances were defined in data.
//

select any sequence from instances of SEQUENCE;
if ( empty sequence )
  i = NVS::space_used();
  if ( i < 100 )
    i = NVS::format();
    if( i != 0 )
      LOG::LogFailure( message:"Error formatting the NVS." );
    end if;
  end if;

  LOG::LogInfo( message:"Did not find any PEI data, initializing NVS" );
  i = NVS::version( first:1, second:2 );
  i =  NVS::checksum( first:1, second:2 );
  
// Create 9 digits.
i = 9;
while ( 0 < i )
  create object instance digit of DIGIT;
  digit.value = i;
  i = i - 1;
end while;
create object instance digit of DIGIT;
digit.value = 0;


i = 9;
while ( 0 < i )

  // Create the row sequence.
  create object instance sequence of SEQUENCE;
  sequence.solved = false;
  sequence.requests = 0;
  create object instance row of ROW;
  row.number = i;
  relate row to sequence across R1;
  
  // Create the column sequence.
  create object instance sequence of SEQUENCE;
  sequence.solved = false;
  sequence.requests = 0;
  create object instance column of COLUMN;
  column.number = i;
  relate column to sequence across R1;
  
  // Create the box sequence.
  create object instance sequence of SEQUENCE;
  sequence.solved = false;
  sequence.requests = 0;
  create object instance box of BOX;
  box.number = i;
  relate box to sequence across R1;
  
  i = i - 1;
end while;

select many rows from instances of ROW;
for each row in rows
  select many columns from instances of COLUMN;
  for each column in columns;
    create object instance cell of CELL;
    select any digit from instances of DIGIT where ( selected.value == 0 );
    relate cell to digit across R9;
    relate cell to row across R2;
    relate cell to column across R3;
  
    // Link in all 9 digits to each cell.
    select many digits from instances of DIGIT where ( selected.value != 0 );
    for each digit in digits
      create object instance eligible of ELIGIBLE;
      relate digit to cell across R8 using eligible;
    end for;
  end for;
end for;

// Link the cells to the correct boxes.
select many cells from instances of CELL;
for each cell in cells
  if ( ( cell.row_number <= 3 ) and
     ( cell.column_number <= 3 ) )
    select any box from instances of BOX where ( selected.number == 1 );
    relate cell to box across R4;
  elif ( ( cell.row_number <= 3 ) and
     ( ( 4 <= cell.column_number ) and ( cell.column_number <= 6 ) ) )
    select any box from instances of BOX where ( selected.number == 2 );
    relate cell to box across R4;
  elif ( ( cell.row_number <= 3 ) and
     ( 7 <= cell.column_number ) )
    select any box from instances of BOX where ( selected.number == 3 );
    relate cell to box across R4;
  elif ( ( ( 4 <= cell.row_number ) and ( cell.row_number <= 6 ) ) and
     ( cell.column_number <= 3 ) )
    select any box from instances of BOX where ( selected.number == 4 );
    relate cell to box across R4;
  elif ( ( ( 4 <= cell.row_number ) and ( cell.row_number <= 6 ) ) and
     ( ( 4 <= cell.column_number ) and ( cell.column_number <= 6 ) ) )
    select any box from instances of BOX where ( selected.number == 5 );
    relate cell to box across R4;
  elif ( ( ( 4 <= cell.row_number ) and ( cell.row_number <= 6 ) ) and
     ( 7 <= cell.column_number ) )
    select any box from instances of BOX where ( selected.number == 6 );
    relate cell to box across R4;
  elif ( ( 7 <= cell.row_number ) and
     ( cell.column_number <= 3 ) )
    select any box from instances of BOX where ( selected.number == 7 );
    relate cell to box across R4;
  elif ( ( 7 <= cell.row_number ) and
     ( ( 4 <= cell.column_number ) and ( cell.column_number <= 6 ) ) )
    select any box from instances of BOX where ( selected.number == 8 );
    relate cell to box across R4;
  elif ( ( 7 <= cell.row_number ) and
     ( 7 <= cell.column_number ) )
    select any box from instances of BOX where ( selected.number == 9 );
    relate cell to box across R4;
  end if;
end for;

else
  LOG::LogInfo( message:"PEI data found." );
end if;
',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"481ba5a4-6cf3-4444-ab97-cf3d0239e62f");
INSERT INTO ACT_ACT
	VALUES ("4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	'function',
	0,
	"ba65ac85-b123-473f-954f-6e8b6bbf1e00",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setup',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("ba65ac85-b123-473f-954f-6e8b6bbf1e00",
	1,
	0,
	0,
	'',
	'',
	'',
	123,
	1,
	7,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b413eb49-1fc6-4c98-a554-fc8aa85ba7e6",
	"ba65ac85-b123-473f-954f-6e8b6bbf1e00",
	"31645bc2-25b4-49b4-a89b-ea04150c7aaa",
	7,
	1,
	'setup line: 7');
INSERT INTO ACT_FIO
	VALUES ("b413eb49-1fc6-4c98-a554-fc8aa85ba7e6",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514",
	1,
	'any',
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	7,
	39);
INSERT INTO ACT_SMT
	VALUES ("31645bc2-25b4-49b4-a89b-ea04150c7aaa",
	"ba65ac85-b123-473f-954f-6e8b6bbf1e00",
	"00000000-0000-0000-0000-000000000000",
	8,
	1,
	'setup line: 8');
INSERT INTO ACT_IF
	VALUES ("31645bc2-25b4-49b4-a89b-ea04150c7aaa",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"0eed2ea3-3358-463c-9de5-52713cd00041",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("207baada-1184-42c9-89cb-fb918af95a98",
	"ba65ac85-b123-473f-954f-6e8b6bbf1e00",
	"00000000-0000-0000-0000-000000000000",
	123,
	1,
	'setup line: 123');
INSERT INTO ACT_E
	VALUES ("207baada-1184-42c9-89cb-fb918af95a98",
	"8d023eb4-b13c-4eaa-90b7-d26e92e23673",
	"31645bc2-25b4-49b4-a89b-ea04150c7aaa");
INSERT INTO V_VAL
	VALUES ("b6f5dfad-7337-4de5-8a93-c938b9bcfef0",
	0,
	0,
	8,
	12,
	19,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"ba65ac85-b123-473f-954f-6e8b6bbf1e00");
INSERT INTO V_IRF
	VALUES ("b6f5dfad-7337-4de5-8a93-c938b9bcfef0",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_VAL
	VALUES ("0eed2ea3-3358-463c-9de5-52713cd00041",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"ba65ac85-b123-473f-954f-6e8b6bbf1e00");
INSERT INTO V_UNY
	VALUES ("0eed2ea3-3358-463c-9de5-52713cd00041",
	"b6f5dfad-7337-4de5-8a93-c938b9bcfef0",
	'empty');
INSERT INTO V_VAR
	VALUES ("0ff702fe-f375-4c4a-81a6-33f33ed3e514",
	"ba65ac85-b123-473f-954f-6e8b6bbf1e00",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("0ff702fe-f375-4c4a-81a6-33f33ed3e514",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("7eed709c-ce36-4229-a988-551a156212cd",
	7,
	12,
	19,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("9dae207a-3354-4fcf-8db6-f82f47abbf5c",
	36,
	26,
	33,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("69a7d2ff-be84-46ca-aebe-0da6dbc931cb",
	37,
	3,
	10,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("73dc6cdc-f436-4ff0-a02a-13d4a06b8572",
	38,
	3,
	10,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("d3b3ca3d-b69f-480b-84d2-f637cf30424c",
	41,
	17,
	24,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("7647dcd0-6453-4c77-9fd8-2d7e616ca3c3",
	44,
	26,
	33,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("3463ea58-c2bc-4282-9868-5db3bf8cbd76",
	45,
	3,
	10,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("283f7659-b5ea-4071-b929-bfeab361a712",
	46,
	3,
	10,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("82d78b58-56f3-411b-8814-9f49f26f7d4f",
	49,
	20,
	27,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("9f762bd4-12e4-4512-ae7c-84c1ad914cb2",
	52,
	26,
	33,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("092053cc-80af-4849-8356-d3a2f2faec6e",
	53,
	3,
	10,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("57e8dba5-c733-4c0c-8163-c607049c3bba",
	54,
	3,
	10,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_LOC
	VALUES ("d066b71d-aa45-42b9-a6e9-dcefb35fa9f2",
	57,
	17,
	24,
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO ACT_BLK
	VALUES ("9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	1,
	0,
	0,
	'NVS',
	'',
	'',
	83,
	1,
	82,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("064fb1af-412b-4e6d-a124-3738c0eddb77",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"924cfa38-ae6c-4a00-87ba-a601b259a94f",
	9,
	3,
	'setup line: 9');
INSERT INTO ACT_AI
	VALUES ("064fb1af-412b-4e6d-a124-3738c0eddb77",
	"b17b3c6c-1e3c-407e-af8b-e6e8a39536e8",
	"afed0fa0-a72d-445b-91b0-5033d243b073",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("924cfa38-ae6c-4a00-87ba-a601b259a94f",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"a01a259f-8095-4d7a-ad86-5b2e1c0e92b2",
	10,
	3,
	'setup line: 10');
INSERT INTO ACT_IF
	VALUES ("924cfa38-ae6c-4a00-87ba-a601b259a94f",
	"ff0d37e3-3813-44b6-a777-68dc42ca4a8c",
	"0dacd94b-fbc2-47d6-a1dc-54c0ba244033",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("a01a259f-8095-4d7a-ad86-5b2e1c0e92b2",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"748fcf5c-9afb-4884-8f22-3efc71e80ed5",
	17,
	3,
	'setup line: 17');
INSERT INTO ACT_BRG
	VALUES ("a01a259f-8095-4d7a-ad86-5b2e1c0e92b2",
	"fcecd865-72da-4176-a9bd-ae415b51a1ff",
	17,
	8,
	17,
	3);
INSERT INTO ACT_SMT
	VALUES ("748fcf5c-9afb-4884-8f22-3efc71e80ed5",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"c7349bc0-f936-4843-b88e-068ca1cdaba4",
	18,
	3,
	'setup line: 18');
INSERT INTO ACT_AI
	VALUES ("748fcf5c-9afb-4884-8f22-3efc71e80ed5",
	"401c53b6-e49e-4954-a4fd-e5c9e62e90f8",
	"bbe57ce0-9ddc-4d0f-a9e0-b573e10f4345",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c7349bc0-f936-4843-b88e-068ca1cdaba4",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"11465543-d92c-49de-97dc-2514658e00d2",
	19,
	3,
	'setup line: 19');
INSERT INTO ACT_AI
	VALUES ("c7349bc0-f936-4843-b88e-068ca1cdaba4",
	"01bc4c62-607a-4214-b112-bfb4f3afd9f8",
	"8deaee1a-4d98-4051-aa58-322153e8c9c9",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("11465543-d92c-49de-97dc-2514658e00d2",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"cc1ebd51-3864-4b95-b324-a96910fb7a1f",
	22,
	1,
	'setup line: 22');
INSERT INTO ACT_AI
	VALUES ("11465543-d92c-49de-97dc-2514658e00d2",
	"082cccbe-a2bd-441c-a777-7a405ce4ade6",
	"da4053c6-c0d3-465e-963f-21a32d24bba2",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("cc1ebd51-3864-4b95-b324-a96910fb7a1f",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"c4c3c8bd-fccc-4dde-88f4-1b758bfdd24b",
	23,
	1,
	'setup line: 23');
INSERT INTO ACT_WHL
	VALUES ("cc1ebd51-3864-4b95-b324-a96910fb7a1f",
	"af28d497-433d-4e16-910d-add11629c7bb",
	"516ef6c1-017e-48e1-80b5-6798d76c9678");
INSERT INTO ACT_SMT
	VALUES ("c4c3c8bd-fccc-4dde-88f4-1b758bfdd24b",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"5e3040cb-d6b3-4498-afaa-70fafd835162",
	28,
	1,
	'setup line: 28');
INSERT INTO ACT_CR
	VALUES ("c4c3c8bd-fccc-4dde-88f4-1b758bfdd24b",
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a",
	1,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	28,
	33);
INSERT INTO ACT_SMT
	VALUES ("5e3040cb-d6b3-4498-afaa-70fafd835162",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"6dcfa924-5373-4bcf-825e-699e7e52e626",
	29,
	1,
	'setup line: 29');
INSERT INTO ACT_AI
	VALUES ("5e3040cb-d6b3-4498-afaa-70fafd835162",
	"37c1e8ed-3e57-4fa4-b145-cba73f8d0b82",
	"eb30bb03-8f55-4320-8f82-8122e744da6d",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("6dcfa924-5373-4bcf-825e-699e7e52e626",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"2c00d106-aac8-4cca-affc-05298404c9a2",
	32,
	1,
	'setup line: 32');
INSERT INTO ACT_AI
	VALUES ("6dcfa924-5373-4bcf-825e-699e7e52e626",
	"f3288f4a-e1fa-4545-a60d-5b9c9f096087",
	"bdf3224e-7791-4cff-93b8-cc55493258bd",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("2c00d106-aac8-4cca-affc-05298404c9a2",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"76e7069d-9f97-4f89-bb2a-9605a584f093",
	33,
	1,
	'setup line: 33');
INSERT INTO ACT_WHL
	VALUES ("2c00d106-aac8-4cca-affc-05298404c9a2",
	"434afa0f-c76a-4681-a86a-2be2bcf3848f",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO ACT_SMT
	VALUES ("76e7069d-9f97-4f89-bb2a-9605a584f093",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"3534582a-8cac-45c6-814b-a0ad8ead2c96",
	62,
	1,
	'setup line: 62');
INSERT INTO ACT_FIO
	VALUES ("76e7069d-9f97-4f89-bb2a-9605a584f093",
	"0eb1e47a-e19a-4c22-9090-fd9cc426ef45",
	1,
	'many',
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	62,
	36);
INSERT INTO ACT_SMT
	VALUES ("3534582a-8cac-45c6-814b-a0ad8ead2c96",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"834b730c-64a8-4ddd-b827-e37543a6a7f6",
	63,
	1,
	'setup line: 63');
INSERT INTO ACT_FOR
	VALUES ("3534582a-8cac-45c6-814b-a0ad8ead2c96",
	"a8a7bfa2-d6e1-4a8a-954c-71fe71aa333e",
	1,
	"7b2d7c61-fdc5-4932-b37e-b08ae2ce1bb6",
	"0eb1e47a-e19a-4c22-9090-fd9cc426ef45",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO ACT_SMT
	VALUES ("834b730c-64a8-4ddd-b827-e37543a6a7f6",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"c35c742d-388d-494f-9f0a-60cb2e4200e0",
	82,
	1,
	'setup line: 82');
INSERT INTO ACT_FIO
	VALUES ("834b730c-64a8-4ddd-b827-e37543a6a7f6",
	"636a00bb-dfb2-421d-bae7-94fc3fc9c63d",
	1,
	'many',
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	82,
	37);
INSERT INTO ACT_SMT
	VALUES ("c35c742d-388d-494f-9f0a-60cb2e4200e0",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	"00000000-0000-0000-0000-000000000000",
	83,
	1,
	'setup line: 83');
INSERT INTO ACT_FOR
	VALUES ("c35c742d-388d-494f-9f0a-60cb2e4200e0",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	1,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"636a00bb-dfb2-421d-bae7-94fc3fc9c63d",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_VAL
	VALUES ("afed0fa0-a72d-445b-91b0-5033d243b073",
	1,
	1,
	9,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_TVL
	VALUES ("afed0fa0-a72d-445b-91b0-5033d243b073",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("b17b3c6c-1e3c-407e-af8b-e6e8a39536e8",
	0,
	0,
	9,
	12,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_BRV
	VALUES ("b17b3c6c-1e3c-407e-af8b-e6e8a39536e8",
	"4c24a9f3-0479-450b-8f8c-cb6001790a57",
	1,
	9,
	7);
INSERT INTO V_VAL
	VALUES ("e04ec670-e813-4566-be15-6e0953089cc7",
	0,
	0,
	10,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_TVL
	VALUES ("e04ec670-e813-4566-be15-6e0953089cc7",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("0dacd94b-fbc2-47d6-a1dc-54c0ba244033",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_BIN
	VALUES ("0dacd94b-fbc2-47d6-a1dc-54c0ba244033",
	"3e8f6591-01ce-43cc-887e-21a28a07a8db",
	"e04ec670-e813-4566-be15-6e0953089cc7",
	'<');
INSERT INTO V_VAL
	VALUES ("3e8f6591-01ce-43cc-887e-21a28a07a8db",
	0,
	0,
	10,
	12,
	14,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LIN
	VALUES ("3e8f6591-01ce-43cc-887e-21a28a07a8db",
	'100');
INSERT INTO V_VAL
	VALUES ("212825cd-ae2a-4575-85e6-1aa1d7fa761f",
	0,
	0,
	17,
	25,
	68,
	0,
	0,
	0,
	0,
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LST
	VALUES ("212825cd-ae2a-4575-85e6-1aa1d7fa761f",
	'Did not find any PEI data, initializing NVS');
INSERT INTO V_PAR
	VALUES ("212825cd-ae2a-4575-85e6-1aa1d7fa761f",
	"a01a259f-8095-4d7a-ad86-5b2e1c0e92b2",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	17,
	17);
INSERT INTO V_VAL
	VALUES ("bbe57ce0-9ddc-4d0f-a9e0-b573e10f4345",
	1,
	0,
	18,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_TVL
	VALUES ("bbe57ce0-9ddc-4d0f-a9e0-b573e10f4345",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("401c53b6-e49e-4954-a4fd-e5c9e62e90f8",
	0,
	0,
	18,
	12,
	-1,
	18,
	21,
	18,
	30,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_BRV
	VALUES ("401c53b6-e49e-4954-a4fd-e5c9e62e90f8",
	"2ca594d3-fef0-4107-9845-9cc3a8c75c53",
	1,
	18,
	7);
INSERT INTO V_VAL
	VALUES ("f139295a-edd6-401a-83d6-bda422938fbc",
	0,
	0,
	18,
	27,
	27,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LIN
	VALUES ("f139295a-edd6-401a-83d6-bda422938fbc",
	'1');
INSERT INTO V_PAR
	VALUES ("f139295a-edd6-401a-83d6-bda422938fbc",
	"00000000-0000-0000-0000-000000000000",
	"401c53b6-e49e-4954-a4fd-e5c9e62e90f8",
	'first',
	"897d5fe0-5987-4b6a-9ef1-64ac9bde2f2f",
	18,
	21);
INSERT INTO V_VAL
	VALUES ("897d5fe0-5987-4b6a-9ef1-64ac9bde2f2f",
	0,
	0,
	18,
	37,
	37,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LIN
	VALUES ("897d5fe0-5987-4b6a-9ef1-64ac9bde2f2f",
	'2');
INSERT INTO V_PAR
	VALUES ("897d5fe0-5987-4b6a-9ef1-64ac9bde2f2f",
	"00000000-0000-0000-0000-000000000000",
	"401c53b6-e49e-4954-a4fd-e5c9e62e90f8",
	'second',
	"00000000-0000-0000-0000-000000000000",
	18,
	30);
INSERT INTO V_VAL
	VALUES ("8deaee1a-4d98-4051-aa58-322153e8c9c9",
	1,
	0,
	19,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_TVL
	VALUES ("8deaee1a-4d98-4051-aa58-322153e8c9c9",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("01bc4c62-607a-4214-b112-bfb4f3afd9f8",
	0,
	0,
	19,
	13,
	-1,
	19,
	23,
	19,
	32,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_BRV
	VALUES ("01bc4c62-607a-4214-b112-bfb4f3afd9f8",
	"06f826bd-af3c-4624-8d2d-d3858b34a6c8",
	1,
	19,
	8);
INSERT INTO V_VAL
	VALUES ("bf74bf6f-c5e5-4e2c-93de-9d38d13cc9a7",
	0,
	0,
	19,
	29,
	29,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LIN
	VALUES ("bf74bf6f-c5e5-4e2c-93de-9d38d13cc9a7",
	'1');
INSERT INTO V_PAR
	VALUES ("bf74bf6f-c5e5-4e2c-93de-9d38d13cc9a7",
	"00000000-0000-0000-0000-000000000000",
	"01bc4c62-607a-4214-b112-bfb4f3afd9f8",
	'first',
	"e1797e16-de2e-437c-ae90-05f5d1a1eaf8",
	19,
	23);
INSERT INTO V_VAL
	VALUES ("e1797e16-de2e-437c-ae90-05f5d1a1eaf8",
	0,
	0,
	19,
	39,
	39,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LIN
	VALUES ("e1797e16-de2e-437c-ae90-05f5d1a1eaf8",
	'2');
INSERT INTO V_PAR
	VALUES ("e1797e16-de2e-437c-ae90-05f5d1a1eaf8",
	"00000000-0000-0000-0000-000000000000",
	"01bc4c62-607a-4214-b112-bfb4f3afd9f8",
	'second',
	"00000000-0000-0000-0000-000000000000",
	19,
	32);
INSERT INTO V_VAL
	VALUES ("da4053c6-c0d3-465e-963f-21a32d24bba2",
	1,
	0,
	22,
	1,
	1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_TVL
	VALUES ("da4053c6-c0d3-465e-963f-21a32d24bba2",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("082cccbe-a2bd-441c-a777-7a405ce4ade6",
	0,
	0,
	22,
	5,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LIN
	VALUES ("082cccbe-a2bd-441c-a777-7a405ce4ade6",
	'9');
INSERT INTO V_VAL
	VALUES ("83aeb481-d3c1-4a03-a972-b1ba42df7ab6",
	0,
	0,
	23,
	9,
	9,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LIN
	VALUES ("83aeb481-d3c1-4a03-a972-b1ba42df7ab6",
	'0');
INSERT INTO V_VAL
	VALUES ("af28d497-433d-4e16-910d-add11629c7bb",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_BIN
	VALUES ("af28d497-433d-4e16-910d-add11629c7bb",
	"0730122c-9f9d-4484-a0bc-c91664a6c36d",
	"83aeb481-d3c1-4a03-a972-b1ba42df7ab6",
	'<');
INSERT INTO V_VAL
	VALUES ("0730122c-9f9d-4484-a0bc-c91664a6c36d",
	0,
	0,
	23,
	13,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_TVL
	VALUES ("0730122c-9f9d-4484-a0bc-c91664a6c36d",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("39fdd07c-248c-4647-be9f-85516682b4a2",
	1,
	0,
	29,
	1,
	5,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_IRF
	VALUES ("39fdd07c-248c-4647-be9f-85516682b4a2",
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a");
INSERT INTO V_VAL
	VALUES ("eb30bb03-8f55-4320-8f82-8122e744da6d",
	1,
	0,
	29,
	7,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_AVL
	VALUES ("eb30bb03-8f55-4320-8f82-8122e744da6d",
	"39fdd07c-248c-4647-be9f-85516682b4a2",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO V_VAL
	VALUES ("37c1e8ed-3e57-4fa4-b145-cba73f8d0b82",
	0,
	0,
	29,
	15,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LIN
	VALUES ("37c1e8ed-3e57-4fa4-b145-cba73f8d0b82",
	'0');
INSERT INTO V_VAL
	VALUES ("bdf3224e-7791-4cff-93b8-cc55493258bd",
	1,
	0,
	32,
	1,
	1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_TVL
	VALUES ("bdf3224e-7791-4cff-93b8-cc55493258bd",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("f3288f4a-e1fa-4545-a60d-5b9c9f096087",
	0,
	0,
	32,
	5,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LIN
	VALUES ("f3288f4a-e1fa-4545-a60d-5b9c9f096087",
	'9');
INSERT INTO V_VAL
	VALUES ("331ee1c4-9fc2-4531-9b5d-ee60fef125db",
	0,
	0,
	33,
	9,
	9,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_LIN
	VALUES ("331ee1c4-9fc2-4531-9b5d-ee60fef125db",
	'0');
INSERT INTO V_VAL
	VALUES ("434afa0f-c76a-4681-a86a-2be2bcf3848f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_BIN
	VALUES ("434afa0f-c76a-4681-a86a-2be2bcf3848f",
	"7df821b1-3d78-4a34-9a04-4fab42ec3f99",
	"331ee1c4-9fc2-4531-9b5d-ee60fef125db",
	'<');
INSERT INTO V_VAL
	VALUES ("7df821b1-3d78-4a34-9a04-4fab42ec3f99",
	0,
	0,
	33,
	13,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2");
INSERT INTO V_TVL
	VALUES ("7df821b1-3d78-4a34-9a04-4fab42ec3f99",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAR
	VALUES ("ed89029f-49a9-4184-a0f8-cdd4d0cf2288",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	'i',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("ed89029f-49a9-4184-a0f8-cdd4d0cf2288",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("282e968b-101e-481c-aefc-22e1a6a559f2",
	9,
	3,
	3,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("4e65c435-7f95-4c8d-90ec-5e245a0f0931",
	10,
	8,
	8,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("9940fb5b-f2d7-4577-8ba0-579f1c0924a2",
	11,
	5,
	5,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("7c10916c-91e8-458e-857d-d50f946887ad",
	12,
	9,
	9,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("1e11dd00-36c0-4994-bc15-33869bd9018d",
	18,
	3,
	3,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("9baa837b-faba-4141-8e0c-62daa00e6b08",
	19,
	3,
	3,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("ccee22e1-548e-444a-a429-7a924ce79641",
	22,
	1,
	1,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("91ad9887-2f2f-4b34-b0f9-a467f1c2d1b5",
	23,
	13,
	13,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("c01313cb-7087-4a3b-be78-14346f177cc6",
	25,
	17,
	17,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("164e0de1-5e23-43d3-b1a4-efd3d4521ac3",
	26,
	3,
	3,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("88c38b0d-8a9b-4faf-bd8b-11c1598707c3",
	26,
	7,
	7,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("1c0ff879-816d-4b0f-8dcf-74404cbd73ed",
	32,
	1,
	1,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("a154dc9f-3b69-4173-92ca-76ab1c5738ff",
	33,
	13,
	13,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("580d2d64-df31-4c89-9cd4-90927ec0bec1",
	40,
	16,
	16,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("95987837-fd7e-461f-9780-55c6987f4b0d",
	48,
	19,
	19,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("fa70870e-4161-465b-a725-7c74a36e70bb",
	56,
	16,
	16,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("ed7a5458-8b7f-431f-8592-467dc1e2e508",
	59,
	3,
	3,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_LOC
	VALUES ("f51264bd-75b2-4af1-ac61-4652e142980d",
	59,
	7,
	7,
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAR
	VALUES ("a1f31bf0-1308-488f-b18c-06fb4bb2893a",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	'digit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("a1f31bf0-1308-488f-b18c-06fb4bb2893a",
	0,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("931cf3af-3f17-49d4-b4f6-0707c77d6df5",
	28,
	24,
	28,
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a");
INSERT INTO V_LOC
	VALUES ("8e3fc914-2662-4370-9fe5-c90b4f577726",
	29,
	1,
	5,
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a");
INSERT INTO V_LOC
	VALUES ("4bc6a4eb-ef62-4223-8ddd-ea855363d7c9",
	67,
	16,
	20,
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a");
INSERT INTO V_LOC
	VALUES ("938d8047-399b-4bbd-b985-085a99930cfe",
	68,
	20,
	24,
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a");
INSERT INTO V_LOC
	VALUES ("be65e037-a1c2-4d2e-ba3c-79c73046e186",
	74,
	14,
	18,
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a");
INSERT INTO V_LOC
	VALUES ("bf8ccb22-1fb5-4066-acb9-6ca0f395717d",
	76,
	14,
	18,
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a");
INSERT INTO V_VAR
	VALUES ("0eb1e47a-e19a-4c22-9090-fd9cc426ef45",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	'rows',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("0eb1e47a-e19a-4c22-9090-fd9cc426ef45",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("54c93df8-025f-463f-b3e7-c97b3ea4dde6",
	62,
	13,
	16,
	"0eb1e47a-e19a-4c22-9090-fd9cc426ef45");
INSERT INTO V_LOC
	VALUES ("7bf30ef1-252f-4ee2-8500-3aceff48fc8c",
	63,
	17,
	20,
	"0eb1e47a-e19a-4c22-9090-fd9cc426ef45");
INSERT INTO V_VAR
	VALUES ("7b2d7c61-fdc5-4932-b37e-b08ae2ce1bb6",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	'row',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("7b2d7c61-fdc5-4932-b37e-b08ae2ce1bb6",
	1,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("bd0f02ff-4a14-4831-b425-7ede0671535a",
	63,
	10,
	12,
	"7b2d7c61-fdc5-4932-b37e-b08ae2ce1bb6");
INSERT INTO V_LOC
	VALUES ("ed21e9b4-4456-4b5b-bf94-9ae6558b0d56",
	69,
	20,
	22,
	"7b2d7c61-fdc5-4932-b37e-b08ae2ce1bb6");
INSERT INTO V_VAR
	VALUES ("636a00bb-dfb2-421d-bae7-94fc3fc9c63d",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	'cells',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("636a00bb-dfb2-421d-bae7-94fc3fc9c63d",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("b9dd8247-18bf-4211-a593-9e51324c6d3e",
	82,
	13,
	17,
	"636a00bb-dfb2-421d-bae7-94fc3fc9c63d");
INSERT INTO V_LOC
	VALUES ("638b514e-1de0-4eca-8996-5dc16b5cb91a",
	83,
	18,
	22,
	"636a00bb-dfb2-421d-bae7-94fc3fc9c63d");
INSERT INTO V_VAR
	VALUES ("c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"9dddad9d-65c0-4802-a7d6-a070f0664ea2",
	'cell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	1,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("9e255132-44e5-49e7-8a1f-fa3f8b94b0e5",
	83,
	10,
	13,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("e25c948e-1f77-4f90-8c2f-c5a50b9749ed",
	84,
	10,
	13,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("fd5007e2-43b8-46fa-9050-10b2d9c004c3",
	85,
	8,
	11,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("82abb19c-1516-4578-98aa-184247581a60",
	87,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("ad134fe2-c0ea-4e10-a570-78cb77dcc31f",
	88,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("bdc30b16-f2f2-476b-9cd9-62c35e53853f",
	89,
	15,
	18,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("3b461c54-2e17-46c3-873f-14f1fccb593a",
	89,
	42,
	45,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("2dd9b696-435a-4c55-90a0-8d8d3abd559f",
	91,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("61dfe20c-27a7-4d3b-8ec4-a04ef7483fc4",
	92,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("682ca03e-7a22-4d72-870d-b9a091b80dea",
	93,
	13,
	16,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("99c8b079-bba5-4911-b4b3-99e21fa20791",
	95,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("7773ee09-7601-4def-9c4f-7b593e41118c",
	96,
	19,
	22,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("08b24e30-cd17-44a1-addd-3ef9d6578e8a",
	96,
	43,
	46,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("47d97cdd-aa1f-471f-add7-1e17b5e85f69",
	97,
	8,
	11,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("4a6a0d78-ed97-49b6-8870-e52281a1d16a",
	99,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("f4f8adb4-dc8d-4db1-8655-033c9ba5d925",
	100,
	19,
	22,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("434f34bb-132b-40b1-ab84-9105c3390446",
	100,
	43,
	46,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("1943ff09-2289-4800-8e45-e57f57d01502",
	101,
	15,
	18,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("1a3ed4cd-7ae2-48bd-b47e-a447cbb2d25b",
	101,
	42,
	45,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("5aa2c8cc-389c-44db-a16a-ef038fb2eb6c",
	103,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("a0689844-3da2-487c-83bc-318d4e3434b4",
	104,
	19,
	22,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("75898a8e-b308-49e2-93a6-504f5f8a9e5f",
	104,
	43,
	46,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("efe8d2a8-619b-4641-be33-ff573a2c27b3",
	105,
	13,
	16,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("aa124eb4-158b-4647-a997-f29120909755",
	107,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("8bf1df7e-db7a-46d8-977b-f74e0b52b572",
	108,
	17,
	20,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("42e3bbfb-0cae-4c50-b19d-d8d12d0a15d8",
	109,
	8,
	11,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("3cf15671-47e4-4f84-a42a-dd10f5a3d826",
	111,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("1d4b86ad-8b62-4601-a83d-19df9894853a",
	112,
	17,
	20,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("3aa7a84b-848c-4efe-b18b-b415da73430f",
	113,
	15,
	18,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("ace7b0b1-46a1-4211-bd37-17d10d4d9a85",
	113,
	42,
	45,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("0d99bb66-d8bd-41da-aa44-4a1b759bdd6c",
	115,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("4653a0ca-638e-4847-b676-0a2bb1203938",
	116,
	17,
	20,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("87490910-50ea-4676-8ee2-08abeebb000b",
	117,
	13,
	16,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_LOC
	VALUES ("42714968-aca7-4d0f-ae00-ce371cc6f530",
	119,
	12,
	15,
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO ACT_BLK
	VALUES ("ff0d37e3-3813-44b6-a777-68dc42ca4a8c",
	0,
	0,
	0,
	'NVS',
	'',
	'',
	12,
	5,
	11,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c0f8d891-186b-46e8-88d4-1049893b8ce0",
	"ff0d37e3-3813-44b6-a777-68dc42ca4a8c",
	"d55b4a0d-922d-4e8a-a09f-5ba51e18dd7c",
	11,
	5,
	'setup line: 11');
INSERT INTO ACT_AI
	VALUES ("c0f8d891-186b-46e8-88d4-1049893b8ce0",
	"475102f5-1f6e-4e22-8e2f-3cbe7c65e5ca",
	"4b62a254-677e-4148-b790-7ab4c04c1d25",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d55b4a0d-922d-4e8a-a09f-5ba51e18dd7c",
	"ff0d37e3-3813-44b6-a777-68dc42ca4a8c",
	"00000000-0000-0000-0000-000000000000",
	12,
	5,
	'setup line: 12');
INSERT INTO ACT_IF
	VALUES ("d55b4a0d-922d-4e8a-a09f-5ba51e18dd7c",
	"02c53363-f809-4c4f-8344-2e1cf105c9cc",
	"73a4cf63-fcb4-437f-a6e7-b5ff208acbda",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("4b62a254-677e-4148-b790-7ab4c04c1d25",
	1,
	0,
	11,
	5,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ff0d37e3-3813-44b6-a777-68dc42ca4a8c");
INSERT INTO V_TVL
	VALUES ("4b62a254-677e-4148-b790-7ab4c04c1d25",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("475102f5-1f6e-4e22-8e2f-3cbe7c65e5ca",
	0,
	0,
	11,
	14,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ff0d37e3-3813-44b6-a777-68dc42ca4a8c");
INSERT INTO V_BRV
	VALUES ("475102f5-1f6e-4e22-8e2f-3cbe7c65e5ca",
	"67455258-154c-43e8-9707-54c4e94d82b8",
	1,
	11,
	9);
INSERT INTO V_VAL
	VALUES ("19ac506f-0a38-4b07-bc46-0f276e7d392e",
	0,
	0,
	12,
	9,
	9,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ff0d37e3-3813-44b6-a777-68dc42ca4a8c");
INSERT INTO V_TVL
	VALUES ("19ac506f-0a38-4b07-bc46-0f276e7d392e",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("73a4cf63-fcb4-437f-a6e7-b5ff208acbda",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"ff0d37e3-3813-44b6-a777-68dc42ca4a8c");
INSERT INTO V_BIN
	VALUES ("73a4cf63-fcb4-437f-a6e7-b5ff208acbda",
	"c389e9a6-47b8-4525-98c1-20cd361947c8",
	"19ac506f-0a38-4b07-bc46-0f276e7d392e",
	'!=');
INSERT INTO V_VAL
	VALUES ("c389e9a6-47b8-4525-98c1-20cd361947c8",
	0,
	0,
	12,
	14,
	14,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ff0d37e3-3813-44b6-a777-68dc42ca4a8c");
INSERT INTO V_LIN
	VALUES ("c389e9a6-47b8-4525-98c1-20cd361947c8",
	'0');
INSERT INTO ACT_BLK
	VALUES ("02c53363-f809-4c4f-8344-2e1cf105c9cc",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	13,
	7,
	13,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1df6e76d-cee3-4eaf-9974-7cd9c56b60c8",
	"02c53363-f809-4c4f-8344-2e1cf105c9cc",
	"00000000-0000-0000-0000-000000000000",
	13,
	7,
	'setup line: 13');
INSERT INTO ACT_BRG
	VALUES ("1df6e76d-cee3-4eaf-9974-7cd9c56b60c8",
	"f598b35c-392f-4d82-90a7-a4f0d9281584",
	13,
	12,
	13,
	7);
INSERT INTO V_VAL
	VALUES ("eb6bf9b5-0b4e-4283-ae31-0bdbf05fe14a",
	0,
	0,
	13,
	32,
	57,
	0,
	0,
	0,
	0,
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	"02c53363-f809-4c4f-8344-2e1cf105c9cc");
INSERT INTO V_LST
	VALUES ("eb6bf9b5-0b4e-4283-ae31-0bdbf05fe14a",
	'Error formatting the NVS.');
INSERT INTO V_PAR
	VALUES ("eb6bf9b5-0b4e-4283-ae31-0bdbf05fe14a",
	"1df6e76d-cee3-4eaf-9974-7cd9c56b60c8",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	13,
	24);
INSERT INTO ACT_BLK
	VALUES ("516ef6c1-017e-48e1-80b5-6798d76c9678",
	0,
	0,
	0,
	'',
	'',
	'',
	26,
	3,
	24,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("528edee4-d0ea-40a5-844b-e4ae834b3539",
	"516ef6c1-017e-48e1-80b5-6798d76c9678",
	"0730fd8d-7405-4f2b-a480-87dc9f4292d0",
	24,
	3,
	'setup line: 24');
INSERT INTO ACT_CR
	VALUES ("528edee4-d0ea-40a5-844b-e4ae834b3539",
	"c386ebd6-2407-43e4-8200-f89d32c21e2a",
	1,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	24,
	35);
INSERT INTO ACT_SMT
	VALUES ("0730fd8d-7405-4f2b-a480-87dc9f4292d0",
	"516ef6c1-017e-48e1-80b5-6798d76c9678",
	"97b17cac-dfd7-4ce9-91fc-dec2cc40a3f1",
	25,
	3,
	'setup line: 25');
INSERT INTO ACT_AI
	VALUES ("0730fd8d-7405-4f2b-a480-87dc9f4292d0",
	"fc50c9cf-bc5b-4ab5-892c-774f49b7b744",
	"056545f4-e729-4da4-a9af-10a4fb334c49",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("97b17cac-dfd7-4ce9-91fc-dec2cc40a3f1",
	"516ef6c1-017e-48e1-80b5-6798d76c9678",
	"00000000-0000-0000-0000-000000000000",
	26,
	3,
	'setup line: 26');
INSERT INTO ACT_AI
	VALUES ("97b17cac-dfd7-4ce9-91fc-dec2cc40a3f1",
	"9588ba5d-94f6-457e-81a8-626d482f7068",
	"e6994b12-17f1-45b3-90e1-2e85136f408b",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("3cc3d009-ec73-44bb-a428-edaf896c54a8",
	1,
	0,
	25,
	3,
	7,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"516ef6c1-017e-48e1-80b5-6798d76c9678");
INSERT INTO V_IRF
	VALUES ("3cc3d009-ec73-44bb-a428-edaf896c54a8",
	"c386ebd6-2407-43e4-8200-f89d32c21e2a");
INSERT INTO V_VAL
	VALUES ("056545f4-e729-4da4-a9af-10a4fb334c49",
	1,
	0,
	25,
	9,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"516ef6c1-017e-48e1-80b5-6798d76c9678");
INSERT INTO V_AVL
	VALUES ("056545f4-e729-4da4-a9af-10a4fb334c49",
	"3cc3d009-ec73-44bb-a428-edaf896c54a8",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO V_VAL
	VALUES ("fc50c9cf-bc5b-4ab5-892c-774f49b7b744",
	0,
	0,
	25,
	17,
	17,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"516ef6c1-017e-48e1-80b5-6798d76c9678");
INSERT INTO V_TVL
	VALUES ("fc50c9cf-bc5b-4ab5-892c-774f49b7b744",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("e6994b12-17f1-45b3-90e1-2e85136f408b",
	1,
	0,
	26,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"516ef6c1-017e-48e1-80b5-6798d76c9678");
INSERT INTO V_TVL
	VALUES ("e6994b12-17f1-45b3-90e1-2e85136f408b",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("8b073f24-7b23-45d7-a63d-7bf45a58a057",
	0,
	0,
	26,
	7,
	7,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"516ef6c1-017e-48e1-80b5-6798d76c9678");
INSERT INTO V_TVL
	VALUES ("8b073f24-7b23-45d7-a63d-7bf45a58a057",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("9588ba5d-94f6-457e-81a8-626d482f7068",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"516ef6c1-017e-48e1-80b5-6798d76c9678");
INSERT INTO V_BIN
	VALUES ("9588ba5d-94f6-457e-81a8-626d482f7068",
	"01889250-5a56-46df-9112-f760a2f66fdf",
	"8b073f24-7b23-45d7-a63d-7bf45a58a057",
	'-');
INSERT INTO V_VAL
	VALUES ("01889250-5a56-46df-9112-f760a2f66fdf",
	0,
	0,
	26,
	11,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"516ef6c1-017e-48e1-80b5-6798d76c9678");
INSERT INTO V_LIN
	VALUES ("01889250-5a56-46df-9112-f760a2f66fdf",
	'1');
INSERT INTO V_VAR
	VALUES ("c386ebd6-2407-43e4-8200-f89d32c21e2a",
	"516ef6c1-017e-48e1-80b5-6798d76c9678",
	'digit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("c386ebd6-2407-43e4-8200-f89d32c21e2a",
	0,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("8045d053-d68d-493e-8e32-18c4477bd536",
	24,
	26,
	30,
	"c386ebd6-2407-43e4-8200-f89d32c21e2a");
INSERT INTO V_LOC
	VALUES ("95354f31-fdaa-4b7f-98bc-ab1e79de4471",
	25,
	3,
	7,
	"c386ebd6-2407-43e4-8200-f89d32c21e2a");
INSERT INTO ACT_BLK
	VALUES ("c4920aca-c711-4d54-8641-b96d480e4856",
	0,
	0,
	0,
	'',
	'',
	'',
	59,
	3,
	55,
	33,
	0,
	0,
	57,
	33,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0c1a0abf-9529-4f3f-b2e7-549e7919361c",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"e6018d7f-3912-4308-99da-b3b3e1d47ea4",
	36,
	3,
	'setup line: 36');
INSERT INTO ACT_CR
	VALUES ("0c1a0abf-9529-4f3f-b2e7-549e7919361c",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	36,
	38);
INSERT INTO ACT_SMT
	VALUES ("e6018d7f-3912-4308-99da-b3b3e1d47ea4",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"be283979-3682-414a-91a1-7e18bc887b9a",
	37,
	3,
	'setup line: 37');
INSERT INTO ACT_AI
	VALUES ("e6018d7f-3912-4308-99da-b3b3e1d47ea4",
	"bd06481b-2608-46dc-8960-e278246a9171",
	"0750f07c-1ce0-4de4-bb52-dd65db49e9cf",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("be283979-3682-414a-91a1-7e18bc887b9a",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"11c6b7da-2c28-4815-babd-659370a11ffd",
	38,
	3,
	'setup line: 38');
INSERT INTO ACT_AI
	VALUES ("be283979-3682-414a-91a1-7e18bc887b9a",
	"5649d759-9034-4c56-b408-3621904f982b",
	"84a633e9-2d67-4468-bc94-e27f55203aef",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("11c6b7da-2c28-4815-babd-659370a11ffd",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"69c9712d-15c8-4c02-a3df-7f29fc494417",
	39,
	3,
	'setup line: 39');
INSERT INTO ACT_CR
	VALUES ("11c6b7da-2c28-4815-babd-659370a11ffd",
	"e1727f03-4065-49ea-ad46-cd8276c6d4a7",
	1,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	39,
	33);
INSERT INTO ACT_SMT
	VALUES ("69c9712d-15c8-4c02-a3df-7f29fc494417",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"c5383bc8-779e-4964-bf2d-fd258d248e7f",
	40,
	3,
	'setup line: 40');
INSERT INTO ACT_AI
	VALUES ("69c9712d-15c8-4c02-a3df-7f29fc494417",
	"c30f4db3-0b92-4b07-83a7-bcab14d9531e",
	"eb99874f-0b5e-49eb-9c53-b88408d30b10",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c5383bc8-779e-4964-bf2d-fd258d248e7f",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"fbbded5d-d338-4d2a-b04c-341999588c60",
	41,
	3,
	'setup line: 41');
INSERT INTO ACT_REL
	VALUES ("c5383bc8-779e-4964-bf2d-fd258d248e7f",
	"e1727f03-4065-49ea-ad46-cd8276c6d4a7",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514",
	'',
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	41,
	33,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("fbbded5d-d338-4d2a-b04c-341999588c60",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"26b9ac2c-cef3-46ce-a0f2-ebd66aee94ac",
	44,
	3,
	'setup line: 44');
INSERT INTO ACT_CR
	VALUES ("fbbded5d-d338-4d2a-b04c-341999588c60",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	44,
	38);
INSERT INTO ACT_SMT
	VALUES ("26b9ac2c-cef3-46ce-a0f2-ebd66aee94ac",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"626ab38b-43a4-4ef6-a76f-a03989c664a7",
	45,
	3,
	'setup line: 45');
INSERT INTO ACT_AI
	VALUES ("26b9ac2c-cef3-46ce-a0f2-ebd66aee94ac",
	"85c99ff8-5cf2-4d56-8684-559a14cc4992",
	"6c975edf-b38e-413d-9ee6-6be56ead7894",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("626ab38b-43a4-4ef6-a76f-a03989c664a7",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"325c9b40-7d20-4c82-9bfd-4422a028c192",
	46,
	3,
	'setup line: 46');
INSERT INTO ACT_AI
	VALUES ("626ab38b-43a4-4ef6-a76f-a03989c664a7",
	"afbea154-6964-4638-8408-08c9eef5d95d",
	"4a1c2b6d-0bf6-4cd3-8427-0055c8a6a50f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("325c9b40-7d20-4c82-9bfd-4422a028c192",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"4a6ee557-1c00-4eef-9e96-82597a587826",
	47,
	3,
	'setup line: 47');
INSERT INTO ACT_CR
	VALUES ("325c9b40-7d20-4c82-9bfd-4422a028c192",
	"63e4b0a5-d7f2-48d4-8a1b-041bd945f879",
	1,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	47,
	36);
INSERT INTO ACT_SMT
	VALUES ("4a6ee557-1c00-4eef-9e96-82597a587826",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"e6b4f330-6395-4da8-b915-44b6ed0949ab",
	48,
	3,
	'setup line: 48');
INSERT INTO ACT_AI
	VALUES ("4a6ee557-1c00-4eef-9e96-82597a587826",
	"30a321e5-b6f7-4361-9c71-569e9fe00cb4",
	"09eccb88-caf1-4526-961b-642d5db5d3d7",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e6b4f330-6395-4da8-b915-44b6ed0949ab",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"57b2156d-b32d-496e-932a-28922bc90a9a",
	49,
	3,
	'setup line: 49');
INSERT INTO ACT_REL
	VALUES ("e6b4f330-6395-4da8-b915-44b6ed0949ab",
	"63e4b0a5-d7f2-48d4-8a1b-041bd945f879",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514",
	'',
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	49,
	36,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("57b2156d-b32d-496e-932a-28922bc90a9a",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"53f01e78-a4ed-46c9-9c33-f09ba8769565",
	52,
	3,
	'setup line: 52');
INSERT INTO ACT_CR
	VALUES ("57b2156d-b32d-496e-932a-28922bc90a9a",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	52,
	38);
INSERT INTO ACT_SMT
	VALUES ("53f01e78-a4ed-46c9-9c33-f09ba8769565",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"ad8e3bf6-21f5-4d77-b8cb-74d90b53463c",
	53,
	3,
	'setup line: 53');
INSERT INTO ACT_AI
	VALUES ("53f01e78-a4ed-46c9-9c33-f09ba8769565",
	"ef7d8bcb-7f92-440c-bf7a-d045532a63ef",
	"08127eb4-2958-4c5f-b416-52f8db5dec7c",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ad8e3bf6-21f5-4d77-b8cb-74d90b53463c",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"fee4420a-f266-40a0-84ab-b355b63b9b12",
	54,
	3,
	'setup line: 54');
INSERT INTO ACT_AI
	VALUES ("ad8e3bf6-21f5-4d77-b8cb-74d90b53463c",
	"79200527-e353-4af0-97e9-e72c02387731",
	"ddec090e-720f-4ffc-a466-f92a4de66739",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("fee4420a-f266-40a0-84ab-b355b63b9b12",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"225361ae-692f-4e9c-b810-91f9b1224a31",
	55,
	3,
	'setup line: 55');
INSERT INTO ACT_CR
	VALUES ("fee4420a-f266-40a0-84ab-b355b63b9b12",
	"4f2258ff-ba86-45c0-91b2-2491a100c752",
	1,
	"0aa0576e-b480-43da-8919-6b6e88544902",
	55,
	33);
INSERT INTO ACT_SMT
	VALUES ("225361ae-692f-4e9c-b810-91f9b1224a31",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"8d5af993-83b8-4688-8d0e-7b85e3cc95aa",
	56,
	3,
	'setup line: 56');
INSERT INTO ACT_AI
	VALUES ("225361ae-692f-4e9c-b810-91f9b1224a31",
	"ae568918-e3b8-44f8-bcec-bd39e0c96c91",
	"771f8293-f865-4796-b3d7-0e98ce3c431d",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8d5af993-83b8-4688-8d0e-7b85e3cc95aa",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"31a57a50-0247-44ed-9eb4-35caab6024bd",
	57,
	3,
	'setup line: 57');
INSERT INTO ACT_REL
	VALUES ("8d5af993-83b8-4688-8d0e-7b85e3cc95aa",
	"4f2258ff-ba86-45c0-91b2-2491a100c752",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514",
	'',
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	57,
	33,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("31a57a50-0247-44ed-9eb4-35caab6024bd",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	"00000000-0000-0000-0000-000000000000",
	59,
	3,
	'setup line: 59');
INSERT INTO ACT_AI
	VALUES ("31a57a50-0247-44ed-9eb4-35caab6024bd",
	"3cf7c34d-c3b8-471f-87b8-32da4bd60639",
	"9ad016fe-90ea-4b31-b48c-8868400d8eec",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("73841c76-23d9-485b-ac3c-1976b06b0158",
	1,
	0,
	37,
	3,
	10,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_IRF
	VALUES ("73841c76-23d9-485b-ac3c-1976b06b0158",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_VAL
	VALUES ("0750f07c-1ce0-4de4-bb52-dd65db49e9cf",
	1,
	0,
	37,
	12,
	17,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_AVL
	VALUES ("0750f07c-1ce0-4de4-bb52-dd65db49e9cf",
	"73841c76-23d9-485b-ac3c-1976b06b0158",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"52c42da4-a4c5-4627-bb84-a09549090418");
INSERT INTO V_VAL
	VALUES ("bd06481b-2608-46dc-8960-e278246a9171",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_LBO
	VALUES ("bd06481b-2608-46dc-8960-e278246a9171",
	'FALSE');
INSERT INTO V_VAL
	VALUES ("421f9e8e-c0f0-42d6-8060-89f97fd07cfe",
	1,
	0,
	38,
	3,
	10,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_IRF
	VALUES ("421f9e8e-c0f0-42d6-8060-89f97fd07cfe",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_VAL
	VALUES ("84a633e9-2d67-4468-bc94-e27f55203aef",
	1,
	0,
	38,
	12,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_AVL
	VALUES ("84a633e9-2d67-4468-bc94-e27f55203aef",
	"421f9e8e-c0f0-42d6-8060-89f97fd07cfe",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("5649d759-9034-4c56-b408-3621904f982b",
	0,
	0,
	38,
	23,
	23,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_LIN
	VALUES ("5649d759-9034-4c56-b408-3621904f982b",
	'0');
INSERT INTO V_VAL
	VALUES ("9068d03c-5626-4e56-8fde-0da967a6284a",
	1,
	0,
	40,
	3,
	5,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_IRF
	VALUES ("9068d03c-5626-4e56-8fde-0da967a6284a",
	"e1727f03-4065-49ea-ad46-cd8276c6d4a7");
INSERT INTO V_VAL
	VALUES ("eb99874f-0b5e-49eb-9c53-b88408d30b10",
	1,
	0,
	40,
	7,
	12,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_AVL
	VALUES ("eb99874f-0b5e-49eb-9c53-b88408d30b10",
	"9068d03c-5626-4e56-8fde-0da967a6284a",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	"bc6df04d-3498-4476-817a-f3273e8f61f2");
INSERT INTO V_VAL
	VALUES ("c30f4db3-0b92-4b07-83a7-bcab14d9531e",
	0,
	0,
	40,
	16,
	16,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_TVL
	VALUES ("c30f4db3-0b92-4b07-83a7-bcab14d9531e",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("978ce90b-1704-4c9e-8a61-cc4d7975a824",
	1,
	0,
	45,
	3,
	10,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_IRF
	VALUES ("978ce90b-1704-4c9e-8a61-cc4d7975a824",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_VAL
	VALUES ("6c975edf-b38e-413d-9ee6-6be56ead7894",
	1,
	0,
	45,
	12,
	17,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_AVL
	VALUES ("6c975edf-b38e-413d-9ee6-6be56ead7894",
	"978ce90b-1704-4c9e-8a61-cc4d7975a824",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"52c42da4-a4c5-4627-bb84-a09549090418");
INSERT INTO V_VAL
	VALUES ("85c99ff8-5cf2-4d56-8684-559a14cc4992",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_LBO
	VALUES ("85c99ff8-5cf2-4d56-8684-559a14cc4992",
	'FALSE');
INSERT INTO V_VAL
	VALUES ("194ca6d8-e336-4fea-b91f-f5621aebf059",
	1,
	0,
	46,
	3,
	10,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_IRF
	VALUES ("194ca6d8-e336-4fea-b91f-f5621aebf059",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_VAL
	VALUES ("4a1c2b6d-0bf6-4cd3-8427-0055c8a6a50f",
	1,
	0,
	46,
	12,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_AVL
	VALUES ("4a1c2b6d-0bf6-4cd3-8427-0055c8a6a50f",
	"194ca6d8-e336-4fea-b91f-f5621aebf059",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("afbea154-6964-4638-8408-08c9eef5d95d",
	0,
	0,
	46,
	23,
	23,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_LIN
	VALUES ("afbea154-6964-4638-8408-08c9eef5d95d",
	'0');
INSERT INTO V_VAL
	VALUES ("3caf62ca-7040-4468-80db-8c70f43d8d7b",
	1,
	0,
	48,
	3,
	8,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_IRF
	VALUES ("3caf62ca-7040-4468-80db-8c70f43d8d7b",
	"63e4b0a5-d7f2-48d4-8a1b-041bd945f879");
INSERT INTO V_VAL
	VALUES ("09eccb88-caf1-4526-961b-642d5db5d3d7",
	1,
	0,
	48,
	10,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_AVL
	VALUES ("09eccb88-caf1-4526-961b-642d5db5d3d7",
	"3caf62ca-7040-4468-80db-8c70f43d8d7b",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	"f26a153c-9ca1-42f0-b8e3-a33ce851c778");
INSERT INTO V_VAL
	VALUES ("30a321e5-b6f7-4361-9c71-569e9fe00cb4",
	0,
	0,
	48,
	19,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_TVL
	VALUES ("30a321e5-b6f7-4361-9c71-569e9fe00cb4",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("94aa56be-a0f4-447f-9c5e-ea5b5eaf3a53",
	1,
	0,
	53,
	3,
	10,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_IRF
	VALUES ("94aa56be-a0f4-447f-9c5e-ea5b5eaf3a53",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_VAL
	VALUES ("08127eb4-2958-4c5f-b416-52f8db5dec7c",
	1,
	0,
	53,
	12,
	17,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_AVL
	VALUES ("08127eb4-2958-4c5f-b416-52f8db5dec7c",
	"94aa56be-a0f4-447f-9c5e-ea5b5eaf3a53",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"52c42da4-a4c5-4627-bb84-a09549090418");
INSERT INTO V_VAL
	VALUES ("ef7d8bcb-7f92-440c-bf7a-d045532a63ef",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_LBO
	VALUES ("ef7d8bcb-7f92-440c-bf7a-d045532a63ef",
	'FALSE');
INSERT INTO V_VAL
	VALUES ("178a6704-5b16-45a1-9eea-693d4a6f2bc3",
	1,
	0,
	54,
	3,
	10,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_IRF
	VALUES ("178a6704-5b16-45a1-9eea-693d4a6f2bc3",
	"0ff702fe-f375-4c4a-81a6-33f33ed3e514");
INSERT INTO V_VAL
	VALUES ("ddec090e-720f-4ffc-a466-f92a4de66739",
	1,
	0,
	54,
	12,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_AVL
	VALUES ("ddec090e-720f-4ffc-a466-f92a4de66739",
	"178a6704-5b16-45a1-9eea-693d4a6f2bc3",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("79200527-e353-4af0-97e9-e72c02387731",
	0,
	0,
	54,
	23,
	23,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_LIN
	VALUES ("79200527-e353-4af0-97e9-e72c02387731",
	'0');
INSERT INTO V_VAL
	VALUES ("6704558e-54ad-4b60-86fa-e119e6251b1e",
	1,
	0,
	56,
	3,
	5,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_IRF
	VALUES ("6704558e-54ad-4b60-86fa-e119e6251b1e",
	"4f2258ff-ba86-45c0-91b2-2491a100c752");
INSERT INTO V_VAL
	VALUES ("771f8293-f865-4796-b3d7-0e98ce3c431d",
	1,
	0,
	56,
	7,
	12,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_AVL
	VALUES ("771f8293-f865-4796-b3d7-0e98ce3c431d",
	"6704558e-54ad-4b60-86fa-e119e6251b1e",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c");
INSERT INTO V_VAL
	VALUES ("ae568918-e3b8-44f8-bcec-bd39e0c96c91",
	0,
	0,
	56,
	16,
	16,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_TVL
	VALUES ("ae568918-e3b8-44f8-bcec-bd39e0c96c91",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("9ad016fe-90ea-4b31-b48c-8868400d8eec",
	1,
	0,
	59,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_TVL
	VALUES ("9ad016fe-90ea-4b31-b48c-8868400d8eec",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("abc278bd-d86a-4782-b5d8-b674fa66001d",
	0,
	0,
	59,
	7,
	7,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_TVL
	VALUES ("abc278bd-d86a-4782-b5d8-b674fa66001d",
	"ed89029f-49a9-4184-a0f8-cdd4d0cf2288");
INSERT INTO V_VAL
	VALUES ("3cf7c34d-c3b8-471f-87b8-32da4bd60639",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_BIN
	VALUES ("3cf7c34d-c3b8-471f-87b8-32da4bd60639",
	"b7b6a573-41f1-4953-8a59-63d1a6ca8aff",
	"abc278bd-d86a-4782-b5d8-b674fa66001d",
	'-');
INSERT INTO V_VAL
	VALUES ("b7b6a573-41f1-4953-8a59-63d1a6ca8aff",
	0,
	0,
	59,
	11,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4920aca-c711-4d54-8641-b96d480e4856");
INSERT INTO V_LIN
	VALUES ("b7b6a573-41f1-4953-8a59-63d1a6ca8aff",
	'1');
INSERT INTO V_VAR
	VALUES ("e1727f03-4065-49ea-ad46-cd8276c6d4a7",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	'row',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("e1727f03-4065-49ea-ad46-cd8276c6d4a7",
	0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("36604470-44f9-45c8-9d59-9703d224d9e0",
	39,
	26,
	28,
	"e1727f03-4065-49ea-ad46-cd8276c6d4a7");
INSERT INTO V_LOC
	VALUES ("950483ea-a631-474e-beb9-38e85dbb6f14",
	40,
	3,
	5,
	"e1727f03-4065-49ea-ad46-cd8276c6d4a7");
INSERT INTO V_LOC
	VALUES ("951edc6c-3b94-4f7d-98b4-a9b7f441868a",
	41,
	10,
	12,
	"e1727f03-4065-49ea-ad46-cd8276c6d4a7");
INSERT INTO V_VAR
	VALUES ("63e4b0a5-d7f2-48d4-8a1b-041bd945f879",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	'column',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("63e4b0a5-d7f2-48d4-8a1b-041bd945f879",
	0,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_LOC
	VALUES ("c944cfa0-1918-42da-9de3-052d77831d05",
	47,
	26,
	31,
	"63e4b0a5-d7f2-48d4-8a1b-041bd945f879");
INSERT INTO V_LOC
	VALUES ("73741905-822b-472e-bc9b-639db39fe2a0",
	48,
	3,
	8,
	"63e4b0a5-d7f2-48d4-8a1b-041bd945f879");
INSERT INTO V_LOC
	VALUES ("114119cd-bd32-406f-be1c-e2fae5e70f31",
	49,
	10,
	15,
	"63e4b0a5-d7f2-48d4-8a1b-041bd945f879");
INSERT INTO V_VAR
	VALUES ("4f2258ff-ba86-45c0-91b2-2491a100c752",
	"c4920aca-c711-4d54-8641-b96d480e4856",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("4f2258ff-ba86-45c0-91b2-2491a100c752",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("a77f4581-c1c7-4b6f-9be6-9066d5b8ec67",
	55,
	26,
	28,
	"4f2258ff-ba86-45c0-91b2-2491a100c752");
INSERT INTO V_LOC
	VALUES ("57b71e40-d9be-4f43-9634-1d2edc8af0a6",
	56,
	3,
	5,
	"4f2258ff-ba86-45c0-91b2-2491a100c752");
INSERT INTO V_LOC
	VALUES ("84f870c0-0d63-4b87-a6e9-7b5f0f1713de",
	57,
	10,
	12,
	"4f2258ff-ba86-45c0-91b2-2491a100c752");
INSERT INTO ACT_BLK
	VALUES ("a8a7bfa2-d6e1-4a8a-954c-71fe71aa333e",
	1,
	0,
	0,
	'',
	'',
	'',
	65,
	3,
	64,
	41,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9b998fa9-ad58-41e9-b982-b82f3676c873",
	"a8a7bfa2-d6e1-4a8a-954c-71fe71aa333e",
	"2c10b90b-b41f-4f96-bf70-f03d278dcaba",
	64,
	3,
	'setup line: 64');
INSERT INTO ACT_FIO
	VALUES ("9b998fa9-ad58-41e9-b982-b82f3676c873",
	"1fb26e6e-5e89-479f-a259-031331159f73",
	1,
	'many',
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	64,
	41);
INSERT INTO ACT_SMT
	VALUES ("2c10b90b-b41f-4f96-bf70-f03d278dcaba",
	"a8a7bfa2-d6e1-4a8a-954c-71fe71aa333e",
	"00000000-0000-0000-0000-000000000000",
	65,
	3,
	'setup line: 65');
INSERT INTO ACT_FOR
	VALUES ("2c10b90b-b41f-4f96-bf70-f03d278dcaba",
	"aceb355d-74c3-4692-9504-21328cd72e60",
	1,
	"b38f0ebf-1010-49d7-880b-8ccebc8e1519",
	"1fb26e6e-5e89-479f-a259-031331159f73",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_VAR
	VALUES ("1fb26e6e-5e89-479f-a259-031331159f73",
	"a8a7bfa2-d6e1-4a8a-954c-71fe71aa333e",
	'columns',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("1fb26e6e-5e89-479f-a259-031331159f73",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_LOC
	VALUES ("cdec3a3c-4c12-4f54-8125-c442fbbfb506",
	64,
	15,
	21,
	"1fb26e6e-5e89-479f-a259-031331159f73");
INSERT INTO V_LOC
	VALUES ("8787f1de-b65f-426c-a8f6-956a3a673f64",
	65,
	22,
	28,
	"1fb26e6e-5e89-479f-a259-031331159f73");
INSERT INTO V_VAR
	VALUES ("b38f0ebf-1010-49d7-880b-8ccebc8e1519",
	"a8a7bfa2-d6e1-4a8a-954c-71fe71aa333e",
	'column',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("b38f0ebf-1010-49d7-880b-8ccebc8e1519",
	1,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_LOC
	VALUES ("22272de5-8321-438f-8a76-4c8d72dbaf1e",
	65,
	12,
	17,
	"b38f0ebf-1010-49d7-880b-8ccebc8e1519");
INSERT INTO V_LOC
	VALUES ("60b1dc2c-27f2-43e2-85bf-9db52dffeffc",
	70,
	20,
	25,
	"b38f0ebf-1010-49d7-880b-8ccebc8e1519");
INSERT INTO ACT_BLK
	VALUES ("aceb355d-74c3-4692-9504-21328cd72e60",
	1,
	0,
	1,
	'',
	'',
	'',
	74,
	5,
	73,
	42,
	0,
	0,
	70,
	34,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d7e5b338-deb4-4a6d-ab3e-4015b2a79970",
	"aceb355d-74c3-4692-9504-21328cd72e60",
	"b578044d-6ba5-49a4-bce9-b2ea9b196fb8",
	66,
	5,
	'setup line: 66');
INSERT INTO ACT_CR
	VALUES ("d7e5b338-deb4-4a6d-ab3e-4015b2a79970",
	"279ed21d-2933-413b-b304-0dd0b70a96de",
	1,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	66,
	36);
INSERT INTO ACT_SMT
	VALUES ("b578044d-6ba5-49a4-bce9-b2ea9b196fb8",
	"aceb355d-74c3-4692-9504-21328cd72e60",
	"4efe7ec1-cb9c-4a99-a31c-2ecf7f6c4b3a",
	67,
	5,
	'setup line: 67');
INSERT INTO ACT_FIW
	VALUES ("b578044d-6ba5-49a4-bce9-b2ea9b196fb8",
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a",
	0,
	'any',
	"da29895a-a48e-4903-bf0b-f1ce81b42feb",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	67,
	40);
INSERT INTO ACT_SMT
	VALUES ("4efe7ec1-cb9c-4a99-a31c-2ecf7f6c4b3a",
	"aceb355d-74c3-4692-9504-21328cd72e60",
	"93e0da06-eeb7-4c1c-b78c-7f9ae8590f75",
	68,
	5,
	'setup line: 68');
INSERT INTO ACT_REL
	VALUES ("4efe7ec1-cb9c-4a99-a31c-2ecf7f6c4b3a",
	"279ed21d-2933-413b-b304-0dd0b70a96de",
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a",
	'',
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	68,
	33,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("93e0da06-eeb7-4c1c-b78c-7f9ae8590f75",
	"aceb355d-74c3-4692-9504-21328cd72e60",
	"7faebcf8-255c-4185-aa3b-0aa3cceb16de",
	69,
	5,
	'setup line: 69');
INSERT INTO ACT_REL
	VALUES ("93e0da06-eeb7-4c1c-b78c-7f9ae8590f75",
	"279ed21d-2933-413b-b304-0dd0b70a96de",
	"7b2d7c61-fdc5-4932-b37e-b08ae2ce1bb6",
	'',
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	69,
	31,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7faebcf8-255c-4185-aa3b-0aa3cceb16de",
	"aceb355d-74c3-4692-9504-21328cd72e60",
	"858420a4-c03b-40d2-a326-2743bd923c96",
	70,
	5,
	'setup line: 70');
INSERT INTO ACT_REL
	VALUES ("7faebcf8-255c-4185-aa3b-0aa3cceb16de",
	"279ed21d-2933-413b-b304-0dd0b70a96de",
	"b38f0ebf-1010-49d7-880b-8ccebc8e1519",
	'',
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	70,
	34,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("858420a4-c03b-40d2-a326-2743bd923c96",
	"aceb355d-74c3-4692-9504-21328cd72e60",
	"c61d43e3-63c8-4e76-a46b-5e82a1f4ed73",
	73,
	5,
	'setup line: 73');
INSERT INTO ACT_FIW
	VALUES ("858420a4-c03b-40d2-a326-2743bd923c96",
	"229f4747-43ed-440c-8c98-2dbbae389719",
	1,
	'many',
	"5e46bfd9-1d15-483a-b41a-0c1c85be0390",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	73,
	42);
INSERT INTO ACT_SMT
	VALUES ("c61d43e3-63c8-4e76-a46b-5e82a1f4ed73",
	"aceb355d-74c3-4692-9504-21328cd72e60",
	"00000000-0000-0000-0000-000000000000",
	74,
	5,
	'setup line: 74');
INSERT INTO ACT_FOR
	VALUES ("c61d43e3-63c8-4e76-a46b-5e82a1f4ed73",
	"8fc1b5a1-c0b9-45f8-a203-c105c9f20f85",
	0,
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a",
	"229f4747-43ed-440c-8c98-2dbbae389719",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_VAL
	VALUES ("976e40c9-d042-4623-b231-05d0b14d8022",
	0,
	0,
	67,
	54,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"aceb355d-74c3-4692-9504-21328cd72e60");
INSERT INTO V_SLR
	VALUES ("976e40c9-d042-4623-b231-05d0b14d8022",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("a1d652f9-cf3d-4194-bbfe-9a4dce58b2aa",
	0,
	0,
	67,
	63,
	67,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aceb355d-74c3-4692-9504-21328cd72e60");
INSERT INTO V_AVL
	VALUES ("a1d652f9-cf3d-4194-bbfe-9a4dce58b2aa",
	"976e40c9-d042-4623-b231-05d0b14d8022",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO V_VAL
	VALUES ("da29895a-a48e-4903-bf0b-f1ce81b42feb",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"aceb355d-74c3-4692-9504-21328cd72e60");
INSERT INTO V_BIN
	VALUES ("da29895a-a48e-4903-bf0b-f1ce81b42feb",
	"19a12f0a-48e3-42da-8675-bc0a2e7a2809",
	"a1d652f9-cf3d-4194-bbfe-9a4dce58b2aa",
	'==');
INSERT INTO V_VAL
	VALUES ("19a12f0a-48e3-42da-8675-bc0a2e7a2809",
	0,
	0,
	67,
	72,
	72,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aceb355d-74c3-4692-9504-21328cd72e60");
INSERT INTO V_LIN
	VALUES ("19a12f0a-48e3-42da-8675-bc0a2e7a2809",
	'0');
INSERT INTO V_VAL
	VALUES ("58490655-14f8-483a-b826-9a7c5b6243c6",
	0,
	0,
	73,
	56,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"aceb355d-74c3-4692-9504-21328cd72e60");
INSERT INTO V_SLR
	VALUES ("58490655-14f8-483a-b826-9a7c5b6243c6",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("93e939db-c9e8-4d20-8ac9-ec4b769da8b0",
	0,
	0,
	73,
	65,
	69,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aceb355d-74c3-4692-9504-21328cd72e60");
INSERT INTO V_AVL
	VALUES ("93e939db-c9e8-4d20-8ac9-ec4b769da8b0",
	"58490655-14f8-483a-b826-9a7c5b6243c6",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO V_VAL
	VALUES ("5e46bfd9-1d15-483a-b41a-0c1c85be0390",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"aceb355d-74c3-4692-9504-21328cd72e60");
INSERT INTO V_BIN
	VALUES ("5e46bfd9-1d15-483a-b41a-0c1c85be0390",
	"8ad1dc47-915c-4741-9807-7e5298d78e29",
	"93e939db-c9e8-4d20-8ac9-ec4b769da8b0",
	'!=');
INSERT INTO V_VAL
	VALUES ("8ad1dc47-915c-4741-9807-7e5298d78e29",
	0,
	0,
	73,
	74,
	74,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aceb355d-74c3-4692-9504-21328cd72e60");
INSERT INTO V_LIN
	VALUES ("8ad1dc47-915c-4741-9807-7e5298d78e29",
	'0');
INSERT INTO V_VAR
	VALUES ("279ed21d-2933-413b-b304-0dd0b70a96de",
	"aceb355d-74c3-4692-9504-21328cd72e60",
	'cell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("279ed21d-2933-413b-b304-0dd0b70a96de",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("4ba95a6b-09b9-4ace-b9c5-9faf46160724",
	66,
	28,
	31,
	"279ed21d-2933-413b-b304-0dd0b70a96de");
INSERT INTO V_LOC
	VALUES ("2304d601-04a7-4af5-aec2-90580bb40ebd",
	68,
	12,
	15,
	"279ed21d-2933-413b-b304-0dd0b70a96de");
INSERT INTO V_LOC
	VALUES ("e3590009-22a3-4fb1-a6ed-278d367c5905",
	69,
	12,
	15,
	"279ed21d-2933-413b-b304-0dd0b70a96de");
INSERT INTO V_LOC
	VALUES ("4635e65f-71e9-444a-9a19-c3f081b86076",
	70,
	12,
	15,
	"279ed21d-2933-413b-b304-0dd0b70a96de");
INSERT INTO V_LOC
	VALUES ("25425185-6690-411d-94c5-b646b08320ee",
	76,
	23,
	26,
	"279ed21d-2933-413b-b304-0dd0b70a96de");
INSERT INTO V_VAR
	VALUES ("229f4747-43ed-440c-8c98-2dbbae389719",
	"aceb355d-74c3-4692-9504-21328cd72e60",
	'digits',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("229f4747-43ed-440c-8c98-2dbbae389719",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("a722b9db-d76b-4015-af79-261d1b978d2a",
	73,
	17,
	22,
	"229f4747-43ed-440c-8c98-2dbbae389719");
INSERT INTO V_LOC
	VALUES ("f3d426f0-67c2-49f8-8daa-f16680eb2121",
	74,
	23,
	28,
	"229f4747-43ed-440c-8c98-2dbbae389719");
INSERT INTO ACT_BLK
	VALUES ("8fc1b5a1-c0b9-45f8-a203-c105c9f20f85",
	0,
	0,
	0,
	'',
	'',
	'',
	76,
	7,
	75,
	42,
	0,
	0,
	76,
	35,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8260db12-318b-4ebc-8655-8b22f0f026e6",
	"8fc1b5a1-c0b9-45f8-a203-c105c9f20f85",
	"9702ed00-fa05-44ca-bad2-0122cb7224e6",
	75,
	7,
	'setup line: 75');
INSERT INTO ACT_CR
	VALUES ("8260db12-318b-4ebc-8655-8b22f0f026e6",
	"87a994b7-167a-49c8-80eb-88b9580e714d",
	1,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	75,
	42);
INSERT INTO ACT_SMT
	VALUES ("9702ed00-fa05-44ca-bad2-0122cb7224e6",
	"8fc1b5a1-c0b9-45f8-a203-c105c9f20f85",
	"00000000-0000-0000-0000-000000000000",
	76,
	7,
	'setup line: 76');
INSERT INTO ACT_RU
	VALUES ("9702ed00-fa05-44ca-bad2-0122cb7224e6",
	"a1f31bf0-1308-488f-b18c-06fb4bb2893a",
	"279ed21d-2933-413b-b304-0dd0b70a96de",
	"87a994b7-167a-49c8-80eb-88b9580e714d",
	'',
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	76,
	35,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("87a994b7-167a-49c8-80eb-88b9580e714d",
	"8fc1b5a1-c0b9-45f8-a203-c105c9f20f85",
	'eligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("87a994b7-167a-49c8-80eb-88b9580e714d",
	0,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("b1f74b04-e83d-4784-9d6e-c2a84e336cd4",
	75,
	30,
	37,
	"87a994b7-167a-49c8-80eb-88b9580e714d");
INSERT INTO V_LOC
	VALUES ("127185b9-d822-4f0a-81d9-b679ac53901e",
	76,
	44,
	51,
	"87a994b7-167a-49c8-80eb-88b9580e714d");
INSERT INTO ACT_BLK
	VALUES ("6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	0,
	0,
	0,
	'',
	'',
	'',
	116,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f60737af-5800-4aae-bd3f-ce070216028b",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	"00000000-0000-0000-0000-000000000000",
	84,
	3,
	'setup line: 84');
INSERT INTO ACT_IF
	VALUES ("f60737af-5800-4aae-bd3f-ce070216028b",
	"cc832d96-f252-4aa7-b5c3-c58ecd2eefb7",
	"a4d5c399-c5a7-412d-b97e-58d949e6b29f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("121c42cb-5f01-4a44-82a1-856151a7917c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	"00000000-0000-0000-0000-000000000000",
	88,
	3,
	'setup line: 88');
INSERT INTO ACT_EL
	VALUES ("121c42cb-5f01-4a44-82a1-856151a7917c",
	"ca4a460f-d0a6-41d0-b0d7-db3ada576ccf",
	"968e674e-35f9-468d-bd73-cf30117e8d46",
	"f60737af-5800-4aae-bd3f-ce070216028b");
INSERT INTO ACT_SMT
	VALUES ("55e57fdd-86e7-4d39-948b-9f6bfa075b4f",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	"00000000-0000-0000-0000-000000000000",
	92,
	3,
	'setup line: 92');
INSERT INTO ACT_EL
	VALUES ("55e57fdd-86e7-4d39-948b-9f6bfa075b4f",
	"b46822c8-4635-4d75-9c0f-79ec2f345022",
	"39102f75-b077-497d-a1c3-ab7a6f0c2528",
	"f60737af-5800-4aae-bd3f-ce070216028b");
INSERT INTO ACT_SMT
	VALUES ("39d7fac3-0c0a-4d21-862c-fad406e8a63c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	"00000000-0000-0000-0000-000000000000",
	96,
	3,
	'setup line: 96');
INSERT INTO ACT_EL
	VALUES ("39d7fac3-0c0a-4d21-862c-fad406e8a63c",
	"c10cd259-8dc6-49c3-9053-834733fc4ee4",
	"0e516f75-f53e-4fcc-a1e5-6d30b30e5275",
	"f60737af-5800-4aae-bd3f-ce070216028b");
INSERT INTO ACT_SMT
	VALUES ("7f4e0aa9-05d8-44b4-9f81-362b011fab60",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	"00000000-0000-0000-0000-000000000000",
	100,
	3,
	'setup line: 100');
INSERT INTO ACT_EL
	VALUES ("7f4e0aa9-05d8-44b4-9f81-362b011fab60",
	"fb600425-78f5-458c-995c-f1a85c247514",
	"416cd389-4365-43a8-8774-b9798f1637a2",
	"f60737af-5800-4aae-bd3f-ce070216028b");
INSERT INTO ACT_SMT
	VALUES ("eb3b8ed5-5624-434d-b4e5-1dd009227bc4",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	"00000000-0000-0000-0000-000000000000",
	104,
	3,
	'setup line: 104');
INSERT INTO ACT_EL
	VALUES ("eb3b8ed5-5624-434d-b4e5-1dd009227bc4",
	"3077da32-e8a9-416e-baba-ee1712aac53e",
	"6e6ac493-3663-4382-a2b4-de122004ee6b",
	"f60737af-5800-4aae-bd3f-ce070216028b");
INSERT INTO ACT_SMT
	VALUES ("8969a7f7-59c3-4a7f-9cc2-81f965641f89",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	"00000000-0000-0000-0000-000000000000",
	108,
	3,
	'setup line: 108');
INSERT INTO ACT_EL
	VALUES ("8969a7f7-59c3-4a7f-9cc2-81f965641f89",
	"3cc83580-3985-463e-b07e-457458daf4ba",
	"adf13465-4530-4cc6-b26b-391c3ae79797",
	"f60737af-5800-4aae-bd3f-ce070216028b");
INSERT INTO ACT_SMT
	VALUES ("96b875f1-bd6e-42d9-bad6-fca619223ed8",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	"00000000-0000-0000-0000-000000000000",
	112,
	3,
	'setup line: 112');
INSERT INTO ACT_EL
	VALUES ("96b875f1-bd6e-42d9-bad6-fca619223ed8",
	"5107610a-0416-44a7-b132-349affa58cfb",
	"60d1f65c-9e00-435b-8f72-466b15ce370f",
	"f60737af-5800-4aae-bd3f-ce070216028b");
INSERT INTO ACT_SMT
	VALUES ("6c249e92-7a4b-4cdc-82fa-bd1c01df4429",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f",
	"00000000-0000-0000-0000-000000000000",
	116,
	3,
	'setup line: 116');
INSERT INTO ACT_EL
	VALUES ("6c249e92-7a4b-4cdc-82fa-bd1c01df4429",
	"84d318d0-3290-42ee-94fc-0ca82a809368",
	"e51b1777-830c-49be-a8bd-0dac8e9b2eb5",
	"f60737af-5800-4aae-bd3f-ce070216028b");
INSERT INTO V_VAL
	VALUES ("acaaf773-35a6-48c2-a899-0ef0a3dc4878",
	0,
	0,
	84,
	10,
	13,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("acaaf773-35a6-48c2-a899-0ef0a3dc4878",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("790df0a1-0655-47e0-96d3-772e36a62a7d",
	0,
	0,
	84,
	15,
	24,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("790df0a1-0655-47e0-96d3-772e36a62a7d",
	"acaaf773-35a6-48c2-a899-0ef0a3dc4878",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("7f93c344-0a41-47e5-9cae-5ae83389471b",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("7f93c344-0a41-47e5-9cae-5ae83389471b",
	"6121844b-ed33-49f8-9d9b-91787fb24e8e",
	"790df0a1-0655-47e0-96d3-772e36a62a7d",
	'<=');
INSERT INTO V_VAL
	VALUES ("6121844b-ed33-49f8-9d9b-91787fb24e8e",
	0,
	0,
	84,
	29,
	29,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("6121844b-ed33-49f8-9d9b-91787fb24e8e",
	'3');
INSERT INTO V_VAL
	VALUES ("50a1096f-4195-4835-9869-76b84e530b36",
	0,
	0,
	85,
	8,
	11,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("50a1096f-4195-4835-9869-76b84e530b36",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("7a6484da-8808-42ea-938a-ac4c72e40967",
	0,
	0,
	85,
	13,
	25,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("7a6484da-8808-42ea-938a-ac4c72e40967",
	"50a1096f-4195-4835-9869-76b84e530b36",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("062f6d67-29e6-4b99-98b5-a94a72cb38f6",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("062f6d67-29e6-4b99-98b5-a94a72cb38f6",
	"fc0cda14-af1c-4a43-adb8-11b2924bbe45",
	"7a6484da-8808-42ea-938a-ac4c72e40967",
	'<=');
INSERT INTO V_VAL
	VALUES ("fc0cda14-af1c-4a43-adb8-11b2924bbe45",
	0,
	0,
	85,
	30,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("fc0cda14-af1c-4a43-adb8-11b2924bbe45",
	'3');
INSERT INTO V_VAL
	VALUES ("a4d5c399-c5a7-412d-b97e-58d949e6b29f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("a4d5c399-c5a7-412d-b97e-58d949e6b29f",
	"062f6d67-29e6-4b99-98b5-a94a72cb38f6",
	"7f93c344-0a41-47e5-9cae-5ae83389471b",
	'and');
INSERT INTO V_VAL
	VALUES ("bd18a7d1-1360-468e-aedc-4fb175244deb",
	0,
	0,
	88,
	12,
	15,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("bd18a7d1-1360-468e-aedc-4fb175244deb",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("13552d29-ed72-4f72-9639-8c1939813b59",
	0,
	0,
	88,
	17,
	26,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("13552d29-ed72-4f72-9639-8c1939813b59",
	"bd18a7d1-1360-468e-aedc-4fb175244deb",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("15b1ce61-87ef-43d0-8cb7-b3e74029782d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("15b1ce61-87ef-43d0-8cb7-b3e74029782d",
	"8d4bc016-6df5-4e3f-be23-ff0196dba9b3",
	"13552d29-ed72-4f72-9639-8c1939813b59",
	'<=');
INSERT INTO V_VAL
	VALUES ("8d4bc016-6df5-4e3f-be23-ff0196dba9b3",
	0,
	0,
	88,
	31,
	31,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("8d4bc016-6df5-4e3f-be23-ff0196dba9b3",
	'3');
INSERT INTO V_VAL
	VALUES ("5c5139bf-6684-4769-943d-08ec87194d54",
	0,
	0,
	89,
	10,
	10,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("5c5139bf-6684-4769-943d-08ec87194d54",
	'4');
INSERT INTO V_VAL
	VALUES ("e5c6613e-8079-4a1b-b91e-e22b617aa9ce",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("e5c6613e-8079-4a1b-b91e-e22b617aa9ce",
	"1ad07568-a327-45a3-aacb-0f21b5b9ef51",
	"5c5139bf-6684-4769-943d-08ec87194d54",
	'<=');
INSERT INTO V_VAL
	VALUES ("70dcdbf1-a23f-441c-b974-467827a8f114",
	0,
	0,
	89,
	15,
	18,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("70dcdbf1-a23f-441c-b974-467827a8f114",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("1ad07568-a327-45a3-aacb-0f21b5b9ef51",
	0,
	0,
	89,
	20,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("1ad07568-a327-45a3-aacb-0f21b5b9ef51",
	"70dcdbf1-a23f-441c-b974-467827a8f114",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("d0d36638-9c51-441b-865a-d162a97c4115",
	0,
	0,
	89,
	42,
	45,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("d0d36638-9c51-441b-865a-d162a97c4115",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("8550c61c-08e6-4bd7-805c-d4bedf4fbf25",
	0,
	0,
	89,
	47,
	59,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("8550c61c-08e6-4bd7-805c-d4bedf4fbf25",
	"d0d36638-9c51-441b-865a-d162a97c4115",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("d2dc8c0d-c32f-4bb2-9bf8-77fe5f399d40",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("d2dc8c0d-c32f-4bb2-9bf8-77fe5f399d40",
	"c732dc22-cbf5-4e13-acdf-dd8aafa30deb",
	"8550c61c-08e6-4bd7-805c-d4bedf4fbf25",
	'<=');
INSERT INTO V_VAL
	VALUES ("c732dc22-cbf5-4e13-acdf-dd8aafa30deb",
	0,
	0,
	89,
	64,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("c732dc22-cbf5-4e13-acdf-dd8aafa30deb",
	'6');
INSERT INTO V_VAL
	VALUES ("9ef5cbc0-3021-476e-a948-4c3b4bdaa310",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("9ef5cbc0-3021-476e-a948-4c3b4bdaa310",
	"d2dc8c0d-c32f-4bb2-9bf8-77fe5f399d40",
	"e5c6613e-8079-4a1b-b91e-e22b617aa9ce",
	'and');
INSERT INTO V_VAL
	VALUES ("968e674e-35f9-468d-bd73-cf30117e8d46",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("968e674e-35f9-468d-bd73-cf30117e8d46",
	"9ef5cbc0-3021-476e-a948-4c3b4bdaa310",
	"15b1ce61-87ef-43d0-8cb7-b3e74029782d",
	'and');
INSERT INTO V_VAL
	VALUES ("2b6eb697-3a4f-425f-98e8-eabf79636473",
	0,
	0,
	92,
	12,
	15,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("2b6eb697-3a4f-425f-98e8-eabf79636473",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("871e4960-4fd3-49cf-aa6b-8fe8561ecb64",
	0,
	0,
	92,
	17,
	26,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("871e4960-4fd3-49cf-aa6b-8fe8561ecb64",
	"2b6eb697-3a4f-425f-98e8-eabf79636473",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("1be47482-4c16-486a-ac1f-c98ad0ed2a3c",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("1be47482-4c16-486a-ac1f-c98ad0ed2a3c",
	"eba4e6fd-0a85-4a40-be51-e7f4435f593e",
	"871e4960-4fd3-49cf-aa6b-8fe8561ecb64",
	'<=');
INSERT INTO V_VAL
	VALUES ("eba4e6fd-0a85-4a40-be51-e7f4435f593e",
	0,
	0,
	92,
	31,
	31,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("eba4e6fd-0a85-4a40-be51-e7f4435f593e",
	'3');
INSERT INTO V_VAL
	VALUES ("c7e3d4c3-c600-44ec-99e7-36c263549772",
	0,
	0,
	93,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("c7e3d4c3-c600-44ec-99e7-36c263549772",
	'7');
INSERT INTO V_VAL
	VALUES ("ef8e4f9b-99e5-4080-9f8b-d95d244b293f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("ef8e4f9b-99e5-4080-9f8b-d95d244b293f",
	"4830e2a7-1f93-4eab-b54b-5ab68236dc93",
	"c7e3d4c3-c600-44ec-99e7-36c263549772",
	'<=');
INSERT INTO V_VAL
	VALUES ("7c04ec1a-d002-49f1-8695-b32ff3eaee03",
	0,
	0,
	93,
	13,
	16,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("7c04ec1a-d002-49f1-8695-b32ff3eaee03",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("4830e2a7-1f93-4eab-b54b-5ab68236dc93",
	0,
	0,
	93,
	18,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("4830e2a7-1f93-4eab-b54b-5ab68236dc93",
	"7c04ec1a-d002-49f1-8695-b32ff3eaee03",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("39102f75-b077-497d-a1c3-ab7a6f0c2528",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("39102f75-b077-497d-a1c3-ab7a6f0c2528",
	"ef8e4f9b-99e5-4080-9f8b-d95d244b293f",
	"1be47482-4c16-486a-ac1f-c98ad0ed2a3c",
	'and');
INSERT INTO V_VAL
	VALUES ("de9817b6-e898-47b7-89a6-29401c773789",
	0,
	0,
	96,
	14,
	14,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("de9817b6-e898-47b7-89a6-29401c773789",
	'4');
INSERT INTO V_VAL
	VALUES ("59b64d6c-aa92-4597-bcb1-85c815b33f12",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("59b64d6c-aa92-4597-bcb1-85c815b33f12",
	"127b2aa1-0e89-45d7-a37e-6c3ced64e9c5",
	"de9817b6-e898-47b7-89a6-29401c773789",
	'<=');
INSERT INTO V_VAL
	VALUES ("0c1db385-5fd7-460f-af94-88f9341031c2",
	0,
	0,
	96,
	19,
	22,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("0c1db385-5fd7-460f-af94-88f9341031c2",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("127b2aa1-0e89-45d7-a37e-6c3ced64e9c5",
	0,
	0,
	96,
	24,
	33,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("127b2aa1-0e89-45d7-a37e-6c3ced64e9c5",
	"0c1db385-5fd7-460f-af94-88f9341031c2",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("76a107c7-3247-453a-94ce-24afbbf9e779",
	0,
	0,
	96,
	43,
	46,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("76a107c7-3247-453a-94ce-24afbbf9e779",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("6d2735ae-8c5b-4b44-861b-c666f0a1d30d",
	0,
	0,
	96,
	48,
	57,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("6d2735ae-8c5b-4b44-861b-c666f0a1d30d",
	"76a107c7-3247-453a-94ce-24afbbf9e779",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("be78d7a5-cee5-4e90-b137-362d630c7581",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("be78d7a5-cee5-4e90-b137-362d630c7581",
	"197dc8e0-aef8-4034-adea-a889b6ef81f8",
	"6d2735ae-8c5b-4b44-861b-c666f0a1d30d",
	'<=');
INSERT INTO V_VAL
	VALUES ("197dc8e0-aef8-4034-adea-a889b6ef81f8",
	0,
	0,
	96,
	62,
	62,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("197dc8e0-aef8-4034-adea-a889b6ef81f8",
	'6');
INSERT INTO V_VAL
	VALUES ("15dc7490-4766-490e-b0e5-4d7c9b1d4743",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("15dc7490-4766-490e-b0e5-4d7c9b1d4743",
	"be78d7a5-cee5-4e90-b137-362d630c7581",
	"59b64d6c-aa92-4597-bcb1-85c815b33f12",
	'and');
INSERT INTO V_VAL
	VALUES ("19feb33f-b270-42f7-9f19-fb99d78115d8",
	0,
	0,
	97,
	8,
	11,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("19feb33f-b270-42f7-9f19-fb99d78115d8",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("147b97c1-4cf9-4ec6-ac1d-1bf6b570e33a",
	0,
	0,
	97,
	13,
	25,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("147b97c1-4cf9-4ec6-ac1d-1bf6b570e33a",
	"19feb33f-b270-42f7-9f19-fb99d78115d8",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("f00c2cf4-75c6-47d4-94a3-dcedd0adc2b1",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("f00c2cf4-75c6-47d4-94a3-dcedd0adc2b1",
	"5eff9701-ef38-4f1e-a305-99f28d08d815",
	"147b97c1-4cf9-4ec6-ac1d-1bf6b570e33a",
	'<=');
INSERT INTO V_VAL
	VALUES ("5eff9701-ef38-4f1e-a305-99f28d08d815",
	0,
	0,
	97,
	30,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("5eff9701-ef38-4f1e-a305-99f28d08d815",
	'3');
INSERT INTO V_VAL
	VALUES ("0e516f75-f53e-4fcc-a1e5-6d30b30e5275",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("0e516f75-f53e-4fcc-a1e5-6d30b30e5275",
	"f00c2cf4-75c6-47d4-94a3-dcedd0adc2b1",
	"15dc7490-4766-490e-b0e5-4d7c9b1d4743",
	'and');
INSERT INTO V_VAL
	VALUES ("f8807220-0edd-4e9f-a6fb-38425747e4a9",
	0,
	0,
	100,
	14,
	14,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("f8807220-0edd-4e9f-a6fb-38425747e4a9",
	'4');
INSERT INTO V_VAL
	VALUES ("4ed5d243-6a13-4dc9-b0f2-e9e7063a2ee7",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("4ed5d243-6a13-4dc9-b0f2-e9e7063a2ee7",
	"026bf591-a8ff-4561-8890-cdb35e21abc9",
	"f8807220-0edd-4e9f-a6fb-38425747e4a9",
	'<=');
INSERT INTO V_VAL
	VALUES ("36b898b5-d4b3-4c71-919f-64f92969b977",
	0,
	0,
	100,
	19,
	22,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("36b898b5-d4b3-4c71-919f-64f92969b977",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("026bf591-a8ff-4561-8890-cdb35e21abc9",
	0,
	0,
	100,
	24,
	33,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("026bf591-a8ff-4561-8890-cdb35e21abc9",
	"36b898b5-d4b3-4c71-919f-64f92969b977",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("4eb22706-7a89-4ca1-8a22-e6b1ba352bac",
	0,
	0,
	100,
	43,
	46,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("4eb22706-7a89-4ca1-8a22-e6b1ba352bac",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("e0c557d4-5130-489e-8b59-148e27d1a319",
	0,
	0,
	100,
	48,
	57,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("e0c557d4-5130-489e-8b59-148e27d1a319",
	"4eb22706-7a89-4ca1-8a22-e6b1ba352bac",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("408a4af1-b16c-4214-9237-49a7c83179c3",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("408a4af1-b16c-4214-9237-49a7c83179c3",
	"4760935a-04a6-432c-89bf-e90fa7a7fad7",
	"e0c557d4-5130-489e-8b59-148e27d1a319",
	'<=');
INSERT INTO V_VAL
	VALUES ("4760935a-04a6-432c-89bf-e90fa7a7fad7",
	0,
	0,
	100,
	62,
	62,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("4760935a-04a6-432c-89bf-e90fa7a7fad7",
	'6');
INSERT INTO V_VAL
	VALUES ("61983912-7dea-4da6-a47b-d156bfd6e6f4",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("61983912-7dea-4da6-a47b-d156bfd6e6f4",
	"408a4af1-b16c-4214-9237-49a7c83179c3",
	"4ed5d243-6a13-4dc9-b0f2-e9e7063a2ee7",
	'and');
INSERT INTO V_VAL
	VALUES ("dc180e97-828f-40dd-8f02-f1d74bef9bfd",
	0,
	0,
	101,
	10,
	10,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("dc180e97-828f-40dd-8f02-f1d74bef9bfd",
	'4');
INSERT INTO V_VAL
	VALUES ("2dafb8e6-cc65-48d2-813b-57f6a562472f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("2dafb8e6-cc65-48d2-813b-57f6a562472f",
	"1ede9333-13ae-4fb2-a174-ba8a33fb9d72",
	"dc180e97-828f-40dd-8f02-f1d74bef9bfd",
	'<=');
INSERT INTO V_VAL
	VALUES ("56f2e1dc-d02d-485c-8c7d-8f3f28d960b9",
	0,
	0,
	101,
	15,
	18,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("56f2e1dc-d02d-485c-8c7d-8f3f28d960b9",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("1ede9333-13ae-4fb2-a174-ba8a33fb9d72",
	0,
	0,
	101,
	20,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("1ede9333-13ae-4fb2-a174-ba8a33fb9d72",
	"56f2e1dc-d02d-485c-8c7d-8f3f28d960b9",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("51b48764-f114-428e-a30f-e85915185a99",
	0,
	0,
	101,
	42,
	45,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("51b48764-f114-428e-a30f-e85915185a99",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("e8600adf-d0d6-4d33-9c7c-29caad2deda7",
	0,
	0,
	101,
	47,
	59,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("e8600adf-d0d6-4d33-9c7c-29caad2deda7",
	"51b48764-f114-428e-a30f-e85915185a99",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("afc0dcf6-f6b9-41cb-93e4-651cd4655869",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("afc0dcf6-f6b9-41cb-93e4-651cd4655869",
	"00e7a8dd-de06-4fca-9410-10e416385c2a",
	"e8600adf-d0d6-4d33-9c7c-29caad2deda7",
	'<=');
INSERT INTO V_VAL
	VALUES ("00e7a8dd-de06-4fca-9410-10e416385c2a",
	0,
	0,
	101,
	64,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("00e7a8dd-de06-4fca-9410-10e416385c2a",
	'6');
INSERT INTO V_VAL
	VALUES ("0059a850-4f3f-4b95-ae75-40060650ea09",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("0059a850-4f3f-4b95-ae75-40060650ea09",
	"afc0dcf6-f6b9-41cb-93e4-651cd4655869",
	"2dafb8e6-cc65-48d2-813b-57f6a562472f",
	'and');
INSERT INTO V_VAL
	VALUES ("416cd389-4365-43a8-8774-b9798f1637a2",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("416cd389-4365-43a8-8774-b9798f1637a2",
	"0059a850-4f3f-4b95-ae75-40060650ea09",
	"61983912-7dea-4da6-a47b-d156bfd6e6f4",
	'and');
INSERT INTO V_VAL
	VALUES ("caf98220-e555-4da2-aeae-5f606b6a27a5",
	0,
	0,
	104,
	14,
	14,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("caf98220-e555-4da2-aeae-5f606b6a27a5",
	'4');
INSERT INTO V_VAL
	VALUES ("5e8121f2-7504-4efb-a016-4dcb150362d3",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("5e8121f2-7504-4efb-a016-4dcb150362d3",
	"d6bad205-faa2-4641-acd2-f60aef6057ac",
	"caf98220-e555-4da2-aeae-5f606b6a27a5",
	'<=');
INSERT INTO V_VAL
	VALUES ("5f40425b-6829-42ce-9eb1-0d234ceba249",
	0,
	0,
	104,
	19,
	22,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("5f40425b-6829-42ce-9eb1-0d234ceba249",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("d6bad205-faa2-4641-acd2-f60aef6057ac",
	0,
	0,
	104,
	24,
	33,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("d6bad205-faa2-4641-acd2-f60aef6057ac",
	"5f40425b-6829-42ce-9eb1-0d234ceba249",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("f5369d1e-8989-471c-a7d1-247bf0e71324",
	0,
	0,
	104,
	43,
	46,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("f5369d1e-8989-471c-a7d1-247bf0e71324",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("eeb1a609-9202-459f-a525-6b7fb07abf34",
	0,
	0,
	104,
	48,
	57,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("eeb1a609-9202-459f-a525-6b7fb07abf34",
	"f5369d1e-8989-471c-a7d1-247bf0e71324",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("e8d2277e-07d5-48ce-9469-055fd845b1c7",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("e8d2277e-07d5-48ce-9469-055fd845b1c7",
	"14b0d168-cf42-4e43-83ad-1a9d9ec18006",
	"eeb1a609-9202-459f-a525-6b7fb07abf34",
	'<=');
INSERT INTO V_VAL
	VALUES ("14b0d168-cf42-4e43-83ad-1a9d9ec18006",
	0,
	0,
	104,
	62,
	62,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("14b0d168-cf42-4e43-83ad-1a9d9ec18006",
	'6');
INSERT INTO V_VAL
	VALUES ("f0191f4b-dfd9-4381-a378-6964804ee9aa",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("f0191f4b-dfd9-4381-a378-6964804ee9aa",
	"e8d2277e-07d5-48ce-9469-055fd845b1c7",
	"5e8121f2-7504-4efb-a016-4dcb150362d3",
	'and');
INSERT INTO V_VAL
	VALUES ("5565e8a6-fd5b-4a83-95e6-5d67d5d0db41",
	0,
	0,
	105,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("5565e8a6-fd5b-4a83-95e6-5d67d5d0db41",
	'7');
INSERT INTO V_VAL
	VALUES ("a02d40d7-54b1-4cc8-bc0f-3bb4d37aeb4a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("a02d40d7-54b1-4cc8-bc0f-3bb4d37aeb4a",
	"1bcebd5f-a2a7-4da6-88f0-2b1b93f6cf7d",
	"5565e8a6-fd5b-4a83-95e6-5d67d5d0db41",
	'<=');
INSERT INTO V_VAL
	VALUES ("27553cb3-a2e2-4aa1-9745-ed19b9b4d0c5",
	0,
	0,
	105,
	13,
	16,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("27553cb3-a2e2-4aa1-9745-ed19b9b4d0c5",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("1bcebd5f-a2a7-4da6-88f0-2b1b93f6cf7d",
	0,
	0,
	105,
	18,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("1bcebd5f-a2a7-4da6-88f0-2b1b93f6cf7d",
	"27553cb3-a2e2-4aa1-9745-ed19b9b4d0c5",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("6e6ac493-3663-4382-a2b4-de122004ee6b",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("6e6ac493-3663-4382-a2b4-de122004ee6b",
	"a02d40d7-54b1-4cc8-bc0f-3bb4d37aeb4a",
	"f0191f4b-dfd9-4381-a378-6964804ee9aa",
	'and');
INSERT INTO V_VAL
	VALUES ("bb01f7f9-f281-44c9-b323-391ddf650e6a",
	0,
	0,
	108,
	12,
	12,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("bb01f7f9-f281-44c9-b323-391ddf650e6a",
	'7');
INSERT INTO V_VAL
	VALUES ("7bd9c5c8-d020-4679-9fc4-3489ff3ff452",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("7bd9c5c8-d020-4679-9fc4-3489ff3ff452",
	"0f623b82-90d5-4a16-955f-b9c483a7b404",
	"bb01f7f9-f281-44c9-b323-391ddf650e6a",
	'<=');
INSERT INTO V_VAL
	VALUES ("f3c140e5-6a25-494b-8c5e-6b45e691b7f0",
	0,
	0,
	108,
	17,
	20,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("f3c140e5-6a25-494b-8c5e-6b45e691b7f0",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("0f623b82-90d5-4a16-955f-b9c483a7b404",
	0,
	0,
	108,
	22,
	31,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("0f623b82-90d5-4a16-955f-b9c483a7b404",
	"f3c140e5-6a25-494b-8c5e-6b45e691b7f0",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("2f8c3618-6522-4057-95d0-f8c88eba7dcc",
	0,
	0,
	109,
	8,
	11,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("2f8c3618-6522-4057-95d0-f8c88eba7dcc",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("f7df6729-f741-4060-859d-28bce3626629",
	0,
	0,
	109,
	13,
	25,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("f7df6729-f741-4060-859d-28bce3626629",
	"2f8c3618-6522-4057-95d0-f8c88eba7dcc",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("63ef60b3-f332-48f7-8534-0dc8ee318c69",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("63ef60b3-f332-48f7-8534-0dc8ee318c69",
	"b6e61675-a02a-48c9-b608-887d0ec1816f",
	"f7df6729-f741-4060-859d-28bce3626629",
	'<=');
INSERT INTO V_VAL
	VALUES ("b6e61675-a02a-48c9-b608-887d0ec1816f",
	0,
	0,
	109,
	30,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("b6e61675-a02a-48c9-b608-887d0ec1816f",
	'3');
INSERT INTO V_VAL
	VALUES ("adf13465-4530-4cc6-b26b-391c3ae79797",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("adf13465-4530-4cc6-b26b-391c3ae79797",
	"63ef60b3-f332-48f7-8534-0dc8ee318c69",
	"7bd9c5c8-d020-4679-9fc4-3489ff3ff452",
	'and');
INSERT INTO V_VAL
	VALUES ("b4afd7b5-396c-46db-b028-624d4c6d3f63",
	0,
	0,
	112,
	12,
	12,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("b4afd7b5-396c-46db-b028-624d4c6d3f63",
	'7');
INSERT INTO V_VAL
	VALUES ("22528e84-63d1-44d2-baa0-e13e365fa663",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("22528e84-63d1-44d2-baa0-e13e365fa663",
	"b8d782f5-11c0-4e28-a2cd-ceec68abb3c5",
	"b4afd7b5-396c-46db-b028-624d4c6d3f63",
	'<=');
INSERT INTO V_VAL
	VALUES ("0720dad8-9ccf-48c1-a4b5-33d1b5d77e1f",
	0,
	0,
	112,
	17,
	20,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("0720dad8-9ccf-48c1-a4b5-33d1b5d77e1f",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("b8d782f5-11c0-4e28-a2cd-ceec68abb3c5",
	0,
	0,
	112,
	22,
	31,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("b8d782f5-11c0-4e28-a2cd-ceec68abb3c5",
	"0720dad8-9ccf-48c1-a4b5-33d1b5d77e1f",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("be339f4d-d3f7-4c4c-a29d-6f4f4096599d",
	0,
	0,
	113,
	10,
	10,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("be339f4d-d3f7-4c4c-a29d-6f4f4096599d",
	'4');
INSERT INTO V_VAL
	VALUES ("8dec1cc5-4b22-4f1c-9d20-57f5013fffc5",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("8dec1cc5-4b22-4f1c-9d20-57f5013fffc5",
	"879e2c5c-f1f7-42d5-9e97-cf8e5b3b7584",
	"be339f4d-d3f7-4c4c-a29d-6f4f4096599d",
	'<=');
INSERT INTO V_VAL
	VALUES ("3bc57631-ca13-47ea-84cf-3b68fad77152",
	0,
	0,
	113,
	15,
	18,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("3bc57631-ca13-47ea-84cf-3b68fad77152",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("879e2c5c-f1f7-42d5-9e97-cf8e5b3b7584",
	0,
	0,
	113,
	20,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("879e2c5c-f1f7-42d5-9e97-cf8e5b3b7584",
	"3bc57631-ca13-47ea-84cf-3b68fad77152",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("bbe5ba06-8d5e-4472-80bf-4f2676f16ad9",
	0,
	0,
	113,
	42,
	45,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("bbe5ba06-8d5e-4472-80bf-4f2676f16ad9",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("43a502c7-c548-47de-acc8-a70d6f6aca9c",
	0,
	0,
	113,
	47,
	59,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("43a502c7-c548-47de-acc8-a70d6f6aca9c",
	"bbe5ba06-8d5e-4472-80bf-4f2676f16ad9",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("8f3cfb28-4416-4a6e-ba1c-fc0ff9e2330c",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("8f3cfb28-4416-4a6e-ba1c-fc0ff9e2330c",
	"66d10323-6732-4148-b06e-9474ac84fdf7",
	"43a502c7-c548-47de-acc8-a70d6f6aca9c",
	'<=');
INSERT INTO V_VAL
	VALUES ("66d10323-6732-4148-b06e-9474ac84fdf7",
	0,
	0,
	113,
	64,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("66d10323-6732-4148-b06e-9474ac84fdf7",
	'6');
INSERT INTO V_VAL
	VALUES ("ec3d89c6-3834-4f04-94a3-42d23a807433",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("ec3d89c6-3834-4f04-94a3-42d23a807433",
	"8f3cfb28-4416-4a6e-ba1c-fc0ff9e2330c",
	"8dec1cc5-4b22-4f1c-9d20-57f5013fffc5",
	'and');
INSERT INTO V_VAL
	VALUES ("60d1f65c-9e00-435b-8f72-466b15ce370f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("60d1f65c-9e00-435b-8f72-466b15ce370f",
	"ec3d89c6-3834-4f04-94a3-42d23a807433",
	"22528e84-63d1-44d2-baa0-e13e365fa663",
	'and');
INSERT INTO V_VAL
	VALUES ("0060d0ed-54d0-498d-8059-25a524377e2f",
	0,
	0,
	116,
	12,
	12,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("0060d0ed-54d0-498d-8059-25a524377e2f",
	'7');
INSERT INTO V_VAL
	VALUES ("3bdb9b49-bc7b-4924-9349-2eb2d291bf95",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("3bdb9b49-bc7b-4924-9349-2eb2d291bf95",
	"455691cd-6b71-4658-a079-f7423d4d1d24",
	"0060d0ed-54d0-498d-8059-25a524377e2f",
	'<=');
INSERT INTO V_VAL
	VALUES ("901500e1-0a05-4d85-af70-fff87a34fcc0",
	0,
	0,
	116,
	17,
	20,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("901500e1-0a05-4d85-af70-fff87a34fcc0",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("455691cd-6b71-4658-a079-f7423d4d1d24",
	0,
	0,
	116,
	22,
	31,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("455691cd-6b71-4658-a079-f7423d4d1d24",
	"901500e1-0a05-4d85-af70-fff87a34fcc0",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("8eb37af6-f6cf-4d11-9247-b71e21e2ccfd",
	0,
	0,
	117,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_LIN
	VALUES ("8eb37af6-f6cf-4d11-9247-b71e21e2ccfd",
	'7');
INSERT INTO V_VAL
	VALUES ("7746b06d-6e95-4bff-b55a-333d0ccde2c0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("7746b06d-6e95-4bff-b55a-333d0ccde2c0",
	"eec383dc-a0c2-457b-aded-032c0f71b95a",
	"8eb37af6-f6cf-4d11-9247-b71e21e2ccfd",
	'<=');
INSERT INTO V_VAL
	VALUES ("71c7ee2b-b0d5-48c8-ba31-1bce39bf7768",
	0,
	0,
	117,
	13,
	16,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_IRF
	VALUES ("71c7ee2b-b0d5-48c8-ba31-1bce39bf7768",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81");
INSERT INTO V_VAL
	VALUES ("eec383dc-a0c2-457b-aded-032c0f71b95a",
	0,
	0,
	117,
	18,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_AVL
	VALUES ("eec383dc-a0c2-457b-aded-032c0f71b95a",
	"71c7ee2b-b0d5-48c8-ba31-1bce39bf7768",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("e51b1777-830c-49be-a8bd-0dac8e9b2eb5",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6595117c-d9a3-49f5-9dc9-fc0ff9e09d8f");
INSERT INTO V_BIN
	VALUES ("e51b1777-830c-49be-a8bd-0dac8e9b2eb5",
	"7746b06d-6e95-4bff-b55a-333d0ccde2c0",
	"3bdb9b49-bc7b-4924-9349-2eb2d291bf95",
	'and');
INSERT INTO ACT_BLK
	VALUES ("cc832d96-f252-4aa7-b5c3-c58ecd2eefb7",
	1,
	0,
	1,
	'',
	'',
	'',
	87,
	5,
	86,
	38,
	0,
	0,
	87,
	31,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7d03ee4e-ce3f-42f7-a84d-a7de7291e43c",
	"cc832d96-f252-4aa7-b5c3-c58ecd2eefb7",
	"e0765f60-a72f-4414-844f-468474aebd31",
	86,
	5,
	'setup line: 86');
INSERT INTO ACT_FIW
	VALUES ("7d03ee4e-ce3f-42f7-a84d-a7de7291e43c",
	"14de98b5-5518-4749-9ab8-e0938afee10d",
	1,
	'any',
	"ae57605c-e47a-4166-be71-76450d44ca63",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	86,
	38);
INSERT INTO ACT_SMT
	VALUES ("e0765f60-a72f-4414-844f-468474aebd31",
	"cc832d96-f252-4aa7-b5c3-c58ecd2eefb7",
	"00000000-0000-0000-0000-000000000000",
	87,
	5,
	'setup line: 87');
INSERT INTO ACT_REL
	VALUES ("e0765f60-a72f-4414-844f-468474aebd31",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"14de98b5-5518-4749-9ab8-e0938afee10d",
	'',
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	87,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("426f2866-7549-4ba7-be2f-0f437913630b",
	0,
	0,
	86,
	50,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"cc832d96-f252-4aa7-b5c3-c58ecd2eefb7");
INSERT INTO V_SLR
	VALUES ("426f2866-7549-4ba7-be2f-0f437913630b",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("85b9feeb-c9e0-4558-b822-64a248cab781",
	0,
	0,
	86,
	59,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"cc832d96-f252-4aa7-b5c3-c58ecd2eefb7");
INSERT INTO V_AVL
	VALUES ("85b9feeb-c9e0-4558-b822-64a248cab781",
	"426f2866-7549-4ba7-be2f-0f437913630b",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c");
INSERT INTO V_VAL
	VALUES ("ae57605c-e47a-4166-be71-76450d44ca63",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"cc832d96-f252-4aa7-b5c3-c58ecd2eefb7");
INSERT INTO V_BIN
	VALUES ("ae57605c-e47a-4166-be71-76450d44ca63",
	"7366278d-c08c-409b-b601-2efd28004e5c",
	"85b9feeb-c9e0-4558-b822-64a248cab781",
	'==');
INSERT INTO V_VAL
	VALUES ("7366278d-c08c-409b-b601-2efd28004e5c",
	0,
	0,
	86,
	69,
	69,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"cc832d96-f252-4aa7-b5c3-c58ecd2eefb7");
INSERT INTO V_LIN
	VALUES ("7366278d-c08c-409b-b601-2efd28004e5c",
	'1');
INSERT INTO V_VAR
	VALUES ("14de98b5-5518-4749-9ab8-e0938afee10d",
	"cc832d96-f252-4aa7-b5c3-c58ecd2eefb7",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("14de98b5-5518-4749-9ab8-e0938afee10d",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("3c8f9f8c-0441-4e9f-85dd-6a5d15dec9e6",
	86,
	16,
	18,
	"14de98b5-5518-4749-9ab8-e0938afee10d");
INSERT INTO V_LOC
	VALUES ("34a6c806-0acb-4aea-8b9a-059c89678239",
	87,
	20,
	22,
	"14de98b5-5518-4749-9ab8-e0938afee10d");
INSERT INTO ACT_BLK
	VALUES ("ca4a460f-d0a6-41d0-b0d7-db3ada576ccf",
	1,
	0,
	1,
	'',
	'',
	'',
	91,
	5,
	90,
	38,
	0,
	0,
	91,
	31,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f6902c7f-3663-4a4a-bbda-e5a0b9bcd109",
	"ca4a460f-d0a6-41d0-b0d7-db3ada576ccf",
	"f2bf5f17-095a-4c13-a107-834777de9e4e",
	90,
	5,
	'setup line: 90');
INSERT INTO ACT_FIW
	VALUES ("f6902c7f-3663-4a4a-bbda-e5a0b9bcd109",
	"1f67e6d6-2df6-4cd7-9d5c-fa10384a00d7",
	1,
	'any',
	"86d7d222-e1f8-4412-b9c5-09a15a92890c",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	90,
	38);
INSERT INTO ACT_SMT
	VALUES ("f2bf5f17-095a-4c13-a107-834777de9e4e",
	"ca4a460f-d0a6-41d0-b0d7-db3ada576ccf",
	"00000000-0000-0000-0000-000000000000",
	91,
	5,
	'setup line: 91');
INSERT INTO ACT_REL
	VALUES ("f2bf5f17-095a-4c13-a107-834777de9e4e",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"1f67e6d6-2df6-4cd7-9d5c-fa10384a00d7",
	'',
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	91,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("88f3fb63-a66b-4bd5-b80c-4d82e143ecf9",
	0,
	0,
	90,
	50,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"ca4a460f-d0a6-41d0-b0d7-db3ada576ccf");
INSERT INTO V_SLR
	VALUES ("88f3fb63-a66b-4bd5-b80c-4d82e143ecf9",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("28fa2f61-f595-4a8f-b503-00df7bf1771b",
	0,
	0,
	90,
	59,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ca4a460f-d0a6-41d0-b0d7-db3ada576ccf");
INSERT INTO V_AVL
	VALUES ("28fa2f61-f595-4a8f-b503-00df7bf1771b",
	"88f3fb63-a66b-4bd5-b80c-4d82e143ecf9",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c");
INSERT INTO V_VAL
	VALUES ("86d7d222-e1f8-4412-b9c5-09a15a92890c",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"ca4a460f-d0a6-41d0-b0d7-db3ada576ccf");
INSERT INTO V_BIN
	VALUES ("86d7d222-e1f8-4412-b9c5-09a15a92890c",
	"f3cc3989-87ce-4fed-9a0a-6a3e8f0d9717",
	"28fa2f61-f595-4a8f-b503-00df7bf1771b",
	'==');
INSERT INTO V_VAL
	VALUES ("f3cc3989-87ce-4fed-9a0a-6a3e8f0d9717",
	0,
	0,
	90,
	69,
	69,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ca4a460f-d0a6-41d0-b0d7-db3ada576ccf");
INSERT INTO V_LIN
	VALUES ("f3cc3989-87ce-4fed-9a0a-6a3e8f0d9717",
	'2');
INSERT INTO V_VAR
	VALUES ("1f67e6d6-2df6-4cd7-9d5c-fa10384a00d7",
	"ca4a460f-d0a6-41d0-b0d7-db3ada576ccf",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("1f67e6d6-2df6-4cd7-9d5c-fa10384a00d7",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("b5eee2cc-f6f8-44bf-9820-854d04292243",
	90,
	16,
	18,
	"1f67e6d6-2df6-4cd7-9d5c-fa10384a00d7");
INSERT INTO V_LOC
	VALUES ("824aab7c-f1ec-46b8-bf66-7520471e2209",
	91,
	20,
	22,
	"1f67e6d6-2df6-4cd7-9d5c-fa10384a00d7");
INSERT INTO ACT_BLK
	VALUES ("b46822c8-4635-4d75-9c0f-79ec2f345022",
	1,
	0,
	1,
	'',
	'',
	'',
	95,
	5,
	94,
	38,
	0,
	0,
	95,
	31,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d75105f8-3a78-4f70-83fc-6352eedce00d",
	"b46822c8-4635-4d75-9c0f-79ec2f345022",
	"b62f8c5e-a919-4956-8684-bfaa1f172acf",
	94,
	5,
	'setup line: 94');
INSERT INTO ACT_FIW
	VALUES ("d75105f8-3a78-4f70-83fc-6352eedce00d",
	"7bbcc6a1-abd4-43f7-989f-53640c0f4b34",
	1,
	'any',
	"8d52b119-ee55-4dac-a006-f7d1587773ba",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	94,
	38);
INSERT INTO ACT_SMT
	VALUES ("b62f8c5e-a919-4956-8684-bfaa1f172acf",
	"b46822c8-4635-4d75-9c0f-79ec2f345022",
	"00000000-0000-0000-0000-000000000000",
	95,
	5,
	'setup line: 95');
INSERT INTO ACT_REL
	VALUES ("b62f8c5e-a919-4956-8684-bfaa1f172acf",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"7bbcc6a1-abd4-43f7-989f-53640c0f4b34",
	'',
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	95,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("100e29a3-9360-4495-824a-21f372fd3ab0",
	0,
	0,
	94,
	50,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"b46822c8-4635-4d75-9c0f-79ec2f345022");
INSERT INTO V_SLR
	VALUES ("100e29a3-9360-4495-824a-21f372fd3ab0",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("8652dabc-4c68-4375-945c-a76db6cda8d0",
	0,
	0,
	94,
	59,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"b46822c8-4635-4d75-9c0f-79ec2f345022");
INSERT INTO V_AVL
	VALUES ("8652dabc-4c68-4375-945c-a76db6cda8d0",
	"100e29a3-9360-4495-824a-21f372fd3ab0",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c");
INSERT INTO V_VAL
	VALUES ("8d52b119-ee55-4dac-a006-f7d1587773ba",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"b46822c8-4635-4d75-9c0f-79ec2f345022");
INSERT INTO V_BIN
	VALUES ("8d52b119-ee55-4dac-a006-f7d1587773ba",
	"748daea2-8a8f-46be-86a9-2a7d01df8ca0",
	"8652dabc-4c68-4375-945c-a76db6cda8d0",
	'==');
INSERT INTO V_VAL
	VALUES ("748daea2-8a8f-46be-86a9-2a7d01df8ca0",
	0,
	0,
	94,
	69,
	69,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"b46822c8-4635-4d75-9c0f-79ec2f345022");
INSERT INTO V_LIN
	VALUES ("748daea2-8a8f-46be-86a9-2a7d01df8ca0",
	'3');
INSERT INTO V_VAR
	VALUES ("7bbcc6a1-abd4-43f7-989f-53640c0f4b34",
	"b46822c8-4635-4d75-9c0f-79ec2f345022",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("7bbcc6a1-abd4-43f7-989f-53640c0f4b34",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("b4f6d603-e8d6-4e41-aa3b-5c3d1af5c4c6",
	94,
	16,
	18,
	"7bbcc6a1-abd4-43f7-989f-53640c0f4b34");
INSERT INTO V_LOC
	VALUES ("1fc19059-d335-4bbf-8c2e-47b6c16525f8",
	95,
	20,
	22,
	"7bbcc6a1-abd4-43f7-989f-53640c0f4b34");
INSERT INTO ACT_BLK
	VALUES ("c10cd259-8dc6-49c3-9053-834733fc4ee4",
	1,
	0,
	1,
	'',
	'',
	'',
	99,
	5,
	98,
	38,
	0,
	0,
	99,
	31,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("613f45b7-a1f9-4fb6-b480-e5c17ff43e5b",
	"c10cd259-8dc6-49c3-9053-834733fc4ee4",
	"97be3242-4fff-4e85-8bff-c60569ec2683",
	98,
	5,
	'setup line: 98');
INSERT INTO ACT_FIW
	VALUES ("613f45b7-a1f9-4fb6-b480-e5c17ff43e5b",
	"cb0a1d78-e3ba-494c-bf36-e839623af68a",
	1,
	'any',
	"bf0c105b-0c82-4c48-933d-573a485fafaa",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	98,
	38);
INSERT INTO ACT_SMT
	VALUES ("97be3242-4fff-4e85-8bff-c60569ec2683",
	"c10cd259-8dc6-49c3-9053-834733fc4ee4",
	"00000000-0000-0000-0000-000000000000",
	99,
	5,
	'setup line: 99');
INSERT INTO ACT_REL
	VALUES ("97be3242-4fff-4e85-8bff-c60569ec2683",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"cb0a1d78-e3ba-494c-bf36-e839623af68a",
	'',
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	99,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("71b4b951-688b-44ed-abe0-5a501ca3e0a9",
	0,
	0,
	98,
	50,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c10cd259-8dc6-49c3-9053-834733fc4ee4");
INSERT INTO V_SLR
	VALUES ("71b4b951-688b-44ed-abe0-5a501ca3e0a9",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("f5e39448-cdff-491d-a437-79cec3c65042",
	0,
	0,
	98,
	59,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c10cd259-8dc6-49c3-9053-834733fc4ee4");
INSERT INTO V_AVL
	VALUES ("f5e39448-cdff-491d-a437-79cec3c65042",
	"71b4b951-688b-44ed-abe0-5a501ca3e0a9",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c");
INSERT INTO V_VAL
	VALUES ("bf0c105b-0c82-4c48-933d-573a485fafaa",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c10cd259-8dc6-49c3-9053-834733fc4ee4");
INSERT INTO V_BIN
	VALUES ("bf0c105b-0c82-4c48-933d-573a485fafaa",
	"8fbffe65-22e1-4329-8ff4-e675b065ef76",
	"f5e39448-cdff-491d-a437-79cec3c65042",
	'==');
INSERT INTO V_VAL
	VALUES ("8fbffe65-22e1-4329-8ff4-e675b065ef76",
	0,
	0,
	98,
	69,
	69,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c10cd259-8dc6-49c3-9053-834733fc4ee4");
INSERT INTO V_LIN
	VALUES ("8fbffe65-22e1-4329-8ff4-e675b065ef76",
	'4');
INSERT INTO V_VAR
	VALUES ("cb0a1d78-e3ba-494c-bf36-e839623af68a",
	"c10cd259-8dc6-49c3-9053-834733fc4ee4",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("cb0a1d78-e3ba-494c-bf36-e839623af68a",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("a497f576-9f60-4ea7-b264-05899d4356fc",
	98,
	16,
	18,
	"cb0a1d78-e3ba-494c-bf36-e839623af68a");
INSERT INTO V_LOC
	VALUES ("3fa24457-c150-4d12-9a3e-b48e57dc968c",
	99,
	20,
	22,
	"cb0a1d78-e3ba-494c-bf36-e839623af68a");
INSERT INTO ACT_BLK
	VALUES ("fb600425-78f5-458c-995c-f1a85c247514",
	1,
	0,
	1,
	'',
	'',
	'',
	103,
	5,
	102,
	38,
	0,
	0,
	103,
	31,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5ee30ed1-7c68-470f-a56b-1ab513505382",
	"fb600425-78f5-458c-995c-f1a85c247514",
	"5a624ca3-0a31-4b65-9003-8bb5399fcf02",
	102,
	5,
	'setup line: 102');
INSERT INTO ACT_FIW
	VALUES ("5ee30ed1-7c68-470f-a56b-1ab513505382",
	"bc3aa417-f8bf-4297-8ba0-2b09ca106ed2",
	1,
	'any',
	"57b4f347-f55c-48eb-975b-b00a6102c6b1",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	102,
	38);
INSERT INTO ACT_SMT
	VALUES ("5a624ca3-0a31-4b65-9003-8bb5399fcf02",
	"fb600425-78f5-458c-995c-f1a85c247514",
	"00000000-0000-0000-0000-000000000000",
	103,
	5,
	'setup line: 103');
INSERT INTO ACT_REL
	VALUES ("5a624ca3-0a31-4b65-9003-8bb5399fcf02",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"bc3aa417-f8bf-4297-8ba0-2b09ca106ed2",
	'',
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	103,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("6b5dc82d-4b19-4865-ac46-9959f3924cc1",
	0,
	0,
	102,
	50,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"fb600425-78f5-458c-995c-f1a85c247514");
INSERT INTO V_SLR
	VALUES ("6b5dc82d-4b19-4865-ac46-9959f3924cc1",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("24cf042f-dd09-479d-bfb8-72288ffe6c46",
	0,
	0,
	102,
	59,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"fb600425-78f5-458c-995c-f1a85c247514");
INSERT INTO V_AVL
	VALUES ("24cf042f-dd09-479d-bfb8-72288ffe6c46",
	"6b5dc82d-4b19-4865-ac46-9959f3924cc1",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c");
INSERT INTO V_VAL
	VALUES ("57b4f347-f55c-48eb-975b-b00a6102c6b1",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"fb600425-78f5-458c-995c-f1a85c247514");
INSERT INTO V_BIN
	VALUES ("57b4f347-f55c-48eb-975b-b00a6102c6b1",
	"3f1d3e3f-26c3-4941-8c3f-e09175a65b31",
	"24cf042f-dd09-479d-bfb8-72288ffe6c46",
	'==');
INSERT INTO V_VAL
	VALUES ("3f1d3e3f-26c3-4941-8c3f-e09175a65b31",
	0,
	0,
	102,
	69,
	69,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"fb600425-78f5-458c-995c-f1a85c247514");
INSERT INTO V_LIN
	VALUES ("3f1d3e3f-26c3-4941-8c3f-e09175a65b31",
	'5');
INSERT INTO V_VAR
	VALUES ("bc3aa417-f8bf-4297-8ba0-2b09ca106ed2",
	"fb600425-78f5-458c-995c-f1a85c247514",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("bc3aa417-f8bf-4297-8ba0-2b09ca106ed2",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("8eb93be8-57f2-47a1-b7cc-05596caf95a9",
	102,
	16,
	18,
	"bc3aa417-f8bf-4297-8ba0-2b09ca106ed2");
INSERT INTO V_LOC
	VALUES ("41148dd2-5236-41b0-84a0-28a894e81b0a",
	103,
	20,
	22,
	"bc3aa417-f8bf-4297-8ba0-2b09ca106ed2");
INSERT INTO ACT_BLK
	VALUES ("3077da32-e8a9-416e-baba-ee1712aac53e",
	1,
	0,
	1,
	'',
	'',
	'',
	107,
	5,
	106,
	38,
	0,
	0,
	107,
	31,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("cbeeff65-56e8-4856-803c-82db90a9c3f6",
	"3077da32-e8a9-416e-baba-ee1712aac53e",
	"066e0bfc-02ad-454d-9ad5-1f427eb7e8d5",
	106,
	5,
	'setup line: 106');
INSERT INTO ACT_FIW
	VALUES ("cbeeff65-56e8-4856-803c-82db90a9c3f6",
	"a0e28315-c6e3-41f0-b109-f3ff1f01cd17",
	1,
	'any',
	"4c5707bd-81af-4f3f-a08c-1dc8d8b50667",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	106,
	38);
INSERT INTO ACT_SMT
	VALUES ("066e0bfc-02ad-454d-9ad5-1f427eb7e8d5",
	"3077da32-e8a9-416e-baba-ee1712aac53e",
	"00000000-0000-0000-0000-000000000000",
	107,
	5,
	'setup line: 107');
INSERT INTO ACT_REL
	VALUES ("066e0bfc-02ad-454d-9ad5-1f427eb7e8d5",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"a0e28315-c6e3-41f0-b109-f3ff1f01cd17",
	'',
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	107,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("fa6b0758-308c-4a67-8269-6d97d1e770b3",
	0,
	0,
	106,
	50,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3077da32-e8a9-416e-baba-ee1712aac53e");
INSERT INTO V_SLR
	VALUES ("fa6b0758-308c-4a67-8269-6d97d1e770b3",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("f7ff7b42-bdc6-4620-a122-b47d8890f625",
	0,
	0,
	106,
	59,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3077da32-e8a9-416e-baba-ee1712aac53e");
INSERT INTO V_AVL
	VALUES ("f7ff7b42-bdc6-4620-a122-b47d8890f625",
	"fa6b0758-308c-4a67-8269-6d97d1e770b3",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c");
INSERT INTO V_VAL
	VALUES ("4c5707bd-81af-4f3f-a08c-1dc8d8b50667",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"3077da32-e8a9-416e-baba-ee1712aac53e");
INSERT INTO V_BIN
	VALUES ("4c5707bd-81af-4f3f-a08c-1dc8d8b50667",
	"87e1d649-c28a-4b93-ab1c-18079801afb4",
	"f7ff7b42-bdc6-4620-a122-b47d8890f625",
	'==');
INSERT INTO V_VAL
	VALUES ("87e1d649-c28a-4b93-ab1c-18079801afb4",
	0,
	0,
	106,
	69,
	69,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3077da32-e8a9-416e-baba-ee1712aac53e");
INSERT INTO V_LIN
	VALUES ("87e1d649-c28a-4b93-ab1c-18079801afb4",
	'6');
INSERT INTO V_VAR
	VALUES ("a0e28315-c6e3-41f0-b109-f3ff1f01cd17",
	"3077da32-e8a9-416e-baba-ee1712aac53e",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("a0e28315-c6e3-41f0-b109-f3ff1f01cd17",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("486d0722-f61e-406a-af28-68e07e41f97a",
	106,
	16,
	18,
	"a0e28315-c6e3-41f0-b109-f3ff1f01cd17");
INSERT INTO V_LOC
	VALUES ("5ae3e6b2-527b-4e50-8f0d-fc5952dbb433",
	107,
	20,
	22,
	"a0e28315-c6e3-41f0-b109-f3ff1f01cd17");
INSERT INTO ACT_BLK
	VALUES ("3cc83580-3985-463e-b07e-457458daf4ba",
	1,
	0,
	1,
	'',
	'',
	'',
	111,
	5,
	110,
	38,
	0,
	0,
	111,
	31,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("82dd856d-5f6d-47b2-8e66-80bba14d2d7e",
	"3cc83580-3985-463e-b07e-457458daf4ba",
	"6703cb34-7662-451f-9340-9a65bd9a6f15",
	110,
	5,
	'setup line: 110');
INSERT INTO ACT_FIW
	VALUES ("82dd856d-5f6d-47b2-8e66-80bba14d2d7e",
	"4f213bc1-8e4c-4cd1-b96f-5c75627e4778",
	1,
	'any',
	"accedfbe-6ea6-4210-905e-6ca14dcae0d5",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	110,
	38);
INSERT INTO ACT_SMT
	VALUES ("6703cb34-7662-451f-9340-9a65bd9a6f15",
	"3cc83580-3985-463e-b07e-457458daf4ba",
	"00000000-0000-0000-0000-000000000000",
	111,
	5,
	'setup line: 111');
INSERT INTO ACT_REL
	VALUES ("6703cb34-7662-451f-9340-9a65bd9a6f15",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"4f213bc1-8e4c-4cd1-b96f-5c75627e4778",
	'',
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	111,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("2b78de30-b187-44ea-b843-f44289f079c3",
	0,
	0,
	110,
	50,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3cc83580-3985-463e-b07e-457458daf4ba");
INSERT INTO V_SLR
	VALUES ("2b78de30-b187-44ea-b843-f44289f079c3",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("d3eab4a3-2fc8-4564-abda-5dc28402bff0",
	0,
	0,
	110,
	59,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3cc83580-3985-463e-b07e-457458daf4ba");
INSERT INTO V_AVL
	VALUES ("d3eab4a3-2fc8-4564-abda-5dc28402bff0",
	"2b78de30-b187-44ea-b843-f44289f079c3",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c");
INSERT INTO V_VAL
	VALUES ("accedfbe-6ea6-4210-905e-6ca14dcae0d5",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"3cc83580-3985-463e-b07e-457458daf4ba");
INSERT INTO V_BIN
	VALUES ("accedfbe-6ea6-4210-905e-6ca14dcae0d5",
	"4275fecb-94e7-438c-931d-b2473126443f",
	"d3eab4a3-2fc8-4564-abda-5dc28402bff0",
	'==');
INSERT INTO V_VAL
	VALUES ("4275fecb-94e7-438c-931d-b2473126443f",
	0,
	0,
	110,
	69,
	69,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3cc83580-3985-463e-b07e-457458daf4ba");
INSERT INTO V_LIN
	VALUES ("4275fecb-94e7-438c-931d-b2473126443f",
	'7');
INSERT INTO V_VAR
	VALUES ("4f213bc1-8e4c-4cd1-b96f-5c75627e4778",
	"3cc83580-3985-463e-b07e-457458daf4ba",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("4f213bc1-8e4c-4cd1-b96f-5c75627e4778",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("3301fdf1-0cce-4029-92a9-02dcc2610b8c",
	110,
	16,
	18,
	"4f213bc1-8e4c-4cd1-b96f-5c75627e4778");
INSERT INTO V_LOC
	VALUES ("ca719d6c-135f-4ef8-98b8-501afc329220",
	111,
	20,
	22,
	"4f213bc1-8e4c-4cd1-b96f-5c75627e4778");
INSERT INTO ACT_BLK
	VALUES ("5107610a-0416-44a7-b132-349affa58cfb",
	1,
	0,
	1,
	'',
	'',
	'',
	115,
	5,
	114,
	38,
	0,
	0,
	115,
	31,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1c9ebd18-2067-491f-ad9c-07be54b98f23",
	"5107610a-0416-44a7-b132-349affa58cfb",
	"2d38d47c-57b6-4a93-a280-d970382fc69b",
	114,
	5,
	'setup line: 114');
INSERT INTO ACT_FIW
	VALUES ("1c9ebd18-2067-491f-ad9c-07be54b98f23",
	"9bfd3563-f867-4125-9cc0-f22700128c7d",
	1,
	'any',
	"fa8223b4-f37f-4858-97e4-cf3cdadec8dd",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	114,
	38);
INSERT INTO ACT_SMT
	VALUES ("2d38d47c-57b6-4a93-a280-d970382fc69b",
	"5107610a-0416-44a7-b132-349affa58cfb",
	"00000000-0000-0000-0000-000000000000",
	115,
	5,
	'setup line: 115');
INSERT INTO ACT_REL
	VALUES ("2d38d47c-57b6-4a93-a280-d970382fc69b",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"9bfd3563-f867-4125-9cc0-f22700128c7d",
	'',
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	115,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("29b16490-a0fc-41cc-8229-4d8d1b8ad5e4",
	0,
	0,
	114,
	50,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"5107610a-0416-44a7-b132-349affa58cfb");
INSERT INTO V_SLR
	VALUES ("29b16490-a0fc-41cc-8229-4d8d1b8ad5e4",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("7bb0f3ae-46ee-4385-a1d8-c484e8b3ab57",
	0,
	0,
	114,
	59,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5107610a-0416-44a7-b132-349affa58cfb");
INSERT INTO V_AVL
	VALUES ("7bb0f3ae-46ee-4385-a1d8-c484e8b3ab57",
	"29b16490-a0fc-41cc-8229-4d8d1b8ad5e4",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c");
INSERT INTO V_VAL
	VALUES ("fa8223b4-f37f-4858-97e4-cf3cdadec8dd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"5107610a-0416-44a7-b132-349affa58cfb");
INSERT INTO V_BIN
	VALUES ("fa8223b4-f37f-4858-97e4-cf3cdadec8dd",
	"69ab48d8-b4f0-464e-b906-55187078f12a",
	"7bb0f3ae-46ee-4385-a1d8-c484e8b3ab57",
	'==');
INSERT INTO V_VAL
	VALUES ("69ab48d8-b4f0-464e-b906-55187078f12a",
	0,
	0,
	114,
	69,
	69,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5107610a-0416-44a7-b132-349affa58cfb");
INSERT INTO V_LIN
	VALUES ("69ab48d8-b4f0-464e-b906-55187078f12a",
	'8');
INSERT INTO V_VAR
	VALUES ("9bfd3563-f867-4125-9cc0-f22700128c7d",
	"5107610a-0416-44a7-b132-349affa58cfb",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("9bfd3563-f867-4125-9cc0-f22700128c7d",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("4204db86-e01f-45a9-850a-500f1a4a7105",
	114,
	16,
	18,
	"9bfd3563-f867-4125-9cc0-f22700128c7d");
INSERT INTO V_LOC
	VALUES ("a61c4fe9-dc49-451d-9425-949f15395306",
	115,
	20,
	22,
	"9bfd3563-f867-4125-9cc0-f22700128c7d");
INSERT INTO ACT_BLK
	VALUES ("84d318d0-3290-42ee-94fc-0ca82a809368",
	1,
	0,
	1,
	'',
	'',
	'',
	119,
	5,
	118,
	38,
	0,
	0,
	119,
	31,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0421e5d3-7087-41a9-9416-8a7dafe7b50f",
	"84d318d0-3290-42ee-94fc-0ca82a809368",
	"bf64bd83-32c1-4dad-851a-07c52a688f0d",
	118,
	5,
	'setup line: 118');
INSERT INTO ACT_FIW
	VALUES ("0421e5d3-7087-41a9-9416-8a7dafe7b50f",
	"0bd77568-5375-4082-b9cb-0d1fe672f599",
	1,
	'any',
	"1fec25dd-7d77-4984-aaab-4c96f1e41c4f",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	118,
	38);
INSERT INTO ACT_SMT
	VALUES ("bf64bd83-32c1-4dad-851a-07c52a688f0d",
	"84d318d0-3290-42ee-94fc-0ca82a809368",
	"00000000-0000-0000-0000-000000000000",
	119,
	5,
	'setup line: 119');
INSERT INTO ACT_REL
	VALUES ("bf64bd83-32c1-4dad-851a-07c52a688f0d",
	"c3fc219a-bc14-4148-a4ca-0ee7491baf81",
	"0bd77568-5375-4082-b9cb-0d1fe672f599",
	'',
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	119,
	31,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("3f51c46b-8372-4efb-aa4c-f58f9d184af0",
	0,
	0,
	118,
	50,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"84d318d0-3290-42ee-94fc-0ca82a809368");
INSERT INTO V_SLR
	VALUES ("3f51c46b-8372-4efb-aa4c-f58f9d184af0",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("299156f5-df65-4a97-a69a-10e46560da4d",
	0,
	0,
	118,
	59,
	64,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"84d318d0-3290-42ee-94fc-0ca82a809368");
INSERT INTO V_AVL
	VALUES ("299156f5-df65-4a97-a69a-10e46560da4d",
	"3f51c46b-8372-4efb-aa4c-f58f9d184af0",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c");
INSERT INTO V_VAL
	VALUES ("1fec25dd-7d77-4984-aaab-4c96f1e41c4f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"84d318d0-3290-42ee-94fc-0ca82a809368");
INSERT INTO V_BIN
	VALUES ("1fec25dd-7d77-4984-aaab-4c96f1e41c4f",
	"e9ed1cc6-1241-4fe3-b96f-bb6887462006",
	"299156f5-df65-4a97-a69a-10e46560da4d",
	'==');
INSERT INTO V_VAL
	VALUES ("e9ed1cc6-1241-4fe3-b96f-bb6887462006",
	0,
	0,
	118,
	69,
	69,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"84d318d0-3290-42ee-94fc-0ca82a809368");
INSERT INTO V_LIN
	VALUES ("e9ed1cc6-1241-4fe3-b96f-bb6887462006",
	'9');
INSERT INTO V_VAR
	VALUES ("0bd77568-5375-4082-b9cb-0d1fe672f599",
	"84d318d0-3290-42ee-94fc-0ca82a809368",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("0bd77568-5375-4082-b9cb-0d1fe672f599",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("8fe3040d-2534-4dfd-935c-9972be860cce",
	118,
	16,
	18,
	"0bd77568-5375-4082-b9cb-0d1fe672f599");
INSERT INTO V_LOC
	VALUES ("039cf921-5a81-4df2-b488-c4f29ee537be",
	119,
	20,
	22,
	"0bd77568-5375-4082-b9cb-0d1fe672f599");
INSERT INTO ACT_BLK
	VALUES ("8d023eb4-b13c-4eaa-90b7-d26e92e23673",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	124,
	3,
	124,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4006b4ca-1af1-4cd0-a397-268126bbf0dd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("13c9f095-1c40-41c1-b479-29925874637f",
	"8d023eb4-b13c-4eaa-90b7-d26e92e23673",
	"00000000-0000-0000-0000-000000000000",
	124,
	3,
	'setup line: 124');
INSERT INTO ACT_BRG
	VALUES ("13c9f095-1c40-41c1-b479-29925874637f",
	"fcecd865-72da-4176-a9bd-ae415b51a1ff",
	124,
	8,
	124,
	3);
INSERT INTO V_VAL
	VALUES ("af390225-4007-4c2c-874d-2267c3797ed3",
	0,
	0,
	124,
	25,
	40,
	0,
	0,
	0,
	0,
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	"8d023eb4-b13c-4eaa-90b7-d26e92e23673");
INSERT INTO V_LST
	VALUES ("af390225-4007-4c2c-874d-2267c3797ed3",
	'PEI data found.');
INSERT INTO V_PAR
	VALUES ("af390225-4007-4c2c-874d-2267c3797ed3",
	"13c9f095-1c40-41c1-b479-29925874637f",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	124,
	17);
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"19dc62f9-2b6f-4bd6-a881-638d8a495a0a");
INSERT INTO S_SYNC
	VALUES ("19dc62f9-2b6f-4bd6-a881-638d8a495a0a",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'setz1_given',
	'',
	'

CELL::set_given( row:1, column:3, answer:9 );
CELL::set_given( row:1, column:4, answer:3 );
CELL::set_given( row:1, column:9, answer:5 );

CELL::set_given( row:2, column:4, answer:5 );
CELL::set_given( row:2, column:5, answer:1 );
CELL::set_given( row:2, column:6, answer:4 );
CELL::set_given( row:2, column:8, answer:7 );

CELL::set_given( row:3, column:1, answer:1 );
CELL::set_given( row:3, column:2, answer:5 );
CELL::set_given( row:3, column:3, answer:6 );
CELL::set_given( row:3, column:8, answer:8 );

CELL::set_given( row:4, column:1, answer:9 );
CELL::set_given( row:4, column:5, answer:8 );
CELL::set_given( row:4, column:9, answer:1 );

CELL::set_given( row:5, column:1, answer:7 );
CELL::set_given( row:5, column:4, answer:9 );
CELL::set_given( row:5, column:6, answer:5 );
CELL::set_given( row:5, column:9, answer:2 );

CELL::set_given( row:6, column:1, answer:5 );
CELL::set_given( row:6, column:5, answer:3 );
CELL::set_given( row:6, column:9, answer:9 );

CELL::set_given( row:7, column:2, answer:2 );
CELL::set_given( row:7, column:7, answer:4 );
CELL::set_given( row:7, column:8, answer:1 );
CELL::set_given( row:7, column:9, answer:7 );

CELL::set_given( row:8, column:2, answer:4 );
CELL::set_given( row:8, column:4, answer:1 );
CELL::set_given( row:8, column:5, answer:5 );
CELL::set_given( row:8, column:6, answer:6 );

CELL::set_given( row:9, column:1, answer:3 );
CELL::set_given( row:9, column:6, answer:7 );
CELL::set_given( row:9, column:7, answer:5 );

',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("3136100c-9d52-4557-bf99-f148d0a3442d",
	"19dc62f9-2b6f-4bd6-a881-638d8a495a0a");
INSERT INTO ACT_ACT
	VALUES ("3136100c-9d52-4557-bf99-f148d0a3442d",
	'function',
	0,
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setz1_given',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	42,
	1,
	42,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"3136100c-9d52-4557-bf99-f148d0a3442d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d57c65bc-851d-42bf-bbca-a6367add2c16",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"191929b9-f1bd-4f03-800d-76e88a067a18",
	3,
	1,
	'setz1_given line: 3');
INSERT INTO ACT_TFM
	VALUES ("d57c65bc-851d-42bf-bbca-a6367add2c16",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES ("191929b9-f1bd-4f03-800d-76e88a067a18",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"160e7b0e-63d0-4a54-9791-49fe21cbeb54",
	4,
	1,
	'setz1_given line: 4');
INSERT INTO ACT_TFM
	VALUES ("191929b9-f1bd-4f03-800d-76e88a067a18",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES ("160e7b0e-63d0-4a54-9791-49fe21cbeb54",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"fe824ab1-220b-499f-ab0f-cdc4e407ad47",
	5,
	1,
	'setz1_given line: 5');
INSERT INTO ACT_TFM
	VALUES ("160e7b0e-63d0-4a54-9791-49fe21cbeb54",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	5,
	7,
	5,
	1);
INSERT INTO ACT_SMT
	VALUES ("fe824ab1-220b-499f-ab0f-cdc4e407ad47",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"96d2103d-977b-4f7b-b70d-9d78a6f4461d",
	7,
	1,
	'setz1_given line: 7');
INSERT INTO ACT_TFM
	VALUES ("fe824ab1-220b-499f-ab0f-cdc4e407ad47",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES ("96d2103d-977b-4f7b-b70d-9d78a6f4461d",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"503ab559-13cc-47ec-bd1d-9da237d00daf",
	8,
	1,
	'setz1_given line: 8');
INSERT INTO ACT_TFM
	VALUES ("96d2103d-977b-4f7b-b70d-9d78a6f4461d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES ("503ab559-13cc-47ec-bd1d-9da237d00daf",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"4fd59b4e-bd62-4595-890d-19eedd745f51",
	9,
	1,
	'setz1_given line: 9');
INSERT INTO ACT_TFM
	VALUES ("503ab559-13cc-47ec-bd1d-9da237d00daf",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	9,
	7,
	9,
	1);
INSERT INTO ACT_SMT
	VALUES ("4fd59b4e-bd62-4595-890d-19eedd745f51",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"b44f84d0-3308-47c9-9a78-68c0c55515b5",
	10,
	1,
	'setz1_given line: 10');
INSERT INTO ACT_TFM
	VALUES ("4fd59b4e-bd62-4595-890d-19eedd745f51",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES ("b44f84d0-3308-47c9-9a78-68c0c55515b5",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"5238bb9e-f999-4722-a2fc-f0a198d7100d",
	12,
	1,
	'setz1_given line: 12');
INSERT INTO ACT_TFM
	VALUES ("b44f84d0-3308-47c9-9a78-68c0c55515b5",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES ("5238bb9e-f999-4722-a2fc-f0a198d7100d",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"ef6e89e7-3698-41a5-9d7e-07f2ce794e9d",
	13,
	1,
	'setz1_given line: 13');
INSERT INTO ACT_TFM
	VALUES ("5238bb9e-f999-4722-a2fc-f0a198d7100d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	13,
	7,
	13,
	1);
INSERT INTO ACT_SMT
	VALUES ("ef6e89e7-3698-41a5-9d7e-07f2ce794e9d",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"ab4110fd-a4e4-4696-9ed9-b59f479e3333",
	14,
	1,
	'setz1_given line: 14');
INSERT INTO ACT_TFM
	VALUES ("ef6e89e7-3698-41a5-9d7e-07f2ce794e9d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	14,
	7,
	14,
	1);
INSERT INTO ACT_SMT
	VALUES ("ab4110fd-a4e4-4696-9ed9-b59f479e3333",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"cd394ccc-e9ba-4212-a50f-d7f234c0f0fc",
	15,
	1,
	'setz1_given line: 15');
INSERT INTO ACT_TFM
	VALUES ("ab4110fd-a4e4-4696-9ed9-b59f479e3333",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES ("cd394ccc-e9ba-4212-a50f-d7f234c0f0fc",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"90e980e3-6d1e-43a5-86b7-85099667b30f",
	17,
	1,
	'setz1_given line: 17');
INSERT INTO ACT_TFM
	VALUES ("cd394ccc-e9ba-4212-a50f-d7f234c0f0fc",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES ("90e980e3-6d1e-43a5-86b7-85099667b30f",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"869ac889-843c-4f6b-9ebd-428da3d37498",
	18,
	1,
	'setz1_given line: 18');
INSERT INTO ACT_TFM
	VALUES ("90e980e3-6d1e-43a5-86b7-85099667b30f",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	18,
	7,
	18,
	1);
INSERT INTO ACT_SMT
	VALUES ("869ac889-843c-4f6b-9ebd-428da3d37498",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"b9c2ddb8-4ac8-4d14-8cc6-ff9796f5f9a9",
	19,
	1,
	'setz1_given line: 19');
INSERT INTO ACT_TFM
	VALUES ("869ac889-843c-4f6b-9ebd-428da3d37498",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	19,
	7,
	19,
	1);
INSERT INTO ACT_SMT
	VALUES ("b9c2ddb8-4ac8-4d14-8cc6-ff9796f5f9a9",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"7bcd4960-48d1-4517-a1ce-f91bf241078b",
	21,
	1,
	'setz1_given line: 21');
INSERT INTO ACT_TFM
	VALUES ("b9c2ddb8-4ac8-4d14-8cc6-ff9796f5f9a9",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	21,
	7,
	21,
	1);
INSERT INTO ACT_SMT
	VALUES ("7bcd4960-48d1-4517-a1ce-f91bf241078b",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"0da5b4f3-bc74-400e-a8f4-27fbee9b0052",
	22,
	1,
	'setz1_given line: 22');
INSERT INTO ACT_TFM
	VALUES ("7bcd4960-48d1-4517-a1ce-f91bf241078b",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	22,
	7,
	22,
	1);
INSERT INTO ACT_SMT
	VALUES ("0da5b4f3-bc74-400e-a8f4-27fbee9b0052",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"19a886d5-e9fc-455e-8187-0756305c8e6a",
	23,
	1,
	'setz1_given line: 23');
INSERT INTO ACT_TFM
	VALUES ("0da5b4f3-bc74-400e-a8f4-27fbee9b0052",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES ("19a886d5-e9fc-455e-8187-0756305c8e6a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"35cb8458-bfdc-4f13-929b-25b1393f5768",
	24,
	1,
	'setz1_given line: 24');
INSERT INTO ACT_TFM
	VALUES ("19a886d5-e9fc-455e-8187-0756305c8e6a",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES ("35cb8458-bfdc-4f13-929b-25b1393f5768",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"1eba5889-9061-4b6a-8102-125e61d46a2a",
	26,
	1,
	'setz1_given line: 26');
INSERT INTO ACT_TFM
	VALUES ("35cb8458-bfdc-4f13-929b-25b1393f5768",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	26,
	7,
	26,
	1);
INSERT INTO ACT_SMT
	VALUES ("1eba5889-9061-4b6a-8102-125e61d46a2a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"a3162472-5567-4866-a462-b8d9568570be",
	27,
	1,
	'setz1_given line: 27');
INSERT INTO ACT_TFM
	VALUES ("1eba5889-9061-4b6a-8102-125e61d46a2a",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	27,
	7,
	27,
	1);
INSERT INTO ACT_SMT
	VALUES ("a3162472-5567-4866-a462-b8d9568570be",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"0ad3d1f4-3354-4784-ba11-f1466cf98e25",
	28,
	1,
	'setz1_given line: 28');
INSERT INTO ACT_TFM
	VALUES ("a3162472-5567-4866-a462-b8d9568570be",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	28,
	7,
	28,
	1);
INSERT INTO ACT_SMT
	VALUES ("0ad3d1f4-3354-4784-ba11-f1466cf98e25",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"8e6aa81c-b75b-4d40-a215-83c0acaaa313",
	30,
	1,
	'setz1_given line: 30');
INSERT INTO ACT_TFM
	VALUES ("0ad3d1f4-3354-4784-ba11-f1466cf98e25",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	30,
	7,
	30,
	1);
INSERT INTO ACT_SMT
	VALUES ("8e6aa81c-b75b-4d40-a215-83c0acaaa313",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"0df80a29-476b-495b-8b27-277c0a65f18d",
	31,
	1,
	'setz1_given line: 31');
INSERT INTO ACT_TFM
	VALUES ("8e6aa81c-b75b-4d40-a215-83c0acaaa313",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES ("0df80a29-476b-495b-8b27-277c0a65f18d",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"138b117f-6335-4850-baba-667fa3b204ee",
	32,
	1,
	'setz1_given line: 32');
INSERT INTO ACT_TFM
	VALUES ("0df80a29-476b-495b-8b27-277c0a65f18d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES ("138b117f-6335-4850-baba-667fa3b204ee",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"21ea079b-eef7-485a-b26b-9dbbdabac63b",
	33,
	1,
	'setz1_given line: 33');
INSERT INTO ACT_TFM
	VALUES ("138b117f-6335-4850-baba-667fa3b204ee",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES ("21ea079b-eef7-485a-b26b-9dbbdabac63b",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"e08b6578-ea3b-42ec-a700-21672539977c",
	35,
	1,
	'setz1_given line: 35');
INSERT INTO ACT_TFM
	VALUES ("21ea079b-eef7-485a-b26b-9dbbdabac63b",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	35,
	7,
	35,
	1);
INSERT INTO ACT_SMT
	VALUES ("e08b6578-ea3b-42ec-a700-21672539977c",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"c25063a2-7d1f-4365-a145-8079692e689c",
	36,
	1,
	'setz1_given line: 36');
INSERT INTO ACT_TFM
	VALUES ("e08b6578-ea3b-42ec-a700-21672539977c",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES ("c25063a2-7d1f-4365-a145-8079692e689c",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"0df290ad-2783-485e-86ac-efec4b398bea",
	37,
	1,
	'setz1_given line: 37');
INSERT INTO ACT_TFM
	VALUES ("c25063a2-7d1f-4365-a145-8079692e689c",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	37,
	7,
	37,
	1);
INSERT INTO ACT_SMT
	VALUES ("0df290ad-2783-485e-86ac-efec4b398bea",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"c96a2156-bb7c-4011-9519-1d694a5ccb0a",
	38,
	1,
	'setz1_given line: 38');
INSERT INTO ACT_TFM
	VALUES ("0df290ad-2783-485e-86ac-efec4b398bea",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	38,
	7,
	38,
	1);
INSERT INTO ACT_SMT
	VALUES ("c96a2156-bb7c-4011-9519-1d694a5ccb0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"84d23973-bc1d-4621-a967-12438ac8b89f",
	40,
	1,
	'setz1_given line: 40');
INSERT INTO ACT_TFM
	VALUES ("c96a2156-bb7c-4011-9519-1d694a5ccb0a",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	40,
	7,
	40,
	1);
INSERT INTO ACT_SMT
	VALUES ("84d23973-bc1d-4621-a967-12438ac8b89f",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"0ad9cd02-4822-497d-94a2-3127d9d2df12",
	41,
	1,
	'setz1_given line: 41');
INSERT INTO ACT_TFM
	VALUES ("84d23973-bc1d-4621-a967-12438ac8b89f",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	41,
	7,
	41,
	1);
INSERT INTO ACT_SMT
	VALUES ("0ad9cd02-4822-497d-94a2-3127d9d2df12",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019",
	"00000000-0000-0000-0000-000000000000",
	42,
	1,
	'setz1_given line: 42');
INSERT INTO ACT_TFM
	VALUES ("0ad9cd02-4822-497d-94a2-3127d9d2df12",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	42,
	7,
	42,
	1);
INSERT INTO V_VAL
	VALUES ("a4591ace-0329-422b-aa52-11eb476c42ce",
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("a4591ace-0329-422b-aa52-11eb476c42ce",
	'1');
INSERT INTO V_PAR
	VALUES ("a4591ace-0329-422b-aa52-11eb476c42ce",
	"d57c65bc-851d-42bf-bbca-a6367add2c16",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"76d43666-3040-4e07-9653-3f302fcc61b1",
	3,
	18);
INSERT INTO V_VAL
	VALUES ("76d43666-3040-4e07-9653-3f302fcc61b1",
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("76d43666-3040-4e07-9653-3f302fcc61b1",
	'3');
INSERT INTO V_PAR
	VALUES ("76d43666-3040-4e07-9653-3f302fcc61b1",
	"d57c65bc-851d-42bf-bbca-a6367add2c16",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"00674440-e6c0-45e6-8850-b698cc1893ab",
	3,
	25);
INSERT INTO V_VAL
	VALUES ("00674440-e6c0-45e6-8850-b698cc1893ab",
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("00674440-e6c0-45e6-8850-b698cc1893ab",
	'9');
INSERT INTO V_PAR
	VALUES ("00674440-e6c0-45e6-8850-b698cc1893ab",
	"d57c65bc-851d-42bf-bbca-a6367add2c16",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	3,
	35);
INSERT INTO V_VAL
	VALUES ("7dfe9cd7-ff4e-4d9a-829d-308850fa7899",
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("7dfe9cd7-ff4e-4d9a-829d-308850fa7899",
	'1');
INSERT INTO V_PAR
	VALUES ("7dfe9cd7-ff4e-4d9a-829d-308850fa7899",
	"191929b9-f1bd-4f03-800d-76e88a067a18",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"cf9b7a49-252c-4ddb-9444-ee8bbded8673",
	4,
	18);
INSERT INTO V_VAL
	VALUES ("cf9b7a49-252c-4ddb-9444-ee8bbded8673",
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("cf9b7a49-252c-4ddb-9444-ee8bbded8673",
	'4');
INSERT INTO V_PAR
	VALUES ("cf9b7a49-252c-4ddb-9444-ee8bbded8673",
	"191929b9-f1bd-4f03-800d-76e88a067a18",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8a048675-ca27-48b0-acbc-923ea04e8792",
	4,
	25);
INSERT INTO V_VAL
	VALUES ("8a048675-ca27-48b0-acbc-923ea04e8792",
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("8a048675-ca27-48b0-acbc-923ea04e8792",
	'3');
INSERT INTO V_PAR
	VALUES ("8a048675-ca27-48b0-acbc-923ea04e8792",
	"191929b9-f1bd-4f03-800d-76e88a067a18",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	4,
	35);
INSERT INTO V_VAL
	VALUES ("3e405324-9bb7-459d-9113-d2bcdfee1592",
	0,
	0,
	5,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("3e405324-9bb7-459d-9113-d2bcdfee1592",
	'1');
INSERT INTO V_PAR
	VALUES ("3e405324-9bb7-459d-9113-d2bcdfee1592",
	"160e7b0e-63d0-4a54-9791-49fe21cbeb54",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"26a49eb1-ef2b-4385-b070-431bcf179807",
	5,
	18);
INSERT INTO V_VAL
	VALUES ("26a49eb1-ef2b-4385-b070-431bcf179807",
	0,
	0,
	5,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("26a49eb1-ef2b-4385-b070-431bcf179807",
	'9');
INSERT INTO V_PAR
	VALUES ("26a49eb1-ef2b-4385-b070-431bcf179807",
	"160e7b0e-63d0-4a54-9791-49fe21cbeb54",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"d103bbd3-b12c-4ceb-80ae-3c4bc7f2b2b0",
	5,
	25);
INSERT INTO V_VAL
	VALUES ("d103bbd3-b12c-4ceb-80ae-3c4bc7f2b2b0",
	0,
	0,
	5,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("d103bbd3-b12c-4ceb-80ae-3c4bc7f2b2b0",
	'5');
INSERT INTO V_PAR
	VALUES ("d103bbd3-b12c-4ceb-80ae-3c4bc7f2b2b0",
	"160e7b0e-63d0-4a54-9791-49fe21cbeb54",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	5,
	35);
INSERT INTO V_VAL
	VALUES ("d6845088-53bf-4ea5-bf9a-6e14479a5367",
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("d6845088-53bf-4ea5-bf9a-6e14479a5367",
	'2');
INSERT INTO V_PAR
	VALUES ("d6845088-53bf-4ea5-bf9a-6e14479a5367",
	"fe824ab1-220b-499f-ab0f-cdc4e407ad47",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"58ec8628-705c-4000-be48-8f3f7f99b686",
	7,
	18);
INSERT INTO V_VAL
	VALUES ("58ec8628-705c-4000-be48-8f3f7f99b686",
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("58ec8628-705c-4000-be48-8f3f7f99b686",
	'4');
INSERT INTO V_PAR
	VALUES ("58ec8628-705c-4000-be48-8f3f7f99b686",
	"fe824ab1-220b-499f-ab0f-cdc4e407ad47",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"c244a5d6-09e6-4816-8030-598c9e45bdc0",
	7,
	25);
INSERT INTO V_VAL
	VALUES ("c244a5d6-09e6-4816-8030-598c9e45bdc0",
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("c244a5d6-09e6-4816-8030-598c9e45bdc0",
	'5');
INSERT INTO V_PAR
	VALUES ("c244a5d6-09e6-4816-8030-598c9e45bdc0",
	"fe824ab1-220b-499f-ab0f-cdc4e407ad47",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	7,
	35);
INSERT INTO V_VAL
	VALUES ("6dfa9089-91c1-43cd-9f45-d4b9a39e79fd",
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("6dfa9089-91c1-43cd-9f45-d4b9a39e79fd",
	'2');
INSERT INTO V_PAR
	VALUES ("6dfa9089-91c1-43cd-9f45-d4b9a39e79fd",
	"96d2103d-977b-4f7b-b70d-9d78a6f4461d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"0ebe11b9-75f8-4933-a1ac-c03f0304c0b5",
	8,
	18);
INSERT INTO V_VAL
	VALUES ("0ebe11b9-75f8-4933-a1ac-c03f0304c0b5",
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("0ebe11b9-75f8-4933-a1ac-c03f0304c0b5",
	'5');
INSERT INTO V_PAR
	VALUES ("0ebe11b9-75f8-4933-a1ac-c03f0304c0b5",
	"96d2103d-977b-4f7b-b70d-9d78a6f4461d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"9200943d-2910-45e3-b4ac-2f0ed48403c2",
	8,
	25);
INSERT INTO V_VAL
	VALUES ("9200943d-2910-45e3-b4ac-2f0ed48403c2",
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("9200943d-2910-45e3-b4ac-2f0ed48403c2",
	'1');
INSERT INTO V_PAR
	VALUES ("9200943d-2910-45e3-b4ac-2f0ed48403c2",
	"96d2103d-977b-4f7b-b70d-9d78a6f4461d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	8,
	35);
INSERT INTO V_VAL
	VALUES ("d3d5bd48-f7c6-4f55-98d6-ad23d4486a83",
	0,
	0,
	9,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("d3d5bd48-f7c6-4f55-98d6-ad23d4486a83",
	'2');
INSERT INTO V_PAR
	VALUES ("d3d5bd48-f7c6-4f55-98d6-ad23d4486a83",
	"503ab559-13cc-47ec-bd1d-9da237d00daf",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"a1c5a847-b5e7-4380-95cd-fa60cf0fceba",
	9,
	18);
INSERT INTO V_VAL
	VALUES ("a1c5a847-b5e7-4380-95cd-fa60cf0fceba",
	0,
	0,
	9,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("a1c5a847-b5e7-4380-95cd-fa60cf0fceba",
	'6');
INSERT INTO V_PAR
	VALUES ("a1c5a847-b5e7-4380-95cd-fa60cf0fceba",
	"503ab559-13cc-47ec-bd1d-9da237d00daf",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"bdb9b0b6-0753-44f9-8d4a-5d0c13541ffc",
	9,
	25);
INSERT INTO V_VAL
	VALUES ("bdb9b0b6-0753-44f9-8d4a-5d0c13541ffc",
	0,
	0,
	9,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("bdb9b0b6-0753-44f9-8d4a-5d0c13541ffc",
	'4');
INSERT INTO V_PAR
	VALUES ("bdb9b0b6-0753-44f9-8d4a-5d0c13541ffc",
	"503ab559-13cc-47ec-bd1d-9da237d00daf",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	9,
	35);
INSERT INTO V_VAL
	VALUES ("bf5690bd-d643-47e2-9e70-fb77c383016e",
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("bf5690bd-d643-47e2-9e70-fb77c383016e",
	'2');
INSERT INTO V_PAR
	VALUES ("bf5690bd-d643-47e2-9e70-fb77c383016e",
	"4fd59b4e-bd62-4595-890d-19eedd745f51",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"198c30be-0c70-4825-bfa3-6093b1007cdd",
	10,
	18);
INSERT INTO V_VAL
	VALUES ("198c30be-0c70-4825-bfa3-6093b1007cdd",
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("198c30be-0c70-4825-bfa3-6093b1007cdd",
	'8');
INSERT INTO V_PAR
	VALUES ("198c30be-0c70-4825-bfa3-6093b1007cdd",
	"4fd59b4e-bd62-4595-890d-19eedd745f51",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"1c0118ac-9b3c-4cff-95bc-43c9ea333c67",
	10,
	25);
INSERT INTO V_VAL
	VALUES ("1c0118ac-9b3c-4cff-95bc-43c9ea333c67",
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("1c0118ac-9b3c-4cff-95bc-43c9ea333c67",
	'7');
INSERT INTO V_PAR
	VALUES ("1c0118ac-9b3c-4cff-95bc-43c9ea333c67",
	"4fd59b4e-bd62-4595-890d-19eedd745f51",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	10,
	35);
INSERT INTO V_VAL
	VALUES ("c133fc67-7d1f-410e-afcb-666ce3303eb6",
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("c133fc67-7d1f-410e-afcb-666ce3303eb6",
	'3');
INSERT INTO V_PAR
	VALUES ("c133fc67-7d1f-410e-afcb-666ce3303eb6",
	"b44f84d0-3308-47c9-9a78-68c0c55515b5",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"aeb24c2d-078e-4565-957f-6dedad565575",
	12,
	18);
INSERT INTO V_VAL
	VALUES ("aeb24c2d-078e-4565-957f-6dedad565575",
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("aeb24c2d-078e-4565-957f-6dedad565575",
	'1');
INSERT INTO V_PAR
	VALUES ("aeb24c2d-078e-4565-957f-6dedad565575",
	"b44f84d0-3308-47c9-9a78-68c0c55515b5",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"2767793a-aa1c-4e8a-8330-affdf0cd5ccf",
	12,
	25);
INSERT INTO V_VAL
	VALUES ("2767793a-aa1c-4e8a-8330-affdf0cd5ccf",
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("2767793a-aa1c-4e8a-8330-affdf0cd5ccf",
	'1');
INSERT INTO V_PAR
	VALUES ("2767793a-aa1c-4e8a-8330-affdf0cd5ccf",
	"b44f84d0-3308-47c9-9a78-68c0c55515b5",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	12,
	35);
INSERT INTO V_VAL
	VALUES ("d8d257fb-03f3-4c5a-8409-28d0c31c93ea",
	0,
	0,
	13,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("d8d257fb-03f3-4c5a-8409-28d0c31c93ea",
	'3');
INSERT INTO V_PAR
	VALUES ("d8d257fb-03f3-4c5a-8409-28d0c31c93ea",
	"5238bb9e-f999-4722-a2fc-f0a198d7100d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"ee60ac71-1c96-4ce4-8b6a-fa522093af7d",
	13,
	18);
INSERT INTO V_VAL
	VALUES ("ee60ac71-1c96-4ce4-8b6a-fa522093af7d",
	0,
	0,
	13,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("ee60ac71-1c96-4ce4-8b6a-fa522093af7d",
	'2');
INSERT INTO V_PAR
	VALUES ("ee60ac71-1c96-4ce4-8b6a-fa522093af7d",
	"5238bb9e-f999-4722-a2fc-f0a198d7100d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"41226924-e99e-49b6-a63f-976b6c90227b",
	13,
	25);
INSERT INTO V_VAL
	VALUES ("41226924-e99e-49b6-a63f-976b6c90227b",
	0,
	0,
	13,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("41226924-e99e-49b6-a63f-976b6c90227b",
	'5');
INSERT INTO V_PAR
	VALUES ("41226924-e99e-49b6-a63f-976b6c90227b",
	"5238bb9e-f999-4722-a2fc-f0a198d7100d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	13,
	35);
INSERT INTO V_VAL
	VALUES ("e1cf905b-e4c7-4a55-8cfb-ab9181536da9",
	0,
	0,
	14,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("e1cf905b-e4c7-4a55-8cfb-ab9181536da9",
	'3');
INSERT INTO V_PAR
	VALUES ("e1cf905b-e4c7-4a55-8cfb-ab9181536da9",
	"ef6e89e7-3698-41a5-9d7e-07f2ce794e9d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"97e8439f-fa11-4c61-9aa6-c5c073fc48b6",
	14,
	18);
INSERT INTO V_VAL
	VALUES ("97e8439f-fa11-4c61-9aa6-c5c073fc48b6",
	0,
	0,
	14,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("97e8439f-fa11-4c61-9aa6-c5c073fc48b6",
	'3');
INSERT INTO V_PAR
	VALUES ("97e8439f-fa11-4c61-9aa6-c5c073fc48b6",
	"ef6e89e7-3698-41a5-9d7e-07f2ce794e9d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"4942dafb-dc3a-472d-94d5-5d0d0dae38e2",
	14,
	25);
INSERT INTO V_VAL
	VALUES ("4942dafb-dc3a-472d-94d5-5d0d0dae38e2",
	0,
	0,
	14,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("4942dafb-dc3a-472d-94d5-5d0d0dae38e2",
	'6');
INSERT INTO V_PAR
	VALUES ("4942dafb-dc3a-472d-94d5-5d0d0dae38e2",
	"ef6e89e7-3698-41a5-9d7e-07f2ce794e9d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	14,
	35);
INSERT INTO V_VAL
	VALUES ("050526a8-36a5-4d3b-af40-7f2e0ad67f25",
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("050526a8-36a5-4d3b-af40-7f2e0ad67f25",
	'3');
INSERT INTO V_PAR
	VALUES ("050526a8-36a5-4d3b-af40-7f2e0ad67f25",
	"ab4110fd-a4e4-4696-9ed9-b59f479e3333",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"0bacfe00-944c-4845-acfa-f9c3afa9cff5",
	15,
	18);
INSERT INTO V_VAL
	VALUES ("0bacfe00-944c-4845-acfa-f9c3afa9cff5",
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("0bacfe00-944c-4845-acfa-f9c3afa9cff5",
	'8');
INSERT INTO V_PAR
	VALUES ("0bacfe00-944c-4845-acfa-f9c3afa9cff5",
	"ab4110fd-a4e4-4696-9ed9-b59f479e3333",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8f76b646-5a88-47a0-85fa-db60a2043a5c",
	15,
	25);
INSERT INTO V_VAL
	VALUES ("8f76b646-5a88-47a0-85fa-db60a2043a5c",
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("8f76b646-5a88-47a0-85fa-db60a2043a5c",
	'8');
INSERT INTO V_PAR
	VALUES ("8f76b646-5a88-47a0-85fa-db60a2043a5c",
	"ab4110fd-a4e4-4696-9ed9-b59f479e3333",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	15,
	35);
INSERT INTO V_VAL
	VALUES ("fe08e7d5-1bbd-480a-9e8f-44e2bc0e0906",
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("fe08e7d5-1bbd-480a-9e8f-44e2bc0e0906",
	'4');
INSERT INTO V_PAR
	VALUES ("fe08e7d5-1bbd-480a-9e8f-44e2bc0e0906",
	"cd394ccc-e9ba-4212-a50f-d7f234c0f0fc",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"8433b391-a636-41ca-96d8-ed0c8fe916c1",
	17,
	18);
INSERT INTO V_VAL
	VALUES ("8433b391-a636-41ca-96d8-ed0c8fe916c1",
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("8433b391-a636-41ca-96d8-ed0c8fe916c1",
	'1');
INSERT INTO V_PAR
	VALUES ("8433b391-a636-41ca-96d8-ed0c8fe916c1",
	"cd394ccc-e9ba-4212-a50f-d7f234c0f0fc",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f630c098-66f3-4353-abb0-449a7144e68f",
	17,
	25);
INSERT INTO V_VAL
	VALUES ("f630c098-66f3-4353-abb0-449a7144e68f",
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("f630c098-66f3-4353-abb0-449a7144e68f",
	'9');
INSERT INTO V_PAR
	VALUES ("f630c098-66f3-4353-abb0-449a7144e68f",
	"cd394ccc-e9ba-4212-a50f-d7f234c0f0fc",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	17,
	35);
INSERT INTO V_VAL
	VALUES ("b11e2592-844c-4f91-8349-165a828fed3f",
	0,
	0,
	18,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("b11e2592-844c-4f91-8349-165a828fed3f",
	'4');
INSERT INTO V_PAR
	VALUES ("b11e2592-844c-4f91-8349-165a828fed3f",
	"90e980e3-6d1e-43a5-86b7-85099667b30f",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"c983b3fd-f0f0-4d09-94bb-bf1aec21b60c",
	18,
	18);
INSERT INTO V_VAL
	VALUES ("c983b3fd-f0f0-4d09-94bb-bf1aec21b60c",
	0,
	0,
	18,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("c983b3fd-f0f0-4d09-94bb-bf1aec21b60c",
	'5');
INSERT INTO V_PAR
	VALUES ("c983b3fd-f0f0-4d09-94bb-bf1aec21b60c",
	"90e980e3-6d1e-43a5-86b7-85099667b30f",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"04e28de7-8b57-4278-92c3-0cdeeedf7c28",
	18,
	25);
INSERT INTO V_VAL
	VALUES ("04e28de7-8b57-4278-92c3-0cdeeedf7c28",
	0,
	0,
	18,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("04e28de7-8b57-4278-92c3-0cdeeedf7c28",
	'8');
INSERT INTO V_PAR
	VALUES ("04e28de7-8b57-4278-92c3-0cdeeedf7c28",
	"90e980e3-6d1e-43a5-86b7-85099667b30f",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	18,
	35);
INSERT INTO V_VAL
	VALUES ("06856260-4d29-498a-85c8-f927896ceef9",
	0,
	0,
	19,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("06856260-4d29-498a-85c8-f927896ceef9",
	'4');
INSERT INTO V_PAR
	VALUES ("06856260-4d29-498a-85c8-f927896ceef9",
	"869ac889-843c-4f6b-9ebd-428da3d37498",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"0b349b65-518c-4afc-b086-37c82031f0e1",
	19,
	18);
INSERT INTO V_VAL
	VALUES ("0b349b65-518c-4afc-b086-37c82031f0e1",
	0,
	0,
	19,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("0b349b65-518c-4afc-b086-37c82031f0e1",
	'9');
INSERT INTO V_PAR
	VALUES ("0b349b65-518c-4afc-b086-37c82031f0e1",
	"869ac889-843c-4f6b-9ebd-428da3d37498",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"7fb09a1f-2b61-425c-bf40-cca5a95e5d8a",
	19,
	25);
INSERT INTO V_VAL
	VALUES ("7fb09a1f-2b61-425c-bf40-cca5a95e5d8a",
	0,
	0,
	19,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("7fb09a1f-2b61-425c-bf40-cca5a95e5d8a",
	'1');
INSERT INTO V_PAR
	VALUES ("7fb09a1f-2b61-425c-bf40-cca5a95e5d8a",
	"869ac889-843c-4f6b-9ebd-428da3d37498",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	19,
	35);
INSERT INTO V_VAL
	VALUES ("8f9c2875-283f-4ac3-a0ce-48319f4dc5f0",
	0,
	0,
	21,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("8f9c2875-283f-4ac3-a0ce-48319f4dc5f0",
	'5');
INSERT INTO V_PAR
	VALUES ("8f9c2875-283f-4ac3-a0ce-48319f4dc5f0",
	"b9c2ddb8-4ac8-4d14-8cc6-ff9796f5f9a9",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"cb6d1f27-4b14-4d1b-b6e6-b1156cec7eda",
	21,
	18);
INSERT INTO V_VAL
	VALUES ("cb6d1f27-4b14-4d1b-b6e6-b1156cec7eda",
	0,
	0,
	21,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("cb6d1f27-4b14-4d1b-b6e6-b1156cec7eda",
	'1');
INSERT INTO V_PAR
	VALUES ("cb6d1f27-4b14-4d1b-b6e6-b1156cec7eda",
	"b9c2ddb8-4ac8-4d14-8cc6-ff9796f5f9a9",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"a923670c-e5f7-49d6-89e4-6f729540ac37",
	21,
	25);
INSERT INTO V_VAL
	VALUES ("a923670c-e5f7-49d6-89e4-6f729540ac37",
	0,
	0,
	21,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("a923670c-e5f7-49d6-89e4-6f729540ac37",
	'7');
INSERT INTO V_PAR
	VALUES ("a923670c-e5f7-49d6-89e4-6f729540ac37",
	"b9c2ddb8-4ac8-4d14-8cc6-ff9796f5f9a9",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	21,
	35);
INSERT INTO V_VAL
	VALUES ("b0c8a6bf-b9c3-47c8-b2f4-eac5ef1a799c",
	0,
	0,
	22,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("b0c8a6bf-b9c3-47c8-b2f4-eac5ef1a799c",
	'5');
INSERT INTO V_PAR
	VALUES ("b0c8a6bf-b9c3-47c8-b2f4-eac5ef1a799c",
	"7bcd4960-48d1-4517-a1ce-f91bf241078b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"80144d82-89c6-483d-a7d9-5398cdfd73b6",
	22,
	18);
INSERT INTO V_VAL
	VALUES ("80144d82-89c6-483d-a7d9-5398cdfd73b6",
	0,
	0,
	22,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("80144d82-89c6-483d-a7d9-5398cdfd73b6",
	'4');
INSERT INTO V_PAR
	VALUES ("80144d82-89c6-483d-a7d9-5398cdfd73b6",
	"7bcd4960-48d1-4517-a1ce-f91bf241078b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"0fc2e3df-1a83-4cbc-9ba9-298f44f571dc",
	22,
	25);
INSERT INTO V_VAL
	VALUES ("0fc2e3df-1a83-4cbc-9ba9-298f44f571dc",
	0,
	0,
	22,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("0fc2e3df-1a83-4cbc-9ba9-298f44f571dc",
	'9');
INSERT INTO V_PAR
	VALUES ("0fc2e3df-1a83-4cbc-9ba9-298f44f571dc",
	"7bcd4960-48d1-4517-a1ce-f91bf241078b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	22,
	35);
INSERT INTO V_VAL
	VALUES ("301f68ee-05ae-4135-9486-6059266cf0d6",
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("301f68ee-05ae-4135-9486-6059266cf0d6",
	'5');
INSERT INTO V_PAR
	VALUES ("301f68ee-05ae-4135-9486-6059266cf0d6",
	"0da5b4f3-bc74-400e-a8f4-27fbee9b0052",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"1197851c-c6e4-414d-a28f-06a292c645a9",
	23,
	18);
INSERT INTO V_VAL
	VALUES ("1197851c-c6e4-414d-a28f-06a292c645a9",
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("1197851c-c6e4-414d-a28f-06a292c645a9",
	'6');
INSERT INTO V_PAR
	VALUES ("1197851c-c6e4-414d-a28f-06a292c645a9",
	"0da5b4f3-bc74-400e-a8f4-27fbee9b0052",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"e4d8f4f9-21cc-4b7b-9a65-9fd051db5ad2",
	23,
	25);
INSERT INTO V_VAL
	VALUES ("e4d8f4f9-21cc-4b7b-9a65-9fd051db5ad2",
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("e4d8f4f9-21cc-4b7b-9a65-9fd051db5ad2",
	'5');
INSERT INTO V_PAR
	VALUES ("e4d8f4f9-21cc-4b7b-9a65-9fd051db5ad2",
	"0da5b4f3-bc74-400e-a8f4-27fbee9b0052",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	23,
	35);
INSERT INTO V_VAL
	VALUES ("bced6476-6644-48e6-af69-cc3bee0bcd45",
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("bced6476-6644-48e6-af69-cc3bee0bcd45",
	'5');
INSERT INTO V_PAR
	VALUES ("bced6476-6644-48e6-af69-cc3bee0bcd45",
	"19a886d5-e9fc-455e-8187-0756305c8e6a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"96c2439d-6dbd-4d91-be0d-b8d124e4a4f8",
	24,
	18);
INSERT INTO V_VAL
	VALUES ("96c2439d-6dbd-4d91-be0d-b8d124e4a4f8",
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("96c2439d-6dbd-4d91-be0d-b8d124e4a4f8",
	'9');
INSERT INTO V_PAR
	VALUES ("96c2439d-6dbd-4d91-be0d-b8d124e4a4f8",
	"19a886d5-e9fc-455e-8187-0756305c8e6a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"3855397f-bdc5-4927-a612-ea32161c9140",
	24,
	25);
INSERT INTO V_VAL
	VALUES ("3855397f-bdc5-4927-a612-ea32161c9140",
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("3855397f-bdc5-4927-a612-ea32161c9140",
	'2');
INSERT INTO V_PAR
	VALUES ("3855397f-bdc5-4927-a612-ea32161c9140",
	"19a886d5-e9fc-455e-8187-0756305c8e6a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	24,
	35);
INSERT INTO V_VAL
	VALUES ("0623e8a6-3992-4f3d-8bc1-2958e869d9ef",
	0,
	0,
	26,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("0623e8a6-3992-4f3d-8bc1-2958e869d9ef",
	'6');
INSERT INTO V_PAR
	VALUES ("0623e8a6-3992-4f3d-8bc1-2958e869d9ef",
	"35cb8458-bfdc-4f13-929b-25b1393f5768",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4d51e72c-5b5a-41d6-8456-1757c1de980f",
	26,
	18);
INSERT INTO V_VAL
	VALUES ("4d51e72c-5b5a-41d6-8456-1757c1de980f",
	0,
	0,
	26,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("4d51e72c-5b5a-41d6-8456-1757c1de980f",
	'1');
INSERT INTO V_PAR
	VALUES ("4d51e72c-5b5a-41d6-8456-1757c1de980f",
	"35cb8458-bfdc-4f13-929b-25b1393f5768",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"626b681a-a328-4b10-a310-049b98250836",
	26,
	25);
INSERT INTO V_VAL
	VALUES ("626b681a-a328-4b10-a310-049b98250836",
	0,
	0,
	26,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("626b681a-a328-4b10-a310-049b98250836",
	'5');
INSERT INTO V_PAR
	VALUES ("626b681a-a328-4b10-a310-049b98250836",
	"35cb8458-bfdc-4f13-929b-25b1393f5768",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	26,
	35);
INSERT INTO V_VAL
	VALUES ("6a56f1a8-edac-46b7-a9fb-af67465c022c",
	0,
	0,
	27,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("6a56f1a8-edac-46b7-a9fb-af67465c022c",
	'6');
INSERT INTO V_PAR
	VALUES ("6a56f1a8-edac-46b7-a9fb-af67465c022c",
	"1eba5889-9061-4b6a-8102-125e61d46a2a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"c3ecea75-b98b-4d5b-b190-accb45cf0891",
	27,
	18);
INSERT INTO V_VAL
	VALUES ("c3ecea75-b98b-4d5b-b190-accb45cf0891",
	0,
	0,
	27,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("c3ecea75-b98b-4d5b-b190-accb45cf0891",
	'5');
INSERT INTO V_PAR
	VALUES ("c3ecea75-b98b-4d5b-b190-accb45cf0891",
	"1eba5889-9061-4b6a-8102-125e61d46a2a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"25696ac7-903a-45b2-8d7d-180053c12498",
	27,
	25);
INSERT INTO V_VAL
	VALUES ("25696ac7-903a-45b2-8d7d-180053c12498",
	0,
	0,
	27,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("25696ac7-903a-45b2-8d7d-180053c12498",
	'3');
INSERT INTO V_PAR
	VALUES ("25696ac7-903a-45b2-8d7d-180053c12498",
	"1eba5889-9061-4b6a-8102-125e61d46a2a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	27,
	35);
INSERT INTO V_VAL
	VALUES ("e8c97778-a5f5-4563-8fe1-4be756fc9f7b",
	0,
	0,
	28,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("e8c97778-a5f5-4563-8fe1-4be756fc9f7b",
	'6');
INSERT INTO V_PAR
	VALUES ("e8c97778-a5f5-4563-8fe1-4be756fc9f7b",
	"a3162472-5567-4866-a462-b8d9568570be",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"f5f9c436-d3fd-4009-81e3-9be36adb28be",
	28,
	18);
INSERT INTO V_VAL
	VALUES ("f5f9c436-d3fd-4009-81e3-9be36adb28be",
	0,
	0,
	28,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("f5f9c436-d3fd-4009-81e3-9be36adb28be",
	'9');
INSERT INTO V_PAR
	VALUES ("f5f9c436-d3fd-4009-81e3-9be36adb28be",
	"a3162472-5567-4866-a462-b8d9568570be",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"6c961723-84d2-480a-8ec7-7c2130db1e18",
	28,
	25);
INSERT INTO V_VAL
	VALUES ("6c961723-84d2-480a-8ec7-7c2130db1e18",
	0,
	0,
	28,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("6c961723-84d2-480a-8ec7-7c2130db1e18",
	'9');
INSERT INTO V_PAR
	VALUES ("6c961723-84d2-480a-8ec7-7c2130db1e18",
	"a3162472-5567-4866-a462-b8d9568570be",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	28,
	35);
INSERT INTO V_VAL
	VALUES ("595c0afb-1f86-4695-9dae-6b5216a928f5",
	0,
	0,
	30,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("595c0afb-1f86-4695-9dae-6b5216a928f5",
	'7');
INSERT INTO V_PAR
	VALUES ("595c0afb-1f86-4695-9dae-6b5216a928f5",
	"0ad3d1f4-3354-4784-ba11-f1466cf98e25",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"efa69bca-feb7-4161-aedb-bac15caef130",
	30,
	18);
INSERT INTO V_VAL
	VALUES ("efa69bca-feb7-4161-aedb-bac15caef130",
	0,
	0,
	30,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("efa69bca-feb7-4161-aedb-bac15caef130",
	'2');
INSERT INTO V_PAR
	VALUES ("efa69bca-feb7-4161-aedb-bac15caef130",
	"0ad3d1f4-3354-4784-ba11-f1466cf98e25",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"cadbc626-6d08-46b8-8a4b-ffe665e8c3b1",
	30,
	25);
INSERT INTO V_VAL
	VALUES ("cadbc626-6d08-46b8-8a4b-ffe665e8c3b1",
	0,
	0,
	30,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("cadbc626-6d08-46b8-8a4b-ffe665e8c3b1",
	'2');
INSERT INTO V_PAR
	VALUES ("cadbc626-6d08-46b8-8a4b-ffe665e8c3b1",
	"0ad3d1f4-3354-4784-ba11-f1466cf98e25",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	30,
	35);
INSERT INTO V_VAL
	VALUES ("c0ca492a-4f54-4921-a51e-4656d15e3b65",
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("c0ca492a-4f54-4921-a51e-4656d15e3b65",
	'7');
INSERT INTO V_PAR
	VALUES ("c0ca492a-4f54-4921-a51e-4656d15e3b65",
	"8e6aa81c-b75b-4d40-a215-83c0acaaa313",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"6f114d3e-8bf8-47c1-9f37-c319b3efb2ef",
	31,
	18);
INSERT INTO V_VAL
	VALUES ("6f114d3e-8bf8-47c1-9f37-c319b3efb2ef",
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("6f114d3e-8bf8-47c1-9f37-c319b3efb2ef",
	'7');
INSERT INTO V_PAR
	VALUES ("6f114d3e-8bf8-47c1-9f37-c319b3efb2ef",
	"8e6aa81c-b75b-4d40-a215-83c0acaaa313",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"9edc6543-9d5e-49a9-afdc-e20a406c0089",
	31,
	25);
INSERT INTO V_VAL
	VALUES ("9edc6543-9d5e-49a9-afdc-e20a406c0089",
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("9edc6543-9d5e-49a9-afdc-e20a406c0089",
	'4');
INSERT INTO V_PAR
	VALUES ("9edc6543-9d5e-49a9-afdc-e20a406c0089",
	"8e6aa81c-b75b-4d40-a215-83c0acaaa313",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	31,
	35);
INSERT INTO V_VAL
	VALUES ("8c897afc-7dc3-4b75-aacd-979cbc927895",
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("8c897afc-7dc3-4b75-aacd-979cbc927895",
	'7');
INSERT INTO V_PAR
	VALUES ("8c897afc-7dc3-4b75-aacd-979cbc927895",
	"0df80a29-476b-495b-8b27-277c0a65f18d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7b70b0b2-009c-4e41-a7aa-ff1e825cbe66",
	32,
	18);
INSERT INTO V_VAL
	VALUES ("7b70b0b2-009c-4e41-a7aa-ff1e825cbe66",
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("7b70b0b2-009c-4e41-a7aa-ff1e825cbe66",
	'8');
INSERT INTO V_PAR
	VALUES ("7b70b0b2-009c-4e41-a7aa-ff1e825cbe66",
	"0df80a29-476b-495b-8b27-277c0a65f18d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"c16faff8-cfe4-4ab0-b220-1a13727ee3d2",
	32,
	25);
INSERT INTO V_VAL
	VALUES ("c16faff8-cfe4-4ab0-b220-1a13727ee3d2",
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("c16faff8-cfe4-4ab0-b220-1a13727ee3d2",
	'1');
INSERT INTO V_PAR
	VALUES ("c16faff8-cfe4-4ab0-b220-1a13727ee3d2",
	"0df80a29-476b-495b-8b27-277c0a65f18d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	32,
	35);
INSERT INTO V_VAL
	VALUES ("c8c75f7d-7b7c-4842-b188-19ca51dbb975",
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("c8c75f7d-7b7c-4842-b188-19ca51dbb975",
	'7');
INSERT INTO V_PAR
	VALUES ("c8c75f7d-7b7c-4842-b188-19ca51dbb975",
	"138b117f-6335-4850-baba-667fa3b204ee",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"d04b5684-51be-4ad9-b988-7c7220fb1786",
	33,
	18);
INSERT INTO V_VAL
	VALUES ("d04b5684-51be-4ad9-b988-7c7220fb1786",
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("d04b5684-51be-4ad9-b988-7c7220fb1786",
	'9');
INSERT INTO V_PAR
	VALUES ("d04b5684-51be-4ad9-b988-7c7220fb1786",
	"138b117f-6335-4850-baba-667fa3b204ee",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"e683cf93-5052-4526-8f47-d1bcd83dd00d",
	33,
	25);
INSERT INTO V_VAL
	VALUES ("e683cf93-5052-4526-8f47-d1bcd83dd00d",
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("e683cf93-5052-4526-8f47-d1bcd83dd00d",
	'7');
INSERT INTO V_PAR
	VALUES ("e683cf93-5052-4526-8f47-d1bcd83dd00d",
	"138b117f-6335-4850-baba-667fa3b204ee",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	33,
	35);
INSERT INTO V_VAL
	VALUES ("92822c80-ce89-4dbb-9577-4a096ac84b67",
	0,
	0,
	35,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("92822c80-ce89-4dbb-9577-4a096ac84b67",
	'8');
INSERT INTO V_PAR
	VALUES ("92822c80-ce89-4dbb-9577-4a096ac84b67",
	"21ea079b-eef7-485a-b26b-9dbbdabac63b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2c6ace7c-e0d7-4116-a307-09dafb822cbf",
	35,
	18);
INSERT INTO V_VAL
	VALUES ("2c6ace7c-e0d7-4116-a307-09dafb822cbf",
	0,
	0,
	35,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("2c6ace7c-e0d7-4116-a307-09dafb822cbf",
	'2');
INSERT INTO V_PAR
	VALUES ("2c6ace7c-e0d7-4116-a307-09dafb822cbf",
	"21ea079b-eef7-485a-b26b-9dbbdabac63b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"7e9d1f31-39ee-474b-85de-495538d18055",
	35,
	25);
INSERT INTO V_VAL
	VALUES ("7e9d1f31-39ee-474b-85de-495538d18055",
	0,
	0,
	35,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("7e9d1f31-39ee-474b-85de-495538d18055",
	'4');
INSERT INTO V_PAR
	VALUES ("7e9d1f31-39ee-474b-85de-495538d18055",
	"21ea079b-eef7-485a-b26b-9dbbdabac63b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	35,
	35);
INSERT INTO V_VAL
	VALUES ("8d41aa13-9ab7-4c4c-9abf-ae26356cb421",
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("8d41aa13-9ab7-4c4c-9abf-ae26356cb421",
	'8');
INSERT INTO V_PAR
	VALUES ("8d41aa13-9ab7-4c4c-9abf-ae26356cb421",
	"e08b6578-ea3b-42ec-a700-21672539977c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"040f8ac8-7007-474a-a22f-4ab567bae194",
	36,
	18);
INSERT INTO V_VAL
	VALUES ("040f8ac8-7007-474a-a22f-4ab567bae194",
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("040f8ac8-7007-474a-a22f-4ab567bae194",
	'4');
INSERT INTO V_PAR
	VALUES ("040f8ac8-7007-474a-a22f-4ab567bae194",
	"e08b6578-ea3b-42ec-a700-21672539977c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"d3727682-9b40-4dd8-82e6-080f6c64e67a",
	36,
	25);
INSERT INTO V_VAL
	VALUES ("d3727682-9b40-4dd8-82e6-080f6c64e67a",
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("d3727682-9b40-4dd8-82e6-080f6c64e67a",
	'1');
INSERT INTO V_PAR
	VALUES ("d3727682-9b40-4dd8-82e6-080f6c64e67a",
	"e08b6578-ea3b-42ec-a700-21672539977c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	36,
	35);
INSERT INTO V_VAL
	VALUES ("f89ca530-6d94-4c21-aada-08b1c3029205",
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("f89ca530-6d94-4c21-aada-08b1c3029205",
	'8');
INSERT INTO V_PAR
	VALUES ("f89ca530-6d94-4c21-aada-08b1c3029205",
	"c25063a2-7d1f-4365-a145-8079692e689c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"565964ad-d4ea-401f-8d32-143422590776",
	37,
	18);
INSERT INTO V_VAL
	VALUES ("565964ad-d4ea-401f-8d32-143422590776",
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("565964ad-d4ea-401f-8d32-143422590776",
	'5');
INSERT INTO V_PAR
	VALUES ("565964ad-d4ea-401f-8d32-143422590776",
	"c25063a2-7d1f-4365-a145-8079692e689c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"07dfda1c-b221-4c6d-ac1d-7df43aca1480",
	37,
	25);
INSERT INTO V_VAL
	VALUES ("07dfda1c-b221-4c6d-ac1d-7df43aca1480",
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("07dfda1c-b221-4c6d-ac1d-7df43aca1480",
	'5');
INSERT INTO V_PAR
	VALUES ("07dfda1c-b221-4c6d-ac1d-7df43aca1480",
	"c25063a2-7d1f-4365-a145-8079692e689c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	37,
	35);
INSERT INTO V_VAL
	VALUES ("8c2825fe-814e-4f6a-8354-8026210f460f",
	0,
	0,
	38,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("8c2825fe-814e-4f6a-8354-8026210f460f",
	'8');
INSERT INTO V_PAR
	VALUES ("8c2825fe-814e-4f6a-8354-8026210f460f",
	"0df290ad-2783-485e-86ac-efec4b398bea",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"cdd5c157-d0d2-41f4-81ca-076dd1da4043",
	38,
	18);
INSERT INTO V_VAL
	VALUES ("cdd5c157-d0d2-41f4-81ca-076dd1da4043",
	0,
	0,
	38,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("cdd5c157-d0d2-41f4-81ca-076dd1da4043",
	'6');
INSERT INTO V_PAR
	VALUES ("cdd5c157-d0d2-41f4-81ca-076dd1da4043",
	"0df290ad-2783-485e-86ac-efec4b398bea",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"c3ff518f-05fa-4d89-85ff-b39e0b4e1ec8",
	38,
	25);
INSERT INTO V_VAL
	VALUES ("c3ff518f-05fa-4d89-85ff-b39e0b4e1ec8",
	0,
	0,
	38,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("c3ff518f-05fa-4d89-85ff-b39e0b4e1ec8",
	'6');
INSERT INTO V_PAR
	VALUES ("c3ff518f-05fa-4d89-85ff-b39e0b4e1ec8",
	"0df290ad-2783-485e-86ac-efec4b398bea",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	38,
	35);
INSERT INTO V_VAL
	VALUES ("94d8ea3f-deb8-49a9-a1f5-ca7191c6d86d",
	0,
	0,
	40,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("94d8ea3f-deb8-49a9-a1f5-ca7191c6d86d",
	'9');
INSERT INTO V_PAR
	VALUES ("94d8ea3f-deb8-49a9-a1f5-ca7191c6d86d",
	"c96a2156-bb7c-4011-9519-1d694a5ccb0a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"35aa9a76-f247-4eea-ba9b-8a1f6b3a9f9a",
	40,
	18);
INSERT INTO V_VAL
	VALUES ("35aa9a76-f247-4eea-ba9b-8a1f6b3a9f9a",
	0,
	0,
	40,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("35aa9a76-f247-4eea-ba9b-8a1f6b3a9f9a",
	'1');
INSERT INTO V_PAR
	VALUES ("35aa9a76-f247-4eea-ba9b-8a1f6b3a9f9a",
	"c96a2156-bb7c-4011-9519-1d694a5ccb0a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"2510b45d-d14b-4f3d-95c7-298797a8db42",
	40,
	25);
INSERT INTO V_VAL
	VALUES ("2510b45d-d14b-4f3d-95c7-298797a8db42",
	0,
	0,
	40,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("2510b45d-d14b-4f3d-95c7-298797a8db42",
	'3');
INSERT INTO V_PAR
	VALUES ("2510b45d-d14b-4f3d-95c7-298797a8db42",
	"c96a2156-bb7c-4011-9519-1d694a5ccb0a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	40,
	35);
INSERT INTO V_VAL
	VALUES ("04cda125-8e28-4d77-98f2-06a2f67b055d",
	0,
	0,
	41,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("04cda125-8e28-4d77-98f2-06a2f67b055d",
	'9');
INSERT INTO V_PAR
	VALUES ("04cda125-8e28-4d77-98f2-06a2f67b055d",
	"84d23973-bc1d-4621-a967-12438ac8b89f",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"668636ef-7e4e-4d8f-9219-659233c1da79",
	41,
	18);
INSERT INTO V_VAL
	VALUES ("668636ef-7e4e-4d8f-9219-659233c1da79",
	0,
	0,
	41,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("668636ef-7e4e-4d8f-9219-659233c1da79",
	'6');
INSERT INTO V_PAR
	VALUES ("668636ef-7e4e-4d8f-9219-659233c1da79",
	"84d23973-bc1d-4621-a967-12438ac8b89f",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f69ae077-baef-4ea8-ac92-586fd960aaa0",
	41,
	25);
INSERT INTO V_VAL
	VALUES ("f69ae077-baef-4ea8-ac92-586fd960aaa0",
	0,
	0,
	41,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("f69ae077-baef-4ea8-ac92-586fd960aaa0",
	'7');
INSERT INTO V_PAR
	VALUES ("f69ae077-baef-4ea8-ac92-586fd960aaa0",
	"84d23973-bc1d-4621-a967-12438ac8b89f",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	41,
	35);
INSERT INTO V_VAL
	VALUES ("b14a6931-781d-4843-93bb-0fc938fab60f",
	0,
	0,
	42,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("b14a6931-781d-4843-93bb-0fc938fab60f",
	'9');
INSERT INTO V_PAR
	VALUES ("b14a6931-781d-4843-93bb-0fc938fab60f",
	"0ad9cd02-4822-497d-94a2-3127d9d2df12",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4a9a6e46-1b2b-4d5d-98ae-b2b0b925a315",
	42,
	18);
INSERT INTO V_VAL
	VALUES ("4a9a6e46-1b2b-4d5d-98ae-b2b0b925a315",
	0,
	0,
	42,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("4a9a6e46-1b2b-4d5d-98ae-b2b0b925a315",
	'7');
INSERT INTO V_PAR
	VALUES ("4a9a6e46-1b2b-4d5d-98ae-b2b0b925a315",
	"0ad9cd02-4822-497d-94a2-3127d9d2df12",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"ed3ecf31-d636-4d0f-a84e-dc61b9c5943f",
	42,
	25);
INSERT INTO V_VAL
	VALUES ("ed3ecf31-d636-4d0f-a84e-dc61b9c5943f",
	0,
	0,
	42,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eb25a7ff-7a8f-4fb7-b366-a0db191b4019");
INSERT INTO V_LIN
	VALUES ("ed3ecf31-d636-4d0f-a84e-dc61b9c5943f",
	'5');
INSERT INTO V_PAR
	VALUES ("ed3ecf31-d636-4d0f-a84e-dc61b9c5943f",
	"0ad9cd02-4822-497d-94a2-3127d9d2df12",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	42,
	35);
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"1306c98a-2790-4d7c-9822-6a721684d866");
INSERT INTO S_SYNC
	VALUES ("1306c98a-2790-4d7c-9822-6a721684d866",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'display',
	'',
	'i = 1;
/*#inline
  printf( "\n|---+---+---+---+---+---+---+---+---|\n" );
*/
while ( i <= 9 )
  j = 1;
  /*#inline
  printf( "|" );
  */
  while ( j <= 9 )
    select any cell from instances of CELL
      where ( ( selected.row_number == i ) and ( selected.column_number == j ) );
    a = cell.answer_value;
    /*#inline
    if ( 0 == v59_a )
      printf( "   |" );
    else
      printf( " %d |", v59_a );
    */
    j = j + 1;
  end while;  
  /*#inline
  printf( "\n|---+---+---+---+---+---+---+---+---|\n" );
  */
  i = i + 1;
end while;',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("3ca17a5f-c13b-4ab5-b41e-207413d2e0b7",
	"1306c98a-2790-4d7c-9822-6a721684d866");
INSERT INTO ACT_ACT
	VALUES ("3ca17a5f-c13b-4ab5-b41e-207413d2e0b7",
	'function',
	0,
	"c97f48d1-d054-4607-8918-dfd863bbe491",
	"00000000-0000-0000-0000-000000000000",
	0,
	'display',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c97f48d1-d054-4607-8918-dfd863bbe491",
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"3ca17a5f-c13b-4ab5-b41e-207413d2e0b7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ff4164af-8236-4ef3-92b3-f5fafb2bea3f",
	"c97f48d1-d054-4607-8918-dfd863bbe491",
	"ddfc6039-9e74-4161-ab62-a52920d45e7d",
	1,
	1,
	'display line: 1');
INSERT INTO ACT_AI
	VALUES ("ff4164af-8236-4ef3-92b3-f5fafb2bea3f",
	"f1455131-0a50-4d7b-8732-3d8a44039953",
	"02148a76-304e-46c8-8908-ebc10543adef",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ddfc6039-9e74-4161-ab62-a52920d45e7d",
	"c97f48d1-d054-4607-8918-dfd863bbe491",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'display line: 5');
INSERT INTO ACT_WHL
	VALUES ("ddfc6039-9e74-4161-ab62-a52920d45e7d",
	"98a18057-d7fd-4a91-80eb-ee090d6d610d",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc");
INSERT INTO V_VAL
	VALUES ("02148a76-304e-46c8-8908-ebc10543adef",
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c97f48d1-d054-4607-8918-dfd863bbe491");
INSERT INTO V_TVL
	VALUES ("02148a76-304e-46c8-8908-ebc10543adef",
	"3870c5e9-180d-4ed0-9c75-1dfd28fabfd1");
INSERT INTO V_VAL
	VALUES ("f1455131-0a50-4d7b-8732-3d8a44039953",
	0,
	0,
	1,
	5,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c97f48d1-d054-4607-8918-dfd863bbe491");
INSERT INTO V_LIN
	VALUES ("f1455131-0a50-4d7b-8732-3d8a44039953",
	'1');
INSERT INTO V_VAL
	VALUES ("6a338fb7-c956-45ad-93bf-5e1dcab8ab7f",
	0,
	0,
	5,
	9,
	9,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c97f48d1-d054-4607-8918-dfd863bbe491");
INSERT INTO V_TVL
	VALUES ("6a338fb7-c956-45ad-93bf-5e1dcab8ab7f",
	"3870c5e9-180d-4ed0-9c75-1dfd28fabfd1");
INSERT INTO V_VAL
	VALUES ("98a18057-d7fd-4a91-80eb-ee090d6d610d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c97f48d1-d054-4607-8918-dfd863bbe491");
INSERT INTO V_BIN
	VALUES ("98a18057-d7fd-4a91-80eb-ee090d6d610d",
	"469455bd-cf0e-4f80-85bf-4afe3e95177a",
	"6a338fb7-c956-45ad-93bf-5e1dcab8ab7f",
	'<=');
INSERT INTO V_VAL
	VALUES ("469455bd-cf0e-4f80-85bf-4afe3e95177a",
	0,
	0,
	5,
	14,
	14,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c97f48d1-d054-4607-8918-dfd863bbe491");
INSERT INTO V_LIN
	VALUES ("469455bd-cf0e-4f80-85bf-4afe3e95177a",
	'9');
INSERT INTO V_VAR
	VALUES ("3870c5e9-180d-4ed0-9c75-1dfd28fabfd1",
	"c97f48d1-d054-4607-8918-dfd863bbe491",
	'i',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("3870c5e9-180d-4ed0-9c75-1dfd28fabfd1",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("2a711677-d2ec-4d45-aa19-94910ce7dc47",
	1,
	1,
	1,
	"3870c5e9-180d-4ed0-9c75-1dfd28fabfd1");
INSERT INTO V_LOC
	VALUES ("953b9b4c-bcc6-47db-8a56-73f903ec8b87",
	5,
	9,
	9,
	"3870c5e9-180d-4ed0-9c75-1dfd28fabfd1");
INSERT INTO V_LOC
	VALUES ("1726f937-8f8d-4d0d-9b5c-d47c9547c40d",
	12,
	40,
	40,
	"3870c5e9-180d-4ed0-9c75-1dfd28fabfd1");
INSERT INTO V_LOC
	VALUES ("ef80f680-09c5-4926-ac08-dd626ca6c155",
	25,
	3,
	3,
	"3870c5e9-180d-4ed0-9c75-1dfd28fabfd1");
INSERT INTO V_LOC
	VALUES ("627d3638-1380-440e-bd49-a5af1e6f1299",
	25,
	7,
	7,
	"3870c5e9-180d-4ed0-9c75-1dfd28fabfd1");
INSERT INTO ACT_BLK
	VALUES ("4606aad8-cded-449e-a5a7-a307d73cd2bc",
	0,
	0,
	0,
	'',
	'',
	'',
	25,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"3ca17a5f-c13b-4ab5-b41e-207413d2e0b7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b2a0d091-2901-4a11-b065-ce63211e0edd",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc",
	"e42f4d0f-f85a-4aaf-88bd-df25775a77d1",
	6,
	3,
	'display line: 6');
INSERT INTO ACT_AI
	VALUES ("b2a0d091-2901-4a11-b065-ce63211e0edd",
	"0cae1b9e-93a9-477e-98ec-3dbfa78a1acc",
	"d11a1dbe-e4de-43b1-a51a-926a5158c07b",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e42f4d0f-f85a-4aaf-88bd-df25775a77d1",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc",
	"d6c7429f-fc81-45dd-97eb-984d0ce4ba24",
	10,
	3,
	'display line: 10');
INSERT INTO ACT_WHL
	VALUES ("e42f4d0f-f85a-4aaf-88bd-df25775a77d1",
	"477840e2-6c9a-441a-86a2-288e7e1c577a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO ACT_SMT
	VALUES ("d6c7429f-fc81-45dd-97eb-984d0ce4ba24",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc",
	"00000000-0000-0000-0000-000000000000",
	25,
	3,
	'display line: 25');
INSERT INTO ACT_AI
	VALUES ("d6c7429f-fc81-45dd-97eb-984d0ce4ba24",
	"09ce2701-2bb7-454e-9607-b4e8b94d6fd0",
	"799ecd9f-bb09-4d64-820d-aede75755f9e",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("d11a1dbe-e4de-43b1-a51a-926a5158c07b",
	1,
	1,
	6,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc");
INSERT INTO V_TVL
	VALUES ("d11a1dbe-e4de-43b1-a51a-926a5158c07b",
	"021b0f1a-8e54-4f00-89d0-fc8e1e289ff4");
INSERT INTO V_VAL
	VALUES ("0cae1b9e-93a9-477e-98ec-3dbfa78a1acc",
	0,
	0,
	6,
	7,
	7,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc");
INSERT INTO V_LIN
	VALUES ("0cae1b9e-93a9-477e-98ec-3dbfa78a1acc",
	'1');
INSERT INTO V_VAL
	VALUES ("74305d62-c4cd-4766-96fb-ac5e24be1a1c",
	0,
	0,
	10,
	11,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc");
INSERT INTO V_TVL
	VALUES ("74305d62-c4cd-4766-96fb-ac5e24be1a1c",
	"021b0f1a-8e54-4f00-89d0-fc8e1e289ff4");
INSERT INTO V_VAL
	VALUES ("477840e2-6c9a-441a-86a2-288e7e1c577a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc");
INSERT INTO V_BIN
	VALUES ("477840e2-6c9a-441a-86a2-288e7e1c577a",
	"233b1610-5d50-4419-b535-3ea47343d643",
	"74305d62-c4cd-4766-96fb-ac5e24be1a1c",
	'<=');
INSERT INTO V_VAL
	VALUES ("233b1610-5d50-4419-b535-3ea47343d643",
	0,
	0,
	10,
	16,
	16,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc");
INSERT INTO V_LIN
	VALUES ("233b1610-5d50-4419-b535-3ea47343d643",
	'9');
INSERT INTO V_VAL
	VALUES ("799ecd9f-bb09-4d64-820d-aede75755f9e",
	1,
	0,
	25,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc");
INSERT INTO V_TVL
	VALUES ("799ecd9f-bb09-4d64-820d-aede75755f9e",
	"3870c5e9-180d-4ed0-9c75-1dfd28fabfd1");
INSERT INTO V_VAL
	VALUES ("175620a6-5834-4af1-8e2c-cae496674add",
	0,
	0,
	25,
	7,
	7,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc");
INSERT INTO V_TVL
	VALUES ("175620a6-5834-4af1-8e2c-cae496674add",
	"3870c5e9-180d-4ed0-9c75-1dfd28fabfd1");
INSERT INTO V_VAL
	VALUES ("09ce2701-2bb7-454e-9607-b4e8b94d6fd0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc");
INSERT INTO V_BIN
	VALUES ("09ce2701-2bb7-454e-9607-b4e8b94d6fd0",
	"c974f577-d4b1-42c2-ade9-dd2e67fca57f",
	"175620a6-5834-4af1-8e2c-cae496674add",
	'+');
INSERT INTO V_VAL
	VALUES ("c974f577-d4b1-42c2-ade9-dd2e67fca57f",
	0,
	0,
	25,
	11,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc");
INSERT INTO V_LIN
	VALUES ("c974f577-d4b1-42c2-ade9-dd2e67fca57f",
	'1');
INSERT INTO V_VAR
	VALUES ("021b0f1a-8e54-4f00-89d0-fc8e1e289ff4",
	"4606aad8-cded-449e-a5a7-a307d73cd2bc",
	'j',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("021b0f1a-8e54-4f00-89d0-fc8e1e289ff4",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("7f17c205-8ba0-4c17-a50d-91d025e0e40b",
	6,
	3,
	3,
	"021b0f1a-8e54-4f00-89d0-fc8e1e289ff4");
INSERT INTO V_LOC
	VALUES ("34b39252-77b0-4d2e-8e9f-658d4a082265",
	10,
	11,
	11,
	"021b0f1a-8e54-4f00-89d0-fc8e1e289ff4");
INSERT INTO V_LOC
	VALUES ("65dc3a10-ac15-44fd-be68-d9b7d5ead29b",
	12,
	76,
	76,
	"021b0f1a-8e54-4f00-89d0-fc8e1e289ff4");
INSERT INTO V_LOC
	VALUES ("d15c7170-6191-4416-b4a2-1eb5f3742307",
	20,
	5,
	5,
	"021b0f1a-8e54-4f00-89d0-fc8e1e289ff4");
INSERT INTO V_LOC
	VALUES ("937a7086-f982-4780-a303-e680c5cc9724",
	20,
	9,
	9,
	"021b0f1a-8e54-4f00-89d0-fc8e1e289ff4");
INSERT INTO ACT_BLK
	VALUES ("aa47a3a4-6452-4963-8f69-86d6772928c9",
	1,
	0,
	1,
	'',
	'',
	'',
	20,
	5,
	11,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"3ca17a5f-c13b-4ab5-b41e-207413d2e0b7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5fbedc36-f49a-4119-aef7-bc4a4a113881",
	"aa47a3a4-6452-4963-8f69-86d6772928c9",
	"6f4f28ec-f9dc-4143-93ef-4923e14d3367",
	11,
	5,
	'display line: 11');
INSERT INTO ACT_FIW
	VALUES ("5fbedc36-f49a-4119-aef7-bc4a4a113881",
	"d8b52296-7f04-445d-8662-e9246d6576ee",
	1,
	'any',
	"b1f497d5-dba5-4c58-a3bd-4025d250eda7",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	11,
	39);
INSERT INTO ACT_SMT
	VALUES ("6f4f28ec-f9dc-4143-93ef-4923e14d3367",
	"aa47a3a4-6452-4963-8f69-86d6772928c9",
	"e164b430-33d7-4eee-909e-12633d4d4fb6",
	13,
	5,
	'display line: 13');
INSERT INTO ACT_AI
	VALUES ("6f4f28ec-f9dc-4143-93ef-4923e14d3367",
	"eb66f009-20c1-48e8-afbf-6692b41ca11d",
	"149e5e14-2a85-4612-8734-87851edd8c80",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e164b430-33d7-4eee-909e-12633d4d4fb6",
	"aa47a3a4-6452-4963-8f69-86d6772928c9",
	"00000000-0000-0000-0000-000000000000",
	20,
	5,
	'display line: 20');
INSERT INTO ACT_AI
	VALUES ("e164b430-33d7-4eee-909e-12633d4d4fb6",
	"e9c9ea79-7516-4c37-b14b-0e9433232f2d",
	"cc13a538-0d85-4c93-82e0-d4501614d42c",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("90bf61ae-d47b-425a-be3a-4bebaf84fc83",
	0,
	0,
	12,
	17,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_SLR
	VALUES ("90bf61ae-d47b-425a-be3a-4bebaf84fc83",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("271bdc2e-42f1-4362-9386-c5d7399daea3",
	0,
	0,
	12,
	26,
	35,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_AVL
	VALUES ("271bdc2e-42f1-4362-9386-c5d7399daea3",
	"90bf61ae-d47b-425a-be3a-4bebaf84fc83",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("2456384a-035d-4ba9-b48b-5e9bc311d75d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_BIN
	VALUES ("2456384a-035d-4ba9-b48b-5e9bc311d75d",
	"23b614e2-a050-439c-a4bf-6d19482d691b",
	"271bdc2e-42f1-4362-9386-c5d7399daea3",
	'==');
INSERT INTO V_VAL
	VALUES ("23b614e2-a050-439c-a4bf-6d19482d691b",
	0,
	0,
	12,
	40,
	40,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_TVL
	VALUES ("23b614e2-a050-439c-a4bf-6d19482d691b",
	"3870c5e9-180d-4ed0-9c75-1dfd28fabfd1");
INSERT INTO V_VAL
	VALUES ("741f945e-2c48-4ee0-bc77-0317e07b03fb",
	0,
	0,
	12,
	50,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_SLR
	VALUES ("741f945e-2c48-4ee0-bc77-0317e07b03fb",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("0c57b9c0-2b44-4c7d-b280-623842e4a2ff",
	0,
	0,
	12,
	59,
	71,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_AVL
	VALUES ("0c57b9c0-2b44-4c7d-b280-623842e4a2ff",
	"741f945e-2c48-4ee0-bc77-0317e07b03fb",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("75cfd919-1af8-458d-9b67-87e0f6f37baa",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_BIN
	VALUES ("75cfd919-1af8-458d-9b67-87e0f6f37baa",
	"c3a460a6-fc47-4d14-8ef4-fadb7395ac98",
	"0c57b9c0-2b44-4c7d-b280-623842e4a2ff",
	'==');
INSERT INTO V_VAL
	VALUES ("c3a460a6-fc47-4d14-8ef4-fadb7395ac98",
	0,
	0,
	12,
	76,
	76,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_TVL
	VALUES ("c3a460a6-fc47-4d14-8ef4-fadb7395ac98",
	"021b0f1a-8e54-4f00-89d0-fc8e1e289ff4");
INSERT INTO V_VAL
	VALUES ("b1f497d5-dba5-4c58-a3bd-4025d250eda7",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_BIN
	VALUES ("b1f497d5-dba5-4c58-a3bd-4025d250eda7",
	"75cfd919-1af8-458d-9b67-87e0f6f37baa",
	"2456384a-035d-4ba9-b48b-5e9bc311d75d",
	'and');
INSERT INTO V_VAL
	VALUES ("149e5e14-2a85-4612-8734-87851edd8c80",
	1,
	1,
	13,
	5,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_TVL
	VALUES ("149e5e14-2a85-4612-8734-87851edd8c80",
	"c4b986af-36d6-4d7c-825f-117acd248559");
INSERT INTO V_VAL
	VALUES ("266332d4-6539-4316-8724-95366939bbb5",
	0,
	0,
	13,
	9,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_IRF
	VALUES ("266332d4-6539-4316-8724-95366939bbb5",
	"d8b52296-7f04-445d-8662-e9246d6576ee");
INSERT INTO V_VAL
	VALUES ("eb66f009-20c1-48e8-afbf-6692b41ca11d",
	0,
	0,
	13,
	14,
	25,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_AVL
	VALUES ("eb66f009-20c1-48e8-afbf-6692b41ca11d",
	"266332d4-6539-4316-8724-95366939bbb5",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4");
INSERT INTO V_VAL
	VALUES ("cc13a538-0d85-4c93-82e0-d4501614d42c",
	1,
	0,
	20,
	5,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_TVL
	VALUES ("cc13a538-0d85-4c93-82e0-d4501614d42c",
	"021b0f1a-8e54-4f00-89d0-fc8e1e289ff4");
INSERT INTO V_VAL
	VALUES ("a2d32950-41b7-4bd4-9a00-590a33696462",
	0,
	0,
	20,
	9,
	9,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_TVL
	VALUES ("a2d32950-41b7-4bd4-9a00-590a33696462",
	"021b0f1a-8e54-4f00-89d0-fc8e1e289ff4");
INSERT INTO V_VAL
	VALUES ("e9c9ea79-7516-4c37-b14b-0e9433232f2d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_BIN
	VALUES ("e9c9ea79-7516-4c37-b14b-0e9433232f2d",
	"0a4a8325-f996-4b69-be6e-266b597921a3",
	"a2d32950-41b7-4bd4-9a00-590a33696462",
	'+');
INSERT INTO V_VAL
	VALUES ("0a4a8325-f996-4b69-be6e-266b597921a3",
	0,
	0,
	20,
	13,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"aa47a3a4-6452-4963-8f69-86d6772928c9");
INSERT INTO V_LIN
	VALUES ("0a4a8325-f996-4b69-be6e-266b597921a3",
	'1');
INSERT INTO V_VAR
	VALUES ("d8b52296-7f04-445d-8662-e9246d6576ee",
	"aa47a3a4-6452-4963-8f69-86d6772928c9",
	'cell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("d8b52296-7f04-445d-8662-e9246d6576ee",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("855e3a39-ec48-438c-96ac-c25542476219",
	11,
	16,
	19,
	"d8b52296-7f04-445d-8662-e9246d6576ee");
INSERT INTO V_LOC
	VALUES ("60a0752d-c5e9-431d-b626-fbfa2b90babd",
	13,
	9,
	12,
	"d8b52296-7f04-445d-8662-e9246d6576ee");
INSERT INTO V_VAR
	VALUES ("c4b986af-36d6-4d7c-825f-117acd248559",
	"aa47a3a4-6452-4963-8f69-86d6772928c9",
	'a',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("c4b986af-36d6-4d7c-825f-117acd248559",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("f4147b4f-7449-4ece-82c1-e7742b7fb5a1",
	13,
	5,
	5,
	"c4b986af-36d6-4d7c-825f-117acd248559");
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"9f5b86d5-d88d-40df-9f51-a76cc5fdb2ca");
INSERT INTO S_SYNC
	VALUES ("9f5b86d5-d88d-40df-9f51-a76cc5fdb2ca",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'solve',
	'',
	'score = CELL::score();
::display();

SEQUENCE::solve();

score = CELL::score();
if ( 81 == score )
  LOG::LogSuccess( message:"solved the puzzle" );
else
  LOG::LogFailure( message:"failed to solved the puzzle" );
end if;
::display();',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("f91c60af-f4c9-49b0-b40d-e679a92ae87e",
	"9f5b86d5-d88d-40df-9f51-a76cc5fdb2ca");
INSERT INTO ACT_ACT
	VALUES ("f91c60af-f4c9-49b0-b40d-e679a92ae87e",
	'function',
	0,
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438",
	"00000000-0000-0000-0000-000000000000",
	0,
	'solve',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("e2e1ef4c-383f-46e0-a54c-bfdb10962438",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	12,
	1,
	6,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f91c60af-f4c9-49b0-b40d-e679a92ae87e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7577a37b-d043-458d-bcfb-13e48402fcd6",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438",
	"be1141a7-4681-4d31-9cdf-258566332d86",
	1,
	1,
	'solve line: 1');
INSERT INTO ACT_AI
	VALUES ("7577a37b-d043-458d-bcfb-13e48402fcd6",
	"31646a85-4280-48b9-bff2-ed05d528eb67",
	"419b2f3a-e318-471f-879a-e7d53539ef0c",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("be1141a7-4681-4d31-9cdf-258566332d86",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438",
	"2d78e721-64f6-484b-90c2-0eb9bdd5f63e",
	2,
	1,
	'solve line: 2');
INSERT INTO ACT_FNC
	VALUES ("be1141a7-4681-4d31-9cdf-258566332d86",
	"1306c98a-2790-4d7c-9822-6a721684d866",
	2,
	3);
INSERT INTO ACT_SMT
	VALUES ("2d78e721-64f6-484b-90c2-0eb9bdd5f63e",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438",
	"055e134c-98e9-4873-8b68-a19229ce6e6b",
	4,
	1,
	'solve line: 4');
INSERT INTO ACT_TFM
	VALUES ("2d78e721-64f6-484b-90c2-0eb9bdd5f63e",
	"de80b9f3-d4a2-444b-9de6-3729cf844dc8",
	"00000000-0000-0000-0000-000000000000",
	4,
	11,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES ("055e134c-98e9-4873-8b68-a19229ce6e6b",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438",
	"28e31161-0d1a-4a2d-8522-7aaab4adb569",
	6,
	1,
	'solve line: 6');
INSERT INTO ACT_AI
	VALUES ("055e134c-98e9-4873-8b68-a19229ce6e6b",
	"aecc768f-1dfd-459f-b2df-22cd1f8e0e9f",
	"056d3af9-ba67-46a4-a80d-9645c41aaf2a",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("28e31161-0d1a-4a2d-8522-7aaab4adb569",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438",
	"8d3eed79-8f79-47e3-add3-144897fe5f36",
	7,
	1,
	'solve line: 7');
INSERT INTO ACT_IF
	VALUES ("28e31161-0d1a-4a2d-8522-7aaab4adb569",
	"49ce6bb2-2bd0-4f50-baa6-a9240780d39f",
	"8d4899c0-f2be-4494-be4e-ccd257a0900d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("6d6eb0d6-6239-42f0-a3a1-80a547366249",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438",
	"00000000-0000-0000-0000-000000000000",
	9,
	1,
	'solve line: 9');
INSERT INTO ACT_E
	VALUES ("6d6eb0d6-6239-42f0-a3a1-80a547366249",
	"b00e473e-6b02-4cf8-a9db-17d2f26bb108",
	"28e31161-0d1a-4a2d-8522-7aaab4adb569");
INSERT INTO ACT_SMT
	VALUES ("8d3eed79-8f79-47e3-add3-144897fe5f36",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438",
	"00000000-0000-0000-0000-000000000000",
	12,
	1,
	'solve line: 12');
INSERT INTO ACT_FNC
	VALUES ("8d3eed79-8f79-47e3-add3-144897fe5f36",
	"1306c98a-2790-4d7c-9822-6a721684d866",
	12,
	3);
INSERT INTO V_VAL
	VALUES ("419b2f3a-e318-471f-879a-e7d53539ef0c",
	1,
	1,
	1,
	1,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438");
INSERT INTO V_TVL
	VALUES ("419b2f3a-e318-471f-879a-e7d53539ef0c",
	"b4b06234-567b-42cf-afe0-509dcf77b393");
INSERT INTO V_VAL
	VALUES ("31646a85-4280-48b9-bff2-ed05d528eb67",
	0,
	0,
	1,
	15,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438");
INSERT INTO V_TRV
	VALUES ("31646a85-4280-48b9-bff2-ed05d528eb67",
	"85d40a8c-8b51-408d-85d3-824453116397",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	9);
INSERT INTO V_VAL
	VALUES ("056d3af9-ba67-46a4-a80d-9645c41aaf2a",
	1,
	0,
	6,
	1,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438");
INSERT INTO V_TVL
	VALUES ("056d3af9-ba67-46a4-a80d-9645c41aaf2a",
	"b4b06234-567b-42cf-afe0-509dcf77b393");
INSERT INTO V_VAL
	VALUES ("aecc768f-1dfd-459f-b2df-22cd1f8e0e9f",
	0,
	0,
	6,
	15,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438");
INSERT INTO V_TRV
	VALUES ("aecc768f-1dfd-459f-b2df-22cd1f8e0e9f",
	"85d40a8c-8b51-408d-85d3-824453116397",
	"00000000-0000-0000-0000-000000000000",
	1,
	6,
	9);
INSERT INTO V_VAL
	VALUES ("a12e7853-32b1-4f47-8398-c26f59db3b52",
	0,
	0,
	7,
	6,
	7,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438");
INSERT INTO V_LIN
	VALUES ("a12e7853-32b1-4f47-8398-c26f59db3b52",
	'81');
INSERT INTO V_VAL
	VALUES ("8d4899c0-f2be-4494-be4e-ccd257a0900d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438");
INSERT INTO V_BIN
	VALUES ("8d4899c0-f2be-4494-be4e-ccd257a0900d",
	"deeee33e-7154-4406-a338-1840ede0fcdd",
	"a12e7853-32b1-4f47-8398-c26f59db3b52",
	'==');
INSERT INTO V_VAL
	VALUES ("deeee33e-7154-4406-a338-1840ede0fcdd",
	0,
	0,
	7,
	12,
	16,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438");
INSERT INTO V_TVL
	VALUES ("deeee33e-7154-4406-a338-1840ede0fcdd",
	"b4b06234-567b-42cf-afe0-509dcf77b393");
INSERT INTO V_VAR
	VALUES ("b4b06234-567b-42cf-afe0-509dcf77b393",
	"e2e1ef4c-383f-46e0-a54c-bfdb10962438",
	'score',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("b4b06234-567b-42cf-afe0-509dcf77b393",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("3b6ee198-6955-42ac-82f1-edeb56f4171f",
	1,
	1,
	5,
	"b4b06234-567b-42cf-afe0-509dcf77b393");
INSERT INTO V_LOC
	VALUES ("4b160638-0a5d-4826-8c03-58ee53143479",
	6,
	1,
	5,
	"b4b06234-567b-42cf-afe0-509dcf77b393");
INSERT INTO V_LOC
	VALUES ("c7c159c6-b761-4de4-98f1-63efc4407759",
	7,
	12,
	16,
	"b4b06234-567b-42cf-afe0-509dcf77b393");
INSERT INTO ACT_BLK
	VALUES ("49ce6bb2-2bd0-4f50-baa6-a9240780d39f",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	8,
	3,
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f91c60af-f4c9-49b0-b40d-e679a92ae87e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ae118a76-3618-410c-8f5d-ae62a69727a0",
	"49ce6bb2-2bd0-4f50-baa6-a9240780d39f",
	"00000000-0000-0000-0000-000000000000",
	8,
	3,
	'solve line: 8');
INSERT INTO ACT_BRG
	VALUES ("ae118a76-3618-410c-8f5d-ae62a69727a0",
	"15f7937e-f6a0-46c4-88b5-c74594313811",
	8,
	8,
	8,
	3);
INSERT INTO V_VAL
	VALUES ("b30dcf8a-abe5-453d-ba1b-8261ab76ed81",
	0,
	0,
	8,
	28,
	45,
	0,
	0,
	0,
	0,
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	"49ce6bb2-2bd0-4f50-baa6-a9240780d39f");
INSERT INTO V_LST
	VALUES ("b30dcf8a-abe5-453d-ba1b-8261ab76ed81",
	'solved the puzzle');
INSERT INTO V_PAR
	VALUES ("b30dcf8a-abe5-453d-ba1b-8261ab76ed81",
	"ae118a76-3618-410c-8f5d-ae62a69727a0",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	8,
	20);
INSERT INTO ACT_BLK
	VALUES ("b00e473e-6b02-4cf8-a9db-17d2f26bb108",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	10,
	3,
	10,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f91c60af-f4c9-49b0-b40d-e679a92ae87e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ef305cb1-a2b9-40d8-a5d5-d69e4000e6e4",
	"b00e473e-6b02-4cf8-a9db-17d2f26bb108",
	"00000000-0000-0000-0000-000000000000",
	10,
	3,
	'solve line: 10');
INSERT INTO ACT_BRG
	VALUES ("ef305cb1-a2b9-40d8-a5d5-d69e4000e6e4",
	"f598b35c-392f-4d82-90a7-a4f0d9281584",
	10,
	8,
	10,
	3);
INSERT INTO V_VAL
	VALUES ("dc920608-77e1-48a5-a6aa-0ecfa9aa9a59",
	0,
	0,
	10,
	28,
	55,
	0,
	0,
	0,
	0,
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	"b00e473e-6b02-4cf8-a9db-17d2f26bb108");
INSERT INTO V_LST
	VALUES ("dc920608-77e1-48a5-a6aa-0ecfa9aa9a59",
	'failed to solved the puzzle');
INSERT INTO V_PAR
	VALUES ("dc920608-77e1-48a5-a6aa-0ecfa9aa9a59",
	"ef305cb1-a2b9-40d8-a5d5-d69e4000e6e4",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	10,
	20);
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"8cc0e2e7-9b23-4db4-8b1e-798828f1761d");
INSERT INTO S_SYNC
	VALUES ("8cc0e2e7-9b23-4db4-8b1e-798828f1761d",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'setz2_given',
	'',
	'
CELL::set_given( row:1, column:2, answer:6 );
CELL::set_given( row:1, column:4, answer:1 );
CELL::set_given( row:1, column:6, answer:4 );
CELL::set_given( row:1, column:8, answer:5 );

CELL::set_given( row:2, column:3, answer:8 );
CELL::set_given( row:2, column:4, answer:3 );
CELL::set_given( row:2, column:6, answer:5 );
CELL::set_given( row:2, column:7, answer:6 );

CELL::set_given( row:3, column:1, answer:2 );
CELL::set_given( row:3, column:9, answer:1 );

CELL::set_given( row:4, column:1, answer:8 );
CELL::set_given( row:4, column:4, answer:4 );
CELL::set_given( row:4, column:6, answer:7 );
CELL::set_given( row:4, column:9, answer:6 );

CELL::set_given( row:5, column:3, answer:6 );
CELL::set_given( row:5, column:7, answer:3 );

CELL::set_given( row:6, column:1, answer:7 );
CELL::set_given( row:6, column:4, answer:9 );
CELL::set_given( row:6, column:6, answer:1 );
CELL::set_given( row:6, column:9, answer:4 );

CELL::set_given( row:7, column:1, answer:5 );
CELL::set_given( row:7, column:9, answer:2 );

CELL::set_given( row:8, column:3, answer:7 );
CELL::set_given( row:8, column:4, answer:2 );
CELL::set_given( row:8, column:6, answer:6 );
CELL::set_given( row:8, column:7, answer:9 );

CELL::set_given( row:9, column:2, answer:4 );
CELL::set_given( row:9, column:4, answer:5 );
CELL::set_given( row:9, column:6, answer:8 );
CELL::set_given( row:9, column:8, answer:7 );

// This is extra.  Should not need this.
CELL::set_given( row:8, column:1, answer:3 );
',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("510aa21b-19bf-4fe9-8ce9-a5d9e78acf3f",
	"8cc0e2e7-9b23-4db4-8b1e-798828f1761d");
INSERT INTO ACT_ACT
	VALUES ("510aa21b-19bf-4fe9-8ce9-a5d9e78acf3f",
	'function',
	0,
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setz2_given',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("307464ab-75fe-4ba3-aed8-9178979b2cae",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	42,
	1,
	42,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"510aa21b-19bf-4fe9-8ce9-a5d9e78acf3f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("154b95f2-2998-4791-88fa-46b8dd4c3c52",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"4103aabb-5d32-457a-9580-0f122cc8a82a",
	2,
	1,
	'setz2_given line: 2');
INSERT INTO ACT_TFM
	VALUES ("154b95f2-2998-4791-88fa-46b8dd4c3c52",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	2,
	7,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES ("4103aabb-5d32-457a-9580-0f122cc8a82a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"586d931f-1ba3-44cc-9fd1-062410871125",
	3,
	1,
	'setz2_given line: 3');
INSERT INTO ACT_TFM
	VALUES ("4103aabb-5d32-457a-9580-0f122cc8a82a",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES ("586d931f-1ba3-44cc-9fd1-062410871125",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"5320465c-30d6-45f7-bede-20f8c3acb705",
	4,
	1,
	'setz2_given line: 4');
INSERT INTO ACT_TFM
	VALUES ("586d931f-1ba3-44cc-9fd1-062410871125",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES ("5320465c-30d6-45f7-bede-20f8c3acb705",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"0381160f-5246-4042-9e75-5056d5655f58",
	5,
	1,
	'setz2_given line: 5');
INSERT INTO ACT_TFM
	VALUES ("5320465c-30d6-45f7-bede-20f8c3acb705",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	5,
	7,
	5,
	1);
INSERT INTO ACT_SMT
	VALUES ("0381160f-5246-4042-9e75-5056d5655f58",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"96675312-61f8-492e-ac7d-a52811485ee4",
	7,
	1,
	'setz2_given line: 7');
INSERT INTO ACT_TFM
	VALUES ("0381160f-5246-4042-9e75-5056d5655f58",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES ("96675312-61f8-492e-ac7d-a52811485ee4",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"639f314e-890a-42cb-ab00-328749140a08",
	8,
	1,
	'setz2_given line: 8');
INSERT INTO ACT_TFM
	VALUES ("96675312-61f8-492e-ac7d-a52811485ee4",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES ("639f314e-890a-42cb-ab00-328749140a08",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"9d46245f-5643-43f5-95c7-39526c833beb",
	9,
	1,
	'setz2_given line: 9');
INSERT INTO ACT_TFM
	VALUES ("639f314e-890a-42cb-ab00-328749140a08",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	9,
	7,
	9,
	1);
INSERT INTO ACT_SMT
	VALUES ("9d46245f-5643-43f5-95c7-39526c833beb",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"c5d5d9c6-edb0-4cb8-962c-a2b5047fef6a",
	10,
	1,
	'setz2_given line: 10');
INSERT INTO ACT_TFM
	VALUES ("9d46245f-5643-43f5-95c7-39526c833beb",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES ("c5d5d9c6-edb0-4cb8-962c-a2b5047fef6a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"f0f6a14c-471f-4568-b58e-a008d63b3698",
	12,
	1,
	'setz2_given line: 12');
INSERT INTO ACT_TFM
	VALUES ("c5d5d9c6-edb0-4cb8-962c-a2b5047fef6a",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES ("f0f6a14c-471f-4568-b58e-a008d63b3698",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"b0cb3e1b-daef-4d51-ae20-50df9d125849",
	13,
	1,
	'setz2_given line: 13');
INSERT INTO ACT_TFM
	VALUES ("f0f6a14c-471f-4568-b58e-a008d63b3698",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	13,
	7,
	13,
	1);
INSERT INTO ACT_SMT
	VALUES ("b0cb3e1b-daef-4d51-ae20-50df9d125849",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"a90643b0-d02f-4225-b8b8-5e65f31f938f",
	15,
	1,
	'setz2_given line: 15');
INSERT INTO ACT_TFM
	VALUES ("b0cb3e1b-daef-4d51-ae20-50df9d125849",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES ("a90643b0-d02f-4225-b8b8-5e65f31f938f",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"9bd31405-e0fa-446e-ad15-b8220de95741",
	16,
	1,
	'setz2_given line: 16');
INSERT INTO ACT_TFM
	VALUES ("a90643b0-d02f-4225-b8b8-5e65f31f938f",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	16,
	1);
INSERT INTO ACT_SMT
	VALUES ("9bd31405-e0fa-446e-ad15-b8220de95741",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"c346dab0-6a8f-45c5-8fbf-a77d16f47a1c",
	17,
	1,
	'setz2_given line: 17');
INSERT INTO ACT_TFM
	VALUES ("9bd31405-e0fa-446e-ad15-b8220de95741",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES ("c346dab0-6a8f-45c5-8fbf-a77d16f47a1c",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"1e3ca14d-4629-42b8-9364-9638fb60294e",
	18,
	1,
	'setz2_given line: 18');
INSERT INTO ACT_TFM
	VALUES ("c346dab0-6a8f-45c5-8fbf-a77d16f47a1c",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	18,
	7,
	18,
	1);
INSERT INTO ACT_SMT
	VALUES ("1e3ca14d-4629-42b8-9364-9638fb60294e",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"14421484-a951-45f9-9528-1dab17a9e869",
	20,
	1,
	'setz2_given line: 20');
INSERT INTO ACT_TFM
	VALUES ("1e3ca14d-4629-42b8-9364-9638fb60294e",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	20,
	7,
	20,
	1);
INSERT INTO ACT_SMT
	VALUES ("14421484-a951-45f9-9528-1dab17a9e869",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"33058ef4-0882-4388-b516-8363c03261e6",
	21,
	1,
	'setz2_given line: 21');
INSERT INTO ACT_TFM
	VALUES ("14421484-a951-45f9-9528-1dab17a9e869",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	21,
	7,
	21,
	1);
INSERT INTO ACT_SMT
	VALUES ("33058ef4-0882-4388-b516-8363c03261e6",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"e8e74b2f-a3e7-4118-89e8-a5431fab06c4",
	23,
	1,
	'setz2_given line: 23');
INSERT INTO ACT_TFM
	VALUES ("33058ef4-0882-4388-b516-8363c03261e6",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES ("e8e74b2f-a3e7-4118-89e8-a5431fab06c4",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"6d733ef8-74ec-4613-9d53-e4b02a7f9f31",
	24,
	1,
	'setz2_given line: 24');
INSERT INTO ACT_TFM
	VALUES ("e8e74b2f-a3e7-4118-89e8-a5431fab06c4",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES ("6d733ef8-74ec-4613-9d53-e4b02a7f9f31",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"0e0d93d2-4b80-4123-b5c6-c6aa373abc8b",
	25,
	1,
	'setz2_given line: 25');
INSERT INTO ACT_TFM
	VALUES ("6d733ef8-74ec-4613-9d53-e4b02a7f9f31",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	25,
	7,
	25,
	1);
INSERT INTO ACT_SMT
	VALUES ("0e0d93d2-4b80-4123-b5c6-c6aa373abc8b",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"c765e9ad-c638-462c-a126-0781788235f9",
	26,
	1,
	'setz2_given line: 26');
INSERT INTO ACT_TFM
	VALUES ("0e0d93d2-4b80-4123-b5c6-c6aa373abc8b",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	26,
	7,
	26,
	1);
INSERT INTO ACT_SMT
	VALUES ("c765e9ad-c638-462c-a126-0781788235f9",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"ebd0de20-8e83-4cb1-89f6-2b1fac9eb7ad",
	28,
	1,
	'setz2_given line: 28');
INSERT INTO ACT_TFM
	VALUES ("c765e9ad-c638-462c-a126-0781788235f9",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	28,
	7,
	28,
	1);
INSERT INTO ACT_SMT
	VALUES ("ebd0de20-8e83-4cb1-89f6-2b1fac9eb7ad",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"73342370-b353-483e-a8c4-8ff1d724c555",
	29,
	1,
	'setz2_given line: 29');
INSERT INTO ACT_TFM
	VALUES ("ebd0de20-8e83-4cb1-89f6-2b1fac9eb7ad",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	29,
	7,
	29,
	1);
INSERT INTO ACT_SMT
	VALUES ("73342370-b353-483e-a8c4-8ff1d724c555",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"f812f2db-7ca2-4053-ab8d-9590a2c075c9",
	31,
	1,
	'setz2_given line: 31');
INSERT INTO ACT_TFM
	VALUES ("73342370-b353-483e-a8c4-8ff1d724c555",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES ("f812f2db-7ca2-4053-ab8d-9590a2c075c9",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"3c4b533e-0728-4c85-bbc8-caaebe6dc85e",
	32,
	1,
	'setz2_given line: 32');
INSERT INTO ACT_TFM
	VALUES ("f812f2db-7ca2-4053-ab8d-9590a2c075c9",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES ("3c4b533e-0728-4c85-bbc8-caaebe6dc85e",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"aaf408bd-88a3-4efd-9b55-2b8c2c8f8c19",
	33,
	1,
	'setz2_given line: 33');
INSERT INTO ACT_TFM
	VALUES ("3c4b533e-0728-4c85-bbc8-caaebe6dc85e",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES ("aaf408bd-88a3-4efd-9b55-2b8c2c8f8c19",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"892f898f-37e5-4b25-a39e-a49ba49c692c",
	34,
	1,
	'setz2_given line: 34');
INSERT INTO ACT_TFM
	VALUES ("aaf408bd-88a3-4efd-9b55-2b8c2c8f8c19",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	34,
	7,
	34,
	1);
INSERT INTO ACT_SMT
	VALUES ("892f898f-37e5-4b25-a39e-a49ba49c692c",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"1c940326-61c1-4193-b4dd-d5e98212d849",
	36,
	1,
	'setz2_given line: 36');
INSERT INTO ACT_TFM
	VALUES ("892f898f-37e5-4b25-a39e-a49ba49c692c",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES ("1c940326-61c1-4193-b4dd-d5e98212d849",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"0777f999-f748-4300-a988-aca64144f77b",
	37,
	1,
	'setz2_given line: 37');
INSERT INTO ACT_TFM
	VALUES ("1c940326-61c1-4193-b4dd-d5e98212d849",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	37,
	7,
	37,
	1);
INSERT INTO ACT_SMT
	VALUES ("0777f999-f748-4300-a988-aca64144f77b",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"b271be23-d56a-4782-963e-fc80c81485fa",
	38,
	1,
	'setz2_given line: 38');
INSERT INTO ACT_TFM
	VALUES ("0777f999-f748-4300-a988-aca64144f77b",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	38,
	7,
	38,
	1);
INSERT INTO ACT_SMT
	VALUES ("b271be23-d56a-4782-963e-fc80c81485fa",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"bd6c7825-3c8c-43c2-b019-9b74d8d00dd1",
	39,
	1,
	'setz2_given line: 39');
INSERT INTO ACT_TFM
	VALUES ("b271be23-d56a-4782-963e-fc80c81485fa",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	39,
	7,
	39,
	1);
INSERT INTO ACT_SMT
	VALUES ("bd6c7825-3c8c-43c2-b019-9b74d8d00dd1",
	"307464ab-75fe-4ba3-aed8-9178979b2cae",
	"00000000-0000-0000-0000-000000000000",
	42,
	1,
	'setz2_given line: 42');
INSERT INTO ACT_TFM
	VALUES ("bd6c7825-3c8c-43c2-b019-9b74d8d00dd1",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	42,
	7,
	42,
	1);
INSERT INTO V_VAL
	VALUES ("98f00d15-0a4f-4ffa-8d0c-3cf667174ab9",
	0,
	0,
	2,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("98f00d15-0a4f-4ffa-8d0c-3cf667174ab9",
	'1');
INSERT INTO V_PAR
	VALUES ("98f00d15-0a4f-4ffa-8d0c-3cf667174ab9",
	"154b95f2-2998-4791-88fa-46b8dd4c3c52",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"89691ea8-2313-4471-a6fa-79cc90c7c6bf",
	2,
	18);
INSERT INTO V_VAL
	VALUES ("89691ea8-2313-4471-a6fa-79cc90c7c6bf",
	0,
	0,
	2,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("89691ea8-2313-4471-a6fa-79cc90c7c6bf",
	'2');
INSERT INTO V_PAR
	VALUES ("89691ea8-2313-4471-a6fa-79cc90c7c6bf",
	"154b95f2-2998-4791-88fa-46b8dd4c3c52",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"778a87b7-c486-45c7-b59d-9a33ee0dc324",
	2,
	25);
INSERT INTO V_VAL
	VALUES ("778a87b7-c486-45c7-b59d-9a33ee0dc324",
	0,
	0,
	2,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("778a87b7-c486-45c7-b59d-9a33ee0dc324",
	'6');
INSERT INTO V_PAR
	VALUES ("778a87b7-c486-45c7-b59d-9a33ee0dc324",
	"154b95f2-2998-4791-88fa-46b8dd4c3c52",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	2,
	35);
INSERT INTO V_VAL
	VALUES ("dff1a794-e7a2-4c8a-a18a-8b429cdac3d7",
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("dff1a794-e7a2-4c8a-a18a-8b429cdac3d7",
	'1');
INSERT INTO V_PAR
	VALUES ("dff1a794-e7a2-4c8a-a18a-8b429cdac3d7",
	"4103aabb-5d32-457a-9580-0f122cc8a82a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"fcef2762-ab96-4667-952f-855139559987",
	3,
	18);
INSERT INTO V_VAL
	VALUES ("fcef2762-ab96-4667-952f-855139559987",
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("fcef2762-ab96-4667-952f-855139559987",
	'4');
INSERT INTO V_PAR
	VALUES ("fcef2762-ab96-4667-952f-855139559987",
	"4103aabb-5d32-457a-9580-0f122cc8a82a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"a82c3bd7-6e04-41e1-ab0b-11419d2968d5",
	3,
	25);
INSERT INTO V_VAL
	VALUES ("a82c3bd7-6e04-41e1-ab0b-11419d2968d5",
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("a82c3bd7-6e04-41e1-ab0b-11419d2968d5",
	'1');
INSERT INTO V_PAR
	VALUES ("a82c3bd7-6e04-41e1-ab0b-11419d2968d5",
	"4103aabb-5d32-457a-9580-0f122cc8a82a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	3,
	35);
INSERT INTO V_VAL
	VALUES ("716e34d1-4a03-42e7-9503-1d6e917bd8c5",
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("716e34d1-4a03-42e7-9503-1d6e917bd8c5",
	'1');
INSERT INTO V_PAR
	VALUES ("716e34d1-4a03-42e7-9503-1d6e917bd8c5",
	"586d931f-1ba3-44cc-9fd1-062410871125",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"240597b9-13db-456e-bda0-ce8c8934ab6e",
	4,
	18);
INSERT INTO V_VAL
	VALUES ("240597b9-13db-456e-bda0-ce8c8934ab6e",
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("240597b9-13db-456e-bda0-ce8c8934ab6e",
	'6');
INSERT INTO V_PAR
	VALUES ("240597b9-13db-456e-bda0-ce8c8934ab6e",
	"586d931f-1ba3-44cc-9fd1-062410871125",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"b738b8ec-113a-4ef3-88fb-be6c0027d6a0",
	4,
	25);
INSERT INTO V_VAL
	VALUES ("b738b8ec-113a-4ef3-88fb-be6c0027d6a0",
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("b738b8ec-113a-4ef3-88fb-be6c0027d6a0",
	'4');
INSERT INTO V_PAR
	VALUES ("b738b8ec-113a-4ef3-88fb-be6c0027d6a0",
	"586d931f-1ba3-44cc-9fd1-062410871125",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	4,
	35);
INSERT INTO V_VAL
	VALUES ("a86bda91-a12c-446b-b1d8-1a7e35825a91",
	0,
	0,
	5,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("a86bda91-a12c-446b-b1d8-1a7e35825a91",
	'1');
INSERT INTO V_PAR
	VALUES ("a86bda91-a12c-446b-b1d8-1a7e35825a91",
	"5320465c-30d6-45f7-bede-20f8c3acb705",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7e304e8c-4301-489b-a1b9-c913a4ad75dd",
	5,
	18);
INSERT INTO V_VAL
	VALUES ("7e304e8c-4301-489b-a1b9-c913a4ad75dd",
	0,
	0,
	5,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("7e304e8c-4301-489b-a1b9-c913a4ad75dd",
	'8');
INSERT INTO V_PAR
	VALUES ("7e304e8c-4301-489b-a1b9-c913a4ad75dd",
	"5320465c-30d6-45f7-bede-20f8c3acb705",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f265f975-762a-476a-9084-334465d39b29",
	5,
	25);
INSERT INTO V_VAL
	VALUES ("f265f975-762a-476a-9084-334465d39b29",
	0,
	0,
	5,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("f265f975-762a-476a-9084-334465d39b29",
	'5');
INSERT INTO V_PAR
	VALUES ("f265f975-762a-476a-9084-334465d39b29",
	"5320465c-30d6-45f7-bede-20f8c3acb705",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	5,
	35);
INSERT INTO V_VAL
	VALUES ("aa189aab-6816-496a-b4f8-01905028536e",
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("aa189aab-6816-496a-b4f8-01905028536e",
	'2');
INSERT INTO V_PAR
	VALUES ("aa189aab-6816-496a-b4f8-01905028536e",
	"0381160f-5246-4042-9e75-5056d5655f58",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"35966601-21c5-46b5-92df-c8dc239619cc",
	7,
	18);
INSERT INTO V_VAL
	VALUES ("35966601-21c5-46b5-92df-c8dc239619cc",
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("35966601-21c5-46b5-92df-c8dc239619cc",
	'3');
INSERT INTO V_PAR
	VALUES ("35966601-21c5-46b5-92df-c8dc239619cc",
	"0381160f-5246-4042-9e75-5056d5655f58",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"1809b0c9-4dc4-4e72-bfee-c726c9609680",
	7,
	25);
INSERT INTO V_VAL
	VALUES ("1809b0c9-4dc4-4e72-bfee-c726c9609680",
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("1809b0c9-4dc4-4e72-bfee-c726c9609680",
	'8');
INSERT INTO V_PAR
	VALUES ("1809b0c9-4dc4-4e72-bfee-c726c9609680",
	"0381160f-5246-4042-9e75-5056d5655f58",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	7,
	35);
INSERT INTO V_VAL
	VALUES ("a7d518de-baa5-47d8-b6e1-5e54245f5234",
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("a7d518de-baa5-47d8-b6e1-5e54245f5234",
	'2');
INSERT INTO V_PAR
	VALUES ("a7d518de-baa5-47d8-b6e1-5e54245f5234",
	"96675312-61f8-492e-ac7d-a52811485ee4",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"70411beb-e109-4216-9f48-65336b1d1139",
	8,
	18);
INSERT INTO V_VAL
	VALUES ("70411beb-e109-4216-9f48-65336b1d1139",
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("70411beb-e109-4216-9f48-65336b1d1139",
	'4');
INSERT INTO V_PAR
	VALUES ("70411beb-e109-4216-9f48-65336b1d1139",
	"96675312-61f8-492e-ac7d-a52811485ee4",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"4fee1eda-6ecb-4715-850d-f2d4b23986bf",
	8,
	25);
INSERT INTO V_VAL
	VALUES ("4fee1eda-6ecb-4715-850d-f2d4b23986bf",
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("4fee1eda-6ecb-4715-850d-f2d4b23986bf",
	'3');
INSERT INTO V_PAR
	VALUES ("4fee1eda-6ecb-4715-850d-f2d4b23986bf",
	"96675312-61f8-492e-ac7d-a52811485ee4",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	8,
	35);
INSERT INTO V_VAL
	VALUES ("eedf3d0d-b3c5-4f4a-b765-ef437dfd3e0b",
	0,
	0,
	9,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("eedf3d0d-b3c5-4f4a-b765-ef437dfd3e0b",
	'2');
INSERT INTO V_PAR
	VALUES ("eedf3d0d-b3c5-4f4a-b765-ef437dfd3e0b",
	"639f314e-890a-42cb-ab00-328749140a08",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"224a4b2c-0ab3-4dfd-bcdb-0b7e423ad4d2",
	9,
	18);
INSERT INTO V_VAL
	VALUES ("224a4b2c-0ab3-4dfd-bcdb-0b7e423ad4d2",
	0,
	0,
	9,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("224a4b2c-0ab3-4dfd-bcdb-0b7e423ad4d2",
	'6');
INSERT INTO V_PAR
	VALUES ("224a4b2c-0ab3-4dfd-bcdb-0b7e423ad4d2",
	"639f314e-890a-42cb-ab00-328749140a08",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8db1fa7d-3450-4723-9c25-0f8d5ae39c0a",
	9,
	25);
INSERT INTO V_VAL
	VALUES ("8db1fa7d-3450-4723-9c25-0f8d5ae39c0a",
	0,
	0,
	9,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("8db1fa7d-3450-4723-9c25-0f8d5ae39c0a",
	'5');
INSERT INTO V_PAR
	VALUES ("8db1fa7d-3450-4723-9c25-0f8d5ae39c0a",
	"639f314e-890a-42cb-ab00-328749140a08",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	9,
	35);
INSERT INTO V_VAL
	VALUES ("d1bae917-e517-466c-974e-0cdd0e98de6a",
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("d1bae917-e517-466c-974e-0cdd0e98de6a",
	'2');
INSERT INTO V_PAR
	VALUES ("d1bae917-e517-466c-974e-0cdd0e98de6a",
	"9d46245f-5643-43f5-95c7-39526c833beb",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"e70f23df-c79e-4333-9b4e-72fc4d75ff46",
	10,
	18);
INSERT INTO V_VAL
	VALUES ("e70f23df-c79e-4333-9b4e-72fc4d75ff46",
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("e70f23df-c79e-4333-9b4e-72fc4d75ff46",
	'7');
INSERT INTO V_PAR
	VALUES ("e70f23df-c79e-4333-9b4e-72fc4d75ff46",
	"9d46245f-5643-43f5-95c7-39526c833beb",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"b8479863-7d75-4a1c-8952-2b271570da63",
	10,
	25);
INSERT INTO V_VAL
	VALUES ("b8479863-7d75-4a1c-8952-2b271570da63",
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("b8479863-7d75-4a1c-8952-2b271570da63",
	'6');
INSERT INTO V_PAR
	VALUES ("b8479863-7d75-4a1c-8952-2b271570da63",
	"9d46245f-5643-43f5-95c7-39526c833beb",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	10,
	35);
INSERT INTO V_VAL
	VALUES ("4a172608-7396-4e5b-8522-1b639a3bda83",
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("4a172608-7396-4e5b-8522-1b639a3bda83",
	'3');
INSERT INTO V_PAR
	VALUES ("4a172608-7396-4e5b-8522-1b639a3bda83",
	"c5d5d9c6-edb0-4cb8-962c-a2b5047fef6a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"c673ea42-c2ce-4ebf-ac91-af7713432a30",
	12,
	18);
INSERT INTO V_VAL
	VALUES ("c673ea42-c2ce-4ebf-ac91-af7713432a30",
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("c673ea42-c2ce-4ebf-ac91-af7713432a30",
	'1');
INSERT INTO V_PAR
	VALUES ("c673ea42-c2ce-4ebf-ac91-af7713432a30",
	"c5d5d9c6-edb0-4cb8-962c-a2b5047fef6a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"5c12fcf2-6acf-40a5-92eb-b487d7146446",
	12,
	25);
INSERT INTO V_VAL
	VALUES ("5c12fcf2-6acf-40a5-92eb-b487d7146446",
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("5c12fcf2-6acf-40a5-92eb-b487d7146446",
	'2');
INSERT INTO V_PAR
	VALUES ("5c12fcf2-6acf-40a5-92eb-b487d7146446",
	"c5d5d9c6-edb0-4cb8-962c-a2b5047fef6a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	12,
	35);
INSERT INTO V_VAL
	VALUES ("6838b708-b53f-406e-83fc-c4009282d5f3",
	0,
	0,
	13,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("6838b708-b53f-406e-83fc-c4009282d5f3",
	'3');
INSERT INTO V_PAR
	VALUES ("6838b708-b53f-406e-83fc-c4009282d5f3",
	"f0f6a14c-471f-4568-b58e-a008d63b3698",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"d33712c7-f504-4a4c-bc40-d89eeb28dd52",
	13,
	18);
INSERT INTO V_VAL
	VALUES ("d33712c7-f504-4a4c-bc40-d89eeb28dd52",
	0,
	0,
	13,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("d33712c7-f504-4a4c-bc40-d89eeb28dd52",
	'9');
INSERT INTO V_PAR
	VALUES ("d33712c7-f504-4a4c-bc40-d89eeb28dd52",
	"f0f6a14c-471f-4568-b58e-a008d63b3698",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"e945eede-529c-486b-9461-02de27678437",
	13,
	25);
INSERT INTO V_VAL
	VALUES ("e945eede-529c-486b-9461-02de27678437",
	0,
	0,
	13,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("e945eede-529c-486b-9461-02de27678437",
	'1');
INSERT INTO V_PAR
	VALUES ("e945eede-529c-486b-9461-02de27678437",
	"f0f6a14c-471f-4568-b58e-a008d63b3698",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	13,
	35);
INSERT INTO V_VAL
	VALUES ("1399f1ea-6378-4894-8dbe-548c7a2f0213",
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("1399f1ea-6378-4894-8dbe-548c7a2f0213",
	'4');
INSERT INTO V_PAR
	VALUES ("1399f1ea-6378-4894-8dbe-548c7a2f0213",
	"b0cb3e1b-daef-4d51-ae20-50df9d125849",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"da2ca910-c3fa-4e8e-abd7-be6562e4bc16",
	15,
	18);
INSERT INTO V_VAL
	VALUES ("da2ca910-c3fa-4e8e-abd7-be6562e4bc16",
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("da2ca910-c3fa-4e8e-abd7-be6562e4bc16",
	'1');
INSERT INTO V_PAR
	VALUES ("da2ca910-c3fa-4e8e-abd7-be6562e4bc16",
	"b0cb3e1b-daef-4d51-ae20-50df9d125849",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f2108a9f-dd72-4d29-af1d-f3d5fbfbdaba",
	15,
	25);
INSERT INTO V_VAL
	VALUES ("f2108a9f-dd72-4d29-af1d-f3d5fbfbdaba",
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("f2108a9f-dd72-4d29-af1d-f3d5fbfbdaba",
	'8');
INSERT INTO V_PAR
	VALUES ("f2108a9f-dd72-4d29-af1d-f3d5fbfbdaba",
	"b0cb3e1b-daef-4d51-ae20-50df9d125849",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	15,
	35);
INSERT INTO V_VAL
	VALUES ("34aba817-84ad-4ea9-9030-0a49c61c159a",
	0,
	0,
	16,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("34aba817-84ad-4ea9-9030-0a49c61c159a",
	'4');
INSERT INTO V_PAR
	VALUES ("34aba817-84ad-4ea9-9030-0a49c61c159a",
	"a90643b0-d02f-4225-b8b8-5e65f31f938f",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2f5bee60-d974-4ecd-94b2-7d6fd6ff96a8",
	16,
	18);
INSERT INTO V_VAL
	VALUES ("2f5bee60-d974-4ecd-94b2-7d6fd6ff96a8",
	0,
	0,
	16,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("2f5bee60-d974-4ecd-94b2-7d6fd6ff96a8",
	'4');
INSERT INTO V_PAR
	VALUES ("2f5bee60-d974-4ecd-94b2-7d6fd6ff96a8",
	"a90643b0-d02f-4225-b8b8-5e65f31f938f",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"a01a2be3-e83d-4f4b-a902-3b6621e162b4",
	16,
	25);
INSERT INTO V_VAL
	VALUES ("a01a2be3-e83d-4f4b-a902-3b6621e162b4",
	0,
	0,
	16,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("a01a2be3-e83d-4f4b-a902-3b6621e162b4",
	'4');
INSERT INTO V_PAR
	VALUES ("a01a2be3-e83d-4f4b-a902-3b6621e162b4",
	"a90643b0-d02f-4225-b8b8-5e65f31f938f",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	16,
	35);
INSERT INTO V_VAL
	VALUES ("b53388a8-2527-488a-868f-43c952f6d826",
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("b53388a8-2527-488a-868f-43c952f6d826",
	'4');
INSERT INTO V_PAR
	VALUES ("b53388a8-2527-488a-868f-43c952f6d826",
	"9bd31405-e0fa-446e-ad15-b8220de95741",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"9d2c95a1-c340-4f2c-929a-12733d23531e",
	17,
	18);
INSERT INTO V_VAL
	VALUES ("9d2c95a1-c340-4f2c-929a-12733d23531e",
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("9d2c95a1-c340-4f2c-929a-12733d23531e",
	'6');
INSERT INTO V_PAR
	VALUES ("9d2c95a1-c340-4f2c-929a-12733d23531e",
	"9bd31405-e0fa-446e-ad15-b8220de95741",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"56ae35f1-e11e-4502-822a-2451eb1c5a4a",
	17,
	25);
INSERT INTO V_VAL
	VALUES ("56ae35f1-e11e-4502-822a-2451eb1c5a4a",
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("56ae35f1-e11e-4502-822a-2451eb1c5a4a",
	'7');
INSERT INTO V_PAR
	VALUES ("56ae35f1-e11e-4502-822a-2451eb1c5a4a",
	"9bd31405-e0fa-446e-ad15-b8220de95741",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	17,
	35);
INSERT INTO V_VAL
	VALUES ("ada2af86-2f40-4034-8e45-4918b8d52cac",
	0,
	0,
	18,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("ada2af86-2f40-4034-8e45-4918b8d52cac",
	'4');
INSERT INTO V_PAR
	VALUES ("ada2af86-2f40-4034-8e45-4918b8d52cac",
	"c346dab0-6a8f-45c5-8fbf-a77d16f47a1c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"455b214f-66e2-48e6-b45e-203e413d6b57",
	18,
	18);
INSERT INTO V_VAL
	VALUES ("455b214f-66e2-48e6-b45e-203e413d6b57",
	0,
	0,
	18,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("455b214f-66e2-48e6-b45e-203e413d6b57",
	'9');
INSERT INTO V_PAR
	VALUES ("455b214f-66e2-48e6-b45e-203e413d6b57",
	"c346dab0-6a8f-45c5-8fbf-a77d16f47a1c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"7bde9901-2e83-427f-954f-5d476e1030dd",
	18,
	25);
INSERT INTO V_VAL
	VALUES ("7bde9901-2e83-427f-954f-5d476e1030dd",
	0,
	0,
	18,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("7bde9901-2e83-427f-954f-5d476e1030dd",
	'6');
INSERT INTO V_PAR
	VALUES ("7bde9901-2e83-427f-954f-5d476e1030dd",
	"c346dab0-6a8f-45c5-8fbf-a77d16f47a1c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	18,
	35);
INSERT INTO V_VAL
	VALUES ("21f1d050-efda-4b87-9a33-eed556cbafc5",
	0,
	0,
	20,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("21f1d050-efda-4b87-9a33-eed556cbafc5",
	'5');
INSERT INTO V_PAR
	VALUES ("21f1d050-efda-4b87-9a33-eed556cbafc5",
	"1e3ca14d-4629-42b8-9364-9638fb60294e",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"77f6f84a-6a8b-4869-929a-01985320ddbc",
	20,
	18);
INSERT INTO V_VAL
	VALUES ("77f6f84a-6a8b-4869-929a-01985320ddbc",
	0,
	0,
	20,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("77f6f84a-6a8b-4869-929a-01985320ddbc",
	'3');
INSERT INTO V_PAR
	VALUES ("77f6f84a-6a8b-4869-929a-01985320ddbc",
	"1e3ca14d-4629-42b8-9364-9638fb60294e",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"3b1a92c7-472d-4669-b9a0-7b387fbe689e",
	20,
	25);
INSERT INTO V_VAL
	VALUES ("3b1a92c7-472d-4669-b9a0-7b387fbe689e",
	0,
	0,
	20,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("3b1a92c7-472d-4669-b9a0-7b387fbe689e",
	'6');
INSERT INTO V_PAR
	VALUES ("3b1a92c7-472d-4669-b9a0-7b387fbe689e",
	"1e3ca14d-4629-42b8-9364-9638fb60294e",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	20,
	35);
INSERT INTO V_VAL
	VALUES ("98de5586-9aa6-41fe-8f1e-ac4eada1b9a8",
	0,
	0,
	21,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("98de5586-9aa6-41fe-8f1e-ac4eada1b9a8",
	'5');
INSERT INTO V_PAR
	VALUES ("98de5586-9aa6-41fe-8f1e-ac4eada1b9a8",
	"14421484-a951-45f9-9528-1dab17a9e869",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"776b1433-11c3-4cf1-baea-1d83e9ebe2c6",
	21,
	18);
INSERT INTO V_VAL
	VALUES ("776b1433-11c3-4cf1-baea-1d83e9ebe2c6",
	0,
	0,
	21,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("776b1433-11c3-4cf1-baea-1d83e9ebe2c6",
	'7');
INSERT INTO V_PAR
	VALUES ("776b1433-11c3-4cf1-baea-1d83e9ebe2c6",
	"14421484-a951-45f9-9528-1dab17a9e869",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"1325bb41-23a1-4a57-9b02-43b3e875c728",
	21,
	25);
INSERT INTO V_VAL
	VALUES ("1325bb41-23a1-4a57-9b02-43b3e875c728",
	0,
	0,
	21,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("1325bb41-23a1-4a57-9b02-43b3e875c728",
	'3');
INSERT INTO V_PAR
	VALUES ("1325bb41-23a1-4a57-9b02-43b3e875c728",
	"14421484-a951-45f9-9528-1dab17a9e869",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	21,
	35);
INSERT INTO V_VAL
	VALUES ("c60a9a56-eb70-459a-8582-f328e5a6e19d",
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("c60a9a56-eb70-459a-8582-f328e5a6e19d",
	'6');
INSERT INTO V_PAR
	VALUES ("c60a9a56-eb70-459a-8582-f328e5a6e19d",
	"33058ef4-0882-4388-b516-8363c03261e6",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"eaf49ad1-11d3-4991-a4ed-68af2b796495",
	23,
	18);
INSERT INTO V_VAL
	VALUES ("eaf49ad1-11d3-4991-a4ed-68af2b796495",
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("eaf49ad1-11d3-4991-a4ed-68af2b796495",
	'1');
INSERT INTO V_PAR
	VALUES ("eaf49ad1-11d3-4991-a4ed-68af2b796495",
	"33058ef4-0882-4388-b516-8363c03261e6",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"38ff6b59-0bba-4ad9-a70b-ca7e5ef48a0b",
	23,
	25);
INSERT INTO V_VAL
	VALUES ("38ff6b59-0bba-4ad9-a70b-ca7e5ef48a0b",
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("38ff6b59-0bba-4ad9-a70b-ca7e5ef48a0b",
	'7');
INSERT INTO V_PAR
	VALUES ("38ff6b59-0bba-4ad9-a70b-ca7e5ef48a0b",
	"33058ef4-0882-4388-b516-8363c03261e6",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	23,
	35);
INSERT INTO V_VAL
	VALUES ("b3f6a3eb-172c-402e-887a-5ef1f96b4b2f",
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("b3f6a3eb-172c-402e-887a-5ef1f96b4b2f",
	'6');
INSERT INTO V_PAR
	VALUES ("b3f6a3eb-172c-402e-887a-5ef1f96b4b2f",
	"e8e74b2f-a3e7-4118-89e8-a5431fab06c4",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"e6dcf1c4-6c6f-4939-942e-be802b72ceac",
	24,
	18);
INSERT INTO V_VAL
	VALUES ("e6dcf1c4-6c6f-4939-942e-be802b72ceac",
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("e6dcf1c4-6c6f-4939-942e-be802b72ceac",
	'4');
INSERT INTO V_PAR
	VALUES ("e6dcf1c4-6c6f-4939-942e-be802b72ceac",
	"e8e74b2f-a3e7-4118-89e8-a5431fab06c4",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"b8e16773-b536-4502-9c44-040fc465d1f9",
	24,
	25);
INSERT INTO V_VAL
	VALUES ("b8e16773-b536-4502-9c44-040fc465d1f9",
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("b8e16773-b536-4502-9c44-040fc465d1f9",
	'9');
INSERT INTO V_PAR
	VALUES ("b8e16773-b536-4502-9c44-040fc465d1f9",
	"e8e74b2f-a3e7-4118-89e8-a5431fab06c4",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	24,
	35);
INSERT INTO V_VAL
	VALUES ("79391a6b-736e-47d1-94a1-fed3bb5b896f",
	0,
	0,
	25,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("79391a6b-736e-47d1-94a1-fed3bb5b896f",
	'6');
INSERT INTO V_PAR
	VALUES ("79391a6b-736e-47d1-94a1-fed3bb5b896f",
	"6d733ef8-74ec-4613-9d53-e4b02a7f9f31",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"305974de-09fd-4e5d-a5d2-275196d0eef3",
	25,
	18);
INSERT INTO V_VAL
	VALUES ("305974de-09fd-4e5d-a5d2-275196d0eef3",
	0,
	0,
	25,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("305974de-09fd-4e5d-a5d2-275196d0eef3",
	'6');
INSERT INTO V_PAR
	VALUES ("305974de-09fd-4e5d-a5d2-275196d0eef3",
	"6d733ef8-74ec-4613-9d53-e4b02a7f9f31",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"772f1e13-182b-4c8c-b4d0-305af78c6870",
	25,
	25);
INSERT INTO V_VAL
	VALUES ("772f1e13-182b-4c8c-b4d0-305af78c6870",
	0,
	0,
	25,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("772f1e13-182b-4c8c-b4d0-305af78c6870",
	'1');
INSERT INTO V_PAR
	VALUES ("772f1e13-182b-4c8c-b4d0-305af78c6870",
	"6d733ef8-74ec-4613-9d53-e4b02a7f9f31",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	25,
	35);
INSERT INTO V_VAL
	VALUES ("7f476f60-386e-400f-8cfa-4954fde4a504",
	0,
	0,
	26,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("7f476f60-386e-400f-8cfa-4954fde4a504",
	'6');
INSERT INTO V_PAR
	VALUES ("7f476f60-386e-400f-8cfa-4954fde4a504",
	"0e0d93d2-4b80-4123-b5c6-c6aa373abc8b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7325c542-1c2a-4eaa-b7bc-a4dc3e3abf1b",
	26,
	18);
INSERT INTO V_VAL
	VALUES ("7325c542-1c2a-4eaa-b7bc-a4dc3e3abf1b",
	0,
	0,
	26,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("7325c542-1c2a-4eaa-b7bc-a4dc3e3abf1b",
	'9');
INSERT INTO V_PAR
	VALUES ("7325c542-1c2a-4eaa-b7bc-a4dc3e3abf1b",
	"0e0d93d2-4b80-4123-b5c6-c6aa373abc8b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"eac21ec4-2273-4458-b24f-018403eab3b3",
	26,
	25);
INSERT INTO V_VAL
	VALUES ("eac21ec4-2273-4458-b24f-018403eab3b3",
	0,
	0,
	26,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("eac21ec4-2273-4458-b24f-018403eab3b3",
	'4');
INSERT INTO V_PAR
	VALUES ("eac21ec4-2273-4458-b24f-018403eab3b3",
	"0e0d93d2-4b80-4123-b5c6-c6aa373abc8b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	26,
	35);
INSERT INTO V_VAL
	VALUES ("fcfbadcc-c867-4452-bae2-fa7eda247563",
	0,
	0,
	28,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("fcfbadcc-c867-4452-bae2-fa7eda247563",
	'7');
INSERT INTO V_PAR
	VALUES ("fcfbadcc-c867-4452-bae2-fa7eda247563",
	"c765e9ad-c638-462c-a126-0781788235f9",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"e1906b4f-6cf6-4c22-a29b-2e2a72dbff89",
	28,
	18);
INSERT INTO V_VAL
	VALUES ("e1906b4f-6cf6-4c22-a29b-2e2a72dbff89",
	0,
	0,
	28,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("e1906b4f-6cf6-4c22-a29b-2e2a72dbff89",
	'1');
INSERT INTO V_PAR
	VALUES ("e1906b4f-6cf6-4c22-a29b-2e2a72dbff89",
	"c765e9ad-c638-462c-a126-0781788235f9",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"633a46c9-0372-447f-aaa2-4a7b7c47f6f5",
	28,
	25);
INSERT INTO V_VAL
	VALUES ("633a46c9-0372-447f-aaa2-4a7b7c47f6f5",
	0,
	0,
	28,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("633a46c9-0372-447f-aaa2-4a7b7c47f6f5",
	'5');
INSERT INTO V_PAR
	VALUES ("633a46c9-0372-447f-aaa2-4a7b7c47f6f5",
	"c765e9ad-c638-462c-a126-0781788235f9",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	28,
	35);
INSERT INTO V_VAL
	VALUES ("608ab8dc-3a20-4b24-95b8-058938f1ce79",
	0,
	0,
	29,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("608ab8dc-3a20-4b24-95b8-058938f1ce79",
	'7');
INSERT INTO V_PAR
	VALUES ("608ab8dc-3a20-4b24-95b8-058938f1ce79",
	"ebd0de20-8e83-4cb1-89f6-2b1fac9eb7ad",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4799b7f2-053c-4e98-aa80-239c653efbae",
	29,
	18);
INSERT INTO V_VAL
	VALUES ("4799b7f2-053c-4e98-aa80-239c653efbae",
	0,
	0,
	29,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("4799b7f2-053c-4e98-aa80-239c653efbae",
	'9');
INSERT INTO V_PAR
	VALUES ("4799b7f2-053c-4e98-aa80-239c653efbae",
	"ebd0de20-8e83-4cb1-89f6-2b1fac9eb7ad",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"15a66c3d-cec3-4cb5-afbb-811da3fa386c",
	29,
	25);
INSERT INTO V_VAL
	VALUES ("15a66c3d-cec3-4cb5-afbb-811da3fa386c",
	0,
	0,
	29,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("15a66c3d-cec3-4cb5-afbb-811da3fa386c",
	'2');
INSERT INTO V_PAR
	VALUES ("15a66c3d-cec3-4cb5-afbb-811da3fa386c",
	"ebd0de20-8e83-4cb1-89f6-2b1fac9eb7ad",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	29,
	35);
INSERT INTO V_VAL
	VALUES ("90d9a15a-d02b-42ba-9a46-0023f8347b66",
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("90d9a15a-d02b-42ba-9a46-0023f8347b66",
	'8');
INSERT INTO V_PAR
	VALUES ("90d9a15a-d02b-42ba-9a46-0023f8347b66",
	"73342370-b353-483e-a8c4-8ff1d724c555",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2984d20d-0ea9-48f5-bb1c-6adb230b03c9",
	31,
	18);
INSERT INTO V_VAL
	VALUES ("2984d20d-0ea9-48f5-bb1c-6adb230b03c9",
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("2984d20d-0ea9-48f5-bb1c-6adb230b03c9",
	'3');
INSERT INTO V_PAR
	VALUES ("2984d20d-0ea9-48f5-bb1c-6adb230b03c9",
	"73342370-b353-483e-a8c4-8ff1d724c555",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"def21771-a076-404d-abea-d9f3cd1807d1",
	31,
	25);
INSERT INTO V_VAL
	VALUES ("def21771-a076-404d-abea-d9f3cd1807d1",
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("def21771-a076-404d-abea-d9f3cd1807d1",
	'7');
INSERT INTO V_PAR
	VALUES ("def21771-a076-404d-abea-d9f3cd1807d1",
	"73342370-b353-483e-a8c4-8ff1d724c555",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	31,
	35);
INSERT INTO V_VAL
	VALUES ("1a334b08-a632-4f8b-9871-831dcee9246e",
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("1a334b08-a632-4f8b-9871-831dcee9246e",
	'8');
INSERT INTO V_PAR
	VALUES ("1a334b08-a632-4f8b-9871-831dcee9246e",
	"f812f2db-7ca2-4053-ab8d-9590a2c075c9",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"6811f331-da4a-4181-a59b-3ba294891d44",
	32,
	18);
INSERT INTO V_VAL
	VALUES ("6811f331-da4a-4181-a59b-3ba294891d44",
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("6811f331-da4a-4181-a59b-3ba294891d44",
	'4');
INSERT INTO V_PAR
	VALUES ("6811f331-da4a-4181-a59b-3ba294891d44",
	"f812f2db-7ca2-4053-ab8d-9590a2c075c9",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"c255fb4a-21a2-4042-be53-ca44a3e8962a",
	32,
	25);
INSERT INTO V_VAL
	VALUES ("c255fb4a-21a2-4042-be53-ca44a3e8962a",
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("c255fb4a-21a2-4042-be53-ca44a3e8962a",
	'2');
INSERT INTO V_PAR
	VALUES ("c255fb4a-21a2-4042-be53-ca44a3e8962a",
	"f812f2db-7ca2-4053-ab8d-9590a2c075c9",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	32,
	35);
INSERT INTO V_VAL
	VALUES ("e01fee15-f835-410d-a6dd-c2ffc1b7b86f",
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("e01fee15-f835-410d-a6dd-c2ffc1b7b86f",
	'8');
INSERT INTO V_PAR
	VALUES ("e01fee15-f835-410d-a6dd-c2ffc1b7b86f",
	"3c4b533e-0728-4c85-bbc8-caaebe6dc85e",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"62accec1-fedc-43dc-b98f-27e07fb3d83f",
	33,
	18);
INSERT INTO V_VAL
	VALUES ("62accec1-fedc-43dc-b98f-27e07fb3d83f",
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("62accec1-fedc-43dc-b98f-27e07fb3d83f",
	'6');
INSERT INTO V_PAR
	VALUES ("62accec1-fedc-43dc-b98f-27e07fb3d83f",
	"3c4b533e-0728-4c85-bbc8-caaebe6dc85e",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f461f811-7b08-4d62-a4fb-5fa354138e81",
	33,
	25);
INSERT INTO V_VAL
	VALUES ("f461f811-7b08-4d62-a4fb-5fa354138e81",
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("f461f811-7b08-4d62-a4fb-5fa354138e81",
	'6');
INSERT INTO V_PAR
	VALUES ("f461f811-7b08-4d62-a4fb-5fa354138e81",
	"3c4b533e-0728-4c85-bbc8-caaebe6dc85e",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	33,
	35);
INSERT INTO V_VAL
	VALUES ("8db4a867-a576-40e0-aa8f-af59f7e14f2b",
	0,
	0,
	34,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("8db4a867-a576-40e0-aa8f-af59f7e14f2b",
	'8');
INSERT INTO V_PAR
	VALUES ("8db4a867-a576-40e0-aa8f-af59f7e14f2b",
	"aaf408bd-88a3-4efd-9b55-2b8c2c8f8c19",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"58275386-8c98-41f3-b735-ff95c4de3dba",
	34,
	18);
INSERT INTO V_VAL
	VALUES ("58275386-8c98-41f3-b735-ff95c4de3dba",
	0,
	0,
	34,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("58275386-8c98-41f3-b735-ff95c4de3dba",
	'7');
INSERT INTO V_PAR
	VALUES ("58275386-8c98-41f3-b735-ff95c4de3dba",
	"aaf408bd-88a3-4efd-9b55-2b8c2c8f8c19",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"28ef958b-ec3c-4742-b100-fd3708b64328",
	34,
	25);
INSERT INTO V_VAL
	VALUES ("28ef958b-ec3c-4742-b100-fd3708b64328",
	0,
	0,
	34,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("28ef958b-ec3c-4742-b100-fd3708b64328",
	'9');
INSERT INTO V_PAR
	VALUES ("28ef958b-ec3c-4742-b100-fd3708b64328",
	"aaf408bd-88a3-4efd-9b55-2b8c2c8f8c19",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	34,
	35);
INSERT INTO V_VAL
	VALUES ("eb23e1e8-b722-45fd-b79f-99ba46c927ac",
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("eb23e1e8-b722-45fd-b79f-99ba46c927ac",
	'9');
INSERT INTO V_PAR
	VALUES ("eb23e1e8-b722-45fd-b79f-99ba46c927ac",
	"892f898f-37e5-4b25-a39e-a49ba49c692c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"91f730c6-76e2-4d46-baa0-7be24fbcdc1e",
	36,
	18);
INSERT INTO V_VAL
	VALUES ("91f730c6-76e2-4d46-baa0-7be24fbcdc1e",
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("91f730c6-76e2-4d46-baa0-7be24fbcdc1e",
	'2');
INSERT INTO V_PAR
	VALUES ("91f730c6-76e2-4d46-baa0-7be24fbcdc1e",
	"892f898f-37e5-4b25-a39e-a49ba49c692c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f34bae09-614c-469a-9c9c-1f7c1baae640",
	36,
	25);
INSERT INTO V_VAL
	VALUES ("f34bae09-614c-469a-9c9c-1f7c1baae640",
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("f34bae09-614c-469a-9c9c-1f7c1baae640",
	'4');
INSERT INTO V_PAR
	VALUES ("f34bae09-614c-469a-9c9c-1f7c1baae640",
	"892f898f-37e5-4b25-a39e-a49ba49c692c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	36,
	35);
INSERT INTO V_VAL
	VALUES ("c27eb278-2e55-4ba9-a3b4-a370c1981eb7",
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("c27eb278-2e55-4ba9-a3b4-a370c1981eb7",
	'9');
INSERT INTO V_PAR
	VALUES ("c27eb278-2e55-4ba9-a3b4-a370c1981eb7",
	"1c940326-61c1-4193-b4dd-d5e98212d849",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"14ec8b31-7549-4ab1-845e-d8fbfc55f562",
	37,
	18);
INSERT INTO V_VAL
	VALUES ("14ec8b31-7549-4ab1-845e-d8fbfc55f562",
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("14ec8b31-7549-4ab1-845e-d8fbfc55f562",
	'4');
INSERT INTO V_PAR
	VALUES ("14ec8b31-7549-4ab1-845e-d8fbfc55f562",
	"1c940326-61c1-4193-b4dd-d5e98212d849",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"165e90ab-8def-4a1c-8a5f-c9808a584159",
	37,
	25);
INSERT INTO V_VAL
	VALUES ("165e90ab-8def-4a1c-8a5f-c9808a584159",
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("165e90ab-8def-4a1c-8a5f-c9808a584159",
	'5');
INSERT INTO V_PAR
	VALUES ("165e90ab-8def-4a1c-8a5f-c9808a584159",
	"1c940326-61c1-4193-b4dd-d5e98212d849",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	37,
	35);
INSERT INTO V_VAL
	VALUES ("217336a5-d5fd-424f-b4e1-e4f1b6ba30ca",
	0,
	0,
	38,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("217336a5-d5fd-424f-b4e1-e4f1b6ba30ca",
	'9');
INSERT INTO V_PAR
	VALUES ("217336a5-d5fd-424f-b4e1-e4f1b6ba30ca",
	"0777f999-f748-4300-a988-aca64144f77b",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"cebe016b-68dc-414b-90bd-c742371976b1",
	38,
	18);
INSERT INTO V_VAL
	VALUES ("cebe016b-68dc-414b-90bd-c742371976b1",
	0,
	0,
	38,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("cebe016b-68dc-414b-90bd-c742371976b1",
	'6');
INSERT INTO V_PAR
	VALUES ("cebe016b-68dc-414b-90bd-c742371976b1",
	"0777f999-f748-4300-a988-aca64144f77b",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"81a77b7f-2e1f-412a-b9fe-b04b94f06046",
	38,
	25);
INSERT INTO V_VAL
	VALUES ("81a77b7f-2e1f-412a-b9fe-b04b94f06046",
	0,
	0,
	38,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("81a77b7f-2e1f-412a-b9fe-b04b94f06046",
	'8');
INSERT INTO V_PAR
	VALUES ("81a77b7f-2e1f-412a-b9fe-b04b94f06046",
	"0777f999-f748-4300-a988-aca64144f77b",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	38,
	35);
INSERT INTO V_VAL
	VALUES ("8cf3b981-21e9-4fb3-8c4e-f12efe887a26",
	0,
	0,
	39,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("8cf3b981-21e9-4fb3-8c4e-f12efe887a26",
	'9');
INSERT INTO V_PAR
	VALUES ("8cf3b981-21e9-4fb3-8c4e-f12efe887a26",
	"b271be23-d56a-4782-963e-fc80c81485fa",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2518e69a-ee1d-4fc9-8de0-1007571ce562",
	39,
	18);
INSERT INTO V_VAL
	VALUES ("2518e69a-ee1d-4fc9-8de0-1007571ce562",
	0,
	0,
	39,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("2518e69a-ee1d-4fc9-8de0-1007571ce562",
	'8');
INSERT INTO V_PAR
	VALUES ("2518e69a-ee1d-4fc9-8de0-1007571ce562",
	"b271be23-d56a-4782-963e-fc80c81485fa",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"1d3e244a-3385-43ca-ad41-01a489fd70fe",
	39,
	25);
INSERT INTO V_VAL
	VALUES ("1d3e244a-3385-43ca-ad41-01a489fd70fe",
	0,
	0,
	39,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("1d3e244a-3385-43ca-ad41-01a489fd70fe",
	'7');
INSERT INTO V_PAR
	VALUES ("1d3e244a-3385-43ca-ad41-01a489fd70fe",
	"b271be23-d56a-4782-963e-fc80c81485fa",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	39,
	35);
INSERT INTO V_VAL
	VALUES ("0f09fd9c-10b3-472e-87ae-c13b5925bd8a",
	0,
	0,
	42,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("0f09fd9c-10b3-472e-87ae-c13b5925bd8a",
	'8');
INSERT INTO V_PAR
	VALUES ("0f09fd9c-10b3-472e-87ae-c13b5925bd8a",
	"bd6c7825-3c8c-43c2-b019-9b74d8d00dd1",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"32897163-f462-47f5-93ea-7e7bc26cda71",
	42,
	18);
INSERT INTO V_VAL
	VALUES ("32897163-f462-47f5-93ea-7e7bc26cda71",
	0,
	0,
	42,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("32897163-f462-47f5-93ea-7e7bc26cda71",
	'1');
INSERT INTO V_PAR
	VALUES ("32897163-f462-47f5-93ea-7e7bc26cda71",
	"bd6c7825-3c8c-43c2-b019-9b74d8d00dd1",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"64673ee2-edcd-4c82-b584-d856404ea37e",
	42,
	25);
INSERT INTO V_VAL
	VALUES ("64673ee2-edcd-4c82-b584-d856404ea37e",
	0,
	0,
	42,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"307464ab-75fe-4ba3-aed8-9178979b2cae");
INSERT INTO V_LIN
	VALUES ("64673ee2-edcd-4c82-b584-d856404ea37e",
	'3');
INSERT INTO V_PAR
	VALUES ("64673ee2-edcd-4c82-b584-d856404ea37e",
	"bd6c7825-3c8c-43c2-b019-9b74d8d00dd1",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	42,
	35);
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"e67fb7dd-e53c-4a9e-850f-6681083a26cf");
INSERT INTO S_SYNC
	VALUES ("e67fb7dd-e53c-4a9e-850f-6681083a26cf",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'setz3_given',
	'',
	'
CELL::set_given( row:1, column:2, answer:9 );
CELL::set_given( row:1, column:5, answer:6 );
CELL::set_given( row:1, column:6, answer:5 );

CELL::set_given( row:2, column:4, answer:3 );
CELL::set_given( row:2, column:7, answer:4 );
CELL::set_given( row:2, column:8, answer:9 );

CELL::set_given( row:3, column:2, answer:8 );
CELL::set_given( row:3, column:3, answer:3 );
CELL::set_given( row:3, column:7, answer:2 );

CELL::set_given( row:4, column:1, answer:3 );
CELL::set_given( row:4, column:4, answer:8 );
CELL::set_given( row:4, column:6, answer:4 );
CELL::set_given( row:4, column:9, answer:6 );

CELL::set_given( row:5, column:1, answer:1 );
CELL::set_given( row:5, column:9, answer:7 );

CELL::set_given( row:6, column:1, answer:5 );
CELL::set_given( row:6, column:4, answer:2 );
CELL::set_given( row:6, column:6, answer:3 );
CELL::set_given( row:6, column:9, answer:9 );

CELL::set_given( row:7, column:3, answer:4 );
CELL::set_given( row:7, column:7, answer:6 );
CELL::set_given( row:7, column:8, answer:1 );

CELL::set_given( row:8, column:2, answer:2 );
CELL::set_given( row:8, column:3, answer:7 );
CELL::set_given( row:8, column:6, answer:6 );

CELL::set_given( row:9, column:4, answer:9 );
CELL::set_given( row:9, column:5, answer:3 );
CELL::set_given( row:9, column:8, answer:8 );',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("7f217a15-760f-4364-9ad8-5d0f4d75c489",
	"e67fb7dd-e53c-4a9e-850f-6681083a26cf");
INSERT INTO ACT_ACT
	VALUES ("7f217a15-760f-4364-9ad8-5d0f4d75c489",
	'function',
	0,
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setz3_given',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	37,
	1,
	37,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7f217a15-760f-4364-9ad8-5d0f4d75c489",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f22cc5a4-3f1c-4ee1-9542-624885f67474",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"1c309649-6428-4144-adb8-b87ecc98234c",
	2,
	1,
	'setz3_given line: 2');
INSERT INTO ACT_TFM
	VALUES ("f22cc5a4-3f1c-4ee1-9542-624885f67474",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	2,
	7,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES ("1c309649-6428-4144-adb8-b87ecc98234c",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"597035d9-59c6-47fd-8b8d-e7462fbbd8f6",
	3,
	1,
	'setz3_given line: 3');
INSERT INTO ACT_TFM
	VALUES ("1c309649-6428-4144-adb8-b87ecc98234c",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES ("597035d9-59c6-47fd-8b8d-e7462fbbd8f6",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"8ddd163b-e286-4a86-9c7e-e1183eed7a00",
	4,
	1,
	'setz3_given line: 4');
INSERT INTO ACT_TFM
	VALUES ("597035d9-59c6-47fd-8b8d-e7462fbbd8f6",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES ("8ddd163b-e286-4a86-9c7e-e1183eed7a00",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"7c887f4f-d0fa-4c92-adbb-a65d3e8ad286",
	6,
	1,
	'setz3_given line: 6');
INSERT INTO ACT_TFM
	VALUES ("8ddd163b-e286-4a86-9c7e-e1183eed7a00",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	6,
	7,
	6,
	1);
INSERT INTO ACT_SMT
	VALUES ("7c887f4f-d0fa-4c92-adbb-a65d3e8ad286",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"e10a7046-55f4-427a-b029-8154942b6194",
	7,
	1,
	'setz3_given line: 7');
INSERT INTO ACT_TFM
	VALUES ("7c887f4f-d0fa-4c92-adbb-a65d3e8ad286",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES ("e10a7046-55f4-427a-b029-8154942b6194",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"6a05606c-89eb-4ca7-8f91-e13eb79be52e",
	8,
	1,
	'setz3_given line: 8');
INSERT INTO ACT_TFM
	VALUES ("e10a7046-55f4-427a-b029-8154942b6194",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES ("6a05606c-89eb-4ca7-8f91-e13eb79be52e",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"13348514-ed0e-4c41-8244-43daf9a9927a",
	10,
	1,
	'setz3_given line: 10');
INSERT INTO ACT_TFM
	VALUES ("6a05606c-89eb-4ca7-8f91-e13eb79be52e",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES ("13348514-ed0e-4c41-8244-43daf9a9927a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"7b209a7f-2f0d-4ef9-a8a8-2e37498cf29e",
	11,
	1,
	'setz3_given line: 11');
INSERT INTO ACT_TFM
	VALUES ("13348514-ed0e-4c41-8244-43daf9a9927a",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	11,
	7,
	11,
	1);
INSERT INTO ACT_SMT
	VALUES ("7b209a7f-2f0d-4ef9-a8a8-2e37498cf29e",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"169c358b-1928-4098-9b5a-03acc6917c1d",
	12,
	1,
	'setz3_given line: 12');
INSERT INTO ACT_TFM
	VALUES ("7b209a7f-2f0d-4ef9-a8a8-2e37498cf29e",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES ("169c358b-1928-4098-9b5a-03acc6917c1d",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"60e86784-dc11-4b56-b5f1-52d20a7dcce5",
	14,
	1,
	'setz3_given line: 14');
INSERT INTO ACT_TFM
	VALUES ("169c358b-1928-4098-9b5a-03acc6917c1d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	14,
	7,
	14,
	1);
INSERT INTO ACT_SMT
	VALUES ("60e86784-dc11-4b56-b5f1-52d20a7dcce5",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"a2a4452f-cffc-46c4-8152-344ab5b14218",
	15,
	1,
	'setz3_given line: 15');
INSERT INTO ACT_TFM
	VALUES ("60e86784-dc11-4b56-b5f1-52d20a7dcce5",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES ("a2a4452f-cffc-46c4-8152-344ab5b14218",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"da5dcdbb-dbcd-4716-974c-1c8c02f6f4ef",
	16,
	1,
	'setz3_given line: 16');
INSERT INTO ACT_TFM
	VALUES ("a2a4452f-cffc-46c4-8152-344ab5b14218",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	16,
	1);
INSERT INTO ACT_SMT
	VALUES ("da5dcdbb-dbcd-4716-974c-1c8c02f6f4ef",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"794ebc6e-77dc-416f-beb6-4f37d865238d",
	17,
	1,
	'setz3_given line: 17');
INSERT INTO ACT_TFM
	VALUES ("da5dcdbb-dbcd-4716-974c-1c8c02f6f4ef",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES ("794ebc6e-77dc-416f-beb6-4f37d865238d",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"d25e38bc-7e47-4c8d-ac62-c220d306e96c",
	19,
	1,
	'setz3_given line: 19');
INSERT INTO ACT_TFM
	VALUES ("794ebc6e-77dc-416f-beb6-4f37d865238d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	19,
	7,
	19,
	1);
INSERT INTO ACT_SMT
	VALUES ("d25e38bc-7e47-4c8d-ac62-c220d306e96c",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"e35e5be9-be97-4c53-9dc6-57b16433b224",
	20,
	1,
	'setz3_given line: 20');
INSERT INTO ACT_TFM
	VALUES ("d25e38bc-7e47-4c8d-ac62-c220d306e96c",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	20,
	7,
	20,
	1);
INSERT INTO ACT_SMT
	VALUES ("e35e5be9-be97-4c53-9dc6-57b16433b224",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"76eeba37-5e49-48dc-b940-895f1cf0173c",
	22,
	1,
	'setz3_given line: 22');
INSERT INTO ACT_TFM
	VALUES ("e35e5be9-be97-4c53-9dc6-57b16433b224",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	22,
	7,
	22,
	1);
INSERT INTO ACT_SMT
	VALUES ("76eeba37-5e49-48dc-b940-895f1cf0173c",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"f91a80ca-6f0a-4fdc-8f18-0123fe020c57",
	23,
	1,
	'setz3_given line: 23');
INSERT INTO ACT_TFM
	VALUES ("76eeba37-5e49-48dc-b940-895f1cf0173c",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES ("f91a80ca-6f0a-4fdc-8f18-0123fe020c57",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"990596bd-eefa-4522-8313-cc494831338e",
	24,
	1,
	'setz3_given line: 24');
INSERT INTO ACT_TFM
	VALUES ("f91a80ca-6f0a-4fdc-8f18-0123fe020c57",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES ("990596bd-eefa-4522-8313-cc494831338e",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"a82064c7-9a4b-4ebf-84e9-85385339096c",
	25,
	1,
	'setz3_given line: 25');
INSERT INTO ACT_TFM
	VALUES ("990596bd-eefa-4522-8313-cc494831338e",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	25,
	7,
	25,
	1);
INSERT INTO ACT_SMT
	VALUES ("a82064c7-9a4b-4ebf-84e9-85385339096c",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"3f9c3e47-3c36-48b8-8241-92a7ff3fa79d",
	27,
	1,
	'setz3_given line: 27');
INSERT INTO ACT_TFM
	VALUES ("a82064c7-9a4b-4ebf-84e9-85385339096c",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	27,
	7,
	27,
	1);
INSERT INTO ACT_SMT
	VALUES ("3f9c3e47-3c36-48b8-8241-92a7ff3fa79d",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"f3da4272-1b97-4311-bcfd-b5cb3da66890",
	28,
	1,
	'setz3_given line: 28');
INSERT INTO ACT_TFM
	VALUES ("3f9c3e47-3c36-48b8-8241-92a7ff3fa79d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	28,
	7,
	28,
	1);
INSERT INTO ACT_SMT
	VALUES ("f3da4272-1b97-4311-bcfd-b5cb3da66890",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"749e542f-b4f4-494d-bb8e-4c94e48ae18f",
	29,
	1,
	'setz3_given line: 29');
INSERT INTO ACT_TFM
	VALUES ("f3da4272-1b97-4311-bcfd-b5cb3da66890",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	29,
	7,
	29,
	1);
INSERT INTO ACT_SMT
	VALUES ("749e542f-b4f4-494d-bb8e-4c94e48ae18f",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"a3ceee8c-473f-4326-ae9d-ed18f8745035",
	31,
	1,
	'setz3_given line: 31');
INSERT INTO ACT_TFM
	VALUES ("749e542f-b4f4-494d-bb8e-4c94e48ae18f",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES ("a3ceee8c-473f-4326-ae9d-ed18f8745035",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"34138a03-4732-4eef-b0da-93d52c3d8a82",
	32,
	1,
	'setz3_given line: 32');
INSERT INTO ACT_TFM
	VALUES ("a3ceee8c-473f-4326-ae9d-ed18f8745035",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES ("34138a03-4732-4eef-b0da-93d52c3d8a82",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"3544d88f-62b2-42a3-971a-fe75ff7f9ceb",
	33,
	1,
	'setz3_given line: 33');
INSERT INTO ACT_TFM
	VALUES ("34138a03-4732-4eef-b0da-93d52c3d8a82",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES ("3544d88f-62b2-42a3-971a-fe75ff7f9ceb",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"5dfeb0d0-9d90-432f-8f8f-5ab333f0ac24",
	35,
	1,
	'setz3_given line: 35');
INSERT INTO ACT_TFM
	VALUES ("3544d88f-62b2-42a3-971a-fe75ff7f9ceb",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	35,
	7,
	35,
	1);
INSERT INTO ACT_SMT
	VALUES ("5dfeb0d0-9d90-432f-8f8f-5ab333f0ac24",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"46fd1a10-b963-4496-8a69-1a197f2da04a",
	36,
	1,
	'setz3_given line: 36');
INSERT INTO ACT_TFM
	VALUES ("5dfeb0d0-9d90-432f-8f8f-5ab333f0ac24",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES ("46fd1a10-b963-4496-8a69-1a197f2da04a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b",
	"00000000-0000-0000-0000-000000000000",
	37,
	1,
	'setz3_given line: 37');
INSERT INTO ACT_TFM
	VALUES ("46fd1a10-b963-4496-8a69-1a197f2da04a",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	37,
	7,
	37,
	1);
INSERT INTO V_VAL
	VALUES ("4ec7fc63-03eb-4385-8b8d-ddf47366dab0",
	0,
	0,
	2,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("4ec7fc63-03eb-4385-8b8d-ddf47366dab0",
	'1');
INSERT INTO V_PAR
	VALUES ("4ec7fc63-03eb-4385-8b8d-ddf47366dab0",
	"f22cc5a4-3f1c-4ee1-9542-624885f67474",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"d885a941-25bc-4a2c-8e6e-d85b75b12708",
	2,
	18);
INSERT INTO V_VAL
	VALUES ("d885a941-25bc-4a2c-8e6e-d85b75b12708",
	0,
	0,
	2,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("d885a941-25bc-4a2c-8e6e-d85b75b12708",
	'2');
INSERT INTO V_PAR
	VALUES ("d885a941-25bc-4a2c-8e6e-d85b75b12708",
	"f22cc5a4-3f1c-4ee1-9542-624885f67474",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"0a1f6540-6c22-4268-8295-164bea382147",
	2,
	25);
INSERT INTO V_VAL
	VALUES ("0a1f6540-6c22-4268-8295-164bea382147",
	0,
	0,
	2,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("0a1f6540-6c22-4268-8295-164bea382147",
	'9');
INSERT INTO V_PAR
	VALUES ("0a1f6540-6c22-4268-8295-164bea382147",
	"f22cc5a4-3f1c-4ee1-9542-624885f67474",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	2,
	35);
INSERT INTO V_VAL
	VALUES ("66ffe0b2-f237-49e1-9119-87bad66742e4",
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("66ffe0b2-f237-49e1-9119-87bad66742e4",
	'1');
INSERT INTO V_PAR
	VALUES ("66ffe0b2-f237-49e1-9119-87bad66742e4",
	"1c309649-6428-4144-adb8-b87ecc98234c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"9e99d604-05ea-47ed-ab38-9ed281e1db82",
	3,
	18);
INSERT INTO V_VAL
	VALUES ("9e99d604-05ea-47ed-ab38-9ed281e1db82",
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("9e99d604-05ea-47ed-ab38-9ed281e1db82",
	'5');
INSERT INTO V_PAR
	VALUES ("9e99d604-05ea-47ed-ab38-9ed281e1db82",
	"1c309649-6428-4144-adb8-b87ecc98234c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f77f8451-489e-4f38-b061-db25a2558a80",
	3,
	25);
INSERT INTO V_VAL
	VALUES ("f77f8451-489e-4f38-b061-db25a2558a80",
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("f77f8451-489e-4f38-b061-db25a2558a80",
	'6');
INSERT INTO V_PAR
	VALUES ("f77f8451-489e-4f38-b061-db25a2558a80",
	"1c309649-6428-4144-adb8-b87ecc98234c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	3,
	35);
INSERT INTO V_VAL
	VALUES ("6a681743-6ad6-484b-ac66-5886b13caf98",
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("6a681743-6ad6-484b-ac66-5886b13caf98",
	'1');
INSERT INTO V_PAR
	VALUES ("6a681743-6ad6-484b-ac66-5886b13caf98",
	"597035d9-59c6-47fd-8b8d-e7462fbbd8f6",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"9c2015ca-8b78-4a62-a553-b073c69f0142",
	4,
	18);
INSERT INTO V_VAL
	VALUES ("9c2015ca-8b78-4a62-a553-b073c69f0142",
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("9c2015ca-8b78-4a62-a553-b073c69f0142",
	'6');
INSERT INTO V_PAR
	VALUES ("9c2015ca-8b78-4a62-a553-b073c69f0142",
	"597035d9-59c6-47fd-8b8d-e7462fbbd8f6",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"af06f3c8-cbf3-430c-b947-0f75feb4a55a",
	4,
	25);
INSERT INTO V_VAL
	VALUES ("af06f3c8-cbf3-430c-b947-0f75feb4a55a",
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("af06f3c8-cbf3-430c-b947-0f75feb4a55a",
	'5');
INSERT INTO V_PAR
	VALUES ("af06f3c8-cbf3-430c-b947-0f75feb4a55a",
	"597035d9-59c6-47fd-8b8d-e7462fbbd8f6",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	4,
	35);
INSERT INTO V_VAL
	VALUES ("6e397919-afba-47b3-97f7-189a97eda6d0",
	0,
	0,
	6,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("6e397919-afba-47b3-97f7-189a97eda6d0",
	'2');
INSERT INTO V_PAR
	VALUES ("6e397919-afba-47b3-97f7-189a97eda6d0",
	"8ddd163b-e286-4a86-9c7e-e1183eed7a00",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"03213acd-55dc-448a-814d-0c02fd8605ca",
	6,
	18);
INSERT INTO V_VAL
	VALUES ("03213acd-55dc-448a-814d-0c02fd8605ca",
	0,
	0,
	6,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("03213acd-55dc-448a-814d-0c02fd8605ca",
	'4');
INSERT INTO V_PAR
	VALUES ("03213acd-55dc-448a-814d-0c02fd8605ca",
	"8ddd163b-e286-4a86-9c7e-e1183eed7a00",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8ec7bc6e-a574-4e53-a8eb-7b230c078257",
	6,
	25);
INSERT INTO V_VAL
	VALUES ("8ec7bc6e-a574-4e53-a8eb-7b230c078257",
	0,
	0,
	6,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("8ec7bc6e-a574-4e53-a8eb-7b230c078257",
	'3');
INSERT INTO V_PAR
	VALUES ("8ec7bc6e-a574-4e53-a8eb-7b230c078257",
	"8ddd163b-e286-4a86-9c7e-e1183eed7a00",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	6,
	35);
INSERT INTO V_VAL
	VALUES ("d2243ba8-a6a0-42a0-b0aa-2dc1ee475661",
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("d2243ba8-a6a0-42a0-b0aa-2dc1ee475661",
	'2');
INSERT INTO V_PAR
	VALUES ("d2243ba8-a6a0-42a0-b0aa-2dc1ee475661",
	"7c887f4f-d0fa-4c92-adbb-a65d3e8ad286",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"0469ac7f-9d87-4fdd-a5e9-8db2d42e47a4",
	7,
	18);
INSERT INTO V_VAL
	VALUES ("0469ac7f-9d87-4fdd-a5e9-8db2d42e47a4",
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("0469ac7f-9d87-4fdd-a5e9-8db2d42e47a4",
	'7');
INSERT INTO V_PAR
	VALUES ("0469ac7f-9d87-4fdd-a5e9-8db2d42e47a4",
	"7c887f4f-d0fa-4c92-adbb-a65d3e8ad286",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"6711d69c-0338-4997-bba5-c89f994fdc8d",
	7,
	25);
INSERT INTO V_VAL
	VALUES ("6711d69c-0338-4997-bba5-c89f994fdc8d",
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("6711d69c-0338-4997-bba5-c89f994fdc8d",
	'4');
INSERT INTO V_PAR
	VALUES ("6711d69c-0338-4997-bba5-c89f994fdc8d",
	"7c887f4f-d0fa-4c92-adbb-a65d3e8ad286",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	7,
	35);
INSERT INTO V_VAL
	VALUES ("d6427557-e0f4-4497-a6b0-604de102eb86",
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("d6427557-e0f4-4497-a6b0-604de102eb86",
	'2');
INSERT INTO V_PAR
	VALUES ("d6427557-e0f4-4497-a6b0-604de102eb86",
	"e10a7046-55f4-427a-b029-8154942b6194",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"06fcfd54-7ce7-40a6-b4bd-201671acdc65",
	8,
	18);
INSERT INTO V_VAL
	VALUES ("06fcfd54-7ce7-40a6-b4bd-201671acdc65",
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("06fcfd54-7ce7-40a6-b4bd-201671acdc65",
	'8');
INSERT INTO V_PAR
	VALUES ("06fcfd54-7ce7-40a6-b4bd-201671acdc65",
	"e10a7046-55f4-427a-b029-8154942b6194",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"71bdd6af-cc17-4f2d-8d1b-77899dd3f3a0",
	8,
	25);
INSERT INTO V_VAL
	VALUES ("71bdd6af-cc17-4f2d-8d1b-77899dd3f3a0",
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("71bdd6af-cc17-4f2d-8d1b-77899dd3f3a0",
	'9');
INSERT INTO V_PAR
	VALUES ("71bdd6af-cc17-4f2d-8d1b-77899dd3f3a0",
	"e10a7046-55f4-427a-b029-8154942b6194",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	8,
	35);
INSERT INTO V_VAL
	VALUES ("a2463384-b693-4ce2-90c3-aa47e98b6c9c",
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("a2463384-b693-4ce2-90c3-aa47e98b6c9c",
	'3');
INSERT INTO V_PAR
	VALUES ("a2463384-b693-4ce2-90c3-aa47e98b6c9c",
	"6a05606c-89eb-4ca7-8f91-e13eb79be52e",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"86c5fd99-c548-4f34-9e89-60eb14f0cfc0",
	10,
	18);
INSERT INTO V_VAL
	VALUES ("86c5fd99-c548-4f34-9e89-60eb14f0cfc0",
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("86c5fd99-c548-4f34-9e89-60eb14f0cfc0",
	'2');
INSERT INTO V_PAR
	VALUES ("86c5fd99-c548-4f34-9e89-60eb14f0cfc0",
	"6a05606c-89eb-4ca7-8f91-e13eb79be52e",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"3f99330d-4a59-475b-8c05-8c1ca3779098",
	10,
	25);
INSERT INTO V_VAL
	VALUES ("3f99330d-4a59-475b-8c05-8c1ca3779098",
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("3f99330d-4a59-475b-8c05-8c1ca3779098",
	'8');
INSERT INTO V_PAR
	VALUES ("3f99330d-4a59-475b-8c05-8c1ca3779098",
	"6a05606c-89eb-4ca7-8f91-e13eb79be52e",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	10,
	35);
INSERT INTO V_VAL
	VALUES ("78e0c605-aac0-4c08-83ec-3d68506c2b74",
	0,
	0,
	11,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("78e0c605-aac0-4c08-83ec-3d68506c2b74",
	'3');
INSERT INTO V_PAR
	VALUES ("78e0c605-aac0-4c08-83ec-3d68506c2b74",
	"13348514-ed0e-4c41-8244-43daf9a9927a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"2a956d97-998e-4cd2-a455-167414d29ffd",
	11,
	18);
INSERT INTO V_VAL
	VALUES ("2a956d97-998e-4cd2-a455-167414d29ffd",
	0,
	0,
	11,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("2a956d97-998e-4cd2-a455-167414d29ffd",
	'3');
INSERT INTO V_PAR
	VALUES ("2a956d97-998e-4cd2-a455-167414d29ffd",
	"13348514-ed0e-4c41-8244-43daf9a9927a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"21a6b0e9-7be5-4b58-9424-31c8671caad5",
	11,
	25);
INSERT INTO V_VAL
	VALUES ("21a6b0e9-7be5-4b58-9424-31c8671caad5",
	0,
	0,
	11,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("21a6b0e9-7be5-4b58-9424-31c8671caad5",
	'3');
INSERT INTO V_PAR
	VALUES ("21a6b0e9-7be5-4b58-9424-31c8671caad5",
	"13348514-ed0e-4c41-8244-43daf9a9927a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	11,
	35);
INSERT INTO V_VAL
	VALUES ("212c29fd-0fca-4bcb-8c40-6b3f4823d58c",
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("212c29fd-0fca-4bcb-8c40-6b3f4823d58c",
	'3');
INSERT INTO V_PAR
	VALUES ("212c29fd-0fca-4bcb-8c40-6b3f4823d58c",
	"7b209a7f-2f0d-4ef9-a8a8-2e37498cf29e",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"45c46b81-23db-4db3-8e5e-1c4a2acec4ba",
	12,
	18);
INSERT INTO V_VAL
	VALUES ("45c46b81-23db-4db3-8e5e-1c4a2acec4ba",
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("45c46b81-23db-4db3-8e5e-1c4a2acec4ba",
	'7');
INSERT INTO V_PAR
	VALUES ("45c46b81-23db-4db3-8e5e-1c4a2acec4ba",
	"7b209a7f-2f0d-4ef9-a8a8-2e37498cf29e",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"ff92c2c7-0e58-49ef-95b9-c13c17f7045e",
	12,
	25);
INSERT INTO V_VAL
	VALUES ("ff92c2c7-0e58-49ef-95b9-c13c17f7045e",
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("ff92c2c7-0e58-49ef-95b9-c13c17f7045e",
	'2');
INSERT INTO V_PAR
	VALUES ("ff92c2c7-0e58-49ef-95b9-c13c17f7045e",
	"7b209a7f-2f0d-4ef9-a8a8-2e37498cf29e",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	12,
	35);
INSERT INTO V_VAL
	VALUES ("f47fef99-5949-4f3d-b440-4104f42fddd8",
	0,
	0,
	14,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("f47fef99-5949-4f3d-b440-4104f42fddd8",
	'4');
INSERT INTO V_PAR
	VALUES ("f47fef99-5949-4f3d-b440-4104f42fddd8",
	"169c358b-1928-4098-9b5a-03acc6917c1d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"39e8eb5e-9c1a-4a10-b9e0-afac5da728a2",
	14,
	18);
INSERT INTO V_VAL
	VALUES ("39e8eb5e-9c1a-4a10-b9e0-afac5da728a2",
	0,
	0,
	14,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("39e8eb5e-9c1a-4a10-b9e0-afac5da728a2",
	'1');
INSERT INTO V_PAR
	VALUES ("39e8eb5e-9c1a-4a10-b9e0-afac5da728a2",
	"169c358b-1928-4098-9b5a-03acc6917c1d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"a21c6d8c-9f01-421a-9035-b7315400e7c8",
	14,
	25);
INSERT INTO V_VAL
	VALUES ("a21c6d8c-9f01-421a-9035-b7315400e7c8",
	0,
	0,
	14,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("a21c6d8c-9f01-421a-9035-b7315400e7c8",
	'3');
INSERT INTO V_PAR
	VALUES ("a21c6d8c-9f01-421a-9035-b7315400e7c8",
	"169c358b-1928-4098-9b5a-03acc6917c1d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	14,
	35);
INSERT INTO V_VAL
	VALUES ("ba8a58d0-5097-4b04-a661-abb43f6b5cda",
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("ba8a58d0-5097-4b04-a661-abb43f6b5cda",
	'4');
INSERT INTO V_PAR
	VALUES ("ba8a58d0-5097-4b04-a661-abb43f6b5cda",
	"60e86784-dc11-4b56-b5f1-52d20a7dcce5",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"dd862393-1615-41e9-86a6-9364cb3672f3",
	15,
	18);
INSERT INTO V_VAL
	VALUES ("dd862393-1615-41e9-86a6-9364cb3672f3",
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("dd862393-1615-41e9-86a6-9364cb3672f3",
	'4');
INSERT INTO V_PAR
	VALUES ("dd862393-1615-41e9-86a6-9364cb3672f3",
	"60e86784-dc11-4b56-b5f1-52d20a7dcce5",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f7e49200-33d4-4445-a3f4-77ca86a99a0e",
	15,
	25);
INSERT INTO V_VAL
	VALUES ("f7e49200-33d4-4445-a3f4-77ca86a99a0e",
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("f7e49200-33d4-4445-a3f4-77ca86a99a0e",
	'8');
INSERT INTO V_PAR
	VALUES ("f7e49200-33d4-4445-a3f4-77ca86a99a0e",
	"60e86784-dc11-4b56-b5f1-52d20a7dcce5",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	15,
	35);
INSERT INTO V_VAL
	VALUES ("7366f696-673a-41cc-9c1c-f09cc3b37d6f",
	0,
	0,
	16,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("7366f696-673a-41cc-9c1c-f09cc3b37d6f",
	'4');
INSERT INTO V_PAR
	VALUES ("7366f696-673a-41cc-9c1c-f09cc3b37d6f",
	"a2a4452f-cffc-46c4-8152-344ab5b14218",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"c5a0f388-b1f5-480b-9644-d68d3a67891a",
	16,
	18);
INSERT INTO V_VAL
	VALUES ("c5a0f388-b1f5-480b-9644-d68d3a67891a",
	0,
	0,
	16,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("c5a0f388-b1f5-480b-9644-d68d3a67891a",
	'6');
INSERT INTO V_PAR
	VALUES ("c5a0f388-b1f5-480b-9644-d68d3a67891a",
	"a2a4452f-cffc-46c4-8152-344ab5b14218",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"dde4ebe0-276c-425f-a09e-568a12109067",
	16,
	25);
INSERT INTO V_VAL
	VALUES ("dde4ebe0-276c-425f-a09e-568a12109067",
	0,
	0,
	16,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("dde4ebe0-276c-425f-a09e-568a12109067",
	'4');
INSERT INTO V_PAR
	VALUES ("dde4ebe0-276c-425f-a09e-568a12109067",
	"a2a4452f-cffc-46c4-8152-344ab5b14218",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	16,
	35);
INSERT INTO V_VAL
	VALUES ("7192f5e0-3a9e-4847-a0fa-876f89b0fb72",
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("7192f5e0-3a9e-4847-a0fa-876f89b0fb72",
	'4');
INSERT INTO V_PAR
	VALUES ("7192f5e0-3a9e-4847-a0fa-876f89b0fb72",
	"da5dcdbb-dbcd-4716-974c-1c8c02f6f4ef",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"801ab369-9eed-495e-a908-3ddca6539d8c",
	17,
	18);
INSERT INTO V_VAL
	VALUES ("801ab369-9eed-495e-a908-3ddca6539d8c",
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("801ab369-9eed-495e-a908-3ddca6539d8c",
	'9');
INSERT INTO V_PAR
	VALUES ("801ab369-9eed-495e-a908-3ddca6539d8c",
	"da5dcdbb-dbcd-4716-974c-1c8c02f6f4ef",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"9eb3be52-1bba-47ed-be1a-8c3bf20f9f81",
	17,
	25);
INSERT INTO V_VAL
	VALUES ("9eb3be52-1bba-47ed-be1a-8c3bf20f9f81",
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("9eb3be52-1bba-47ed-be1a-8c3bf20f9f81",
	'6');
INSERT INTO V_PAR
	VALUES ("9eb3be52-1bba-47ed-be1a-8c3bf20f9f81",
	"da5dcdbb-dbcd-4716-974c-1c8c02f6f4ef",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	17,
	35);
INSERT INTO V_VAL
	VALUES ("64fccd11-d7e9-4f8f-95fb-72ea5ee0e222",
	0,
	0,
	19,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("64fccd11-d7e9-4f8f-95fb-72ea5ee0e222",
	'5');
INSERT INTO V_PAR
	VALUES ("64fccd11-d7e9-4f8f-95fb-72ea5ee0e222",
	"794ebc6e-77dc-416f-beb6-4f37d865238d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"d9b10906-f49c-44ce-b8ff-532d2eea4cc0",
	19,
	18);
INSERT INTO V_VAL
	VALUES ("d9b10906-f49c-44ce-b8ff-532d2eea4cc0",
	0,
	0,
	19,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("d9b10906-f49c-44ce-b8ff-532d2eea4cc0",
	'1');
INSERT INTO V_PAR
	VALUES ("d9b10906-f49c-44ce-b8ff-532d2eea4cc0",
	"794ebc6e-77dc-416f-beb6-4f37d865238d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"3e47e87f-a416-4646-bdb9-8035df6608ad",
	19,
	25);
INSERT INTO V_VAL
	VALUES ("3e47e87f-a416-4646-bdb9-8035df6608ad",
	0,
	0,
	19,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("3e47e87f-a416-4646-bdb9-8035df6608ad",
	'1');
INSERT INTO V_PAR
	VALUES ("3e47e87f-a416-4646-bdb9-8035df6608ad",
	"794ebc6e-77dc-416f-beb6-4f37d865238d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	19,
	35);
INSERT INTO V_VAL
	VALUES ("7c44fa35-3fb4-4c3a-a9c7-89aa083e05b2",
	0,
	0,
	20,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("7c44fa35-3fb4-4c3a-a9c7-89aa083e05b2",
	'5');
INSERT INTO V_PAR
	VALUES ("7c44fa35-3fb4-4c3a-a9c7-89aa083e05b2",
	"d25e38bc-7e47-4c8d-ac62-c220d306e96c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"306d9368-d281-4763-8e51-e146e7e31420",
	20,
	18);
INSERT INTO V_VAL
	VALUES ("306d9368-d281-4763-8e51-e146e7e31420",
	0,
	0,
	20,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("306d9368-d281-4763-8e51-e146e7e31420",
	'9');
INSERT INTO V_PAR
	VALUES ("306d9368-d281-4763-8e51-e146e7e31420",
	"d25e38bc-7e47-4c8d-ac62-c220d306e96c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"e1270242-45fa-4702-9194-fd13c37c896a",
	20,
	25);
INSERT INTO V_VAL
	VALUES ("e1270242-45fa-4702-9194-fd13c37c896a",
	0,
	0,
	20,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("e1270242-45fa-4702-9194-fd13c37c896a",
	'7');
INSERT INTO V_PAR
	VALUES ("e1270242-45fa-4702-9194-fd13c37c896a",
	"d25e38bc-7e47-4c8d-ac62-c220d306e96c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	20,
	35);
INSERT INTO V_VAL
	VALUES ("f00b9592-e86a-4fab-8afc-8196734998b7",
	0,
	0,
	22,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("f00b9592-e86a-4fab-8afc-8196734998b7",
	'6');
INSERT INTO V_PAR
	VALUES ("f00b9592-e86a-4fab-8afc-8196734998b7",
	"e35e5be9-be97-4c53-9dc6-57b16433b224",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"ec0a8473-ef84-475d-a590-1bfbad831574",
	22,
	18);
INSERT INTO V_VAL
	VALUES ("ec0a8473-ef84-475d-a590-1bfbad831574",
	0,
	0,
	22,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("ec0a8473-ef84-475d-a590-1bfbad831574",
	'1');
INSERT INTO V_PAR
	VALUES ("ec0a8473-ef84-475d-a590-1bfbad831574",
	"e35e5be9-be97-4c53-9dc6-57b16433b224",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"ffe4012d-15bb-49b9-91f9-a771e96be249",
	22,
	25);
INSERT INTO V_VAL
	VALUES ("ffe4012d-15bb-49b9-91f9-a771e96be249",
	0,
	0,
	22,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("ffe4012d-15bb-49b9-91f9-a771e96be249",
	'5');
INSERT INTO V_PAR
	VALUES ("ffe4012d-15bb-49b9-91f9-a771e96be249",
	"e35e5be9-be97-4c53-9dc6-57b16433b224",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	22,
	35);
INSERT INTO V_VAL
	VALUES ("a07df02b-2d29-4936-aaa7-f7d4037f1800",
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("a07df02b-2d29-4936-aaa7-f7d4037f1800",
	'6');
INSERT INTO V_PAR
	VALUES ("a07df02b-2d29-4936-aaa7-f7d4037f1800",
	"76eeba37-5e49-48dc-b940-895f1cf0173c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"42cb469b-b5ea-4a56-802b-e9ebd6386f9c",
	23,
	18);
INSERT INTO V_VAL
	VALUES ("42cb469b-b5ea-4a56-802b-e9ebd6386f9c",
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("42cb469b-b5ea-4a56-802b-e9ebd6386f9c",
	'4');
INSERT INTO V_PAR
	VALUES ("42cb469b-b5ea-4a56-802b-e9ebd6386f9c",
	"76eeba37-5e49-48dc-b940-895f1cf0173c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"2a2369e4-f430-4dd4-98e3-d14ec5eeee10",
	23,
	25);
INSERT INTO V_VAL
	VALUES ("2a2369e4-f430-4dd4-98e3-d14ec5eeee10",
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("2a2369e4-f430-4dd4-98e3-d14ec5eeee10",
	'2');
INSERT INTO V_PAR
	VALUES ("2a2369e4-f430-4dd4-98e3-d14ec5eeee10",
	"76eeba37-5e49-48dc-b940-895f1cf0173c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	23,
	35);
INSERT INTO V_VAL
	VALUES ("206a6dd5-deba-445d-8d97-fbac8018fce2",
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("206a6dd5-deba-445d-8d97-fbac8018fce2",
	'6');
INSERT INTO V_PAR
	VALUES ("206a6dd5-deba-445d-8d97-fbac8018fce2",
	"f91a80ca-6f0a-4fdc-8f18-0123fe020c57",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"dde9d231-0eae-4199-a904-2413f16ac036",
	24,
	18);
INSERT INTO V_VAL
	VALUES ("dde9d231-0eae-4199-a904-2413f16ac036",
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("dde9d231-0eae-4199-a904-2413f16ac036",
	'6');
INSERT INTO V_PAR
	VALUES ("dde9d231-0eae-4199-a904-2413f16ac036",
	"f91a80ca-6f0a-4fdc-8f18-0123fe020c57",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"aa2a1c58-a277-4654-ad55-57f132d0292f",
	24,
	25);
INSERT INTO V_VAL
	VALUES ("aa2a1c58-a277-4654-ad55-57f132d0292f",
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("aa2a1c58-a277-4654-ad55-57f132d0292f",
	'3');
INSERT INTO V_PAR
	VALUES ("aa2a1c58-a277-4654-ad55-57f132d0292f",
	"f91a80ca-6f0a-4fdc-8f18-0123fe020c57",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	24,
	35);
INSERT INTO V_VAL
	VALUES ("5894fad8-72ad-49e8-9fff-d7abdb81622c",
	0,
	0,
	25,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("5894fad8-72ad-49e8-9fff-d7abdb81622c",
	'6');
INSERT INTO V_PAR
	VALUES ("5894fad8-72ad-49e8-9fff-d7abdb81622c",
	"990596bd-eefa-4522-8313-cc494831338e",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"44b7bb10-bb8d-4409-b9d4-f11d3094c660",
	25,
	18);
INSERT INTO V_VAL
	VALUES ("44b7bb10-bb8d-4409-b9d4-f11d3094c660",
	0,
	0,
	25,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("44b7bb10-bb8d-4409-b9d4-f11d3094c660",
	'9');
INSERT INTO V_PAR
	VALUES ("44b7bb10-bb8d-4409-b9d4-f11d3094c660",
	"990596bd-eefa-4522-8313-cc494831338e",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"c3a98bc8-8cd2-4c70-852f-194c992d6fe8",
	25,
	25);
INSERT INTO V_VAL
	VALUES ("c3a98bc8-8cd2-4c70-852f-194c992d6fe8",
	0,
	0,
	25,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("c3a98bc8-8cd2-4c70-852f-194c992d6fe8",
	'9');
INSERT INTO V_PAR
	VALUES ("c3a98bc8-8cd2-4c70-852f-194c992d6fe8",
	"990596bd-eefa-4522-8313-cc494831338e",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	25,
	35);
INSERT INTO V_VAL
	VALUES ("30abe244-1418-4800-a466-1a75c4257516",
	0,
	0,
	27,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("30abe244-1418-4800-a466-1a75c4257516",
	'7');
INSERT INTO V_PAR
	VALUES ("30abe244-1418-4800-a466-1a75c4257516",
	"a82064c7-9a4b-4ebf-84e9-85385339096c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"568e9eab-d2e4-4ed5-b8aa-722725ce52f5",
	27,
	18);
INSERT INTO V_VAL
	VALUES ("568e9eab-d2e4-4ed5-b8aa-722725ce52f5",
	0,
	0,
	27,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("568e9eab-d2e4-4ed5-b8aa-722725ce52f5",
	'3');
INSERT INTO V_PAR
	VALUES ("568e9eab-d2e4-4ed5-b8aa-722725ce52f5",
	"a82064c7-9a4b-4ebf-84e9-85385339096c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"7866cb0b-3db6-4ce2-b07a-b21698910df7",
	27,
	25);
INSERT INTO V_VAL
	VALUES ("7866cb0b-3db6-4ce2-b07a-b21698910df7",
	0,
	0,
	27,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("7866cb0b-3db6-4ce2-b07a-b21698910df7",
	'4');
INSERT INTO V_PAR
	VALUES ("7866cb0b-3db6-4ce2-b07a-b21698910df7",
	"a82064c7-9a4b-4ebf-84e9-85385339096c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	27,
	35);
INSERT INTO V_VAL
	VALUES ("fe4a9546-a5d0-409e-be70-15b6740d88d9",
	0,
	0,
	28,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("fe4a9546-a5d0-409e-be70-15b6740d88d9",
	'7');
INSERT INTO V_PAR
	VALUES ("fe4a9546-a5d0-409e-be70-15b6740d88d9",
	"3f9c3e47-3c36-48b8-8241-92a7ff3fa79d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"76b19029-3b5d-404c-81d4-5d4618948fd1",
	28,
	18);
INSERT INTO V_VAL
	VALUES ("76b19029-3b5d-404c-81d4-5d4618948fd1",
	0,
	0,
	28,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("76b19029-3b5d-404c-81d4-5d4618948fd1",
	'7');
INSERT INTO V_PAR
	VALUES ("76b19029-3b5d-404c-81d4-5d4618948fd1",
	"3f9c3e47-3c36-48b8-8241-92a7ff3fa79d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"31dd49f4-d1ae-4777-9e1f-4ab346c07ee6",
	28,
	25);
INSERT INTO V_VAL
	VALUES ("31dd49f4-d1ae-4777-9e1f-4ab346c07ee6",
	0,
	0,
	28,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("31dd49f4-d1ae-4777-9e1f-4ab346c07ee6",
	'6');
INSERT INTO V_PAR
	VALUES ("31dd49f4-d1ae-4777-9e1f-4ab346c07ee6",
	"3f9c3e47-3c36-48b8-8241-92a7ff3fa79d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	28,
	35);
INSERT INTO V_VAL
	VALUES ("6920ab48-5491-4adb-823b-124e7e55f8f4",
	0,
	0,
	29,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("6920ab48-5491-4adb-823b-124e7e55f8f4",
	'7');
INSERT INTO V_PAR
	VALUES ("6920ab48-5491-4adb-823b-124e7e55f8f4",
	"f3da4272-1b97-4311-bcfd-b5cb3da66890",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"c33ce722-4ec6-4c29-98cf-dd5cf2f467f1",
	29,
	18);
INSERT INTO V_VAL
	VALUES ("c33ce722-4ec6-4c29-98cf-dd5cf2f467f1",
	0,
	0,
	29,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("c33ce722-4ec6-4c29-98cf-dd5cf2f467f1",
	'8');
INSERT INTO V_PAR
	VALUES ("c33ce722-4ec6-4c29-98cf-dd5cf2f467f1",
	"f3da4272-1b97-4311-bcfd-b5cb3da66890",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"39d7fdf7-1795-4b65-8f85-2d1a206032ae",
	29,
	25);
INSERT INTO V_VAL
	VALUES ("39d7fdf7-1795-4b65-8f85-2d1a206032ae",
	0,
	0,
	29,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("39d7fdf7-1795-4b65-8f85-2d1a206032ae",
	'1');
INSERT INTO V_PAR
	VALUES ("39d7fdf7-1795-4b65-8f85-2d1a206032ae",
	"f3da4272-1b97-4311-bcfd-b5cb3da66890",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	29,
	35);
INSERT INTO V_VAL
	VALUES ("9b56f464-2e7e-48f2-96cb-306af21bd5ae",
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("9b56f464-2e7e-48f2-96cb-306af21bd5ae",
	'8');
INSERT INTO V_PAR
	VALUES ("9b56f464-2e7e-48f2-96cb-306af21bd5ae",
	"749e542f-b4f4-494d-bb8e-4c94e48ae18f",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"29a5e2a0-8d37-47a8-b8f3-81edc345416c",
	31,
	18);
INSERT INTO V_VAL
	VALUES ("29a5e2a0-8d37-47a8-b8f3-81edc345416c",
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("29a5e2a0-8d37-47a8-b8f3-81edc345416c",
	'2');
INSERT INTO V_PAR
	VALUES ("29a5e2a0-8d37-47a8-b8f3-81edc345416c",
	"749e542f-b4f4-494d-bb8e-4c94e48ae18f",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"4dc9a9b5-4bfc-4889-9bfe-d46ee9e8f498",
	31,
	25);
INSERT INTO V_VAL
	VALUES ("4dc9a9b5-4bfc-4889-9bfe-d46ee9e8f498",
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("4dc9a9b5-4bfc-4889-9bfe-d46ee9e8f498",
	'2');
INSERT INTO V_PAR
	VALUES ("4dc9a9b5-4bfc-4889-9bfe-d46ee9e8f498",
	"749e542f-b4f4-494d-bb8e-4c94e48ae18f",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	31,
	35);
INSERT INTO V_VAL
	VALUES ("6e779e1c-8252-4b5c-a46d-416c7e6fd508",
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("6e779e1c-8252-4b5c-a46d-416c7e6fd508",
	'8');
INSERT INTO V_PAR
	VALUES ("6e779e1c-8252-4b5c-a46d-416c7e6fd508",
	"a3ceee8c-473f-4326-ae9d-ed18f8745035",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"61794897-ee90-4e47-a745-2f48039be8c7",
	32,
	18);
INSERT INTO V_VAL
	VALUES ("61794897-ee90-4e47-a745-2f48039be8c7",
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("61794897-ee90-4e47-a745-2f48039be8c7",
	'3');
INSERT INTO V_PAR
	VALUES ("61794897-ee90-4e47-a745-2f48039be8c7",
	"a3ceee8c-473f-4326-ae9d-ed18f8745035",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"b3a45c3c-eaaf-455d-a861-093ae0840277",
	32,
	25);
INSERT INTO V_VAL
	VALUES ("b3a45c3c-eaaf-455d-a861-093ae0840277",
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("b3a45c3c-eaaf-455d-a861-093ae0840277",
	'7');
INSERT INTO V_PAR
	VALUES ("b3a45c3c-eaaf-455d-a861-093ae0840277",
	"a3ceee8c-473f-4326-ae9d-ed18f8745035",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	32,
	35);
INSERT INTO V_VAL
	VALUES ("a3fbd8aa-7670-40ea-9d79-623b89af6963",
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("a3fbd8aa-7670-40ea-9d79-623b89af6963",
	'8');
INSERT INTO V_PAR
	VALUES ("a3fbd8aa-7670-40ea-9d79-623b89af6963",
	"34138a03-4732-4eef-b0da-93d52c3d8a82",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7db915ab-6b0c-4506-b7c7-f98e8a1adce4",
	33,
	18);
INSERT INTO V_VAL
	VALUES ("7db915ab-6b0c-4506-b7c7-f98e8a1adce4",
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("7db915ab-6b0c-4506-b7c7-f98e8a1adce4",
	'6');
INSERT INTO V_PAR
	VALUES ("7db915ab-6b0c-4506-b7c7-f98e8a1adce4",
	"34138a03-4732-4eef-b0da-93d52c3d8a82",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"be18d8eb-9f22-4180-8f4b-4caebde7f5af",
	33,
	25);
INSERT INTO V_VAL
	VALUES ("be18d8eb-9f22-4180-8f4b-4caebde7f5af",
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("be18d8eb-9f22-4180-8f4b-4caebde7f5af",
	'6');
INSERT INTO V_PAR
	VALUES ("be18d8eb-9f22-4180-8f4b-4caebde7f5af",
	"34138a03-4732-4eef-b0da-93d52c3d8a82",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	33,
	35);
INSERT INTO V_VAL
	VALUES ("e024b3fd-ed0d-48bf-8885-97a1f69ceee8",
	0,
	0,
	35,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("e024b3fd-ed0d-48bf-8885-97a1f69ceee8",
	'9');
INSERT INTO V_PAR
	VALUES ("e024b3fd-ed0d-48bf-8885-97a1f69ceee8",
	"3544d88f-62b2-42a3-971a-fe75ff7f9ceb",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"77f8d9a7-ae80-4678-8dc2-ce3de723be89",
	35,
	18);
INSERT INTO V_VAL
	VALUES ("77f8d9a7-ae80-4678-8dc2-ce3de723be89",
	0,
	0,
	35,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("77f8d9a7-ae80-4678-8dc2-ce3de723be89",
	'4');
INSERT INTO V_PAR
	VALUES ("77f8d9a7-ae80-4678-8dc2-ce3de723be89",
	"3544d88f-62b2-42a3-971a-fe75ff7f9ceb",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"a86f519f-1bdc-43c9-9bdc-f37064efee66",
	35,
	25);
INSERT INTO V_VAL
	VALUES ("a86f519f-1bdc-43c9-9bdc-f37064efee66",
	0,
	0,
	35,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("a86f519f-1bdc-43c9-9bdc-f37064efee66",
	'9');
INSERT INTO V_PAR
	VALUES ("a86f519f-1bdc-43c9-9bdc-f37064efee66",
	"3544d88f-62b2-42a3-971a-fe75ff7f9ceb",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	35,
	35);
INSERT INTO V_VAL
	VALUES ("7fdf6d74-7ae9-4bf4-a974-33247f25c6ff",
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("7fdf6d74-7ae9-4bf4-a974-33247f25c6ff",
	'9');
INSERT INTO V_PAR
	VALUES ("7fdf6d74-7ae9-4bf4-a974-33247f25c6ff",
	"5dfeb0d0-9d90-432f-8f8f-5ab333f0ac24",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"03ba9b9c-46c2-4aa6-a051-ee3192f181db",
	36,
	18);
INSERT INTO V_VAL
	VALUES ("03ba9b9c-46c2-4aa6-a051-ee3192f181db",
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("03ba9b9c-46c2-4aa6-a051-ee3192f181db",
	'5');
INSERT INTO V_PAR
	VALUES ("03ba9b9c-46c2-4aa6-a051-ee3192f181db",
	"5dfeb0d0-9d90-432f-8f8f-5ab333f0ac24",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8f2619ab-00db-4f4d-8d1d-d3cf811a0d95",
	36,
	25);
INSERT INTO V_VAL
	VALUES ("8f2619ab-00db-4f4d-8d1d-d3cf811a0d95",
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("8f2619ab-00db-4f4d-8d1d-d3cf811a0d95",
	'3');
INSERT INTO V_PAR
	VALUES ("8f2619ab-00db-4f4d-8d1d-d3cf811a0d95",
	"5dfeb0d0-9d90-432f-8f8f-5ab333f0ac24",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	36,
	35);
INSERT INTO V_VAL
	VALUES ("c33527ef-f794-4b78-b2c6-256d13dbb360",
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("c33527ef-f794-4b78-b2c6-256d13dbb360",
	'9');
INSERT INTO V_PAR
	VALUES ("c33527ef-f794-4b78-b2c6-256d13dbb360",
	"46fd1a10-b963-4496-8a69-1a197f2da04a",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"1df3b24e-bfba-4dac-8c7e-b1f1fbba33ee",
	37,
	18);
INSERT INTO V_VAL
	VALUES ("1df3b24e-bfba-4dac-8c7e-b1f1fbba33ee",
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("1df3b24e-bfba-4dac-8c7e-b1f1fbba33ee",
	'8');
INSERT INTO V_PAR
	VALUES ("1df3b24e-bfba-4dac-8c7e-b1f1fbba33ee",
	"46fd1a10-b963-4496-8a69-1a197f2da04a",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"b207898e-886c-49c4-ae4d-5ee131c145f4",
	37,
	25);
INSERT INTO V_VAL
	VALUES ("b207898e-886c-49c4-ae4d-5ee131c145f4",
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"82fe89dd-2b11-4f4d-b9db-ec847c14284b");
INSERT INTO V_LIN
	VALUES ("b207898e-886c-49c4-ae4d-5ee131c145f4",
	'8');
INSERT INTO V_PAR
	VALUES ("b207898e-886c-49c4-ae4d-5ee131c145f4",
	"46fd1a10-b963-4496-8a69-1a197f2da04a",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	37,
	35);
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"22009600-89a7-424a-8f43-e4751f59e7d5");
INSERT INTO S_SYNC
	VALUES ("22009600-89a7-424a-8f43-e4751f59e7d5",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'setz4_spectrum',
	'',
	'
CELL::set_given( row:1, column:5, answer:8 );
CELL::set_given( row:1, column:6, answer:3 );
CELL::set_given( row:1, column:7, answer:4 );

CELL::set_given( row:2, column:1, answer:3 );
CELL::set_given( row:2, column:6, answer:4 );
CELL::set_given( row:2, column:7, answer:8 );
CELL::set_given( row:2, column:8, answer:2 );
CELL::set_given( row:2, column:9, answer:1 );

CELL::set_given( row:3, column:1, answer:7 );

CELL::set_given( row:4, column:3, answer:9 );
CELL::set_given( row:4, column:4, answer:4 );
CELL::set_given( row:4, column:6, answer:1 );
CELL::set_given( row:4, column:8, answer:8 );
CELL::set_given( row:4, column:9, answer:3 );


CELL::set_given( row:6, column:1, answer:4 );
CELL::set_given( row:6, column:2, answer:6 );
CELL::set_given( row:6, column:4, answer:5 );
CELL::set_given( row:6, column:6, answer:7 );
CELL::set_given( row:6, column:7, answer:1 );

CELL::set_given( row:7, column:9, answer:7 );

CELL::set_given( row:8, column:1, answer:1 );
CELL::set_given( row:8, column:2, answer:2 );
CELL::set_given( row:8, column:3, answer:5 );
CELL::set_given( row:8, column:4, answer:3 );
CELL::set_given( row:8, column:9, answer:9 );

CELL::set_given( row:9, column:3, answer:7 );
CELL::set_given( row:9, column:4, answer:2 );
CELL::set_given( row:9, column:5, answer:4 );',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("e602afc3-62fa-43bb-a16c-fb12e870e015",
	"22009600-89a7-424a-8f43-e4751f59e7d5");
INSERT INTO ACT_ACT
	VALUES ("e602afc3-62fa-43bb-a16c-fb12e870e015",
	'function',
	0,
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setz4_spectrum',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	37,
	1,
	37,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"e602afc3-62fa-43bb-a16c-fb12e870e015",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3069e6cd-17c0-46ed-8764-1ee9e187f4a2",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"50aacff4-359b-4a4d-bb41-4c98c09cfaac",
	2,
	1,
	'setz4_spectrum line: 2');
INSERT INTO ACT_TFM
	VALUES ("3069e6cd-17c0-46ed-8764-1ee9e187f4a2",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	2,
	7,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES ("50aacff4-359b-4a4d-bb41-4c98c09cfaac",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"cb9022f7-243b-4b42-a077-a1d242284f5f",
	3,
	1,
	'setz4_spectrum line: 3');
INSERT INTO ACT_TFM
	VALUES ("50aacff4-359b-4a4d-bb41-4c98c09cfaac",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	3,
	7,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES ("cb9022f7-243b-4b42-a077-a1d242284f5f",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"d7fb44a7-417e-4d1a-853b-9ec70f2715c4",
	4,
	1,
	'setz4_spectrum line: 4');
INSERT INTO ACT_TFM
	VALUES ("cb9022f7-243b-4b42-a077-a1d242284f5f",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	4,
	7,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES ("d7fb44a7-417e-4d1a-853b-9ec70f2715c4",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"ea4b7531-d992-423f-832a-b471aa54fd60",
	6,
	1,
	'setz4_spectrum line: 6');
INSERT INTO ACT_TFM
	VALUES ("d7fb44a7-417e-4d1a-853b-9ec70f2715c4",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	6,
	7,
	6,
	1);
INSERT INTO ACT_SMT
	VALUES ("ea4b7531-d992-423f-832a-b471aa54fd60",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"2ef3bf9c-ab25-4b6b-aa23-96657978a14d",
	7,
	1,
	'setz4_spectrum line: 7');
INSERT INTO ACT_TFM
	VALUES ("ea4b7531-d992-423f-832a-b471aa54fd60",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	7,
	7,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES ("2ef3bf9c-ab25-4b6b-aa23-96657978a14d",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"b557892b-d347-4b4e-83dd-29e46df5cfd4",
	8,
	1,
	'setz4_spectrum line: 8');
INSERT INTO ACT_TFM
	VALUES ("2ef3bf9c-ab25-4b6b-aa23-96657978a14d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	8,
	7,
	8,
	1);
INSERT INTO ACT_SMT
	VALUES ("b557892b-d347-4b4e-83dd-29e46df5cfd4",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"ea662d15-f7e5-4bcd-a29a-48645bebc156",
	9,
	1,
	'setz4_spectrum line: 9');
INSERT INTO ACT_TFM
	VALUES ("b557892b-d347-4b4e-83dd-29e46df5cfd4",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	9,
	7,
	9,
	1);
INSERT INTO ACT_SMT
	VALUES ("ea662d15-f7e5-4bcd-a29a-48645bebc156",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"1edf0b43-09d8-4396-8777-74d0442b578c",
	10,
	1,
	'setz4_spectrum line: 10');
INSERT INTO ACT_TFM
	VALUES ("ea662d15-f7e5-4bcd-a29a-48645bebc156",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	10,
	7,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES ("1edf0b43-09d8-4396-8777-74d0442b578c",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"4878ac81-acf3-4d23-81a5-7b1ef686e8e6",
	12,
	1,
	'setz4_spectrum line: 12');
INSERT INTO ACT_TFM
	VALUES ("1edf0b43-09d8-4396-8777-74d0442b578c",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	12,
	1);
INSERT INTO ACT_SMT
	VALUES ("4878ac81-acf3-4d23-81a5-7b1ef686e8e6",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"40b65c07-1ef7-4c67-be9d-866e208da8d7",
	14,
	1,
	'setz4_spectrum line: 14');
INSERT INTO ACT_TFM
	VALUES ("4878ac81-acf3-4d23-81a5-7b1ef686e8e6",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	14,
	7,
	14,
	1);
INSERT INTO ACT_SMT
	VALUES ("40b65c07-1ef7-4c67-be9d-866e208da8d7",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"8c22562a-3ac5-46dc-90ea-ceea0a6facb6",
	15,
	1,
	'setz4_spectrum line: 15');
INSERT INTO ACT_TFM
	VALUES ("40b65c07-1ef7-4c67-be9d-866e208da8d7",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	15,
	7,
	15,
	1);
INSERT INTO ACT_SMT
	VALUES ("8c22562a-3ac5-46dc-90ea-ceea0a6facb6",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"e4ff777a-3eb6-41a2-bb26-e3770aaac305",
	16,
	1,
	'setz4_spectrum line: 16');
INSERT INTO ACT_TFM
	VALUES ("8c22562a-3ac5-46dc-90ea-ceea0a6facb6",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	16,
	1);
INSERT INTO ACT_SMT
	VALUES ("e4ff777a-3eb6-41a2-bb26-e3770aaac305",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"f619cc2c-3659-4f5b-b918-9eb7c92a4a27",
	17,
	1,
	'setz4_spectrum line: 17');
INSERT INTO ACT_TFM
	VALUES ("e4ff777a-3eb6-41a2-bb26-e3770aaac305",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	17,
	7,
	17,
	1);
INSERT INTO ACT_SMT
	VALUES ("f619cc2c-3659-4f5b-b918-9eb7c92a4a27",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"d0de00c6-3aae-498c-b3e3-b938aa49d8da",
	18,
	1,
	'setz4_spectrum line: 18');
INSERT INTO ACT_TFM
	VALUES ("f619cc2c-3659-4f5b-b918-9eb7c92a4a27",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	18,
	7,
	18,
	1);
INSERT INTO ACT_SMT
	VALUES ("d0de00c6-3aae-498c-b3e3-b938aa49d8da",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"2a3f2a22-fdba-41a7-9e62-7d2bdf62b8db",
	21,
	1,
	'setz4_spectrum line: 21');
INSERT INTO ACT_TFM
	VALUES ("d0de00c6-3aae-498c-b3e3-b938aa49d8da",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	21,
	7,
	21,
	1);
INSERT INTO ACT_SMT
	VALUES ("2a3f2a22-fdba-41a7-9e62-7d2bdf62b8db",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"426f7bd0-8562-495a-a0ed-61e70df0d8ee",
	22,
	1,
	'setz4_spectrum line: 22');
INSERT INTO ACT_TFM
	VALUES ("2a3f2a22-fdba-41a7-9e62-7d2bdf62b8db",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	22,
	7,
	22,
	1);
INSERT INTO ACT_SMT
	VALUES ("426f7bd0-8562-495a-a0ed-61e70df0d8ee",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"4ba5afc2-182a-4cc8-a06d-e542a4b71c81",
	23,
	1,
	'setz4_spectrum line: 23');
INSERT INTO ACT_TFM
	VALUES ("426f7bd0-8562-495a-a0ed-61e70df0d8ee",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	23,
	7,
	23,
	1);
INSERT INTO ACT_SMT
	VALUES ("4ba5afc2-182a-4cc8-a06d-e542a4b71c81",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"bc46a27a-1b3d-47ec-aa4b-e1bc2582dbb1",
	24,
	1,
	'setz4_spectrum line: 24');
INSERT INTO ACT_TFM
	VALUES ("4ba5afc2-182a-4cc8-a06d-e542a4b71c81",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	24,
	7,
	24,
	1);
INSERT INTO ACT_SMT
	VALUES ("bc46a27a-1b3d-47ec-aa4b-e1bc2582dbb1",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"77035ab3-4d1f-41ad-b396-cb5c38c6dc09",
	25,
	1,
	'setz4_spectrum line: 25');
INSERT INTO ACT_TFM
	VALUES ("bc46a27a-1b3d-47ec-aa4b-e1bc2582dbb1",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	25,
	7,
	25,
	1);
INSERT INTO ACT_SMT
	VALUES ("77035ab3-4d1f-41ad-b396-cb5c38c6dc09",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"72696d0c-5ed3-42af-8e02-4392f5abd469",
	27,
	1,
	'setz4_spectrum line: 27');
INSERT INTO ACT_TFM
	VALUES ("77035ab3-4d1f-41ad-b396-cb5c38c6dc09",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	27,
	7,
	27,
	1);
INSERT INTO ACT_SMT
	VALUES ("72696d0c-5ed3-42af-8e02-4392f5abd469",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"571d816e-7d80-4899-8b94-030ede72c68c",
	29,
	1,
	'setz4_spectrum line: 29');
INSERT INTO ACT_TFM
	VALUES ("72696d0c-5ed3-42af-8e02-4392f5abd469",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	29,
	7,
	29,
	1);
INSERT INTO ACT_SMT
	VALUES ("571d816e-7d80-4899-8b94-030ede72c68c",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"6097ff51-d366-45cd-b6c8-34d712cab727",
	30,
	1,
	'setz4_spectrum line: 30');
INSERT INTO ACT_TFM
	VALUES ("571d816e-7d80-4899-8b94-030ede72c68c",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	30,
	7,
	30,
	1);
INSERT INTO ACT_SMT
	VALUES ("6097ff51-d366-45cd-b6c8-34d712cab727",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"569232d8-ddfd-4768-bb45-5c49cce07183",
	31,
	1,
	'setz4_spectrum line: 31');
INSERT INTO ACT_TFM
	VALUES ("6097ff51-d366-45cd-b6c8-34d712cab727",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	31,
	7,
	31,
	1);
INSERT INTO ACT_SMT
	VALUES ("569232d8-ddfd-4768-bb45-5c49cce07183",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"c43238af-882b-48fd-87ff-57f93fa39e1f",
	32,
	1,
	'setz4_spectrum line: 32');
INSERT INTO ACT_TFM
	VALUES ("569232d8-ddfd-4768-bb45-5c49cce07183",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	32,
	7,
	32,
	1);
INSERT INTO ACT_SMT
	VALUES ("c43238af-882b-48fd-87ff-57f93fa39e1f",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"7182740c-3861-4918-82ff-9dced2a1656d",
	33,
	1,
	'setz4_spectrum line: 33');
INSERT INTO ACT_TFM
	VALUES ("c43238af-882b-48fd-87ff-57f93fa39e1f",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	33,
	7,
	33,
	1);
INSERT INTO ACT_SMT
	VALUES ("7182740c-3861-4918-82ff-9dced2a1656d",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"13b039b6-4bbc-4b78-94ed-92590f854995",
	35,
	1,
	'setz4_spectrum line: 35');
INSERT INTO ACT_TFM
	VALUES ("7182740c-3861-4918-82ff-9dced2a1656d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	35,
	7,
	35,
	1);
INSERT INTO ACT_SMT
	VALUES ("13b039b6-4bbc-4b78-94ed-92590f854995",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"fbcdc549-5eed-493b-82f6-a360aecd68bb",
	36,
	1,
	'setz4_spectrum line: 36');
INSERT INTO ACT_TFM
	VALUES ("13b039b6-4bbc-4b78-94ed-92590f854995",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	36,
	7,
	36,
	1);
INSERT INTO ACT_SMT
	VALUES ("fbcdc549-5eed-493b-82f6-a360aecd68bb",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac",
	"00000000-0000-0000-0000-000000000000",
	37,
	1,
	'setz4_spectrum line: 37');
INSERT INTO ACT_TFM
	VALUES ("fbcdc549-5eed-493b-82f6-a360aecd68bb",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"00000000-0000-0000-0000-000000000000",
	37,
	7,
	37,
	1);
INSERT INTO V_VAL
	VALUES ("befe782f-9d5d-470d-8fd0-f9ad905c13ea",
	0,
	0,
	2,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("befe782f-9d5d-470d-8fd0-f9ad905c13ea",
	'1');
INSERT INTO V_PAR
	VALUES ("befe782f-9d5d-470d-8fd0-f9ad905c13ea",
	"3069e6cd-17c0-46ed-8764-1ee9e187f4a2",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4313a716-0e6c-434d-8b2f-63496433fa0c",
	2,
	18);
INSERT INTO V_VAL
	VALUES ("4313a716-0e6c-434d-8b2f-63496433fa0c",
	0,
	0,
	2,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("4313a716-0e6c-434d-8b2f-63496433fa0c",
	'5');
INSERT INTO V_PAR
	VALUES ("4313a716-0e6c-434d-8b2f-63496433fa0c",
	"3069e6cd-17c0-46ed-8764-1ee9e187f4a2",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8d5861cf-db56-4055-a98d-8d9e8aa5a4f7",
	2,
	25);
INSERT INTO V_VAL
	VALUES ("8d5861cf-db56-4055-a98d-8d9e8aa5a4f7",
	0,
	0,
	2,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("8d5861cf-db56-4055-a98d-8d9e8aa5a4f7",
	'8');
INSERT INTO V_PAR
	VALUES ("8d5861cf-db56-4055-a98d-8d9e8aa5a4f7",
	"3069e6cd-17c0-46ed-8764-1ee9e187f4a2",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	2,
	35);
INSERT INTO V_VAL
	VALUES ("c99816d8-c890-4cbe-82e0-fa51c944efac",
	0,
	0,
	3,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("c99816d8-c890-4cbe-82e0-fa51c944efac",
	'1');
INSERT INTO V_PAR
	VALUES ("c99816d8-c890-4cbe-82e0-fa51c944efac",
	"50aacff4-359b-4a4d-bb41-4c98c09cfaac",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7ad3b7a7-61a3-428f-afe4-22041b4b27c1",
	3,
	18);
INSERT INTO V_VAL
	VALUES ("7ad3b7a7-61a3-428f-afe4-22041b4b27c1",
	0,
	0,
	3,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("7ad3b7a7-61a3-428f-afe4-22041b4b27c1",
	'6');
INSERT INTO V_PAR
	VALUES ("7ad3b7a7-61a3-428f-afe4-22041b4b27c1",
	"50aacff4-359b-4a4d-bb41-4c98c09cfaac",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"86c05d26-7c0c-4c68-8c94-8ef7eaccb02e",
	3,
	25);
INSERT INTO V_VAL
	VALUES ("86c05d26-7c0c-4c68-8c94-8ef7eaccb02e",
	0,
	0,
	3,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("86c05d26-7c0c-4c68-8c94-8ef7eaccb02e",
	'3');
INSERT INTO V_PAR
	VALUES ("86c05d26-7c0c-4c68-8c94-8ef7eaccb02e",
	"50aacff4-359b-4a4d-bb41-4c98c09cfaac",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	3,
	35);
INSERT INTO V_VAL
	VALUES ("6a518833-a613-4039-a489-77ef420dda59",
	0,
	0,
	4,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("6a518833-a613-4039-a489-77ef420dda59",
	'1');
INSERT INTO V_PAR
	VALUES ("6a518833-a613-4039-a489-77ef420dda59",
	"cb9022f7-243b-4b42-a077-a1d242284f5f",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"6d8ec105-1d47-413a-8706-85f9a15f523f",
	4,
	18);
INSERT INTO V_VAL
	VALUES ("6d8ec105-1d47-413a-8706-85f9a15f523f",
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("6d8ec105-1d47-413a-8706-85f9a15f523f",
	'7');
INSERT INTO V_PAR
	VALUES ("6d8ec105-1d47-413a-8706-85f9a15f523f",
	"cb9022f7-243b-4b42-a077-a1d242284f5f",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"3b38dfa2-aebf-4542-bf6f-335421ac3c74",
	4,
	25);
INSERT INTO V_VAL
	VALUES ("3b38dfa2-aebf-4542-bf6f-335421ac3c74",
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("3b38dfa2-aebf-4542-bf6f-335421ac3c74",
	'4');
INSERT INTO V_PAR
	VALUES ("3b38dfa2-aebf-4542-bf6f-335421ac3c74",
	"cb9022f7-243b-4b42-a077-a1d242284f5f",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	4,
	35);
INSERT INTO V_VAL
	VALUES ("f100c830-be73-40d4-9262-78d4b9afa300",
	0,
	0,
	6,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("f100c830-be73-40d4-9262-78d4b9afa300",
	'2');
INSERT INTO V_PAR
	VALUES ("f100c830-be73-40d4-9262-78d4b9afa300",
	"d7fb44a7-417e-4d1a-853b-9ec70f2715c4",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"a326bc5f-f1dc-4740-97d7-28dbe234ce51",
	6,
	18);
INSERT INTO V_VAL
	VALUES ("a326bc5f-f1dc-4740-97d7-28dbe234ce51",
	0,
	0,
	6,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("a326bc5f-f1dc-4740-97d7-28dbe234ce51",
	'1');
INSERT INTO V_PAR
	VALUES ("a326bc5f-f1dc-4740-97d7-28dbe234ce51",
	"d7fb44a7-417e-4d1a-853b-9ec70f2715c4",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"b1f7d222-4220-4c61-9cb3-6e77ee14e114",
	6,
	25);
INSERT INTO V_VAL
	VALUES ("b1f7d222-4220-4c61-9cb3-6e77ee14e114",
	0,
	0,
	6,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("b1f7d222-4220-4c61-9cb3-6e77ee14e114",
	'3');
INSERT INTO V_PAR
	VALUES ("b1f7d222-4220-4c61-9cb3-6e77ee14e114",
	"d7fb44a7-417e-4d1a-853b-9ec70f2715c4",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	6,
	35);
INSERT INTO V_VAL
	VALUES ("395de0d7-f4f0-48d4-bd4f-0fb7c939cc07",
	0,
	0,
	7,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("395de0d7-f4f0-48d4-bd4f-0fb7c939cc07",
	'2');
INSERT INTO V_PAR
	VALUES ("395de0d7-f4f0-48d4-bd4f-0fb7c939cc07",
	"ea4b7531-d992-423f-832a-b471aa54fd60",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"fd55723f-fcb9-4a1f-9f52-2ec18e632811",
	7,
	18);
INSERT INTO V_VAL
	VALUES ("fd55723f-fcb9-4a1f-9f52-2ec18e632811",
	0,
	0,
	7,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("fd55723f-fcb9-4a1f-9f52-2ec18e632811",
	'6');
INSERT INTO V_PAR
	VALUES ("fd55723f-fcb9-4a1f-9f52-2ec18e632811",
	"ea4b7531-d992-423f-832a-b471aa54fd60",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"5acd1b5c-0102-4e67-be97-f11ca864b5dd",
	7,
	25);
INSERT INTO V_VAL
	VALUES ("5acd1b5c-0102-4e67-be97-f11ca864b5dd",
	0,
	0,
	7,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("5acd1b5c-0102-4e67-be97-f11ca864b5dd",
	'4');
INSERT INTO V_PAR
	VALUES ("5acd1b5c-0102-4e67-be97-f11ca864b5dd",
	"ea4b7531-d992-423f-832a-b471aa54fd60",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	7,
	35);
INSERT INTO V_VAL
	VALUES ("37166978-3869-4b88-a9dd-84b9866a7d20",
	0,
	0,
	8,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("37166978-3869-4b88-a9dd-84b9866a7d20",
	'2');
INSERT INTO V_PAR
	VALUES ("37166978-3869-4b88-a9dd-84b9866a7d20",
	"2ef3bf9c-ab25-4b6b-aa23-96657978a14d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"73c3879c-92fa-4da6-b101-6e60b8d1d0c4",
	8,
	18);
INSERT INTO V_VAL
	VALUES ("73c3879c-92fa-4da6-b101-6e60b8d1d0c4",
	0,
	0,
	8,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("73c3879c-92fa-4da6-b101-6e60b8d1d0c4",
	'7');
INSERT INTO V_PAR
	VALUES ("73c3879c-92fa-4da6-b101-6e60b8d1d0c4",
	"2ef3bf9c-ab25-4b6b-aa23-96657978a14d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"2e5eb255-944a-4d0d-bd94-d2ca9a70880a",
	8,
	25);
INSERT INTO V_VAL
	VALUES ("2e5eb255-944a-4d0d-bd94-d2ca9a70880a",
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("2e5eb255-944a-4d0d-bd94-d2ca9a70880a",
	'8');
INSERT INTO V_PAR
	VALUES ("2e5eb255-944a-4d0d-bd94-d2ca9a70880a",
	"2ef3bf9c-ab25-4b6b-aa23-96657978a14d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	8,
	35);
INSERT INTO V_VAL
	VALUES ("17399a8d-b140-4da7-ac58-bf4adc8bdda2",
	0,
	0,
	9,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("17399a8d-b140-4da7-ac58-bf4adc8bdda2",
	'2');
INSERT INTO V_PAR
	VALUES ("17399a8d-b140-4da7-ac58-bf4adc8bdda2",
	"b557892b-d347-4b4e-83dd-29e46df5cfd4",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4f510c33-4991-435a-8921-799a025227a2",
	9,
	18);
INSERT INTO V_VAL
	VALUES ("4f510c33-4991-435a-8921-799a025227a2",
	0,
	0,
	9,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("4f510c33-4991-435a-8921-799a025227a2",
	'8');
INSERT INTO V_PAR
	VALUES ("4f510c33-4991-435a-8921-799a025227a2",
	"b557892b-d347-4b4e-83dd-29e46df5cfd4",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"8ce85e1d-01be-4d1a-ac4d-12c59e1ce353",
	9,
	25);
INSERT INTO V_VAL
	VALUES ("8ce85e1d-01be-4d1a-ac4d-12c59e1ce353",
	0,
	0,
	9,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("8ce85e1d-01be-4d1a-ac4d-12c59e1ce353",
	'2');
INSERT INTO V_PAR
	VALUES ("8ce85e1d-01be-4d1a-ac4d-12c59e1ce353",
	"b557892b-d347-4b4e-83dd-29e46df5cfd4",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	9,
	35);
INSERT INTO V_VAL
	VALUES ("03319760-aa94-4e16-9b46-c429443b95f7",
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("03319760-aa94-4e16-9b46-c429443b95f7",
	'2');
INSERT INTO V_PAR
	VALUES ("03319760-aa94-4e16-9b46-c429443b95f7",
	"ea662d15-f7e5-4bcd-a29a-48645bebc156",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"390a08c7-9f8f-4866-83d6-76c2cc7cca2a",
	10,
	18);
INSERT INTO V_VAL
	VALUES ("390a08c7-9f8f-4866-83d6-76c2cc7cca2a",
	0,
	0,
	10,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("390a08c7-9f8f-4866-83d6-76c2cc7cca2a",
	'9');
INSERT INTO V_PAR
	VALUES ("390a08c7-9f8f-4866-83d6-76c2cc7cca2a",
	"ea662d15-f7e5-4bcd-a29a-48645bebc156",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"e0452953-6416-437f-a4d5-23b35493213f",
	10,
	25);
INSERT INTO V_VAL
	VALUES ("e0452953-6416-437f-a4d5-23b35493213f",
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("e0452953-6416-437f-a4d5-23b35493213f",
	'1');
INSERT INTO V_PAR
	VALUES ("e0452953-6416-437f-a4d5-23b35493213f",
	"ea662d15-f7e5-4bcd-a29a-48645bebc156",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	10,
	35);
INSERT INTO V_VAL
	VALUES ("752441fa-904f-466e-a76a-538c75abb0cd",
	0,
	0,
	12,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("752441fa-904f-466e-a76a-538c75abb0cd",
	'3');
INSERT INTO V_PAR
	VALUES ("752441fa-904f-466e-a76a-538c75abb0cd",
	"1edf0b43-09d8-4396-8777-74d0442b578c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"7c07aca3-f8b0-484f-b1d2-8ecd9800181c",
	12,
	18);
INSERT INTO V_VAL
	VALUES ("7c07aca3-f8b0-484f-b1d2-8ecd9800181c",
	0,
	0,
	12,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("7c07aca3-f8b0-484f-b1d2-8ecd9800181c",
	'1');
INSERT INTO V_PAR
	VALUES ("7c07aca3-f8b0-484f-b1d2-8ecd9800181c",
	"1edf0b43-09d8-4396-8777-74d0442b578c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"f9df6993-35eb-454c-a814-07078445e5b7",
	12,
	25);
INSERT INTO V_VAL
	VALUES ("f9df6993-35eb-454c-a814-07078445e5b7",
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("f9df6993-35eb-454c-a814-07078445e5b7",
	'7');
INSERT INTO V_PAR
	VALUES ("f9df6993-35eb-454c-a814-07078445e5b7",
	"1edf0b43-09d8-4396-8777-74d0442b578c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	12,
	35);
INSERT INTO V_VAL
	VALUES ("37d2bffd-432e-4115-ab9d-a132728baa5a",
	0,
	0,
	14,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("37d2bffd-432e-4115-ab9d-a132728baa5a",
	'4');
INSERT INTO V_PAR
	VALUES ("37d2bffd-432e-4115-ab9d-a132728baa5a",
	"4878ac81-acf3-4d23-81a5-7b1ef686e8e6",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"aafd683a-db34-4b9b-bf97-e74727b28f8c",
	14,
	18);
INSERT INTO V_VAL
	VALUES ("aafd683a-db34-4b9b-bf97-e74727b28f8c",
	0,
	0,
	14,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("aafd683a-db34-4b9b-bf97-e74727b28f8c",
	'3');
INSERT INTO V_PAR
	VALUES ("aafd683a-db34-4b9b-bf97-e74727b28f8c",
	"4878ac81-acf3-4d23-81a5-7b1ef686e8e6",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"2fce834c-f442-44a1-b0e3-ebfc76959ab7",
	14,
	25);
INSERT INTO V_VAL
	VALUES ("2fce834c-f442-44a1-b0e3-ebfc76959ab7",
	0,
	0,
	14,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("2fce834c-f442-44a1-b0e3-ebfc76959ab7",
	'9');
INSERT INTO V_PAR
	VALUES ("2fce834c-f442-44a1-b0e3-ebfc76959ab7",
	"4878ac81-acf3-4d23-81a5-7b1ef686e8e6",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	14,
	35);
INSERT INTO V_VAL
	VALUES ("6e6d1331-31e0-4783-8aac-ef0b10ea15db",
	0,
	0,
	15,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("6e6d1331-31e0-4783-8aac-ef0b10ea15db",
	'4');
INSERT INTO V_PAR
	VALUES ("6e6d1331-31e0-4783-8aac-ef0b10ea15db",
	"40b65c07-1ef7-4c67-be9d-866e208da8d7",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"4d85f85f-7040-4233-9b12-95a17bba6967",
	15,
	18);
INSERT INTO V_VAL
	VALUES ("4d85f85f-7040-4233-9b12-95a17bba6967",
	0,
	0,
	15,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("4d85f85f-7040-4233-9b12-95a17bba6967",
	'4');
INSERT INTO V_PAR
	VALUES ("4d85f85f-7040-4233-9b12-95a17bba6967",
	"40b65c07-1ef7-4c67-be9d-866e208da8d7",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"d8669751-f7b8-43d4-bcea-a4d959b7218d",
	15,
	25);
INSERT INTO V_VAL
	VALUES ("d8669751-f7b8-43d4-bcea-a4d959b7218d",
	0,
	0,
	15,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("d8669751-f7b8-43d4-bcea-a4d959b7218d",
	'4');
INSERT INTO V_PAR
	VALUES ("d8669751-f7b8-43d4-bcea-a4d959b7218d",
	"40b65c07-1ef7-4c67-be9d-866e208da8d7",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	15,
	35);
INSERT INTO V_VAL
	VALUES ("993ec53e-b322-43f8-b93d-96e780b93522",
	0,
	0,
	16,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("993ec53e-b322-43f8-b93d-96e780b93522",
	'4');
INSERT INTO V_PAR
	VALUES ("993ec53e-b322-43f8-b93d-96e780b93522",
	"8c22562a-3ac5-46dc-90ea-ceea0a6facb6",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"806a6500-3086-476a-9666-b655ac18de87",
	16,
	18);
INSERT INTO V_VAL
	VALUES ("806a6500-3086-476a-9666-b655ac18de87",
	0,
	0,
	16,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("806a6500-3086-476a-9666-b655ac18de87",
	'6');
INSERT INTO V_PAR
	VALUES ("806a6500-3086-476a-9666-b655ac18de87",
	"8c22562a-3ac5-46dc-90ea-ceea0a6facb6",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"282fc095-9bc6-456d-b351-286b7a332011",
	16,
	25);
INSERT INTO V_VAL
	VALUES ("282fc095-9bc6-456d-b351-286b7a332011",
	0,
	0,
	16,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("282fc095-9bc6-456d-b351-286b7a332011",
	'1');
INSERT INTO V_PAR
	VALUES ("282fc095-9bc6-456d-b351-286b7a332011",
	"8c22562a-3ac5-46dc-90ea-ceea0a6facb6",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	16,
	35);
INSERT INTO V_VAL
	VALUES ("c6f2fc07-d576-447e-beea-519c8afb811a",
	0,
	0,
	17,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("c6f2fc07-d576-447e-beea-519c8afb811a",
	'4');
INSERT INTO V_PAR
	VALUES ("c6f2fc07-d576-447e-beea-519c8afb811a",
	"e4ff777a-3eb6-41a2-bb26-e3770aaac305",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"700b28b2-28d9-4a26-a5e5-1485c5b84274",
	17,
	18);
INSERT INTO V_VAL
	VALUES ("700b28b2-28d9-4a26-a5e5-1485c5b84274",
	0,
	0,
	17,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("700b28b2-28d9-4a26-a5e5-1485c5b84274",
	'8');
INSERT INTO V_PAR
	VALUES ("700b28b2-28d9-4a26-a5e5-1485c5b84274",
	"e4ff777a-3eb6-41a2-bb26-e3770aaac305",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"ffac796d-f8ec-4ffe-bdc6-1b1f42f2410e",
	17,
	25);
INSERT INTO V_VAL
	VALUES ("ffac796d-f8ec-4ffe-bdc6-1b1f42f2410e",
	0,
	0,
	17,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("ffac796d-f8ec-4ffe-bdc6-1b1f42f2410e",
	'8');
INSERT INTO V_PAR
	VALUES ("ffac796d-f8ec-4ffe-bdc6-1b1f42f2410e",
	"e4ff777a-3eb6-41a2-bb26-e3770aaac305",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	17,
	35);
INSERT INTO V_VAL
	VALUES ("3a2d9cd2-8f14-43c6-b31b-985f2f12cb48",
	0,
	0,
	18,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("3a2d9cd2-8f14-43c6-b31b-985f2f12cb48",
	'4');
INSERT INTO V_PAR
	VALUES ("3a2d9cd2-8f14-43c6-b31b-985f2f12cb48",
	"f619cc2c-3659-4f5b-b918-9eb7c92a4a27",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"6a7e9855-3a37-4e73-99cc-0b292f471c55",
	18,
	18);
INSERT INTO V_VAL
	VALUES ("6a7e9855-3a37-4e73-99cc-0b292f471c55",
	0,
	0,
	18,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("6a7e9855-3a37-4e73-99cc-0b292f471c55",
	'9');
INSERT INTO V_PAR
	VALUES ("6a7e9855-3a37-4e73-99cc-0b292f471c55",
	"f619cc2c-3659-4f5b-b918-9eb7c92a4a27",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"3450ab4d-5c8f-44bc-9cc2-45f952fadecb",
	18,
	25);
INSERT INTO V_VAL
	VALUES ("3450ab4d-5c8f-44bc-9cc2-45f952fadecb",
	0,
	0,
	18,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("3450ab4d-5c8f-44bc-9cc2-45f952fadecb",
	'3');
INSERT INTO V_PAR
	VALUES ("3450ab4d-5c8f-44bc-9cc2-45f952fadecb",
	"f619cc2c-3659-4f5b-b918-9eb7c92a4a27",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	18,
	35);
INSERT INTO V_VAL
	VALUES ("e19b4246-e5b3-49fd-a0ac-9e59f6628852",
	0,
	0,
	21,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("e19b4246-e5b3-49fd-a0ac-9e59f6628852",
	'6');
INSERT INTO V_PAR
	VALUES ("e19b4246-e5b3-49fd-a0ac-9e59f6628852",
	"d0de00c6-3aae-498c-b3e3-b938aa49d8da",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"b0c39499-b4dc-4ec9-b00c-54fa40719a61",
	21,
	18);
INSERT INTO V_VAL
	VALUES ("b0c39499-b4dc-4ec9-b00c-54fa40719a61",
	0,
	0,
	21,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("b0c39499-b4dc-4ec9-b00c-54fa40719a61",
	'1');
INSERT INTO V_PAR
	VALUES ("b0c39499-b4dc-4ec9-b00c-54fa40719a61",
	"d0de00c6-3aae-498c-b3e3-b938aa49d8da",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"cd8d9608-86cd-4e76-8bf8-fa8d79a9976c",
	21,
	25);
INSERT INTO V_VAL
	VALUES ("cd8d9608-86cd-4e76-8bf8-fa8d79a9976c",
	0,
	0,
	21,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("cd8d9608-86cd-4e76-8bf8-fa8d79a9976c",
	'4');
INSERT INTO V_PAR
	VALUES ("cd8d9608-86cd-4e76-8bf8-fa8d79a9976c",
	"d0de00c6-3aae-498c-b3e3-b938aa49d8da",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	21,
	35);
INSERT INTO V_VAL
	VALUES ("aba3a4a1-3e39-4110-8f1a-e8362afd5e7c",
	0,
	0,
	22,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("aba3a4a1-3e39-4110-8f1a-e8362afd5e7c",
	'6');
INSERT INTO V_PAR
	VALUES ("aba3a4a1-3e39-4110-8f1a-e8362afd5e7c",
	"2a3f2a22-fdba-41a7-9e62-7d2bdf62b8db",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"96f8206c-6dd4-43c7-a789-591b89c6e80d",
	22,
	18);
INSERT INTO V_VAL
	VALUES ("96f8206c-6dd4-43c7-a789-591b89c6e80d",
	0,
	0,
	22,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("96f8206c-6dd4-43c7-a789-591b89c6e80d",
	'2');
INSERT INTO V_PAR
	VALUES ("96f8206c-6dd4-43c7-a789-591b89c6e80d",
	"2a3f2a22-fdba-41a7-9e62-7d2bdf62b8db",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"6d061269-8970-47aa-8548-a7eb8a58461d",
	22,
	25);
INSERT INTO V_VAL
	VALUES ("6d061269-8970-47aa-8548-a7eb8a58461d",
	0,
	0,
	22,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("6d061269-8970-47aa-8548-a7eb8a58461d",
	'6');
INSERT INTO V_PAR
	VALUES ("6d061269-8970-47aa-8548-a7eb8a58461d",
	"2a3f2a22-fdba-41a7-9e62-7d2bdf62b8db",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	22,
	35);
INSERT INTO V_VAL
	VALUES ("d025d610-6346-416a-ba9f-ad21cef6fb97",
	0,
	0,
	23,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("d025d610-6346-416a-ba9f-ad21cef6fb97",
	'6');
INSERT INTO V_PAR
	VALUES ("d025d610-6346-416a-ba9f-ad21cef6fb97",
	"426f7bd0-8562-495a-a0ed-61e70df0d8ee",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"38290b5f-6fb2-4d96-af75-723802fa8f3a",
	23,
	18);
INSERT INTO V_VAL
	VALUES ("38290b5f-6fb2-4d96-af75-723802fa8f3a",
	0,
	0,
	23,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("38290b5f-6fb2-4d96-af75-723802fa8f3a",
	'4');
INSERT INTO V_PAR
	VALUES ("38290b5f-6fb2-4d96-af75-723802fa8f3a",
	"426f7bd0-8562-495a-a0ed-61e70df0d8ee",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"fdfd0327-53c4-4a99-bdee-56d704a827d3",
	23,
	25);
INSERT INTO V_VAL
	VALUES ("fdfd0327-53c4-4a99-bdee-56d704a827d3",
	0,
	0,
	23,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("fdfd0327-53c4-4a99-bdee-56d704a827d3",
	'5');
INSERT INTO V_PAR
	VALUES ("fdfd0327-53c4-4a99-bdee-56d704a827d3",
	"426f7bd0-8562-495a-a0ed-61e70df0d8ee",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	23,
	35);
INSERT INTO V_VAL
	VALUES ("d3c630dd-b64e-407e-b806-e55e5b31cd09",
	0,
	0,
	24,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("d3c630dd-b64e-407e-b806-e55e5b31cd09",
	'6');
INSERT INTO V_PAR
	VALUES ("d3c630dd-b64e-407e-b806-e55e5b31cd09",
	"4ba5afc2-182a-4cc8-a06d-e542a4b71c81",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"cef044c6-922d-45da-bb82-f044a79319a9",
	24,
	18);
INSERT INTO V_VAL
	VALUES ("cef044c6-922d-45da-bb82-f044a79319a9",
	0,
	0,
	24,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("cef044c6-922d-45da-bb82-f044a79319a9",
	'6');
INSERT INTO V_PAR
	VALUES ("cef044c6-922d-45da-bb82-f044a79319a9",
	"4ba5afc2-182a-4cc8-a06d-e542a4b71c81",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"0a7693e4-5318-4474-b862-e59985cb4777",
	24,
	25);
INSERT INTO V_VAL
	VALUES ("0a7693e4-5318-4474-b862-e59985cb4777",
	0,
	0,
	24,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("0a7693e4-5318-4474-b862-e59985cb4777",
	'7');
INSERT INTO V_PAR
	VALUES ("0a7693e4-5318-4474-b862-e59985cb4777",
	"4ba5afc2-182a-4cc8-a06d-e542a4b71c81",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	24,
	35);
INSERT INTO V_VAL
	VALUES ("70363c1b-7ffe-46c3-b821-f976b3fc83be",
	0,
	0,
	25,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("70363c1b-7ffe-46c3-b821-f976b3fc83be",
	'6');
INSERT INTO V_PAR
	VALUES ("70363c1b-7ffe-46c3-b821-f976b3fc83be",
	"bc46a27a-1b3d-47ec-aa4b-e1bc2582dbb1",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"d5d8336d-2f02-4fe8-8637-95f20fdd2de7",
	25,
	18);
INSERT INTO V_VAL
	VALUES ("d5d8336d-2f02-4fe8-8637-95f20fdd2de7",
	0,
	0,
	25,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("d5d8336d-2f02-4fe8-8637-95f20fdd2de7",
	'7');
INSERT INTO V_PAR
	VALUES ("d5d8336d-2f02-4fe8-8637-95f20fdd2de7",
	"bc46a27a-1b3d-47ec-aa4b-e1bc2582dbb1",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"e3fa0989-fce4-43b5-8957-d87474aed945",
	25,
	25);
INSERT INTO V_VAL
	VALUES ("e3fa0989-fce4-43b5-8957-d87474aed945",
	0,
	0,
	25,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("e3fa0989-fce4-43b5-8957-d87474aed945",
	'1');
INSERT INTO V_PAR
	VALUES ("e3fa0989-fce4-43b5-8957-d87474aed945",
	"bc46a27a-1b3d-47ec-aa4b-e1bc2582dbb1",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	25,
	35);
INSERT INTO V_VAL
	VALUES ("39fa6f78-5e74-4a5c-ab46-2db8e4bec4b4",
	0,
	0,
	27,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("39fa6f78-5e74-4a5c-ab46-2db8e4bec4b4",
	'7');
INSERT INTO V_PAR
	VALUES ("39fa6f78-5e74-4a5c-ab46-2db8e4bec4b4",
	"77035ab3-4d1f-41ad-b396-cb5c38c6dc09",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"1e320fc9-c00d-4b07-bf74-e0f013e9abb6",
	27,
	18);
INSERT INTO V_VAL
	VALUES ("1e320fc9-c00d-4b07-bf74-e0f013e9abb6",
	0,
	0,
	27,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("1e320fc9-c00d-4b07-bf74-e0f013e9abb6",
	'9');
INSERT INTO V_PAR
	VALUES ("1e320fc9-c00d-4b07-bf74-e0f013e9abb6",
	"77035ab3-4d1f-41ad-b396-cb5c38c6dc09",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"97b49e4a-c199-47b0-85ae-60007b4f91e0",
	27,
	25);
INSERT INTO V_VAL
	VALUES ("97b49e4a-c199-47b0-85ae-60007b4f91e0",
	0,
	0,
	27,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("97b49e4a-c199-47b0-85ae-60007b4f91e0",
	'7');
INSERT INTO V_PAR
	VALUES ("97b49e4a-c199-47b0-85ae-60007b4f91e0",
	"77035ab3-4d1f-41ad-b396-cb5c38c6dc09",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	27,
	35);
INSERT INTO V_VAL
	VALUES ("e5ae7a70-8741-421c-adca-b56953827810",
	0,
	0,
	29,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("e5ae7a70-8741-421c-adca-b56953827810",
	'8');
INSERT INTO V_PAR
	VALUES ("e5ae7a70-8741-421c-adca-b56953827810",
	"72696d0c-5ed3-42af-8e02-4392f5abd469",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"526f8252-d340-4194-82d8-012110d79c6d",
	29,
	18);
INSERT INTO V_VAL
	VALUES ("526f8252-d340-4194-82d8-012110d79c6d",
	0,
	0,
	29,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("526f8252-d340-4194-82d8-012110d79c6d",
	'1');
INSERT INTO V_PAR
	VALUES ("526f8252-d340-4194-82d8-012110d79c6d",
	"72696d0c-5ed3-42af-8e02-4392f5abd469",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"4ea58526-c504-45cc-ad83-cb2b0af0fd08",
	29,
	25);
INSERT INTO V_VAL
	VALUES ("4ea58526-c504-45cc-ad83-cb2b0af0fd08",
	0,
	0,
	29,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("4ea58526-c504-45cc-ad83-cb2b0af0fd08",
	'1');
INSERT INTO V_PAR
	VALUES ("4ea58526-c504-45cc-ad83-cb2b0af0fd08",
	"72696d0c-5ed3-42af-8e02-4392f5abd469",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	29,
	35);
INSERT INTO V_VAL
	VALUES ("8b5fcc17-85a7-43f9-9405-369858c31bec",
	0,
	0,
	30,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("8b5fcc17-85a7-43f9-9405-369858c31bec",
	'8');
INSERT INTO V_PAR
	VALUES ("8b5fcc17-85a7-43f9-9405-369858c31bec",
	"571d816e-7d80-4899-8b94-030ede72c68c",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"bf19df8f-d56b-43cd-87e9-2e5d66b706b1",
	30,
	18);
INSERT INTO V_VAL
	VALUES ("bf19df8f-d56b-43cd-87e9-2e5d66b706b1",
	0,
	0,
	30,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("bf19df8f-d56b-43cd-87e9-2e5d66b706b1",
	'2');
INSERT INTO V_PAR
	VALUES ("bf19df8f-d56b-43cd-87e9-2e5d66b706b1",
	"571d816e-7d80-4899-8b94-030ede72c68c",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"7b53673f-db86-475c-a47e-61062e047fb1",
	30,
	25);
INSERT INTO V_VAL
	VALUES ("7b53673f-db86-475c-a47e-61062e047fb1",
	0,
	0,
	30,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("7b53673f-db86-475c-a47e-61062e047fb1",
	'2');
INSERT INTO V_PAR
	VALUES ("7b53673f-db86-475c-a47e-61062e047fb1",
	"571d816e-7d80-4899-8b94-030ede72c68c",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	30,
	35);
INSERT INTO V_VAL
	VALUES ("5dc38447-f5ac-4596-9de3-d835eec7f55c",
	0,
	0,
	31,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("5dc38447-f5ac-4596-9de3-d835eec7f55c",
	'8');
INSERT INTO V_PAR
	VALUES ("5dc38447-f5ac-4596-9de3-d835eec7f55c",
	"6097ff51-d366-45cd-b6c8-34d712cab727",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"349bbfab-b973-4590-8990-74533770d3d3",
	31,
	18);
INSERT INTO V_VAL
	VALUES ("349bbfab-b973-4590-8990-74533770d3d3",
	0,
	0,
	31,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("349bbfab-b973-4590-8990-74533770d3d3",
	'3');
INSERT INTO V_PAR
	VALUES ("349bbfab-b973-4590-8990-74533770d3d3",
	"6097ff51-d366-45cd-b6c8-34d712cab727",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"53fe37bf-4a15-4945-9616-c3f694ffb0af",
	31,
	25);
INSERT INTO V_VAL
	VALUES ("53fe37bf-4a15-4945-9616-c3f694ffb0af",
	0,
	0,
	31,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("53fe37bf-4a15-4945-9616-c3f694ffb0af",
	'5');
INSERT INTO V_PAR
	VALUES ("53fe37bf-4a15-4945-9616-c3f694ffb0af",
	"6097ff51-d366-45cd-b6c8-34d712cab727",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	31,
	35);
INSERT INTO V_VAL
	VALUES ("48b133e8-ac07-459c-8158-91add136ab20",
	0,
	0,
	32,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("48b133e8-ac07-459c-8158-91add136ab20",
	'8');
INSERT INTO V_PAR
	VALUES ("48b133e8-ac07-459c-8158-91add136ab20",
	"569232d8-ddfd-4768-bb45-5c49cce07183",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"bf0d6ef2-8ea0-4d71-834d-ead79b82aa82",
	32,
	18);
INSERT INTO V_VAL
	VALUES ("bf0d6ef2-8ea0-4d71-834d-ead79b82aa82",
	0,
	0,
	32,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("bf0d6ef2-8ea0-4d71-834d-ead79b82aa82",
	'4');
INSERT INTO V_PAR
	VALUES ("bf0d6ef2-8ea0-4d71-834d-ead79b82aa82",
	"569232d8-ddfd-4768-bb45-5c49cce07183",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"07ad769b-2989-4946-bfd7-3aba33cd6b6f",
	32,
	25);
INSERT INTO V_VAL
	VALUES ("07ad769b-2989-4946-bfd7-3aba33cd6b6f",
	0,
	0,
	32,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("07ad769b-2989-4946-bfd7-3aba33cd6b6f",
	'3');
INSERT INTO V_PAR
	VALUES ("07ad769b-2989-4946-bfd7-3aba33cd6b6f",
	"569232d8-ddfd-4768-bb45-5c49cce07183",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	32,
	35);
INSERT INTO V_VAL
	VALUES ("93e87a5a-f03b-4c5b-9ca7-20c13ca2a00a",
	0,
	0,
	33,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("93e87a5a-f03b-4c5b-9ca7-20c13ca2a00a",
	'8');
INSERT INTO V_PAR
	VALUES ("93e87a5a-f03b-4c5b-9ca7-20c13ca2a00a",
	"c43238af-882b-48fd-87ff-57f93fa39e1f",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"8a465e2f-df3d-48bb-ab06-bd9605a08cee",
	33,
	18);
INSERT INTO V_VAL
	VALUES ("8a465e2f-df3d-48bb-ab06-bd9605a08cee",
	0,
	0,
	33,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("8a465e2f-df3d-48bb-ab06-bd9605a08cee",
	'9');
INSERT INTO V_PAR
	VALUES ("8a465e2f-df3d-48bb-ab06-bd9605a08cee",
	"c43238af-882b-48fd-87ff-57f93fa39e1f",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"d37860eb-26b2-4f93-a196-34a7725f809e",
	33,
	25);
INSERT INTO V_VAL
	VALUES ("d37860eb-26b2-4f93-a196-34a7725f809e",
	0,
	0,
	33,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("d37860eb-26b2-4f93-a196-34a7725f809e",
	'9');
INSERT INTO V_PAR
	VALUES ("d37860eb-26b2-4f93-a196-34a7725f809e",
	"c43238af-882b-48fd-87ff-57f93fa39e1f",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	33,
	35);
INSERT INTO V_VAL
	VALUES ("cb32b071-a770-4550-85cf-87d6910582d0",
	0,
	0,
	35,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("cb32b071-a770-4550-85cf-87d6910582d0",
	'9');
INSERT INTO V_PAR
	VALUES ("cb32b071-a770-4550-85cf-87d6910582d0",
	"7182740c-3861-4918-82ff-9dced2a1656d",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"0780ecff-7f61-497e-aac1-bbf3e3916ed8",
	35,
	18);
INSERT INTO V_VAL
	VALUES ("0780ecff-7f61-497e-aac1-bbf3e3916ed8",
	0,
	0,
	35,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("0780ecff-7f61-497e-aac1-bbf3e3916ed8",
	'3');
INSERT INTO V_PAR
	VALUES ("0780ecff-7f61-497e-aac1-bbf3e3916ed8",
	"7182740c-3861-4918-82ff-9dced2a1656d",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"d3063d33-f228-4a67-bb78-317a7d91a2d2",
	35,
	25);
INSERT INTO V_VAL
	VALUES ("d3063d33-f228-4a67-bb78-317a7d91a2d2",
	0,
	0,
	35,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("d3063d33-f228-4a67-bb78-317a7d91a2d2",
	'7');
INSERT INTO V_PAR
	VALUES ("d3063d33-f228-4a67-bb78-317a7d91a2d2",
	"7182740c-3861-4918-82ff-9dced2a1656d",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	35,
	35);
INSERT INTO V_VAL
	VALUES ("a11a71d9-b351-42a5-8561-9f64c7987031",
	0,
	0,
	36,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("a11a71d9-b351-42a5-8561-9f64c7987031",
	'9');
INSERT INTO V_PAR
	VALUES ("a11a71d9-b351-42a5-8561-9f64c7987031",
	"13b039b6-4bbc-4b78-94ed-92590f854995",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"fe83f3ed-4787-4dc4-ab3a-ce6190e7e182",
	36,
	18);
INSERT INTO V_VAL
	VALUES ("fe83f3ed-4787-4dc4-ab3a-ce6190e7e182",
	0,
	0,
	36,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("fe83f3ed-4787-4dc4-ab3a-ce6190e7e182",
	'4');
INSERT INTO V_PAR
	VALUES ("fe83f3ed-4787-4dc4-ab3a-ce6190e7e182",
	"13b039b6-4bbc-4b78-94ed-92590f854995",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"6367ae7a-c51b-4941-bc35-af4d7c8d7e41",
	36,
	25);
INSERT INTO V_VAL
	VALUES ("6367ae7a-c51b-4941-bc35-af4d7c8d7e41",
	0,
	0,
	36,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("6367ae7a-c51b-4941-bc35-af4d7c8d7e41",
	'2');
INSERT INTO V_PAR
	VALUES ("6367ae7a-c51b-4941-bc35-af4d7c8d7e41",
	"13b039b6-4bbc-4b78-94ed-92590f854995",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	36,
	35);
INSERT INTO V_VAL
	VALUES ("f6dd6968-70b1-4b19-b73e-6f1469bcbc9d",
	0,
	0,
	37,
	22,
	22,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("f6dd6968-70b1-4b19-b73e-6f1469bcbc9d",
	'9');
INSERT INTO V_PAR
	VALUES ("f6dd6968-70b1-4b19-b73e-6f1469bcbc9d",
	"fbcdc549-5eed-493b-82f6-a360aecd68bb",
	"00000000-0000-0000-0000-000000000000",
	'row',
	"40704cb8-0cd5-4f7a-9453-b74ab82acc4b",
	37,
	18);
INSERT INTO V_VAL
	VALUES ("40704cb8-0cd5-4f7a-9453-b74ab82acc4b",
	0,
	0,
	37,
	32,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("40704cb8-0cd5-4f7a-9453-b74ab82acc4b",
	'5');
INSERT INTO V_PAR
	VALUES ("40704cb8-0cd5-4f7a-9453-b74ab82acc4b",
	"fbcdc549-5eed-493b-82f6-a360aecd68bb",
	"00000000-0000-0000-0000-000000000000",
	'column',
	"038f4a29-3739-4602-a5ab-761b0754b5d8",
	37,
	25);
INSERT INTO V_VAL
	VALUES ("038f4a29-3739-4602-a5ab-761b0754b5d8",
	0,
	0,
	37,
	42,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7a5f65cc-ca0a-4ac5-8254-dd01079786ac");
INSERT INTO V_LIN
	VALUES ("038f4a29-3739-4602-a5ab-761b0754b5d8",
	'4');
INSERT INTO V_PAR
	VALUES ("038f4a29-3739-4602-a5ab-761b0754b5d8",
	"fbcdc549-5eed-493b-82f6-a360aecd68bb",
	"00000000-0000-0000-0000-000000000000",
	'answer',
	"00000000-0000-0000-0000-000000000000",
	37,
	35);
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"78b030a6-8715-49a6-b58c-0a0cc3efe66e");
INSERT INTO S_SYNC
	VALUES ("78b030a6-8715-49a6-b58c-0a0cc3efe66e",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'test',
	'',
	'// Run the puzzles we know about.
::setz4_spectrum();
::solve();
::cleanup();

/*
::setup();
::setz2_given();
::solve();
::cleanup();

::setup();
::setz4_spectrum();
::solve();
::cleanup();
*/
',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("3b29c269-070a-4127-bda1-09cabddf34c0",
	"78b030a6-8715-49a6-b58c-0a0cc3efe66e");
INSERT INTO ACT_ACT
	VALUES ("3b29c269-070a-4127-bda1-09cabddf34c0",
	'function',
	0,
	"97995e2c-7d37-4140-adab-622b0272e063",
	"00000000-0000-0000-0000-000000000000",
	0,
	'test',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("97995e2c-7d37-4140-adab-622b0272e063",
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"3b29c269-070a-4127-bda1-09cabddf34c0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1caee79d-126c-4b8b-8719-9697c28960bf",
	"97995e2c-7d37-4140-adab-622b0272e063",
	"cc02cdea-e15e-401f-a104-265e34931410",
	2,
	1,
	'test line: 2');
INSERT INTO ACT_FNC
	VALUES ("1caee79d-126c-4b8b-8719-9697c28960bf",
	"22009600-89a7-424a-8f43-e4751f59e7d5",
	2,
	3);
INSERT INTO ACT_SMT
	VALUES ("cc02cdea-e15e-401f-a104-265e34931410",
	"97995e2c-7d37-4140-adab-622b0272e063",
	"b09d6d03-a293-4f53-a81c-dae01406ab36",
	3,
	1,
	'test line: 3');
INSERT INTO ACT_FNC
	VALUES ("cc02cdea-e15e-401f-a104-265e34931410",
	"9f5b86d5-d88d-40df-9f51-a76cc5fdb2ca",
	3,
	3);
INSERT INTO ACT_SMT
	VALUES ("b09d6d03-a293-4f53-a81c-dae01406ab36",
	"97995e2c-7d37-4140-adab-622b0272e063",
	"00000000-0000-0000-0000-000000000000",
	4,
	1,
	'test line: 4');
INSERT INTO ACT_FNC
	VALUES ("b09d6d03-a293-4f53-a81c-dae01406ab36",
	"caa64a12-e93b-4d7a-aa14-61eba5fc02d1",
	4,
	3);
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"caa64a12-e93b-4d7a-aa14-61eba5fc02d1");
INSERT INTO S_SYNC
	VALUES ("caa64a12-e93b-4d7a-aa14-61eba5fc02d1",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'cleanup',
	'',
	'
// Clean up any and all eligible digits.
select many eligibles from instances of ELIGIBLE;
for each eligible in eligibles
  select one cell related by eligible->CELL[R8];
  select one digit related by eligible->DIGIT[R8];
  unrelate cell from digit across R8 using eligible;
  delete object instance eligible;
end for;

// Unrelate the answers.
select many cells from instances of CELL;
for each cell in cells
  select one digit related by cell->DIGIT[R9];
  if ( not_empty digit )
    unrelate cell from digit across R9;
  end if;
end for;

// Delete the digits.
select many digits from instances of DIGIT;
for each digit in digits
  delete object instance digit;
end for;

// Unrelate/delete the cells from the rows, columns and boxes.
// Unrelate/delete the sequences.
// Delete the cells while unrelating the boxes.
select many rows from instances of ROW;
for each row in rows
  select many cells related by row->CELL[R2];
  for each cell in cells
    unrelate row from cell across R2;
  end for;
  select one sequence related by row->SEQUENCE[R1];
  delete object instance sequence;
  delete object instance row;
end for;  
select many columns from instances of COLUMN;
for each column in columns
  select many cells related by column->CELL[R3];
  for each cell in cells
    unrelate column from cell across R3;
  end for;
  select one sequence related by column->SEQUENCE[R1];
  delete object instance sequence;
  delete object instance column;
end for;  
select many boxes from instances of BOX;
for each box in boxes
  select many cells related by box->CELL[R4];
  for each cell in cells
    unrelate box from cell across R4;
    delete object instance cell;
  end for;
  select one sequence related by box->SEQUENCE[R1];
  delete object instance sequence;
  delete object instance box;
end for;  
',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"caa64a12-e93b-4d7a-aa14-61eba5fc02d1");
INSERT INTO ACT_ACT
	VALUES ("1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	'function',
	0,
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cleanup',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	1,
	0,
	0,
	'',
	'',
	'',
	50,
	1,
	49,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("01eff157-1a58-4f9f-a6b1-cc191e27403a",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"44b61452-61c8-4f08-96bf-793f55aba290",
	3,
	1,
	'cleanup line: 3');
INSERT INTO ACT_FIO
	VALUES ("01eff157-1a58-4f9f-a6b1-cc191e27403a",
	"92e8fe00-6827-4c4b-b180-298c6e5954e4",
	1,
	'many',
	"497a9d44-e141-4345-bf11-bb067fb75473",
	3,
	41);
INSERT INTO ACT_SMT
	VALUES ("44b61452-61c8-4f08-96bf-793f55aba290",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"ba50a904-42c9-477a-ae66-0c9ce8e42fbd",
	4,
	1,
	'cleanup line: 4');
INSERT INTO ACT_FOR
	VALUES ("44b61452-61c8-4f08-96bf-793f55aba290",
	"aa2c9bd6-039a-4899-8058-4d7f910bab08",
	1,
	"c59703b6-3068-4d2d-897f-bd04f46050e1",
	"92e8fe00-6827-4c4b-b180-298c6e5954e4",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO ACT_SMT
	VALUES ("ba50a904-42c9-477a-ae66-0c9ce8e42fbd",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"6878f138-b3c4-4492-80a2-025112723c9f",
	12,
	1,
	'cleanup line: 12');
INSERT INTO ACT_FIO
	VALUES ("ba50a904-42c9-477a-ae66-0c9ce8e42fbd",
	"3d3f3f49-2ef0-436f-af19-e3c19c743162",
	1,
	'many',
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	12,
	37);
INSERT INTO ACT_SMT
	VALUES ("6878f138-b3c4-4492-80a2-025112723c9f",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"74abc835-54f0-4f4c-8bef-f45e1ee8cc2f",
	13,
	1,
	'cleanup line: 13');
INSERT INTO ACT_FOR
	VALUES ("6878f138-b3c4-4492-80a2-025112723c9f",
	"294f6e1b-5c00-4245-ad3b-49e01b590f92",
	1,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7",
	"3d3f3f49-2ef0-436f-af19-e3c19c743162",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO ACT_SMT
	VALUES ("74abc835-54f0-4f4c-8bef-f45e1ee8cc2f",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"245c2385-4f17-49e1-b252-c242796ed317",
	21,
	1,
	'cleanup line: 21');
INSERT INTO ACT_FIO
	VALUES ("74abc835-54f0-4f4c-8bef-f45e1ee8cc2f",
	"04016c27-5065-4b9b-848f-a1c84a59a62b",
	1,
	'many',
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	21,
	38);
INSERT INTO ACT_SMT
	VALUES ("245c2385-4f17-49e1-b252-c242796ed317",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"84dd4d2b-f7f4-4988-87e4-f73a236e4e2f",
	22,
	1,
	'cleanup line: 22');
INSERT INTO ACT_FOR
	VALUES ("245c2385-4f17-49e1-b252-c242796ed317",
	"5ef014f2-bd7f-43d6-bea0-d6cd61e9ad23",
	1,
	"39032e9e-1ca7-47ba-bb85-887195d5bd45",
	"04016c27-5065-4b9b-848f-a1c84a59a62b",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO ACT_SMT
	VALUES ("84dd4d2b-f7f4-4988-87e4-f73a236e4e2f",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"d07e71ab-0d9d-4109-9b46-e4751431d07b",
	29,
	1,
	'cleanup line: 29');
INSERT INTO ACT_FIO
	VALUES ("84dd4d2b-f7f4-4988-87e4-f73a236e4e2f",
	"8d237561-3fd8-4b8f-9aaf-822255012274",
	1,
	'many',
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	29,
	36);
INSERT INTO ACT_SMT
	VALUES ("d07e71ab-0d9d-4109-9b46-e4751431d07b",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"b09b53d2-ae72-46e5-926d-841d47aa8613",
	30,
	1,
	'cleanup line: 30');
INSERT INTO ACT_FOR
	VALUES ("d07e71ab-0d9d-4109-9b46-e4751431d07b",
	"391021da-d976-425b-af81-352e598852ce",
	1,
	"bf896b7d-b7e5-4b74-9fe6-c3bb0394d8da",
	"8d237561-3fd8-4b8f-9aaf-822255012274",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO ACT_SMT
	VALUES ("b09b53d2-ae72-46e5-926d-841d47aa8613",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"2f86c170-97de-4d41-ba21-690bfbc79692",
	39,
	1,
	'cleanup line: 39');
INSERT INTO ACT_FIO
	VALUES ("b09b53d2-ae72-46e5-926d-841d47aa8613",
	"ef13f971-2026-4291-96d4-af4787267045",
	1,
	'many',
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	39,
	39);
INSERT INTO ACT_SMT
	VALUES ("2f86c170-97de-4d41-ba21-690bfbc79692",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"4b14f582-97da-433b-aa33-a0e96dbb809b",
	40,
	1,
	'cleanup line: 40');
INSERT INTO ACT_FOR
	VALUES ("2f86c170-97de-4d41-ba21-690bfbc79692",
	"d2fe74d6-5c46-4ed7-8779-c12fb2b8ecea",
	1,
	"395c4b07-25db-4a1c-89c3-8d277ebd1163",
	"ef13f971-2026-4291-96d4-af4787267045",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO ACT_SMT
	VALUES ("4b14f582-97da-433b-aa33-a0e96dbb809b",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"25bfa535-aff5-4271-a8bf-c36599f3126f",
	49,
	1,
	'cleanup line: 49');
INSERT INTO ACT_FIO
	VALUES ("4b14f582-97da-433b-aa33-a0e96dbb809b",
	"05cc34d8-2986-4757-9e36-16a4f514812b",
	1,
	'many',
	"0aa0576e-b480-43da-8919-6b6e88544902",
	49,
	37);
INSERT INTO ACT_SMT
	VALUES ("25bfa535-aff5-4271-a8bf-c36599f3126f",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	"00000000-0000-0000-0000-000000000000",
	50,
	1,
	'cleanup line: 50');
INSERT INTO ACT_FOR
	VALUES ("25bfa535-aff5-4271-a8bf-c36599f3126f",
	"7d770c3d-7868-4f0e-9ddd-beff7805039f",
	1,
	"0cbd84e5-a114-4d0e-8290-7a09c80c41b6",
	"05cc34d8-2986-4757-9e36-16a4f514812b",
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_VAR
	VALUES ("92e8fe00-6827-4c4b-b180-298c6e5954e4",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'eligibles',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("92e8fe00-6827-4c4b-b180-298c6e5954e4",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("6e9c8aac-0804-4809-9aab-17b2166c7282",
	3,
	13,
	21,
	"92e8fe00-6827-4c4b-b180-298c6e5954e4");
INSERT INTO V_LOC
	VALUES ("0fe27f6c-572d-4caf-ad0e-2d821bcc7a3a",
	4,
	22,
	30,
	"92e8fe00-6827-4c4b-b180-298c6e5954e4");
INSERT INTO V_VAR
	VALUES ("c59703b6-3068-4d2d-897f-bd04f46050e1",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'eligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("c59703b6-3068-4d2d-897f-bd04f46050e1",
	1,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("1c949fff-843f-4de1-9711-bc974f5ee35e",
	4,
	10,
	17,
	"c59703b6-3068-4d2d-897f-bd04f46050e1");
INSERT INTO V_LOC
	VALUES ("5ab8b4e5-ee40-4e39-bdd6-a33d8d622481",
	7,
	44,
	51,
	"c59703b6-3068-4d2d-897f-bd04f46050e1");
INSERT INTO V_LOC
	VALUES ("9a45e51c-ea42-4333-b6fa-4051f1bf259b",
	8,
	26,
	33,
	"c59703b6-3068-4d2d-897f-bd04f46050e1");
INSERT INTO V_VAR
	VALUES ("3d3f3f49-2ef0-436f-af19-e3c19c743162",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'cells',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("3d3f3f49-2ef0-436f-af19-e3c19c743162",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("86fe79b4-556b-41c5-88fc-57099073ff66",
	12,
	13,
	17,
	"3d3f3f49-2ef0-436f-af19-e3c19c743162");
INSERT INTO V_LOC
	VALUES ("e93ee21d-7629-4c03-ad78-73b19e1a2fbf",
	13,
	18,
	22,
	"3d3f3f49-2ef0-436f-af19-e3c19c743162");
INSERT INTO V_LOC
	VALUES ("0e5558c4-1ff6-45ee-9787-a878e5c3e848",
	31,
	15,
	19,
	"3d3f3f49-2ef0-436f-af19-e3c19c743162");
INSERT INTO V_LOC
	VALUES ("4055788d-535c-4354-befa-e5b6cc0c6c47",
	32,
	20,
	24,
	"3d3f3f49-2ef0-436f-af19-e3c19c743162");
INSERT INTO V_LOC
	VALUES ("b8aadc9c-9ae8-4757-8d17-31a67d1943a1",
	41,
	15,
	19,
	"3d3f3f49-2ef0-436f-af19-e3c19c743162");
INSERT INTO V_LOC
	VALUES ("c9dc63aa-6536-4565-8ce6-40df7c7e637d",
	42,
	20,
	24,
	"3d3f3f49-2ef0-436f-af19-e3c19c743162");
INSERT INTO V_LOC
	VALUES ("b335a975-cece-4218-804e-86a34353d80b",
	51,
	15,
	19,
	"3d3f3f49-2ef0-436f-af19-e3c19c743162");
INSERT INTO V_LOC
	VALUES ("3322df9d-9605-48f8-a595-325c98bf7c15",
	52,
	20,
	24,
	"3d3f3f49-2ef0-436f-af19-e3c19c743162");
INSERT INTO V_VAR
	VALUES ("64cf65ba-bfa5-4a0e-ad88-174f5538dfc7",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'cell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("64cf65ba-bfa5-4a0e-ad88-174f5538dfc7",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("10386a16-7f1f-4c4c-8186-e6af4adf7b5a",
	13,
	10,
	13,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO V_LOC
	VALUES ("efd185e0-b3de-4098-974e-ecc0d3d9a85f",
	16,
	14,
	17,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO V_LOC
	VALUES ("5ca9018c-61cc-4ab6-9077-dac7e9d20246",
	32,
	12,
	15,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO V_LOC
	VALUES ("3ac17954-5efa-4b24-887d-081a57da2001",
	33,
	23,
	26,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO V_LOC
	VALUES ("36b6a6c9-8301-43d1-823e-355e380502e0",
	42,
	12,
	15,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO V_LOC
	VALUES ("974dcb50-313e-4ab3-beee-b5977749766b",
	43,
	26,
	29,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO V_LOC
	VALUES ("88e21d5e-261c-4808-8951-325910c329e5",
	52,
	12,
	15,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO V_LOC
	VALUES ("ea2b592a-5862-491a-b590-a42ce488825f",
	53,
	23,
	26,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO V_LOC
	VALUES ("0a2c1ee9-f569-4415-9170-3b11022af7e2",
	54,
	28,
	31,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO V_VAR
	VALUES ("04016c27-5065-4b9b-848f-a1c84a59a62b",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'digits',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("04016c27-5065-4b9b-848f-a1c84a59a62b",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("e8696827-9d51-4c5c-a4f9-6412c87d9631",
	21,
	13,
	18,
	"04016c27-5065-4b9b-848f-a1c84a59a62b");
INSERT INTO V_LOC
	VALUES ("31fb125f-6fc2-4250-a5e1-f66276c728c5",
	22,
	19,
	24,
	"04016c27-5065-4b9b-848f-a1c84a59a62b");
INSERT INTO V_VAR
	VALUES ("39032e9e-1ca7-47ba-bb85-887195d5bd45",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'digit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("39032e9e-1ca7-47ba-bb85-887195d5bd45",
	1,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("52e1ef3c-394f-4ea2-950c-0d4c6714ed56",
	22,
	10,
	14,
	"39032e9e-1ca7-47ba-bb85-887195d5bd45");
INSERT INTO V_LOC
	VALUES ("bab630b6-d6c0-40ed-836e-6cabedd8a7ef",
	23,
	26,
	30,
	"39032e9e-1ca7-47ba-bb85-887195d5bd45");
INSERT INTO V_VAR
	VALUES ("8d237561-3fd8-4b8f-9aaf-822255012274",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'rows',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("8d237561-3fd8-4b8f-9aaf-822255012274",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("63f1e4be-1f5a-4798-b299-b816655770e5",
	29,
	13,
	16,
	"8d237561-3fd8-4b8f-9aaf-822255012274");
INSERT INTO V_LOC
	VALUES ("d619b4d2-c92c-4800-8a11-7af433f5ca16",
	30,
	17,
	20,
	"8d237561-3fd8-4b8f-9aaf-822255012274");
INSERT INTO V_VAR
	VALUES ("bf896b7d-b7e5-4b74-9fe6-c3bb0394d8da",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'row',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("bf896b7d-b7e5-4b74-9fe6-c3bb0394d8da",
	1,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("a1ccb379-e1ee-4895-bd37-9d0199cae1ff",
	30,
	10,
	12,
	"bf896b7d-b7e5-4b74-9fe6-c3bb0394d8da");
INSERT INTO V_LOC
	VALUES ("e0fab152-8802-4f2b-a037-7c2352935847",
	33,
	14,
	16,
	"bf896b7d-b7e5-4b74-9fe6-c3bb0394d8da");
INSERT INTO V_LOC
	VALUES ("a7c657ab-ed17-434a-be77-d478c0e81ccf",
	37,
	26,
	28,
	"bf896b7d-b7e5-4b74-9fe6-c3bb0394d8da");
INSERT INTO V_VAR
	VALUES ("ef13f971-2026-4291-96d4-af4787267045",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'columns',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("ef13f971-2026-4291-96d4-af4787267045",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_LOC
	VALUES ("d47a4e14-7a94-4062-bb82-b2af1fc53deb",
	39,
	13,
	19,
	"ef13f971-2026-4291-96d4-af4787267045");
INSERT INTO V_LOC
	VALUES ("549a00fe-b038-496c-b710-17d18a8ee619",
	40,
	20,
	26,
	"ef13f971-2026-4291-96d4-af4787267045");
INSERT INTO V_VAR
	VALUES ("395c4b07-25db-4a1c-89c3-8d277ebd1163",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'column',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("395c4b07-25db-4a1c-89c3-8d277ebd1163",
	1,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_LOC
	VALUES ("bcc1b986-d800-461a-9b9c-1610874cd321",
	40,
	10,
	15,
	"395c4b07-25db-4a1c-89c3-8d277ebd1163");
INSERT INTO V_LOC
	VALUES ("1187cf8e-6a0c-4078-868e-32505b9989b6",
	43,
	14,
	19,
	"395c4b07-25db-4a1c-89c3-8d277ebd1163");
INSERT INTO V_LOC
	VALUES ("0b87f171-d680-4538-b0b5-c16759b3fbe9",
	47,
	26,
	31,
	"395c4b07-25db-4a1c-89c3-8d277ebd1163");
INSERT INTO V_VAR
	VALUES ("05cc34d8-2986-4757-9e36-16a4f514812b",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'boxes',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("05cc34d8-2986-4757-9e36-16a4f514812b",
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("63a29c06-ee74-4e15-948d-2098dd1b1730",
	49,
	13,
	17,
	"05cc34d8-2986-4757-9e36-16a4f514812b");
INSERT INTO V_LOC
	VALUES ("75584433-1c5a-4588-b521-f017b5b0ba01",
	50,
	17,
	21,
	"05cc34d8-2986-4757-9e36-16a4f514812b");
INSERT INTO V_VAR
	VALUES ("0cbd84e5-a114-4d0e-8290-7a09c80c41b6",
	"404bd3f5-8a8a-42dc-b6b7-629e46c7390b",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("0cbd84e5-a114-4d0e-8290-7a09c80c41b6",
	1,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("0a39e039-bb53-4408-bc5e-8a3ebbbfcad0",
	50,
	10,
	12,
	"0cbd84e5-a114-4d0e-8290-7a09c80c41b6");
INSERT INTO V_LOC
	VALUES ("d8ed68ed-3c1c-4995-a80d-786deec35fb5",
	53,
	14,
	16,
	"0cbd84e5-a114-4d0e-8290-7a09c80c41b6");
INSERT INTO V_LOC
	VALUES ("81e1fed4-5de7-49ae-bb4b-e203211bef61",
	58,
	26,
	28,
	"0cbd84e5-a114-4d0e-8290-7a09c80c41b6");
INSERT INTO ACT_BLK
	VALUES ("aa2c9bd6-039a-4899-8058-4d7f910bab08",
	1,
	0,
	0,
	'',
	'',
	'',
	8,
	3,
	6,
	41,
	0,
	0,
	7,
	35,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4f949521-af34-4a4d-8f3c-dadcca809c7e",
	"aa2c9bd6-039a-4899-8058-4d7f910bab08",
	"1aeeeb94-4c11-4296-8d61-8ead106c9bb3",
	5,
	3,
	'cleanup line: 5');
INSERT INTO ACT_SEL
	VALUES ("4f949521-af34-4a4d-8f3c-dadcca809c7e",
	"dc06c51a-4ef3-48bf-850c-e8f181eeb379",
	1,
	'one',
	"abf91dc8-3962-4e2e-9813-7cdf86c6c5c7");
INSERT INTO ACT_SR
	VALUES ("4f949521-af34-4a4d-8f3c-dadcca809c7e");
INSERT INTO ACT_LNK
	VALUES ("f52a8df1-12b0-4892-b25d-3c13a4142ea1",
	'',
	"4f949521-af34-4a4d-8f3c-dadcca809c7e",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("1aeeeb94-4c11-4296-8d61-8ead106c9bb3",
	"aa2c9bd6-039a-4899-8058-4d7f910bab08",
	"2abf7770-311a-496e-bbfb-8c7efe500b35",
	6,
	3,
	'cleanup line: 6');
INSERT INTO ACT_SEL
	VALUES ("1aeeeb94-4c11-4296-8d61-8ead106c9bb3",
	"d5dadb33-474a-4b81-969a-2e36062d5699",
	1,
	'one',
	"98b4097e-c89a-448d-9efd-84e38c7cc32e");
INSERT INTO ACT_SR
	VALUES ("1aeeeb94-4c11-4296-8d61-8ead106c9bb3");
INSERT INTO ACT_LNK
	VALUES ("cf4d6419-1ea2-429f-b303-de3688b0e496",
	'',
	"1aeeeb94-4c11-4296-8d61-8ead106c9bb3",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	6,
	41,
	6,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("2abf7770-311a-496e-bbfb-8c7efe500b35",
	"aa2c9bd6-039a-4899-8058-4d7f910bab08",
	"5b066794-6aca-45b3-bdb6-d964fece7e5d",
	7,
	3,
	'cleanup line: 7');
INSERT INTO ACT_URU
	VALUES ("2abf7770-311a-496e-bbfb-8c7efe500b35",
	"dc06c51a-4ef3-48bf-850c-e8f181eeb379",
	"d5dadb33-474a-4b81-969a-2e36062d5699",
	"c59703b6-3068-4d2d-897f-bd04f46050e1",
	'',
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	7,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5b066794-6aca-45b3-bdb6-d964fece7e5d",
	"aa2c9bd6-039a-4899-8058-4d7f910bab08",
	"00000000-0000-0000-0000-000000000000",
	8,
	3,
	'cleanup line: 8');
INSERT INTO ACT_DEL
	VALUES ("5b066794-6aca-45b3-bdb6-d964fece7e5d",
	"c59703b6-3068-4d2d-897f-bd04f46050e1");
INSERT INTO V_VAL
	VALUES ("abf91dc8-3962-4e2e-9813-7cdf86c6c5c7",
	0,
	0,
	5,
	30,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"aa2c9bd6-039a-4899-8058-4d7f910bab08");
INSERT INTO V_IRF
	VALUES ("abf91dc8-3962-4e2e-9813-7cdf86c6c5c7",
	"c59703b6-3068-4d2d-897f-bd04f46050e1");
INSERT INTO V_VAL
	VALUES ("98b4097e-c89a-448d-9efd-84e38c7cc32e",
	0,
	0,
	6,
	31,
	38,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"aa2c9bd6-039a-4899-8058-4d7f910bab08");
INSERT INTO V_IRF
	VALUES ("98b4097e-c89a-448d-9efd-84e38c7cc32e",
	"c59703b6-3068-4d2d-897f-bd04f46050e1");
INSERT INTO V_VAR
	VALUES ("dc06c51a-4ef3-48bf-850c-e8f181eeb379",
	"aa2c9bd6-039a-4899-8058-4d7f910bab08",
	'cell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("dc06c51a-4ef3-48bf-850c-e8f181eeb379",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("024e124b-74db-43ad-9dc2-9771db493487",
	5,
	14,
	17,
	"dc06c51a-4ef3-48bf-850c-e8f181eeb379");
INSERT INTO V_LOC
	VALUES ("6f27d12c-3e5a-47a5-b386-f4e5de6ad40f",
	7,
	12,
	15,
	"dc06c51a-4ef3-48bf-850c-e8f181eeb379");
INSERT INTO V_VAR
	VALUES ("d5dadb33-474a-4b81-969a-2e36062d5699",
	"aa2c9bd6-039a-4899-8058-4d7f910bab08",
	'digit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("d5dadb33-474a-4b81-969a-2e36062d5699",
	0,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("da27c935-aca6-4cfd-b0f0-32b22af86fd0",
	6,
	14,
	18,
	"d5dadb33-474a-4b81-969a-2e36062d5699");
INSERT INTO V_LOC
	VALUES ("366fb745-c18e-446f-a38c-262cc7db418c",
	7,
	22,
	26,
	"d5dadb33-474a-4b81-969a-2e36062d5699");
INSERT INTO ACT_BLK
	VALUES ("294f6e1b-5c00-4245-ad3b-49e01b590f92",
	1,
	0,
	0,
	'',
	'',
	'',
	15,
	3,
	14,
	37,
	0,
	0,
	14,
	43,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("22ab6465-7c2f-4856-a28a-6f82650a688c",
	"294f6e1b-5c00-4245-ad3b-49e01b590f92",
	"796ec689-f452-40ab-96d5-96a942fc4311",
	14,
	3,
	'cleanup line: 14');
INSERT INTO ACT_SEL
	VALUES ("22ab6465-7c2f-4856-a28a-6f82650a688c",
	"bc29912e-9de1-45ba-9a6c-36df800664f0",
	1,
	'one',
	"1b7301e7-2ae1-452b-9680-b554f3d66511");
INSERT INTO ACT_SR
	VALUES ("22ab6465-7c2f-4856-a28a-6f82650a688c");
INSERT INTO ACT_LNK
	VALUES ("bece7ada-a34a-402b-aa94-c6ab88cb55e0",
	'',
	"22ab6465-7c2f-4856-a28a-6f82650a688c",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"00000000-0000-0000-0000-000000000000",
	2,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	14,
	37,
	14,
	43,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("796ec689-f452-40ab-96d5-96a942fc4311",
	"294f6e1b-5c00-4245-ad3b-49e01b590f92",
	"00000000-0000-0000-0000-000000000000",
	15,
	3,
	'cleanup line: 15');
INSERT INTO ACT_IF
	VALUES ("796ec689-f452-40ab-96d5-96a942fc4311",
	"177a3b04-aaf6-4bcf-97ee-514dac3dd3f9",
	"6e2a0aa8-438e-47f0-93db-24072a7252b7",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("1b7301e7-2ae1-452b-9680-b554f3d66511",
	0,
	0,
	14,
	31,
	34,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"294f6e1b-5c00-4245-ad3b-49e01b590f92");
INSERT INTO V_IRF
	VALUES ("1b7301e7-2ae1-452b-9680-b554f3d66511",
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO V_VAL
	VALUES ("e071e8cd-d468-449a-b726-c0e7c45a54e9",
	0,
	0,
	15,
	18,
	22,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"294f6e1b-5c00-4245-ad3b-49e01b590f92");
INSERT INTO V_IRF
	VALUES ("e071e8cd-d468-449a-b726-c0e7c45a54e9",
	"bc29912e-9de1-45ba-9a6c-36df800664f0");
INSERT INTO V_VAL
	VALUES ("6e2a0aa8-438e-47f0-93db-24072a7252b7",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"294f6e1b-5c00-4245-ad3b-49e01b590f92");
INSERT INTO V_UNY
	VALUES ("6e2a0aa8-438e-47f0-93db-24072a7252b7",
	"e071e8cd-d468-449a-b726-c0e7c45a54e9",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("bc29912e-9de1-45ba-9a6c-36df800664f0",
	"294f6e1b-5c00-4245-ad3b-49e01b590f92",
	'digit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("bc29912e-9de1-45ba-9a6c-36df800664f0",
	0,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("8b39544c-cf68-4517-9214-f67115ef4d9d",
	14,
	14,
	18,
	"bc29912e-9de1-45ba-9a6c-36df800664f0");
INSERT INTO V_LOC
	VALUES ("5c981b40-af6d-4f9e-9821-9cdc10e32df6",
	16,
	24,
	28,
	"bc29912e-9de1-45ba-9a6c-36df800664f0");
INSERT INTO ACT_BLK
	VALUES ("177a3b04-aaf6-4bcf-97ee-514dac3dd3f9",
	0,
	0,
	0,
	'',
	'',
	'',
	16,
	5,
	0,
	0,
	0,
	0,
	16,
	37,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("96f68000-5538-4f76-9d8b-737faa041e31",
	"177a3b04-aaf6-4bcf-97ee-514dac3dd3f9",
	"00000000-0000-0000-0000-000000000000",
	16,
	5,
	'cleanup line: 16');
INSERT INTO ACT_UNR
	VALUES ("96f68000-5538-4f76-9d8b-737faa041e31",
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7",
	"bc29912e-9de1-45ba-9a6c-36df800664f0",
	'',
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	16,
	37,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("5ef014f2-bd7f-43d6-bea0-d6cd61e9ad23",
	0,
	0,
	0,
	'',
	'',
	'',
	23,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8ffeb9e6-566a-4fb8-8fff-3d5b9a3d6a6b",
	"5ef014f2-bd7f-43d6-bea0-d6cd61e9ad23",
	"00000000-0000-0000-0000-000000000000",
	23,
	3,
	'cleanup line: 23');
INSERT INTO ACT_DEL
	VALUES ("8ffeb9e6-566a-4fb8-8fff-3d5b9a3d6a6b",
	"39032e9e-1ca7-47ba-bb85-887195d5bd45");
INSERT INTO ACT_BLK
	VALUES ("391021da-d976-425b-af81-352e598852ce",
	1,
	0,
	0,
	'',
	'',
	'',
	37,
	3,
	35,
	39,
	0,
	0,
	35,
	48,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("08fd89d1-4729-4630-bb2d-2e43373e9988",
	"391021da-d976-425b-af81-352e598852ce",
	"edf2be01-0d9c-4fcd-90f0-540adb054139",
	31,
	3,
	'cleanup line: 31');
INSERT INTO ACT_SEL
	VALUES ("08fd89d1-4729-4630-bb2d-2e43373e9988",
	"3d3f3f49-2ef0-436f-af19-e3c19c743162",
	0,
	'many',
	"78f394ea-75f8-40cf-b39e-1d95edc09c8d");
INSERT INTO ACT_SR
	VALUES ("08fd89d1-4729-4630-bb2d-2e43373e9988");
INSERT INTO ACT_LNK
	VALUES ("2ea639d5-bc0a-4155-8ee8-9d9e0dca64ae",
	'',
	"08fd89d1-4729-4630-bb2d-2e43373e9988",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"00000000-0000-0000-0000-000000000000",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	31,
	37,
	31,
	42,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("edf2be01-0d9c-4fcd-90f0-540adb054139",
	"391021da-d976-425b-af81-352e598852ce",
	"97233461-fb7f-4073-9e91-7076852c902c",
	32,
	3,
	'cleanup line: 32');
INSERT INTO ACT_FOR
	VALUES ("edf2be01-0d9c-4fcd-90f0-540adb054139",
	"1bb110f6-e258-4742-a8dc-4d121f6ae43a",
	0,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7",
	"3d3f3f49-2ef0-436f-af19-e3c19c743162",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO ACT_SMT
	VALUES ("97233461-fb7f-4073-9e91-7076852c902c",
	"391021da-d976-425b-af81-352e598852ce",
	"bd9cdc07-88e9-45e7-b4b2-bd0dcfa6c9f0",
	35,
	3,
	'cleanup line: 35');
INSERT INTO ACT_SEL
	VALUES ("97233461-fb7f-4073-9e91-7076852c902c",
	"ca139479-8349-4541-ac0e-63d0e67d455f",
	1,
	'one',
	"4dee730b-e716-4b1e-9904-fe9a5c68eb8a");
INSERT INTO ACT_SR
	VALUES ("97233461-fb7f-4073-9e91-7076852c902c");
INSERT INTO ACT_LNK
	VALUES ("33b1d54f-2dba-4a6a-81ba-0db38850498c",
	'',
	"97233461-fb7f-4073-9e91-7076852c902c",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	35,
	39,
	35,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("bd9cdc07-88e9-45e7-b4b2-bd0dcfa6c9f0",
	"391021da-d976-425b-af81-352e598852ce",
	"543e1c98-8513-4bd2-a0a7-1e7f1a8ef7b9",
	36,
	3,
	'cleanup line: 36');
INSERT INTO ACT_DEL
	VALUES ("bd9cdc07-88e9-45e7-b4b2-bd0dcfa6c9f0",
	"ca139479-8349-4541-ac0e-63d0e67d455f");
INSERT INTO ACT_SMT
	VALUES ("543e1c98-8513-4bd2-a0a7-1e7f1a8ef7b9",
	"391021da-d976-425b-af81-352e598852ce",
	"00000000-0000-0000-0000-000000000000",
	37,
	3,
	'cleanup line: 37');
INSERT INTO ACT_DEL
	VALUES ("543e1c98-8513-4bd2-a0a7-1e7f1a8ef7b9",
	"bf896b7d-b7e5-4b74-9fe6-c3bb0394d8da");
INSERT INTO V_VAL
	VALUES ("78f394ea-75f8-40cf-b39e-1d95edc09c8d",
	0,
	0,
	31,
	32,
	34,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"391021da-d976-425b-af81-352e598852ce");
INSERT INTO V_IRF
	VALUES ("78f394ea-75f8-40cf-b39e-1d95edc09c8d",
	"bf896b7d-b7e5-4b74-9fe6-c3bb0394d8da");
INSERT INTO V_VAL
	VALUES ("4dee730b-e716-4b1e-9904-fe9a5c68eb8a",
	0,
	0,
	35,
	34,
	36,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"391021da-d976-425b-af81-352e598852ce");
INSERT INTO V_IRF
	VALUES ("4dee730b-e716-4b1e-9904-fe9a5c68eb8a",
	"bf896b7d-b7e5-4b74-9fe6-c3bb0394d8da");
INSERT INTO V_VAR
	VALUES ("ca139479-8349-4541-ac0e-63d0e67d455f",
	"391021da-d976-425b-af81-352e598852ce",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("ca139479-8349-4541-ac0e-63d0e67d455f",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("906c8c59-46b1-4a20-84c0-c833be1fa7a0",
	35,
	14,
	21,
	"ca139479-8349-4541-ac0e-63d0e67d455f");
INSERT INTO V_LOC
	VALUES ("0001eb4e-2bc5-4677-8569-ea935fea6ef1",
	36,
	26,
	33,
	"ca139479-8349-4541-ac0e-63d0e67d455f");
INSERT INTO ACT_BLK
	VALUES ("1bb110f6-e258-4742-a8dc-4d121f6ae43a",
	0,
	0,
	0,
	'',
	'',
	'',
	33,
	5,
	0,
	0,
	0,
	0,
	33,
	35,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b6af452a-87b9-4fc0-96fe-47c39af97892",
	"1bb110f6-e258-4742-a8dc-4d121f6ae43a",
	"00000000-0000-0000-0000-000000000000",
	33,
	5,
	'cleanup line: 33');
INSERT INTO ACT_UNR
	VALUES ("b6af452a-87b9-4fc0-96fe-47c39af97892",
	"bf896b7d-b7e5-4b74-9fe6-c3bb0394d8da",
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7",
	'',
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	33,
	35,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("d2fe74d6-5c46-4ed7-8779-c12fb2b8ecea",
	1,
	0,
	0,
	'',
	'',
	'',
	47,
	3,
	45,
	42,
	0,
	0,
	45,
	51,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5ea6e59e-e77a-4dcf-a2b0-63a520abde81",
	"d2fe74d6-5c46-4ed7-8779-c12fb2b8ecea",
	"70705854-4dcb-45a7-999e-2b174260facd",
	41,
	3,
	'cleanup line: 41');
INSERT INTO ACT_SEL
	VALUES ("5ea6e59e-e77a-4dcf-a2b0-63a520abde81",
	"3d3f3f49-2ef0-436f-af19-e3c19c743162",
	0,
	'many',
	"a1b91e44-1f4b-4c80-b922-7b090d03851b");
INSERT INTO ACT_SR
	VALUES ("5ea6e59e-e77a-4dcf-a2b0-63a520abde81");
INSERT INTO ACT_LNK
	VALUES ("8e9c5c08-316a-41dc-9cea-ec38216f075f",
	'',
	"5ea6e59e-e77a-4dcf-a2b0-63a520abde81",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"00000000-0000-0000-0000-000000000000",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	41,
	40,
	41,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("70705854-4dcb-45a7-999e-2b174260facd",
	"d2fe74d6-5c46-4ed7-8779-c12fb2b8ecea",
	"6697529a-fa97-4e61-9d90-b86dfab7b914",
	42,
	3,
	'cleanup line: 42');
INSERT INTO ACT_FOR
	VALUES ("70705854-4dcb-45a7-999e-2b174260facd",
	"641af903-dee0-4df9-a10e-7e22ee4663fe",
	0,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7",
	"3d3f3f49-2ef0-436f-af19-e3c19c743162",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO ACT_SMT
	VALUES ("6697529a-fa97-4e61-9d90-b86dfab7b914",
	"d2fe74d6-5c46-4ed7-8779-c12fb2b8ecea",
	"8a455a41-2132-43b6-81c2-0a548ca9df22",
	45,
	3,
	'cleanup line: 45');
INSERT INTO ACT_SEL
	VALUES ("6697529a-fa97-4e61-9d90-b86dfab7b914",
	"e0f06761-70ce-4ac6-a814-08c739974b75",
	1,
	'one',
	"9161c703-5b51-4a12-b0de-e47f7fb54c37");
INSERT INTO ACT_SR
	VALUES ("6697529a-fa97-4e61-9d90-b86dfab7b914");
INSERT INTO ACT_LNK
	VALUES ("04ba2039-d77a-464c-b21c-d1265ca47978",
	'',
	"6697529a-fa97-4e61-9d90-b86dfab7b914",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	45,
	42,
	45,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8a455a41-2132-43b6-81c2-0a548ca9df22",
	"d2fe74d6-5c46-4ed7-8779-c12fb2b8ecea",
	"7c3cfbf6-4097-4279-a252-1626ba0e6be3",
	46,
	3,
	'cleanup line: 46');
INSERT INTO ACT_DEL
	VALUES ("8a455a41-2132-43b6-81c2-0a548ca9df22",
	"e0f06761-70ce-4ac6-a814-08c739974b75");
INSERT INTO ACT_SMT
	VALUES ("7c3cfbf6-4097-4279-a252-1626ba0e6be3",
	"d2fe74d6-5c46-4ed7-8779-c12fb2b8ecea",
	"00000000-0000-0000-0000-000000000000",
	47,
	3,
	'cleanup line: 47');
INSERT INTO ACT_DEL
	VALUES ("7c3cfbf6-4097-4279-a252-1626ba0e6be3",
	"395c4b07-25db-4a1c-89c3-8d277ebd1163");
INSERT INTO V_VAL
	VALUES ("a1b91e44-1f4b-4c80-b922-7b090d03851b",
	0,
	0,
	41,
	32,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"d2fe74d6-5c46-4ed7-8779-c12fb2b8ecea");
INSERT INTO V_IRF
	VALUES ("a1b91e44-1f4b-4c80-b922-7b090d03851b",
	"395c4b07-25db-4a1c-89c3-8d277ebd1163");
INSERT INTO V_VAL
	VALUES ("9161c703-5b51-4a12-b0de-e47f7fb54c37",
	0,
	0,
	45,
	34,
	39,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"d2fe74d6-5c46-4ed7-8779-c12fb2b8ecea");
INSERT INTO V_IRF
	VALUES ("9161c703-5b51-4a12-b0de-e47f7fb54c37",
	"395c4b07-25db-4a1c-89c3-8d277ebd1163");
INSERT INTO V_VAR
	VALUES ("e0f06761-70ce-4ac6-a814-08c739974b75",
	"d2fe74d6-5c46-4ed7-8779-c12fb2b8ecea",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("e0f06761-70ce-4ac6-a814-08c739974b75",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("878ff61e-cbcb-4160-9f54-3e0edec31e27",
	45,
	14,
	21,
	"e0f06761-70ce-4ac6-a814-08c739974b75");
INSERT INTO V_LOC
	VALUES ("1ad7b84d-6458-4ffc-b0d7-095517182acb",
	46,
	26,
	33,
	"e0f06761-70ce-4ac6-a814-08c739974b75");
INSERT INTO ACT_BLK
	VALUES ("641af903-dee0-4df9-a10e-7e22ee4663fe",
	0,
	0,
	0,
	'',
	'',
	'',
	43,
	5,
	0,
	0,
	0,
	0,
	43,
	38,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("cad66925-11d6-43cb-9aba-76598a4e387d",
	"641af903-dee0-4df9-a10e-7e22ee4663fe",
	"00000000-0000-0000-0000-000000000000",
	43,
	5,
	'cleanup line: 43');
INSERT INTO ACT_UNR
	VALUES ("cad66925-11d6-43cb-9aba-76598a4e387d",
	"395c4b07-25db-4a1c-89c3-8d277ebd1163",
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7",
	'',
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	43,
	38,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("7d770c3d-7868-4f0e-9ddd-beff7805039f",
	1,
	0,
	0,
	'',
	'',
	'',
	58,
	3,
	56,
	39,
	0,
	0,
	56,
	48,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("056bf464-305a-4d40-af30-65504317654f",
	"7d770c3d-7868-4f0e-9ddd-beff7805039f",
	"c531e5f6-2d14-4ec3-a56b-04b06dea3cb8",
	51,
	3,
	'cleanup line: 51');
INSERT INTO ACT_SEL
	VALUES ("056bf464-305a-4d40-af30-65504317654f",
	"3d3f3f49-2ef0-436f-af19-e3c19c743162",
	0,
	'many',
	"6a16f088-63c2-44b9-aa4d-69d5c0f018cc");
INSERT INTO ACT_SR
	VALUES ("056bf464-305a-4d40-af30-65504317654f");
INSERT INTO ACT_LNK
	VALUES ("7924e22c-6a2a-4fd3-b916-37c256b2630d",
	'',
	"056bf464-305a-4d40-af30-65504317654f",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"00000000-0000-0000-0000-000000000000",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	51,
	37,
	51,
	42,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c531e5f6-2d14-4ec3-a56b-04b06dea3cb8",
	"7d770c3d-7868-4f0e-9ddd-beff7805039f",
	"dc7b51c6-65d3-4a4c-b792-ce1862327178",
	52,
	3,
	'cleanup line: 52');
INSERT INTO ACT_FOR
	VALUES ("c531e5f6-2d14-4ec3-a56b-04b06dea3cb8",
	"d3707f8e-4ef7-4a46-ba5b-de70d9ecb177",
	0,
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7",
	"3d3f3f49-2ef0-436f-af19-e3c19c743162",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO ACT_SMT
	VALUES ("dc7b51c6-65d3-4a4c-b792-ce1862327178",
	"7d770c3d-7868-4f0e-9ddd-beff7805039f",
	"ff499873-17d6-46d5-a6b8-132820f0afba",
	56,
	3,
	'cleanup line: 56');
INSERT INTO ACT_SEL
	VALUES ("dc7b51c6-65d3-4a4c-b792-ce1862327178",
	"f442fe5d-fc79-4661-ba0e-3bc5f40a3459",
	1,
	'one',
	"f344bf8c-a64f-4377-b15d-105ac85f3611");
INSERT INTO ACT_SR
	VALUES ("dc7b51c6-65d3-4a4c-b792-ce1862327178");
INSERT INTO ACT_LNK
	VALUES ("ad86a0ee-dba0-4eae-954c-f8b645b3c51d",
	'',
	"dc7b51c6-65d3-4a4c-b792-ce1862327178",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	56,
	39,
	56,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ff499873-17d6-46d5-a6b8-132820f0afba",
	"7d770c3d-7868-4f0e-9ddd-beff7805039f",
	"c45cdc70-e568-4a45-8deb-feeddd3d4686",
	57,
	3,
	'cleanup line: 57');
INSERT INTO ACT_DEL
	VALUES ("ff499873-17d6-46d5-a6b8-132820f0afba",
	"f442fe5d-fc79-4661-ba0e-3bc5f40a3459");
INSERT INTO ACT_SMT
	VALUES ("c45cdc70-e568-4a45-8deb-feeddd3d4686",
	"7d770c3d-7868-4f0e-9ddd-beff7805039f",
	"00000000-0000-0000-0000-000000000000",
	58,
	3,
	'cleanup line: 58');
INSERT INTO ACT_DEL
	VALUES ("c45cdc70-e568-4a45-8deb-feeddd3d4686",
	"0cbd84e5-a114-4d0e-8290-7a09c80c41b6");
INSERT INTO V_VAL
	VALUES ("6a16f088-63c2-44b9-aa4d-69d5c0f018cc",
	0,
	0,
	51,
	32,
	34,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"7d770c3d-7868-4f0e-9ddd-beff7805039f");
INSERT INTO V_IRF
	VALUES ("6a16f088-63c2-44b9-aa4d-69d5c0f018cc",
	"0cbd84e5-a114-4d0e-8290-7a09c80c41b6");
INSERT INTO V_VAL
	VALUES ("f344bf8c-a64f-4377-b15d-105ac85f3611",
	0,
	0,
	56,
	34,
	36,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"7d770c3d-7868-4f0e-9ddd-beff7805039f");
INSERT INTO V_IRF
	VALUES ("f344bf8c-a64f-4377-b15d-105ac85f3611",
	"0cbd84e5-a114-4d0e-8290-7a09c80c41b6");
INSERT INTO V_VAR
	VALUES ("f442fe5d-fc79-4661-ba0e-3bc5f40a3459",
	"7d770c3d-7868-4f0e-9ddd-beff7805039f",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("f442fe5d-fc79-4661-ba0e-3bc5f40a3459",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("9af40de0-6399-4dde-8c50-f57e3e6248fd",
	56,
	14,
	21,
	"f442fe5d-fc79-4661-ba0e-3bc5f40a3459");
INSERT INTO V_LOC
	VALUES ("792aca15-6d69-42c1-b58e-5cf9be223f0c",
	57,
	26,
	33,
	"f442fe5d-fc79-4661-ba0e-3bc5f40a3459");
INSERT INTO ACT_BLK
	VALUES ("d3707f8e-4ef7-4a46-ba5b-de70d9ecb177",
	0,
	0,
	0,
	'',
	'',
	'',
	54,
	5,
	0,
	0,
	0,
	0,
	53,
	35,
	0,
	0,
	0,
	0,
	0,
	"1504c4d1-9e53-4f2f-b46e-ce6dbf7e55ca",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ad000930-5f8b-42bd-9532-02655a695ae5",
	"d3707f8e-4ef7-4a46-ba5b-de70d9ecb177",
	"121cb148-7c21-421e-905c-de44c7e78ccf",
	53,
	5,
	'cleanup line: 53');
INSERT INTO ACT_UNR
	VALUES ("ad000930-5f8b-42bd-9532-02655a695ae5",
	"0cbd84e5-a114-4d0e-8290-7a09c80c41b6",
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7",
	'',
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	53,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("121cb148-7c21-421e-905c-de44c7e78ccf",
	"d3707f8e-4ef7-4a46-ba5b-de70d9ecb177",
	"00000000-0000-0000-0000-000000000000",
	54,
	5,
	'cleanup line: 54');
INSERT INTO ACT_DEL
	VALUES ("121cb148-7c21-421e-905c-de44c7e78ccf",
	"64cf65ba-bfa5-4a0e-ad88-174f5538dfc7");
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"cf5fdebc-fb7c-40f7-969f-7da8af3f8be3");
INSERT INTO S_SYNC
	VALUES ("cf5fdebc-fb7c-40f7-969f-7da8af3f8be3",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'xit',
	'',
	'::cleanup();
ARCH::shutdown();',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("77f6851f-1f22-4420-8071-98b84815ad0d",
	"cf5fdebc-fb7c-40f7-969f-7da8af3f8be3");
INSERT INTO ACT_ACT
	VALUES ("77f6851f-1f22-4420-8071-98b84815ad0d",
	'function',
	0,
	"8672db70-1931-4a12-a04b-4d40caf8b92f",
	"00000000-0000-0000-0000-000000000000",
	0,
	'xit',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("8672db70-1931-4a12-a04b-4d40caf8b92f",
	0,
	0,
	0,
	'ARCH',
	'',
	'',
	2,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"77f6851f-1f22-4420-8071-98b84815ad0d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f465cff1-d17e-4fa8-82e8-1b0f15cf149f",
	"8672db70-1931-4a12-a04b-4d40caf8b92f",
	"089a65c0-2bf9-4424-a646-531c9f6bf07b",
	1,
	1,
	'xit line: 1');
INSERT INTO ACT_FNC
	VALUES ("f465cff1-d17e-4fa8-82e8-1b0f15cf149f",
	"caa64a12-e93b-4d7a-aa14-61eba5fc02d1",
	1,
	3);
INSERT INTO ACT_SMT
	VALUES ("089a65c0-2bf9-4424-a646-531c9f6bf07b",
	"8672db70-1931-4a12-a04b-4d40caf8b92f",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'xit line: 2');
INSERT INTO ACT_BRG
	VALUES ("089a65c0-2bf9-4424-a646-531c9f6bf07b",
	"d10f74d7-601e-47c5-bb4b-22a3137290e3",
	2,
	7,
	2,
	1);
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"828bed8f-d64e-48e6-be13-4fa070cf8252");
INSERT INTO S_SYNC
	VALUES ("828bed8f-d64e-48e6-be13-4fa070cf8252",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'cort',
	'',
	'',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("ea72531f-cc79-4f6f-b12b-079bf8afeedc",
	"828bed8f-d64e-48e6-be13-4fa070cf8252");
INSERT INTO ACT_ACT
	VALUES ("ea72531f-cc79-4f6f-b12b-079bf8afeedc",
	'function',
	0,
	"253c160a-b4c8-448b-bd00-1b912da74e49",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cort',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("253c160a-b4c8-448b-bd00-1b912da74e49",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ea72531f-cc79-4f6f-b12b-079bf8afeedc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"f97eb768-9a00-418e-8be6-7878a8618fbe");
INSERT INTO S_SYNC
	VALUES ("f97eb768-9a00-418e-8be6-7878a8618fbe",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'solve_concurrently',
	'',
	'score = CELL::score();
::display();

select any row from instances of ROW;
generate ROW1:update() to row;',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("8c87c338-6a56-4a7f-97c1-603017f02961",
	"f97eb768-9a00-418e-8be6-7878a8618fbe");
INSERT INTO ACT_ACT
	VALUES ("8c87c338-6a56-4a7f-97c1-603017f02961",
	'function',
	0,
	"a80aa2ad-6c89-47ca-aed1-4cd9fda0dfcb",
	"00000000-0000-0000-0000-000000000000",
	0,
	'solve_concurrently',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a80aa2ad-6c89-47ca-aed1-4cd9fda0dfcb",
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	5,
	1,
	4,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"8c87c338-6a56-4a7f-97c1-603017f02961",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8abaac2c-d7bc-4065-8d9d-8d7e5052edc9",
	"a80aa2ad-6c89-47ca-aed1-4cd9fda0dfcb",
	"06c1f074-46ea-42d4-b7a2-bfaedc7dd43f",
	1,
	1,
	'solve_concurrently line: 1');
INSERT INTO ACT_AI
	VALUES ("8abaac2c-d7bc-4065-8d9d-8d7e5052edc9",
	"6959ba90-5594-4d0b-9f10-c0c8905163f1",
	"8fda40cd-dd26-44c0-8266-1e85bd25be97",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("06c1f074-46ea-42d4-b7a2-bfaedc7dd43f",
	"a80aa2ad-6c89-47ca-aed1-4cd9fda0dfcb",
	"77a43e39-645b-48ec-adc3-6780ec53ae03",
	2,
	1,
	'solve_concurrently line: 2');
INSERT INTO ACT_FNC
	VALUES ("06c1f074-46ea-42d4-b7a2-bfaedc7dd43f",
	"1306c98a-2790-4d7c-9822-6a721684d866",
	2,
	3);
INSERT INTO ACT_SMT
	VALUES ("77a43e39-645b-48ec-adc3-6780ec53ae03",
	"a80aa2ad-6c89-47ca-aed1-4cd9fda0dfcb",
	"40f02e23-ecae-4c42-942c-24097875b255",
	4,
	1,
	'solve_concurrently line: 4');
INSERT INTO ACT_FIO
	VALUES ("77a43e39-645b-48ec-adc3-6780ec53ae03",
	"e0dff364-1649-4182-97b1-2673cdf4776c",
	1,
	'any',
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	4,
	34);
INSERT INTO ACT_SMT
	VALUES ("40f02e23-ecae-4c42-942c-24097875b255",
	"a80aa2ad-6c89-47ca-aed1-4cd9fda0dfcb",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'solve_concurrently line: 5');
INSERT INTO E_ESS
	VALUES ("40f02e23-ecae-4c42-942c-24097875b255",
	1,
	0,
	5,
	10,
	5,
	15,
	4,
	34,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("40f02e23-ecae-4c42-942c-24097875b255");
INSERT INTO E_GSME
	VALUES ("40f02e23-ecae-4c42-942c-24097875b255",
	"565ead81-20dd-40d5-a168-fbed8112e7aa",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16");
INSERT INTO E_GEN
	VALUES ("40f02e23-ecae-4c42-942c-24097875b255",
	"e0dff364-1649-4182-97b1-2673cdf4776c");
INSERT INTO V_VAL
	VALUES ("8fda40cd-dd26-44c0-8266-1e85bd25be97",
	1,
	1,
	1,
	1,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"a80aa2ad-6c89-47ca-aed1-4cd9fda0dfcb");
INSERT INTO V_TVL
	VALUES ("8fda40cd-dd26-44c0-8266-1e85bd25be97",
	"c70dfbd0-1efd-4dce-846e-f9c2abd07f8a");
INSERT INTO V_VAL
	VALUES ("6959ba90-5594-4d0b-9f10-c0c8905163f1",
	0,
	0,
	1,
	15,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"a80aa2ad-6c89-47ca-aed1-4cd9fda0dfcb");
INSERT INTO V_TRV
	VALUES ("6959ba90-5594-4d0b-9f10-c0c8905163f1",
	"85d40a8c-8b51-408d-85d3-824453116397",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	9);
INSERT INTO V_VAR
	VALUES ("c70dfbd0-1efd-4dce-846e-f9c2abd07f8a",
	"a80aa2ad-6c89-47ca-aed1-4cd9fda0dfcb",
	'score',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("c70dfbd0-1efd-4dce-846e-f9c2abd07f8a",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("165f005f-cc59-44d5-8eff-ec29eca54b5f",
	1,
	1,
	5,
	"c70dfbd0-1efd-4dce-846e-f9c2abd07f8a");
INSERT INTO V_VAR
	VALUES ("e0dff364-1649-4182-97b1-2673cdf4776c",
	"a80aa2ad-6c89-47ca-aed1-4cd9fda0dfcb",
	'row',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("e0dff364-1649-4182-97b1-2673cdf4776c",
	0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("2fbc6bb6-b139-43de-8451-04ffd5adec99",
	4,
	12,
	14,
	"e0dff364-1649-4182-97b1-2673cdf4776c");
INSERT INTO V_LOC
	VALUES ("880091d2-2ce0-4966-94aa-ade8cf03ae63",
	5,
	27,
	29,
	"e0dff364-1649-4182-97b1-2673cdf4776c");
INSERT INTO S_FIP
	VALUES ("c4e9fdb3-233f-46f2-9f10-497944921654",
	"902cf6e3-0b1b-45e2-873c-700a2c6fcea2");
INSERT INTO S_SYNC
	VALUES ("902cf6e3-0b1b-45e2-873c-700a2c6fcea2",
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	'check',
	'',
	'score = CELL::score();
if ( 81 == score )
  LOG::LogSuccess( message:"solved the puzzle" );
else
  LOG::LogFailure( message:"failed to solved the puzzle" );
end if;
::display();',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'');
INSERT INTO ACT_FNB
	VALUES ("4a239673-ff9a-4a3c-8c98-6988ad52a061",
	"902cf6e3-0b1b-45e2-873c-700a2c6fcea2");
INSERT INTO ACT_ACT
	VALUES ("4a239673-ff9a-4a3c-8c98-6988ad52a061",
	'function',
	0,
	"15ba70ae-689c-4ab4-b111-5a8661b035fe",
	"00000000-0000-0000-0000-000000000000",
	0,
	'check',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("15ba70ae-689c-4ab4-b111-5a8661b035fe",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	7,
	1,
	1,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4a239673-ff9a-4a3c-8c98-6988ad52a061",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b596413f-e2c4-47c7-91db-8baa1048e9d2",
	"15ba70ae-689c-4ab4-b111-5a8661b035fe",
	"05c1bc3a-7767-460c-a3e3-9d58a5fca104",
	1,
	1,
	'check line: 1');
INSERT INTO ACT_AI
	VALUES ("b596413f-e2c4-47c7-91db-8baa1048e9d2",
	"e400dc14-b5f4-4ab2-9bd2-c163e08ff285",
	"cf1e5c47-8fca-43e7-8c3f-606b1fe1030d",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("05c1bc3a-7767-460c-a3e3-9d58a5fca104",
	"15ba70ae-689c-4ab4-b111-5a8661b035fe",
	"4dcd0e39-28fe-4710-ad08-5ab2020b5896",
	2,
	1,
	'check line: 2');
INSERT INTO ACT_IF
	VALUES ("05c1bc3a-7767-460c-a3e3-9d58a5fca104",
	"f3c415f0-679d-4392-938a-a6aaecc41202",
	"8d467c9c-155e-4d80-b92b-8ebea83eabe8",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("317b369e-8ed4-469f-9fe9-dc2ce896b6ab",
	"15ba70ae-689c-4ab4-b111-5a8661b035fe",
	"00000000-0000-0000-0000-000000000000",
	4,
	1,
	'check line: 4');
INSERT INTO ACT_E
	VALUES ("317b369e-8ed4-469f-9fe9-dc2ce896b6ab",
	"39f32644-6cdb-4f58-b2e4-349c38cb1073",
	"05c1bc3a-7767-460c-a3e3-9d58a5fca104");
INSERT INTO ACT_SMT
	VALUES ("4dcd0e39-28fe-4710-ad08-5ab2020b5896",
	"15ba70ae-689c-4ab4-b111-5a8661b035fe",
	"00000000-0000-0000-0000-000000000000",
	7,
	1,
	'check line: 7');
INSERT INTO ACT_FNC
	VALUES ("4dcd0e39-28fe-4710-ad08-5ab2020b5896",
	"1306c98a-2790-4d7c-9822-6a721684d866",
	7,
	3);
INSERT INTO V_VAL
	VALUES ("cf1e5c47-8fca-43e7-8c3f-606b1fe1030d",
	1,
	1,
	1,
	1,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"15ba70ae-689c-4ab4-b111-5a8661b035fe");
INSERT INTO V_TVL
	VALUES ("cf1e5c47-8fca-43e7-8c3f-606b1fe1030d",
	"3d865c6b-4e65-46f8-bc4b-6306bdc976fa");
INSERT INTO V_VAL
	VALUES ("e400dc14-b5f4-4ab2-9bd2-c163e08ff285",
	0,
	0,
	1,
	15,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"15ba70ae-689c-4ab4-b111-5a8661b035fe");
INSERT INTO V_TRV
	VALUES ("e400dc14-b5f4-4ab2-9bd2-c163e08ff285",
	"85d40a8c-8b51-408d-85d3-824453116397",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	9);
INSERT INTO V_VAL
	VALUES ("a184475f-69c6-4a70-bb4a-44cf06c0331f",
	0,
	0,
	2,
	6,
	7,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"15ba70ae-689c-4ab4-b111-5a8661b035fe");
INSERT INTO V_LIN
	VALUES ("a184475f-69c6-4a70-bb4a-44cf06c0331f",
	'81');
INSERT INTO V_VAL
	VALUES ("8d467c9c-155e-4d80-b92b-8ebea83eabe8",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"15ba70ae-689c-4ab4-b111-5a8661b035fe");
INSERT INTO V_BIN
	VALUES ("8d467c9c-155e-4d80-b92b-8ebea83eabe8",
	"2d43dcb3-674a-4182-a450-979a9dd091c5",
	"a184475f-69c6-4a70-bb4a-44cf06c0331f",
	'==');
INSERT INTO V_VAL
	VALUES ("2d43dcb3-674a-4182-a450-979a9dd091c5",
	0,
	0,
	2,
	12,
	16,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"15ba70ae-689c-4ab4-b111-5a8661b035fe");
INSERT INTO V_TVL
	VALUES ("2d43dcb3-674a-4182-a450-979a9dd091c5",
	"3d865c6b-4e65-46f8-bc4b-6306bdc976fa");
INSERT INTO V_VAR
	VALUES ("3d865c6b-4e65-46f8-bc4b-6306bdc976fa",
	"15ba70ae-689c-4ab4-b111-5a8661b035fe",
	'score',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("3d865c6b-4e65-46f8-bc4b-6306bdc976fa",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("3578ba65-cbeb-47e7-aa65-641118d21bc5",
	1,
	1,
	5,
	"3d865c6b-4e65-46f8-bc4b-6306bdc976fa");
INSERT INTO V_LOC
	VALUES ("54097706-111a-4580-9cd9-fb5ac76e6eaf",
	2,
	12,
	16,
	"3d865c6b-4e65-46f8-bc4b-6306bdc976fa");
INSERT INTO ACT_BLK
	VALUES ("f3c415f0-679d-4392-938a-a6aaecc41202",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	3,
	3,
	3,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4a239673-ff9a-4a3c-8c98-6988ad52a061",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("a6313e77-1930-417e-b5d8-8b3ea95d59f0",
	"f3c415f0-679d-4392-938a-a6aaecc41202",
	"00000000-0000-0000-0000-000000000000",
	3,
	3,
	'check line: 3');
INSERT INTO ACT_BRG
	VALUES ("a6313e77-1930-417e-b5d8-8b3ea95d59f0",
	"15f7937e-f6a0-46c4-88b5-c74594313811",
	3,
	8,
	3,
	3);
INSERT INTO V_VAL
	VALUES ("ab80e40a-7240-489f-bf55-fce70cae7190",
	0,
	0,
	3,
	28,
	45,
	0,
	0,
	0,
	0,
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	"f3c415f0-679d-4392-938a-a6aaecc41202");
INSERT INTO V_LST
	VALUES ("ab80e40a-7240-489f-bf55-fce70cae7190",
	'solved the puzzle');
INSERT INTO V_PAR
	VALUES ("ab80e40a-7240-489f-bf55-fce70cae7190",
	"a6313e77-1930-417e-b5d8-8b3ea95d59f0",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	3,
	20);
INSERT INTO ACT_BLK
	VALUES ("39f32644-6cdb-4f58-b2e4-349c38cb1073",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	5,
	3,
	5,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4a239673-ff9a-4a3c-8c98-6988ad52a061",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4adcc40e-cc18-459b-a111-4f76df53597d",
	"39f32644-6cdb-4f58-b2e4-349c38cb1073",
	"00000000-0000-0000-0000-000000000000",
	5,
	3,
	'check line: 5');
INSERT INTO ACT_BRG
	VALUES ("4adcc40e-cc18-459b-a111-4f76df53597d",
	"f598b35c-392f-4d82-90a7-a4f0d9281584",
	5,
	8,
	5,
	3);
INSERT INTO V_VAL
	VALUES ("819e785d-6cf6-4755-8960-6f89b8208b5a",
	0,
	0,
	5,
	28,
	55,
	0,
	0,
	0,
	0,
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	"39f32644-6cdb-4f58-b2e4-349c38cb1073");
INSERT INTO V_LST
	VALUES ("819e785d-6cf6-4755-8960-6f89b8208b5a",
	'failed to solved the puzzle');
INSERT INTO V_PAR
	VALUES ("819e785d-6cf6-4755-8960-6f89b8208b5a",
	"4adcc40e-cc18-459b-a111-4f76df53597d",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	5,
	20);
INSERT INTO S_SID
	VALUES ("abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO S_SS
	VALUES ("8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8",
	'sudoku',
	'',
	'',
	0,
	"abdb22a4-fcc5-43ba-ae7b-f829a734749b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_OBJ
	VALUES ("0aa0576e-b480-43da-8919-6b6e88544902",
	'box',
	4,
	'BOX',
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO O_TFR
	VALUES ("9eb8190d-e504-49dd-8d1c-ff3f41269990",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	'prune',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	1,
	'// Cut off eligible digits that match any answer digit for this sequence.

temperature = 0;
select many answerdigits related by self->CELL[R4]->DIGIT[R9] where ( selected.value != 0 );
select many eligibles related by self->CELL[R4]->ELIGIBLE[R8];
for each eligible in eligibles
  for each answerdigit in answerdigits
    if ( eligible.digit_value == answerdigit.value )
      select one opencell related by eligible->CELL[R8];
      if ( opencell.answer_value != eligible.digit_value )
        unrelate answerdigit from opencell across R8 using eligible;
        delete object instance eligible;
        // generate CELL1:eliminate( digit:answerdigit.value ) to opencell;
      end if;
      temperature = 1;
      break;
    end if;
  end for;
end for;
  
select many opencells related by self->CELL[R4]
  where ( selected.answer_value == 0 );
if ( empty opencells )
  temperature = 100;
end if;
for each opencell in opencells
  // Notice if we have the answer now.
  select many eligibles related by opencell->ELIGIBLE[R8];
  c = cardinality eligibles;
  if ( 1 == c )
    select any answer related by opencell->ELIGIBLE[R8];
    opencell.answer( answer_digit:answer.digit_value );
    // generate CELL2:answer( digit:answer.digit_value ) to opencell;
    temperature = 1;
  end if;
end for;

return temperature;
',
	1,
	'',
	"f511495a-58e2-4110-b856-013b6627b6ae");
INSERT INTO ACT_OPB
	VALUES ("358cb221-5019-493a-b923-04caaeabcbcb",
	"9eb8190d-e504-49dd-8d1c-ff3f41269990");
INSERT INTO ACT_ACT
	VALUES ("358cb221-5019-493a-b923-04caaeabcbcb",
	'operation',
	0,
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	"00000000-0000-0000-0000-000000000000",
	0,
	'box::prune',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("3faa9eef-7dd1-496c-a581-dcc86de604db",
	1,
	0,
	1,
	'',
	'',
	'',
	38,
	1,
	21,
	40,
	0,
	0,
	21,
	45,
	0,
	0,
	0,
	0,
	0,
	"358cb221-5019-493a-b923-04caaeabcbcb",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("fb72bc07-902d-47cf-9015-0f3e99a49601",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	"55e2ea36-9a62-4843-8a42-7b2f5ca20351",
	3,
	1,
	'box::prune line: 3');
INSERT INTO ACT_AI
	VALUES ("fb72bc07-902d-47cf-9015-0f3e99a49601",
	"cd3e4639-6873-4f26-83b5-2dac3c958e84",
	"885de8b8-2ce7-4921-b260-9b0d08f4489f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("55e2ea36-9a62-4843-8a42-7b2f5ca20351",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	"6bca50d6-4ba1-4530-8cb6-4d05de9ce745",
	4,
	1,
	'box::prune line: 4');
INSERT INTO ACT_SEL
	VALUES ("55e2ea36-9a62-4843-8a42-7b2f5ca20351",
	"eafffd37-d685-4a5a-94ef-9d270306ddfe",
	1,
	'many',
	"0f509cb9-94f0-43ce-b9cb-3d2fe690d087");
INSERT INTO ACT_SRW
	VALUES ("55e2ea36-9a62-4843-8a42-7b2f5ca20351",
	"a81228aa-912e-47d0-8b8b-26fc1f560ef2");
INSERT INTO ACT_LNK
	VALUES ("74bfc8ed-290a-4cb7-bfe3-7dcc014b87f1",
	'',
	"55e2ea36-9a62-4843-8a42-7b2f5ca20351",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"7055f49e-cb9e-4076-aa33-48bc592cb1fc",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	4,
	43,
	4,
	48,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("7055f49e-cb9e-4076-aa33-48bc592cb1fc",
	'',
	"00000000-0000-0000-0000-000000000000",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"00000000-0000-0000-0000-000000000000",
	2,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	4,
	53,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("6bca50d6-4ba1-4530-8cb6-4d05de9ce745",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	"b3445b42-fba6-4e00-83ca-153b6aa32f5c",
	5,
	1,
	'box::prune line: 5');
INSERT INTO ACT_SEL
	VALUES ("6bca50d6-4ba1-4530-8cb6-4d05de9ce745",
	"77fbafaf-d688-48bb-8523-ac52d855c252",
	1,
	'many',
	"ccf6ce80-0955-455c-bff5-e2c93f12249f");
INSERT INTO ACT_SR
	VALUES ("6bca50d6-4ba1-4530-8cb6-4d05de9ce745");
INSERT INTO ACT_LNK
	VALUES ("152e0ace-6dbf-4753-84da-5423cd3abeb4",
	'',
	"6bca50d6-4ba1-4530-8cb6-4d05de9ce745",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"e8413a0f-bddb-495d-a845-3c23bbc26e6f",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("e8413a0f-bddb-495d-a845-3c23bbc26e6f",
	'',
	"00000000-0000-0000-0000-000000000000",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b3445b42-fba6-4e00-83ca-153b6aa32f5c",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	"8c93b382-2f93-4883-b0a5-f996de64be56",
	6,
	1,
	'box::prune line: 6');
INSERT INTO ACT_FOR
	VALUES ("b3445b42-fba6-4e00-83ca-153b6aa32f5c",
	"fc4fd9ef-ed2e-43da-958c-e3345f95656e",
	1,
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2",
	"77fbafaf-d688-48bb-8523-ac52d855c252",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO ACT_SMT
	VALUES ("8c93b382-2f93-4883-b0a5-f996de64be56",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	"fb8a0e24-4837-4676-ac97-1bdf827ceca4",
	21,
	1,
	'box::prune line: 21');
INSERT INTO ACT_SEL
	VALUES ("8c93b382-2f93-4883-b0a5-f996de64be56",
	"e54eeb1c-d54e-4c97-a7cf-8e66d4fc986b",
	1,
	'many',
	"67f59bb0-be57-4ba6-b1fe-41bf16fc2393");
INSERT INTO ACT_SRW
	VALUES ("8c93b382-2f93-4883-b0a5-f996de64be56",
	"75ec1f91-1b82-41be-888a-d586f6e186ff");
INSERT INTO ACT_LNK
	VALUES ("3e79a2ae-4a7e-4469-b0a6-4667820692ce",
	'',
	"8c93b382-2f93-4883-b0a5-f996de64be56",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"00000000-0000-0000-0000-000000000000",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	21,
	40,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("fb8a0e24-4837-4676-ac97-1bdf827ceca4",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	"d6081e30-f8fc-483a-9274-ac369cbc6e95",
	23,
	1,
	'box::prune line: 23');
INSERT INTO ACT_IF
	VALUES ("fb8a0e24-4837-4676-ac97-1bdf827ceca4",
	"d68fe66a-015d-4afe-8cc3-777575ac4714",
	"4c84343a-a434-4b0a-be73-a6854d6e12eb",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d6081e30-f8fc-483a-9274-ac369cbc6e95",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	"9c6e02c7-00a9-4602-a2f6-4e4e4b773636",
	26,
	1,
	'box::prune line: 26');
INSERT INTO ACT_FOR
	VALUES ("d6081e30-f8fc-483a-9274-ac369cbc6e95",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a",
	1,
	"c77386dd-b526-4ccc-8764-522fab90fd4d",
	"e54eeb1c-d54e-4c97-a7cf-8e66d4fc986b",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO ACT_SMT
	VALUES ("9c6e02c7-00a9-4602-a2f6-4e4e4b773636",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	"00000000-0000-0000-0000-000000000000",
	38,
	1,
	'box::prune line: 38');
INSERT INTO ACT_RET
	VALUES ("9c6e02c7-00a9-4602-a2f6-4e4e4b773636",
	"c5aa3c85-b8d6-4b48-9f45-081fae3003fe");
INSERT INTO V_VAL
	VALUES ("885de8b8-2ce7-4921-b260-9b0d08f4489f",
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_TVL
	VALUES ("885de8b8-2ce7-4921-b260-9b0d08f4489f",
	"6d7391be-f08e-4c93-bdd6-8177ad6c430d");
INSERT INTO V_VAL
	VALUES ("cd3e4639-6873-4f26-83b5-2dac3c958e84",
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_LIN
	VALUES ("cd3e4639-6873-4f26-83b5-2dac3c958e84",
	'0');
INSERT INTO V_VAL
	VALUES ("0f509cb9-94f0-43ce-b9cb-3d2fe690d087",
	0,
	0,
	4,
	37,
	40,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_IRF
	VALUES ("0f509cb9-94f0-43ce-b9cb-3d2fe690d087",
	"9c0771f4-6395-4e93-b384-ffdfc1cc725c");
INSERT INTO V_VAL
	VALUES ("94c983f6-04f3-43f7-9e4f-8b7df839583b",
	0,
	0,
	4,
	71,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_SLR
	VALUES ("94c983f6-04f3-43f7-9e4f-8b7df839583b",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("3d398182-38cb-4c03-8081-b2780b7a82b9",
	0,
	0,
	4,
	80,
	84,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_AVL
	VALUES ("3d398182-38cb-4c03-8081-b2780b7a82b9",
	"94c983f6-04f3-43f7-9e4f-8b7df839583b",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO V_VAL
	VALUES ("a81228aa-912e-47d0-8b8b-26fc1f560ef2",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_BIN
	VALUES ("a81228aa-912e-47d0-8b8b-26fc1f560ef2",
	"697c1037-4ab7-47be-9eac-85393e5749d3",
	"3d398182-38cb-4c03-8081-b2780b7a82b9",
	'!=');
INSERT INTO V_VAL
	VALUES ("697c1037-4ab7-47be-9eac-85393e5749d3",
	0,
	0,
	4,
	89,
	89,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_LIN
	VALUES ("697c1037-4ab7-47be-9eac-85393e5749d3",
	'0');
INSERT INTO V_VAL
	VALUES ("ccf6ce80-0955-455c-bff5-e2c93f12249f",
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_IRF
	VALUES ("ccf6ce80-0955-455c-bff5-e2c93f12249f",
	"9c0771f4-6395-4e93-b384-ffdfc1cc725c");
INSERT INTO V_VAL
	VALUES ("67f59bb0-be57-4ba6-b1fe-41bf16fc2393",
	0,
	0,
	21,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_IRF
	VALUES ("67f59bb0-be57-4ba6-b1fe-41bf16fc2393",
	"9c0771f4-6395-4e93-b384-ffdfc1cc725c");
INSERT INTO V_VAL
	VALUES ("36c9fab4-d2d9-4845-b8cf-83189b94a108",
	0,
	0,
	22,
	11,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_SLR
	VALUES ("36c9fab4-d2d9-4845-b8cf-83189b94a108",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("d65ab6f7-a481-482c-8378-33c45ecbaf5c",
	0,
	0,
	22,
	20,
	31,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_AVL
	VALUES ("d65ab6f7-a481-482c-8378-33c45ecbaf5c",
	"36c9fab4-d2d9-4845-b8cf-83189b94a108",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4");
INSERT INTO V_VAL
	VALUES ("75ec1f91-1b82-41be-888a-d586f6e186ff",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_BIN
	VALUES ("75ec1f91-1b82-41be-888a-d586f6e186ff",
	"05e4bc53-f442-4197-ade2-1aed0d722195",
	"d65ab6f7-a481-482c-8378-33c45ecbaf5c",
	'==');
INSERT INTO V_VAL
	VALUES ("05e4bc53-f442-4197-ade2-1aed0d722195",
	0,
	0,
	22,
	36,
	36,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_LIN
	VALUES ("05e4bc53-f442-4197-ade2-1aed0d722195",
	'0');
INSERT INTO V_VAL
	VALUES ("c0d4b19c-9f1f-4a8a-8bad-491437b70559",
	0,
	0,
	23,
	12,
	20,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_ISR
	VALUES ("c0d4b19c-9f1f-4a8a-8bad-491437b70559",
	"e54eeb1c-d54e-4c97-a7cf-8e66d4fc986b");
INSERT INTO V_VAL
	VALUES ("4c84343a-a434-4b0a-be73-a6854d6e12eb",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_UNY
	VALUES ("4c84343a-a434-4b0a-be73-a6854d6e12eb",
	"c0d4b19c-9f1f-4a8a-8bad-491437b70559",
	'empty');
INSERT INTO V_VAL
	VALUES ("c5aa3c85-b8d6-4b48-9f45-081fae3003fe",
	0,
	0,
	38,
	8,
	18,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3faa9eef-7dd1-496c-a581-dcc86de604db");
INSERT INTO V_TVL
	VALUES ("c5aa3c85-b8d6-4b48-9f45-081fae3003fe",
	"6d7391be-f08e-4c93-bdd6-8177ad6c430d");
INSERT INTO V_VAR
	VALUES ("6d7391be-f08e-4c93-bdd6-8177ad6c430d",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	'temperature',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("6d7391be-f08e-4c93-bdd6-8177ad6c430d",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("bea7fd5f-4cd5-411b-9cde-377518f43c3b",
	3,
	1,
	11,
	"6d7391be-f08e-4c93-bdd6-8177ad6c430d");
INSERT INTO V_LOC
	VALUES ("4f0e8625-651d-494d-bbf3-db772af45eb2",
	15,
	7,
	17,
	"6d7391be-f08e-4c93-bdd6-8177ad6c430d");
INSERT INTO V_LOC
	VALUES ("6d67b25b-d489-4613-902b-fc7e41d2ff39",
	24,
	3,
	13,
	"6d7391be-f08e-4c93-bdd6-8177ad6c430d");
INSERT INTO V_LOC
	VALUES ("2021bdc5-d891-466b-b6ac-80e4268df3d3",
	34,
	5,
	15,
	"6d7391be-f08e-4c93-bdd6-8177ad6c430d");
INSERT INTO V_LOC
	VALUES ("4066dcb9-096f-4397-84e0-f05ed39e83c6",
	38,
	8,
	18,
	"6d7391be-f08e-4c93-bdd6-8177ad6c430d");
INSERT INTO V_VAR
	VALUES ("eafffd37-d685-4a5a-94ef-9d270306ddfe",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	'answerdigits',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("eafffd37-d685-4a5a-94ef-9d270306ddfe",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("659cb1f1-a045-48c7-ac0b-4961b038e79a",
	4,
	13,
	24,
	"eafffd37-d685-4a5a-94ef-9d270306ddfe");
INSERT INTO V_LOC
	VALUES ("7ce200b3-1e71-4b3d-a771-67b047302140",
	7,
	27,
	38,
	"eafffd37-d685-4a5a-94ef-9d270306ddfe");
INSERT INTO V_VAR
	VALUES ("9c0771f4-6395-4e93-b384-ffdfc1cc725c",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("9c0771f4-6395-4e93-b384-ffdfc1cc725c",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_VAR
	VALUES ("77fbafaf-d688-48bb-8523-ac52d855c252",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	'eligibles',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("77fbafaf-d688-48bb-8523-ac52d855c252",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("c68c30b2-81c6-42d9-81e4-2807bcb2be7a",
	5,
	13,
	21,
	"77fbafaf-d688-48bb-8523-ac52d855c252");
INSERT INTO V_LOC
	VALUES ("af227276-9b9b-4b49-bd55-69d3e840af59",
	6,
	22,
	30,
	"77fbafaf-d688-48bb-8523-ac52d855c252");
INSERT INTO V_LOC
	VALUES ("9c003283-00b3-40e6-b34f-8f43d09157f4",
	28,
	15,
	23,
	"77fbafaf-d688-48bb-8523-ac52d855c252");
INSERT INTO V_VAR
	VALUES ("1ac38df7-0390-45d3-92c0-997c0e4cdbf2",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	'eligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("1ac38df7-0390-45d3-92c0-997c0e4cdbf2",
	1,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("a71b433f-bd24-488a-9d33-da027cfb9e50",
	6,
	10,
	17,
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2");
INSERT INTO V_LOC
	VALUES ("a8cf07d2-92d4-409e-ab83-15f02a3916a6",
	8,
	10,
	17,
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2");
INSERT INTO V_LOC
	VALUES ("6cb77173-c278-46e0-b444-60ee9e13f053",
	10,
	37,
	44,
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2");
INSERT INTO V_LOC
	VALUES ("9cca1830-02cb-411a-9433-633bf3bc97d3",
	11,
	60,
	67,
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2");
INSERT INTO V_LOC
	VALUES ("960b289c-4aba-4131-b410-cda6c8e06d65",
	12,
	32,
	39,
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2");
INSERT INTO V_VAR
	VALUES ("e54eeb1c-d54e-4c97-a7cf-8e66d4fc986b",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	'opencells',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("e54eeb1c-d54e-4c97-a7cf-8e66d4fc986b",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("f843f791-ef88-40cd-9096-9256c36003e2",
	21,
	13,
	21,
	"e54eeb1c-d54e-4c97-a7cf-8e66d4fc986b");
INSERT INTO V_LOC
	VALUES ("8d1f296c-9d74-4c98-955b-8a144b4d54a0",
	26,
	22,
	30,
	"e54eeb1c-d54e-4c97-a7cf-8e66d4fc986b");
INSERT INTO V_VAR
	VALUES ("c77386dd-b526-4ccc-8764-522fab90fd4d",
	"3faa9eef-7dd1-496c-a581-dcc86de604db",
	'opencell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("c77386dd-b526-4ccc-8764-522fab90fd4d",
	1,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("c94e21b9-b151-42e6-a422-f2ef3ccc32b4",
	26,
	10,
	17,
	"c77386dd-b526-4ccc-8764-522fab90fd4d");
INSERT INTO V_LOC
	VALUES ("3383dab8-5e62-401a-b152-77590ce8411c",
	32,
	5,
	12,
	"c77386dd-b526-4ccc-8764-522fab90fd4d");
INSERT INTO ACT_BLK
	VALUES ("fc4fd9ef-ed2e-43da-958c-e3345f95656e",
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"358cb221-5019-493a-b923-04caaeabcbcb",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c5ee6ed7-af43-439e-a27c-b936d930d146",
	"fc4fd9ef-ed2e-43da-958c-e3345f95656e",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'box::prune line: 7');
INSERT INTO ACT_FOR
	VALUES ("c5ee6ed7-af43-439e-a27c-b936d930d146",
	"b3e1e651-935c-4900-8089-f96d1a7a68c8",
	1,
	"0d7d0813-763c-4bda-8428-55765674e78b",
	"eafffd37-d685-4a5a-94ef-9d270306ddfe",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_VAR
	VALUES ("0d7d0813-763c-4bda-8428-55765674e78b",
	"fc4fd9ef-ed2e-43da-958c-e3345f95656e",
	'answerdigit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("0d7d0813-763c-4bda-8428-55765674e78b",
	1,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("b5c4f1ab-2e57-4370-9d30-f5b0f38dfba5",
	7,
	12,
	22,
	"0d7d0813-763c-4bda-8428-55765674e78b");
INSERT INTO V_LOC
	VALUES ("51660204-ba58-447a-b3ad-568dc7cc8a35",
	8,
	34,
	44,
	"0d7d0813-763c-4bda-8428-55765674e78b");
INSERT INTO V_LOC
	VALUES ("bd414fc7-858e-4198-a5db-52b09cfce4cc",
	11,
	18,
	28,
	"0d7d0813-763c-4bda-8428-55765674e78b");
INSERT INTO ACT_BLK
	VALUES ("b3e1e651-935c-4900-8089-f96d1a7a68c8",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"358cb221-5019-493a-b923-04caaeabcbcb",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("815bac7f-cac2-4cc3-bc31-5fb261ada762",
	"b3e1e651-935c-4900-8089-f96d1a7a68c8",
	"00000000-0000-0000-0000-000000000000",
	8,
	5,
	'box::prune line: 8');
INSERT INTO ACT_IF
	VALUES ("815bac7f-cac2-4cc3-bc31-5fb261ada762",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d",
	"09cae899-a2eb-49f5-9eee-23aedab0193d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("084d3843-e1e4-4eed-8e5b-a47ebd65f391",
	0,
	0,
	8,
	10,
	17,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"b3e1e651-935c-4900-8089-f96d1a7a68c8");
INSERT INTO V_IRF
	VALUES ("084d3843-e1e4-4eed-8e5b-a47ebd65f391",
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2");
INSERT INTO V_VAL
	VALUES ("5e73161c-009c-4908-9886-8a0823578213",
	0,
	0,
	8,
	19,
	29,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"b3e1e651-935c-4900-8089-f96d1a7a68c8");
INSERT INTO V_AVL
	VALUES ("5e73161c-009c-4908-9886-8a0823578213",
	"084d3843-e1e4-4eed-8e5b-a47ebd65f391",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("09cae899-a2eb-49f5-9eee-23aedab0193d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"b3e1e651-935c-4900-8089-f96d1a7a68c8");
INSERT INTO V_BIN
	VALUES ("09cae899-a2eb-49f5-9eee-23aedab0193d",
	"5bd8bf3d-5719-4d31-aa97-d06777e117cd",
	"5e73161c-009c-4908-9886-8a0823578213",
	'==');
INSERT INTO V_VAL
	VALUES ("3c5c168b-9939-4f26-b428-41c78082f27e",
	0,
	0,
	8,
	34,
	44,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"b3e1e651-935c-4900-8089-f96d1a7a68c8");
INSERT INTO V_IRF
	VALUES ("3c5c168b-9939-4f26-b428-41c78082f27e",
	"0d7d0813-763c-4bda-8428-55765674e78b");
INSERT INTO V_VAL
	VALUES ("5bd8bf3d-5719-4d31-aa97-d06777e117cd",
	0,
	0,
	8,
	46,
	50,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"b3e1e651-935c-4900-8089-f96d1a7a68c8");
INSERT INTO V_AVL
	VALUES ("5bd8bf3d-5719-4d31-aa97-d06777e117cd",
	"3c5c168b-9939-4f26-b428-41c78082f27e",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO ACT_BLK
	VALUES ("4eb5529a-c2a2-4796-8f7c-b98674a2344d",
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	7,
	9,
	48,
	0,
	0,
	9,
	53,
	0,
	0,
	0,
	0,
	0,
	"358cb221-5019-493a-b923-04caaeabcbcb",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5beec0e2-b0d1-4e22-a1a4-c7b34bc14706",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d",
	"00e2eb7b-68fd-45a5-a2ab-2298489c3f1a",
	9,
	7,
	'box::prune line: 9');
INSERT INTO ACT_SEL
	VALUES ("5beec0e2-b0d1-4e22-a1a4-c7b34bc14706",
	"4c333ee7-6bb3-4b68-8142-097a66732c17",
	1,
	'one',
	"a86e0dec-010c-4006-800c-9342ac97626e");
INSERT INTO ACT_SR
	VALUES ("5beec0e2-b0d1-4e22-a1a4-c7b34bc14706");
INSERT INTO ACT_LNK
	VALUES ("437378e0-4347-4d7b-9364-ad2daa0b2d26",
	'',
	"5beec0e2-b0d1-4e22-a1a4-c7b34bc14706",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	9,
	48,
	9,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("00e2eb7b-68fd-45a5-a2ab-2298489c3f1a",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d",
	"3f916145-8243-43ae-9970-9ee26235e90e",
	10,
	7,
	'box::prune line: 10');
INSERT INTO ACT_IF
	VALUES ("00e2eb7b-68fd-45a5-a2ab-2298489c3f1a",
	"e420b864-5a41-4aeb-aa9d-661970ed17a6",
	"a5d03334-eb60-4410-b603-e376847671df",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3f916145-8243-43ae-9970-9ee26235e90e",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d",
	"0e06d993-ac5d-424f-ad86-422c0ae2d774",
	15,
	7,
	'box::prune line: 15');
INSERT INTO ACT_AI
	VALUES ("3f916145-8243-43ae-9970-9ee26235e90e",
	"7ab046a8-734c-4ebc-9dcc-9818ad9c7866",
	"035597c4-9135-42bb-b4b9-ef22f0e6c83f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0e06d993-ac5d-424f-ad86-422c0ae2d774",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	'box::prune line: 16');
INSERT INTO ACT_BRK
	VALUES ("0e06d993-ac5d-424f-ad86-422c0ae2d774");
INSERT INTO V_VAL
	VALUES ("a86e0dec-010c-4006-800c-9342ac97626e",
	0,
	0,
	9,
	38,
	45,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d");
INSERT INTO V_IRF
	VALUES ("a86e0dec-010c-4006-800c-9342ac97626e",
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2");
INSERT INTO V_VAL
	VALUES ("154c6995-4d85-4fc1-afb7-14a80299e486",
	0,
	0,
	10,
	12,
	19,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d");
INSERT INTO V_IRF
	VALUES ("154c6995-4d85-4fc1-afb7-14a80299e486",
	"4c333ee7-6bb3-4b68-8142-097a66732c17");
INSERT INTO V_VAL
	VALUES ("eba85c2b-9f87-4724-9275-83598fa83f3a",
	0,
	0,
	10,
	21,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d");
INSERT INTO V_AVL
	VALUES ("eba85c2b-9f87-4724-9275-83598fa83f3a",
	"154c6995-4d85-4fc1-afb7-14a80299e486",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4");
INSERT INTO V_VAL
	VALUES ("a5d03334-eb60-4410-b603-e376847671df",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d");
INSERT INTO V_BIN
	VALUES ("a5d03334-eb60-4410-b603-e376847671df",
	"d14c6f2a-0849-4395-87e6-2f21942939b6",
	"eba85c2b-9f87-4724-9275-83598fa83f3a",
	'!=');
INSERT INTO V_VAL
	VALUES ("03cda9f0-df61-4fbb-b7eb-15eea30d8a55",
	0,
	0,
	10,
	37,
	44,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d");
INSERT INTO V_IRF
	VALUES ("03cda9f0-df61-4fbb-b7eb-15eea30d8a55",
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2");
INSERT INTO V_VAL
	VALUES ("d14c6f2a-0849-4395-87e6-2f21942939b6",
	0,
	0,
	10,
	46,
	56,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d");
INSERT INTO V_AVL
	VALUES ("d14c6f2a-0849-4395-87e6-2f21942939b6",
	"03cda9f0-df61-4fbb-b7eb-15eea30d8a55",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("035597c4-9135-42bb-b4b9-ef22f0e6c83f",
	1,
	0,
	15,
	7,
	17,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d");
INSERT INTO V_TVL
	VALUES ("035597c4-9135-42bb-b4b9-ef22f0e6c83f",
	"6d7391be-f08e-4c93-bdd6-8177ad6c430d");
INSERT INTO V_VAL
	VALUES ("7ab046a8-734c-4ebc-9dcc-9818ad9c7866",
	0,
	0,
	15,
	21,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d");
INSERT INTO V_LIN
	VALUES ("7ab046a8-734c-4ebc-9dcc-9818ad9c7866",
	'1');
INSERT INTO V_VAR
	VALUES ("4c333ee7-6bb3-4b68-8142-097a66732c17",
	"4eb5529a-c2a2-4796-8f7c-b98674a2344d",
	'opencell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("4c333ee7-6bb3-4b68-8142-097a66732c17",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("13cc449f-1118-494a-af55-b0b1bced8377",
	9,
	18,
	25,
	"4c333ee7-6bb3-4b68-8142-097a66732c17");
INSERT INTO V_LOC
	VALUES ("bc01ea89-8ed8-46ce-a7c5-c4ba28775198",
	10,
	12,
	19,
	"4c333ee7-6bb3-4b68-8142-097a66732c17");
INSERT INTO V_LOC
	VALUES ("560c207d-4cad-48c7-9691-8d357e9ff91b",
	11,
	35,
	42,
	"4c333ee7-6bb3-4b68-8142-097a66732c17");
INSERT INTO ACT_BLK
	VALUES ("e420b864-5a41-4aeb-aa9d-661970ed17a6",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	9,
	0,
	0,
	0,
	0,
	11,
	51,
	0,
	0,
	0,
	0,
	0,
	"358cb221-5019-493a-b923-04caaeabcbcb",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d8df00eb-f559-4eae-a640-89a01679a8f3",
	"e420b864-5a41-4aeb-aa9d-661970ed17a6",
	"5e40adb9-02fb-4bfb-95ea-4ca5166ec64e",
	11,
	9,
	'box::prune line: 11');
INSERT INTO ACT_URU
	VALUES ("d8df00eb-f559-4eae-a640-89a01679a8f3",
	"0d7d0813-763c-4bda-8428-55765674e78b",
	"4c333ee7-6bb3-4b68-8142-097a66732c17",
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2",
	'',
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	11,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5e40adb9-02fb-4bfb-95ea-4ca5166ec64e",
	"e420b864-5a41-4aeb-aa9d-661970ed17a6",
	"00000000-0000-0000-0000-000000000000",
	12,
	9,
	'box::prune line: 12');
INSERT INTO ACT_DEL
	VALUES ("5e40adb9-02fb-4bfb-95ea-4ca5166ec64e",
	"1ac38df7-0390-45d3-92c0-997c0e4cdbf2");
INSERT INTO ACT_BLK
	VALUES ("d68fe66a-015d-4afe-8cc3-777575ac4714",
	0,
	0,
	0,
	'',
	'',
	'',
	24,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"358cb221-5019-493a-b923-04caaeabcbcb",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("6c143282-4d24-4222-b615-1a9fcc6e6277",
	"d68fe66a-015d-4afe-8cc3-777575ac4714",
	"00000000-0000-0000-0000-000000000000",
	24,
	3,
	'box::prune line: 24');
INSERT INTO ACT_AI
	VALUES ("6c143282-4d24-4222-b615-1a9fcc6e6277",
	"c597bae4-83f2-44f6-a4ad-2172d0afb54c",
	"6046fed5-4225-4837-8e44-291f957d4f48",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("6046fed5-4225-4837-8e44-291f957d4f48",
	1,
	0,
	24,
	3,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d68fe66a-015d-4afe-8cc3-777575ac4714");
INSERT INTO V_TVL
	VALUES ("6046fed5-4225-4837-8e44-291f957d4f48",
	"6d7391be-f08e-4c93-bdd6-8177ad6c430d");
INSERT INTO V_VAL
	VALUES ("c597bae4-83f2-44f6-a4ad-2172d0afb54c",
	0,
	0,
	24,
	17,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d68fe66a-015d-4afe-8cc3-777575ac4714");
INSERT INTO V_LIN
	VALUES ("c597bae4-83f2-44f6-a4ad-2172d0afb54c",
	'100');
INSERT INTO ACT_BLK
	VALUES ("edc8e6eb-ce47-4140-8734-4bb040ab478a",
	1,
	0,
	0,
	'',
	'',
	'',
	30,
	3,
	28,
	46,
	0,
	0,
	28,
	55,
	0,
	0,
	0,
	0,
	0,
	"358cb221-5019-493a-b923-04caaeabcbcb",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("eb0a9f4e-53a1-4dfb-9a5a-ad06b6ca90a4",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a",
	"eeef3242-f3eb-4c70-ad35-b720ba0ab82e",
	28,
	3,
	'box::prune line: 28');
INSERT INTO ACT_SEL
	VALUES ("eb0a9f4e-53a1-4dfb-9a5a-ad06b6ca90a4",
	"77fbafaf-d688-48bb-8523-ac52d855c252",
	0,
	'many',
	"cf0adf67-8ece-4b1f-992d-a6422f115909");
INSERT INTO ACT_SR
	VALUES ("eb0a9f4e-53a1-4dfb-9a5a-ad06b6ca90a4");
INSERT INTO ACT_LNK
	VALUES ("41fbeb2d-8764-42f3-b37d-7e8bed45d173",
	'',
	"eb0a9f4e-53a1-4dfb-9a5a-ad06b6ca90a4",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	28,
	46,
	28,
	55,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("eeef3242-f3eb-4c70-ad35-b720ba0ab82e",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a",
	"c4e0e6b2-81b5-44c9-8165-2dc6b8b67d3e",
	29,
	3,
	'box::prune line: 29');
INSERT INTO ACT_AI
	VALUES ("eeef3242-f3eb-4c70-ad35-b720ba0ab82e",
	"6ae058e8-d7a8-4b2f-832d-cb3049e04987",
	"ed4940e0-b1f7-4945-b773-e0f82b9e1cea",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c4e0e6b2-81b5-44c9-8165-2dc6b8b67d3e",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a",
	"00000000-0000-0000-0000-000000000000",
	30,
	3,
	'box::prune line: 30');
INSERT INTO ACT_IF
	VALUES ("c4e0e6b2-81b5-44c9-8165-2dc6b8b67d3e",
	"7ec38ade-19ef-441b-aefb-b77cfe3a9e26",
	"b3c9652c-679b-4665-b5dc-0eaf19e5ade8",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("cf0adf67-8ece-4b1f-992d-a6422f115909",
	0,
	0,
	28,
	36,
	43,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a");
INSERT INTO V_IRF
	VALUES ("cf0adf67-8ece-4b1f-992d-a6422f115909",
	"c77386dd-b526-4ccc-8764-522fab90fd4d");
INSERT INTO V_VAL
	VALUES ("ed4940e0-b1f7-4945-b773-e0f82b9e1cea",
	1,
	1,
	29,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a");
INSERT INTO V_TVL
	VALUES ("ed4940e0-b1f7-4945-b773-e0f82b9e1cea",
	"d75d6201-0eeb-4e0c-bd7c-03b5705ff0b1");
INSERT INTO V_VAL
	VALUES ("1e8d0531-426b-401a-87af-d29d40296677",
	0,
	0,
	29,
	19,
	27,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a");
INSERT INTO V_ISR
	VALUES ("1e8d0531-426b-401a-87af-d29d40296677",
	"77fbafaf-d688-48bb-8523-ac52d855c252");
INSERT INTO V_VAL
	VALUES ("6ae058e8-d7a8-4b2f-832d-cb3049e04987",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a");
INSERT INTO V_UNY
	VALUES ("6ae058e8-d7a8-4b2f-832d-cb3049e04987",
	"1e8d0531-426b-401a-87af-d29d40296677",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("493cc7f7-0b63-45f9-b007-d83f1bf4cdaa",
	0,
	0,
	30,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a");
INSERT INTO V_LIN
	VALUES ("493cc7f7-0b63-45f9-b007-d83f1bf4cdaa",
	'1');
INSERT INTO V_VAL
	VALUES ("b3c9652c-679b-4665-b5dc-0eaf19e5ade8",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a");
INSERT INTO V_BIN
	VALUES ("b3c9652c-679b-4665-b5dc-0eaf19e5ade8",
	"da47f8d6-4eba-42cc-adae-6dca73ed6d85",
	"493cc7f7-0b63-45f9-b007-d83f1bf4cdaa",
	'==');
INSERT INTO V_VAL
	VALUES ("da47f8d6-4eba-42cc-adae-6dca73ed6d85",
	0,
	0,
	30,
	13,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a");
INSERT INTO V_TVL
	VALUES ("da47f8d6-4eba-42cc-adae-6dca73ed6d85",
	"d75d6201-0eeb-4e0c-bd7c-03b5705ff0b1");
INSERT INTO V_VAR
	VALUES ("d75d6201-0eeb-4e0c-bd7c-03b5705ff0b1",
	"edc8e6eb-ce47-4140-8734-4bb040ab478a",
	'c',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("d75d6201-0eeb-4e0c-bd7c-03b5705ff0b1",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("1e3ef19e-0c78-48a5-8a5b-931f0955e6f0",
	29,
	3,
	3,
	"d75d6201-0eeb-4e0c-bd7c-03b5705ff0b1");
INSERT INTO V_LOC
	VALUES ("fca53e07-182e-42da-907d-d459a94d6e3f",
	30,
	13,
	13,
	"d75d6201-0eeb-4e0c-bd7c-03b5705ff0b1");
INSERT INTO ACT_BLK
	VALUES ("7ec38ade-19ef-441b-aefb-b77cfe3a9e26",
	1,
	0,
	0,
	'',
	'',
	'',
	34,
	5,
	31,
	44,
	0,
	0,
	31,
	53,
	0,
	0,
	0,
	0,
	0,
	"358cb221-5019-493a-b923-04caaeabcbcb",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d900b432-d1b2-444b-a48c-edb40994f29d",
	"7ec38ade-19ef-441b-aefb-b77cfe3a9e26",
	"941ad4e2-032d-47ed-a4f1-4cde45552b53",
	31,
	5,
	'box::prune line: 31');
INSERT INTO ACT_SEL
	VALUES ("d900b432-d1b2-444b-a48c-edb40994f29d",
	"b1a52615-971e-460b-8b16-909a14653246",
	1,
	'any',
	"d1791104-1878-48ab-b742-0a192e849ff4");
INSERT INTO ACT_SR
	VALUES ("d900b432-d1b2-444b-a48c-edb40994f29d");
INSERT INTO ACT_LNK
	VALUES ("7092c1ad-05e9-4de0-948e-aa6b274ddc0f",
	'',
	"d900b432-d1b2-444b-a48c-edb40994f29d",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	31,
	44,
	31,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("941ad4e2-032d-47ed-a4f1-4cde45552b53",
	"7ec38ade-19ef-441b-aefb-b77cfe3a9e26",
	"cb145dd3-f285-4081-9230-714740c1258a",
	32,
	5,
	'box::prune line: 32');
INSERT INTO ACT_TFM
	VALUES ("941ad4e2-032d-47ed-a4f1-4cde45552b53",
	"4dbd3878-9ff1-4fa9-8ff2-db063b3aa997",
	"c77386dd-b526-4ccc-8764-522fab90fd4d",
	32,
	14,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("cb145dd3-f285-4081-9230-714740c1258a",
	"7ec38ade-19ef-441b-aefb-b77cfe3a9e26",
	"00000000-0000-0000-0000-000000000000",
	34,
	5,
	'box::prune line: 34');
INSERT INTO ACT_AI
	VALUES ("cb145dd3-f285-4081-9230-714740c1258a",
	"f6c51da4-7895-42e8-9cea-cf8a5ea5dbd0",
	"3a72489e-817f-4e70-aea1-dfa15ec40d71",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("d1791104-1878-48ab-b742-0a192e849ff4",
	0,
	0,
	31,
	34,
	41,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"7ec38ade-19ef-441b-aefb-b77cfe3a9e26");
INSERT INTO V_IRF
	VALUES ("d1791104-1878-48ab-b742-0a192e849ff4",
	"c77386dd-b526-4ccc-8764-522fab90fd4d");
INSERT INTO V_VAL
	VALUES ("164bda97-7c27-4620-97ef-386baf0e1d8d",
	0,
	0,
	32,
	35,
	40,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"7ec38ade-19ef-441b-aefb-b77cfe3a9e26");
INSERT INTO V_IRF
	VALUES ("164bda97-7c27-4620-97ef-386baf0e1d8d",
	"b1a52615-971e-460b-8b16-909a14653246");
INSERT INTO V_VAL
	VALUES ("98c9071a-c65b-4118-a3ea-fb656b8d6abb",
	0,
	0,
	32,
	42,
	52,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7ec38ade-19ef-441b-aefb-b77cfe3a9e26");
INSERT INTO V_AVL
	VALUES ("98c9071a-c65b-4118-a3ea-fb656b8d6abb",
	"164bda97-7c27-4620-97ef-386baf0e1d8d",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_PAR
	VALUES ("98c9071a-c65b-4118-a3ea-fb656b8d6abb",
	"941ad4e2-032d-47ed-a4f1-4cde45552b53",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	32,
	22);
INSERT INTO V_VAL
	VALUES ("3a72489e-817f-4e70-aea1-dfa15ec40d71",
	1,
	0,
	34,
	5,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7ec38ade-19ef-441b-aefb-b77cfe3a9e26");
INSERT INTO V_TVL
	VALUES ("3a72489e-817f-4e70-aea1-dfa15ec40d71",
	"6d7391be-f08e-4c93-bdd6-8177ad6c430d");
INSERT INTO V_VAL
	VALUES ("f6c51da4-7895-42e8-9cea-cf8a5ea5dbd0",
	0,
	0,
	34,
	19,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7ec38ade-19ef-441b-aefb-b77cfe3a9e26");
INSERT INTO V_LIN
	VALUES ("f6c51da4-7895-42e8-9cea-cf8a5ea5dbd0",
	'1');
INSERT INTO V_VAR
	VALUES ("b1a52615-971e-460b-8b16-909a14653246",
	"7ec38ade-19ef-441b-aefb-b77cfe3a9e26",
	'answer',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("b1a52615-971e-460b-8b16-909a14653246",
	0,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("01980b03-4af5-477a-9cb1-482c994431ea",
	31,
	16,
	21,
	"b1a52615-971e-460b-8b16-909a14653246");
INSERT INTO V_LOC
	VALUES ("bc3ade52-3871-4102-bb76-4363f8489a49",
	32,
	35,
	40,
	"b1a52615-971e-460b-8b16-909a14653246");
INSERT INTO O_TFR
	VALUES ("f511495a-58e2-4110-b856-013b6627b6ae",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	'eliminate',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	1,
	'// Solve by selecting eligible digits.
// Notice if any eligible digit appears only once.

temperature = 0;
select many eligibles related by self->CELL[R4]->ELIGIBLE[R8];
c = cardinality eligibles;
if ( 9 == c )
  temperature = 100;
else
for each eligible in eligibles
  select many loners related by self->CELL[R4]->ELIGIBLE[R8]
    where ( selected.digit_value == eligible.digit_value );
  c = cardinality loners;
  if ( 1 == c )
    // This is an answer!
    select one cell related by eligible->CELL[R8];
    cell.answer( answer_digit:eligible.digit_value );
    // generate CELL2:answer( digit:eligible.digit_value ) to cell;
    temperature = 1;
    break;
  end if;
end for;
end if;
return temperature;',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_OPB
	VALUES ("091dc543-8251-459a-9d34-9f73cc5aa884",
	"f511495a-58e2-4110-b856-013b6627b6ae");
INSERT INTO ACT_ACT
	VALUES ("091dc543-8251-459a-9d34-9f73cc5aa884",
	'operation',
	0,
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	"00000000-0000-0000-0000-000000000000",
	0,
	'box::eliminate',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	1,
	0,
	0,
	'',
	'',
	'',
	24,
	1,
	5,
	50,
	0,
	0,
	5,
	59,
	0,
	0,
	0,
	0,
	0,
	"091dc543-8251-459a-9d34-9f73cc5aa884",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("43c4e885-d43c-46d0-b405-cf79e94cf953",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	"d5675c79-e819-4cf2-9f3c-363d2a5a312e",
	4,
	1,
	'box::eliminate line: 4');
INSERT INTO ACT_AI
	VALUES ("43c4e885-d43c-46d0-b405-cf79e94cf953",
	"d951b3e3-bcad-4b01-a27a-0fd0f18b5b66",
	"77fb1e2f-9c36-41c8-8aef-d44f494538d2",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d5675c79-e819-4cf2-9f3c-363d2a5a312e",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	"91ba297d-6595-45ee-ba64-3994c4320290",
	5,
	1,
	'box::eliminate line: 5');
INSERT INTO ACT_SEL
	VALUES ("d5675c79-e819-4cf2-9f3c-363d2a5a312e",
	"c436192e-d955-4eee-a444-0767b0f3b7e2",
	1,
	'many',
	"a4b38778-b7ac-4506-acdd-0733033676cc");
INSERT INTO ACT_SR
	VALUES ("d5675c79-e819-4cf2-9f3c-363d2a5a312e");
INSERT INTO ACT_LNK
	VALUES ("475770e5-3549-4a09-9f49-e1c07e4719e6",
	'',
	"d5675c79-e819-4cf2-9f3c-363d2a5a312e",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"b4460256-0600-4686-b780-74ddae169c13",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("b4460256-0600-4686-b780-74ddae169c13",
	'',
	"00000000-0000-0000-0000-000000000000",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("91ba297d-6595-45ee-ba64-3994c4320290",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	"2470ae64-3e80-4d33-bf6e-f1d1e79238e2",
	6,
	1,
	'box::eliminate line: 6');
INSERT INTO ACT_AI
	VALUES ("91ba297d-6595-45ee-ba64-3994c4320290",
	"90f577f0-c7b7-47ca-85d7-950a6c2ca107",
	"94a9c5e4-6747-442c-991a-10d904687c8f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("2470ae64-3e80-4d33-bf6e-f1d1e79238e2",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	"02f496c7-743d-4c5a-9286-52509c13bb09",
	7,
	1,
	'box::eliminate line: 7');
INSERT INTO ACT_IF
	VALUES ("2470ae64-3e80-4d33-bf6e-f1d1e79238e2",
	"c5ea9348-d26a-4298-8535-18f3d66f5fd7",
	"3bd13d65-94dd-460b-b505-90b5d27086b2",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("2cfb2d88-ab68-46f8-90cc-cd09ca14cfeb",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	"00000000-0000-0000-0000-000000000000",
	9,
	1,
	'box::eliminate line: 9');
INSERT INTO ACT_E
	VALUES ("2cfb2d88-ab68-46f8-90cc-cd09ca14cfeb",
	"d22b49e9-1be6-4543-b3be-3096e7acce65",
	"2470ae64-3e80-4d33-bf6e-f1d1e79238e2");
INSERT INTO ACT_SMT
	VALUES ("02f496c7-743d-4c5a-9286-52509c13bb09",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	"00000000-0000-0000-0000-000000000000",
	24,
	1,
	'box::eliminate line: 24');
INSERT INTO ACT_RET
	VALUES ("02f496c7-743d-4c5a-9286-52509c13bb09",
	"3e559c62-4190-47e6-b3b2-d98938916fd1");
INSERT INTO V_VAL
	VALUES ("77fb1e2f-9c36-41c8-8aef-d44f494538d2",
	1,
	1,
	4,
	1,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255");
INSERT INTO V_TVL
	VALUES ("77fb1e2f-9c36-41c8-8aef-d44f494538d2",
	"ba05a0e7-3310-4233-9146-8e2c2469f310");
INSERT INTO V_VAL
	VALUES ("d951b3e3-bcad-4b01-a27a-0fd0f18b5b66",
	0,
	0,
	4,
	15,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255");
INSERT INTO V_LIN
	VALUES ("d951b3e3-bcad-4b01-a27a-0fd0f18b5b66",
	'0');
INSERT INTO V_VAL
	VALUES ("a4b38778-b7ac-4506-acdd-0733033676cc",
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255");
INSERT INTO V_IRF
	VALUES ("a4b38778-b7ac-4506-acdd-0733033676cc",
	"dfd95fe3-68ef-4274-9232-bf8ab47273c2");
INSERT INTO V_VAL
	VALUES ("94a9c5e4-6747-442c-991a-10d904687c8f",
	1,
	1,
	6,
	1,
	1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255");
INSERT INTO V_TVL
	VALUES ("94a9c5e4-6747-442c-991a-10d904687c8f",
	"e42922dd-293c-4bd4-87a8-9f05a0c759ec");
INSERT INTO V_VAL
	VALUES ("06d37268-3f45-4bcd-9108-69694557964b",
	0,
	0,
	6,
	17,
	25,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255");
INSERT INTO V_ISR
	VALUES ("06d37268-3f45-4bcd-9108-69694557964b",
	"c436192e-d955-4eee-a444-0767b0f3b7e2");
INSERT INTO V_VAL
	VALUES ("90f577f0-c7b7-47ca-85d7-950a6c2ca107",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255");
INSERT INTO V_UNY
	VALUES ("90f577f0-c7b7-47ca-85d7-950a6c2ca107",
	"06d37268-3f45-4bcd-9108-69694557964b",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("230a0052-b3d8-492e-8fff-f0e57330fe24",
	0,
	0,
	7,
	6,
	6,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255");
INSERT INTO V_LIN
	VALUES ("230a0052-b3d8-492e-8fff-f0e57330fe24",
	'9');
INSERT INTO V_VAL
	VALUES ("3bd13d65-94dd-460b-b505-90b5d27086b2",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255");
INSERT INTO V_BIN
	VALUES ("3bd13d65-94dd-460b-b505-90b5d27086b2",
	"b0b273e8-f113-4d03-ae45-8f0338f6e24a",
	"230a0052-b3d8-492e-8fff-f0e57330fe24",
	'==');
INSERT INTO V_VAL
	VALUES ("b0b273e8-f113-4d03-ae45-8f0338f6e24a",
	0,
	0,
	7,
	11,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255");
INSERT INTO V_TVL
	VALUES ("b0b273e8-f113-4d03-ae45-8f0338f6e24a",
	"e42922dd-293c-4bd4-87a8-9f05a0c759ec");
INSERT INTO V_VAL
	VALUES ("3e559c62-4190-47e6-b3b2-d98938916fd1",
	0,
	0,
	24,
	8,
	18,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255");
INSERT INTO V_TVL
	VALUES ("3e559c62-4190-47e6-b3b2-d98938916fd1",
	"ba05a0e7-3310-4233-9146-8e2c2469f310");
INSERT INTO V_VAR
	VALUES ("ba05a0e7-3310-4233-9146-8e2c2469f310",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	'temperature',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("ba05a0e7-3310-4233-9146-8e2c2469f310",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("c30fb5c8-f152-4c5d-a6f6-c700b8d25504",
	4,
	1,
	11,
	"ba05a0e7-3310-4233-9146-8e2c2469f310");
INSERT INTO V_LOC
	VALUES ("110f47fd-3e9d-4b51-a308-f21dd3a5a97d",
	8,
	3,
	13,
	"ba05a0e7-3310-4233-9146-8e2c2469f310");
INSERT INTO V_LOC
	VALUES ("4cbb715b-c616-475e-b11b-7e22bfe31de8",
	19,
	5,
	15,
	"ba05a0e7-3310-4233-9146-8e2c2469f310");
INSERT INTO V_LOC
	VALUES ("83958bec-9625-41ac-a593-ca6d497bb897",
	24,
	8,
	18,
	"ba05a0e7-3310-4233-9146-8e2c2469f310");
INSERT INTO V_VAR
	VALUES ("c436192e-d955-4eee-a444-0767b0f3b7e2",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	'eligibles',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("c436192e-d955-4eee-a444-0767b0f3b7e2",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("f0d5ecbe-7cb9-4988-9a0f-402e13e7bc7e",
	5,
	13,
	21,
	"c436192e-d955-4eee-a444-0767b0f3b7e2");
INSERT INTO V_LOC
	VALUES ("e0b5b338-4069-43f8-9bad-39a4301cc7f4",
	10,
	22,
	30,
	"c436192e-d955-4eee-a444-0767b0f3b7e2");
INSERT INTO V_VAR
	VALUES ("dfd95fe3-68ef-4274-9232-bf8ab47273c2",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("dfd95fe3-68ef-4274-9232-bf8ab47273c2",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_VAR
	VALUES ("e42922dd-293c-4bd4-87a8-9f05a0c759ec",
	"64f441c3-5f45-4fdf-8e69-cc2eebfb4255",
	'c',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("e42922dd-293c-4bd4-87a8-9f05a0c759ec",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("76bc3cec-0653-45f5-9f7d-9a1c06e0a5aa",
	6,
	1,
	1,
	"e42922dd-293c-4bd4-87a8-9f05a0c759ec");
INSERT INTO V_LOC
	VALUES ("6fd854b6-e079-4efe-912d-12c383f9b4b9",
	7,
	11,
	11,
	"e42922dd-293c-4bd4-87a8-9f05a0c759ec");
INSERT INTO V_LOC
	VALUES ("2db06d2c-85dd-4f56-9016-f2bc1d9fd3a2",
	13,
	3,
	3,
	"e42922dd-293c-4bd4-87a8-9f05a0c759ec");
INSERT INTO V_LOC
	VALUES ("7831b046-576a-4764-8632-f9c6e4c41184",
	14,
	13,
	13,
	"e42922dd-293c-4bd4-87a8-9f05a0c759ec");
INSERT INTO ACT_BLK
	VALUES ("c5ea9348-d26a-4298-8535-18f3d66f5fd7",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"091dc543-8251-459a-9d34-9f73cc5aa884",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c0745dc2-26c6-4759-b946-1820818ebf34",
	"c5ea9348-d26a-4298-8535-18f3d66f5fd7",
	"00000000-0000-0000-0000-000000000000",
	8,
	3,
	'box::eliminate line: 8');
INSERT INTO ACT_AI
	VALUES ("c0745dc2-26c6-4759-b946-1820818ebf34",
	"ac716e25-efd2-4c1b-855e-2f12b74e98e9",
	"aebe21d6-214b-49f8-a860-78055046d24d",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("aebe21d6-214b-49f8-a860-78055046d24d",
	1,
	0,
	8,
	3,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c5ea9348-d26a-4298-8535-18f3d66f5fd7");
INSERT INTO V_TVL
	VALUES ("aebe21d6-214b-49f8-a860-78055046d24d",
	"ba05a0e7-3310-4233-9146-8e2c2469f310");
INSERT INTO V_VAL
	VALUES ("ac716e25-efd2-4c1b-855e-2f12b74e98e9",
	0,
	0,
	8,
	17,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c5ea9348-d26a-4298-8535-18f3d66f5fd7");
INSERT INTO V_LIN
	VALUES ("ac716e25-efd2-4c1b-855e-2f12b74e98e9",
	'100');
INSERT INTO ACT_BLK
	VALUES ("d22b49e9-1be6-4543-b3be-3096e7acce65",
	0,
	0,
	0,
	'',
	'',
	'',
	10,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"091dc543-8251-459a-9d34-9f73cc5aa884",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("30c497ca-94b6-473c-a1da-05198a08ab60",
	"d22b49e9-1be6-4543-b3be-3096e7acce65",
	"00000000-0000-0000-0000-000000000000",
	10,
	1,
	'box::eliminate line: 10');
INSERT INTO ACT_FOR
	VALUES ("30c497ca-94b6-473c-a1da-05198a08ab60",
	"1a030139-8228-42fa-b723-7b582443a325",
	1,
	"57337781-37a2-4f78-b3cc-b47c93f447b5",
	"c436192e-d955-4eee-a444-0767b0f3b7e2",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_VAR
	VALUES ("57337781-37a2-4f78-b3cc-b47c93f447b5",
	"d22b49e9-1be6-4543-b3be-3096e7acce65",
	'eligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("57337781-37a2-4f78-b3cc-b47c93f447b5",
	1,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("9b4d494c-f7c9-48ef-b62d-485e3fe11dfa",
	10,
	10,
	17,
	"57337781-37a2-4f78-b3cc-b47c93f447b5");
INSERT INTO V_LOC
	VALUES ("01c16c81-970f-44c4-a03e-7866b101c988",
	12,
	37,
	44,
	"57337781-37a2-4f78-b3cc-b47c93f447b5");
INSERT INTO V_LOC
	VALUES ("7753a19e-a6dc-4664-bcbb-c2cd57892b49",
	17,
	31,
	38,
	"57337781-37a2-4f78-b3cc-b47c93f447b5");
INSERT INTO ACT_BLK
	VALUES ("1a030139-8228-42fa-b723-7b582443a325",
	1,
	0,
	1,
	'',
	'',
	'',
	14,
	3,
	11,
	49,
	0,
	0,
	11,
	58,
	0,
	0,
	0,
	0,
	0,
	"091dc543-8251-459a-9d34-9f73cc5aa884",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("bfde6b14-04b7-46da-b704-9b3fda0e399e",
	"1a030139-8228-42fa-b723-7b582443a325",
	"d48ca14c-8ff9-4dce-bd65-d6ccd9ee5339",
	11,
	3,
	'box::eliminate line: 11');
INSERT INTO ACT_SEL
	VALUES ("bfde6b14-04b7-46da-b704-9b3fda0e399e",
	"41b7dc69-4287-4ae0-bb38-04f8e1ad4c6b",
	1,
	'many',
	"35fc9ad1-c70b-4252-b257-41204fc08af3");
INSERT INTO ACT_SRW
	VALUES ("bfde6b14-04b7-46da-b704-9b3fda0e399e",
	"a441ddbc-8f96-4dc3-bd9f-7714399bf36d");
INSERT INTO ACT_LNK
	VALUES ("f8adf184-c454-4b1a-9764-b55ae9d6440a",
	'',
	"bfde6b14-04b7-46da-b704-9b3fda0e399e",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"3888ab0a-ee6f-4f46-bfc6-41205041ec0f",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	11,
	39,
	11,
	44,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("3888ab0a-ee6f-4f46-bfc6-41205041ec0f",
	'',
	"00000000-0000-0000-0000-000000000000",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	11,
	49,
	11,
	58,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d48ca14c-8ff9-4dce-bd65-d6ccd9ee5339",
	"1a030139-8228-42fa-b723-7b582443a325",
	"f1c5c6d7-567f-4b62-9c23-a7cb79279292",
	13,
	3,
	'box::eliminate line: 13');
INSERT INTO ACT_AI
	VALUES ("d48ca14c-8ff9-4dce-bd65-d6ccd9ee5339",
	"c8fb4c6c-8eff-4c50-b643-b26ed50464d3",
	"10832656-cbe6-40e9-a67e-222b3a742d16",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f1c5c6d7-567f-4b62-9c23-a7cb79279292",
	"1a030139-8228-42fa-b723-7b582443a325",
	"00000000-0000-0000-0000-000000000000",
	14,
	3,
	'box::eliminate line: 14');
INSERT INTO ACT_IF
	VALUES ("f1c5c6d7-567f-4b62-9c23-a7cb79279292",
	"6d8c3407-dc88-4a32-98f9-7816e649e091",
	"2f02ada2-0be2-45fd-b0e0-856088c16fd9",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("35fc9ad1-c70b-4252-b257-41204fc08af3",
	0,
	0,
	11,
	33,
	36,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_IRF
	VALUES ("35fc9ad1-c70b-4252-b257-41204fc08af3",
	"dfd95fe3-68ef-4274-9232-bf8ab47273c2");
INSERT INTO V_VAL
	VALUES ("964a35b1-5d8f-431b-ab56-8ee7e4b3a894",
	0,
	0,
	12,
	13,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_SLR
	VALUES ("964a35b1-5d8f-431b-ab56-8ee7e4b3a894",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("9efdcf2c-2d4b-4ee2-84d1-c9b651df2b6e",
	0,
	0,
	12,
	22,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_AVL
	VALUES ("9efdcf2c-2d4b-4ee2-84d1-c9b651df2b6e",
	"964a35b1-5d8f-431b-ab56-8ee7e4b3a894",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("a441ddbc-8f96-4dc3-bd9f-7714399bf36d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_BIN
	VALUES ("a441ddbc-8f96-4dc3-bd9f-7714399bf36d",
	"64625e57-aa97-452c-977f-7172bbb81c12",
	"9efdcf2c-2d4b-4ee2-84d1-c9b651df2b6e",
	'==');
INSERT INTO V_VAL
	VALUES ("74457852-026e-4d04-9342-7e2fd7978231",
	0,
	0,
	12,
	37,
	44,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_IRF
	VALUES ("74457852-026e-4d04-9342-7e2fd7978231",
	"57337781-37a2-4f78-b3cc-b47c93f447b5");
INSERT INTO V_VAL
	VALUES ("64625e57-aa97-452c-977f-7172bbb81c12",
	0,
	0,
	12,
	46,
	56,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_AVL
	VALUES ("64625e57-aa97-452c-977f-7172bbb81c12",
	"74457852-026e-4d04-9342-7e2fd7978231",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("10832656-cbe6-40e9-a67e-222b3a742d16",
	1,
	0,
	13,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_TVL
	VALUES ("10832656-cbe6-40e9-a67e-222b3a742d16",
	"e42922dd-293c-4bd4-87a8-9f05a0c759ec");
INSERT INTO V_VAL
	VALUES ("bda11aee-40e6-4be6-a5d3-3e6a2cf472c2",
	0,
	0,
	13,
	19,
	24,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_ISR
	VALUES ("bda11aee-40e6-4be6-a5d3-3e6a2cf472c2",
	"41b7dc69-4287-4ae0-bb38-04f8e1ad4c6b");
INSERT INTO V_VAL
	VALUES ("c8fb4c6c-8eff-4c50-b643-b26ed50464d3",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_UNY
	VALUES ("c8fb4c6c-8eff-4c50-b643-b26ed50464d3",
	"bda11aee-40e6-4be6-a5d3-3e6a2cf472c2",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("a7e8b234-0db9-470c-b302-7b6d21e53d87",
	0,
	0,
	14,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_LIN
	VALUES ("a7e8b234-0db9-470c-b302-7b6d21e53d87",
	'1');
INSERT INTO V_VAL
	VALUES ("2f02ada2-0be2-45fd-b0e0-856088c16fd9",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_BIN
	VALUES ("2f02ada2-0be2-45fd-b0e0-856088c16fd9",
	"6dcf5fbb-67a1-4f8d-a7a9-689e789fef17",
	"a7e8b234-0db9-470c-b302-7b6d21e53d87",
	'==');
INSERT INTO V_VAL
	VALUES ("6dcf5fbb-67a1-4f8d-a7a9-689e789fef17",
	0,
	0,
	14,
	13,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"1a030139-8228-42fa-b723-7b582443a325");
INSERT INTO V_TVL
	VALUES ("6dcf5fbb-67a1-4f8d-a7a9-689e789fef17",
	"e42922dd-293c-4bd4-87a8-9f05a0c759ec");
INSERT INTO V_VAR
	VALUES ("41b7dc69-4287-4ae0-bb38-04f8e1ad4c6b",
	"1a030139-8228-42fa-b723-7b582443a325",
	'loners',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("41b7dc69-4287-4ae0-bb38-04f8e1ad4c6b",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("4cd809bc-17d1-4e2b-8d02-582f482c6701",
	11,
	15,
	20,
	"41b7dc69-4287-4ae0-bb38-04f8e1ad4c6b");
INSERT INTO ACT_BLK
	VALUES ("6d8c3407-dc88-4a32-98f9-7816e649e091",
	1,
	0,
	0,
	'',
	'',
	'',
	20,
	5,
	16,
	42,
	0,
	0,
	16,
	47,
	0,
	0,
	0,
	0,
	0,
	"091dc543-8251-459a-9d34-9f73cc5aa884",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e0ab5d54-a8ea-46bd-b2a1-f2deb67a3e45",
	"6d8c3407-dc88-4a32-98f9-7816e649e091",
	"f9fc5f9e-8f2c-4cec-a7e6-c24a3d883d1c",
	16,
	5,
	'box::eliminate line: 16');
INSERT INTO ACT_SEL
	VALUES ("e0ab5d54-a8ea-46bd-b2a1-f2deb67a3e45",
	"eabcb4a3-ff55-4164-b4d0-4b8398065e9e",
	1,
	'one',
	"de9c3b22-88a4-432d-b17a-422551c787e7");
INSERT INTO ACT_SR
	VALUES ("e0ab5d54-a8ea-46bd-b2a1-f2deb67a3e45");
INSERT INTO ACT_LNK
	VALUES ("5e538bbb-1e99-448b-960a-4a9cddc32869",
	'',
	"e0ab5d54-a8ea-46bd-b2a1-f2deb67a3e45",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	16,
	42,
	16,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f9fc5f9e-8f2c-4cec-a7e6-c24a3d883d1c",
	"6d8c3407-dc88-4a32-98f9-7816e649e091",
	"0f245cc4-27e1-4c69-af25-0c9e77d4345e",
	17,
	5,
	'box::eliminate line: 17');
INSERT INTO ACT_TFM
	VALUES ("f9fc5f9e-8f2c-4cec-a7e6-c24a3d883d1c",
	"4dbd3878-9ff1-4fa9-8ff2-db063b3aa997",
	"eabcb4a3-ff55-4164-b4d0-4b8398065e9e",
	17,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0f245cc4-27e1-4c69-af25-0c9e77d4345e",
	"6d8c3407-dc88-4a32-98f9-7816e649e091",
	"56289642-e368-4fd9-acef-19dda5eac5f8",
	19,
	5,
	'box::eliminate line: 19');
INSERT INTO ACT_AI
	VALUES ("0f245cc4-27e1-4c69-af25-0c9e77d4345e",
	"662d7cb4-9768-4fbd-8562-9f91ece61f65",
	"76a9fc3a-48a4-4928-bb37-c23ae5e25cfb",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("56289642-e368-4fd9-acef-19dda5eac5f8",
	"6d8c3407-dc88-4a32-98f9-7816e649e091",
	"00000000-0000-0000-0000-000000000000",
	20,
	5,
	'box::eliminate line: 20');
INSERT INTO ACT_BRK
	VALUES ("56289642-e368-4fd9-acef-19dda5eac5f8");
INSERT INTO V_VAL
	VALUES ("de9c3b22-88a4-432d-b17a-422551c787e7",
	0,
	0,
	16,
	32,
	39,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6d8c3407-dc88-4a32-98f9-7816e649e091");
INSERT INTO V_IRF
	VALUES ("de9c3b22-88a4-432d-b17a-422551c787e7",
	"57337781-37a2-4f78-b3cc-b47c93f447b5");
INSERT INTO V_VAL
	VALUES ("c7515722-5ae8-4a85-88f5-1e0bc1b35f95",
	0,
	0,
	17,
	31,
	38,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6d8c3407-dc88-4a32-98f9-7816e649e091");
INSERT INTO V_IRF
	VALUES ("c7515722-5ae8-4a85-88f5-1e0bc1b35f95",
	"57337781-37a2-4f78-b3cc-b47c93f447b5");
INSERT INTO V_VAL
	VALUES ("9493bb51-d3db-403a-b886-1d5a25b7b819",
	0,
	0,
	17,
	40,
	50,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6d8c3407-dc88-4a32-98f9-7816e649e091");
INSERT INTO V_AVL
	VALUES ("9493bb51-d3db-403a-b886-1d5a25b7b819",
	"c7515722-5ae8-4a85-88f5-1e0bc1b35f95",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_PAR
	VALUES ("9493bb51-d3db-403a-b886-1d5a25b7b819",
	"f9fc5f9e-8f2c-4cec-a7e6-c24a3d883d1c",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	17,
	18);
INSERT INTO V_VAL
	VALUES ("76a9fc3a-48a4-4928-bb37-c23ae5e25cfb",
	1,
	0,
	19,
	5,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6d8c3407-dc88-4a32-98f9-7816e649e091");
INSERT INTO V_TVL
	VALUES ("76a9fc3a-48a4-4928-bb37-c23ae5e25cfb",
	"ba05a0e7-3310-4233-9146-8e2c2469f310");
INSERT INTO V_VAL
	VALUES ("662d7cb4-9768-4fbd-8562-9f91ece61f65",
	0,
	0,
	19,
	19,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6d8c3407-dc88-4a32-98f9-7816e649e091");
INSERT INTO V_LIN
	VALUES ("662d7cb4-9768-4fbd-8562-9f91ece61f65",
	'1');
INSERT INTO V_VAR
	VALUES ("eabcb4a3-ff55-4164-b4d0-4b8398065e9e",
	"6d8c3407-dc88-4a32-98f9-7816e649e091",
	'cell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("eabcb4a3-ff55-4164-b4d0-4b8398065e9e",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("2da7e7c6-cb26-455d-a4a3-fdd36de53b49",
	16,
	16,
	19,
	"eabcb4a3-ff55-4164-b4d0-4b8398065e9e");
INSERT INTO V_LOC
	VALUES ("80d3f65f-468d-486f-9856-f103fc3e969d",
	17,
	5,
	8,
	"eabcb4a3-ff55-4164-b4d0-4b8398065e9e");
INSERT INTO O_NBATTR
	VALUES ("b66048a0-61eb-4e7f-9b91-d394e7449b6c",
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO O_BATTR
	VALUES ("b66048a0-61eb-4e7f-9b91-d394e7449b6c",
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO O_ATTR
	VALUES ("b66048a0-61eb-4e7f-9b91-d394e7449b6c",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"00000000-0000-0000-0000-000000000000",
	'number',
	'',
	'',
	'number',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("cafc6a8d-f480-47b0-945a-763f11cc5c8c",
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO O_BATTR
	VALUES ("cafc6a8d-f480-47b0-945a-763f11cc5c8c",
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO O_ATTR
	VALUES ("cafc6a8d-f480-47b0-945a-763f11cc5c8c",
	"0aa0576e-b480-43da-8919-6b6e88544902",
	"b66048a0-61eb-4e7f-9b91-d394e7449b6c",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"65468da2-1083-4089-81cf-f2430c0ade46",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO O_ID
	VALUES (1,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO O_ID
	VALUES (2,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO SM_ISM
	VALUES ("56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO SM_SM
	VALUES ("56d15a5d-9abc-4ff5-8785-f948c27a4410",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("56d15a5d-9abc-4ff5-8785-f948c27a4410");
INSERT INTO SM_LEVT
	VALUES ("d7e974e2-f076-486f-8751-749403cb72ec",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("d7e974e2-f076-486f-8751-749403cb72ec",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("d7e974e2-f076-486f-8751-749403cb72ec",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000",
	1,
	'update',
	0,
	'',
	'BOX1',
	'');
INSERT INTO SM_LEVT
	VALUES ("76c97f76-a5f6-4beb-b959-f95945b157a3",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("76c97f76-a5f6-4beb-b959-f95945b157a3",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("76c97f76-a5f6-4beb-b959-f95945b157a3",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000",
	2,
	'solved',
	0,
	'',
	'BOX2',
	'');
INSERT INTO SM_STATE
	VALUES ("56f8c26a-1557-4152-9ef5-a70c1fc254f7",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000",
	'solving',
	1,
	0);
INSERT INTO SM_SEME
	VALUES ("56f8c26a-1557-4152-9ef5-a70c1fc254f7",
	"d7e974e2-f076-486f-8751-749403cb72ec",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("56f8c26a-1557-4152-9ef5-a70c1fc254f7",
	"76c97f76-a5f6-4beb-b959-f95945b157a3",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("448c5fb3-1c1a-4d56-a088-19e061377cd4",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"56f8c26a-1557-4152-9ef5-a70c1fc254f7");
INSERT INTO SM_AH
	VALUES ("448c5fb3-1c1a-4d56-a088-19e061377cd4",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410");
INSERT INTO SM_ACT
	VALUES ("448c5fb3-1c1a-4d56-a088-19e061377cd4",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	1,
	'if ( 100 == self.prune() )
  generate BOX2:solved() to self;
elif ( 100 == self.eliminate() )
  generate BOX2:solved() to self;
else
  select one sequence related by self->SEQUENCE[R1];
  if ( sequence.requests >= 1 )
    sequence.requests = 1;
    b = self;
    generate BOX1:update() to b;
  else
    sequence.requests = 0;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES ("ad93f65d-2a8f-44d1-b97b-db390b53b6a6",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"448c5fb3-1c1a-4d56-a088-19e061377cd4");
INSERT INTO ACT_ACT
	VALUES ("ad93f65d-2a8f-44d1-b97b-db390b53b6a6",
	'state',
	0,
	"017e4de6-6892-48f9-a718-298889fadc45",
	"00000000-0000-0000-0000-000000000000",
	0,
	'box::solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("017e4de6-6892-48f9-a718-298889fadc45",
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ad93f65d-2a8f-44d1-b97b-db390b53b6a6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("521670ca-f469-44c6-b3c7-016cd7dc784f",
	"017e4de6-6892-48f9-a718-298889fadc45",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'box::solving line: 1');
INSERT INTO ACT_IF
	VALUES ("521670ca-f469-44c6-b3c7-016cd7dc784f",
	"597ad114-aa76-432b-a108-c994f2a1c212",
	"705b9528-8822-4443-9d20-69335924a393",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("95cca247-3f8f-4278-8d5f-68d2e686d17c",
	"017e4de6-6892-48f9-a718-298889fadc45",
	"00000000-0000-0000-0000-000000000000",
	3,
	1,
	'box::solving line: 3');
INSERT INTO ACT_EL
	VALUES ("95cca247-3f8f-4278-8d5f-68d2e686d17c",
	"8070ccab-acd3-4738-9826-7289387d900b",
	"80a88d72-98c7-4929-aacf-973b58888ffc",
	"521670ca-f469-44c6-b3c7-016cd7dc784f");
INSERT INTO ACT_SMT
	VALUES ("f37fc672-82e4-40fd-acab-04a95bff7720",
	"017e4de6-6892-48f9-a718-298889fadc45",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'box::solving line: 5');
INSERT INTO ACT_E
	VALUES ("f37fc672-82e4-40fd-acab-04a95bff7720",
	"2e3e98a0-6f31-4be6-b904-2ceb22bac83e",
	"521670ca-f469-44c6-b3c7-016cd7dc784f");
INSERT INTO V_VAL
	VALUES ("0dff8921-ab67-42f4-8689-62cd4a3d43c3",
	0,
	0,
	1,
	6,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"017e4de6-6892-48f9-a718-298889fadc45");
INSERT INTO V_LIN
	VALUES ("0dff8921-ab67-42f4-8689-62cd4a3d43c3",
	'100');
INSERT INTO V_VAL
	VALUES ("705b9528-8822-4443-9d20-69335924a393",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"017e4de6-6892-48f9-a718-298889fadc45");
INSERT INTO V_BIN
	VALUES ("705b9528-8822-4443-9d20-69335924a393",
	"2a5a89d9-556f-415d-8171-9f28275ad19f",
	"0dff8921-ab67-42f4-8689-62cd4a3d43c3",
	'==');
INSERT INTO V_VAL
	VALUES ("2a5a89d9-556f-415d-8171-9f28275ad19f",
	0,
	0,
	1,
	18,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"017e4de6-6892-48f9-a718-298889fadc45");
INSERT INTO V_TRV
	VALUES ("2a5a89d9-556f-415d-8171-9f28275ad19f",
	"9eb8190d-e504-49dd-8d1c-ff3f41269990",
	"45649a7d-233b-48bb-b6b1-640afb1a3d30",
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("7e99a9b4-2ff5-47b5-ba7e-c6f514ffea9b",
	0,
	0,
	3,
	8,
	10,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"017e4de6-6892-48f9-a718-298889fadc45");
INSERT INTO V_LIN
	VALUES ("7e99a9b4-2ff5-47b5-ba7e-c6f514ffea9b",
	'100');
INSERT INTO V_VAL
	VALUES ("80a88d72-98c7-4929-aacf-973b58888ffc",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"017e4de6-6892-48f9-a718-298889fadc45");
INSERT INTO V_BIN
	VALUES ("80a88d72-98c7-4929-aacf-973b58888ffc",
	"3641503b-a6dd-4cfb-bcdf-46f3cb439977",
	"7e99a9b4-2ff5-47b5-ba7e-c6f514ffea9b",
	'==');
INSERT INTO V_VAL
	VALUES ("3641503b-a6dd-4cfb-bcdf-46f3cb439977",
	0,
	0,
	3,
	20,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"017e4de6-6892-48f9-a718-298889fadc45");
INSERT INTO V_TRV
	VALUES ("3641503b-a6dd-4cfb-bcdf-46f3cb439977",
	"f511495a-58e2-4110-b856-013b6627b6ae",
	"45649a7d-233b-48bb-b6b1-640afb1a3d30",
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("45649a7d-233b-48bb-b6b1-640afb1a3d30",
	"017e4de6-6892-48f9-a718-298889fadc45",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("45649a7d-233b-48bb-b6b1-640afb1a3d30",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("24514863-f96a-433b-bc36-715c1dc91057",
	1,
	13,
	16,
	"45649a7d-233b-48bb-b6b1-640afb1a3d30");
INSERT INTO V_LOC
	VALUES ("5a97b41f-fd48-4645-a240-32686ce99a5d",
	2,
	29,
	32,
	"45649a7d-233b-48bb-b6b1-640afb1a3d30");
INSERT INTO V_LOC
	VALUES ("b6f97079-efa9-488d-b153-44155fa9ae90",
	3,
	15,
	18,
	"45649a7d-233b-48bb-b6b1-640afb1a3d30");
INSERT INTO V_LOC
	VALUES ("636eb842-c188-4b12-bd4b-50d26ab157b1",
	4,
	29,
	32,
	"45649a7d-233b-48bb-b6b1-640afb1a3d30");
INSERT INTO V_LOC
	VALUES ("8efaea09-07c8-4e67-a623-cdc9f857ae56",
	9,
	9,
	12,
	"45649a7d-233b-48bb-b6b1-640afb1a3d30");
INSERT INTO ACT_BLK
	VALUES ("597ad114-aa76-432b-a108-c994f2a1c212",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ad93f65d-2a8f-44d1-b97b-db390b53b6a6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("20f61adb-424a-43a4-90c7-0c59f3ec187b",
	"597ad114-aa76-432b-a108-c994f2a1c212",
	"00000000-0000-0000-0000-000000000000",
	2,
	3,
	'box::solving line: 2');
INSERT INTO E_ESS
	VALUES ("20f61adb-424a-43a4-90c7-0c59f3ec187b",
	1,
	0,
	2,
	12,
	2,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("20f61adb-424a-43a4-90c7-0c59f3ec187b");
INSERT INTO E_GSME
	VALUES ("20f61adb-424a-43a4-90c7-0c59f3ec187b",
	"76c97f76-a5f6-4beb-b959-f95945b157a3",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410");
INSERT INTO E_GEN
	VALUES ("20f61adb-424a-43a4-90c7-0c59f3ec187b",
	"45649a7d-233b-48bb-b6b1-640afb1a3d30");
INSERT INTO ACT_BLK
	VALUES ("8070ccab-acd3-4738-9826-7289387d900b",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ad93f65d-2a8f-44d1-b97b-db390b53b6a6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("6236353f-e949-4358-8935-26b28aefde86",
	"8070ccab-acd3-4738-9826-7289387d900b",
	"00000000-0000-0000-0000-000000000000",
	4,
	3,
	'box::solving line: 4');
INSERT INTO E_ESS
	VALUES ("6236353f-e949-4358-8935-26b28aefde86",
	1,
	0,
	4,
	12,
	4,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("6236353f-e949-4358-8935-26b28aefde86");
INSERT INTO E_GSME
	VALUES ("6236353f-e949-4358-8935-26b28aefde86",
	"76c97f76-a5f6-4beb-b959-f95945b157a3",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410");
INSERT INTO E_GEN
	VALUES ("6236353f-e949-4358-8935-26b28aefde86",
	"45649a7d-233b-48bb-b6b1-640afb1a3d30");
INSERT INTO ACT_BLK
	VALUES ("2e3e98a0-6f31-4be6-b904-2ceb22bac83e",
	1,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	6,
	40,
	0,
	0,
	6,
	49,
	0,
	0,
	0,
	0,
	0,
	"ad93f65d-2a8f-44d1-b97b-db390b53b6a6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("efdf2f5f-ba42-4232-b230-f90110569c54",
	"2e3e98a0-6f31-4be6-b904-2ceb22bac83e",
	"0c5a7701-f99a-409d-9c21-8b8205479e7c",
	6,
	3,
	'box::solving line: 6');
INSERT INTO ACT_SEL
	VALUES ("efdf2f5f-ba42-4232-b230-f90110569c54",
	"60cbc147-1f01-4f0f-879f-58d4a9f67abb",
	1,
	'one',
	"fe60e317-7be7-4d28-b4bb-e1f16de12034");
INSERT INTO ACT_SR
	VALUES ("efdf2f5f-ba42-4232-b230-f90110569c54");
INSERT INTO ACT_LNK
	VALUES ("7c05251e-4b49-41a7-8ed3-fbb2f982b0fb",
	'',
	"efdf2f5f-ba42-4232-b230-f90110569c54",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	6,
	40,
	6,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0c5a7701-f99a-409d-9c21-8b8205479e7c",
	"2e3e98a0-6f31-4be6-b904-2ceb22bac83e",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'box::solving line: 7');
INSERT INTO ACT_IF
	VALUES ("0c5a7701-f99a-409d-9c21-8b8205479e7c",
	"3879d905-989a-46a4-90de-1319e2f0b9f6",
	"3777fc5b-527c-4686-aa04-9466c1f5e405",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("baa25c72-92fc-4191-af65-b10791215532",
	"2e3e98a0-6f31-4be6-b904-2ceb22bac83e",
	"00000000-0000-0000-0000-000000000000",
	11,
	3,
	'box::solving line: 11');
INSERT INTO ACT_E
	VALUES ("baa25c72-92fc-4191-af65-b10791215532",
	"fd5061ce-ed0c-43d4-b5c8-8d6c437258b3",
	"0c5a7701-f99a-409d-9c21-8b8205479e7c");
INSERT INTO V_VAL
	VALUES ("fe60e317-7be7-4d28-b4bb-e1f16de12034",
	0,
	0,
	6,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"2e3e98a0-6f31-4be6-b904-2ceb22bac83e");
INSERT INTO V_IRF
	VALUES ("fe60e317-7be7-4d28-b4bb-e1f16de12034",
	"45649a7d-233b-48bb-b6b1-640afb1a3d30");
INSERT INTO V_VAL
	VALUES ("6047a787-8d9d-49fa-a130-0be09b571928",
	0,
	0,
	7,
	8,
	15,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"2e3e98a0-6f31-4be6-b904-2ceb22bac83e");
INSERT INTO V_IRF
	VALUES ("6047a787-8d9d-49fa-a130-0be09b571928",
	"60cbc147-1f01-4f0f-879f-58d4a9f67abb");
INSERT INTO V_VAL
	VALUES ("db1c4689-b7e0-49a3-94c2-70272eb2c55c",
	0,
	0,
	7,
	17,
	24,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"2e3e98a0-6f31-4be6-b904-2ceb22bac83e");
INSERT INTO V_AVL
	VALUES ("db1c4689-b7e0-49a3-94c2-70272eb2c55c",
	"6047a787-8d9d-49fa-a130-0be09b571928",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("3777fc5b-527c-4686-aa04-9466c1f5e405",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"2e3e98a0-6f31-4be6-b904-2ceb22bac83e");
INSERT INTO V_BIN
	VALUES ("3777fc5b-527c-4686-aa04-9466c1f5e405",
	"b400b7f3-bf5f-41a4-8148-88190a2c0baa",
	"db1c4689-b7e0-49a3-94c2-70272eb2c55c",
	'>=');
INSERT INTO V_VAL
	VALUES ("b400b7f3-bf5f-41a4-8148-88190a2c0baa",
	0,
	0,
	7,
	29,
	29,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"2e3e98a0-6f31-4be6-b904-2ceb22bac83e");
INSERT INTO V_LIN
	VALUES ("b400b7f3-bf5f-41a4-8148-88190a2c0baa",
	'1');
INSERT INTO V_VAR
	VALUES ("60cbc147-1f01-4f0f-879f-58d4a9f67abb",
	"2e3e98a0-6f31-4be6-b904-2ceb22bac83e",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("60cbc147-1f01-4f0f-879f-58d4a9f67abb",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("b91d6102-5cae-455e-a4c0-17268f8627bf",
	6,
	14,
	21,
	"60cbc147-1f01-4f0f-879f-58d4a9f67abb");
INSERT INTO V_LOC
	VALUES ("4cddfc5a-2ea4-4fdd-a0f9-51790a69086e",
	7,
	8,
	15,
	"60cbc147-1f01-4f0f-879f-58d4a9f67abb");
INSERT INTO V_LOC
	VALUES ("5c6f128a-2394-4dfb-8968-1508c1cbdde9",
	8,
	5,
	12,
	"60cbc147-1f01-4f0f-879f-58d4a9f67abb");
INSERT INTO V_LOC
	VALUES ("878e0cb4-eb94-4a29-b322-b18daec7a343",
	12,
	5,
	12,
	"60cbc147-1f01-4f0f-879f-58d4a9f67abb");
INSERT INTO ACT_BLK
	VALUES ("3879d905-989a-46a4-90de-1319e2f0b9f6",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ad93f65d-2a8f-44d1-b97b-db390b53b6a6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d7c98e63-b04c-4c15-9508-c457a7c43513",
	"3879d905-989a-46a4-90de-1319e2f0b9f6",
	"d4b61b1d-b338-4d3d-88bb-34a80a8f0757",
	8,
	5,
	'box::solving line: 8');
INSERT INTO ACT_AI
	VALUES ("d7c98e63-b04c-4c15-9508-c457a7c43513",
	"a6fba2f2-e65b-4e29-8916-bee75e4a8667",
	"93e035a1-4745-4e64-8412-b073e5c1f3a5",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d4b61b1d-b338-4d3d-88bb-34a80a8f0757",
	"3879d905-989a-46a4-90de-1319e2f0b9f6",
	"0ccb3303-4f03-4a6f-9143-8a8b4aa06f59",
	9,
	5,
	'box::solving line: 9');
INSERT INTO ACT_AI
	VALUES ("d4b61b1d-b338-4d3d-88bb-34a80a8f0757",
	"92f9fa46-9bb5-4583-8784-c165d4e416ac",
	"f51add63-3361-4f56-a36e-1135f3643ce7",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0ccb3303-4f03-4a6f-9143-8a8b4aa06f59",
	"3879d905-989a-46a4-90de-1319e2f0b9f6",
	"00000000-0000-0000-0000-000000000000",
	10,
	5,
	'box::solving line: 10');
INSERT INTO E_ESS
	VALUES ("0ccb3303-4f03-4a6f-9143-8a8b4aa06f59",
	1,
	0,
	10,
	14,
	10,
	19,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("0ccb3303-4f03-4a6f-9143-8a8b4aa06f59");
INSERT INTO E_GSME
	VALUES ("0ccb3303-4f03-4a6f-9143-8a8b4aa06f59",
	"d7e974e2-f076-486f-8751-749403cb72ec",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410");
INSERT INTO E_GEN
	VALUES ("0ccb3303-4f03-4a6f-9143-8a8b4aa06f59",
	"18d1998f-fd95-4825-b2f5-2d469b019e7d");
INSERT INTO V_VAL
	VALUES ("b95ae16e-a862-4688-89f5-be6dec0a1629",
	1,
	0,
	8,
	5,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3879d905-989a-46a4-90de-1319e2f0b9f6");
INSERT INTO V_IRF
	VALUES ("b95ae16e-a862-4688-89f5-be6dec0a1629",
	"60cbc147-1f01-4f0f-879f-58d4a9f67abb");
INSERT INTO V_VAL
	VALUES ("93e035a1-4745-4e64-8412-b073e5c1f3a5",
	1,
	0,
	8,
	14,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3879d905-989a-46a4-90de-1319e2f0b9f6");
INSERT INTO V_AVL
	VALUES ("93e035a1-4745-4e64-8412-b073e5c1f3a5",
	"b95ae16e-a862-4688-89f5-be6dec0a1629",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("a6fba2f2-e65b-4e29-8916-bee75e4a8667",
	0,
	0,
	8,
	25,
	25,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3879d905-989a-46a4-90de-1319e2f0b9f6");
INSERT INTO V_LIN
	VALUES ("a6fba2f2-e65b-4e29-8916-bee75e4a8667",
	'1');
INSERT INTO V_VAL
	VALUES ("f51add63-3361-4f56-a36e-1135f3643ce7",
	1,
	1,
	9,
	5,
	5,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3879d905-989a-46a4-90de-1319e2f0b9f6");
INSERT INTO V_IRF
	VALUES ("f51add63-3361-4f56-a36e-1135f3643ce7",
	"18d1998f-fd95-4825-b2f5-2d469b019e7d");
INSERT INTO V_VAL
	VALUES ("92f9fa46-9bb5-4583-8784-c165d4e416ac",
	0,
	0,
	9,
	9,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3879d905-989a-46a4-90de-1319e2f0b9f6");
INSERT INTO V_IRF
	VALUES ("92f9fa46-9bb5-4583-8784-c165d4e416ac",
	"45649a7d-233b-48bb-b6b1-640afb1a3d30");
INSERT INTO V_VAR
	VALUES ("18d1998f-fd95-4825-b2f5-2d469b019e7d",
	"3879d905-989a-46a4-90de-1319e2f0b9f6",
	'b',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("18d1998f-fd95-4825-b2f5-2d469b019e7d",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("5c269023-aaa2-480c-9fb1-bf731551b95a",
	9,
	5,
	5,
	"18d1998f-fd95-4825-b2f5-2d469b019e7d");
INSERT INTO V_LOC
	VALUES ("14bc0ab9-2616-4d55-8a84-634c5895b036",
	10,
	31,
	31,
	"18d1998f-fd95-4825-b2f5-2d469b019e7d");
INSERT INTO ACT_BLK
	VALUES ("fd5061ce-ed0c-43d4-b5c8-8d6c437258b3",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ad93f65d-2a8f-44d1-b97b-db390b53b6a6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("64f7141c-2a14-46a9-bcad-c2a79600b821",
	"fd5061ce-ed0c-43d4-b5c8-8d6c437258b3",
	"00000000-0000-0000-0000-000000000000",
	12,
	5,
	'box::solving line: 12');
INSERT INTO ACT_AI
	VALUES ("64f7141c-2a14-46a9-bcad-c2a79600b821",
	"6e1b120c-604a-44f8-8a57-c6ae8f6c18d8",
	"16dff43f-858c-4d7a-bc0d-37025c0b04ed",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("2a78e022-b7d0-4851-929b-f080745c025c",
	1,
	0,
	12,
	5,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"fd5061ce-ed0c-43d4-b5c8-8d6c437258b3");
INSERT INTO V_IRF
	VALUES ("2a78e022-b7d0-4851-929b-f080745c025c",
	"60cbc147-1f01-4f0f-879f-58d4a9f67abb");
INSERT INTO V_VAL
	VALUES ("16dff43f-858c-4d7a-bc0d-37025c0b04ed",
	1,
	0,
	12,
	14,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"fd5061ce-ed0c-43d4-b5c8-8d6c437258b3");
INSERT INTO V_AVL
	VALUES ("16dff43f-858c-4d7a-bc0d-37025c0b04ed",
	"2a78e022-b7d0-4851-929b-f080745c025c",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("6e1b120c-604a-44f8-8a57-c6ae8f6c18d8",
	0,
	0,
	12,
	25,
	25,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"fd5061ce-ed0c-43d4-b5c8-8d6c437258b3");
INSERT INTO V_LIN
	VALUES ("6e1b120c-604a-44f8-8a57-c6ae8f6c18d8",
	'0');
INSERT INTO SM_STATE
	VALUES ("2dcd9113-9cfe-440c-903b-fe6740215ba2",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000",
	'solved',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES ("2dcd9113-9cfe-440c-903b-fe6740215ba2",
	"d7e974e2-f076-486f-8751-749403cb72ec",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("2dcd9113-9cfe-440c-903b-fe6740215ba2",
	"d7e974e2-f076-486f-8751-749403cb72ec",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EIGN
	VALUES ("2dcd9113-9cfe-440c-903b-fe6740215ba2",
	"76c97f76-a5f6-4beb-b959-f95945b157a3",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("2dcd9113-9cfe-440c-903b-fe6740215ba2",
	"76c97f76-a5f6-4beb-b959-f95945b157a3",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("87fcabf7-7dcc-4633-b4cf-b238e3b546d8",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"2dcd9113-9cfe-440c-903b-fe6740215ba2");
INSERT INTO SM_AH
	VALUES ("87fcabf7-7dcc-4633-b4cf-b238e3b546d8",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410");
INSERT INTO SM_ACT
	VALUES ("87fcabf7-7dcc-4633-b4cf-b238e3b546d8",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	1,
	'select one sequence related by self->SEQUENCE[R1];
sequence.solved = true;',
	'');
INSERT INTO ACT_SAB
	VALUES ("28ceefc1-8491-4c07-ab35-87151bea082c",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"87fcabf7-7dcc-4633-b4cf-b238e3b546d8");
INSERT INTO ACT_ACT
	VALUES ("28ceefc1-8491-4c07-ab35-87151bea082c",
	'state',
	0,
	"7de7c35f-92e3-4f1d-826c-7f08cce414a4",
	"00000000-0000-0000-0000-000000000000",
	0,
	'box::solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("7de7c35f-92e3-4f1d-826c-7f08cce414a4",
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	1,
	47,
	0,
	0,
	0,
	0,
	0,
	"28ceefc1-8491-4c07-ab35-87151bea082c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("2b17c495-df3f-4ed2-b0f9-9e10e047b09f",
	"7de7c35f-92e3-4f1d-826c-7f08cce414a4",
	"9cf59cdc-de72-4ef9-b854-2a98ba656516",
	1,
	1,
	'box::solved line: 1');
INSERT INTO ACT_SEL
	VALUES ("2b17c495-df3f-4ed2-b0f9-9e10e047b09f",
	"7f76d7f7-1c17-4f8b-a4c0-43a24f7c7c23",
	1,
	'one',
	"ef0011a2-cc4a-41bc-8628-1e90cc622871");
INSERT INTO ACT_SR
	VALUES ("2b17c495-df3f-4ed2-b0f9-9e10e047b09f");
INSERT INTO ACT_LNK
	VALUES ("d27f4d75-2f9f-4963-adcd-ca4c098287c8",
	'',
	"2b17c495-df3f-4ed2-b0f9-9e10e047b09f",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	1,
	38,
	1,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9cf59cdc-de72-4ef9-b854-2a98ba656516",
	"7de7c35f-92e3-4f1d-826c-7f08cce414a4",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'box::solved line: 2');
INSERT INTO ACT_AI
	VALUES ("9cf59cdc-de72-4ef9-b854-2a98ba656516",
	"b1dd8f93-9b82-4433-84f3-62ca2542156a",
	"fa84c9d5-a53e-4d8e-a6c5-3919d0d2fc4b",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("ef0011a2-cc4a-41bc-8628-1e90cc622871",
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"7de7c35f-92e3-4f1d-826c-7f08cce414a4");
INSERT INTO V_IRF
	VALUES ("ef0011a2-cc4a-41bc-8628-1e90cc622871",
	"eb91de8b-79ae-41a1-80d8-1d0a45d08d33");
INSERT INTO V_VAL
	VALUES ("b07d532a-8981-45a6-be30-5763d05ab787",
	1,
	0,
	2,
	1,
	8,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"7de7c35f-92e3-4f1d-826c-7f08cce414a4");
INSERT INTO V_IRF
	VALUES ("b07d532a-8981-45a6-be30-5763d05ab787",
	"7f76d7f7-1c17-4f8b-a4c0-43a24f7c7c23");
INSERT INTO V_VAL
	VALUES ("fa84c9d5-a53e-4d8e-a6c5-3919d0d2fc4b",
	1,
	0,
	2,
	10,
	15,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"7de7c35f-92e3-4f1d-826c-7f08cce414a4");
INSERT INTO V_AVL
	VALUES ("fa84c9d5-a53e-4d8e-a6c5-3919d0d2fc4b",
	"b07d532a-8981-45a6-be30-5763d05ab787",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"52c42da4-a4c5-4627-bb84-a09549090418");
INSERT INTO V_VAL
	VALUES ("b1dd8f93-9b82-4433-84f3-62ca2542156a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"7de7c35f-92e3-4f1d-826c-7f08cce414a4");
INSERT INTO V_LBO
	VALUES ("b1dd8f93-9b82-4433-84f3-62ca2542156a",
	'TRUE');
INSERT INTO V_VAR
	VALUES ("7f76d7f7-1c17-4f8b-a4c0-43a24f7c7c23",
	"7de7c35f-92e3-4f1d-826c-7f08cce414a4",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("7f76d7f7-1c17-4f8b-a4c0-43a24f7c7c23",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("80858060-2804-454e-a304-a70102fd09af",
	1,
	12,
	19,
	"7f76d7f7-1c17-4f8b-a4c0-43a24f7c7c23");
INSERT INTO V_LOC
	VALUES ("20f33b06-1fe9-4dd5-98a6-9fc882eb698f",
	2,
	1,
	8,
	"7f76d7f7-1c17-4f8b-a4c0-43a24f7c7c23");
INSERT INTO V_VAR
	VALUES ("eb91de8b-79ae-41a1-80d8-1d0a45d08d33",
	"7de7c35f-92e3-4f1d-826c-7f08cce414a4",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("eb91de8b-79ae-41a1-80d8-1d0a45d08d33",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO SM_NSTXN
	VALUES ("f73b6657-e677-46a9-9219-d092912cd683",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"56f8c26a-1557-4152-9ef5-a70c1fc254f7",
	"d7e974e2-f076-486f-8751-749403cb72ec",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("4cf07b25-abce-4487-9ee2-0f4e00bd6209",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"f73b6657-e677-46a9-9219-d092912cd683");
INSERT INTO SM_AH
	VALUES ("4cf07b25-abce-4487-9ee2-0f4e00bd6209",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410");
INSERT INTO SM_ACT
	VALUES ("4cf07b25-abce-4487-9ee2-0f4e00bd6209",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("0683fb04-82a6-4b1b-bda0-edf271cfc24a",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"4cf07b25-abce-4487-9ee2-0f4e00bd6209");
INSERT INTO ACT_ACT
	VALUES ("0683fb04-82a6-4b1b-bda0-edf271cfc24a",
	'transition',
	0,
	"94e60503-9b5d-4e03-9371-cb51ea5280ba",
	"00000000-0000-0000-0000-000000000000",
	0,
	'BOX1: update in solving to solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("94e60503-9b5d-4e03-9371-cb51ea5280ba",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0683fb04-82a6-4b1b-bda0-edf271cfc24a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("f73b6657-e677-46a9-9219-d092912cd683",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"56f8c26a-1557-4152-9ef5-a70c1fc254f7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("0c67e84b-fbd0-415b-9196-f4a946b12252",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"56f8c26a-1557-4152-9ef5-a70c1fc254f7",
	"76c97f76-a5f6-4beb-b959-f95945b157a3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("fb4fb71a-449d-4f41-bc0c-a9117ab42e42",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"0c67e84b-fbd0-415b-9196-f4a946b12252");
INSERT INTO SM_AH
	VALUES ("fb4fb71a-449d-4f41-bc0c-a9117ab42e42",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410");
INSERT INTO SM_ACT
	VALUES ("fb4fb71a-449d-4f41-bc0c-a9117ab42e42",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("96edd556-6145-4efe-b19e-e8279bfb9dc0",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"fb4fb71a-449d-4f41-bc0c-a9117ab42e42");
INSERT INTO ACT_ACT
	VALUES ("96edd556-6145-4efe-b19e-e8279bfb9dc0",
	'transition',
	0,
	"03b4d38d-9ba7-47e0-805a-fc20091cc59b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'BOX2: solved in solving to solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("03b4d38d-9ba7-47e0-805a-fc20091cc59b",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"96edd556-6145-4efe-b19e-e8279bfb9dc0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("0c67e84b-fbd0-415b-9196-f4a946b12252",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410",
	"2dcd9113-9cfe-440c-903b-fe6740215ba2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_OBJ
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	'cell',
	5,
	'CELL',
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO O_TFR
	VALUES ("4f679239-a22a-49f6-94ac-aa4a28d43e87",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	'set_given',
	'',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	0,
	'select any cell from instances of CELL
  where ( ( selected.row_number == param.row ) and 
          ( selected.column_number == param.column ) );
cell.answer( answer_digit:param.answer );',
	1,
	'',
	"85d40a8c-8b51-408d-85d3-824453116397");
INSERT INTO O_TPARM
	VALUES ("037e6fcf-72af-4af2-97aa-9295e5682c5b",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	'row',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"347a4a75-9ae1-4e4c-a5d3-efa5c7fb9d69",
	'');
INSERT INTO O_TPARM
	VALUES ("347a4a75-9ae1-4e4c-a5d3-efa5c7fb9d69",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	'column',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"9ccd1fa7-1987-4964-bc23-3f5d2c7fad3d",
	'');
INSERT INTO O_TPARM
	VALUES ("9ccd1fa7-1987-4964-bc23-3f5d2c7fad3d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87",
	'answer',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_OPB
	VALUES ("cce296f1-a6db-4370-9718-76dbf75a934d",
	"4f679239-a22a-49f6-94ac-aa4a28d43e87");
INSERT INTO ACT_ACT
	VALUES ("cce296f1-a6db-4370-9718-76dbf75a934d",
	'class operation',
	0,
	"633f8b34-3de4-4a4c-b704-21e7d293279b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cell::set_given',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("633f8b34-3de4-4a4c-b704-21e7d293279b",
	1,
	0,
	1,
	'',
	'',
	'',
	4,
	1,
	1,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"cce296f1-a6db-4370-9718-76dbf75a934d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7cf20d04-d9e0-4880-bd71-1b0a99e13726",
	"633f8b34-3de4-4a4c-b704-21e7d293279b",
	"827fe23c-5edb-4d19-b2fc-fd8091d5a381",
	1,
	1,
	'cell::set_given line: 1');
INSERT INTO ACT_FIW
	VALUES ("7cf20d04-d9e0-4880-bd71-1b0a99e13726",
	"39457bff-35e4-4c53-8399-daf3bd53b19d",
	1,
	'any',
	"58b7b9ba-4479-4214-bb86-7d96a19ea36c",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	1,
	35);
INSERT INTO ACT_SMT
	VALUES ("827fe23c-5edb-4d19-b2fc-fd8091d5a381",
	"633f8b34-3de4-4a4c-b704-21e7d293279b",
	"00000000-0000-0000-0000-000000000000",
	4,
	1,
	'cell::set_given line: 4');
INSERT INTO ACT_TFM
	VALUES ("827fe23c-5edb-4d19-b2fc-fd8091d5a381",
	"4dbd3878-9ff1-4fa9-8ff2-db063b3aa997",
	"39457bff-35e4-4c53-8399-daf3bd53b19d",
	4,
	6,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("ce344fe6-5296-42c0-ad3c-d7c699179bbf",
	0,
	0,
	2,
	13,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"633f8b34-3de4-4a4c-b704-21e7d293279b");
INSERT INTO V_SLR
	VALUES ("ce344fe6-5296-42c0-ad3c-d7c699179bbf",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("9ff4848e-47b5-4aa3-9818-413e5aca82f3",
	0,
	0,
	2,
	22,
	31,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"633f8b34-3de4-4a4c-b704-21e7d293279b");
INSERT INTO V_AVL
	VALUES ("9ff4848e-47b5-4aa3-9818-413e5aca82f3",
	"ce344fe6-5296-42c0-ad3c-d7c699179bbf",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26");
INSERT INTO V_VAL
	VALUES ("4d25493c-0cf9-4dae-99f6-080a32151417",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"633f8b34-3de4-4a4c-b704-21e7d293279b");
INSERT INTO V_BIN
	VALUES ("4d25493c-0cf9-4dae-99f6-080a32151417",
	"0bc14f44-80ab-42ba-ada2-98e5fa9f5e4f",
	"9ff4848e-47b5-4aa3-9818-413e5aca82f3",
	'==');
INSERT INTO V_VAL
	VALUES ("0bc14f44-80ab-42ba-ada2-98e5fa9f5e4f",
	0,
	0,
	2,
	42,
	44,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"633f8b34-3de4-4a4c-b704-21e7d293279b");
INSERT INTO V_PVL
	VALUES ("0bc14f44-80ab-42ba-ada2-98e5fa9f5e4f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"037e6fcf-72af-4af2-97aa-9295e5682c5b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("8530f9fd-2284-4c95-b9ca-08a56165612e",
	0,
	0,
	3,
	13,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"633f8b34-3de4-4a4c-b704-21e7d293279b");
INSERT INTO V_SLR
	VALUES ("8530f9fd-2284-4c95-b9ca-08a56165612e",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("56508b07-ff90-4697-bd07-30a7dd316da9",
	0,
	0,
	3,
	22,
	34,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"633f8b34-3de4-4a4c-b704-21e7d293279b");
INSERT INTO V_AVL
	VALUES ("56508b07-ff90-4697-bd07-30a7dd316da9",
	"8530f9fd-2284-4c95-b9ca-08a56165612e",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b");
INSERT INTO V_VAL
	VALUES ("3bb78c3c-09b7-4daf-8cb6-ad86719c75b4",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"633f8b34-3de4-4a4c-b704-21e7d293279b");
INSERT INTO V_BIN
	VALUES ("3bb78c3c-09b7-4daf-8cb6-ad86719c75b4",
	"ff4ecb3b-812d-477f-9109-ba8dae3b671c",
	"56508b07-ff90-4697-bd07-30a7dd316da9",
	'==');
INSERT INTO V_VAL
	VALUES ("ff4ecb3b-812d-477f-9109-ba8dae3b671c",
	0,
	0,
	3,
	45,
	50,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"633f8b34-3de4-4a4c-b704-21e7d293279b");
INSERT INTO V_PVL
	VALUES ("ff4ecb3b-812d-477f-9109-ba8dae3b671c",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"347a4a75-9ae1-4e4c-a5d3-efa5c7fb9d69",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("58b7b9ba-4479-4214-bb86-7d96a19ea36c",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"633f8b34-3de4-4a4c-b704-21e7d293279b");
INSERT INTO V_BIN
	VALUES ("58b7b9ba-4479-4214-bb86-7d96a19ea36c",
	"3bb78c3c-09b7-4daf-8cb6-ad86719c75b4",
	"4d25493c-0cf9-4dae-99f6-080a32151417",
	'and');
INSERT INTO V_VAL
	VALUES ("b34258f5-0d00-417d-af8c-83fcedbb569c",
	0,
	0,
	4,
	33,
	38,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"633f8b34-3de4-4a4c-b704-21e7d293279b");
INSERT INTO V_PVL
	VALUES ("b34258f5-0d00-417d-af8c-83fcedbb569c",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"9ccd1fa7-1987-4964-bc23-3f5d2c7fad3d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_PAR
	VALUES ("b34258f5-0d00-417d-af8c-83fcedbb569c",
	"827fe23c-5edb-4d19-b2fc-fd8091d5a381",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	4,
	14);
INSERT INTO V_VAR
	VALUES ("39457bff-35e4-4c53-8399-daf3bd53b19d",
	"633f8b34-3de4-4a4c-b704-21e7d293279b",
	'cell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("39457bff-35e4-4c53-8399-daf3bd53b19d",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("1178600e-30d9-485d-acdb-4075a1404880",
	1,
	12,
	15,
	"39457bff-35e4-4c53-8399-daf3bd53b19d");
INSERT INTO V_LOC
	VALUES ("d7952aff-c53c-4a2c-b9a9-72de451bc0a8",
	4,
	1,
	4,
	"39457bff-35e4-4c53-8399-daf3bd53b19d");
INSERT INTO O_TFR
	VALUES ("4dbd3878-9ff1-4fa9-8ff2-db063b3aa997",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	'answer',
	'',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	1,
	'// An answer has been found, so remove the eligible
// digits which are now ineligible digits.
select one zerodigit related by self->DIGIT[R9] where ( selected.value == 0 );
if ( not_empty zerodigit )
  unrelate self from zerodigit across R9;
end if;

// Link in the answer.
select any digit from instances of DIGIT 
  where ( selected.value == param.answer_digit );
if ( not_empty digit )
  relate self to digit across R9;
end if;

// Unlink the other digits.  There can be only one answer.
select many ineligibles related by self->ELIGIBLE[R8]
  where ( selected.digit_value != param.answer_digit );
for each ineligible in ineligibles
  select one digit related by ineligible->DIGIT[R8];
  unrelate self from digit across R8 using ineligible;
  delete object instance ineligible;
end for;',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_TPARM
	VALUES ("8c6ac5a8-04f5-4014-884c-f7153bccf1ff",
	"4dbd3878-9ff1-4fa9-8ff2-db063b3aa997",
	'answer_digit',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_OPB
	VALUES ("8da9558e-a27a-477d-9370-b794215790bc",
	"4dbd3878-9ff1-4fa9-8ff2-db063b3aa997");
INSERT INTO ACT_ACT
	VALUES ("8da9558e-a27a-477d-9370-b794215790bc",
	'operation',
	0,
	"8563231d-42c6-410a-802b-0f586cb1d623",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cell::answer',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("8563231d-42c6-410a-802b-0f586cb1d623",
	1,
	0,
	1,
	'',
	'',
	'',
	18,
	1,
	16,
	42,
	0,
	0,
	16,
	51,
	0,
	0,
	0,
	0,
	0,
	"8da9558e-a27a-477d-9370-b794215790bc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("efce7498-a0fe-44f4-a466-5dc6b8f34a07",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	"5bbc9f50-c1b8-4e52-a235-cb2f625f8451",
	3,
	1,
	'cell::answer line: 3');
INSERT INTO ACT_SEL
	VALUES ("efce7498-a0fe-44f4-a466-5dc6b8f34a07",
	"6798c8ba-d376-4590-9457-f566f8f6e651",
	1,
	'one',
	"d0b2c2ba-20aa-4b64-9cbc-c6c54037da65");
INSERT INTO ACT_SRW
	VALUES ("efce7498-a0fe-44f4-a466-5dc6b8f34a07",
	"d779e933-c8b1-4f34-a3d6-5f366cd9b188");
INSERT INTO ACT_LNK
	VALUES ("7f220417-dce3-411c-bdf9-1c3278a298a1",
	'',
	"efce7498-a0fe-44f4-a466-5dc6b8f34a07",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"00000000-0000-0000-0000-000000000000",
	2,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	3,
	39,
	3,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5bbc9f50-c1b8-4e52-a235-cb2f625f8451",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	"7e84599f-5b79-4a86-8dc2-0b3ce5cb18a8",
	4,
	1,
	'cell::answer line: 4');
INSERT INTO ACT_IF
	VALUES ("5bbc9f50-c1b8-4e52-a235-cb2f625f8451",
	"a61a3452-0399-44a0-9734-a888d810a173",
	"3b42123c-be20-4e91-99a0-490c632c9833",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7e84599f-5b79-4a86-8dc2-0b3ce5cb18a8",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	"fa0a90a0-3117-4ac0-8c3f-ed8e51c5f375",
	9,
	1,
	'cell::answer line: 9');
INSERT INTO ACT_FIW
	VALUES ("7e84599f-5b79-4a86-8dc2-0b3ce5cb18a8",
	"4c04f981-155c-4c7d-a820-1d7e419de9d9",
	1,
	'any',
	"7a5e0039-968d-4a25-9df5-b138a727b641",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	9,
	36);
INSERT INTO ACT_SMT
	VALUES ("fa0a90a0-3117-4ac0-8c3f-ed8e51c5f375",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	"297f5594-b641-4207-b396-f0daf7b74dd8",
	11,
	1,
	'cell::answer line: 11');
INSERT INTO ACT_IF
	VALUES ("fa0a90a0-3117-4ac0-8c3f-ed8e51c5f375",
	"e24fa69f-4950-4ce0-8374-37396f48bb9f",
	"735bb96d-647f-4593-97b5-4b9bc3677dc0",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("297f5594-b641-4207-b396-f0daf7b74dd8",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	"acc984ae-cf8d-45a8-9471-b4735e62994e",
	16,
	1,
	'cell::answer line: 16');
INSERT INTO ACT_SEL
	VALUES ("297f5594-b641-4207-b396-f0daf7b74dd8",
	"733b019e-e191-45ae-bcdd-096019186faa",
	1,
	'many',
	"275b995e-97a4-45a1-af4f-a97f9febc5be");
INSERT INTO ACT_SRW
	VALUES ("297f5594-b641-4207-b396-f0daf7b74dd8",
	"234a8391-b34a-48b9-bbc3-f046767c3dff");
INSERT INTO ACT_LNK
	VALUES ("0dd3940d-8a07-4054-8981-b96f17466cec",
	'',
	"297f5594-b641-4207-b396-f0daf7b74dd8",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	16,
	42,
	16,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("acc984ae-cf8d-45a8-9471-b4735e62994e",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	"00000000-0000-0000-0000-000000000000",
	18,
	1,
	'cell::answer line: 18');
INSERT INTO ACT_FOR
	VALUES ("acc984ae-cf8d-45a8-9471-b4735e62994e",
	"e7af8251-f2d7-407f-8059-882cf777ec1e",
	1,
	"4eb1f630-51f5-416c-9624-832e209a071e",
	"733b019e-e191-45ae-bcdd-096019186faa",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_VAL
	VALUES ("d0b2c2ba-20aa-4b64-9cbc-c6c54037da65",
	0,
	0,
	3,
	33,
	36,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_IRF
	VALUES ("d0b2c2ba-20aa-4b64-9cbc-c6c54037da65",
	"6d324f90-3a55-4452-a918-ee6d621f4536");
INSERT INTO V_VAL
	VALUES ("531243ec-c685-42f6-bcdf-ddf9af6d9748",
	0,
	0,
	3,
	57,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_SLR
	VALUES ("531243ec-c685-42f6-bcdf-ddf9af6d9748",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("c7f59d1b-37fb-45f3-b93b-3230ae5cbd8a",
	0,
	0,
	3,
	66,
	70,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_AVL
	VALUES ("c7f59d1b-37fb-45f3-b93b-3230ae5cbd8a",
	"531243ec-c685-42f6-bcdf-ddf9af6d9748",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO V_VAL
	VALUES ("d779e933-c8b1-4f34-a3d6-5f366cd9b188",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_BIN
	VALUES ("d779e933-c8b1-4f34-a3d6-5f366cd9b188",
	"8cdaaf78-ccfb-412d-87aa-1f33449a42ed",
	"c7f59d1b-37fb-45f3-b93b-3230ae5cbd8a",
	'==');
INSERT INTO V_VAL
	VALUES ("8cdaaf78-ccfb-412d-87aa-1f33449a42ed",
	0,
	0,
	3,
	75,
	75,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_LIN
	VALUES ("8cdaaf78-ccfb-412d-87aa-1f33449a42ed",
	'0');
INSERT INTO V_VAL
	VALUES ("71637c3d-ca1b-4b9f-9bb4-2c578b3b6ee9",
	0,
	0,
	4,
	16,
	24,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_IRF
	VALUES ("71637c3d-ca1b-4b9f-9bb4-2c578b3b6ee9",
	"6798c8ba-d376-4590-9457-f566f8f6e651");
INSERT INTO V_VAL
	VALUES ("3b42123c-be20-4e91-99a0-490c632c9833",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_UNY
	VALUES ("3b42123c-be20-4e91-99a0-490c632c9833",
	"71637c3d-ca1b-4b9f-9bb4-2c578b3b6ee9",
	'not_empty');
INSERT INTO V_VAL
	VALUES ("1754677a-96ac-4dcd-b64d-87234bab3f58",
	0,
	0,
	10,
	11,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_SLR
	VALUES ("1754677a-96ac-4dcd-b64d-87234bab3f58",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("ea0c7df9-f1ba-47b5-8671-c1386b9a6d85",
	0,
	0,
	10,
	20,
	24,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_AVL
	VALUES ("ea0c7df9-f1ba-47b5-8671-c1386b9a6d85",
	"1754677a-96ac-4dcd-b64d-87234bab3f58",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO V_VAL
	VALUES ("7a5e0039-968d-4a25-9df5-b138a727b641",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_BIN
	VALUES ("7a5e0039-968d-4a25-9df5-b138a727b641",
	"69616406-8e0f-4e69-ba07-878e589d6387",
	"ea0c7df9-f1ba-47b5-8671-c1386b9a6d85",
	'==');
INSERT INTO V_VAL
	VALUES ("69616406-8e0f-4e69-ba07-878e589d6387",
	0,
	0,
	10,
	35,
	46,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_PVL
	VALUES ("69616406-8e0f-4e69-ba07-878e589d6387",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"8c6ac5a8-04f5-4014-884c-f7153bccf1ff",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("d053ae38-9145-468a-b186-5d588e325cd6",
	0,
	0,
	11,
	16,
	20,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_IRF
	VALUES ("d053ae38-9145-468a-b186-5d588e325cd6",
	"4c04f981-155c-4c7d-a820-1d7e419de9d9");
INSERT INTO V_VAL
	VALUES ("735bb96d-647f-4593-97b5-4b9bc3677dc0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_UNY
	VALUES ("735bb96d-647f-4593-97b5-4b9bc3677dc0",
	"d053ae38-9145-468a-b186-5d588e325cd6",
	'not_empty');
INSERT INTO V_VAL
	VALUES ("275b995e-97a4-45a1-af4f-a97f9febc5be",
	0,
	0,
	16,
	36,
	39,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_IRF
	VALUES ("275b995e-97a4-45a1-af4f-a97f9febc5be",
	"6d324f90-3a55-4452-a918-ee6d621f4536");
INSERT INTO V_VAL
	VALUES ("bbdad9c4-c25c-428c-ba26-05597ce1e22c",
	0,
	0,
	17,
	11,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_SLR
	VALUES ("bbdad9c4-c25c-428c-ba26-05597ce1e22c",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("ea247b9b-2f45-482d-8ef2-aeb644e31641",
	0,
	0,
	17,
	20,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_AVL
	VALUES ("ea247b9b-2f45-482d-8ef2-aeb644e31641",
	"bbdad9c4-c25c-428c-ba26-05597ce1e22c",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("234a8391-b34a-48b9-bbc3-f046767c3dff",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_BIN
	VALUES ("234a8391-b34a-48b9-bbc3-f046767c3dff",
	"243d9c02-2225-4ec4-8992-879735a17b28",
	"ea247b9b-2f45-482d-8ef2-aeb644e31641",
	'!=');
INSERT INTO V_VAL
	VALUES ("243d9c02-2225-4ec4-8992-879735a17b28",
	0,
	0,
	17,
	41,
	52,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"8563231d-42c6-410a-802b-0f586cb1d623");
INSERT INTO V_PVL
	VALUES ("243d9c02-2225-4ec4-8992-879735a17b28",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"8c6ac5a8-04f5-4014-884c-f7153bccf1ff",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAR
	VALUES ("6798c8ba-d376-4590-9457-f566f8f6e651",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	'zerodigit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("6798c8ba-d376-4590-9457-f566f8f6e651",
	0,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("7f3e16a2-4612-442d-87a1-0f5ed0b8ead1",
	3,
	12,
	20,
	"6798c8ba-d376-4590-9457-f566f8f6e651");
INSERT INTO V_LOC
	VALUES ("2fb35430-76e0-4251-a5ec-e2f4f5423286",
	5,
	22,
	30,
	"6798c8ba-d376-4590-9457-f566f8f6e651");
INSERT INTO V_VAR
	VALUES ("6d324f90-3a55-4452-a918-ee6d621f4536",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("6d324f90-3a55-4452-a918-ee6d621f4536",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("da0049b0-f974-4f84-a88a-f61bec4b825a",
	5,
	12,
	15,
	"6d324f90-3a55-4452-a918-ee6d621f4536");
INSERT INTO V_LOC
	VALUES ("f01c6ad6-31cf-45b8-a1c8-cde3ae79d099",
	12,
	10,
	13,
	"6d324f90-3a55-4452-a918-ee6d621f4536");
INSERT INTO V_LOC
	VALUES ("79c45f83-c8c2-4f6d-bbe3-8f918599c28d",
	20,
	12,
	15,
	"6d324f90-3a55-4452-a918-ee6d621f4536");
INSERT INTO V_VAR
	VALUES ("4c04f981-155c-4c7d-a820-1d7e419de9d9",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	'digit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("4c04f981-155c-4c7d-a820-1d7e419de9d9",
	0,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("0883ae21-3130-43b8-9964-235af038d413",
	9,
	12,
	16,
	"4c04f981-155c-4c7d-a820-1d7e419de9d9");
INSERT INTO V_LOC
	VALUES ("cac88e5c-c0ce-4544-8bed-5e4626bd2b48",
	12,
	18,
	22,
	"4c04f981-155c-4c7d-a820-1d7e419de9d9");
INSERT INTO V_LOC
	VALUES ("af960ca1-0657-44b7-a118-e67e736589a4",
	19,
	14,
	18,
	"4c04f981-155c-4c7d-a820-1d7e419de9d9");
INSERT INTO V_LOC
	VALUES ("1c28bf92-e75a-42dc-9556-aee31f7e627f",
	20,
	22,
	26,
	"4c04f981-155c-4c7d-a820-1d7e419de9d9");
INSERT INTO V_VAR
	VALUES ("733b019e-e191-45ae-bcdd-096019186faa",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	'ineligibles',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("733b019e-e191-45ae-bcdd-096019186faa",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("a2f13973-7d58-4136-9765-ba5e259f801b",
	16,
	13,
	23,
	"733b019e-e191-45ae-bcdd-096019186faa");
INSERT INTO V_LOC
	VALUES ("3cba5fb2-8a6e-452a-b06d-a296ec03557d",
	18,
	24,
	34,
	"733b019e-e191-45ae-bcdd-096019186faa");
INSERT INTO V_VAR
	VALUES ("4eb1f630-51f5-416c-9624-832e209a071e",
	"8563231d-42c6-410a-802b-0f586cb1d623",
	'ineligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("4eb1f630-51f5-416c-9624-832e209a071e",
	1,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("1cb08567-53a0-40ab-8b74-5b2a3c3fe251",
	18,
	10,
	19,
	"4eb1f630-51f5-416c-9624-832e209a071e");
INSERT INTO V_LOC
	VALUES ("59dbc176-6c69-4797-91ff-c2d1cd34d882",
	20,
	44,
	53,
	"4eb1f630-51f5-416c-9624-832e209a071e");
INSERT INTO V_LOC
	VALUES ("ea74ae6a-e586-43c2-899d-5f8f0b4b8c9f",
	21,
	26,
	35,
	"4eb1f630-51f5-416c-9624-832e209a071e");
INSERT INTO ACT_BLK
	VALUES ("a61a3452-0399-44a0-9734-a888d810a173",
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	3,
	0,
	0,
	0,
	0,
	5,
	39,
	0,
	0,
	0,
	0,
	0,
	"8da9558e-a27a-477d-9370-b794215790bc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d758c118-18b8-4fc4-9402-db1db4b7309f",
	"a61a3452-0399-44a0-9734-a888d810a173",
	"00000000-0000-0000-0000-000000000000",
	5,
	3,
	'cell::answer line: 5');
INSERT INTO ACT_UNR
	VALUES ("d758c118-18b8-4fc4-9402-db1db4b7309f",
	"6d324f90-3a55-4452-a918-ee6d621f4536",
	"6798c8ba-d376-4590-9457-f566f8f6e651",
	'',
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	5,
	39,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("e24fa69f-4950-4ce0-8374-37396f48bb9f",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	3,
	0,
	0,
	0,
	0,
	12,
	31,
	0,
	0,
	0,
	0,
	0,
	"8da9558e-a27a-477d-9370-b794215790bc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("2ff4eee9-9ae5-46a3-b5a2-26d49ff55d40",
	"e24fa69f-4950-4ce0-8374-37396f48bb9f",
	"00000000-0000-0000-0000-000000000000",
	12,
	3,
	'cell::answer line: 12');
INSERT INTO ACT_REL
	VALUES ("2ff4eee9-9ae5-46a3-b5a2-26d49ff55d40",
	"6d324f90-3a55-4452-a918-ee6d621f4536",
	"4c04f981-155c-4c7d-a820-1d7e419de9d9",
	'',
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	12,
	31,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("e7af8251-f2d7-407f-8059-882cf777ec1e",
	1,
	0,
	0,
	'',
	'',
	'',
	21,
	3,
	19,
	43,
	0,
	0,
	20,
	35,
	0,
	0,
	0,
	0,
	0,
	"8da9558e-a27a-477d-9370-b794215790bc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("2c239656-fb5c-4df2-8abf-98cb69d8bb05",
	"e7af8251-f2d7-407f-8059-882cf777ec1e",
	"5c99af16-13fb-44e3-a108-0013dc83864c",
	19,
	3,
	'cell::answer line: 19');
INSERT INTO ACT_SEL
	VALUES ("2c239656-fb5c-4df2-8abf-98cb69d8bb05",
	"4c04f981-155c-4c7d-a820-1d7e419de9d9",
	0,
	'one',
	"fb2cea64-275c-494b-983a-56ae98bb297c");
INSERT INTO ACT_SR
	VALUES ("2c239656-fb5c-4df2-8abf-98cb69d8bb05");
INSERT INTO ACT_LNK
	VALUES ("30f36d3b-5db4-40bd-be16-fbd3f61febe4",
	'',
	"2c239656-fb5c-4df2-8abf-98cb69d8bb05",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	19,
	43,
	19,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5c99af16-13fb-44e3-a108-0013dc83864c",
	"e7af8251-f2d7-407f-8059-882cf777ec1e",
	"059f9042-a7a3-4617-97a5-4efa507f46b5",
	20,
	3,
	'cell::answer line: 20');
INSERT INTO ACT_URU
	VALUES ("5c99af16-13fb-44e3-a108-0013dc83864c",
	"6d324f90-3a55-4452-a918-ee6d621f4536",
	"4c04f981-155c-4c7d-a820-1d7e419de9d9",
	"4eb1f630-51f5-416c-9624-832e209a071e",
	'',
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	20,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("059f9042-a7a3-4617-97a5-4efa507f46b5",
	"e7af8251-f2d7-407f-8059-882cf777ec1e",
	"00000000-0000-0000-0000-000000000000",
	21,
	3,
	'cell::answer line: 21');
INSERT INTO ACT_DEL
	VALUES ("059f9042-a7a3-4617-97a5-4efa507f46b5",
	"4eb1f630-51f5-416c-9624-832e209a071e");
INSERT INTO V_VAL
	VALUES ("fb2cea64-275c-494b-983a-56ae98bb297c",
	0,
	0,
	19,
	31,
	40,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"e7af8251-f2d7-407f-8059-882cf777ec1e");
INSERT INTO V_IRF
	VALUES ("fb2cea64-275c-494b-983a-56ae98bb297c",
	"4eb1f630-51f5-416c-9624-832e209a071e");
INSERT INTO O_TFR
	VALUES ("85d40a8c-8b51-408d-85d3-824453116397",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	'score',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	0,
	'select many cells from instances of CELL 
  where ( selected.answer_value != 0 );
score = cardinality cells;

/*#inline
  printf( "Score is:  %d\n", v234_score );
*/

return score;',
	1,
	'',
	"4dbd3878-9ff1-4fa9-8ff2-db063b3aa997");
INSERT INTO ACT_OPB
	VALUES ("e1d99b90-e8d8-4770-baef-3fc310e27781",
	"85d40a8c-8b51-408d-85d3-824453116397");
INSERT INTO ACT_ACT
	VALUES ("e1d99b90-e8d8-4770-baef-3fc310e27781",
	'class operation',
	0,
	"5d579e22-6286-4c45-83b9-aaf60d95d257",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cell::score',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("5d579e22-6286-4c45-83b9-aaf60d95d257",
	1,
	0,
	1,
	'',
	'',
	'',
	9,
	1,
	1,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"e1d99b90-e8d8-4770-baef-3fc310e27781",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d8634e62-ac49-4075-8ba1-e80577d3e94f",
	"5d579e22-6286-4c45-83b9-aaf60d95d257",
	"ac215271-1995-450a-a99a-5c8e54d9ccad",
	1,
	1,
	'cell::score line: 1');
INSERT INTO ACT_FIW
	VALUES ("d8634e62-ac49-4075-8ba1-e80577d3e94f",
	"2fccae44-3642-45d4-941e-01817beb37bc",
	1,
	'many',
	"45a35739-5c01-46a5-80ec-d74f3df59fcd",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	1,
	37);
INSERT INTO ACT_SMT
	VALUES ("ac215271-1995-450a-a99a-5c8e54d9ccad",
	"5d579e22-6286-4c45-83b9-aaf60d95d257",
	"5b789cf5-6440-4c8e-bbd3-fd54b2580363",
	3,
	1,
	'cell::score line: 3');
INSERT INTO ACT_AI
	VALUES ("ac215271-1995-450a-a99a-5c8e54d9ccad",
	"a3e2f756-a1a1-4132-a49b-bc5fed3b0e3b",
	"16a2e580-bd8c-4606-a03a-1c2d699aa5de",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5b789cf5-6440-4c8e-bbd3-fd54b2580363",
	"5d579e22-6286-4c45-83b9-aaf60d95d257",
	"00000000-0000-0000-0000-000000000000",
	9,
	1,
	'cell::score line: 9');
INSERT INTO ACT_RET
	VALUES ("5b789cf5-6440-4c8e-bbd3-fd54b2580363",
	"7131893f-c4de-44af-abf0-cb12d7195584");
INSERT INTO V_VAL
	VALUES ("f1c65e0a-20ef-4d96-b181-674b43d6c14b",
	0,
	0,
	2,
	11,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"5d579e22-6286-4c45-83b9-aaf60d95d257");
INSERT INTO V_SLR
	VALUES ("f1c65e0a-20ef-4d96-b181-674b43d6c14b",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("625f011b-9213-43aa-a699-2c64a33031a0",
	0,
	0,
	2,
	20,
	31,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5d579e22-6286-4c45-83b9-aaf60d95d257");
INSERT INTO V_AVL
	VALUES ("625f011b-9213-43aa-a699-2c64a33031a0",
	"f1c65e0a-20ef-4d96-b181-674b43d6c14b",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4");
INSERT INTO V_VAL
	VALUES ("45a35739-5c01-46a5-80ec-d74f3df59fcd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"5d579e22-6286-4c45-83b9-aaf60d95d257");
INSERT INTO V_BIN
	VALUES ("45a35739-5c01-46a5-80ec-d74f3df59fcd",
	"f85ff5e5-eac9-4857-938f-07871cbae459",
	"625f011b-9213-43aa-a699-2c64a33031a0",
	'!=');
INSERT INTO V_VAL
	VALUES ("f85ff5e5-eac9-4857-938f-07871cbae459",
	0,
	0,
	2,
	36,
	36,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5d579e22-6286-4c45-83b9-aaf60d95d257");
INSERT INTO V_LIN
	VALUES ("f85ff5e5-eac9-4857-938f-07871cbae459",
	'0');
INSERT INTO V_VAL
	VALUES ("16a2e580-bd8c-4606-a03a-1c2d699aa5de",
	1,
	1,
	3,
	1,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5d579e22-6286-4c45-83b9-aaf60d95d257");
INSERT INTO V_TVL
	VALUES ("16a2e580-bd8c-4606-a03a-1c2d699aa5de",
	"013a6a62-ba2d-40af-aaf7-f565aaf0fbae");
INSERT INTO V_VAL
	VALUES ("39df7f79-96b1-4aa6-9f7d-6d8464f20e7b",
	0,
	0,
	3,
	21,
	25,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"5d579e22-6286-4c45-83b9-aaf60d95d257");
INSERT INTO V_ISR
	VALUES ("39df7f79-96b1-4aa6-9f7d-6d8464f20e7b",
	"2fccae44-3642-45d4-941e-01817beb37bc");
INSERT INTO V_VAL
	VALUES ("a3e2f756-a1a1-4132-a49b-bc5fed3b0e3b",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5d579e22-6286-4c45-83b9-aaf60d95d257");
INSERT INTO V_UNY
	VALUES ("a3e2f756-a1a1-4132-a49b-bc5fed3b0e3b",
	"39df7f79-96b1-4aa6-9f7d-6d8464f20e7b",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("7131893f-c4de-44af-abf0-cb12d7195584",
	0,
	0,
	9,
	8,
	12,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5d579e22-6286-4c45-83b9-aaf60d95d257");
INSERT INTO V_TVL
	VALUES ("7131893f-c4de-44af-abf0-cb12d7195584",
	"013a6a62-ba2d-40af-aaf7-f565aaf0fbae");
INSERT INTO V_VAR
	VALUES ("2fccae44-3642-45d4-941e-01817beb37bc",
	"5d579e22-6286-4c45-83b9-aaf60d95d257",
	'cells',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("2fccae44-3642-45d4-941e-01817beb37bc",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("e9a5578f-bfd3-4ba9-a285-ac809836dcc5",
	1,
	13,
	17,
	"2fccae44-3642-45d4-941e-01817beb37bc");
INSERT INTO V_VAR
	VALUES ("013a6a62-ba2d-40af-aaf7-f565aaf0fbae",
	"5d579e22-6286-4c45-83b9-aaf60d95d257",
	'score',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("013a6a62-ba2d-40af-aaf7-f565aaf0fbae",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("a823fae8-a727-4da3-a1de-f57c0efaddfb",
	3,
	1,
	5,
	"013a6a62-ba2d-40af-aaf7-f565aaf0fbae");
INSERT INTO V_LOC
	VALUES ("0a8caa19-646a-4bcd-98c3-0f934d0b5f7e",
	9,
	8,
	12,
	"013a6a62-ba2d-40af-aaf7-f565aaf0fbae");
INSERT INTO O_REF
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	1,
	"bc6df04d-3498-4476-817a-f3273e8f61f2",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"68c9495f-23d7-4a5a-8785-8d92642880a1",
	"9c3c8405-01a4-40ee-a4da-d38b31e284a9",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26",
	"7745ce3b-e4ca-4f85-83dc-e2ef1a151eeb",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'row',
	'number',
	'R2');
INSERT INTO O_RATTR
	VALUES ("dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"bc6df04d-3498-4476-817a-f3273e8f61f2",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	1,
	'number');
INSERT INTO O_ATTR
	VALUES ("dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"00000000-0000-0000-0000-000000000000",
	'row_number',
	'',
	'row_',
	'number',
	1,
	"1d4138ff-0b11-4c15-ba60-a919d89e9e3d",
	'',
	'');
INSERT INTO O_REF
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	1,
	"f26a153c-9ca1-42f0-b8e3-a33ce851c778",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"81e3eff5-9e2f-4f48-90f5-30937d260be1",
	"c21ace17-cbde-4c47-9f00-e2ec1b3cdef1",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b",
	"78875a1d-eeaa-4cff-ae4c-ea805851458c",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'column',
	'number',
	'R3');
INSERT INTO O_RATTR
	VALUES ("81faeef5-3440-4d38-a08b-a9fc5deea10b",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"f26a153c-9ca1-42f0-b8e3-a33ce851c778",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	1,
	'number');
INSERT INTO O_ATTR
	VALUES ("81faeef5-3440-4d38-a08b-a9fc5deea10b",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26",
	'column_number',
	'',
	'column_',
	'number',
	1,
	"1d4138ff-0b11-4c15-ba60-a919d89e9e3d",
	'',
	'');
INSERT INTO O_REF
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	0,
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"308bc367-f896-4eeb-bf93-8723b4dfaad7",
	"5fbbe4bb-9b74-49bd-91ee-35cd30b10c88",
	"ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4",
	"d854532d-5eeb-4fef-bfd0-76f502228e53",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'digit',
	'value',
	'R9');
INSERT INTO O_RATTR
	VALUES ("ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	1,
	'value');
INSERT INTO O_ATTR
	VALUES ("ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"81faeef5-3440-4d38-a08b-a9fc5deea10b",
	'answer_value',
	'',
	'answer_',
	'value',
	1,
	"1d4138ff-0b11-4c15-ba60-a919d89e9e3d",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("25e5312a-05b0-4e67-9df4-ae33c8f5fc42",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO O_BATTR
	VALUES ("25e5312a-05b0-4e67-9df4-ae33c8f5fc42",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO O_ATTR
	VALUES ("25e5312a-05b0-4e67-9df4-ae33c8f5fc42",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"65468da2-1083-4089-81cf-f2430c0ade46",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO O_OIDA
	VALUES ("dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	0);
INSERT INTO O_OIDA
	VALUES ("81faeef5-3440-4d38-a08b-a9fc5deea10b",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	0);
INSERT INTO O_ID
	VALUES (1,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO O_ID
	VALUES (2,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO SM_ISM
	VALUES ("247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO SM_SM
	VALUES ("247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("247f4e44-7c6c-4bb9-bc5a-59c72749b065");
INSERT INTO SM_EVTDI
	VALUES ("9edf9a91-d602-4eb8-b094-445a98c4e352",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	'digit',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	"24cb641a-7d3f-48df-8f88-b8d07bacdbda",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVTDI
	VALUES ("e5dfe816-1cac-416b-928c-6232294b349a",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	'digit',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	"47502570-e42e-4963-ab1f-e4df543a21cf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_LEVT
	VALUES ("47502570-e42e-4963-ab1f-e4df543a21cf",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("47502570-e42e-4963-ab1f-e4df543a21cf",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("47502570-e42e-4963-ab1f-e4df543a21cf",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000",
	1,
	'eliminate',
	0,
	'',
	'CELL1',
	'');
INSERT INTO SM_LEVT
	VALUES ("24cb641a-7d3f-48df-8f88-b8d07bacdbda",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("24cb641a-7d3f-48df-8f88-b8d07bacdbda",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("24cb641a-7d3f-48df-8f88-b8d07bacdbda",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000",
	2,
	'answer',
	0,
	'',
	'CELL2',
	'');
INSERT INTO SM_STATE
	VALUES ("fc40f9e1-7979-4507-a29b-0666b183dbb0",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000",
	'unsolved',
	1,
	0);
INSERT INTO SM_SEME
	VALUES ("fc40f9e1-7979-4507-a29b-0666b183dbb0",
	"47502570-e42e-4963-ab1f-e4df543a21cf",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("fc40f9e1-7979-4507-a29b-0666b183dbb0",
	"24cb641a-7d3f-48df-8f88-b8d07bacdbda",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("4a30da31-c043-4f1d-b24d-6804abd2ec43",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"fc40f9e1-7979-4507-a29b-0666b183dbb0");
INSERT INTO SM_AH
	VALUES ("4a30da31-c043-4f1d-b24d-6804abd2ec43",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065");
INSERT INTO SM_ACT
	VALUES ("4a30da31-c043-4f1d-b24d-6804abd2ec43",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	1,
	'// It has been determined that the input digit cannot
// be used in this cell.

// Unlink the eliminated digit.
select any ineligible related by self->ELIGIBLE[R8]
  where ( selected.digit_value == rcvd_evt.digit );
if ( not_empty ineligible )
  select one digit related by ineligible->DIGIT[R8];
  unrelate self from digit across R8 using ineligible;
  // delete object instance ineligible;
  // Inform the row, col and box of the change. 
  // CDS:  Consider polymorphic event here.
  select one row related by self->ROW[R2];
  select one sequence related by row->SEQUENCE[R1];
  if ( not sequence.solved )
    sequence.requests = sequence.requests + 1;
    if ( sequence.requests < 2 )
      generate ROW1:update() to row;
    end if;
  end if;
  select one column related by self->COLUMN[R3];
  select one sequence related by column->SEQUENCE[R1];
  if ( not sequence.solved )
    sequence.requests = sequence.requests + 1;
    if ( sequence.requests < 2 )
      generate COLUMN1:update() to column;
    end if;
  end if;
  select one box related by self->BOX[R4];
  select one sequence related by box->SEQUENCE[R1];
  if ( not sequence.solved )
    sequence.requests = sequence.requests + 1;
    if ( sequence.requests < 2 )
      generate BOX1:update() to box;
    end if;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES ("7eb88b41-2247-4d32-848c-214bbe8f16b6",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"4a30da31-c043-4f1d-b24d-6804abd2ec43");
INSERT INTO ACT_ACT
	VALUES ("7eb88b41-2247-4d32-848c-214bbe8f16b6",
	'state',
	0,
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cell::unsolved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("cd25f2b0-afbb-4315-bb1d-f4a12ef45420",
	1,
	0,
	1,
	'',
	'',
	'',
	7,
	1,
	5,
	40,
	0,
	0,
	5,
	49,
	0,
	0,
	0,
	0,
	0,
	"7eb88b41-2247-4d32-848c-214bbe8f16b6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7d5e5a3a-3469-427d-8ec6-8be1951685de",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420",
	"b504817f-0ef4-4518-9362-5121a67d5af6",
	5,
	1,
	'cell::unsolved line: 5');
INSERT INTO ACT_SEL
	VALUES ("7d5e5a3a-3469-427d-8ec6-8be1951685de",
	"3c34cd7b-f58d-4294-8d1d-17cd7e4b681e",
	1,
	'any',
	"d42d9411-5a17-4d05-8f07-88830207d960");
INSERT INTO ACT_SRW
	VALUES ("7d5e5a3a-3469-427d-8ec6-8be1951685de",
	"479c388d-3132-494c-8755-3dc1b1d31195");
INSERT INTO ACT_LNK
	VALUES ("56b9ed75-4bb3-4e80-a208-b70ebf7a3963",
	'',
	"7d5e5a3a-3469-427d-8ec6-8be1951685de",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	5,
	40,
	5,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b504817f-0ef4-4518-9362-5121a67d5af6",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420",
	"00000000-0000-0000-0000-000000000000",
	7,
	1,
	'cell::unsolved line: 7');
INSERT INTO ACT_IF
	VALUES ("b504817f-0ef4-4518-9362-5121a67d5af6",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"76be9e6e-440b-4782-b3ef-593fab43b95d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("d42d9411-5a17-4d05-8f07-88830207d960",
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420");
INSERT INTO V_IRF
	VALUES ("d42d9411-5a17-4d05-8f07-88830207d960",
	"6b6dfe4f-3915-4c33-be0b-00303eaa3de6");
INSERT INTO V_VAL
	VALUES ("5d98f13e-b0df-41ee-a32e-2e176bf042be",
	0,
	0,
	6,
	11,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420");
INSERT INTO V_SLR
	VALUES ("5d98f13e-b0df-41ee-a32e-2e176bf042be",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("a9046195-e6d3-49be-a68d-105929e3bbb5",
	0,
	0,
	6,
	20,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420");
INSERT INTO V_AVL
	VALUES ("a9046195-e6d3-49be-a68d-105929e3bbb5",
	"5d98f13e-b0df-41ee-a32e-2e176bf042be",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("479c388d-3132-494c-8755-3dc1b1d31195",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420");
INSERT INTO V_BIN
	VALUES ("479c388d-3132-494c-8755-3dc1b1d31195",
	"3956b823-1c1c-45e0-b2f8-970485683aa4",
	"a9046195-e6d3-49be-a68d-105929e3bbb5",
	'==');
INSERT INTO V_VAL
	VALUES ("3956b823-1c1c-45e0-b2f8-970485683aa4",
	0,
	0,
	6,
	44,
	48,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420");
INSERT INTO V_EDV
	VALUES ("3956b823-1c1c-45e0-b2f8-970485683aa4");
INSERT INTO V_EPR
	VALUES ("3956b823-1c1c-45e0-b2f8-970485683aa4",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"e5dfe816-1cac-416b-928c-6232294b349a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("f2610b37-3ba8-4035-8f83-bc2b163e22a6",
	0,
	0,
	7,
	16,
	25,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420");
INSERT INTO V_IRF
	VALUES ("f2610b37-3ba8-4035-8f83-bc2b163e22a6",
	"3c34cd7b-f58d-4294-8d1d-17cd7e4b681e");
INSERT INTO V_VAL
	VALUES ("76be9e6e-440b-4782-b3ef-593fab43b95d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420");
INSERT INTO V_UNY
	VALUES ("76be9e6e-440b-4782-b3ef-593fab43b95d",
	"f2610b37-3ba8-4035-8f83-bc2b163e22a6",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("3c34cd7b-f58d-4294-8d1d-17cd7e4b681e",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420",
	'ineligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("3c34cd7b-f58d-4294-8d1d-17cd7e4b681e",
	0,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("9c766128-93df-4855-933e-4c2af1e5682d",
	5,
	12,
	21,
	"3c34cd7b-f58d-4294-8d1d-17cd7e4b681e");
INSERT INTO V_LOC
	VALUES ("34a2bbac-91ac-4a3b-a2c0-7a2a6125927f",
	9,
	44,
	53,
	"3c34cd7b-f58d-4294-8d1d-17cd7e4b681e");
INSERT INTO V_VAR
	VALUES ("6b6dfe4f-3915-4c33-be0b-00303eaa3de6",
	"cd25f2b0-afbb-4315-bb1d-f4a12ef45420",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("6b6dfe4f-3915-4c33-be0b-00303eaa3de6",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("68e43e89-7919-4b25-8522-a916999c3e6d",
	9,
	12,
	15,
	"6b6dfe4f-3915-4c33-be0b-00303eaa3de6");
INSERT INTO ACT_BLK
	VALUES ("c7396f13-c350-4291-9539-1e5c099075d7",
	1,
	0,
	0,
	'',
	'',
	'',
	31,
	3,
	30,
	39,
	0,
	0,
	30,
	48,
	0,
	0,
	0,
	0,
	0,
	"7eb88b41-2247-4d32-848c-214bbe8f16b6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("51ed4e40-7f08-4b68-ac0e-a1340293dcb8",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"87edd95f-924d-4357-a002-e7d6e9a7b30a",
	8,
	3,
	'cell::unsolved line: 8');
INSERT INTO ACT_SEL
	VALUES ("51ed4e40-7f08-4b68-ac0e-a1340293dcb8",
	"1cd69d8c-8ad1-43ca-a660-ed243d963cf2",
	1,
	'one',
	"d0df181c-5ad0-4eda-863b-3cf37c1098f2");
INSERT INTO ACT_SR
	VALUES ("51ed4e40-7f08-4b68-ac0e-a1340293dcb8");
INSERT INTO ACT_LNK
	VALUES ("a2b5534e-9cdd-4f7d-8a44-3f7294c4c332",
	'',
	"51ed4e40-7f08-4b68-ac0e-a1340293dcb8",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	8,
	43,
	8,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("87edd95f-924d-4357-a002-e7d6e9a7b30a",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"2aa7fd62-a599-41d9-889c-dcc3f73b6862",
	9,
	3,
	'cell::unsolved line: 9');
INSERT INTO ACT_URU
	VALUES ("87edd95f-924d-4357-a002-e7d6e9a7b30a",
	"6b6dfe4f-3915-4c33-be0b-00303eaa3de6",
	"1cd69d8c-8ad1-43ca-a660-ed243d963cf2",
	"3c34cd7b-f58d-4294-8d1d-17cd7e4b681e",
	'',
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	9,
	35,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("2aa7fd62-a599-41d9-889c-dcc3f73b6862",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"6b7a33c2-0e20-4e19-aa04-ae274930b419",
	13,
	3,
	'cell::unsolved line: 13');
INSERT INTO ACT_SEL
	VALUES ("2aa7fd62-a599-41d9-889c-dcc3f73b6862",
	"e2930fc8-b52c-41e3-997b-fd0113282cef",
	1,
	'one',
	"dea8406b-c9f4-434c-adb8-bb0ae8a822c1");
INSERT INTO ACT_SR
	VALUES ("2aa7fd62-a599-41d9-889c-dcc3f73b6862");
INSERT INTO ACT_LNK
	VALUES ("414bb3c3-df8d-4953-b960-f8b157d7045f",
	'',
	"2aa7fd62-a599-41d9-889c-dcc3f73b6862",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"00000000-0000-0000-0000-000000000000",
	2,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	13,
	35,
	13,
	39,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("6b7a33c2-0e20-4e19-aa04-ae274930b419",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"10bb787e-1f62-4a64-b222-435a19f9135a",
	14,
	3,
	'cell::unsolved line: 14');
INSERT INTO ACT_SEL
	VALUES ("6b7a33c2-0e20-4e19-aa04-ae274930b419",
	"0d023d13-9330-4858-969f-0617739ddf59",
	1,
	'one',
	"f4ed0785-72a6-4e40-a26a-77df694fbfd3");
INSERT INTO ACT_SR
	VALUES ("6b7a33c2-0e20-4e19-aa04-ae274930b419");
INSERT INTO ACT_LNK
	VALUES ("e4f0d52c-8822-455e-8e67-61a4130e81af",
	'',
	"6b7a33c2-0e20-4e19-aa04-ae274930b419",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	14,
	39,
	14,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("10bb787e-1f62-4a64-b222-435a19f9135a",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"59e99760-b904-450b-b12b-e845f9dd779a",
	15,
	3,
	'cell::unsolved line: 15');
INSERT INTO ACT_IF
	VALUES ("10bb787e-1f62-4a64-b222-435a19f9135a",
	"53e79f68-0133-4895-8a1c-b1a9837f9887",
	"d9ec51b3-605d-4804-bd90-c4672e204254",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("59e99760-b904-450b-b12b-e845f9dd779a",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"10752387-65ba-428f-a95c-b8c7f7b3d080",
	21,
	3,
	'cell::unsolved line: 21');
INSERT INTO ACT_SEL
	VALUES ("59e99760-b904-450b-b12b-e845f9dd779a",
	"6ef2e8a5-9a88-4e4a-a6f1-4ac8ce2792d9",
	1,
	'one',
	"d0950389-2295-4ad1-aa5a-49ece753f962");
INSERT INTO ACT_SR
	VALUES ("59e99760-b904-450b-b12b-e845f9dd779a");
INSERT INTO ACT_LNK
	VALUES ("86b4347d-bc11-4c8c-8208-1b0ecac02d2d",
	'',
	"59e99760-b904-450b-b12b-e845f9dd779a",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"00000000-0000-0000-0000-000000000000",
	2,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	21,
	38,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("10752387-65ba-428f-a95c-b8c7f7b3d080",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"7f16dbea-e74e-4915-91e9-068a69f73197",
	22,
	3,
	'cell::unsolved line: 22');
INSERT INTO ACT_SEL
	VALUES ("10752387-65ba-428f-a95c-b8c7f7b3d080",
	"0d023d13-9330-4858-969f-0617739ddf59",
	0,
	'one',
	"83029e0f-19de-401b-9aa4-5ea57150840b");
INSERT INTO ACT_SR
	VALUES ("10752387-65ba-428f-a95c-b8c7f7b3d080");
INSERT INTO ACT_LNK
	VALUES ("2e7d090c-b6f9-40a9-a5ef-fddec5019d33",
	'',
	"10752387-65ba-428f-a95c-b8c7f7b3d080",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	22,
	42,
	22,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7f16dbea-e74e-4915-91e9-068a69f73197",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"448fd26b-ba69-4939-8064-18c370cf0bc9",
	23,
	3,
	'cell::unsolved line: 23');
INSERT INTO ACT_IF
	VALUES ("7f16dbea-e74e-4915-91e9-068a69f73197",
	"de9de57e-4964-46e2-96ae-f7106158ac1e",
	"6912f2ee-ca10-4951-acf8-12b639341fa3",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("448fd26b-ba69-4939-8064-18c370cf0bc9",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"b2c8c45a-b97e-456b-b955-afec76c3b5b0",
	29,
	3,
	'cell::unsolved line: 29');
INSERT INTO ACT_SEL
	VALUES ("448fd26b-ba69-4939-8064-18c370cf0bc9",
	"8bee351f-989d-4219-b50b-ad158edc7074",
	1,
	'one',
	"c7d1da51-8bc2-4a3d-966e-00f5da925b66");
INSERT INTO ACT_SR
	VALUES ("448fd26b-ba69-4939-8064-18c370cf0bc9");
INSERT INTO ACT_LNK
	VALUES ("96425aad-1f79-4fd6-8c7f-53c141920d7e",
	'',
	"448fd26b-ba69-4939-8064-18c370cf0bc9",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"00000000-0000-0000-0000-000000000000",
	2,
	"0aa0576e-b480-43da-8919-6b6e88544902",
	29,
	35,
	29,
	39,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b2c8c45a-b97e-456b-b955-afec76c3b5b0",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"02c612db-9b69-411e-baca-e08284c4a879",
	30,
	3,
	'cell::unsolved line: 30');
INSERT INTO ACT_SEL
	VALUES ("b2c8c45a-b97e-456b-b955-afec76c3b5b0",
	"0d023d13-9330-4858-969f-0617739ddf59",
	0,
	'one',
	"9fbbd5ba-b547-46dd-bea1-457900fde45c");
INSERT INTO ACT_SR
	VALUES ("b2c8c45a-b97e-456b-b955-afec76c3b5b0");
INSERT INTO ACT_LNK
	VALUES ("cf1b5ead-7e54-466e-b201-7040242b14ed",
	'',
	"b2c8c45a-b97e-456b-b955-afec76c3b5b0",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	30,
	39,
	30,
	48,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("02c612db-9b69-411e-baca-e08284c4a879",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	"00000000-0000-0000-0000-000000000000",
	31,
	3,
	'cell::unsolved line: 31');
INSERT INTO ACT_IF
	VALUES ("02c612db-9b69-411e-baca-e08284c4a879",
	"ad68f2df-5366-4658-892f-c5354e08c7f3",
	"70aefbf5-4810-4efd-8d6e-048250ca7758",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("d0df181c-5ad0-4eda-863b-3cf37c1098f2",
	0,
	0,
	8,
	31,
	40,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_IRF
	VALUES ("d0df181c-5ad0-4eda-863b-3cf37c1098f2",
	"3c34cd7b-f58d-4294-8d1d-17cd7e4b681e");
INSERT INTO V_VAL
	VALUES ("dea8406b-c9f4-434c-adb8-bb0ae8a822c1",
	0,
	0,
	13,
	29,
	32,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_IRF
	VALUES ("dea8406b-c9f4-434c-adb8-bb0ae8a822c1",
	"6b6dfe4f-3915-4c33-be0b-00303eaa3de6");
INSERT INTO V_VAL
	VALUES ("f4ed0785-72a6-4e40-a26a-77df694fbfd3",
	0,
	0,
	14,
	34,
	36,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_IRF
	VALUES ("f4ed0785-72a6-4e40-a26a-77df694fbfd3",
	"e2930fc8-b52c-41e3-997b-fd0113282cef");
INSERT INTO V_VAL
	VALUES ("c3f525ca-c653-49f4-a620-ce78231a46d3",
	0,
	0,
	15,
	12,
	19,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_IRF
	VALUES ("c3f525ca-c653-49f4-a620-ce78231a46d3",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("fe6432a8-d617-4f91-be34-96dd58e18e3a",
	0,
	0,
	15,
	21,
	26,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_AVL
	VALUES ("fe6432a8-d617-4f91-be34-96dd58e18e3a",
	"c3f525ca-c653-49f4-a620-ce78231a46d3",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"52c42da4-a4c5-4627-bb84-a09549090418");
INSERT INTO V_VAL
	VALUES ("d9ec51b3-605d-4804-bd90-c4672e204254",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_UNY
	VALUES ("d9ec51b3-605d-4804-bd90-c4672e204254",
	"fe6432a8-d617-4f91-be34-96dd58e18e3a",
	'not');
INSERT INTO V_VAL
	VALUES ("d0950389-2295-4ad1-aa5a-49ece753f962",
	0,
	0,
	21,
	32,
	35,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_IRF
	VALUES ("d0950389-2295-4ad1-aa5a-49ece753f962",
	"6b6dfe4f-3915-4c33-be0b-00303eaa3de6");
INSERT INTO V_VAL
	VALUES ("83029e0f-19de-401b-9aa4-5ea57150840b",
	0,
	0,
	22,
	34,
	39,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_IRF
	VALUES ("83029e0f-19de-401b-9aa4-5ea57150840b",
	"6ef2e8a5-9a88-4e4a-a6f1-4ac8ce2792d9");
INSERT INTO V_VAL
	VALUES ("633461ae-c620-4100-911d-3259ab7cacbc",
	0,
	0,
	23,
	12,
	19,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_IRF
	VALUES ("633461ae-c620-4100-911d-3259ab7cacbc",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("f76aaeee-2469-4c26-8d4f-cc9526dcc133",
	0,
	0,
	23,
	21,
	26,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_AVL
	VALUES ("f76aaeee-2469-4c26-8d4f-cc9526dcc133",
	"633461ae-c620-4100-911d-3259ab7cacbc",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"52c42da4-a4c5-4627-bb84-a09549090418");
INSERT INTO V_VAL
	VALUES ("6912f2ee-ca10-4951-acf8-12b639341fa3",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_UNY
	VALUES ("6912f2ee-ca10-4951-acf8-12b639341fa3",
	"f76aaeee-2469-4c26-8d4f-cc9526dcc133",
	'not');
INSERT INTO V_VAL
	VALUES ("c7d1da51-8bc2-4a3d-966e-00f5da925b66",
	0,
	0,
	29,
	29,
	32,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_IRF
	VALUES ("c7d1da51-8bc2-4a3d-966e-00f5da925b66",
	"6b6dfe4f-3915-4c33-be0b-00303eaa3de6");
INSERT INTO V_VAL
	VALUES ("9fbbd5ba-b547-46dd-bea1-457900fde45c",
	0,
	0,
	30,
	34,
	36,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_IRF
	VALUES ("9fbbd5ba-b547-46dd-bea1-457900fde45c",
	"8bee351f-989d-4219-b50b-ad158edc7074");
INSERT INTO V_VAL
	VALUES ("dbf4bb7e-4e3d-4cc4-8a05-c51de5f537b6",
	0,
	0,
	31,
	12,
	19,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_IRF
	VALUES ("dbf4bb7e-4e3d-4cc4-8a05-c51de5f537b6",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("65086ca1-7fb7-410e-8e72-8466babe8d95",
	0,
	0,
	31,
	21,
	26,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_AVL
	VALUES ("65086ca1-7fb7-410e-8e72-8466babe8d95",
	"dbf4bb7e-4e3d-4cc4-8a05-c51de5f537b6",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"52c42da4-a4c5-4627-bb84-a09549090418");
INSERT INTO V_VAL
	VALUES ("70aefbf5-4810-4efd-8d6e-048250ca7758",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c7396f13-c350-4291-9539-1e5c099075d7");
INSERT INTO V_UNY
	VALUES ("70aefbf5-4810-4efd-8d6e-048250ca7758",
	"65086ca1-7fb7-410e-8e72-8466babe8d95",
	'not');
INSERT INTO V_VAR
	VALUES ("1cd69d8c-8ad1-43ca-a660-ed243d963cf2",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	'digit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("1cd69d8c-8ad1-43ca-a660-ed243d963cf2",
	0,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("e24f884e-b7c2-499b-a643-4b32319e7a5a",
	8,
	14,
	18,
	"1cd69d8c-8ad1-43ca-a660-ed243d963cf2");
INSERT INTO V_LOC
	VALUES ("6e5a4b72-8b28-45ae-8fac-5528ef271a21",
	9,
	22,
	26,
	"1cd69d8c-8ad1-43ca-a660-ed243d963cf2");
INSERT INTO V_VAR
	VALUES ("e2930fc8-b52c-41e3-997b-fd0113282cef",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	'row',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("e2930fc8-b52c-41e3-997b-fd0113282cef",
	0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("66862193-16c7-4d39-b7c9-bc30733c2a2d",
	13,
	14,
	16,
	"e2930fc8-b52c-41e3-997b-fd0113282cef");
INSERT INTO V_LOC
	VALUES ("ca7872d1-53bf-4abc-ac18-20d294875d8d",
	18,
	33,
	35,
	"e2930fc8-b52c-41e3-997b-fd0113282cef");
INSERT INTO V_VAR
	VALUES ("0d023d13-9330-4858-969f-0617739ddf59",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("0d023d13-9330-4858-969f-0617739ddf59",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("45b445eb-a457-469f-b75a-019d87c19f3a",
	14,
	14,
	21,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("114c7b7b-ea63-4497-89ed-659e676d39ea",
	15,
	12,
	19,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("85451cd7-1fb8-41c3-ad4b-e60a5dd5b009",
	16,
	5,
	12,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("567bd445-5f5f-4e7c-88c6-162cef8fbe64",
	16,
	25,
	32,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("3f322908-b345-4fe1-bfa9-06e1334b9d3a",
	17,
	10,
	17,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("407d5121-ea72-4259-9291-630b9048aece",
	22,
	14,
	21,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("a0f3afb2-4635-4799-95fd-5e69734d64b3",
	23,
	12,
	19,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("06a65b02-2179-4d56-a2ea-7d4121182e2e",
	24,
	5,
	12,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("7d7b8081-3e9f-430c-af65-781708ef2273",
	24,
	25,
	32,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("e975a21d-5219-4a92-b5f8-57a68fb6848e",
	25,
	10,
	17,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("dc149f17-09cd-4911-a018-28129828c842",
	30,
	14,
	21,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("6802df56-634a-4d7a-8fe7-273483cfda7d",
	31,
	12,
	19,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("6cb9ab7e-04aa-4830-aaa0-be25a7aeb094",
	32,
	5,
	12,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("c7451b86-9a7f-4337-a2fb-9437a45e5dfd",
	32,
	25,
	32,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_LOC
	VALUES ("0c64940e-1e48-4011-884b-059d85798a56",
	33,
	10,
	17,
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAR
	VALUES ("6ef2e8a5-9a88-4e4a-a6f1-4ac8ce2792d9",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	'column',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("6ef2e8a5-9a88-4e4a-a6f1-4ac8ce2792d9",
	0,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_LOC
	VALUES ("8d153666-68f9-42d7-8b09-79d554db4fcc",
	21,
	14,
	19,
	"6ef2e8a5-9a88-4e4a-a6f1-4ac8ce2792d9");
INSERT INTO V_LOC
	VALUES ("361d4ae7-169b-4f8f-9106-e1ca7a6a1e3c",
	26,
	36,
	41,
	"6ef2e8a5-9a88-4e4a-a6f1-4ac8ce2792d9");
INSERT INTO V_VAR
	VALUES ("8bee351f-989d-4219-b50b-ad158edc7074",
	"c7396f13-c350-4291-9539-1e5c099075d7",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("8bee351f-989d-4219-b50b-ad158edc7074",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("291898e5-8ba7-4c3d-8da0-c53f5c6a8874",
	29,
	14,
	16,
	"8bee351f-989d-4219-b50b-ad158edc7074");
INSERT INTO V_LOC
	VALUES ("4cb13455-4597-4ffb-89dd-51e25efbedf2",
	34,
	33,
	35,
	"8bee351f-989d-4219-b50b-ad158edc7074");
INSERT INTO ACT_BLK
	VALUES ("53e79f68-0133-4895-8a1c-b1a9837f9887",
	0,
	0,
	0,
	'',
	'',
	'',
	17,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7eb88b41-2247-4d32-848c-214bbe8f16b6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b65b6edb-fad3-40ab-8a32-0ac2809e983e",
	"53e79f68-0133-4895-8a1c-b1a9837f9887",
	"04f2fdca-e1ce-4067-9fbe-cbed632cccd5",
	16,
	5,
	'cell::unsolved line: 16');
INSERT INTO ACT_AI
	VALUES ("b65b6edb-fad3-40ab-8a32-0ac2809e983e",
	"6f68d1e2-5196-41dc-bd71-66cf3d65f8fa",
	"415586a1-ef9c-47e0-bc24-efb150e52572",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("04f2fdca-e1ce-4067-9fbe-cbed632cccd5",
	"53e79f68-0133-4895-8a1c-b1a9837f9887",
	"00000000-0000-0000-0000-000000000000",
	17,
	5,
	'cell::unsolved line: 17');
INSERT INTO ACT_IF
	VALUES ("04f2fdca-e1ce-4067-9fbe-cbed632cccd5",
	"7978c66a-7db1-404d-b2c8-71eb010817db",
	"1cb72b4e-fe8f-47ca-9c31-80a6f648a0f9",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("764af883-efdc-4c09-9581-f036ea749fbe",
	1,
	0,
	16,
	5,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"53e79f68-0133-4895-8a1c-b1a9837f9887");
INSERT INTO V_IRF
	VALUES ("764af883-efdc-4c09-9581-f036ea749fbe",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("415586a1-ef9c-47e0-bc24-efb150e52572",
	1,
	0,
	16,
	14,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"53e79f68-0133-4895-8a1c-b1a9837f9887");
INSERT INTO V_AVL
	VALUES ("415586a1-ef9c-47e0-bc24-efb150e52572",
	"764af883-efdc-4c09-9581-f036ea749fbe",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("6d7730f8-79e2-45f7-958e-7601117f89ee",
	0,
	0,
	16,
	25,
	32,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"53e79f68-0133-4895-8a1c-b1a9837f9887");
INSERT INTO V_IRF
	VALUES ("6d7730f8-79e2-45f7-958e-7601117f89ee",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("9fded308-1967-4edb-b912-daea4897191b",
	0,
	0,
	16,
	34,
	41,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"53e79f68-0133-4895-8a1c-b1a9837f9887");
INSERT INTO V_AVL
	VALUES ("9fded308-1967-4edb-b912-daea4897191b",
	"6d7730f8-79e2-45f7-958e-7601117f89ee",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("6f68d1e2-5196-41dc-bd71-66cf3d65f8fa",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"53e79f68-0133-4895-8a1c-b1a9837f9887");
INSERT INTO V_BIN
	VALUES ("6f68d1e2-5196-41dc-bd71-66cf3d65f8fa",
	"8dc602ac-5533-4b8a-a84b-e10e056404e4",
	"9fded308-1967-4edb-b912-daea4897191b",
	'+');
INSERT INTO V_VAL
	VALUES ("8dc602ac-5533-4b8a-a84b-e10e056404e4",
	0,
	0,
	16,
	45,
	45,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"53e79f68-0133-4895-8a1c-b1a9837f9887");
INSERT INTO V_LIN
	VALUES ("8dc602ac-5533-4b8a-a84b-e10e056404e4",
	'1');
INSERT INTO V_VAL
	VALUES ("f2478d7c-ba1e-4acc-ab69-0dc59ba26b88",
	0,
	0,
	17,
	10,
	17,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"53e79f68-0133-4895-8a1c-b1a9837f9887");
INSERT INTO V_IRF
	VALUES ("f2478d7c-ba1e-4acc-ab69-0dc59ba26b88",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("7f49b7b0-4fac-4277-98cd-57b7f7a0d6aa",
	0,
	0,
	17,
	19,
	26,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"53e79f68-0133-4895-8a1c-b1a9837f9887");
INSERT INTO V_AVL
	VALUES ("7f49b7b0-4fac-4277-98cd-57b7f7a0d6aa",
	"f2478d7c-ba1e-4acc-ab69-0dc59ba26b88",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("1cb72b4e-fe8f-47ca-9c31-80a6f648a0f9",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"53e79f68-0133-4895-8a1c-b1a9837f9887");
INSERT INTO V_BIN
	VALUES ("1cb72b4e-fe8f-47ca-9c31-80a6f648a0f9",
	"a64de790-df78-4791-b282-31a9b4f349e4",
	"7f49b7b0-4fac-4277-98cd-57b7f7a0d6aa",
	'<');
INSERT INTO V_VAL
	VALUES ("a64de790-df78-4791-b282-31a9b4f349e4",
	0,
	0,
	17,
	30,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"53e79f68-0133-4895-8a1c-b1a9837f9887");
INSERT INTO V_LIN
	VALUES ("a64de790-df78-4791-b282-31a9b4f349e4",
	'2');
INSERT INTO ACT_BLK
	VALUES ("7978c66a-7db1-404d-b2c8-71eb010817db",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	18,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7eb88b41-2247-4d32-848c-214bbe8f16b6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("de11f76b-df09-4942-aa03-2c51c2a5ee0d",
	"7978c66a-7db1-404d-b2c8-71eb010817db",
	"00000000-0000-0000-0000-000000000000",
	18,
	7,
	'cell::unsolved line: 18');
INSERT INTO E_ESS
	VALUES ("de11f76b-df09-4942-aa03-2c51c2a5ee0d",
	1,
	0,
	18,
	16,
	18,
	21,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("de11f76b-df09-4942-aa03-2c51c2a5ee0d");
INSERT INTO E_GSME
	VALUES ("de11f76b-df09-4942-aa03-2c51c2a5ee0d",
	"565ead81-20dd-40d5-a168-fbed8112e7aa",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16");
INSERT INTO E_GEN
	VALUES ("de11f76b-df09-4942-aa03-2c51c2a5ee0d",
	"e2930fc8-b52c-41e3-997b-fd0113282cef");
INSERT INTO ACT_BLK
	VALUES ("de9de57e-4964-46e2-96ae-f7106158ac1e",
	0,
	0,
	0,
	'',
	'',
	'',
	25,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7eb88b41-2247-4d32-848c-214bbe8f16b6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b3e41a9e-499f-460e-b049-1046184e6a70",
	"de9de57e-4964-46e2-96ae-f7106158ac1e",
	"9757b68a-a9aa-47fe-914c-4db574160ce7",
	24,
	5,
	'cell::unsolved line: 24');
INSERT INTO ACT_AI
	VALUES ("b3e41a9e-499f-460e-b049-1046184e6a70",
	"a4129103-6251-44d8-84b6-a9173467e34e",
	"82200048-4066-4716-bdf0-9eeee8ed029a",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9757b68a-a9aa-47fe-914c-4db574160ce7",
	"de9de57e-4964-46e2-96ae-f7106158ac1e",
	"00000000-0000-0000-0000-000000000000",
	25,
	5,
	'cell::unsolved line: 25');
INSERT INTO ACT_IF
	VALUES ("9757b68a-a9aa-47fe-914c-4db574160ce7",
	"b6e41f4d-9956-4e2b-a7b5-f6d7e670fb33",
	"68b4da44-3d52-4cc2-bcb3-eb29fda63ee7",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("383f61f7-ed8c-4fbd-adf5-e1376b7d73d8",
	1,
	0,
	24,
	5,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"de9de57e-4964-46e2-96ae-f7106158ac1e");
INSERT INTO V_IRF
	VALUES ("383f61f7-ed8c-4fbd-adf5-e1376b7d73d8",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("82200048-4066-4716-bdf0-9eeee8ed029a",
	1,
	0,
	24,
	14,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"de9de57e-4964-46e2-96ae-f7106158ac1e");
INSERT INTO V_AVL
	VALUES ("82200048-4066-4716-bdf0-9eeee8ed029a",
	"383f61f7-ed8c-4fbd-adf5-e1376b7d73d8",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("6a7dd4ea-c3f7-415b-97d7-5a800594ec27",
	0,
	0,
	24,
	25,
	32,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"de9de57e-4964-46e2-96ae-f7106158ac1e");
INSERT INTO V_IRF
	VALUES ("6a7dd4ea-c3f7-415b-97d7-5a800594ec27",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("044f638c-32e4-4a50-a78c-dd1f308080b7",
	0,
	0,
	24,
	34,
	41,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"de9de57e-4964-46e2-96ae-f7106158ac1e");
INSERT INTO V_AVL
	VALUES ("044f638c-32e4-4a50-a78c-dd1f308080b7",
	"6a7dd4ea-c3f7-415b-97d7-5a800594ec27",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("a4129103-6251-44d8-84b6-a9173467e34e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"de9de57e-4964-46e2-96ae-f7106158ac1e");
INSERT INTO V_BIN
	VALUES ("a4129103-6251-44d8-84b6-a9173467e34e",
	"29796965-5d9e-4b11-9ecc-1409d2a28ceb",
	"044f638c-32e4-4a50-a78c-dd1f308080b7",
	'+');
INSERT INTO V_VAL
	VALUES ("29796965-5d9e-4b11-9ecc-1409d2a28ceb",
	0,
	0,
	24,
	45,
	45,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"de9de57e-4964-46e2-96ae-f7106158ac1e");
INSERT INTO V_LIN
	VALUES ("29796965-5d9e-4b11-9ecc-1409d2a28ceb",
	'1');
INSERT INTO V_VAL
	VALUES ("3ba46758-3e7e-4c9a-9851-d4622d092335",
	0,
	0,
	25,
	10,
	17,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"de9de57e-4964-46e2-96ae-f7106158ac1e");
INSERT INTO V_IRF
	VALUES ("3ba46758-3e7e-4c9a-9851-d4622d092335",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("63ad8c13-7715-4cb4-80c8-892099921142",
	0,
	0,
	25,
	19,
	26,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"de9de57e-4964-46e2-96ae-f7106158ac1e");
INSERT INTO V_AVL
	VALUES ("63ad8c13-7715-4cb4-80c8-892099921142",
	"3ba46758-3e7e-4c9a-9851-d4622d092335",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("68b4da44-3d52-4cc2-bcb3-eb29fda63ee7",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"de9de57e-4964-46e2-96ae-f7106158ac1e");
INSERT INTO V_BIN
	VALUES ("68b4da44-3d52-4cc2-bcb3-eb29fda63ee7",
	"0ee47784-4cc4-4049-97e5-5ef1bb19f5fe",
	"63ad8c13-7715-4cb4-80c8-892099921142",
	'<');
INSERT INTO V_VAL
	VALUES ("0ee47784-4cc4-4049-97e5-5ef1bb19f5fe",
	0,
	0,
	25,
	30,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"de9de57e-4964-46e2-96ae-f7106158ac1e");
INSERT INTO V_LIN
	VALUES ("0ee47784-4cc4-4049-97e5-5ef1bb19f5fe",
	'2');
INSERT INTO ACT_BLK
	VALUES ("b6e41f4d-9956-4e2b-a7b5-f6d7e670fb33",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	26,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7eb88b41-2247-4d32-848c-214bbe8f16b6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("58c8b6ca-4a0b-484c-bce7-142dd6e071c9",
	"b6e41f4d-9956-4e2b-a7b5-f6d7e670fb33",
	"00000000-0000-0000-0000-000000000000",
	26,
	7,
	'cell::unsolved line: 26');
INSERT INTO E_ESS
	VALUES ("58c8b6ca-4a0b-484c-bce7-142dd6e071c9",
	1,
	0,
	26,
	16,
	26,
	24,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("58c8b6ca-4a0b-484c-bce7-142dd6e071c9");
INSERT INTO E_GSME
	VALUES ("58c8b6ca-4a0b-484c-bce7-142dd6e071c9",
	"5fd7dc66-b6f4-42c9-b56e-583a604d532b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019");
INSERT INTO E_GEN
	VALUES ("58c8b6ca-4a0b-484c-bce7-142dd6e071c9",
	"6ef2e8a5-9a88-4e4a-a6f1-4ac8ce2792d9");
INSERT INTO ACT_BLK
	VALUES ("ad68f2df-5366-4658-892f-c5354e08c7f3",
	0,
	0,
	0,
	'',
	'',
	'',
	33,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7eb88b41-2247-4d32-848c-214bbe8f16b6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9b34bef1-bb3d-4704-9e41-51ae53fa82ec",
	"ad68f2df-5366-4658-892f-c5354e08c7f3",
	"bdc4548d-c595-4435-94e9-f7a8336ed948",
	32,
	5,
	'cell::unsolved line: 32');
INSERT INTO ACT_AI
	VALUES ("9b34bef1-bb3d-4704-9e41-51ae53fa82ec",
	"0d369b3a-8430-402a-a5a9-49fe6b4e7073",
	"ebc85aad-be2f-4cc0-9ae1-c56bf38d4d27",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("bdc4548d-c595-4435-94e9-f7a8336ed948",
	"ad68f2df-5366-4658-892f-c5354e08c7f3",
	"00000000-0000-0000-0000-000000000000",
	33,
	5,
	'cell::unsolved line: 33');
INSERT INTO ACT_IF
	VALUES ("bdc4548d-c595-4435-94e9-f7a8336ed948",
	"21fdbf87-89be-4d91-a392-ba6baa4390f4",
	"8bd34dc1-d174-431f-bedc-9ca07ede78f5",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("17e9091a-e695-483d-b88e-429de11ec853",
	1,
	0,
	32,
	5,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"ad68f2df-5366-4658-892f-c5354e08c7f3");
INSERT INTO V_IRF
	VALUES ("17e9091a-e695-483d-b88e-429de11ec853",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("ebc85aad-be2f-4cc0-9ae1-c56bf38d4d27",
	1,
	0,
	32,
	14,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ad68f2df-5366-4658-892f-c5354e08c7f3");
INSERT INTO V_AVL
	VALUES ("ebc85aad-be2f-4cc0-9ae1-c56bf38d4d27",
	"17e9091a-e695-483d-b88e-429de11ec853",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("0558b07d-7784-4f53-b2a2-c6cc1831670f",
	0,
	0,
	32,
	25,
	32,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"ad68f2df-5366-4658-892f-c5354e08c7f3");
INSERT INTO V_IRF
	VALUES ("0558b07d-7784-4f53-b2a2-c6cc1831670f",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("dfee90eb-ecac-4687-8f56-be35d8776354",
	0,
	0,
	32,
	34,
	41,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ad68f2df-5366-4658-892f-c5354e08c7f3");
INSERT INTO V_AVL
	VALUES ("dfee90eb-ecac-4687-8f56-be35d8776354",
	"0558b07d-7784-4f53-b2a2-c6cc1831670f",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("0d369b3a-8430-402a-a5a9-49fe6b4e7073",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ad68f2df-5366-4658-892f-c5354e08c7f3");
INSERT INTO V_BIN
	VALUES ("0d369b3a-8430-402a-a5a9-49fe6b4e7073",
	"995f5463-2b04-4cfb-a1d1-b5ebbe2247db",
	"dfee90eb-ecac-4687-8f56-be35d8776354",
	'+');
INSERT INTO V_VAL
	VALUES ("995f5463-2b04-4cfb-a1d1-b5ebbe2247db",
	0,
	0,
	32,
	45,
	45,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ad68f2df-5366-4658-892f-c5354e08c7f3");
INSERT INTO V_LIN
	VALUES ("995f5463-2b04-4cfb-a1d1-b5ebbe2247db",
	'1');
INSERT INTO V_VAL
	VALUES ("802583ba-4633-4b80-923d-85d333d476c3",
	0,
	0,
	33,
	10,
	17,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"ad68f2df-5366-4658-892f-c5354e08c7f3");
INSERT INTO V_IRF
	VALUES ("802583ba-4633-4b80-923d-85d333d476c3",
	"0d023d13-9330-4858-969f-0617739ddf59");
INSERT INTO V_VAL
	VALUES ("ab424dab-0e51-40d3-8b83-ff281a3298c6",
	0,
	0,
	33,
	19,
	26,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ad68f2df-5366-4658-892f-c5354e08c7f3");
INSERT INTO V_AVL
	VALUES ("ab424dab-0e51-40d3-8b83-ff281a3298c6",
	"802583ba-4633-4b80-923d-85d333d476c3",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("8bd34dc1-d174-431f-bedc-9ca07ede78f5",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"ad68f2df-5366-4658-892f-c5354e08c7f3");
INSERT INTO V_BIN
	VALUES ("8bd34dc1-d174-431f-bedc-9ca07ede78f5",
	"9c63487e-5874-4963-af3c-c68ebe23ec0f",
	"ab424dab-0e51-40d3-8b83-ff281a3298c6",
	'<');
INSERT INTO V_VAL
	VALUES ("9c63487e-5874-4963-af3c-c68ebe23ec0f",
	0,
	0,
	33,
	30,
	30,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ad68f2df-5366-4658-892f-c5354e08c7f3");
INSERT INTO V_LIN
	VALUES ("9c63487e-5874-4963-af3c-c68ebe23ec0f",
	'2');
INSERT INTO ACT_BLK
	VALUES ("21fdbf87-89be-4d91-a392-ba6baa4390f4",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	34,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7eb88b41-2247-4d32-848c-214bbe8f16b6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("82313fee-a6e4-44d4-8b58-bb7d132d1a07",
	"21fdbf87-89be-4d91-a392-ba6baa4390f4",
	"00000000-0000-0000-0000-000000000000",
	34,
	7,
	'cell::unsolved line: 34');
INSERT INTO E_ESS
	VALUES ("82313fee-a6e4-44d4-8b58-bb7d132d1a07",
	1,
	0,
	34,
	16,
	34,
	21,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("82313fee-a6e4-44d4-8b58-bb7d132d1a07");
INSERT INTO E_GSME
	VALUES ("82313fee-a6e4-44d4-8b58-bb7d132d1a07",
	"d7e974e2-f076-486f-8751-749403cb72ec",
	"56d15a5d-9abc-4ff5-8785-f948c27a4410");
INSERT INTO E_GEN
	VALUES ("82313fee-a6e4-44d4-8b58-bb7d132d1a07",
	"8bee351f-989d-4219-b50b-ad158edc7074");
INSERT INTO SM_STATE
	VALUES ("5f2385d6-012d-4145-8315-8a32534ff15b",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000",
	'solved',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES ("5f2385d6-012d-4145-8315-8a32534ff15b",
	"47502570-e42e-4963-ab1f-e4df543a21cf",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("5f2385d6-012d-4145-8315-8a32534ff15b",
	"47502570-e42e-4963-ab1f-e4df543a21cf",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EIGN
	VALUES ("5f2385d6-012d-4145-8315-8a32534ff15b",
	"24cb641a-7d3f-48df-8f88-b8d07bacdbda",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("5f2385d6-012d-4145-8315-8a32534ff15b",
	"24cb641a-7d3f-48df-8f88-b8d07bacdbda",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("47e85851-63ae-4325-b2cd-cf7b7e6626e1",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"5f2385d6-012d-4145-8315-8a32534ff15b");
INSERT INTO SM_AH
	VALUES ("47e85851-63ae-4325-b2cd-cf7b7e6626e1",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065");
INSERT INTO SM_ACT
	VALUES ("47e85851-63ae-4325-b2cd-cf7b7e6626e1",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	1,
	'// An answer has been found, so remove the eligible
// digits which are now ineligible digits.

// Link in the answer.
// CDS:  Consider selecting across R8 here.
select any digit from instances of DIGIT 
  where ( selected.value == rcvd_evt.digit );
if ( not_empty digit )
  relate self to digit across R9;
end if;

// Unlink the other digits.  There can be only one answer.
select many ineligibles related by self->ELIGIBLE[R8];
for each ineligible in ineligibles
  select one digit related by ineligible->DIGIT[R8];
  unrelate self from digit across R8 using ineligible;
  // delete object instance ineligible;
end for;

// CDS:  Inform the row, col and box that there is a change.',
	'');
INSERT INTO ACT_SAB
	VALUES ("a61c56dd-7859-4759-9b4e-b34840d4c3c7",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"47e85851-63ae-4325-b2cd-cf7b7e6626e1");
INSERT INTO ACT_ACT
	VALUES ("a61c56dd-7859-4759-9b4e-b34840d4c3c7",
	'state',
	0,
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f",
	"00000000-0000-0000-0000-000000000000",
	0,
	'cell::solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("9ef93a51-0e75-4641-8fab-9e20fb5a330f",
	1,
	0,
	1,
	'',
	'',
	'',
	14,
	1,
	13,
	42,
	0,
	0,
	13,
	51,
	0,
	0,
	0,
	0,
	0,
	"a61c56dd-7859-4759-9b4e-b34840d4c3c7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0adeb4cc-6e53-49bb-86d2-2a7804ff2343",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f",
	"964773f5-a2e0-4d01-8dd4-6fcfa0c4f919",
	6,
	1,
	'cell::solved line: 6');
INSERT INTO ACT_FIW
	VALUES ("0adeb4cc-6e53-49bb-86d2-2a7804ff2343",
	"27e0a310-9474-4c87-93b9-c6dc5326ceef",
	1,
	'any',
	"1c0cf079-0124-4e10-b513-c53c68a37317",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	6,
	36);
INSERT INTO ACT_SMT
	VALUES ("964773f5-a2e0-4d01-8dd4-6fcfa0c4f919",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f",
	"840dbfcf-8426-4470-9570-edae70e9eaff",
	8,
	1,
	'cell::solved line: 8');
INSERT INTO ACT_IF
	VALUES ("964773f5-a2e0-4d01-8dd4-6fcfa0c4f919",
	"639e4b39-0590-476b-b0a5-17860cc97719",
	"392d163a-8dfe-4545-affa-64e41f534494",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("840dbfcf-8426-4470-9570-edae70e9eaff",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f",
	"43fc27f0-d53f-4938-986e-e7ebae5b74a3",
	13,
	1,
	'cell::solved line: 13');
INSERT INTO ACT_SEL
	VALUES ("840dbfcf-8426-4470-9570-edae70e9eaff",
	"9cb2d163-735a-4e7f-9914-472bbc976205",
	1,
	'many',
	"a2a48444-36cb-44f3-8c72-d0376fce637d");
INSERT INTO ACT_SR
	VALUES ("840dbfcf-8426-4470-9570-edae70e9eaff");
INSERT INTO ACT_LNK
	VALUES ("cbebbe9c-a109-4f51-a7d5-9f018cca33be",
	'',
	"840dbfcf-8426-4470-9570-edae70e9eaff",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	13,
	42,
	13,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("43fc27f0-d53f-4938-986e-e7ebae5b74a3",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f",
	"00000000-0000-0000-0000-000000000000",
	14,
	1,
	'cell::solved line: 14');
INSERT INTO ACT_FOR
	VALUES ("43fc27f0-d53f-4938-986e-e7ebae5b74a3",
	"07c952bf-7bf9-4b7f-b055-0842067ab8b5",
	1,
	"7adff08c-3499-4427-bd28-0b1ab71b44da",
	"9cb2d163-735a-4e7f-9914-472bbc976205",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_VAL
	VALUES ("d7c1d888-1075-443a-a049-826360585ee8",
	0,
	0,
	7,
	11,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f");
INSERT INTO V_SLR
	VALUES ("d7c1d888-1075-443a-a049-826360585ee8",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("7f174449-a1c7-4f61-95bb-a1e7b5e8d1e4",
	0,
	0,
	7,
	20,
	24,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f");
INSERT INTO V_AVL
	VALUES ("7f174449-a1c7-4f61-95bb-a1e7b5e8d1e4",
	"d7c1d888-1075-443a-a049-826360585ee8",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO V_VAL
	VALUES ("1c0cf079-0124-4e10-b513-c53c68a37317",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f");
INSERT INTO V_BIN
	VALUES ("1c0cf079-0124-4e10-b513-c53c68a37317",
	"9cb5214e-b5cb-48e7-b569-e5a059b02e91",
	"7f174449-a1c7-4f61-95bb-a1e7b5e8d1e4",
	'==');
INSERT INTO V_VAL
	VALUES ("9cb5214e-b5cb-48e7-b569-e5a059b02e91",
	0,
	0,
	7,
	38,
	42,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f");
INSERT INTO V_EDV
	VALUES ("9cb5214e-b5cb-48e7-b569-e5a059b02e91");
INSERT INTO V_EPR
	VALUES ("9cb5214e-b5cb-48e7-b569-e5a059b02e91",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"9edf9a91-d602-4eb8-b094-445a98c4e352",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("04f943c6-5992-4448-9282-218c96db4cbf",
	0,
	0,
	8,
	16,
	20,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f");
INSERT INTO V_IRF
	VALUES ("04f943c6-5992-4448-9282-218c96db4cbf",
	"27e0a310-9474-4c87-93b9-c6dc5326ceef");
INSERT INTO V_VAL
	VALUES ("392d163a-8dfe-4545-affa-64e41f534494",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f");
INSERT INTO V_UNY
	VALUES ("392d163a-8dfe-4545-affa-64e41f534494",
	"04f943c6-5992-4448-9282-218c96db4cbf",
	'not_empty');
INSERT INTO V_VAL
	VALUES ("a2a48444-36cb-44f3-8c72-d0376fce637d",
	0,
	0,
	13,
	36,
	39,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f");
INSERT INTO V_IRF
	VALUES ("a2a48444-36cb-44f3-8c72-d0376fce637d",
	"c994150c-44fa-4f37-9443-565027eb4c9d");
INSERT INTO V_VAR
	VALUES ("27e0a310-9474-4c87-93b9-c6dc5326ceef",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f",
	'digit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("27e0a310-9474-4c87-93b9-c6dc5326ceef",
	0,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("673a6bea-e8f5-43f2-a860-efc16ab00eb3",
	6,
	12,
	16,
	"27e0a310-9474-4c87-93b9-c6dc5326ceef");
INSERT INTO V_LOC
	VALUES ("6fe101ec-bcc7-450e-aa64-00ff1d088e4d",
	9,
	18,
	22,
	"27e0a310-9474-4c87-93b9-c6dc5326ceef");
INSERT INTO V_LOC
	VALUES ("ee73915b-2200-409f-83b7-97c9a139f07d",
	15,
	14,
	18,
	"27e0a310-9474-4c87-93b9-c6dc5326ceef");
INSERT INTO V_LOC
	VALUES ("13c93c77-084d-4441-8ac0-ace44d9c0fee",
	16,
	22,
	26,
	"27e0a310-9474-4c87-93b9-c6dc5326ceef");
INSERT INTO V_VAR
	VALUES ("c994150c-44fa-4f37-9443-565027eb4c9d",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("c994150c-44fa-4f37-9443-565027eb4c9d",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("8d229105-363d-4793-92e6-fc1c57d8b206",
	9,
	10,
	13,
	"c994150c-44fa-4f37-9443-565027eb4c9d");
INSERT INTO V_LOC
	VALUES ("d9ed1249-b601-4da9-9b9a-9862a2768a11",
	16,
	12,
	15,
	"c994150c-44fa-4f37-9443-565027eb4c9d");
INSERT INTO V_VAR
	VALUES ("9cb2d163-735a-4e7f-9914-472bbc976205",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f",
	'ineligibles',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("9cb2d163-735a-4e7f-9914-472bbc976205",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("76f4f634-cd3e-4218-8ac3-f51a52a5fb56",
	13,
	13,
	23,
	"9cb2d163-735a-4e7f-9914-472bbc976205");
INSERT INTO V_LOC
	VALUES ("ac73c6db-e090-4aba-8aae-0e8590a4b808",
	14,
	24,
	34,
	"9cb2d163-735a-4e7f-9914-472bbc976205");
INSERT INTO V_VAR
	VALUES ("7adff08c-3499-4427-bd28-0b1ab71b44da",
	"9ef93a51-0e75-4641-8fab-9e20fb5a330f",
	'ineligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("7adff08c-3499-4427-bd28-0b1ab71b44da",
	1,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("c2001294-9573-4236-b934-0f6df54f1040",
	14,
	10,
	19,
	"7adff08c-3499-4427-bd28-0b1ab71b44da");
INSERT INTO V_LOC
	VALUES ("2448182e-90a1-44b5-937f-ebd3b4fb6a4e",
	16,
	44,
	53,
	"7adff08c-3499-4427-bd28-0b1ab71b44da");
INSERT INTO ACT_BLK
	VALUES ("639e4b39-0590-476b-b0a5-17860cc97719",
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	0,
	0,
	0,
	0,
	9,
	31,
	0,
	0,
	0,
	0,
	0,
	"a61c56dd-7859-4759-9b4e-b34840d4c3c7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("956a3198-b458-4b0c-8792-23f4b9b26ca7",
	"639e4b39-0590-476b-b0a5-17860cc97719",
	"00000000-0000-0000-0000-000000000000",
	9,
	3,
	'cell::solved line: 9');
INSERT INTO ACT_REL
	VALUES ("956a3198-b458-4b0c-8792-23f4b9b26ca7",
	"c994150c-44fa-4f37-9443-565027eb4c9d",
	"27e0a310-9474-4c87-93b9-c6dc5326ceef",
	'',
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	9,
	31,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("07c952bf-7bf9-4b7f-b055-0842067ab8b5",
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	3,
	15,
	43,
	0,
	0,
	16,
	35,
	0,
	0,
	0,
	0,
	0,
	"a61c56dd-7859-4759-9b4e-b34840d4c3c7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("929b280a-2b6c-4cec-8ad9-0251561f84eb",
	"07c952bf-7bf9-4b7f-b055-0842067ab8b5",
	"ff34954a-9f1f-48ed-81fb-9a540df9ef34",
	15,
	3,
	'cell::solved line: 15');
INSERT INTO ACT_SEL
	VALUES ("929b280a-2b6c-4cec-8ad9-0251561f84eb",
	"27e0a310-9474-4c87-93b9-c6dc5326ceef",
	0,
	'one',
	"3cc94d0c-349d-4ef4-9f0f-f138e5237537");
INSERT INTO ACT_SR
	VALUES ("929b280a-2b6c-4cec-8ad9-0251561f84eb");
INSERT INTO ACT_LNK
	VALUES ("7b18330b-d68b-4cab-b67e-ce3b5083bc75",
	'',
	"929b280a-2b6c-4cec-8ad9-0251561f84eb",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	15,
	43,
	15,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ff34954a-9f1f-48ed-81fb-9a540df9ef34",
	"07c952bf-7bf9-4b7f-b055-0842067ab8b5",
	"00000000-0000-0000-0000-000000000000",
	16,
	3,
	'cell::solved line: 16');
INSERT INTO ACT_URU
	VALUES ("ff34954a-9f1f-48ed-81fb-9a540df9ef34",
	"c994150c-44fa-4f37-9443-565027eb4c9d",
	"27e0a310-9474-4c87-93b9-c6dc5326ceef",
	"7adff08c-3499-4427-bd28-0b1ab71b44da",
	'',
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	16,
	35,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("3cc94d0c-349d-4ef4-9f0f-f138e5237537",
	0,
	0,
	15,
	31,
	40,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"07c952bf-7bf9-4b7f-b055-0842067ab8b5");
INSERT INTO V_IRF
	VALUES ("3cc94d0c-349d-4ef4-9f0f-f138e5237537",
	"7adff08c-3499-4427-bd28-0b1ab71b44da");
INSERT INTO SM_NSTXN
	VALUES ("0887e298-c131-4231-adbe-81fe10f35562",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"fc40f9e1-7979-4507-a29b-0666b183dbb0",
	"24cb641a-7d3f-48df-8f88-b8d07bacdbda",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("1566254b-7a2c-495f-ba1e-af59ddec30a1",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"0887e298-c131-4231-adbe-81fe10f35562");
INSERT INTO SM_AH
	VALUES ("1566254b-7a2c-495f-ba1e-af59ddec30a1",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065");
INSERT INTO SM_ACT
	VALUES ("1566254b-7a2c-495f-ba1e-af59ddec30a1",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("9d84739c-b5e5-4ff2-9c15-24a8bc464154",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"1566254b-7a2c-495f-ba1e-af59ddec30a1");
INSERT INTO ACT_ACT
	VALUES ("9d84739c-b5e5-4ff2-9c15-24a8bc464154",
	'transition',
	0,
	"0be2188d-c0e3-44a4-a821-6f1e9aa53317",
	"00000000-0000-0000-0000-000000000000",
	0,
	'CELL2: answer in unsolved to solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("0be2188d-c0e3-44a4-a821-6f1e9aa53317",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9d84739c-b5e5-4ff2-9c15-24a8bc464154",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("0887e298-c131-4231-adbe-81fe10f35562",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"5f2385d6-012d-4145-8315-8a32534ff15b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("12f9628a-ac5e-4390-912c-7f36ba47ab39",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"fc40f9e1-7979-4507-a29b-0666b183dbb0",
	"47502570-e42e-4963-ab1f-e4df543a21cf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("45d49bdc-2106-4ed1-a90e-5f615779ad8d",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"12f9628a-ac5e-4390-912c-7f36ba47ab39");
INSERT INTO SM_AH
	VALUES ("45d49bdc-2106-4ed1-a90e-5f615779ad8d",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065");
INSERT INTO SM_ACT
	VALUES ("45d49bdc-2106-4ed1-a90e-5f615779ad8d",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("fa62a041-53ac-4cea-a11a-66f6d10332cf",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"45d49bdc-2106-4ed1-a90e-5f615779ad8d");
INSERT INTO ACT_ACT
	VALUES ("fa62a041-53ac-4cea-a11a-66f6d10332cf",
	'transition',
	0,
	"03c1022c-a4ed-4da0-88c9-51eea03a05f8",
	"00000000-0000-0000-0000-000000000000",
	0,
	'CELL1: eliminate in unsolved to unsolved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("03c1022c-a4ed-4da0-88c9-51eea03a05f8",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"fa62a041-53ac-4cea-a11a-66f6d10332cf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("12f9628a-ac5e-4390-912c-7f36ba47ab39",
	"247f4e44-7c6c-4bb9-bc5a-59c72749b065",
	"fc40f9e1-7979-4507-a29b-0666b183dbb0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_OBJ
	VALUES ("4717be2d-8755-4321-a6af-92c4a16fe7c2",
	'column',
	3,
	'COLUMN',
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO O_TFR
	VALUES ("d2362f48-e98f-4889-a32e-046f0f334fd1",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	'prune',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	1,
	'// Eliminate eligible digits that match any answer digit for this sequence.

temperature = 0;
select many answerdigits related by self->CELL[R3]->DIGIT[R9] where ( selected.value != 0 );
select many eligibles related by self->CELL[R3]->ELIGIBLE[R8];
for each eligible in eligibles
  for each answerdigit in answerdigits
    if ( eligible.digit_value == answerdigit.value )
      select one opencell related by eligible->CELL[R8];
      if ( opencell.answer_value != eligible.digit_value )
        unrelate answerdigit from opencell across R8 using eligible;
        delete object instance eligible;
        // generate CELL1:eliminate( digit:answerdigit.value ) to opencell;
      end if;
      temperature = 1;
      break;
    end if;
  end for;
end for;
  
select many opencells related by self->CELL[R3]
  where ( selected.answer_value == 0 );
if ( empty opencells )
  temperature = 100;
end if;
for each opencell in opencells
  // Notice if we have the answer now.
  select many eligibles related by opencell->ELIGIBLE[R8];
  c = cardinality eligibles;
  if ( 1 == c )
    select any answer related by opencell->ELIGIBLE[R8];
    opencell.answer( answer_digit:answer.digit_value );
    // generate CELL2:answer( digit:answer.digit_value ) to opencell;
    temperature = 1;
  end if;
end for;

return temperature;
',
	1,
	'',
	"e184be1e-e976-4c07-baa6-c4de41296f45");
INSERT INTO ACT_OPB
	VALUES ("5b596a9f-bd90-47f2-a3ab-3ab38ae5ca82",
	"d2362f48-e98f-4889-a32e-046f0f334fd1");
INSERT INTO ACT_ACT
	VALUES ("5b596a9f-bd90-47f2-a3ab-3ab38ae5ca82",
	'operation',
	0,
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	"00000000-0000-0000-0000-000000000000",
	0,
	'column::prune',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("006f4a24-ce98-44fe-8461-8be67c22a45c",
	1,
	0,
	1,
	'',
	'',
	'',
	38,
	1,
	21,
	40,
	0,
	0,
	21,
	45,
	0,
	0,
	0,
	0,
	0,
	"5b596a9f-bd90-47f2-a3ab-3ab38ae5ca82",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("65d5afcc-4d02-4277-bfdd-36a4844aa106",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	"eb634406-2f10-4105-9ac7-a4e4d253ffa9",
	3,
	1,
	'column::prune line: 3');
INSERT INTO ACT_AI
	VALUES ("65d5afcc-4d02-4277-bfdd-36a4844aa106",
	"877122ac-cae3-4360-b6f0-8318618731b2",
	"018a969e-3c25-40ed-a359-0b6aed27a82b",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("eb634406-2f10-4105-9ac7-a4e4d253ffa9",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	"9975c23f-171a-4bb8-bbc2-4dcdd145f693",
	4,
	1,
	'column::prune line: 4');
INSERT INTO ACT_SEL
	VALUES ("eb634406-2f10-4105-9ac7-a4e4d253ffa9",
	"27fff1ff-061c-45bd-8096-8de81ef8b7b9",
	1,
	'many',
	"32c77fa5-43f9-4b2e-9d8d-bc4e8968d34c");
INSERT INTO ACT_SRW
	VALUES ("eb634406-2f10-4105-9ac7-a4e4d253ffa9",
	"eef78245-863c-4532-981d-ac8897292ffb");
INSERT INTO ACT_LNK
	VALUES ("43e649e7-04c4-43ff-9daf-f39273783600",
	'',
	"eb634406-2f10-4105-9ac7-a4e4d253ffa9",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"e1b48ae4-d9e3-4857-9917-47735e555063",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	4,
	43,
	4,
	48,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("e1b48ae4-d9e3-4857-9917-47735e555063",
	'',
	"00000000-0000-0000-0000-000000000000",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"00000000-0000-0000-0000-000000000000",
	2,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	4,
	53,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9975c23f-171a-4bb8-bbc2-4dcdd145f693",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	"a5021bf0-e36d-4da2-bbe3-d10829112333",
	5,
	1,
	'column::prune line: 5');
INSERT INTO ACT_SEL
	VALUES ("9975c23f-171a-4bb8-bbc2-4dcdd145f693",
	"083c3c09-82d4-481b-9f73-fbbb5f9ea459",
	1,
	'many',
	"95fd9a78-3bfe-4e23-b8cc-141b601f4750");
INSERT INTO ACT_SR
	VALUES ("9975c23f-171a-4bb8-bbc2-4dcdd145f693");
INSERT INTO ACT_LNK
	VALUES ("c595d1c9-6312-42c5-bd5e-761bfc201e8b",
	'',
	"9975c23f-171a-4bb8-bbc2-4dcdd145f693",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"654d0d7f-f872-4d01-aaa7-f6c25c8ccd2b",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("654d0d7f-f872-4d01-aaa7-f6c25c8ccd2b",
	'',
	"00000000-0000-0000-0000-000000000000",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a5021bf0-e36d-4da2-bbe3-d10829112333",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	"3e3ee7c2-a53d-44cd-8b0f-d52ddbd6f8a9",
	6,
	1,
	'column::prune line: 6');
INSERT INTO ACT_FOR
	VALUES ("a5021bf0-e36d-4da2-bbe3-d10829112333",
	"98dec500-afee-493c-b4f8-52b77453a0d6",
	1,
	"bd9997df-7641-4018-b192-218aaabb8991",
	"083c3c09-82d4-481b-9f73-fbbb5f9ea459",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO ACT_SMT
	VALUES ("3e3ee7c2-a53d-44cd-8b0f-d52ddbd6f8a9",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	"7c03db97-a4ec-460b-8abb-78411bd2baad",
	21,
	1,
	'column::prune line: 21');
INSERT INTO ACT_SEL
	VALUES ("3e3ee7c2-a53d-44cd-8b0f-d52ddbd6f8a9",
	"0c6f3940-e311-4ec9-8e3d-68083ebf20db",
	1,
	'many',
	"556fe99d-7ecd-4729-a9df-113732590fa1");
INSERT INTO ACT_SRW
	VALUES ("3e3ee7c2-a53d-44cd-8b0f-d52ddbd6f8a9",
	"fb701e48-0bd1-45c3-8f1d-c27fa3c25f2c");
INSERT INTO ACT_LNK
	VALUES ("66cd8501-c4a3-4ea6-9328-921962281958",
	'',
	"3e3ee7c2-a53d-44cd-8b0f-d52ddbd6f8a9",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"00000000-0000-0000-0000-000000000000",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	21,
	40,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7c03db97-a4ec-460b-8abb-78411bd2baad",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	"4d517eb1-a056-446c-862a-e923ce42a51e",
	23,
	1,
	'column::prune line: 23');
INSERT INTO ACT_IF
	VALUES ("7c03db97-a4ec-460b-8abb-78411bd2baad",
	"e307453c-19e4-42e6-a567-dfa818d20c62",
	"2c784362-f323-4be3-a8da-cc763611d635",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4d517eb1-a056-446c-862a-e923ce42a51e",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	"4108b812-718d-4ba7-b025-e759b3fe410a",
	26,
	1,
	'column::prune line: 26');
INSERT INTO ACT_FOR
	VALUES ("4d517eb1-a056-446c-862a-e923ce42a51e",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c",
	1,
	"93e0cf63-ee47-4d1f-b0e5-501b77b5c237",
	"0c6f3940-e311-4ec9-8e3d-68083ebf20db",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO ACT_SMT
	VALUES ("4108b812-718d-4ba7-b025-e759b3fe410a",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	"00000000-0000-0000-0000-000000000000",
	38,
	1,
	'column::prune line: 38');
INSERT INTO ACT_RET
	VALUES ("4108b812-718d-4ba7-b025-e759b3fe410a",
	"926b4538-4dba-4b18-8222-ef181948ed25");
INSERT INTO V_VAL
	VALUES ("018a969e-3c25-40ed-a359-0b6aed27a82b",
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_TVL
	VALUES ("018a969e-3c25-40ed-a359-0b6aed27a82b",
	"428a7dd6-18b9-4f07-aae0-d33f1ea19298");
INSERT INTO V_VAL
	VALUES ("877122ac-cae3-4360-b6f0-8318618731b2",
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_LIN
	VALUES ("877122ac-cae3-4360-b6f0-8318618731b2",
	'0');
INSERT INTO V_VAL
	VALUES ("32c77fa5-43f9-4b2e-9d8d-bc4e8968d34c",
	0,
	0,
	4,
	37,
	40,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_IRF
	VALUES ("32c77fa5-43f9-4b2e-9d8d-bc4e8968d34c",
	"b81a2a95-984e-4f49-a62a-c2e7a5f1ccc9");
INSERT INTO V_VAL
	VALUES ("017879f7-5e04-42f2-bf7e-25fb94b4b471",
	0,
	0,
	4,
	71,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_SLR
	VALUES ("017879f7-5e04-42f2-bf7e-25fb94b4b471",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("e9e757b2-2e4f-42cf-afea-3896d6ce6f13",
	0,
	0,
	4,
	80,
	84,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_AVL
	VALUES ("e9e757b2-2e4f-42cf-afea-3896d6ce6f13",
	"017879f7-5e04-42f2-bf7e-25fb94b4b471",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO V_VAL
	VALUES ("eef78245-863c-4532-981d-ac8897292ffb",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_BIN
	VALUES ("eef78245-863c-4532-981d-ac8897292ffb",
	"a4e1125b-35da-47dc-b6c3-d2e4d8df68f2",
	"e9e757b2-2e4f-42cf-afea-3896d6ce6f13",
	'!=');
INSERT INTO V_VAL
	VALUES ("a4e1125b-35da-47dc-b6c3-d2e4d8df68f2",
	0,
	0,
	4,
	89,
	89,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_LIN
	VALUES ("a4e1125b-35da-47dc-b6c3-d2e4d8df68f2",
	'0');
INSERT INTO V_VAL
	VALUES ("95fd9a78-3bfe-4e23-b8cc-141b601f4750",
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_IRF
	VALUES ("95fd9a78-3bfe-4e23-b8cc-141b601f4750",
	"b81a2a95-984e-4f49-a62a-c2e7a5f1ccc9");
INSERT INTO V_VAL
	VALUES ("556fe99d-7ecd-4729-a9df-113732590fa1",
	0,
	0,
	21,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_IRF
	VALUES ("556fe99d-7ecd-4729-a9df-113732590fa1",
	"b81a2a95-984e-4f49-a62a-c2e7a5f1ccc9");
INSERT INTO V_VAL
	VALUES ("c57cf8a6-a6c8-4515-a9b2-3eac70d1be19",
	0,
	0,
	22,
	11,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_SLR
	VALUES ("c57cf8a6-a6c8-4515-a9b2-3eac70d1be19",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("c287db53-d626-439c-a734-336e4beaef63",
	0,
	0,
	22,
	20,
	31,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_AVL
	VALUES ("c287db53-d626-439c-a734-336e4beaef63",
	"c57cf8a6-a6c8-4515-a9b2-3eac70d1be19",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4");
INSERT INTO V_VAL
	VALUES ("fb701e48-0bd1-45c3-8f1d-c27fa3c25f2c",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_BIN
	VALUES ("fb701e48-0bd1-45c3-8f1d-c27fa3c25f2c",
	"5b6d4f0e-5721-498c-bb0b-cfe8ea8ce64d",
	"c287db53-d626-439c-a734-336e4beaef63",
	'==');
INSERT INTO V_VAL
	VALUES ("5b6d4f0e-5721-498c-bb0b-cfe8ea8ce64d",
	0,
	0,
	22,
	36,
	36,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_LIN
	VALUES ("5b6d4f0e-5721-498c-bb0b-cfe8ea8ce64d",
	'0');
INSERT INTO V_VAL
	VALUES ("1b74aff1-d76d-42b4-a806-9cbd2288ba27",
	0,
	0,
	23,
	12,
	20,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_ISR
	VALUES ("1b74aff1-d76d-42b4-a806-9cbd2288ba27",
	"0c6f3940-e311-4ec9-8e3d-68083ebf20db");
INSERT INTO V_VAL
	VALUES ("2c784362-f323-4be3-a8da-cc763611d635",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_UNY
	VALUES ("2c784362-f323-4be3-a8da-cc763611d635",
	"1b74aff1-d76d-42b4-a806-9cbd2288ba27",
	'empty');
INSERT INTO V_VAL
	VALUES ("926b4538-4dba-4b18-8222-ef181948ed25",
	0,
	0,
	38,
	8,
	18,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"006f4a24-ce98-44fe-8461-8be67c22a45c");
INSERT INTO V_TVL
	VALUES ("926b4538-4dba-4b18-8222-ef181948ed25",
	"428a7dd6-18b9-4f07-aae0-d33f1ea19298");
INSERT INTO V_VAR
	VALUES ("428a7dd6-18b9-4f07-aae0-d33f1ea19298",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	'temperature',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("428a7dd6-18b9-4f07-aae0-d33f1ea19298",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("b0c51525-6195-4975-b851-2c5fb4b2b788",
	3,
	1,
	11,
	"428a7dd6-18b9-4f07-aae0-d33f1ea19298");
INSERT INTO V_LOC
	VALUES ("cf28546a-6f65-4b0d-b706-72c8a4f61901",
	15,
	7,
	17,
	"428a7dd6-18b9-4f07-aae0-d33f1ea19298");
INSERT INTO V_LOC
	VALUES ("2f858088-a462-4cc9-a14d-6872dab91d82",
	24,
	3,
	13,
	"428a7dd6-18b9-4f07-aae0-d33f1ea19298");
INSERT INTO V_LOC
	VALUES ("63249da1-a00f-4881-9af0-0b6cfaf213cd",
	34,
	5,
	15,
	"428a7dd6-18b9-4f07-aae0-d33f1ea19298");
INSERT INTO V_LOC
	VALUES ("f3659eff-46c7-422b-b377-7b063bc09b1e",
	38,
	8,
	18,
	"428a7dd6-18b9-4f07-aae0-d33f1ea19298");
INSERT INTO V_VAR
	VALUES ("27fff1ff-061c-45bd-8096-8de81ef8b7b9",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	'answerdigits',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("27fff1ff-061c-45bd-8096-8de81ef8b7b9",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("24dd6f8b-0881-40aa-99bb-3b470f987b95",
	4,
	13,
	24,
	"27fff1ff-061c-45bd-8096-8de81ef8b7b9");
INSERT INTO V_LOC
	VALUES ("e0f69eb2-21d5-4133-8a23-60e9bbf6f04c",
	7,
	27,
	38,
	"27fff1ff-061c-45bd-8096-8de81ef8b7b9");
INSERT INTO V_VAR
	VALUES ("b81a2a95-984e-4f49-a62a-c2e7a5f1ccc9",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("b81a2a95-984e-4f49-a62a-c2e7a5f1ccc9",
	0,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_VAR
	VALUES ("083c3c09-82d4-481b-9f73-fbbb5f9ea459",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	'eligibles',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("083c3c09-82d4-481b-9f73-fbbb5f9ea459",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("0be46e17-a6fc-4e70-9028-48f5b19eb8c7",
	5,
	13,
	21,
	"083c3c09-82d4-481b-9f73-fbbb5f9ea459");
INSERT INTO V_LOC
	VALUES ("aa80f023-2e62-49ad-baac-f96399fc3247",
	6,
	22,
	30,
	"083c3c09-82d4-481b-9f73-fbbb5f9ea459");
INSERT INTO V_LOC
	VALUES ("034302c2-a792-4b69-ad9f-fd1b173b9d09",
	28,
	15,
	23,
	"083c3c09-82d4-481b-9f73-fbbb5f9ea459");
INSERT INTO V_VAR
	VALUES ("bd9997df-7641-4018-b192-218aaabb8991",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	'eligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("bd9997df-7641-4018-b192-218aaabb8991",
	1,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("b7f1369e-301b-46d0-beae-d5670da802d7",
	6,
	10,
	17,
	"bd9997df-7641-4018-b192-218aaabb8991");
INSERT INTO V_LOC
	VALUES ("be7ead27-0a69-4e80-860f-b660ff70f340",
	8,
	10,
	17,
	"bd9997df-7641-4018-b192-218aaabb8991");
INSERT INTO V_LOC
	VALUES ("32c12408-a076-4cd5-aeef-3f2e9b64b3f4",
	10,
	37,
	44,
	"bd9997df-7641-4018-b192-218aaabb8991");
INSERT INTO V_LOC
	VALUES ("3f1668dc-e56e-4cfa-aa06-f3f41bdfed2b",
	11,
	60,
	67,
	"bd9997df-7641-4018-b192-218aaabb8991");
INSERT INTO V_LOC
	VALUES ("2fb22c32-459e-4667-8fe2-2867fb3e319d",
	12,
	32,
	39,
	"bd9997df-7641-4018-b192-218aaabb8991");
INSERT INTO V_VAR
	VALUES ("0c6f3940-e311-4ec9-8e3d-68083ebf20db",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	'opencells',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("0c6f3940-e311-4ec9-8e3d-68083ebf20db",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("90d12b87-21cf-4dcf-93f9-75cf8adcc106",
	21,
	13,
	21,
	"0c6f3940-e311-4ec9-8e3d-68083ebf20db");
INSERT INTO V_LOC
	VALUES ("291c25a1-7724-447a-9807-82484f59c56d",
	26,
	22,
	30,
	"0c6f3940-e311-4ec9-8e3d-68083ebf20db");
INSERT INTO V_VAR
	VALUES ("93e0cf63-ee47-4d1f-b0e5-501b77b5c237",
	"006f4a24-ce98-44fe-8461-8be67c22a45c",
	'opencell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("93e0cf63-ee47-4d1f-b0e5-501b77b5c237",
	1,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("afa06ff4-76a3-4213-8119-0dc89299326d",
	26,
	10,
	17,
	"93e0cf63-ee47-4d1f-b0e5-501b77b5c237");
INSERT INTO V_LOC
	VALUES ("51042118-a33a-4dd2-94ab-eda4e24c3cd7",
	32,
	5,
	12,
	"93e0cf63-ee47-4d1f-b0e5-501b77b5c237");
INSERT INTO ACT_BLK
	VALUES ("98dec500-afee-493c-b4f8-52b77453a0d6",
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"5b596a9f-bd90-47f2-a3ab-3ab38ae5ca82",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c3b315de-1b78-4521-90ff-d42d7d3cc86d",
	"98dec500-afee-493c-b4f8-52b77453a0d6",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'column::prune line: 7');
INSERT INTO ACT_FOR
	VALUES ("c3b315de-1b78-4521-90ff-d42d7d3cc86d",
	"eaefcfdf-7627-442e-9180-aabb3c359492",
	1,
	"bbe07c00-5500-43d2-aaca-b93595a70c97",
	"27fff1ff-061c-45bd-8096-8de81ef8b7b9",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_VAR
	VALUES ("bbe07c00-5500-43d2-aaca-b93595a70c97",
	"98dec500-afee-493c-b4f8-52b77453a0d6",
	'answerdigit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("bbe07c00-5500-43d2-aaca-b93595a70c97",
	1,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("7d47647a-a6c0-419a-a6b1-1a5b1fd99c0c",
	7,
	12,
	22,
	"bbe07c00-5500-43d2-aaca-b93595a70c97");
INSERT INTO V_LOC
	VALUES ("d629f938-3f93-4dfe-834f-5965a3f4b2b0",
	8,
	34,
	44,
	"bbe07c00-5500-43d2-aaca-b93595a70c97");
INSERT INTO V_LOC
	VALUES ("e05753a9-cb6b-4042-a2c7-05762e6a0511",
	11,
	18,
	28,
	"bbe07c00-5500-43d2-aaca-b93595a70c97");
INSERT INTO ACT_BLK
	VALUES ("eaefcfdf-7627-442e-9180-aabb3c359492",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"5b596a9f-bd90-47f2-a3ab-3ab38ae5ca82",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("83633005-6e70-4512-bb67-5dd34c938b20",
	"eaefcfdf-7627-442e-9180-aabb3c359492",
	"00000000-0000-0000-0000-000000000000",
	8,
	5,
	'column::prune line: 8');
INSERT INTO ACT_IF
	VALUES ("83633005-6e70-4512-bb67-5dd34c938b20",
	"e3f72ebf-598b-488d-8200-a60f3000b596",
	"028035b6-8d87-40ec-a3ab-4abe35771ceb",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("b225993a-57da-479e-99ff-29ac9a571fd2",
	0,
	0,
	8,
	10,
	17,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"eaefcfdf-7627-442e-9180-aabb3c359492");
INSERT INTO V_IRF
	VALUES ("b225993a-57da-479e-99ff-29ac9a571fd2",
	"bd9997df-7641-4018-b192-218aaabb8991");
INSERT INTO V_VAL
	VALUES ("f368feda-4955-4795-ba32-13095bd24acd",
	0,
	0,
	8,
	19,
	29,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eaefcfdf-7627-442e-9180-aabb3c359492");
INSERT INTO V_AVL
	VALUES ("f368feda-4955-4795-ba32-13095bd24acd",
	"b225993a-57da-479e-99ff-29ac9a571fd2",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("028035b6-8d87-40ec-a3ab-4abe35771ceb",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"eaefcfdf-7627-442e-9180-aabb3c359492");
INSERT INTO V_BIN
	VALUES ("028035b6-8d87-40ec-a3ab-4abe35771ceb",
	"ef6c1317-cbcb-4364-98aa-c86a4ff4cda4",
	"f368feda-4955-4795-ba32-13095bd24acd",
	'==');
INSERT INTO V_VAL
	VALUES ("12666f46-8f82-495c-ab8f-ffe94c29fb3a",
	0,
	0,
	8,
	34,
	44,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"eaefcfdf-7627-442e-9180-aabb3c359492");
INSERT INTO V_IRF
	VALUES ("12666f46-8f82-495c-ab8f-ffe94c29fb3a",
	"bbe07c00-5500-43d2-aaca-b93595a70c97");
INSERT INTO V_VAL
	VALUES ("ef6c1317-cbcb-4364-98aa-c86a4ff4cda4",
	0,
	0,
	8,
	46,
	50,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"eaefcfdf-7627-442e-9180-aabb3c359492");
INSERT INTO V_AVL
	VALUES ("ef6c1317-cbcb-4364-98aa-c86a4ff4cda4",
	"12666f46-8f82-495c-ab8f-ffe94c29fb3a",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO ACT_BLK
	VALUES ("e3f72ebf-598b-488d-8200-a60f3000b596",
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	7,
	9,
	48,
	0,
	0,
	9,
	53,
	0,
	0,
	0,
	0,
	0,
	"5b596a9f-bd90-47f2-a3ab-3ab38ae5ca82",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4f7865bb-b302-4f9d-8f3d-9f33fba5181e",
	"e3f72ebf-598b-488d-8200-a60f3000b596",
	"56e962e4-9484-4482-a5b4-1c8c009eddef",
	9,
	7,
	'column::prune line: 9');
INSERT INTO ACT_SEL
	VALUES ("4f7865bb-b302-4f9d-8f3d-9f33fba5181e",
	"be542248-4b86-48bc-8190-e4e3e7f04a7b",
	1,
	'one',
	"80172be2-8f0a-4807-805b-4d82b0e8d333");
INSERT INTO ACT_SR
	VALUES ("4f7865bb-b302-4f9d-8f3d-9f33fba5181e");
INSERT INTO ACT_LNK
	VALUES ("6aea98b8-6224-4337-b418-86fbebc10c30",
	'',
	"4f7865bb-b302-4f9d-8f3d-9f33fba5181e",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	9,
	48,
	9,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("56e962e4-9484-4482-a5b4-1c8c009eddef",
	"e3f72ebf-598b-488d-8200-a60f3000b596",
	"4fd928b9-3005-4ca4-bf33-86a6268dc767",
	10,
	7,
	'column::prune line: 10');
INSERT INTO ACT_IF
	VALUES ("56e962e4-9484-4482-a5b4-1c8c009eddef",
	"3e7d52c2-334b-4324-9022-39cd2ee303e2",
	"51d7163b-14d8-47a2-8f17-36e6e46c77f0",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4fd928b9-3005-4ca4-bf33-86a6268dc767",
	"e3f72ebf-598b-488d-8200-a60f3000b596",
	"9fd62f03-65f4-4e31-9702-12956a5f2e84",
	15,
	7,
	'column::prune line: 15');
INSERT INTO ACT_AI
	VALUES ("4fd928b9-3005-4ca4-bf33-86a6268dc767",
	"3fd64c30-b3ae-4d66-93bc-690665ea568a",
	"925e4fba-88e1-4456-8059-9bbf6f3a2b82",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9fd62f03-65f4-4e31-9702-12956a5f2e84",
	"e3f72ebf-598b-488d-8200-a60f3000b596",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	'column::prune line: 16');
INSERT INTO ACT_BRK
	VALUES ("9fd62f03-65f4-4e31-9702-12956a5f2e84");
INSERT INTO V_VAL
	VALUES ("80172be2-8f0a-4807-805b-4d82b0e8d333",
	0,
	0,
	9,
	38,
	45,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"e3f72ebf-598b-488d-8200-a60f3000b596");
INSERT INTO V_IRF
	VALUES ("80172be2-8f0a-4807-805b-4d82b0e8d333",
	"bd9997df-7641-4018-b192-218aaabb8991");
INSERT INTO V_VAL
	VALUES ("d1a6e433-eb41-4cc9-8cf8-dde24cb87462",
	0,
	0,
	10,
	12,
	19,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"e3f72ebf-598b-488d-8200-a60f3000b596");
INSERT INTO V_IRF
	VALUES ("d1a6e433-eb41-4cc9-8cf8-dde24cb87462",
	"be542248-4b86-48bc-8190-e4e3e7f04a7b");
INSERT INTO V_VAL
	VALUES ("98df4756-2c9b-4b27-8a2b-9ee8c1e05d2f",
	0,
	0,
	10,
	21,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e3f72ebf-598b-488d-8200-a60f3000b596");
INSERT INTO V_AVL
	VALUES ("98df4756-2c9b-4b27-8a2b-9ee8c1e05d2f",
	"d1a6e433-eb41-4cc9-8cf8-dde24cb87462",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4");
INSERT INTO V_VAL
	VALUES ("51d7163b-14d8-47a2-8f17-36e6e46c77f0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"e3f72ebf-598b-488d-8200-a60f3000b596");
INSERT INTO V_BIN
	VALUES ("51d7163b-14d8-47a2-8f17-36e6e46c77f0",
	"64883efc-5bf7-4898-aed2-94dd83dc915e",
	"98df4756-2c9b-4b27-8a2b-9ee8c1e05d2f",
	'!=');
INSERT INTO V_VAL
	VALUES ("6640c83f-8e5f-44ce-bea0-5a0158366485",
	0,
	0,
	10,
	37,
	44,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"e3f72ebf-598b-488d-8200-a60f3000b596");
INSERT INTO V_IRF
	VALUES ("6640c83f-8e5f-44ce-bea0-5a0158366485",
	"bd9997df-7641-4018-b192-218aaabb8991");
INSERT INTO V_VAL
	VALUES ("64883efc-5bf7-4898-aed2-94dd83dc915e",
	0,
	0,
	10,
	46,
	56,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e3f72ebf-598b-488d-8200-a60f3000b596");
INSERT INTO V_AVL
	VALUES ("64883efc-5bf7-4898-aed2-94dd83dc915e",
	"6640c83f-8e5f-44ce-bea0-5a0158366485",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("925e4fba-88e1-4456-8059-9bbf6f3a2b82",
	1,
	0,
	15,
	7,
	17,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e3f72ebf-598b-488d-8200-a60f3000b596");
INSERT INTO V_TVL
	VALUES ("925e4fba-88e1-4456-8059-9bbf6f3a2b82",
	"428a7dd6-18b9-4f07-aae0-d33f1ea19298");
INSERT INTO V_VAL
	VALUES ("3fd64c30-b3ae-4d66-93bc-690665ea568a",
	0,
	0,
	15,
	21,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e3f72ebf-598b-488d-8200-a60f3000b596");
INSERT INTO V_LIN
	VALUES ("3fd64c30-b3ae-4d66-93bc-690665ea568a",
	'1');
INSERT INTO V_VAR
	VALUES ("be542248-4b86-48bc-8190-e4e3e7f04a7b",
	"e3f72ebf-598b-488d-8200-a60f3000b596",
	'opencell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("be542248-4b86-48bc-8190-e4e3e7f04a7b",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("559ecc0a-b92c-456c-8e14-2996324132b2",
	9,
	18,
	25,
	"be542248-4b86-48bc-8190-e4e3e7f04a7b");
INSERT INTO V_LOC
	VALUES ("a6319f2e-eff1-4e95-be15-3c1cdfc365e4",
	10,
	12,
	19,
	"be542248-4b86-48bc-8190-e4e3e7f04a7b");
INSERT INTO V_LOC
	VALUES ("5b793f40-d3e9-4feb-9631-7a544a4bf379",
	11,
	35,
	42,
	"be542248-4b86-48bc-8190-e4e3e7f04a7b");
INSERT INTO ACT_BLK
	VALUES ("3e7d52c2-334b-4324-9022-39cd2ee303e2",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	9,
	0,
	0,
	0,
	0,
	11,
	51,
	0,
	0,
	0,
	0,
	0,
	"5b596a9f-bd90-47f2-a3ab-3ab38ae5ca82",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1d8a8a5a-0e78-4f87-9b20-e286b71c3113",
	"3e7d52c2-334b-4324-9022-39cd2ee303e2",
	"ba989345-a573-4bb1-9294-1973e2c20585",
	11,
	9,
	'column::prune line: 11');
INSERT INTO ACT_URU
	VALUES ("1d8a8a5a-0e78-4f87-9b20-e286b71c3113",
	"bbe07c00-5500-43d2-aaca-b93595a70c97",
	"be542248-4b86-48bc-8190-e4e3e7f04a7b",
	"bd9997df-7641-4018-b192-218aaabb8991",
	'',
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	11,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ba989345-a573-4bb1-9294-1973e2c20585",
	"3e7d52c2-334b-4324-9022-39cd2ee303e2",
	"00000000-0000-0000-0000-000000000000",
	12,
	9,
	'column::prune line: 12');
INSERT INTO ACT_DEL
	VALUES ("ba989345-a573-4bb1-9294-1973e2c20585",
	"bd9997df-7641-4018-b192-218aaabb8991");
INSERT INTO ACT_BLK
	VALUES ("e307453c-19e4-42e6-a567-dfa818d20c62",
	0,
	0,
	0,
	'',
	'',
	'',
	24,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"5b596a9f-bd90-47f2-a3ab-3ab38ae5ca82",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("a7070697-e943-4a43-b82e-a7345f1bf2de",
	"e307453c-19e4-42e6-a567-dfa818d20c62",
	"00000000-0000-0000-0000-000000000000",
	24,
	3,
	'column::prune line: 24');
INSERT INTO ACT_AI
	VALUES ("a7070697-e943-4a43-b82e-a7345f1bf2de",
	"ae926e73-6e24-450c-b328-0c5e6ade4eb8",
	"70e038d8-3fa0-49b0-8cab-5019821a6cd0",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("70e038d8-3fa0-49b0-8cab-5019821a6cd0",
	1,
	0,
	24,
	3,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e307453c-19e4-42e6-a567-dfa818d20c62");
INSERT INTO V_TVL
	VALUES ("70e038d8-3fa0-49b0-8cab-5019821a6cd0",
	"428a7dd6-18b9-4f07-aae0-d33f1ea19298");
INSERT INTO V_VAL
	VALUES ("ae926e73-6e24-450c-b328-0c5e6ade4eb8",
	0,
	0,
	24,
	17,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"e307453c-19e4-42e6-a567-dfa818d20c62");
INSERT INTO V_LIN
	VALUES ("ae926e73-6e24-450c-b328-0c5e6ade4eb8",
	'100');
INSERT INTO ACT_BLK
	VALUES ("6c9e3943-3936-4756-8c5d-a8e1f669940c",
	1,
	0,
	0,
	'',
	'',
	'',
	30,
	3,
	28,
	46,
	0,
	0,
	28,
	55,
	0,
	0,
	0,
	0,
	0,
	"5b596a9f-bd90-47f2-a3ab-3ab38ae5ca82",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c7e7120a-dc80-45b2-a0d4-ebe10f2e5040",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c",
	"d2eca8d7-7ca3-428f-9606-e5c9476ba9f6",
	28,
	3,
	'column::prune line: 28');
INSERT INTO ACT_SEL
	VALUES ("c7e7120a-dc80-45b2-a0d4-ebe10f2e5040",
	"083c3c09-82d4-481b-9f73-fbbb5f9ea459",
	0,
	'many',
	"38b487f1-cafa-4e38-8516-120e5c8671e4");
INSERT INTO ACT_SR
	VALUES ("c7e7120a-dc80-45b2-a0d4-ebe10f2e5040");
INSERT INTO ACT_LNK
	VALUES ("54db4ef4-51cf-46df-bf5c-d52d04995c82",
	'',
	"c7e7120a-dc80-45b2-a0d4-ebe10f2e5040",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	28,
	46,
	28,
	55,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d2eca8d7-7ca3-428f-9606-e5c9476ba9f6",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c",
	"a977050d-52ac-40be-b267-1e45510b98b7",
	29,
	3,
	'column::prune line: 29');
INSERT INTO ACT_AI
	VALUES ("d2eca8d7-7ca3-428f-9606-e5c9476ba9f6",
	"ea14fcf3-e4ee-4b67-9492-acaba57d81cd",
	"0bef0bd5-dd96-46f0-8853-e5464af6f12f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a977050d-52ac-40be-b267-1e45510b98b7",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c",
	"00000000-0000-0000-0000-000000000000",
	30,
	3,
	'column::prune line: 30');
INSERT INTO ACT_IF
	VALUES ("a977050d-52ac-40be-b267-1e45510b98b7",
	"02305bb4-6909-4677-afc3-4fe68197da2f",
	"9f1ecd16-f481-4e55-b3a5-899d4ce7e261",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("38b487f1-cafa-4e38-8516-120e5c8671e4",
	0,
	0,
	28,
	36,
	43,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c");
INSERT INTO V_IRF
	VALUES ("38b487f1-cafa-4e38-8516-120e5c8671e4",
	"93e0cf63-ee47-4d1f-b0e5-501b77b5c237");
INSERT INTO V_VAL
	VALUES ("0bef0bd5-dd96-46f0-8853-e5464af6f12f",
	1,
	1,
	29,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c");
INSERT INTO V_TVL
	VALUES ("0bef0bd5-dd96-46f0-8853-e5464af6f12f",
	"afb0bf73-ca13-477d-a967-cfefaa81478b");
INSERT INTO V_VAL
	VALUES ("fc375f47-bc91-4947-a675-996f319c08cc",
	0,
	0,
	29,
	19,
	27,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c");
INSERT INTO V_ISR
	VALUES ("fc375f47-bc91-4947-a675-996f319c08cc",
	"083c3c09-82d4-481b-9f73-fbbb5f9ea459");
INSERT INTO V_VAL
	VALUES ("ea14fcf3-e4ee-4b67-9492-acaba57d81cd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c");
INSERT INTO V_UNY
	VALUES ("ea14fcf3-e4ee-4b67-9492-acaba57d81cd",
	"fc375f47-bc91-4947-a675-996f319c08cc",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("dc693013-d9e6-456b-a3b5-6601cde4150c",
	0,
	0,
	30,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c");
INSERT INTO V_LIN
	VALUES ("dc693013-d9e6-456b-a3b5-6601cde4150c",
	'1');
INSERT INTO V_VAL
	VALUES ("9f1ecd16-f481-4e55-b3a5-899d4ce7e261",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c");
INSERT INTO V_BIN
	VALUES ("9f1ecd16-f481-4e55-b3a5-899d4ce7e261",
	"b1e90488-0bdd-4739-9dc3-47b064753c82",
	"dc693013-d9e6-456b-a3b5-6601cde4150c",
	'==');
INSERT INTO V_VAL
	VALUES ("b1e90488-0bdd-4739-9dc3-47b064753c82",
	0,
	0,
	30,
	13,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c");
INSERT INTO V_TVL
	VALUES ("b1e90488-0bdd-4739-9dc3-47b064753c82",
	"afb0bf73-ca13-477d-a967-cfefaa81478b");
INSERT INTO V_VAR
	VALUES ("afb0bf73-ca13-477d-a967-cfefaa81478b",
	"6c9e3943-3936-4756-8c5d-a8e1f669940c",
	'c',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("afb0bf73-ca13-477d-a967-cfefaa81478b",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("c29825ef-3a84-4c7d-a1b3-c7b6d4969b28",
	29,
	3,
	3,
	"afb0bf73-ca13-477d-a967-cfefaa81478b");
INSERT INTO V_LOC
	VALUES ("a8ce4d64-5b04-421b-b89e-a42fbb925ec9",
	30,
	13,
	13,
	"afb0bf73-ca13-477d-a967-cfefaa81478b");
INSERT INTO ACT_BLK
	VALUES ("02305bb4-6909-4677-afc3-4fe68197da2f",
	1,
	0,
	0,
	'',
	'',
	'',
	34,
	5,
	31,
	44,
	0,
	0,
	31,
	53,
	0,
	0,
	0,
	0,
	0,
	"5b596a9f-bd90-47f2-a3ab-3ab38ae5ca82",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ab24ec95-6f63-44bb-99d6-19dc45b6b83a",
	"02305bb4-6909-4677-afc3-4fe68197da2f",
	"26b85b2a-f6f8-4c16-ab89-1c0df527986d",
	31,
	5,
	'column::prune line: 31');
INSERT INTO ACT_SEL
	VALUES ("ab24ec95-6f63-44bb-99d6-19dc45b6b83a",
	"7c59b9a6-6049-4269-a8b6-61353cf2db3f",
	1,
	'any',
	"c6b0d4b6-0bd1-4049-92f1-1c643003cfc0");
INSERT INTO ACT_SR
	VALUES ("ab24ec95-6f63-44bb-99d6-19dc45b6b83a");
INSERT INTO ACT_LNK
	VALUES ("a63e643a-6a0d-4900-a04d-5a93b0db5fcd",
	'',
	"ab24ec95-6f63-44bb-99d6-19dc45b6b83a",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	31,
	44,
	31,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("26b85b2a-f6f8-4c16-ab89-1c0df527986d",
	"02305bb4-6909-4677-afc3-4fe68197da2f",
	"b47101f8-1f14-4cb4-837f-dcfed12f5c20",
	32,
	5,
	'column::prune line: 32');
INSERT INTO ACT_TFM
	VALUES ("26b85b2a-f6f8-4c16-ab89-1c0df527986d",
	"4dbd3878-9ff1-4fa9-8ff2-db063b3aa997",
	"93e0cf63-ee47-4d1f-b0e5-501b77b5c237",
	32,
	14,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b47101f8-1f14-4cb4-837f-dcfed12f5c20",
	"02305bb4-6909-4677-afc3-4fe68197da2f",
	"00000000-0000-0000-0000-000000000000",
	34,
	5,
	'column::prune line: 34');
INSERT INTO ACT_AI
	VALUES ("b47101f8-1f14-4cb4-837f-dcfed12f5c20",
	"49c84d31-6eb2-4753-8101-d0ff22d61761",
	"e841e369-5c21-407f-a84c-08be18165a70",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("c6b0d4b6-0bd1-4049-92f1-1c643003cfc0",
	0,
	0,
	31,
	34,
	41,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"02305bb4-6909-4677-afc3-4fe68197da2f");
INSERT INTO V_IRF
	VALUES ("c6b0d4b6-0bd1-4049-92f1-1c643003cfc0",
	"93e0cf63-ee47-4d1f-b0e5-501b77b5c237");
INSERT INTO V_VAL
	VALUES ("bf49a374-1332-4ef3-90c6-1594b1bee049",
	0,
	0,
	32,
	35,
	40,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"02305bb4-6909-4677-afc3-4fe68197da2f");
INSERT INTO V_IRF
	VALUES ("bf49a374-1332-4ef3-90c6-1594b1bee049",
	"7c59b9a6-6049-4269-a8b6-61353cf2db3f");
INSERT INTO V_VAL
	VALUES ("466397d0-166d-459c-8af7-944da32d631d",
	0,
	0,
	32,
	42,
	52,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"02305bb4-6909-4677-afc3-4fe68197da2f");
INSERT INTO V_AVL
	VALUES ("466397d0-166d-459c-8af7-944da32d631d",
	"bf49a374-1332-4ef3-90c6-1594b1bee049",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_PAR
	VALUES ("466397d0-166d-459c-8af7-944da32d631d",
	"26b85b2a-f6f8-4c16-ab89-1c0df527986d",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	32,
	22);
INSERT INTO V_VAL
	VALUES ("e841e369-5c21-407f-a84c-08be18165a70",
	1,
	0,
	34,
	5,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"02305bb4-6909-4677-afc3-4fe68197da2f");
INSERT INTO V_TVL
	VALUES ("e841e369-5c21-407f-a84c-08be18165a70",
	"428a7dd6-18b9-4f07-aae0-d33f1ea19298");
INSERT INTO V_VAL
	VALUES ("49c84d31-6eb2-4753-8101-d0ff22d61761",
	0,
	0,
	34,
	19,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"02305bb4-6909-4677-afc3-4fe68197da2f");
INSERT INTO V_LIN
	VALUES ("49c84d31-6eb2-4753-8101-d0ff22d61761",
	'1');
INSERT INTO V_VAR
	VALUES ("7c59b9a6-6049-4269-a8b6-61353cf2db3f",
	"02305bb4-6909-4677-afc3-4fe68197da2f",
	'answer',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("7c59b9a6-6049-4269-a8b6-61353cf2db3f",
	0,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("8b13edda-9ae7-4009-9289-c0e24d59756a",
	31,
	16,
	21,
	"7c59b9a6-6049-4269-a8b6-61353cf2db3f");
INSERT INTO V_LOC
	VALUES ("e2d6bb1b-4659-46ea-9294-3d755c757e42",
	32,
	35,
	40,
	"7c59b9a6-6049-4269-a8b6-61353cf2db3f");
INSERT INTO O_TFR
	VALUES ("e184be1e-e976-4c07-baa6-c4de41296f45",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	'eliminate',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	1,
	'// Solve by select all eligible digits.  Notice if any eligible digit appears only once.

temperature = 0;
select many eligibles related by self->CELL[R3]->ELIGIBLE[R8];
c = cardinality eligibles;
if ( 9 == c )
  temperature = 100;
else
for each eligible in eligibles
  select many loners related by self->CELL[R3]->ELIGIBLE[R8]
    where ( selected.digit_value == eligible.digit_value );
  c = cardinality loners;
  if ( 1 == c )
    // This is an answer!
    select one cell related by eligible->CELL[R8];
    cell.answer( answer_digit:eligible.digit_value );
    // generate CELL2:answer( digit:eligible.digit_value ) to cell;
    temperature = 1;
    break;
  end if;
end for;
end if;
return temperature;
',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_OPB
	VALUES ("7d3a104f-ad64-4ccb-8088-58d811ec8cec",
	"e184be1e-e976-4c07-baa6-c4de41296f45");
INSERT INTO ACT_ACT
	VALUES ("7d3a104f-ad64-4ccb-8088-58d811ec8cec",
	'operation',
	0,
	"16da37a0-1028-44d3-99f7-7843210b131a",
	"00000000-0000-0000-0000-000000000000",
	0,
	'column::eliminate',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("16da37a0-1028-44d3-99f7-7843210b131a",
	1,
	0,
	0,
	'',
	'',
	'',
	23,
	1,
	4,
	50,
	0,
	0,
	4,
	59,
	0,
	0,
	0,
	0,
	0,
	"7d3a104f-ad64-4ccb-8088-58d811ec8cec",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b420cb30-3049-437a-b199-def85fc3b3ea",
	"16da37a0-1028-44d3-99f7-7843210b131a",
	"deee95e8-ae8e-4f3b-8c5d-19ed4de14fad",
	3,
	1,
	'column::eliminate line: 3');
INSERT INTO ACT_AI
	VALUES ("b420cb30-3049-437a-b199-def85fc3b3ea",
	"d64573e2-6e65-4bac-ad27-e5096ab43d80",
	"bfdc5138-7945-40f3-907d-7f2e40185cec",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("deee95e8-ae8e-4f3b-8c5d-19ed4de14fad",
	"16da37a0-1028-44d3-99f7-7843210b131a",
	"90e5c937-af6d-4c3d-bbad-f93269a21d65",
	4,
	1,
	'column::eliminate line: 4');
INSERT INTO ACT_SEL
	VALUES ("deee95e8-ae8e-4f3b-8c5d-19ed4de14fad",
	"c6595314-d6d7-43ec-a503-8cbace3a90d9",
	1,
	'many',
	"be43ce3c-f10f-4aab-af84-5126b8dacfcd");
INSERT INTO ACT_SR
	VALUES ("deee95e8-ae8e-4f3b-8c5d-19ed4de14fad");
INSERT INTO ACT_LNK
	VALUES ("6b56db27-5a80-43ff-b6b4-2fed1bf66bd8",
	'',
	"deee95e8-ae8e-4f3b-8c5d-19ed4de14fad",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"d0a0efa0-3678-44e5-ae78-155d054905a3",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	4,
	40,
	4,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("d0a0efa0-3678-44e5-ae78-155d054905a3",
	'',
	"00000000-0000-0000-0000-000000000000",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	4,
	50,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("90e5c937-af6d-4c3d-bbad-f93269a21d65",
	"16da37a0-1028-44d3-99f7-7843210b131a",
	"159187b4-1f3c-4f6e-b640-793878584fdf",
	5,
	1,
	'column::eliminate line: 5');
INSERT INTO ACT_AI
	VALUES ("90e5c937-af6d-4c3d-bbad-f93269a21d65",
	"fca1815d-dd67-4aa9-90fd-25e481830419",
	"55327f74-11f8-4998-bac6-a4c3651b0b5f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("159187b4-1f3c-4f6e-b640-793878584fdf",
	"16da37a0-1028-44d3-99f7-7843210b131a",
	"c46ac4c0-7bd5-447f-ba84-a1bd41a99f27",
	6,
	1,
	'column::eliminate line: 6');
INSERT INTO ACT_IF
	VALUES ("159187b4-1f3c-4f6e-b640-793878584fdf",
	"90d2d141-bd25-420f-9629-8d7a4109c86c",
	"53b01ba1-f638-48cb-9819-aa3f2140b117",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("142b38f0-4651-426b-8c9a-4109f74c787c",
	"16da37a0-1028-44d3-99f7-7843210b131a",
	"00000000-0000-0000-0000-000000000000",
	8,
	1,
	'column::eliminate line: 8');
INSERT INTO ACT_E
	VALUES ("142b38f0-4651-426b-8c9a-4109f74c787c",
	"d506d3ca-a152-4161-b78b-1c276cae33dd",
	"159187b4-1f3c-4f6e-b640-793878584fdf");
INSERT INTO ACT_SMT
	VALUES ("c46ac4c0-7bd5-447f-ba84-a1bd41a99f27",
	"16da37a0-1028-44d3-99f7-7843210b131a",
	"00000000-0000-0000-0000-000000000000",
	23,
	1,
	'column::eliminate line: 23');
INSERT INTO ACT_RET
	VALUES ("c46ac4c0-7bd5-447f-ba84-a1bd41a99f27",
	"27afb9b3-caf9-44ce-b506-f46b16617279");
INSERT INTO V_VAL
	VALUES ("bfdc5138-7945-40f3-907d-7f2e40185cec",
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"16da37a0-1028-44d3-99f7-7843210b131a");
INSERT INTO V_TVL
	VALUES ("bfdc5138-7945-40f3-907d-7f2e40185cec",
	"ceb23edb-6b21-4cda-bb5e-d42af132b099");
INSERT INTO V_VAL
	VALUES ("d64573e2-6e65-4bac-ad27-e5096ab43d80",
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"16da37a0-1028-44d3-99f7-7843210b131a");
INSERT INTO V_LIN
	VALUES ("d64573e2-6e65-4bac-ad27-e5096ab43d80",
	'0');
INSERT INTO V_VAL
	VALUES ("be43ce3c-f10f-4aab-af84-5126b8dacfcd",
	0,
	0,
	4,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"16da37a0-1028-44d3-99f7-7843210b131a");
INSERT INTO V_IRF
	VALUES ("be43ce3c-f10f-4aab-af84-5126b8dacfcd",
	"9999b346-e41d-4379-a788-c25dd0213185");
INSERT INTO V_VAL
	VALUES ("55327f74-11f8-4998-bac6-a4c3651b0b5f",
	1,
	1,
	5,
	1,
	1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"16da37a0-1028-44d3-99f7-7843210b131a");
INSERT INTO V_TVL
	VALUES ("55327f74-11f8-4998-bac6-a4c3651b0b5f",
	"1c04d186-4d54-4325-8bf4-cdb4008bba1b");
INSERT INTO V_VAL
	VALUES ("433c3444-4f6a-4db0-97ed-483c2c25c6e6",
	0,
	0,
	5,
	17,
	25,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"16da37a0-1028-44d3-99f7-7843210b131a");
INSERT INTO V_ISR
	VALUES ("433c3444-4f6a-4db0-97ed-483c2c25c6e6",
	"c6595314-d6d7-43ec-a503-8cbace3a90d9");
INSERT INTO V_VAL
	VALUES ("fca1815d-dd67-4aa9-90fd-25e481830419",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"16da37a0-1028-44d3-99f7-7843210b131a");
INSERT INTO V_UNY
	VALUES ("fca1815d-dd67-4aa9-90fd-25e481830419",
	"433c3444-4f6a-4db0-97ed-483c2c25c6e6",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("b0e5d24c-27b8-4126-9b9f-6b71a23fe6cf",
	0,
	0,
	6,
	6,
	6,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"16da37a0-1028-44d3-99f7-7843210b131a");
INSERT INTO V_LIN
	VALUES ("b0e5d24c-27b8-4126-9b9f-6b71a23fe6cf",
	'9');
INSERT INTO V_VAL
	VALUES ("53b01ba1-f638-48cb-9819-aa3f2140b117",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"16da37a0-1028-44d3-99f7-7843210b131a");
INSERT INTO V_BIN
	VALUES ("53b01ba1-f638-48cb-9819-aa3f2140b117",
	"a910f836-c23c-43bd-965e-7183cfe7e376",
	"b0e5d24c-27b8-4126-9b9f-6b71a23fe6cf",
	'==');
INSERT INTO V_VAL
	VALUES ("a910f836-c23c-43bd-965e-7183cfe7e376",
	0,
	0,
	6,
	11,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"16da37a0-1028-44d3-99f7-7843210b131a");
INSERT INTO V_TVL
	VALUES ("a910f836-c23c-43bd-965e-7183cfe7e376",
	"1c04d186-4d54-4325-8bf4-cdb4008bba1b");
INSERT INTO V_VAL
	VALUES ("27afb9b3-caf9-44ce-b506-f46b16617279",
	0,
	0,
	23,
	8,
	18,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"16da37a0-1028-44d3-99f7-7843210b131a");
INSERT INTO V_TVL
	VALUES ("27afb9b3-caf9-44ce-b506-f46b16617279",
	"ceb23edb-6b21-4cda-bb5e-d42af132b099");
INSERT INTO V_VAR
	VALUES ("ceb23edb-6b21-4cda-bb5e-d42af132b099",
	"16da37a0-1028-44d3-99f7-7843210b131a",
	'temperature',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("ceb23edb-6b21-4cda-bb5e-d42af132b099",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("ac15b842-51f0-402d-a729-9fb84279d9bb",
	3,
	1,
	11,
	"ceb23edb-6b21-4cda-bb5e-d42af132b099");
INSERT INTO V_LOC
	VALUES ("a11a61c8-1dd6-48c3-9531-23c3f43a9b45",
	7,
	3,
	13,
	"ceb23edb-6b21-4cda-bb5e-d42af132b099");
INSERT INTO V_LOC
	VALUES ("af5b1237-9c0b-4a34-893d-06a8518bf9f3",
	18,
	5,
	15,
	"ceb23edb-6b21-4cda-bb5e-d42af132b099");
INSERT INTO V_LOC
	VALUES ("8e69afbe-bdcb-4daf-9e01-3847e357b478",
	23,
	8,
	18,
	"ceb23edb-6b21-4cda-bb5e-d42af132b099");
INSERT INTO V_VAR
	VALUES ("c6595314-d6d7-43ec-a503-8cbace3a90d9",
	"16da37a0-1028-44d3-99f7-7843210b131a",
	'eligibles',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("c6595314-d6d7-43ec-a503-8cbace3a90d9",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("6d026f55-1203-4cef-bab9-33576c2eb098",
	4,
	13,
	21,
	"c6595314-d6d7-43ec-a503-8cbace3a90d9");
INSERT INTO V_LOC
	VALUES ("35f0f361-9f0d-4315-8577-c7abf20e45df",
	9,
	22,
	30,
	"c6595314-d6d7-43ec-a503-8cbace3a90d9");
INSERT INTO V_VAR
	VALUES ("9999b346-e41d-4379-a788-c25dd0213185",
	"16da37a0-1028-44d3-99f7-7843210b131a",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("9999b346-e41d-4379-a788-c25dd0213185",
	0,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_VAR
	VALUES ("1c04d186-4d54-4325-8bf4-cdb4008bba1b",
	"16da37a0-1028-44d3-99f7-7843210b131a",
	'c',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("1c04d186-4d54-4325-8bf4-cdb4008bba1b",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("455fea51-7c08-4833-bd17-e7885eedccac",
	5,
	1,
	1,
	"1c04d186-4d54-4325-8bf4-cdb4008bba1b");
INSERT INTO V_LOC
	VALUES ("a2520d49-43fe-4e60-a74b-e1320ba7babb",
	6,
	11,
	11,
	"1c04d186-4d54-4325-8bf4-cdb4008bba1b");
INSERT INTO V_LOC
	VALUES ("6d21ed07-18f7-4aa4-a75c-0bc7ed2ba09a",
	12,
	3,
	3,
	"1c04d186-4d54-4325-8bf4-cdb4008bba1b");
INSERT INTO V_LOC
	VALUES ("7fb8aab1-6a58-494b-8453-0b2fd45581f4",
	13,
	13,
	13,
	"1c04d186-4d54-4325-8bf4-cdb4008bba1b");
INSERT INTO ACT_BLK
	VALUES ("90d2d141-bd25-420f-9629-8d7a4109c86c",
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7d3a104f-ad64-4ccb-8088-58d811ec8cec",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7fc93c11-ed3b-4f4c-9b9e-f3eac7aea87b",
	"90d2d141-bd25-420f-9629-8d7a4109c86c",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'column::eliminate line: 7');
INSERT INTO ACT_AI
	VALUES ("7fc93c11-ed3b-4f4c-9b9e-f3eac7aea87b",
	"be5e72bd-a569-4c75-8843-ea19fc265832",
	"0847c3c3-e018-4c92-bf41-53e0fdca65e2",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("0847c3c3-e018-4c92-bf41-53e0fdca65e2",
	1,
	0,
	7,
	3,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"90d2d141-bd25-420f-9629-8d7a4109c86c");
INSERT INTO V_TVL
	VALUES ("0847c3c3-e018-4c92-bf41-53e0fdca65e2",
	"ceb23edb-6b21-4cda-bb5e-d42af132b099");
INSERT INTO V_VAL
	VALUES ("be5e72bd-a569-4c75-8843-ea19fc265832",
	0,
	0,
	7,
	17,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"90d2d141-bd25-420f-9629-8d7a4109c86c");
INSERT INTO V_LIN
	VALUES ("be5e72bd-a569-4c75-8843-ea19fc265832",
	'100');
INSERT INTO ACT_BLK
	VALUES ("d506d3ca-a152-4161-b78b-1c276cae33dd",
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7d3a104f-ad64-4ccb-8088-58d811ec8cec",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f6c96456-2485-469e-a709-b957f1bdbfea",
	"d506d3ca-a152-4161-b78b-1c276cae33dd",
	"00000000-0000-0000-0000-000000000000",
	9,
	1,
	'column::eliminate line: 9');
INSERT INTO ACT_FOR
	VALUES ("f6c96456-2485-469e-a709-b957f1bdbfea",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f",
	1,
	"7d79998c-053c-4bb7-8d9e-dde8552c7744",
	"c6595314-d6d7-43ec-a503-8cbace3a90d9",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_VAR
	VALUES ("7d79998c-053c-4bb7-8d9e-dde8552c7744",
	"d506d3ca-a152-4161-b78b-1c276cae33dd",
	'eligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("7d79998c-053c-4bb7-8d9e-dde8552c7744",
	1,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("aa7a8796-236a-489b-9d21-c872967f02e8",
	9,
	10,
	17,
	"7d79998c-053c-4bb7-8d9e-dde8552c7744");
INSERT INTO V_LOC
	VALUES ("45b81197-42e7-4c9b-bf8b-02913e35660a",
	11,
	37,
	44,
	"7d79998c-053c-4bb7-8d9e-dde8552c7744");
INSERT INTO V_LOC
	VALUES ("ec2e7a8a-9963-4b7e-a7d9-ff65f694e393",
	16,
	31,
	38,
	"7d79998c-053c-4bb7-8d9e-dde8552c7744");
INSERT INTO ACT_BLK
	VALUES ("f73b77ea-f05e-4020-92fb-3fe70da94b4f",
	1,
	0,
	1,
	'',
	'',
	'',
	13,
	3,
	10,
	49,
	0,
	0,
	10,
	58,
	0,
	0,
	0,
	0,
	0,
	"7d3a104f-ad64-4ccb-8088-58d811ec8cec",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b5443fc8-9c31-4a27-84d2-ff8e6b7e67ce",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f",
	"aa8e874e-1d1d-441e-8bf1-0215ef2200f1",
	10,
	3,
	'column::eliminate line: 10');
INSERT INTO ACT_SEL
	VALUES ("b5443fc8-9c31-4a27-84d2-ff8e6b7e67ce",
	"10db8bd2-2966-4d0e-8ac4-7de9defedb2f",
	1,
	'many',
	"a80262ad-bca6-4db3-9f84-53135d9de336");
INSERT INTO ACT_SRW
	VALUES ("b5443fc8-9c31-4a27-84d2-ff8e6b7e67ce",
	"60dddd9b-25e7-42f5-8ceb-ec7af78e5645");
INSERT INTO ACT_LNK
	VALUES ("06b413bd-55d1-446b-bc45-19feea9736ed",
	'',
	"b5443fc8-9c31-4a27-84d2-ff8e6b7e67ce",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"1ab632af-764c-41ed-a191-73948e3a74f0",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	10,
	39,
	10,
	44,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("1ab632af-764c-41ed-a191-73948e3a74f0",
	'',
	"00000000-0000-0000-0000-000000000000",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	10,
	49,
	10,
	58,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("aa8e874e-1d1d-441e-8bf1-0215ef2200f1",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f",
	"d03381bd-40d2-4cb8-a2a8-c25f83f53984",
	12,
	3,
	'column::eliminate line: 12');
INSERT INTO ACT_AI
	VALUES ("aa8e874e-1d1d-441e-8bf1-0215ef2200f1",
	"ec05ea83-5c15-4228-8d9e-85d62a1e6b38",
	"49d2ed3f-8305-48e6-9ebe-0be76558794b",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d03381bd-40d2-4cb8-a2a8-c25f83f53984",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f",
	"00000000-0000-0000-0000-000000000000",
	13,
	3,
	'column::eliminate line: 13');
INSERT INTO ACT_IF
	VALUES ("d03381bd-40d2-4cb8-a2a8-c25f83f53984",
	"ebd77280-b289-4d0e-8396-28a89c99ee73",
	"aeceaade-d3ba-44a3-acdc-1d260912a215",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("a80262ad-bca6-4db3-9f84-53135d9de336",
	0,
	0,
	10,
	33,
	36,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_IRF
	VALUES ("a80262ad-bca6-4db3-9f84-53135d9de336",
	"9999b346-e41d-4379-a788-c25dd0213185");
INSERT INTO V_VAL
	VALUES ("7fc32f2e-a794-49a4-9f67-b5d9e252c9fa",
	0,
	0,
	11,
	13,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_SLR
	VALUES ("7fc32f2e-a794-49a4-9f67-b5d9e252c9fa",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("2a13a910-07e2-4a9c-9cd4-3f6186d89628",
	0,
	0,
	11,
	22,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_AVL
	VALUES ("2a13a910-07e2-4a9c-9cd4-3f6186d89628",
	"7fc32f2e-a794-49a4-9f67-b5d9e252c9fa",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("60dddd9b-25e7-42f5-8ceb-ec7af78e5645",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_BIN
	VALUES ("60dddd9b-25e7-42f5-8ceb-ec7af78e5645",
	"2cf77731-b568-4af4-b824-da95467515b3",
	"2a13a910-07e2-4a9c-9cd4-3f6186d89628",
	'==');
INSERT INTO V_VAL
	VALUES ("ae78f5ff-0780-4e3c-b1e2-aed61f885cf4",
	0,
	0,
	11,
	37,
	44,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_IRF
	VALUES ("ae78f5ff-0780-4e3c-b1e2-aed61f885cf4",
	"7d79998c-053c-4bb7-8d9e-dde8552c7744");
INSERT INTO V_VAL
	VALUES ("2cf77731-b568-4af4-b824-da95467515b3",
	0,
	0,
	11,
	46,
	56,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_AVL
	VALUES ("2cf77731-b568-4af4-b824-da95467515b3",
	"ae78f5ff-0780-4e3c-b1e2-aed61f885cf4",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("49d2ed3f-8305-48e6-9ebe-0be76558794b",
	1,
	0,
	12,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_TVL
	VALUES ("49d2ed3f-8305-48e6-9ebe-0be76558794b",
	"1c04d186-4d54-4325-8bf4-cdb4008bba1b");
INSERT INTO V_VAL
	VALUES ("41bcd67b-826b-41df-965a-eea97bdd3232",
	0,
	0,
	12,
	19,
	24,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_ISR
	VALUES ("41bcd67b-826b-41df-965a-eea97bdd3232",
	"10db8bd2-2966-4d0e-8ac4-7de9defedb2f");
INSERT INTO V_VAL
	VALUES ("ec05ea83-5c15-4228-8d9e-85d62a1e6b38",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_UNY
	VALUES ("ec05ea83-5c15-4228-8d9e-85d62a1e6b38",
	"41bcd67b-826b-41df-965a-eea97bdd3232",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("fda5fceb-3d44-495e-96fc-0ef9852005e4",
	0,
	0,
	13,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_LIN
	VALUES ("fda5fceb-3d44-495e-96fc-0ef9852005e4",
	'1');
INSERT INTO V_VAL
	VALUES ("aeceaade-d3ba-44a3-acdc-1d260912a215",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_BIN
	VALUES ("aeceaade-d3ba-44a3-acdc-1d260912a215",
	"605528a1-21ef-4fc8-ba98-5ec91f2cefac",
	"fda5fceb-3d44-495e-96fc-0ef9852005e4",
	'==');
INSERT INTO V_VAL
	VALUES ("605528a1-21ef-4fc8-ba98-5ec91f2cefac",
	0,
	0,
	13,
	13,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f");
INSERT INTO V_TVL
	VALUES ("605528a1-21ef-4fc8-ba98-5ec91f2cefac",
	"1c04d186-4d54-4325-8bf4-cdb4008bba1b");
INSERT INTO V_VAR
	VALUES ("10db8bd2-2966-4d0e-8ac4-7de9defedb2f",
	"f73b77ea-f05e-4020-92fb-3fe70da94b4f",
	'loners',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("10db8bd2-2966-4d0e-8ac4-7de9defedb2f",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("452075ec-e8a7-410d-a333-bcedf3c96e48",
	10,
	15,
	20,
	"10db8bd2-2966-4d0e-8ac4-7de9defedb2f");
INSERT INTO ACT_BLK
	VALUES ("ebd77280-b289-4d0e-8396-28a89c99ee73",
	1,
	0,
	0,
	'',
	'',
	'',
	19,
	5,
	15,
	42,
	0,
	0,
	15,
	47,
	0,
	0,
	0,
	0,
	0,
	"7d3a104f-ad64-4ccb-8088-58d811ec8cec",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("174b7b68-7824-4fab-9056-f960770085eb",
	"ebd77280-b289-4d0e-8396-28a89c99ee73",
	"7ddf236c-e832-4fdd-af36-eac8fbd83052",
	15,
	5,
	'column::eliminate line: 15');
INSERT INTO ACT_SEL
	VALUES ("174b7b68-7824-4fab-9056-f960770085eb",
	"54455580-d6ef-4d6b-9e03-81f917dbe633",
	1,
	'one',
	"32b09b28-481e-4b71-8b34-626e42c1381e");
INSERT INTO ACT_SR
	VALUES ("174b7b68-7824-4fab-9056-f960770085eb");
INSERT INTO ACT_LNK
	VALUES ("241f5d41-20f5-4fc7-a371-fa217a8d9b89",
	'',
	"174b7b68-7824-4fab-9056-f960770085eb",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	15,
	42,
	15,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7ddf236c-e832-4fdd-af36-eac8fbd83052",
	"ebd77280-b289-4d0e-8396-28a89c99ee73",
	"e892b841-5405-421d-bbcd-08ae6a4d23a2",
	16,
	5,
	'column::eliminate line: 16');
INSERT INTO ACT_TFM
	VALUES ("7ddf236c-e832-4fdd-af36-eac8fbd83052",
	"4dbd3878-9ff1-4fa9-8ff2-db063b3aa997",
	"54455580-d6ef-4d6b-9e03-81f917dbe633",
	16,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e892b841-5405-421d-bbcd-08ae6a4d23a2",
	"ebd77280-b289-4d0e-8396-28a89c99ee73",
	"7e05506c-f50a-4b78-b930-8d73b5fe1ecb",
	18,
	5,
	'column::eliminate line: 18');
INSERT INTO ACT_AI
	VALUES ("e892b841-5405-421d-bbcd-08ae6a4d23a2",
	"15f61408-4357-4e6b-90d3-7926f54f95ea",
	"e6f9c2d5-d65c-4009-b948-b29b319ee0e3",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7e05506c-f50a-4b78-b930-8d73b5fe1ecb",
	"ebd77280-b289-4d0e-8396-28a89c99ee73",
	"00000000-0000-0000-0000-000000000000",
	19,
	5,
	'column::eliminate line: 19');
INSERT INTO ACT_BRK
	VALUES ("7e05506c-f50a-4b78-b930-8d73b5fe1ecb");
INSERT INTO V_VAL
	VALUES ("32b09b28-481e-4b71-8b34-626e42c1381e",
	0,
	0,
	15,
	32,
	39,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"ebd77280-b289-4d0e-8396-28a89c99ee73");
INSERT INTO V_IRF
	VALUES ("32b09b28-481e-4b71-8b34-626e42c1381e",
	"7d79998c-053c-4bb7-8d9e-dde8552c7744");
INSERT INTO V_VAL
	VALUES ("744db8cb-e0de-465f-9c00-8aedbd207d88",
	0,
	0,
	16,
	31,
	38,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"ebd77280-b289-4d0e-8396-28a89c99ee73");
INSERT INTO V_IRF
	VALUES ("744db8cb-e0de-465f-9c00-8aedbd207d88",
	"7d79998c-053c-4bb7-8d9e-dde8552c7744");
INSERT INTO V_VAL
	VALUES ("5fa1e049-13db-4677-b71c-6216e3ccd889",
	0,
	0,
	16,
	40,
	50,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ebd77280-b289-4d0e-8396-28a89c99ee73");
INSERT INTO V_AVL
	VALUES ("5fa1e049-13db-4677-b71c-6216e3ccd889",
	"744db8cb-e0de-465f-9c00-8aedbd207d88",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_PAR
	VALUES ("5fa1e049-13db-4677-b71c-6216e3ccd889",
	"7ddf236c-e832-4fdd-af36-eac8fbd83052",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	16,
	18);
INSERT INTO V_VAL
	VALUES ("e6f9c2d5-d65c-4009-b948-b29b319ee0e3",
	1,
	0,
	18,
	5,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ebd77280-b289-4d0e-8396-28a89c99ee73");
INSERT INTO V_TVL
	VALUES ("e6f9c2d5-d65c-4009-b948-b29b319ee0e3",
	"ceb23edb-6b21-4cda-bb5e-d42af132b099");
INSERT INTO V_VAL
	VALUES ("15f61408-4357-4e6b-90d3-7926f54f95ea",
	0,
	0,
	18,
	19,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ebd77280-b289-4d0e-8396-28a89c99ee73");
INSERT INTO V_LIN
	VALUES ("15f61408-4357-4e6b-90d3-7926f54f95ea",
	'1');
INSERT INTO V_VAR
	VALUES ("54455580-d6ef-4d6b-9e03-81f917dbe633",
	"ebd77280-b289-4d0e-8396-28a89c99ee73",
	'cell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("54455580-d6ef-4d6b-9e03-81f917dbe633",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("5b171d34-e671-48a7-8daf-29359e63f090",
	15,
	16,
	19,
	"54455580-d6ef-4d6b-9e03-81f917dbe633");
INSERT INTO V_LOC
	VALUES ("30381238-b6c9-4263-86a7-922104ccc43a",
	16,
	5,
	8,
	"54455580-d6ef-4d6b-9e03-81f917dbe633");
INSERT INTO O_NBATTR
	VALUES ("f26a153c-9ca1-42f0-b8e3-a33ce851c778",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO O_BATTR
	VALUES ("f26a153c-9ca1-42f0-b8e3-a33ce851c778",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO O_ATTR
	VALUES ("f26a153c-9ca1-42f0-b8e3-a33ce851c778",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	"00000000-0000-0000-0000-000000000000",
	'number',
	'',
	'',
	'number',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("be055c7d-d193-46c5-a266-7086de7d3798",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO O_BATTR
	VALUES ("be055c7d-d193-46c5-a266-7086de7d3798",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO O_ATTR
	VALUES ("be055c7d-d193-46c5-a266-7086de7d3798",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	"f26a153c-9ca1-42f0-b8e3-a33ce851c778",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"65468da2-1083-4089-81cf-f2430c0ade46",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO O_ID
	VALUES (1,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO O_OIDA
	VALUES ("f26a153c-9ca1-42f0-b8e3-a33ce851c778",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	1);
INSERT INTO O_ID
	VALUES (2,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO SM_ISM
	VALUES ("6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO SM_SM
	VALUES ("6d077a0b-5a9a-45f1-873c-3c19271cd019",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("6d077a0b-5a9a-45f1-873c-3c19271cd019");
INSERT INTO SM_LEVT
	VALUES ("5fd7dc66-b6f4-42c9-b56e-583a604d532b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("5fd7dc66-b6f4-42c9-b56e-583a604d532b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("5fd7dc66-b6f4-42c9-b56e-583a604d532b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000",
	1,
	'update',
	0,
	'',
	'COLUMN1',
	'');
INSERT INTO SM_LEVT
	VALUES ("ab07d48c-ad8e-4ed3-a271-a874cc6faed8",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("ab07d48c-ad8e-4ed3-a271-a874cc6faed8",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("ab07d48c-ad8e-4ed3-a271-a874cc6faed8",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000",
	2,
	'solved',
	0,
	'',
	'COLUMN2',
	'');
INSERT INTO SM_STATE
	VALUES ("8b353543-deb1-4dfa-967d-8b87103c03ac",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000",
	'solving',
	1,
	0);
INSERT INTO SM_SEME
	VALUES ("8b353543-deb1-4dfa-967d-8b87103c03ac",
	"5fd7dc66-b6f4-42c9-b56e-583a604d532b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("8b353543-deb1-4dfa-967d-8b87103c03ac",
	"ab07d48c-ad8e-4ed3-a271-a874cc6faed8",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("8dd8d5fe-b160-4e7c-854c-d80462d6784b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"8b353543-deb1-4dfa-967d-8b87103c03ac");
INSERT INTO SM_AH
	VALUES ("8dd8d5fe-b160-4e7c-854c-d80462d6784b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019");
INSERT INTO SM_ACT
	VALUES ("8dd8d5fe-b160-4e7c-854c-d80462d6784b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	1,
	'if ( 100 == self.prune() )
  generate COLUMN2:solved() to self;
elif ( 100 == self.eliminate() )
  generate COLUMN2:solved() to self;
else
  select one sequence related by self->SEQUENCE[R1];
  if ( sequence.requests >= 1 )
    sequence.requests = 1;
    c = self;
    generate COLUMN1:update() to c;
  else
    sequence.requests = 0;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES ("9213d04a-0bd4-44b0-b7ca-e6d631e58f67",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"8dd8d5fe-b160-4e7c-854c-d80462d6784b");
INSERT INTO ACT_ACT
	VALUES ("9213d04a-0bd4-44b0-b7ca-e6d631e58f67",
	'state',
	0,
	"c4aab548-6695-4559-ba9d-a712abbe4aec",
	"00000000-0000-0000-0000-000000000000",
	0,
	'column::solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c4aab548-6695-4559-ba9d-a712abbe4aec",
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9213d04a-0bd4-44b0-b7ca-e6d631e58f67",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1e093ef4-598f-443a-8e4a-22b5f706cd1c",
	"c4aab548-6695-4559-ba9d-a712abbe4aec",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'column::solving line: 1');
INSERT INTO ACT_IF
	VALUES ("1e093ef4-598f-443a-8e4a-22b5f706cd1c",
	"88b350d3-fc91-40c9-ab32-dc90df209a83",
	"4816666a-fd3d-4eed-b09c-5cbbc65d958a",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("6c3623cc-8af3-4b3f-b9d1-4fc6c652214c",
	"c4aab548-6695-4559-ba9d-a712abbe4aec",
	"00000000-0000-0000-0000-000000000000",
	3,
	1,
	'column::solving line: 3');
INSERT INTO ACT_EL
	VALUES ("6c3623cc-8af3-4b3f-b9d1-4fc6c652214c",
	"6b8db268-9100-44fa-a304-9c81b3e5c39c",
	"c5d9fe77-e0cb-4dfb-b222-812dd073c355",
	"1e093ef4-598f-443a-8e4a-22b5f706cd1c");
INSERT INTO ACT_SMT
	VALUES ("a356dcd1-935f-416d-8300-0e99256aea80",
	"c4aab548-6695-4559-ba9d-a712abbe4aec",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'column::solving line: 5');
INSERT INTO ACT_E
	VALUES ("a356dcd1-935f-416d-8300-0e99256aea80",
	"9f8353e3-c3f5-44fe-886f-a6fbd3240c7d",
	"1e093ef4-598f-443a-8e4a-22b5f706cd1c");
INSERT INTO V_VAL
	VALUES ("693b8d76-6d68-4ad3-8485-989a772fcf8e",
	0,
	0,
	1,
	6,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4aab548-6695-4559-ba9d-a712abbe4aec");
INSERT INTO V_LIN
	VALUES ("693b8d76-6d68-4ad3-8485-989a772fcf8e",
	'100');
INSERT INTO V_VAL
	VALUES ("4816666a-fd3d-4eed-b09c-5cbbc65d958a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c4aab548-6695-4559-ba9d-a712abbe4aec");
INSERT INTO V_BIN
	VALUES ("4816666a-fd3d-4eed-b09c-5cbbc65d958a",
	"3f569c2b-0bf2-406d-b7bf-41b320ffafb1",
	"693b8d76-6d68-4ad3-8485-989a772fcf8e",
	'==');
INSERT INTO V_VAL
	VALUES ("3f569c2b-0bf2-406d-b7bf-41b320ffafb1",
	0,
	0,
	1,
	18,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4aab548-6695-4559-ba9d-a712abbe4aec");
INSERT INTO V_TRV
	VALUES ("3f569c2b-0bf2-406d-b7bf-41b320ffafb1",
	"d2362f48-e98f-4889-a32e-046f0f334fd1",
	"e3453cf9-ebb4-4d98-a53f-51515a049fff",
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("bb2ce761-9e34-4ca2-9432-05b11bc3f62d",
	0,
	0,
	3,
	8,
	10,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4aab548-6695-4559-ba9d-a712abbe4aec");
INSERT INTO V_LIN
	VALUES ("bb2ce761-9e34-4ca2-9432-05b11bc3f62d",
	'100');
INSERT INTO V_VAL
	VALUES ("c5d9fe77-e0cb-4dfb-b222-812dd073c355",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c4aab548-6695-4559-ba9d-a712abbe4aec");
INSERT INTO V_BIN
	VALUES ("c5d9fe77-e0cb-4dfb-b222-812dd073c355",
	"888163f4-5628-4bc8-9e42-4245161530b1",
	"bb2ce761-9e34-4ca2-9432-05b11bc3f62d",
	'==');
INSERT INTO V_VAL
	VALUES ("888163f4-5628-4bc8-9e42-4245161530b1",
	0,
	0,
	3,
	20,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c4aab548-6695-4559-ba9d-a712abbe4aec");
INSERT INTO V_TRV
	VALUES ("888163f4-5628-4bc8-9e42-4245161530b1",
	"e184be1e-e976-4c07-baa6-c4de41296f45",
	"e3453cf9-ebb4-4d98-a53f-51515a049fff",
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("e3453cf9-ebb4-4d98-a53f-51515a049fff",
	"c4aab548-6695-4559-ba9d-a712abbe4aec",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("e3453cf9-ebb4-4d98-a53f-51515a049fff",
	0,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_LOC
	VALUES ("3f790f5e-c967-4acb-a991-7d0fa161f0e1",
	1,
	13,
	16,
	"e3453cf9-ebb4-4d98-a53f-51515a049fff");
INSERT INTO V_LOC
	VALUES ("122145c2-803b-4401-97ea-b6948c7a2363",
	2,
	32,
	35,
	"e3453cf9-ebb4-4d98-a53f-51515a049fff");
INSERT INTO V_LOC
	VALUES ("06d74e04-c131-4289-ac72-e63a8c467cad",
	3,
	15,
	18,
	"e3453cf9-ebb4-4d98-a53f-51515a049fff");
INSERT INTO V_LOC
	VALUES ("2ed997b8-fed2-46ff-810e-e17f16e04fbf",
	4,
	32,
	35,
	"e3453cf9-ebb4-4d98-a53f-51515a049fff");
INSERT INTO V_LOC
	VALUES ("d70ca5c1-b7b6-4e2a-a5e1-fd3c31d25217",
	9,
	9,
	12,
	"e3453cf9-ebb4-4d98-a53f-51515a049fff");
INSERT INTO ACT_BLK
	VALUES ("88b350d3-fc91-40c9-ab32-dc90df209a83",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9213d04a-0bd4-44b0-b7ca-e6d631e58f67",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("69df2dbb-e11f-473e-9032-4c94c8a9f4c0",
	"88b350d3-fc91-40c9-ab32-dc90df209a83",
	"00000000-0000-0000-0000-000000000000",
	2,
	3,
	'column::solving line: 2');
INSERT INTO E_ESS
	VALUES ("69df2dbb-e11f-473e-9032-4c94c8a9f4c0",
	1,
	0,
	2,
	12,
	2,
	20,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("69df2dbb-e11f-473e-9032-4c94c8a9f4c0");
INSERT INTO E_GSME
	VALUES ("69df2dbb-e11f-473e-9032-4c94c8a9f4c0",
	"ab07d48c-ad8e-4ed3-a271-a874cc6faed8",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019");
INSERT INTO E_GEN
	VALUES ("69df2dbb-e11f-473e-9032-4c94c8a9f4c0",
	"e3453cf9-ebb4-4d98-a53f-51515a049fff");
INSERT INTO ACT_BLK
	VALUES ("6b8db268-9100-44fa-a304-9c81b3e5c39c",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9213d04a-0bd4-44b0-b7ca-e6d631e58f67",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4b308589-8bd3-4457-a3ef-33880c248b9f",
	"6b8db268-9100-44fa-a304-9c81b3e5c39c",
	"00000000-0000-0000-0000-000000000000",
	4,
	3,
	'column::solving line: 4');
INSERT INTO E_ESS
	VALUES ("4b308589-8bd3-4457-a3ef-33880c248b9f",
	1,
	0,
	4,
	12,
	4,
	20,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("4b308589-8bd3-4457-a3ef-33880c248b9f");
INSERT INTO E_GSME
	VALUES ("4b308589-8bd3-4457-a3ef-33880c248b9f",
	"ab07d48c-ad8e-4ed3-a271-a874cc6faed8",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019");
INSERT INTO E_GEN
	VALUES ("4b308589-8bd3-4457-a3ef-33880c248b9f",
	"e3453cf9-ebb4-4d98-a53f-51515a049fff");
INSERT INTO ACT_BLK
	VALUES ("9f8353e3-c3f5-44fe-886f-a6fbd3240c7d",
	1,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	6,
	40,
	0,
	0,
	6,
	49,
	0,
	0,
	0,
	0,
	0,
	"9213d04a-0bd4-44b0-b7ca-e6d631e58f67",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("b134754b-95c7-4f6a-bda5-e1246ac23723",
	"9f8353e3-c3f5-44fe-886f-a6fbd3240c7d",
	"89d6c6eb-7a6f-4d7c-a8f4-ae71fa5bfbd2",
	6,
	3,
	'column::solving line: 6');
INSERT INTO ACT_SEL
	VALUES ("b134754b-95c7-4f6a-bda5-e1246ac23723",
	"0dbf25d0-01f7-4bf8-b347-0e02b9b125bf",
	1,
	'one',
	"614fc8d0-7e5c-4768-8b45-71565d5deaac");
INSERT INTO ACT_SR
	VALUES ("b134754b-95c7-4f6a-bda5-e1246ac23723");
INSERT INTO ACT_LNK
	VALUES ("67ff8992-e4bb-40bf-b1b7-1e20dd9fba62",
	'',
	"b134754b-95c7-4f6a-bda5-e1246ac23723",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	6,
	40,
	6,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("89d6c6eb-7a6f-4d7c-a8f4-ae71fa5bfbd2",
	"9f8353e3-c3f5-44fe-886f-a6fbd3240c7d",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'column::solving line: 7');
INSERT INTO ACT_IF
	VALUES ("89d6c6eb-7a6f-4d7c-a8f4-ae71fa5bfbd2",
	"59c27c06-38bd-41ab-af98-5f2657d7d6f3",
	"b5210114-1da2-4202-b6c4-217186f2113e",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8ae0fc3b-227b-44cd-a3d4-46bb8db4d1ea",
	"9f8353e3-c3f5-44fe-886f-a6fbd3240c7d",
	"00000000-0000-0000-0000-000000000000",
	11,
	3,
	'column::solving line: 11');
INSERT INTO ACT_E
	VALUES ("8ae0fc3b-227b-44cd-a3d4-46bb8db4d1ea",
	"66d511c7-da18-4977-8e17-b187f9899845",
	"89d6c6eb-7a6f-4d7c-a8f4-ae71fa5bfbd2");
INSERT INTO V_VAL
	VALUES ("614fc8d0-7e5c-4768-8b45-71565d5deaac",
	0,
	0,
	6,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"9f8353e3-c3f5-44fe-886f-a6fbd3240c7d");
INSERT INTO V_IRF
	VALUES ("614fc8d0-7e5c-4768-8b45-71565d5deaac",
	"e3453cf9-ebb4-4d98-a53f-51515a049fff");
INSERT INTO V_VAL
	VALUES ("bf849797-92cb-4609-9c21-9dfa9fd3cc21",
	0,
	0,
	7,
	8,
	15,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"9f8353e3-c3f5-44fe-886f-a6fbd3240c7d");
INSERT INTO V_IRF
	VALUES ("bf849797-92cb-4609-9c21-9dfa9fd3cc21",
	"0dbf25d0-01f7-4bf8-b347-0e02b9b125bf");
INSERT INTO V_VAL
	VALUES ("e3ccd1db-d82a-4ff2-b846-332f241a3270",
	0,
	0,
	7,
	17,
	24,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9f8353e3-c3f5-44fe-886f-a6fbd3240c7d");
INSERT INTO V_AVL
	VALUES ("e3ccd1db-d82a-4ff2-b846-332f241a3270",
	"bf849797-92cb-4609-9c21-9dfa9fd3cc21",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("b5210114-1da2-4202-b6c4-217186f2113e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"9f8353e3-c3f5-44fe-886f-a6fbd3240c7d");
INSERT INTO V_BIN
	VALUES ("b5210114-1da2-4202-b6c4-217186f2113e",
	"80150e49-0727-41ba-84b9-4e65765eaef4",
	"e3ccd1db-d82a-4ff2-b846-332f241a3270",
	'>=');
INSERT INTO V_VAL
	VALUES ("80150e49-0727-41ba-84b9-4e65765eaef4",
	0,
	0,
	7,
	29,
	29,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9f8353e3-c3f5-44fe-886f-a6fbd3240c7d");
INSERT INTO V_LIN
	VALUES ("80150e49-0727-41ba-84b9-4e65765eaef4",
	'1');
INSERT INTO V_VAR
	VALUES ("0dbf25d0-01f7-4bf8-b347-0e02b9b125bf",
	"9f8353e3-c3f5-44fe-886f-a6fbd3240c7d",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("0dbf25d0-01f7-4bf8-b347-0e02b9b125bf",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("e3f47c04-c648-4440-9580-01900b9f7525",
	6,
	14,
	21,
	"0dbf25d0-01f7-4bf8-b347-0e02b9b125bf");
INSERT INTO V_LOC
	VALUES ("aea6ef6c-662e-45f0-af50-33a57c453d93",
	7,
	8,
	15,
	"0dbf25d0-01f7-4bf8-b347-0e02b9b125bf");
INSERT INTO V_LOC
	VALUES ("115328d6-50ec-43c5-b61c-b0431146760b",
	8,
	5,
	12,
	"0dbf25d0-01f7-4bf8-b347-0e02b9b125bf");
INSERT INTO V_LOC
	VALUES ("699f6bff-2018-44a4-82f3-e5c2466ce3fe",
	12,
	5,
	12,
	"0dbf25d0-01f7-4bf8-b347-0e02b9b125bf");
INSERT INTO ACT_BLK
	VALUES ("59c27c06-38bd-41ab-af98-5f2657d7d6f3",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9213d04a-0bd4-44b0-b7ca-e6d631e58f67",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4a05fd03-09ba-4288-9737-6d11b79ed366",
	"59c27c06-38bd-41ab-af98-5f2657d7d6f3",
	"8d44cd7e-e72f-401a-9dd3-a013275758f3",
	8,
	5,
	'column::solving line: 8');
INSERT INTO ACT_AI
	VALUES ("4a05fd03-09ba-4288-9737-6d11b79ed366",
	"2fff45c5-9f44-40dc-a5b6-5b81c8216199",
	"1d13d154-53aa-4b1c-8d3d-3eb38cdd7a16",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8d44cd7e-e72f-401a-9dd3-a013275758f3",
	"59c27c06-38bd-41ab-af98-5f2657d7d6f3",
	"0b3f142d-929a-40b4-8c7a-aec64c0ff8dd",
	9,
	5,
	'column::solving line: 9');
INSERT INTO ACT_AI
	VALUES ("8d44cd7e-e72f-401a-9dd3-a013275758f3",
	"0b00e8fc-9edf-416c-8eae-28a199e23fb6",
	"a230b04c-be39-44f1-9823-ab70fd0b4444",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0b3f142d-929a-40b4-8c7a-aec64c0ff8dd",
	"59c27c06-38bd-41ab-af98-5f2657d7d6f3",
	"00000000-0000-0000-0000-000000000000",
	10,
	5,
	'column::solving line: 10');
INSERT INTO E_ESS
	VALUES ("0b3f142d-929a-40b4-8c7a-aec64c0ff8dd",
	1,
	0,
	10,
	14,
	10,
	22,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("0b3f142d-929a-40b4-8c7a-aec64c0ff8dd");
INSERT INTO E_GSME
	VALUES ("0b3f142d-929a-40b4-8c7a-aec64c0ff8dd",
	"5fd7dc66-b6f4-42c9-b56e-583a604d532b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019");
INSERT INTO E_GEN
	VALUES ("0b3f142d-929a-40b4-8c7a-aec64c0ff8dd",
	"2f375708-4abf-4826-b7a7-6de8c8a04a71");
INSERT INTO V_VAL
	VALUES ("405ab569-a35e-43ad-abb8-87b1833e2c49",
	1,
	0,
	8,
	5,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"59c27c06-38bd-41ab-af98-5f2657d7d6f3");
INSERT INTO V_IRF
	VALUES ("405ab569-a35e-43ad-abb8-87b1833e2c49",
	"0dbf25d0-01f7-4bf8-b347-0e02b9b125bf");
INSERT INTO V_VAL
	VALUES ("1d13d154-53aa-4b1c-8d3d-3eb38cdd7a16",
	1,
	0,
	8,
	14,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"59c27c06-38bd-41ab-af98-5f2657d7d6f3");
INSERT INTO V_AVL
	VALUES ("1d13d154-53aa-4b1c-8d3d-3eb38cdd7a16",
	"405ab569-a35e-43ad-abb8-87b1833e2c49",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("2fff45c5-9f44-40dc-a5b6-5b81c8216199",
	0,
	0,
	8,
	25,
	25,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"59c27c06-38bd-41ab-af98-5f2657d7d6f3");
INSERT INTO V_LIN
	VALUES ("2fff45c5-9f44-40dc-a5b6-5b81c8216199",
	'1');
INSERT INTO V_VAL
	VALUES ("a230b04c-be39-44f1-9823-ab70fd0b4444",
	1,
	1,
	9,
	5,
	5,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"59c27c06-38bd-41ab-af98-5f2657d7d6f3");
INSERT INTO V_IRF
	VALUES ("a230b04c-be39-44f1-9823-ab70fd0b4444",
	"2f375708-4abf-4826-b7a7-6de8c8a04a71");
INSERT INTO V_VAL
	VALUES ("0b00e8fc-9edf-416c-8eae-28a199e23fb6",
	0,
	0,
	9,
	9,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"59c27c06-38bd-41ab-af98-5f2657d7d6f3");
INSERT INTO V_IRF
	VALUES ("0b00e8fc-9edf-416c-8eae-28a199e23fb6",
	"e3453cf9-ebb4-4d98-a53f-51515a049fff");
INSERT INTO V_VAR
	VALUES ("2f375708-4abf-4826-b7a7-6de8c8a04a71",
	"59c27c06-38bd-41ab-af98-5f2657d7d6f3",
	'c',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("2f375708-4abf-4826-b7a7-6de8c8a04a71",
	0,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_LOC
	VALUES ("21082cc7-b89f-436e-8591-69286abfaec9",
	9,
	5,
	5,
	"2f375708-4abf-4826-b7a7-6de8c8a04a71");
INSERT INTO V_LOC
	VALUES ("d08931f6-49ab-47bf-9b14-188b6d25e357",
	10,
	34,
	34,
	"2f375708-4abf-4826-b7a7-6de8c8a04a71");
INSERT INTO ACT_BLK
	VALUES ("66d511c7-da18-4977-8e17-b187f9899845",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9213d04a-0bd4-44b0-b7ca-e6d631e58f67",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("240e4b4b-ef6d-43f7-9b53-a1826007448c",
	"66d511c7-da18-4977-8e17-b187f9899845",
	"00000000-0000-0000-0000-000000000000",
	12,
	5,
	'column::solving line: 12');
INSERT INTO ACT_AI
	VALUES ("240e4b4b-ef6d-43f7-9b53-a1826007448c",
	"214e55ca-7bcc-4b91-a942-9ad4b281ae5d",
	"bc07f68d-523b-4da5-be3c-b887c46a5fb6",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("b3068e2b-614b-466a-84fa-3f66f07eebfd",
	1,
	0,
	12,
	5,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"66d511c7-da18-4977-8e17-b187f9899845");
INSERT INTO V_IRF
	VALUES ("b3068e2b-614b-466a-84fa-3f66f07eebfd",
	"0dbf25d0-01f7-4bf8-b347-0e02b9b125bf");
INSERT INTO V_VAL
	VALUES ("bc07f68d-523b-4da5-be3c-b887c46a5fb6",
	1,
	0,
	12,
	14,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"66d511c7-da18-4977-8e17-b187f9899845");
INSERT INTO V_AVL
	VALUES ("bc07f68d-523b-4da5-be3c-b887c46a5fb6",
	"b3068e2b-614b-466a-84fa-3f66f07eebfd",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("214e55ca-7bcc-4b91-a942-9ad4b281ae5d",
	0,
	0,
	12,
	25,
	25,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"66d511c7-da18-4977-8e17-b187f9899845");
INSERT INTO V_LIN
	VALUES ("214e55ca-7bcc-4b91-a942-9ad4b281ae5d",
	'0');
INSERT INTO SM_STATE
	VALUES ("634beabb-b61f-4c62-9311-fdbbcc3dc0d5",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000",
	'solved',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES ("634beabb-b61f-4c62-9311-fdbbcc3dc0d5",
	"5fd7dc66-b6f4-42c9-b56e-583a604d532b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("634beabb-b61f-4c62-9311-fdbbcc3dc0d5",
	"5fd7dc66-b6f4-42c9-b56e-583a604d532b",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EIGN
	VALUES ("634beabb-b61f-4c62-9311-fdbbcc3dc0d5",
	"ab07d48c-ad8e-4ed3-a271-a874cc6faed8",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("634beabb-b61f-4c62-9311-fdbbcc3dc0d5",
	"ab07d48c-ad8e-4ed3-a271-a874cc6faed8",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("89fd87a1-7956-471d-8b1b-b02a00afb58a",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"634beabb-b61f-4c62-9311-fdbbcc3dc0d5");
INSERT INTO SM_AH
	VALUES ("89fd87a1-7956-471d-8b1b-b02a00afb58a",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019");
INSERT INTO SM_ACT
	VALUES ("89fd87a1-7956-471d-8b1b-b02a00afb58a",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	1,
	'select one sequence related by self->SEQUENCE[R1];
sequence.solved = true;',
	'');
INSERT INTO ACT_SAB
	VALUES ("cf56ee73-13d6-4cd3-a3a0-723b94b02029",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"89fd87a1-7956-471d-8b1b-b02a00afb58a");
INSERT INTO ACT_ACT
	VALUES ("cf56ee73-13d6-4cd3-a3a0-723b94b02029",
	'state',
	0,
	"659001e1-fe39-4fbc-932d-065ef7a30f31",
	"00000000-0000-0000-0000-000000000000",
	0,
	'column::solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("659001e1-fe39-4fbc-932d-065ef7a30f31",
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	1,
	47,
	0,
	0,
	0,
	0,
	0,
	"cf56ee73-13d6-4cd3-a3a0-723b94b02029",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1366d9e7-98c7-4d0e-ab4e-c4bf73db7f53",
	"659001e1-fe39-4fbc-932d-065ef7a30f31",
	"9de3eb4b-d0eb-4c80-b84c-8d461d2c8aa1",
	1,
	1,
	'column::solved line: 1');
INSERT INTO ACT_SEL
	VALUES ("1366d9e7-98c7-4d0e-ab4e-c4bf73db7f53",
	"84ba834d-1ce6-41c7-8973-1234bb05dfef",
	1,
	'one',
	"279abc7a-f815-4ddf-9dd0-5fdcb5f29b86");
INSERT INTO ACT_SR
	VALUES ("1366d9e7-98c7-4d0e-ab4e-c4bf73db7f53");
INSERT INTO ACT_LNK
	VALUES ("aae30d4b-cc9b-42d3-820b-60645e7e3052",
	'',
	"1366d9e7-98c7-4d0e-ab4e-c4bf73db7f53",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	1,
	38,
	1,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9de3eb4b-d0eb-4c80-b84c-8d461d2c8aa1",
	"659001e1-fe39-4fbc-932d-065ef7a30f31",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'column::solved line: 2');
INSERT INTO ACT_AI
	VALUES ("9de3eb4b-d0eb-4c80-b84c-8d461d2c8aa1",
	"713fe61b-7555-4b7a-ba17-7d3587eaea60",
	"b1ed9233-5b00-498f-a3b2-e7d033eb4743",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("279abc7a-f815-4ddf-9dd0-5fdcb5f29b86",
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"659001e1-fe39-4fbc-932d-065ef7a30f31");
INSERT INTO V_IRF
	VALUES ("279abc7a-f815-4ddf-9dd0-5fdcb5f29b86",
	"7dec5631-655e-43c3-8748-c1b23da7ed39");
INSERT INTO V_VAL
	VALUES ("f9375efc-7175-4adf-8e3d-39ab55f142d2",
	1,
	0,
	2,
	1,
	8,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"659001e1-fe39-4fbc-932d-065ef7a30f31");
INSERT INTO V_IRF
	VALUES ("f9375efc-7175-4adf-8e3d-39ab55f142d2",
	"84ba834d-1ce6-41c7-8973-1234bb05dfef");
INSERT INTO V_VAL
	VALUES ("b1ed9233-5b00-498f-a3b2-e7d033eb4743",
	1,
	0,
	2,
	10,
	15,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"659001e1-fe39-4fbc-932d-065ef7a30f31");
INSERT INTO V_AVL
	VALUES ("b1ed9233-5b00-498f-a3b2-e7d033eb4743",
	"f9375efc-7175-4adf-8e3d-39ab55f142d2",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"52c42da4-a4c5-4627-bb84-a09549090418");
INSERT INTO V_VAL
	VALUES ("713fe61b-7555-4b7a-ba17-7d3587eaea60",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"659001e1-fe39-4fbc-932d-065ef7a30f31");
INSERT INTO V_LBO
	VALUES ("713fe61b-7555-4b7a-ba17-7d3587eaea60",
	'TRUE');
INSERT INTO V_VAR
	VALUES ("84ba834d-1ce6-41c7-8973-1234bb05dfef",
	"659001e1-fe39-4fbc-932d-065ef7a30f31",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("84ba834d-1ce6-41c7-8973-1234bb05dfef",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("e381d5e5-8284-4143-9e5b-26e84cc485cf",
	1,
	12,
	19,
	"84ba834d-1ce6-41c7-8973-1234bb05dfef");
INSERT INTO V_LOC
	VALUES ("3d08f52c-bb27-4cfc-9804-9a743c08e013",
	2,
	1,
	8,
	"84ba834d-1ce6-41c7-8973-1234bb05dfef");
INSERT INTO V_VAR
	VALUES ("7dec5631-655e-43c3-8748-c1b23da7ed39",
	"659001e1-fe39-4fbc-932d-065ef7a30f31",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("7dec5631-655e-43c3-8748-c1b23da7ed39",
	0,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO SM_NSTXN
	VALUES ("dfe54abc-e4a7-49ff-911d-77a86d0d2466",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"8b353543-deb1-4dfa-967d-8b87103c03ac",
	"5fd7dc66-b6f4-42c9-b56e-583a604d532b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("ce6e1910-b847-4ae9-ad9d-02e2b5def270",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"dfe54abc-e4a7-49ff-911d-77a86d0d2466");
INSERT INTO SM_AH
	VALUES ("ce6e1910-b847-4ae9-ad9d-02e2b5def270",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019");
INSERT INTO SM_ACT
	VALUES ("ce6e1910-b847-4ae9-ad9d-02e2b5def270",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("c472e047-a2bf-41a6-9b78-ceebfac78dea",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"ce6e1910-b847-4ae9-ad9d-02e2b5def270");
INSERT INTO ACT_ACT
	VALUES ("c472e047-a2bf-41a6-9b78-ceebfac78dea",
	'transition',
	0,
	"bc464542-5501-4ff2-94a6-58cc6657c301",
	"00000000-0000-0000-0000-000000000000",
	0,
	'COLUMN1: update in solving to solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("bc464542-5501-4ff2-94a6-58cc6657c301",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"c472e047-a2bf-41a6-9b78-ceebfac78dea",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("dfe54abc-e4a7-49ff-911d-77a86d0d2466",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"8b353543-deb1-4dfa-967d-8b87103c03ac",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("9d35fc47-f94b-4440-93c7-608fad6b1ccd",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"8b353543-deb1-4dfa-967d-8b87103c03ac",
	"ab07d48c-ad8e-4ed3-a271-a874cc6faed8",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("7d888480-a33b-4423-adc0-2031c108d403",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"9d35fc47-f94b-4440-93c7-608fad6b1ccd");
INSERT INTO SM_AH
	VALUES ("7d888480-a33b-4423-adc0-2031c108d403",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019");
INSERT INTO SM_ACT
	VALUES ("7d888480-a33b-4423-adc0-2031c108d403",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("1a276186-f60c-4492-89b0-97eb9d8d595a",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"7d888480-a33b-4423-adc0-2031c108d403");
INSERT INTO ACT_ACT
	VALUES ("1a276186-f60c-4492-89b0-97eb9d8d595a",
	'transition',
	0,
	"dfc29a55-f632-4232-b1ca-81dafbe98820",
	"00000000-0000-0000-0000-000000000000",
	0,
	'COLUMN2: solved in solving to solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("dfc29a55-f632-4232-b1ca-81dafbe98820",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"1a276186-f60c-4492-89b0-97eb9d8d595a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("9d35fc47-f94b-4440-93c7-608fad6b1ccd",
	"6d077a0b-5a9a-45f1-873c-3c19271cd019",
	"634beabb-b61f-4c62-9311-fdbbcc3dc0d5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_OBJ
	VALUES ("d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	'digit',
	6,
	'DIGIT',
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO O_NBATTR
	VALUES ("d4a31f11-b441-44fd-a723-84a3ed5bf70d",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO O_BATTR
	VALUES ("d4a31f11-b441-44fd-a723-84a3ed5bf70d",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO O_ATTR
	VALUES ("d4a31f11-b441-44fd-a723-84a3ed5bf70d",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"00000000-0000-0000-0000-000000000000",
	'value',
	'',
	'',
	'value',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO O_OIDA
	VALUES ("d4a31f11-b441-44fd-a723-84a3ed5bf70d",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	0);
INSERT INTO O_ID
	VALUES (1,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO O_ID
	VALUES (2,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO O_OBJ
	VALUES ("497a9d44-e141-4345-bf11-bb067fb75473",
	'eligible digit',
	7,
	'ELIGIBLE',
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO O_REF
	VALUES ("497a9d44-e141-4345-bf11-bb067fb75473",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	0,
	"dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"11ef7325-8abe-421f-af5b-9418d8555bd2",
	"dc9d735c-3204-41ae-8936-fb29307d3ef8",
	"4dbc0d4f-05b2-4547-9564-e6a7b72c5587",
	"156c756c-4c77-4c7b-a9a0-55d2e2ffe4d4",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'cell',
	'row_number',
	'R8');
INSERT INTO O_RATTR
	VALUES ("4dbc0d4f-05b2-4547-9564-e6a7b72c5587",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"bc6df04d-3498-4476-817a-f3273e8f61f2",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	1,
	'number');
INSERT INTO O_ATTR
	VALUES ("4dbc0d4f-05b2-4547-9564-e6a7b72c5587",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"00000000-0000-0000-0000-000000000000",
	'row_number',
	'',
	'',
	'row_number',
	2,
	"1d4138ff-0b11-4c15-ba60-a919d89e9e3d",
	'',
	'');
INSERT INTO O_REF
	VALUES ("497a9d44-e141-4345-bf11-bb067fb75473",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	0,
	"81faeef5-3440-4d38-a08b-a9fc5deea10b",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"11ef7325-8abe-421f-af5b-9418d8555bd2",
	"dc9d735c-3204-41ae-8936-fb29307d3ef8",
	"bd09a8dd-a49c-46d8-8718-7580b4511c6b",
	"7637ecc4-b6dd-43df-956e-30b813a49126",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'cell',
	'column_number',
	'R8');
INSERT INTO O_RATTR
	VALUES ("bd09a8dd-a49c-46d8-8718-7580b4511c6b",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"f26a153c-9ca1-42f0-b8e3-a33ce851c778",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	1,
	'number');
INSERT INTO O_ATTR
	VALUES ("bd09a8dd-a49c-46d8-8718-7580b4511c6b",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"4dbc0d4f-05b2-4547-9564-e6a7b72c5587",
	'column_number',
	'',
	'',
	'column_number',
	2,
	"1d4138ff-0b11-4c15-ba60-a919d89e9e3d",
	'',
	'');
INSERT INTO O_REF
	VALUES ("497a9d44-e141-4345-bf11-bb067fb75473",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	0,
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"11ef7325-8abe-421f-af5b-9418d8555bd2",
	"b10100b3-01e7-4b64-992f-de83c29a826b",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2",
	"0f8c6e50-e74e-464f-ae32-ae36c7c9f4e1",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'digit',
	'value',
	'R8');
INSERT INTO O_RATTR
	VALUES ("9d825ab9-0879-4dc5-adfc-18c679fd5bf2",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	1,
	'value');
INSERT INTO O_ATTR
	VALUES ("9d825ab9-0879-4dc5-adfc-18c679fd5bf2",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"bd09a8dd-a49c-46d8-8718-7580b4511c6b",
	'digit_value',
	'',
	'digit_',
	'value',
	1,
	"1d4138ff-0b11-4c15-ba60-a919d89e9e3d",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO O_OIDA
	VALUES ("4dbc0d4f-05b2-4547-9564-e6a7b72c5587",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	0);
INSERT INTO O_OIDA
	VALUES ("bd09a8dd-a49c-46d8-8718-7580b4511c6b",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	0);
INSERT INTO O_OIDA
	VALUES ("9d825ab9-0879-4dc5-adfc-18c679fd5bf2",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	0);
INSERT INTO O_ID
	VALUES (1,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO O_ID
	VALUES (2,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO O_OBJ
	VALUES ("c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	'row',
	2,
	'ROW',
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO O_TFR
	VALUES ("0c6ffade-4c66-4b70-b714-534336415dd0",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	'eliminate',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	1,
	'// Solve by select all eligible digits.  Notice if any eligible digit appears only once.

temperature = 0;
select many eligibles related by self->CELL[R2]->ELIGIBLE[R8];
c = cardinality eligibles;
if ( 9 == c )
  temperature = 100;
else
for each eligible in eligibles
  select many loners related by self->CELL[R2]->ELIGIBLE[R8]
    where ( selected.digit_value == eligible.digit_value );
  c = cardinality loners;
  if ( 1 == c )
    // This is an answer!
    select one cell related by eligible->CELL[R8];
    cell.answer( answer_digit:eligible.digit_value );
    // generate CELL2:answer( digit:eligible.digit_value ) to cell;
    temperature = 1;
    break;
  end if;
end for;
end if;
return temperature;
',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_OPB
	VALUES ("9aa016df-706d-4ac4-840f-eabafa45a1a0",
	"0c6ffade-4c66-4b70-b714-534336415dd0");
INSERT INTO ACT_ACT
	VALUES ("9aa016df-706d-4ac4-840f-eabafa45a1a0",
	'operation',
	0,
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	"00000000-0000-0000-0000-000000000000",
	0,
	'row::eliminate',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("805dd1ae-67b2-432a-b557-8b40f8de34a8",
	1,
	0,
	0,
	'',
	'',
	'',
	23,
	1,
	4,
	50,
	0,
	0,
	4,
	59,
	0,
	0,
	0,
	0,
	0,
	"9aa016df-706d-4ac4-840f-eabafa45a1a0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5457eaf1-d053-4b49-9cb5-7fc2c6467245",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	"622d0856-f9d8-419c-9af5-137539deeab5",
	3,
	1,
	'row::eliminate line: 3');
INSERT INTO ACT_AI
	VALUES ("5457eaf1-d053-4b49-9cb5-7fc2c6467245",
	"f2066222-1258-4a3c-8aab-e13b80c62a9a",
	"ab1b0163-35a2-4885-879d-5ae9438fd8b5",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("622d0856-f9d8-419c-9af5-137539deeab5",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	"4f1913fe-7161-4a8a-a52c-ac3808606436",
	4,
	1,
	'row::eliminate line: 4');
INSERT INTO ACT_SEL
	VALUES ("622d0856-f9d8-419c-9af5-137539deeab5",
	"3804f59a-054b-4ab8-aff5-c5b85b3196a7",
	1,
	'many',
	"911884c0-5037-4b83-b38f-36f4323e67c5");
INSERT INTO ACT_SR
	VALUES ("622d0856-f9d8-419c-9af5-137539deeab5");
INSERT INTO ACT_LNK
	VALUES ("33637194-a2d4-4f3f-905e-390a1042c137",
	'',
	"622d0856-f9d8-419c-9af5-137539deeab5",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"cab91f42-4c06-410f-9706-db75cfec6ecf",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	4,
	40,
	4,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("cab91f42-4c06-410f-9706-db75cfec6ecf",
	'',
	"00000000-0000-0000-0000-000000000000",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	4,
	50,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("4f1913fe-7161-4a8a-a52c-ac3808606436",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	"5e454040-7ed6-4b53-80ab-ff2da3d25e92",
	5,
	1,
	'row::eliminate line: 5');
INSERT INTO ACT_AI
	VALUES ("4f1913fe-7161-4a8a-a52c-ac3808606436",
	"2cd3e627-f3bd-4c6a-bf67-98177edacbf9",
	"3d44247d-5fd0-4b4e-8b8d-1da94e8dd673",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5e454040-7ed6-4b53-80ab-ff2da3d25e92",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	"71360e5f-1e33-451f-bfac-f3e7f82040f3",
	6,
	1,
	'row::eliminate line: 6');
INSERT INTO ACT_IF
	VALUES ("5e454040-7ed6-4b53-80ab-ff2da3d25e92",
	"9c17a686-08b9-4f47-92e1-da4541ead6e5",
	"fa13f11e-c32e-483a-8a67-5813091dd356",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5fce803f-ce55-4d4e-9626-98b68ed4c3ce",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	"00000000-0000-0000-0000-000000000000",
	8,
	1,
	'row::eliminate line: 8');
INSERT INTO ACT_E
	VALUES ("5fce803f-ce55-4d4e-9626-98b68ed4c3ce",
	"e0e126c6-7562-4a5b-86d3-cbc10c6311c8",
	"5e454040-7ed6-4b53-80ab-ff2da3d25e92");
INSERT INTO ACT_SMT
	VALUES ("71360e5f-1e33-451f-bfac-f3e7f82040f3",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	"00000000-0000-0000-0000-000000000000",
	23,
	1,
	'row::eliminate line: 23');
INSERT INTO ACT_RET
	VALUES ("71360e5f-1e33-451f-bfac-f3e7f82040f3",
	"271b5e89-4f37-4cd2-ae1c-eb9a1feb29b1");
INSERT INTO V_VAL
	VALUES ("ab1b0163-35a2-4885-879d-5ae9438fd8b5",
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8");
INSERT INTO V_TVL
	VALUES ("ab1b0163-35a2-4885-879d-5ae9438fd8b5",
	"b5d605b7-7baf-4701-b996-0687fc5616d8");
INSERT INTO V_VAL
	VALUES ("f2066222-1258-4a3c-8aab-e13b80c62a9a",
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8");
INSERT INTO V_LIN
	VALUES ("f2066222-1258-4a3c-8aab-e13b80c62a9a",
	'0');
INSERT INTO V_VAL
	VALUES ("911884c0-5037-4b83-b38f-36f4323e67c5",
	0,
	0,
	4,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8");
INSERT INTO V_IRF
	VALUES ("911884c0-5037-4b83-b38f-36f4323e67c5",
	"18df946f-3e38-4d05-848a-e817449545d9");
INSERT INTO V_VAL
	VALUES ("3d44247d-5fd0-4b4e-8b8d-1da94e8dd673",
	1,
	1,
	5,
	1,
	1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8");
INSERT INTO V_TVL
	VALUES ("3d44247d-5fd0-4b4e-8b8d-1da94e8dd673",
	"8f8b0faf-01cc-4bda-b795-ac697396b1ae");
INSERT INTO V_VAL
	VALUES ("bd0a4d34-1543-4e74-b883-2d68c9de318c",
	0,
	0,
	5,
	17,
	25,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8");
INSERT INTO V_ISR
	VALUES ("bd0a4d34-1543-4e74-b883-2d68c9de318c",
	"3804f59a-054b-4ab8-aff5-c5b85b3196a7");
INSERT INTO V_VAL
	VALUES ("2cd3e627-f3bd-4c6a-bf67-98177edacbf9",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8");
INSERT INTO V_UNY
	VALUES ("2cd3e627-f3bd-4c6a-bf67-98177edacbf9",
	"bd0a4d34-1543-4e74-b883-2d68c9de318c",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("a72159d6-b7b2-41a8-b831-297a55aef075",
	0,
	0,
	6,
	6,
	6,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8");
INSERT INTO V_LIN
	VALUES ("a72159d6-b7b2-41a8-b831-297a55aef075",
	'9');
INSERT INTO V_VAL
	VALUES ("fa13f11e-c32e-483a-8a67-5813091dd356",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8");
INSERT INTO V_BIN
	VALUES ("fa13f11e-c32e-483a-8a67-5813091dd356",
	"2819f2b2-9886-4c95-adb3-04fa449db4be",
	"a72159d6-b7b2-41a8-b831-297a55aef075",
	'==');
INSERT INTO V_VAL
	VALUES ("2819f2b2-9886-4c95-adb3-04fa449db4be",
	0,
	0,
	6,
	11,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8");
INSERT INTO V_TVL
	VALUES ("2819f2b2-9886-4c95-adb3-04fa449db4be",
	"8f8b0faf-01cc-4bda-b795-ac697396b1ae");
INSERT INTO V_VAL
	VALUES ("271b5e89-4f37-4cd2-ae1c-eb9a1feb29b1",
	0,
	0,
	23,
	8,
	18,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8");
INSERT INTO V_TVL
	VALUES ("271b5e89-4f37-4cd2-ae1c-eb9a1feb29b1",
	"b5d605b7-7baf-4701-b996-0687fc5616d8");
INSERT INTO V_VAR
	VALUES ("b5d605b7-7baf-4701-b996-0687fc5616d8",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	'temperature',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("b5d605b7-7baf-4701-b996-0687fc5616d8",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("cb1126a3-e819-45dd-ae80-d9e541426d8e",
	3,
	1,
	11,
	"b5d605b7-7baf-4701-b996-0687fc5616d8");
INSERT INTO V_LOC
	VALUES ("120da5e3-057c-4f01-9127-50b5c6aa98e3",
	7,
	3,
	13,
	"b5d605b7-7baf-4701-b996-0687fc5616d8");
INSERT INTO V_LOC
	VALUES ("51e88932-e524-452a-bb87-a1ff79f041d1",
	18,
	5,
	15,
	"b5d605b7-7baf-4701-b996-0687fc5616d8");
INSERT INTO V_LOC
	VALUES ("acfe984e-cafe-4c33-beff-a9e91889bacc",
	23,
	8,
	18,
	"b5d605b7-7baf-4701-b996-0687fc5616d8");
INSERT INTO V_VAR
	VALUES ("3804f59a-054b-4ab8-aff5-c5b85b3196a7",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	'eligibles',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("3804f59a-054b-4ab8-aff5-c5b85b3196a7",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("659b23f1-a5bb-4fb4-80a3-9801d16ad46a",
	4,
	13,
	21,
	"3804f59a-054b-4ab8-aff5-c5b85b3196a7");
INSERT INTO V_LOC
	VALUES ("66bc2704-0dd2-4120-9275-307b29a37f27",
	9,
	22,
	30,
	"3804f59a-054b-4ab8-aff5-c5b85b3196a7");
INSERT INTO V_VAR
	VALUES ("18df946f-3e38-4d05-848a-e817449545d9",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("18df946f-3e38-4d05-848a-e817449545d9",
	0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_VAR
	VALUES ("8f8b0faf-01cc-4bda-b795-ac697396b1ae",
	"805dd1ae-67b2-432a-b557-8b40f8de34a8",
	'c',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("8f8b0faf-01cc-4bda-b795-ac697396b1ae",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("a7e2e468-a2ec-452b-ba53-4023ba28b669",
	5,
	1,
	1,
	"8f8b0faf-01cc-4bda-b795-ac697396b1ae");
INSERT INTO V_LOC
	VALUES ("cd4465e5-b468-4a5a-8c15-6dc9c8f4d231",
	6,
	11,
	11,
	"8f8b0faf-01cc-4bda-b795-ac697396b1ae");
INSERT INTO V_LOC
	VALUES ("5d71ac90-3520-4e78-9a80-df5217703ed4",
	12,
	3,
	3,
	"8f8b0faf-01cc-4bda-b795-ac697396b1ae");
INSERT INTO V_LOC
	VALUES ("9b2adf67-3c63-4594-82e6-92e036427a91",
	13,
	13,
	13,
	"8f8b0faf-01cc-4bda-b795-ac697396b1ae");
INSERT INTO ACT_BLK
	VALUES ("9c17a686-08b9-4f47-92e1-da4541ead6e5",
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9aa016df-706d-4ac4-840f-eabafa45a1a0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("868d6444-ef02-42ba-9db4-870c2e2b7b8b",
	"9c17a686-08b9-4f47-92e1-da4541ead6e5",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'row::eliminate line: 7');
INSERT INTO ACT_AI
	VALUES ("868d6444-ef02-42ba-9db4-870c2e2b7b8b",
	"4283d281-5602-43ba-8e13-163adc37dba0",
	"c32b1d43-af70-4d1f-8910-330bbb9f5d17",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("c32b1d43-af70-4d1f-8910-330bbb9f5d17",
	1,
	0,
	7,
	3,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9c17a686-08b9-4f47-92e1-da4541ead6e5");
INSERT INTO V_TVL
	VALUES ("c32b1d43-af70-4d1f-8910-330bbb9f5d17",
	"b5d605b7-7baf-4701-b996-0687fc5616d8");
INSERT INTO V_VAL
	VALUES ("4283d281-5602-43ba-8e13-163adc37dba0",
	0,
	0,
	7,
	17,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"9c17a686-08b9-4f47-92e1-da4541ead6e5");
INSERT INTO V_LIN
	VALUES ("4283d281-5602-43ba-8e13-163adc37dba0",
	'100');
INSERT INTO ACT_BLK
	VALUES ("e0e126c6-7562-4a5b-86d3-cbc10c6311c8",
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9aa016df-706d-4ac4-840f-eabafa45a1a0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("02ea13d6-aedf-4c8e-9685-04a7bef8e793",
	"e0e126c6-7562-4a5b-86d3-cbc10c6311c8",
	"00000000-0000-0000-0000-000000000000",
	9,
	1,
	'row::eliminate line: 9');
INSERT INTO ACT_FOR
	VALUES ("02ea13d6-aedf-4c8e-9685-04a7bef8e793",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b",
	1,
	"14359fbc-97bf-4cfd-89da-a037c02862e2",
	"3804f59a-054b-4ab8-aff5-c5b85b3196a7",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_VAR
	VALUES ("14359fbc-97bf-4cfd-89da-a037c02862e2",
	"e0e126c6-7562-4a5b-86d3-cbc10c6311c8",
	'eligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("14359fbc-97bf-4cfd-89da-a037c02862e2",
	1,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("9cb8381f-264e-4a97-9bc6-db8a5b87bb43",
	9,
	10,
	17,
	"14359fbc-97bf-4cfd-89da-a037c02862e2");
INSERT INTO V_LOC
	VALUES ("f71ea5e0-4114-40c0-8c08-5d913fc59d34",
	11,
	37,
	44,
	"14359fbc-97bf-4cfd-89da-a037c02862e2");
INSERT INTO V_LOC
	VALUES ("a9a8edd8-d1aa-4dc4-8f78-ecb1485aa588",
	16,
	31,
	38,
	"14359fbc-97bf-4cfd-89da-a037c02862e2");
INSERT INTO ACT_BLK
	VALUES ("c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b",
	1,
	0,
	1,
	'',
	'',
	'',
	13,
	3,
	10,
	49,
	0,
	0,
	10,
	58,
	0,
	0,
	0,
	0,
	0,
	"9aa016df-706d-4ac4-840f-eabafa45a1a0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f9e3ed95-2686-43c3-9dab-aa93d3cdaaba",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b",
	"450c3728-b4c5-42b4-a02f-83e2c631373a",
	10,
	3,
	'row::eliminate line: 10');
INSERT INTO ACT_SEL
	VALUES ("f9e3ed95-2686-43c3-9dab-aa93d3cdaaba",
	"a1a9cd24-c149-4e4e-bd6f-abb302ee0f67",
	1,
	'many',
	"745f119f-ac00-4bc0-be98-be644140f3c3");
INSERT INTO ACT_SRW
	VALUES ("f9e3ed95-2686-43c3-9dab-aa93d3cdaaba",
	"3a95f37e-0148-4ae9-a078-e21e91c3e68f");
INSERT INTO ACT_LNK
	VALUES ("19f4d24c-b05e-41e0-b0d0-c726fe73cc5a",
	'',
	"f9e3ed95-2686-43c3-9dab-aa93d3cdaaba",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"4cf7c8ea-015a-4245-b3a7-bbe914cebdf2",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	10,
	39,
	10,
	44,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("4cf7c8ea-015a-4245-b3a7-bbe914cebdf2",
	'',
	"00000000-0000-0000-0000-000000000000",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	10,
	49,
	10,
	58,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("450c3728-b4c5-42b4-a02f-83e2c631373a",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b",
	"856bf63d-5e32-4f39-bca7-23b6cfa0ad3c",
	12,
	3,
	'row::eliminate line: 12');
INSERT INTO ACT_AI
	VALUES ("450c3728-b4c5-42b4-a02f-83e2c631373a",
	"a5f302a3-abb2-4dae-a680-04dd6454e675",
	"71ce3a04-3edf-450b-8bc4-faa2ef281bd7",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("856bf63d-5e32-4f39-bca7-23b6cfa0ad3c",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b",
	"00000000-0000-0000-0000-000000000000",
	13,
	3,
	'row::eliminate line: 13');
INSERT INTO ACT_IF
	VALUES ("856bf63d-5e32-4f39-bca7-23b6cfa0ad3c",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3",
	"ef2526af-2d0b-4d67-a326-1c8d8f5383ab",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("745f119f-ac00-4bc0-be98-be644140f3c3",
	0,
	0,
	10,
	33,
	36,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_IRF
	VALUES ("745f119f-ac00-4bc0-be98-be644140f3c3",
	"18df946f-3e38-4d05-848a-e817449545d9");
INSERT INTO V_VAL
	VALUES ("0f1ac049-6df4-47a9-9988-5dd49678027b",
	0,
	0,
	11,
	13,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_SLR
	VALUES ("0f1ac049-6df4-47a9-9988-5dd49678027b",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("4a988e64-e0ad-432f-9617-dca9b41ea4aa",
	0,
	0,
	11,
	22,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_AVL
	VALUES ("4a988e64-e0ad-432f-9617-dca9b41ea4aa",
	"0f1ac049-6df4-47a9-9988-5dd49678027b",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("3a95f37e-0148-4ae9-a078-e21e91c3e68f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_BIN
	VALUES ("3a95f37e-0148-4ae9-a078-e21e91c3e68f",
	"74b416c4-2103-4076-8742-8d2917a0913d",
	"4a988e64-e0ad-432f-9617-dca9b41ea4aa",
	'==');
INSERT INTO V_VAL
	VALUES ("059bb795-e276-401a-ae28-027b111a304e",
	0,
	0,
	11,
	37,
	44,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_IRF
	VALUES ("059bb795-e276-401a-ae28-027b111a304e",
	"14359fbc-97bf-4cfd-89da-a037c02862e2");
INSERT INTO V_VAL
	VALUES ("74b416c4-2103-4076-8742-8d2917a0913d",
	0,
	0,
	11,
	46,
	56,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_AVL
	VALUES ("74b416c4-2103-4076-8742-8d2917a0913d",
	"059bb795-e276-401a-ae28-027b111a304e",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("71ce3a04-3edf-450b-8bc4-faa2ef281bd7",
	1,
	0,
	12,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_TVL
	VALUES ("71ce3a04-3edf-450b-8bc4-faa2ef281bd7",
	"8f8b0faf-01cc-4bda-b795-ac697396b1ae");
INSERT INTO V_VAL
	VALUES ("c3a20377-dcee-4191-acc9-ce46737c1f1f",
	0,
	0,
	12,
	19,
	24,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_ISR
	VALUES ("c3a20377-dcee-4191-acc9-ce46737c1f1f",
	"a1a9cd24-c149-4e4e-bd6f-abb302ee0f67");
INSERT INTO V_VAL
	VALUES ("a5f302a3-abb2-4dae-a680-04dd6454e675",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_UNY
	VALUES ("a5f302a3-abb2-4dae-a680-04dd6454e675",
	"c3a20377-dcee-4191-acc9-ce46737c1f1f",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("b0eabec7-ab5e-43ad-bbad-721c03954e36",
	0,
	0,
	13,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_LIN
	VALUES ("b0eabec7-ab5e-43ad-bbad-721c03954e36",
	'1');
INSERT INTO V_VAL
	VALUES ("ef2526af-2d0b-4d67-a326-1c8d8f5383ab",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_BIN
	VALUES ("ef2526af-2d0b-4d67-a326-1c8d8f5383ab",
	"4235bb42-f6f7-47e0-bd21-19c94ebc16ba",
	"b0eabec7-ab5e-43ad-bbad-721c03954e36",
	'==');
INSERT INTO V_VAL
	VALUES ("4235bb42-f6f7-47e0-bd21-19c94ebc16ba",
	0,
	0,
	13,
	13,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b");
INSERT INTO V_TVL
	VALUES ("4235bb42-f6f7-47e0-bd21-19c94ebc16ba",
	"8f8b0faf-01cc-4bda-b795-ac697396b1ae");
INSERT INTO V_VAR
	VALUES ("a1a9cd24-c149-4e4e-bd6f-abb302ee0f67",
	"c3d1c6f8-ab7c-4c75-90a0-360b478e1d5b",
	'loners',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("a1a9cd24-c149-4e4e-bd6f-abb302ee0f67",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("8df6ca90-6c2c-492a-899c-3fb4cd928314",
	10,
	15,
	20,
	"a1a9cd24-c149-4e4e-bd6f-abb302ee0f67");
INSERT INTO ACT_BLK
	VALUES ("5499a84c-24ff-4f1b-887b-c8dbfbaf38b3",
	1,
	0,
	0,
	'',
	'',
	'',
	19,
	5,
	15,
	42,
	0,
	0,
	15,
	47,
	0,
	0,
	0,
	0,
	0,
	"9aa016df-706d-4ac4-840f-eabafa45a1a0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ef9d35c0-4c01-4afd-9ce0-dcb77fed3939",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3",
	"2c2d0606-88c7-418e-bd1f-5e950f9a99c6",
	15,
	5,
	'row::eliminate line: 15');
INSERT INTO ACT_SEL
	VALUES ("ef9d35c0-4c01-4afd-9ce0-dcb77fed3939",
	"0261645d-e0fd-4546-8aae-2685546ba5d4",
	1,
	'one',
	"77138d7b-b6ab-4638-afe2-1f3d4d269897");
INSERT INTO ACT_SR
	VALUES ("ef9d35c0-4c01-4afd-9ce0-dcb77fed3939");
INSERT INTO ACT_LNK
	VALUES ("a3cce71b-0b98-403a-b6d2-c9f1a82461f4",
	'',
	"ef9d35c0-4c01-4afd-9ce0-dcb77fed3939",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	15,
	42,
	15,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("2c2d0606-88c7-418e-bd1f-5e950f9a99c6",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3",
	"5a27fd95-0a14-4232-b87a-6c6c6336ffda",
	16,
	5,
	'row::eliminate line: 16');
INSERT INTO ACT_TFM
	VALUES ("2c2d0606-88c7-418e-bd1f-5e950f9a99c6",
	"4dbd3878-9ff1-4fa9-8ff2-db063b3aa997",
	"0261645d-e0fd-4546-8aae-2685546ba5d4",
	16,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5a27fd95-0a14-4232-b87a-6c6c6336ffda",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3",
	"e52c3f8c-d9a2-4dd6-8a96-9a0dcaaef532",
	18,
	5,
	'row::eliminate line: 18');
INSERT INTO ACT_AI
	VALUES ("5a27fd95-0a14-4232-b87a-6c6c6336ffda",
	"9e118a5b-a935-4144-953f-42df28aac99b",
	"17721133-0b35-4b96-9646-ae6433fc8cab",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e52c3f8c-d9a2-4dd6-8a96-9a0dcaaef532",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3",
	"00000000-0000-0000-0000-000000000000",
	19,
	5,
	'row::eliminate line: 19');
INSERT INTO ACT_BRK
	VALUES ("e52c3f8c-d9a2-4dd6-8a96-9a0dcaaef532");
INSERT INTO V_VAL
	VALUES ("77138d7b-b6ab-4638-afe2-1f3d4d269897",
	0,
	0,
	15,
	32,
	39,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3");
INSERT INTO V_IRF
	VALUES ("77138d7b-b6ab-4638-afe2-1f3d4d269897",
	"14359fbc-97bf-4cfd-89da-a037c02862e2");
INSERT INTO V_VAL
	VALUES ("7ab225df-60ce-4041-a510-673798b8684e",
	0,
	0,
	16,
	31,
	38,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3");
INSERT INTO V_IRF
	VALUES ("7ab225df-60ce-4041-a510-673798b8684e",
	"14359fbc-97bf-4cfd-89da-a037c02862e2");
INSERT INTO V_VAL
	VALUES ("01cb99a6-f6e6-403e-b5ab-38c23a92b475",
	0,
	0,
	16,
	40,
	50,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3");
INSERT INTO V_AVL
	VALUES ("01cb99a6-f6e6-403e-b5ab-38c23a92b475",
	"7ab225df-60ce-4041-a510-673798b8684e",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_PAR
	VALUES ("01cb99a6-f6e6-403e-b5ab-38c23a92b475",
	"2c2d0606-88c7-418e-bd1f-5e950f9a99c6",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	16,
	18);
INSERT INTO V_VAL
	VALUES ("17721133-0b35-4b96-9646-ae6433fc8cab",
	1,
	0,
	18,
	5,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3");
INSERT INTO V_TVL
	VALUES ("17721133-0b35-4b96-9646-ae6433fc8cab",
	"b5d605b7-7baf-4701-b996-0687fc5616d8");
INSERT INTO V_VAL
	VALUES ("9e118a5b-a935-4144-953f-42df28aac99b",
	0,
	0,
	18,
	19,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3");
INSERT INTO V_LIN
	VALUES ("9e118a5b-a935-4144-953f-42df28aac99b",
	'1');
INSERT INTO V_VAR
	VALUES ("0261645d-e0fd-4546-8aae-2685546ba5d4",
	"5499a84c-24ff-4f1b-887b-c8dbfbaf38b3",
	'cell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("0261645d-e0fd-4546-8aae-2685546ba5d4",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("d16a1577-f2de-4252-a60f-c4af11781d6e",
	15,
	16,
	19,
	"0261645d-e0fd-4546-8aae-2685546ba5d4");
INSERT INTO V_LOC
	VALUES ("d952eff8-fbcd-414f-899a-d39d7bb17534",
	16,
	5,
	8,
	"0261645d-e0fd-4546-8aae-2685546ba5d4");
INSERT INTO O_TFR
	VALUES ("974f15af-1f69-41a6-818a-7e3763126756",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	'prune',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	1,
	'// Eliminate eligible digits that match any answer digit for this sequence.

temperature = 0;
select many answerdigits related by self->CELL[R2]->DIGIT[R9] where ( selected.value != 0 );
select many eligibles related by self->CELL[R2]->ELIGIBLE[R8];
for each eligible in eligibles
  for each answerdigit in answerdigits
    if ( eligible.digit_value == answerdigit.value )
      select one opencell related by eligible->CELL[R8];
      if ( opencell.answer_value != eligible.digit_value )
        unrelate answerdigit from opencell across R8 using eligible;
        delete object instance eligible;
        // generate CELL1:eliminate( digit:answerdigit.value ) to opencell;
      end if;
      temperature = 1;
      break;
    end if;
  end for;
end for;
  
select many opencells related by self->CELL[R2]
  where ( selected.answer_value == 0 );
if ( empty opencells )
  temperature = 100;
end if;
for each opencell in opencells
  // Notice if we have the answer now.
  select many eligibles related by opencell->ELIGIBLE[R8];
  c = cardinality eligibles;
  if ( 1 == c )
    select any answer related by opencell->ELIGIBLE[R8];
    opencell.answer( answer_digit:answer.digit_value );
    // generate CELL2:answer( digit:answer.digit_value ) to opencell;
    temperature = 1;
  end if;
end for;

return temperature;
',
	1,
	'',
	"0c6ffade-4c66-4b70-b714-534336415dd0");
INSERT INTO ACT_OPB
	VALUES ("0d52dfb8-9f52-4860-92f6-50df3d299f4b",
	"974f15af-1f69-41a6-818a-7e3763126756");
INSERT INTO ACT_ACT
	VALUES ("0d52dfb8-9f52-4860-92f6-50df3d299f4b",
	'operation',
	0,
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	"00000000-0000-0000-0000-000000000000",
	0,
	'row::prune',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("3d01f6f7-eb49-421c-9117-8bed27bf516a",
	1,
	0,
	1,
	'',
	'',
	'',
	38,
	1,
	21,
	40,
	0,
	0,
	21,
	45,
	0,
	0,
	0,
	0,
	0,
	"0d52dfb8-9f52-4860-92f6-50df3d299f4b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ac5c1fe6-4101-4756-93e3-5c97fe989c55",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	"735c92b5-3cae-4fa1-9b95-1e69dc94e0a2",
	3,
	1,
	'row::prune line: 3');
INSERT INTO ACT_AI
	VALUES ("ac5c1fe6-4101-4756-93e3-5c97fe989c55",
	"b06f7802-a081-427f-ae93-bc320626be23",
	"c029ac5a-4fc9-4426-87df-47eb0bf46c05",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("735c92b5-3cae-4fa1-9b95-1e69dc94e0a2",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	"f9971dfb-2692-4485-96d5-a4a8e0a45868",
	4,
	1,
	'row::prune line: 4');
INSERT INTO ACT_SEL
	VALUES ("735c92b5-3cae-4fa1-9b95-1e69dc94e0a2",
	"30884a09-8a44-4bc3-b156-0f46f7cce6d4",
	1,
	'many',
	"5e16f3fe-53c4-489d-a6b5-3bf6dc6da03e");
INSERT INTO ACT_SRW
	VALUES ("735c92b5-3cae-4fa1-9b95-1e69dc94e0a2",
	"dbc84e05-66a3-42ab-8dc6-2d69b704ff21");
INSERT INTO ACT_LNK
	VALUES ("64f38aa4-8775-4f3f-a97d-15157a2e095a",
	'',
	"735c92b5-3cae-4fa1-9b95-1e69dc94e0a2",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"c3aa9a68-cece-48d4-9ee4-8a159c982f66",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	4,
	43,
	4,
	48,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("c3aa9a68-cece-48d4-9ee4-8a159c982f66",
	'',
	"00000000-0000-0000-0000-000000000000",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"00000000-0000-0000-0000-000000000000",
	2,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	4,
	53,
	4,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f9971dfb-2692-4485-96d5-a4a8e0a45868",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	"c5d6adee-976d-4e43-937f-4e754a3ba5a9",
	5,
	1,
	'row::prune line: 5');
INSERT INTO ACT_SEL
	VALUES ("f9971dfb-2692-4485-96d5-a4a8e0a45868",
	"cbe0f0d1-1cfb-4a3d-9976-6a3aa53ea5c2",
	1,
	'many',
	"904861f8-9a0d-4bd6-8864-267138f9f2e9");
INSERT INTO ACT_SR
	VALUES ("f9971dfb-2692-4485-96d5-a4a8e0a45868");
INSERT INTO ACT_LNK
	VALUES ("da335725-487c-4852-bcd6-d917262e8704",
	'',
	"f9971dfb-2692-4485-96d5-a4a8e0a45868",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"022c0b51-7bc0-492d-9f7b-51f295b815e7",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	5,
	40,
	5,
	45,
	0,
	0);
INSERT INTO ACT_LNK
	VALUES ("022c0b51-7bc0-492d-9f7b-51f295b815e7",
	'',
	"00000000-0000-0000-0000-000000000000",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	5,
	50,
	5,
	59,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c5d6adee-976d-4e43-937f-4e754a3ba5a9",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	"efcf9f2f-a427-462e-8c1d-b2a72056eb6b",
	6,
	1,
	'row::prune line: 6');
INSERT INTO ACT_FOR
	VALUES ("c5d6adee-976d-4e43-937f-4e754a3ba5a9",
	"8fe35157-7920-4bef-9492-6979e5bce7c4",
	1,
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5",
	"cbe0f0d1-1cfb-4a3d-9976-6a3aa53ea5c2",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO ACT_SMT
	VALUES ("efcf9f2f-a427-462e-8c1d-b2a72056eb6b",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	"c98c5133-311c-4bf6-8d96-d160a05b5446",
	21,
	1,
	'row::prune line: 21');
INSERT INTO ACT_SEL
	VALUES ("efcf9f2f-a427-462e-8c1d-b2a72056eb6b",
	"0ddc703b-d389-4620-8afe-da175946a11a",
	1,
	'many',
	"152ebc69-2972-4901-85dc-9eee8f2947cc");
INSERT INTO ACT_SRW
	VALUES ("efcf9f2f-a427-462e-8c1d-b2a72056eb6b",
	"10083afd-ad59-4146-9c89-d883ee988a22");
INSERT INTO ACT_LNK
	VALUES ("b7e55c5c-084e-4845-9c9d-d59acfe2ab97",
	'',
	"efcf9f2f-a427-462e-8c1d-b2a72056eb6b",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"00000000-0000-0000-0000-000000000000",
	3,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	21,
	40,
	21,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c98c5133-311c-4bf6-8d96-d160a05b5446",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	"75d7e3e8-5ec5-498c-bc6f-1c2ba2a74fda",
	23,
	1,
	'row::prune line: 23');
INSERT INTO ACT_IF
	VALUES ("c98c5133-311c-4bf6-8d96-d160a05b5446",
	"70046c94-eb5e-46f7-a840-9b6f0e918d6c",
	"ff8f3d6d-b388-462f-979c-9f153a6affd4",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("75d7e3e8-5ec5-498c-bc6f-1c2ba2a74fda",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	"43b455a9-e248-4ce9-a849-83ff4cf1a592",
	26,
	1,
	'row::prune line: 26');
INSERT INTO ACT_FOR
	VALUES ("75d7e3e8-5ec5-498c-bc6f-1c2ba2a74fda",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757",
	1,
	"e3b5ff8a-b5c4-4d8b-b1af-50ed41f7f71e",
	"0ddc703b-d389-4620-8afe-da175946a11a",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO ACT_SMT
	VALUES ("43b455a9-e248-4ce9-a849-83ff4cf1a592",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	"00000000-0000-0000-0000-000000000000",
	38,
	1,
	'row::prune line: 38');
INSERT INTO ACT_RET
	VALUES ("43b455a9-e248-4ce9-a849-83ff4cf1a592",
	"b5732fc4-0b4d-4d21-8327-c703f3f83668");
INSERT INTO V_VAL
	VALUES ("c029ac5a-4fc9-4426-87df-47eb0bf46c05",
	1,
	1,
	3,
	1,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_TVL
	VALUES ("c029ac5a-4fc9-4426-87df-47eb0bf46c05",
	"5a890b0d-3278-4d65-91bd-48fe7f4e9d3b");
INSERT INTO V_VAL
	VALUES ("b06f7802-a081-427f-ae93-bc320626be23",
	0,
	0,
	3,
	15,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_LIN
	VALUES ("b06f7802-a081-427f-ae93-bc320626be23",
	'0');
INSERT INTO V_VAL
	VALUES ("5e16f3fe-53c4-489d-a6b5-3bf6dc6da03e",
	0,
	0,
	4,
	37,
	40,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_IRF
	VALUES ("5e16f3fe-53c4-489d-a6b5-3bf6dc6da03e",
	"db61a3f5-2e6d-4602-a35b-ae7b58a08308");
INSERT INTO V_VAL
	VALUES ("87ae51b2-d9fc-49b0-bcf4-d49abce98a2d",
	0,
	0,
	4,
	71,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_SLR
	VALUES ("87ae51b2-d9fc-49b0-bcf4-d49abce98a2d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("2fa8b950-1a55-4227-8725-e635838696d9",
	0,
	0,
	4,
	80,
	84,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_AVL
	VALUES ("2fa8b950-1a55-4227-8725-e635838696d9",
	"87ae51b2-d9fc-49b0-bcf4-d49abce98a2d",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO V_VAL
	VALUES ("dbc84e05-66a3-42ab-8dc6-2d69b704ff21",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_BIN
	VALUES ("dbc84e05-66a3-42ab-8dc6-2d69b704ff21",
	"ec0d6c48-a016-4562-b1a0-30b76684a146",
	"2fa8b950-1a55-4227-8725-e635838696d9",
	'!=');
INSERT INTO V_VAL
	VALUES ("ec0d6c48-a016-4562-b1a0-30b76684a146",
	0,
	0,
	4,
	89,
	89,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_LIN
	VALUES ("ec0d6c48-a016-4562-b1a0-30b76684a146",
	'0');
INSERT INTO V_VAL
	VALUES ("904861f8-9a0d-4bd6-8864-267138f9f2e9",
	0,
	0,
	5,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_IRF
	VALUES ("904861f8-9a0d-4bd6-8864-267138f9f2e9",
	"db61a3f5-2e6d-4602-a35b-ae7b58a08308");
INSERT INTO V_VAL
	VALUES ("152ebc69-2972-4901-85dc-9eee8f2947cc",
	0,
	0,
	21,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_IRF
	VALUES ("152ebc69-2972-4901-85dc-9eee8f2947cc",
	"db61a3f5-2e6d-4602-a35b-ae7b58a08308");
INSERT INTO V_VAL
	VALUES ("12d0e7dc-aa29-4fb5-9f1c-d491aeaf15a3",
	0,
	0,
	22,
	11,
	-1,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_SLR
	VALUES ("12d0e7dc-aa29-4fb5-9f1c-d491aeaf15a3",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("3646c441-b26b-4ca6-82a6-c178706c94d6",
	0,
	0,
	22,
	20,
	31,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_AVL
	VALUES ("3646c441-b26b-4ca6-82a6-c178706c94d6",
	"12d0e7dc-aa29-4fb5-9f1c-d491aeaf15a3",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4");
INSERT INTO V_VAL
	VALUES ("10083afd-ad59-4146-9c89-d883ee988a22",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_BIN
	VALUES ("10083afd-ad59-4146-9c89-d883ee988a22",
	"a6b244b9-caab-4bbe-b323-85093ceeec20",
	"3646c441-b26b-4ca6-82a6-c178706c94d6",
	'==');
INSERT INTO V_VAL
	VALUES ("a6b244b9-caab-4bbe-b323-85093ceeec20",
	0,
	0,
	22,
	36,
	36,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_LIN
	VALUES ("a6b244b9-caab-4bbe-b323-85093ceeec20",
	'0');
INSERT INTO V_VAL
	VALUES ("7ecd4007-4870-4ae2-a9fe-a43633c91996",
	0,
	0,
	23,
	12,
	20,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_ISR
	VALUES ("7ecd4007-4870-4ae2-a9fe-a43633c91996",
	"0ddc703b-d389-4620-8afe-da175946a11a");
INSERT INTO V_VAL
	VALUES ("ff8f3d6d-b388-462f-979c-9f153a6affd4",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_UNY
	VALUES ("ff8f3d6d-b388-462f-979c-9f153a6affd4",
	"7ecd4007-4870-4ae2-a9fe-a43633c91996",
	'empty');
INSERT INTO V_VAL
	VALUES ("b5732fc4-0b4d-4d21-8327-c703f3f83668",
	0,
	0,
	38,
	8,
	18,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a");
INSERT INTO V_TVL
	VALUES ("b5732fc4-0b4d-4d21-8327-c703f3f83668",
	"5a890b0d-3278-4d65-91bd-48fe7f4e9d3b");
INSERT INTO V_VAR
	VALUES ("5a890b0d-3278-4d65-91bd-48fe7f4e9d3b",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	'temperature',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("5a890b0d-3278-4d65-91bd-48fe7f4e9d3b",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("915ec953-4c4b-4f27-8d2c-50e20b02bcbc",
	3,
	1,
	11,
	"5a890b0d-3278-4d65-91bd-48fe7f4e9d3b");
INSERT INTO V_LOC
	VALUES ("5228e68b-aa8d-4d47-bd5f-c0c923b6a9ca",
	15,
	7,
	17,
	"5a890b0d-3278-4d65-91bd-48fe7f4e9d3b");
INSERT INTO V_LOC
	VALUES ("ee4d5f24-b302-4d38-8577-64ab73788ce9",
	24,
	3,
	13,
	"5a890b0d-3278-4d65-91bd-48fe7f4e9d3b");
INSERT INTO V_LOC
	VALUES ("58626735-3078-4b66-938d-066816855429",
	34,
	5,
	15,
	"5a890b0d-3278-4d65-91bd-48fe7f4e9d3b");
INSERT INTO V_LOC
	VALUES ("3ef4b690-23c0-4200-8ea8-efdd4f3994c6",
	38,
	8,
	18,
	"5a890b0d-3278-4d65-91bd-48fe7f4e9d3b");
INSERT INTO V_VAR
	VALUES ("30884a09-8a44-4bc3-b156-0f46f7cce6d4",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	'answerdigits',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("30884a09-8a44-4bc3-b156-0f46f7cce6d4",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("100032df-0a00-4515-8685-291c33cadea1",
	4,
	13,
	24,
	"30884a09-8a44-4bc3-b156-0f46f7cce6d4");
INSERT INTO V_LOC
	VALUES ("c6bac027-098d-4e59-966a-34cbbdd923ec",
	7,
	27,
	38,
	"30884a09-8a44-4bc3-b156-0f46f7cce6d4");
INSERT INTO V_VAR
	VALUES ("db61a3f5-2e6d-4602-a35b-ae7b58a08308",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("db61a3f5-2e6d-4602-a35b-ae7b58a08308",
	0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_VAR
	VALUES ("cbe0f0d1-1cfb-4a3d-9976-6a3aa53ea5c2",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	'eligibles',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("cbe0f0d1-1cfb-4a3d-9976-6a3aa53ea5c2",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("c228672f-4b6c-4751-9d5d-6bdb191a2e8e",
	5,
	13,
	21,
	"cbe0f0d1-1cfb-4a3d-9976-6a3aa53ea5c2");
INSERT INTO V_LOC
	VALUES ("1b72710a-5759-4fee-b294-8f0552391635",
	6,
	22,
	30,
	"cbe0f0d1-1cfb-4a3d-9976-6a3aa53ea5c2");
INSERT INTO V_LOC
	VALUES ("9f513bf4-6f8a-44f7-8f9d-79f76d1cc685",
	28,
	15,
	23,
	"cbe0f0d1-1cfb-4a3d-9976-6a3aa53ea5c2");
INSERT INTO V_VAR
	VALUES ("5ab59d90-cb91-490b-b08f-b4bfcb4569f5",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	'eligible',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("5ab59d90-cb91-490b-b08f-b4bfcb4569f5",
	1,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("d83cf7e5-1b76-4774-9e9f-e82c034fb396",
	6,
	10,
	17,
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5");
INSERT INTO V_LOC
	VALUES ("c80fe465-3b9b-4c9c-8c54-f482cbd1bd25",
	8,
	10,
	17,
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5");
INSERT INTO V_LOC
	VALUES ("7f78ab89-2ba5-4e37-a221-cfca514bc314",
	10,
	37,
	44,
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5");
INSERT INTO V_LOC
	VALUES ("5bb081b0-7f59-4b75-ad6a-96191ef44e1b",
	11,
	60,
	67,
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5");
INSERT INTO V_LOC
	VALUES ("65824534-b662-4ccc-88e3-f3307e52b2ea",
	12,
	32,
	39,
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5");
INSERT INTO V_VAR
	VALUES ("0ddc703b-d389-4620-8afe-da175946a11a",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	'opencells',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("0ddc703b-d389-4620-8afe-da175946a11a",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("db27cad0-6084-44a8-8672-cdc03a1267ea",
	21,
	13,
	21,
	"0ddc703b-d389-4620-8afe-da175946a11a");
INSERT INTO V_LOC
	VALUES ("ec2b52f5-6327-4f30-bfc7-e7e2483862da",
	26,
	22,
	30,
	"0ddc703b-d389-4620-8afe-da175946a11a");
INSERT INTO V_VAR
	VALUES ("e3b5ff8a-b5c4-4d8b-b1af-50ed41f7f71e",
	"3d01f6f7-eb49-421c-9117-8bed27bf516a",
	'opencell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("e3b5ff8a-b5c4-4d8b-b1af-50ed41f7f71e",
	1,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("98cad276-d10c-43ef-98db-ce9448ef608f",
	26,
	10,
	17,
	"e3b5ff8a-b5c4-4d8b-b1af-50ed41f7f71e");
INSERT INTO V_LOC
	VALUES ("60eef909-2982-4a6b-840a-7d5e5b813751",
	32,
	5,
	12,
	"e3b5ff8a-b5c4-4d8b-b1af-50ed41f7f71e");
INSERT INTO ACT_BLK
	VALUES ("8fe35157-7920-4bef-9492-6979e5bce7c4",
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0d52dfb8-9f52-4860-92f6-50df3d299f4b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8fa448ea-2676-455b-810c-dcd869c06a2d",
	"8fe35157-7920-4bef-9492-6979e5bce7c4",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'row::prune line: 7');
INSERT INTO ACT_FOR
	VALUES ("8fa448ea-2676-455b-810c-dcd869c06a2d",
	"b45a0cf1-2975-4341-9ed8-7e658e378f83",
	1,
	"68a9019a-32db-43c2-8927-5fd4c7b1d295",
	"30884a09-8a44-4bc3-b156-0f46f7cce6d4",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_VAR
	VALUES ("68a9019a-32db-43c2-8927-5fd4c7b1d295",
	"8fe35157-7920-4bef-9492-6979e5bce7c4",
	'answerdigit',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("68a9019a-32db-43c2-8927-5fd4c7b1d295",
	1,
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1");
INSERT INTO V_LOC
	VALUES ("cc7711a2-525d-45e2-a791-308358fa3df4",
	7,
	12,
	22,
	"68a9019a-32db-43c2-8927-5fd4c7b1d295");
INSERT INTO V_LOC
	VALUES ("b27a28a0-47b0-4c79-ac40-575e4e680182",
	8,
	34,
	44,
	"68a9019a-32db-43c2-8927-5fd4c7b1d295");
INSERT INTO V_LOC
	VALUES ("6f188ae6-805c-440d-970b-11cb313cf093",
	11,
	18,
	28,
	"68a9019a-32db-43c2-8927-5fd4c7b1d295");
INSERT INTO ACT_BLK
	VALUES ("b45a0cf1-2975-4341-9ed8-7e658e378f83",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0d52dfb8-9f52-4860-92f6-50df3d299f4b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("03f2d800-821a-45d9-ac79-653562015929",
	"b45a0cf1-2975-4341-9ed8-7e658e378f83",
	"00000000-0000-0000-0000-000000000000",
	8,
	5,
	'row::prune line: 8');
INSERT INTO ACT_IF
	VALUES ("03f2d800-821a-45d9-ac79-653562015929",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b",
	"20b742f3-e937-46f7-a206-273828434085",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("38fa2524-040a-49fc-a339-6fd4222d7552",
	0,
	0,
	8,
	10,
	17,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"b45a0cf1-2975-4341-9ed8-7e658e378f83");
INSERT INTO V_IRF
	VALUES ("38fa2524-040a-49fc-a339-6fd4222d7552",
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5");
INSERT INTO V_VAL
	VALUES ("92209510-29a5-4cc8-a253-449bd4da9b04",
	0,
	0,
	8,
	19,
	29,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"b45a0cf1-2975-4341-9ed8-7e658e378f83");
INSERT INTO V_AVL
	VALUES ("92209510-29a5-4cc8-a253-449bd4da9b04",
	"38fa2524-040a-49fc-a339-6fd4222d7552",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("20b742f3-e937-46f7-a206-273828434085",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"b45a0cf1-2975-4341-9ed8-7e658e378f83");
INSERT INTO V_BIN
	VALUES ("20b742f3-e937-46f7-a206-273828434085",
	"f7fcfce9-207c-4325-9def-fcd7d0b3b7d5",
	"92209510-29a5-4cc8-a253-449bd4da9b04",
	'==');
INSERT INTO V_VAL
	VALUES ("3cda122a-f731-4686-9fcf-592974807cdd",
	0,
	0,
	8,
	34,
	44,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"b45a0cf1-2975-4341-9ed8-7e658e378f83");
INSERT INTO V_IRF
	VALUES ("3cda122a-f731-4686-9fcf-592974807cdd",
	"68a9019a-32db-43c2-8927-5fd4c7b1d295");
INSERT INTO V_VAL
	VALUES ("f7fcfce9-207c-4325-9def-fcd7d0b3b7d5",
	0,
	0,
	8,
	46,
	50,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"b45a0cf1-2975-4341-9ed8-7e658e378f83");
INSERT INTO V_AVL
	VALUES ("f7fcfce9-207c-4325-9def-fcd7d0b3b7d5",
	"3cda122a-f731-4686-9fcf-592974807cdd",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"d4a31f11-b441-44fd-a723-84a3ed5bf70d");
INSERT INTO ACT_BLK
	VALUES ("4a3121bb-220c-4cb3-b2ee-666ed6b4303b",
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	7,
	9,
	48,
	0,
	0,
	9,
	53,
	0,
	0,
	0,
	0,
	0,
	"0d52dfb8-9f52-4860-92f6-50df3d299f4b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9965fa48-a2ca-4d6a-a32d-00c2c8ed9aed",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b",
	"f4637f56-e099-40a1-854b-0ac902b165b8",
	9,
	7,
	'row::prune line: 9');
INSERT INTO ACT_SEL
	VALUES ("9965fa48-a2ca-4d6a-a32d-00c2c8ed9aed",
	"c0fccbd9-e42b-4285-a3cc-b183836bb59b",
	1,
	'one',
	"d027fc28-d2ba-46a5-9536-f7d79abf00bf");
INSERT INTO ACT_SR
	VALUES ("9965fa48-a2ca-4d6a-a32d-00c2c8ed9aed");
INSERT INTO ACT_LNK
	VALUES ("197443c3-1e2d-4546-a629-5c08837dd4a8",
	'',
	"9965fa48-a2ca-4d6a-a32d-00c2c8ed9aed",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	2,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	9,
	48,
	9,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f4637f56-e099-40a1-854b-0ac902b165b8",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b",
	"7e1a753f-1227-4749-bbab-34514bc0ec65",
	10,
	7,
	'row::prune line: 10');
INSERT INTO ACT_IF
	VALUES ("f4637f56-e099-40a1-854b-0ac902b165b8",
	"1327d426-765d-4a2e-9923-22d4c1ebf055",
	"db37ba56-6f95-4d09-9a61-5e4847ea05fc",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("7e1a753f-1227-4749-bbab-34514bc0ec65",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b",
	"567fc7bb-964e-486d-bf5d-3e6ce32992d5",
	15,
	7,
	'row::prune line: 15');
INSERT INTO ACT_AI
	VALUES ("7e1a753f-1227-4749-bbab-34514bc0ec65",
	"4a0e2791-378c-4db5-be18-5181ece027d0",
	"9c681ed5-d0a0-4640-a67c-287192d8b58f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("567fc7bb-964e-486d-bf5d-3e6ce32992d5",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b",
	"00000000-0000-0000-0000-000000000000",
	16,
	7,
	'row::prune line: 16');
INSERT INTO ACT_BRK
	VALUES ("567fc7bb-964e-486d-bf5d-3e6ce32992d5");
INSERT INTO V_VAL
	VALUES ("d027fc28-d2ba-46a5-9536-f7d79abf00bf",
	0,
	0,
	9,
	38,
	45,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b");
INSERT INTO V_IRF
	VALUES ("d027fc28-d2ba-46a5-9536-f7d79abf00bf",
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5");
INSERT INTO V_VAL
	VALUES ("9a140177-dfcb-4443-8f4e-159c11a451f8",
	0,
	0,
	10,
	12,
	19,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b");
INSERT INTO V_IRF
	VALUES ("9a140177-dfcb-4443-8f4e-159c11a451f8",
	"c0fccbd9-e42b-4285-a3cc-b183836bb59b");
INSERT INTO V_VAL
	VALUES ("ab6a6365-60b3-40e2-b3bc-0d92e3ae0701",
	0,
	0,
	10,
	21,
	32,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b");
INSERT INTO V_AVL
	VALUES ("ab6a6365-60b3-40e2-b3bc-0d92e3ae0701",
	"9a140177-dfcb-4443-8f4e-159c11a451f8",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"ad465dc0-8bb2-4ec7-b1aa-51dbdbe97bc4");
INSERT INTO V_VAL
	VALUES ("db37ba56-6f95-4d09-9a61-5e4847ea05fc",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b");
INSERT INTO V_BIN
	VALUES ("db37ba56-6f95-4d09-9a61-5e4847ea05fc",
	"87a84539-e326-4602-9ad9-21b9d220a3d1",
	"ab6a6365-60b3-40e2-b3bc-0d92e3ae0701",
	'!=');
INSERT INTO V_VAL
	VALUES ("8dbe7158-fd60-4142-a942-f39c3aa661ec",
	0,
	0,
	10,
	37,
	44,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b");
INSERT INTO V_IRF
	VALUES ("8dbe7158-fd60-4142-a942-f39c3aa661ec",
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5");
INSERT INTO V_VAL
	VALUES ("87a84539-e326-4602-9ad9-21b9d220a3d1",
	0,
	0,
	10,
	46,
	56,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b");
INSERT INTO V_AVL
	VALUES ("87a84539-e326-4602-9ad9-21b9d220a3d1",
	"8dbe7158-fd60-4142-a942-f39c3aa661ec",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_VAL
	VALUES ("9c681ed5-d0a0-4640-a67c-287192d8b58f",
	1,
	0,
	15,
	7,
	17,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b");
INSERT INTO V_TVL
	VALUES ("9c681ed5-d0a0-4640-a67c-287192d8b58f",
	"5a890b0d-3278-4d65-91bd-48fe7f4e9d3b");
INSERT INTO V_VAL
	VALUES ("4a0e2791-378c-4db5-be18-5181ece027d0",
	0,
	0,
	15,
	21,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b");
INSERT INTO V_LIN
	VALUES ("4a0e2791-378c-4db5-be18-5181ece027d0",
	'1');
INSERT INTO V_VAR
	VALUES ("c0fccbd9-e42b-4285-a3cc-b183836bb59b",
	"4a3121bb-220c-4cb3-b2ee-666ed6b4303b",
	'opencell',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("c0fccbd9-e42b-4285-a3cc-b183836bb59b",
	0,
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41");
INSERT INTO V_LOC
	VALUES ("8f89c5cc-2954-4fef-aebe-322deb62779a",
	9,
	18,
	25,
	"c0fccbd9-e42b-4285-a3cc-b183836bb59b");
INSERT INTO V_LOC
	VALUES ("2e95c537-f3a4-4d25-b842-772581bfcdd6",
	10,
	12,
	19,
	"c0fccbd9-e42b-4285-a3cc-b183836bb59b");
INSERT INTO V_LOC
	VALUES ("ee31b6ef-6500-4b01-a4ad-149d87873a3f",
	11,
	35,
	42,
	"c0fccbd9-e42b-4285-a3cc-b183836bb59b");
INSERT INTO ACT_BLK
	VALUES ("1327d426-765d-4a2e-9923-22d4c1ebf055",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	9,
	0,
	0,
	0,
	0,
	11,
	51,
	0,
	0,
	0,
	0,
	0,
	"0d52dfb8-9f52-4860-92f6-50df3d299f4b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ac6b3123-e15f-4ee1-8f31-8d88eba905b4",
	"1327d426-765d-4a2e-9923-22d4c1ebf055",
	"76e0de33-1d73-41f1-8dc5-13e72f04cc59",
	11,
	9,
	'row::prune line: 11');
INSERT INTO ACT_URU
	VALUES ("ac6b3123-e15f-4ee1-8f31-8d88eba905b4",
	"68a9019a-32db-43c2-8927-5fd4c7b1d295",
	"c0fccbd9-e42b-4285-a3cc-b183836bb59b",
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5",
	'',
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	11,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("76e0de33-1d73-41f1-8dc5-13e72f04cc59",
	"1327d426-765d-4a2e-9923-22d4c1ebf055",
	"00000000-0000-0000-0000-000000000000",
	12,
	9,
	'row::prune line: 12');
INSERT INTO ACT_DEL
	VALUES ("76e0de33-1d73-41f1-8dc5-13e72f04cc59",
	"5ab59d90-cb91-490b-b08f-b4bfcb4569f5");
INSERT INTO ACT_BLK
	VALUES ("70046c94-eb5e-46f7-a840-9b6f0e918d6c",
	0,
	0,
	0,
	'',
	'',
	'',
	24,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0d52dfb8-9f52-4860-92f6-50df3d299f4b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("72a6f35a-822b-4d78-8d95-dc07f18bef07",
	"70046c94-eb5e-46f7-a840-9b6f0e918d6c",
	"00000000-0000-0000-0000-000000000000",
	24,
	3,
	'row::prune line: 24');
INSERT INTO ACT_AI
	VALUES ("72a6f35a-822b-4d78-8d95-dc07f18bef07",
	"3b213adc-13f4-46ca-b881-f482731175df",
	"b18f706b-0fed-4c62-acd2-4c5dba2e6c5a",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("b18f706b-0fed-4c62-acd2-4c5dba2e6c5a",
	1,
	0,
	24,
	3,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"70046c94-eb5e-46f7-a840-9b6f0e918d6c");
INSERT INTO V_TVL
	VALUES ("b18f706b-0fed-4c62-acd2-4c5dba2e6c5a",
	"5a890b0d-3278-4d65-91bd-48fe7f4e9d3b");
INSERT INTO V_VAL
	VALUES ("3b213adc-13f4-46ca-b881-f482731175df",
	0,
	0,
	24,
	17,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"70046c94-eb5e-46f7-a840-9b6f0e918d6c");
INSERT INTO V_LIN
	VALUES ("3b213adc-13f4-46ca-b881-f482731175df",
	'100');
INSERT INTO ACT_BLK
	VALUES ("22dc066a-6c2d-4fac-a3ad-d2d01ac98757",
	1,
	0,
	0,
	'',
	'',
	'',
	30,
	3,
	28,
	46,
	0,
	0,
	28,
	55,
	0,
	0,
	0,
	0,
	0,
	"0d52dfb8-9f52-4860-92f6-50df3d299f4b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ef7e6169-3174-4bca-98cc-2bc8dbe6747e",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757",
	"3b11915a-e7ef-43e5-bd60-0e5a4e5a0e16",
	28,
	3,
	'row::prune line: 28');
INSERT INTO ACT_SEL
	VALUES ("ef7e6169-3174-4bca-98cc-2bc8dbe6747e",
	"cbe0f0d1-1cfb-4a3d-9976-6a3aa53ea5c2",
	0,
	'many',
	"532b2827-3af6-402f-8783-b2478ce3662f");
INSERT INTO ACT_SR
	VALUES ("ef7e6169-3174-4bca-98cc-2bc8dbe6747e");
INSERT INTO ACT_LNK
	VALUES ("5778b29d-acd2-4cf7-b437-d46453794e5c",
	'',
	"ef7e6169-3174-4bca-98cc-2bc8dbe6747e",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	28,
	46,
	28,
	55,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("3b11915a-e7ef-43e5-bd60-0e5a4e5a0e16",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757",
	"3687a000-8612-4465-82b3-1e1b694cb4e6",
	29,
	3,
	'row::prune line: 29');
INSERT INTO ACT_AI
	VALUES ("3b11915a-e7ef-43e5-bd60-0e5a4e5a0e16",
	"e6fe4d6d-313c-4ee5-9c2b-77e7b8be437b",
	"deafa650-7387-47d4-80c4-8cc1240eb1a0",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("3687a000-8612-4465-82b3-1e1b694cb4e6",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757",
	"00000000-0000-0000-0000-000000000000",
	30,
	3,
	'row::prune line: 30');
INSERT INTO ACT_IF
	VALUES ("3687a000-8612-4465-82b3-1e1b694cb4e6",
	"7014bcc5-dd4e-4551-a042-8cdd172d3010",
	"582f6560-9b3a-4a32-824a-b13753a5bc77",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("532b2827-3af6-402f-8783-b2478ce3662f",
	0,
	0,
	28,
	36,
	43,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757");
INSERT INTO V_IRF
	VALUES ("532b2827-3af6-402f-8783-b2478ce3662f",
	"e3b5ff8a-b5c4-4d8b-b1af-50ed41f7f71e");
INSERT INTO V_VAL
	VALUES ("deafa650-7387-47d4-80c4-8cc1240eb1a0",
	1,
	1,
	29,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757");
INSERT INTO V_TVL
	VALUES ("deafa650-7387-47d4-80c4-8cc1240eb1a0",
	"6eecc696-dd75-45de-bced-12048de5369c");
INSERT INTO V_VAL
	VALUES ("0fcd8a8d-5d62-46b0-9b5f-3d75b277c06d",
	0,
	0,
	29,
	19,
	27,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757");
INSERT INTO V_ISR
	VALUES ("0fcd8a8d-5d62-46b0-9b5f-3d75b277c06d",
	"cbe0f0d1-1cfb-4a3d-9976-6a3aa53ea5c2");
INSERT INTO V_VAL
	VALUES ("e6fe4d6d-313c-4ee5-9c2b-77e7b8be437b",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757");
INSERT INTO V_UNY
	VALUES ("e6fe4d6d-313c-4ee5-9c2b-77e7b8be437b",
	"0fcd8a8d-5d62-46b0-9b5f-3d75b277c06d",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("2e832c3a-75b5-483c-af7c-5789f42e874f",
	0,
	0,
	30,
	8,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757");
INSERT INTO V_LIN
	VALUES ("2e832c3a-75b5-483c-af7c-5789f42e874f",
	'1');
INSERT INTO V_VAL
	VALUES ("582f6560-9b3a-4a32-824a-b13753a5bc77",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757");
INSERT INTO V_BIN
	VALUES ("582f6560-9b3a-4a32-824a-b13753a5bc77",
	"47180978-5dd1-4a2a-932f-6ffc77ac2920",
	"2e832c3a-75b5-483c-af7c-5789f42e874f",
	'==');
INSERT INTO V_VAL
	VALUES ("47180978-5dd1-4a2a-932f-6ffc77ac2920",
	0,
	0,
	30,
	13,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757");
INSERT INTO V_TVL
	VALUES ("47180978-5dd1-4a2a-932f-6ffc77ac2920",
	"6eecc696-dd75-45de-bced-12048de5369c");
INSERT INTO V_VAR
	VALUES ("6eecc696-dd75-45de-bced-12048de5369c",
	"22dc066a-6c2d-4fac-a3ad-d2d01ac98757",
	'c',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("6eecc696-dd75-45de-bced-12048de5369c",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("8b3a2b92-73eb-4402-bc48-b87ec56d3eb7",
	29,
	3,
	3,
	"6eecc696-dd75-45de-bced-12048de5369c");
INSERT INTO V_LOC
	VALUES ("6529dbae-43d4-463c-9a1f-ac2eaa8d2559",
	30,
	13,
	13,
	"6eecc696-dd75-45de-bced-12048de5369c");
INSERT INTO ACT_BLK
	VALUES ("7014bcc5-dd4e-4551-a042-8cdd172d3010",
	1,
	0,
	0,
	'',
	'',
	'',
	34,
	5,
	31,
	44,
	0,
	0,
	31,
	53,
	0,
	0,
	0,
	0,
	0,
	"0d52dfb8-9f52-4860-92f6-50df3d299f4b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("cf536954-1f71-495e-9763-47f0439b4baa",
	"7014bcc5-dd4e-4551-a042-8cdd172d3010",
	"9443c14f-98f2-42a8-866b-e4b43a967701",
	31,
	5,
	'row::prune line: 31');
INSERT INTO ACT_SEL
	VALUES ("cf536954-1f71-495e-9763-47f0439b4baa",
	"9968261b-c8e7-4ce0-a6ca-2ba76e87b4d4",
	1,
	'any',
	"9eecd228-7953-4130-8f55-f8d4e7c3b1ac");
INSERT INTO ACT_SR
	VALUES ("cf536954-1f71-495e-9763-47f0439b4baa");
INSERT INTO ACT_LNK
	VALUES ("f76fb25a-602a-494d-82f2-a33134ed8717",
	'',
	"cf536954-1f71-495e-9763-47f0439b4baa",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"00000000-0000-0000-0000-000000000000",
	3,
	"497a9d44-e141-4345-bf11-bb067fb75473",
	31,
	44,
	31,
	53,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9443c14f-98f2-42a8-866b-e4b43a967701",
	"7014bcc5-dd4e-4551-a042-8cdd172d3010",
	"7cea50c3-d9d0-4180-afb8-495348ddbb8d",
	32,
	5,
	'row::prune line: 32');
INSERT INTO ACT_TFM
	VALUES ("9443c14f-98f2-42a8-866b-e4b43a967701",
	"4dbd3878-9ff1-4fa9-8ff2-db063b3aa997",
	"e3b5ff8a-b5c4-4d8b-b1af-50ed41f7f71e",
	32,
	14,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7cea50c3-d9d0-4180-afb8-495348ddbb8d",
	"7014bcc5-dd4e-4551-a042-8cdd172d3010",
	"00000000-0000-0000-0000-000000000000",
	34,
	5,
	'row::prune line: 34');
INSERT INTO ACT_AI
	VALUES ("7cea50c3-d9d0-4180-afb8-495348ddbb8d",
	"e38892ef-5505-4fcb-bd59-a47cee64ff0d",
	"fdde43a8-77ab-4f7c-bd39-6665be5e5fb6",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("9eecd228-7953-4130-8f55-f8d4e7c3b1ac",
	0,
	0,
	31,
	34,
	41,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"7014bcc5-dd4e-4551-a042-8cdd172d3010");
INSERT INTO V_IRF
	VALUES ("9eecd228-7953-4130-8f55-f8d4e7c3b1ac",
	"e3b5ff8a-b5c4-4d8b-b1af-50ed41f7f71e");
INSERT INTO V_VAL
	VALUES ("226da4c6-925b-4078-b250-1c86902b3515",
	0,
	0,
	32,
	35,
	40,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"7014bcc5-dd4e-4551-a042-8cdd172d3010");
INSERT INTO V_IRF
	VALUES ("226da4c6-925b-4078-b250-1c86902b3515",
	"9968261b-c8e7-4ce0-a6ca-2ba76e87b4d4");
INSERT INTO V_VAL
	VALUES ("d4bfb7fb-91db-4350-aa22-e3ec03c7cfc0",
	0,
	0,
	32,
	42,
	52,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7014bcc5-dd4e-4551-a042-8cdd172d3010");
INSERT INTO V_AVL
	VALUES ("d4bfb7fb-91db-4350-aa22-e3ec03c7cfc0",
	"226da4c6-925b-4078-b250-1c86902b3515",
	"497a9d44-e141-4345-bf11-bb067fb75473",
	"9d825ab9-0879-4dc5-adfc-18c679fd5bf2");
INSERT INTO V_PAR
	VALUES ("d4bfb7fb-91db-4350-aa22-e3ec03c7cfc0",
	"9443c14f-98f2-42a8-866b-e4b43a967701",
	"00000000-0000-0000-0000-000000000000",
	'answer_digit',
	"00000000-0000-0000-0000-000000000000",
	32,
	22);
INSERT INTO V_VAL
	VALUES ("fdde43a8-77ab-4f7c-bd39-6665be5e5fb6",
	1,
	0,
	34,
	5,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7014bcc5-dd4e-4551-a042-8cdd172d3010");
INSERT INTO V_TVL
	VALUES ("fdde43a8-77ab-4f7c-bd39-6665be5e5fb6",
	"5a890b0d-3278-4d65-91bd-48fe7f4e9d3b");
INSERT INTO V_VAL
	VALUES ("e38892ef-5505-4fcb-bd59-a47cee64ff0d",
	0,
	0,
	34,
	19,
	19,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7014bcc5-dd4e-4551-a042-8cdd172d3010");
INSERT INTO V_LIN
	VALUES ("e38892ef-5505-4fcb-bd59-a47cee64ff0d",
	'1');
INSERT INTO V_VAR
	VALUES ("9968261b-c8e7-4ce0-a6ca-2ba76e87b4d4",
	"7014bcc5-dd4e-4551-a042-8cdd172d3010",
	'answer',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("9968261b-c8e7-4ce0-a6ca-2ba76e87b4d4",
	0,
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("2a90ac03-2039-4a17-abb1-f0e5ecbf94be",
	31,
	16,
	21,
	"9968261b-c8e7-4ce0-a6ca-2ba76e87b4d4");
INSERT INTO V_LOC
	VALUES ("21abe602-bd43-407b-8476-fe249bb44b07",
	32,
	35,
	40,
	"9968261b-c8e7-4ce0-a6ca-2ba76e87b4d4");
INSERT INTO O_NBATTR
	VALUES ("bc6df04d-3498-4476-817a-f3273e8f61f2",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO O_BATTR
	VALUES ("bc6df04d-3498-4476-817a-f3273e8f61f2",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO O_ATTR
	VALUES ("bc6df04d-3498-4476-817a-f3273e8f61f2",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	"00000000-0000-0000-0000-000000000000",
	'number',
	'',
	'',
	'number',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("32f107e3-51ad-485c-a779-08e51fad1dd7",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO O_BATTR
	VALUES ("32f107e3-51ad-485c-a779-08e51fad1dd7",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO O_ATTR
	VALUES ("32f107e3-51ad-485c-a779-08e51fad1dd7",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	"bc6df04d-3498-4476-817a-f3273e8f61f2",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"65468da2-1083-4089-81cf-f2430c0ade46",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO O_ID
	VALUES (1,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO O_OIDA
	VALUES ("bc6df04d-3498-4476-817a-f3273e8f61f2",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	1);
INSERT INTO O_ID
	VALUES (2,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO SM_ISM
	VALUES ("8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO SM_SM
	VALUES ("8756fa70-1836-4b50-a6f3-6d40024a0e16",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("8756fa70-1836-4b50-a6f3-6d40024a0e16");
INSERT INTO SM_LEVT
	VALUES ("565ead81-20dd-40d5-a168-fbed8112e7aa",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("565ead81-20dd-40d5-a168-fbed8112e7aa",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("565ead81-20dd-40d5-a168-fbed8112e7aa",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000",
	1,
	'update',
	0,
	'',
	'ROW1',
	'');
INSERT INTO SM_LEVT
	VALUES ("102c313e-0cd7-458b-bd29-cb901f3bcf5c",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("102c313e-0cd7-458b-bd29-cb901f3bcf5c",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("102c313e-0cd7-458b-bd29-cb901f3bcf5c",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000",
	2,
	'solved',
	0,
	'',
	'ROW2',
	'');
INSERT INTO SM_STATE
	VALUES ("ef7d8e7d-d0f3-4213-b1e8-9e643d3df27a",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000",
	'solving',
	1,
	0);
INSERT INTO SM_SEME
	VALUES ("ef7d8e7d-d0f3-4213-b1e8-9e643d3df27a",
	"565ead81-20dd-40d5-a168-fbed8112e7aa",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("ef7d8e7d-d0f3-4213-b1e8-9e643d3df27a",
	"102c313e-0cd7-458b-bd29-cb901f3bcf5c",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("6eafc095-4e79-4c06-ad7f-6a1592abbedb",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"ef7d8e7d-d0f3-4213-b1e8-9e643d3df27a");
INSERT INTO SM_AH
	VALUES ("6eafc095-4e79-4c06-ad7f-6a1592abbedb",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16");
INSERT INTO SM_ACT
	VALUES ("6eafc095-4e79-4c06-ad7f-6a1592abbedb",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	1,
	'if ( 100 == self.prune() )
  generate ROW2:solved() to self;
elif ( 100 == self.eliminate() )
  generate ROW2:solved() to self;
else
  select one sequence related by self->SEQUENCE[R1];
  if ( sequence.requests >= 1 )
    sequence.requests = 1;
    r = self;
    generate ROW1:update() to r;
  else
    sequence.requests = 0;
  end if;
end if;
',
	'');
INSERT INTO ACT_SAB
	VALUES ("0580667e-514c-454d-b9c3-342f49283489",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"6eafc095-4e79-4c06-ad7f-6a1592abbedb");
INSERT INTO ACT_ACT
	VALUES ("0580667e-514c-454d-b9c3-342f49283489",
	'state',
	0,
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f",
	"00000000-0000-0000-0000-000000000000",
	0,
	'row::solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("37dbe528-01ea-4aa7-ae84-b6aa0ff3069f",
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0580667e-514c-454d-b9c3-342f49283489",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ae1c8d0c-e5c4-4a74-b333-65aa9f02dc50",
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'row::solving line: 1');
INSERT INTO ACT_IF
	VALUES ("ae1c8d0c-e5c4-4a74-b333-65aa9f02dc50",
	"106ac410-9bff-452f-ad1c-6fd6d20e3862",
	"86126b21-b28d-487e-ba43-8d3f38ac8e26",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("246506af-17dc-4100-b051-897a6a497473",
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f",
	"00000000-0000-0000-0000-000000000000",
	3,
	1,
	'row::solving line: 3');
INSERT INTO ACT_EL
	VALUES ("246506af-17dc-4100-b051-897a6a497473",
	"653b0610-9e84-4a4e-922e-19ddfe964d64",
	"d79cbfc2-1b61-440f-9a71-3f02d2c20b9a",
	"ae1c8d0c-e5c4-4a74-b333-65aa9f02dc50");
INSERT INTO ACT_SMT
	VALUES ("18148ca3-135d-402f-9418-83bf994c43e9",
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'row::solving line: 5');
INSERT INTO ACT_E
	VALUES ("18148ca3-135d-402f-9418-83bf994c43e9",
	"1986abdb-5ff1-4869-89ba-a574b429cc54",
	"ae1c8d0c-e5c4-4a74-b333-65aa9f02dc50");
INSERT INTO V_VAL
	VALUES ("1a5b0147-7283-4f0f-acaa-31a45458bf25",
	0,
	0,
	1,
	6,
	8,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f");
INSERT INTO V_LIN
	VALUES ("1a5b0147-7283-4f0f-acaa-31a45458bf25",
	'100');
INSERT INTO V_VAL
	VALUES ("86126b21-b28d-487e-ba43-8d3f38ac8e26",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f");
INSERT INTO V_BIN
	VALUES ("86126b21-b28d-487e-ba43-8d3f38ac8e26",
	"9f4ebcfa-0389-496a-b432-ea139db0f056",
	"1a5b0147-7283-4f0f-acaa-31a45458bf25",
	'==');
INSERT INTO V_VAL
	VALUES ("9f4ebcfa-0389-496a-b432-ea139db0f056",
	0,
	0,
	1,
	18,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f");
INSERT INTO V_TRV
	VALUES ("9f4ebcfa-0389-496a-b432-ea139db0f056",
	"974f15af-1f69-41a6-818a-7e3763126756",
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c",
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES ("3e82d549-1093-48b7-8424-1be46e8e79e2",
	0,
	0,
	3,
	8,
	10,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f");
INSERT INTO V_LIN
	VALUES ("3e82d549-1093-48b7-8424-1be46e8e79e2",
	'100');
INSERT INTO V_VAL
	VALUES ("d79cbfc2-1b61-440f-9a71-3f02d2c20b9a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f");
INSERT INTO V_BIN
	VALUES ("d79cbfc2-1b61-440f-9a71-3f02d2c20b9a",
	"5c4ac5bd-b37e-4d42-9ec4-1239a01121ca",
	"3e82d549-1093-48b7-8424-1be46e8e79e2",
	'==');
INSERT INTO V_VAL
	VALUES ("5c4ac5bd-b37e-4d42-9ec4-1239a01121ca",
	0,
	0,
	3,
	20,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f");
INSERT INTO V_TRV
	VALUES ("5c4ac5bd-b37e-4d42-9ec4-1239a01121ca",
	"0c6ffade-4c66-4b70-b714-534336415dd0",
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c",
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("4847bb1f-52ec-4a35-9ba3-885a7e34386c",
	"37dbe528-01ea-4aa7-ae84-b6aa0ff3069f",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("4847bb1f-52ec-4a35-9ba3-885a7e34386c",
	0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("b378893f-62c7-4caf-af0a-3223626002fe",
	1,
	13,
	16,
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c");
INSERT INTO V_LOC
	VALUES ("baed12e0-08e5-4fff-a160-111cb8e80f79",
	2,
	29,
	32,
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c");
INSERT INTO V_LOC
	VALUES ("1599f95c-28a7-4e8a-a18e-6031a20590ac",
	3,
	15,
	18,
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c");
INSERT INTO V_LOC
	VALUES ("f5cd950f-a7dd-4ec5-a964-f268e3940803",
	4,
	29,
	32,
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c");
INSERT INTO V_LOC
	VALUES ("4feadc18-e8ad-4582-a9f8-f56641f03936",
	9,
	9,
	12,
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c");
INSERT INTO ACT_BLK
	VALUES ("106ac410-9bff-452f-ad1c-6fd6d20e3862",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0580667e-514c-454d-b9c3-342f49283489",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("ce31b099-bab1-49fb-9a54-42adf54a0e67",
	"106ac410-9bff-452f-ad1c-6fd6d20e3862",
	"00000000-0000-0000-0000-000000000000",
	2,
	3,
	'row::solving line: 2');
INSERT INTO E_ESS
	VALUES ("ce31b099-bab1-49fb-9a54-42adf54a0e67",
	1,
	0,
	2,
	12,
	2,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("ce31b099-bab1-49fb-9a54-42adf54a0e67");
INSERT INTO E_GSME
	VALUES ("ce31b099-bab1-49fb-9a54-42adf54a0e67",
	"102c313e-0cd7-458b-bd29-cb901f3bcf5c",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16");
INSERT INTO E_GEN
	VALUES ("ce31b099-bab1-49fb-9a54-42adf54a0e67",
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c");
INSERT INTO ACT_BLK
	VALUES ("653b0610-9e84-4a4e-922e-19ddfe964d64",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0580667e-514c-454d-b9c3-342f49283489",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("df155e1a-5941-48c9-97fd-1bb3f9429611",
	"653b0610-9e84-4a4e-922e-19ddfe964d64",
	"00000000-0000-0000-0000-000000000000",
	4,
	3,
	'row::solving line: 4');
INSERT INTO E_ESS
	VALUES ("df155e1a-5941-48c9-97fd-1bb3f9429611",
	1,
	0,
	4,
	12,
	4,
	17,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("df155e1a-5941-48c9-97fd-1bb3f9429611");
INSERT INTO E_GSME
	VALUES ("df155e1a-5941-48c9-97fd-1bb3f9429611",
	"102c313e-0cd7-458b-bd29-cb901f3bcf5c",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16");
INSERT INTO E_GEN
	VALUES ("df155e1a-5941-48c9-97fd-1bb3f9429611",
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c");
INSERT INTO ACT_BLK
	VALUES ("1986abdb-5ff1-4869-89ba-a574b429cc54",
	1,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	6,
	40,
	0,
	0,
	6,
	49,
	0,
	0,
	0,
	0,
	0,
	"0580667e-514c-454d-b9c3-342f49283489",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("618275a1-ae5c-45f2-89ba-9bf880239d4b",
	"1986abdb-5ff1-4869-89ba-a574b429cc54",
	"5ed2d7c9-b8ad-4b56-b7ba-249dd5f636cb",
	6,
	3,
	'row::solving line: 6');
INSERT INTO ACT_SEL
	VALUES ("618275a1-ae5c-45f2-89ba-9bf880239d4b",
	"9de555ce-fefd-41ac-8e3d-ff859de0e226",
	1,
	'one',
	"e8623ec8-2ef3-48ae-adc7-8d07a92b3cdf");
INSERT INTO ACT_SR
	VALUES ("618275a1-ae5c-45f2-89ba-9bf880239d4b");
INSERT INTO ACT_LNK
	VALUES ("477f147f-9c84-4d29-9691-74a2ea1bca18",
	'',
	"618275a1-ae5c-45f2-89ba-9bf880239d4b",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	6,
	40,
	6,
	49,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5ed2d7c9-b8ad-4b56-b7ba-249dd5f636cb",
	"1986abdb-5ff1-4869-89ba-a574b429cc54",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'row::solving line: 7');
INSERT INTO ACT_IF
	VALUES ("5ed2d7c9-b8ad-4b56-b7ba-249dd5f636cb",
	"a2a6e5f1-b55b-41c0-82e8-355e924eee7e",
	"8add5521-ef73-4f03-8b17-06c239a1515c",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e6df5abc-fcd9-4504-8579-5ca64dc802ee",
	"1986abdb-5ff1-4869-89ba-a574b429cc54",
	"00000000-0000-0000-0000-000000000000",
	11,
	3,
	'row::solving line: 11');
INSERT INTO ACT_E
	VALUES ("e6df5abc-fcd9-4504-8579-5ca64dc802ee",
	"138325a6-ed68-4910-8bcf-b90a950958aa",
	"5ed2d7c9-b8ad-4b56-b7ba-249dd5f636cb");
INSERT INTO V_VAL
	VALUES ("e8623ec8-2ef3-48ae-adc7-8d07a92b3cdf",
	0,
	0,
	6,
	34,
	37,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"1986abdb-5ff1-4869-89ba-a574b429cc54");
INSERT INTO V_IRF
	VALUES ("e8623ec8-2ef3-48ae-adc7-8d07a92b3cdf",
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c");
INSERT INTO V_VAL
	VALUES ("3aac814a-25dd-432e-9fec-55bfe42b18a6",
	0,
	0,
	7,
	8,
	15,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"1986abdb-5ff1-4869-89ba-a574b429cc54");
INSERT INTO V_IRF
	VALUES ("3aac814a-25dd-432e-9fec-55bfe42b18a6",
	"9de555ce-fefd-41ac-8e3d-ff859de0e226");
INSERT INTO V_VAL
	VALUES ("b883a792-5d9d-4136-94c2-81579c7fec54",
	0,
	0,
	7,
	17,
	24,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"1986abdb-5ff1-4869-89ba-a574b429cc54");
INSERT INTO V_AVL
	VALUES ("b883a792-5d9d-4136-94c2-81579c7fec54",
	"3aac814a-25dd-432e-9fec-55bfe42b18a6",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("8add5521-ef73-4f03-8b17-06c239a1515c",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"1986abdb-5ff1-4869-89ba-a574b429cc54");
INSERT INTO V_BIN
	VALUES ("8add5521-ef73-4f03-8b17-06c239a1515c",
	"15a8a804-eff8-426c-bd1f-c983b425034f",
	"b883a792-5d9d-4136-94c2-81579c7fec54",
	'>=');
INSERT INTO V_VAL
	VALUES ("15a8a804-eff8-426c-bd1f-c983b425034f",
	0,
	0,
	7,
	29,
	29,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"1986abdb-5ff1-4869-89ba-a574b429cc54");
INSERT INTO V_LIN
	VALUES ("15a8a804-eff8-426c-bd1f-c983b425034f",
	'1');
INSERT INTO V_VAR
	VALUES ("9de555ce-fefd-41ac-8e3d-ff859de0e226",
	"1986abdb-5ff1-4869-89ba-a574b429cc54",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("9de555ce-fefd-41ac-8e3d-ff859de0e226",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("db932d2a-bcbf-4d1b-b448-16fec764fe7d",
	6,
	14,
	21,
	"9de555ce-fefd-41ac-8e3d-ff859de0e226");
INSERT INTO V_LOC
	VALUES ("8af3770d-14ce-4e31-9431-1463c1b0f1c6",
	7,
	8,
	15,
	"9de555ce-fefd-41ac-8e3d-ff859de0e226");
INSERT INTO V_LOC
	VALUES ("7578e437-2f07-467e-b298-6162c903497e",
	8,
	5,
	12,
	"9de555ce-fefd-41ac-8e3d-ff859de0e226");
INSERT INTO V_LOC
	VALUES ("1d99c41f-3684-4a4f-a6e2-79d544467c3a",
	12,
	5,
	12,
	"9de555ce-fefd-41ac-8e3d-ff859de0e226");
INSERT INTO ACT_BLK
	VALUES ("a2a6e5f1-b55b-41c0-82e8-355e924eee7e",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0580667e-514c-454d-b9c3-342f49283489",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3d4143a7-d23f-401e-8a3f-e67963b8cd35",
	"a2a6e5f1-b55b-41c0-82e8-355e924eee7e",
	"cb45a49e-8350-46fe-8df4-446f0cd5b17c",
	8,
	5,
	'row::solving line: 8');
INSERT INTO ACT_AI
	VALUES ("3d4143a7-d23f-401e-8a3f-e67963b8cd35",
	"51140ddc-5fcc-4269-9994-1d3ef2f01bc1",
	"1c61938e-12a3-4a41-8062-ee18ea30df58",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("cb45a49e-8350-46fe-8df4-446f0cd5b17c",
	"a2a6e5f1-b55b-41c0-82e8-355e924eee7e",
	"8623e8bd-30d9-42b9-b22a-af4a95db89d3",
	9,
	5,
	'row::solving line: 9');
INSERT INTO ACT_AI
	VALUES ("cb45a49e-8350-46fe-8df4-446f0cd5b17c",
	"b3dae949-3c3d-459e-b882-e432cd737239",
	"021a1f6a-aa13-4962-bce5-bd3ac4f38eaf",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8623e8bd-30d9-42b9-b22a-af4a95db89d3",
	"a2a6e5f1-b55b-41c0-82e8-355e924eee7e",
	"00000000-0000-0000-0000-000000000000",
	10,
	5,
	'row::solving line: 10');
INSERT INTO E_ESS
	VALUES ("8623e8bd-30d9-42b9-b22a-af4a95db89d3",
	1,
	0,
	10,
	14,
	10,
	19,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("8623e8bd-30d9-42b9-b22a-af4a95db89d3");
INSERT INTO E_GSME
	VALUES ("8623e8bd-30d9-42b9-b22a-af4a95db89d3",
	"565ead81-20dd-40d5-a168-fbed8112e7aa",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16");
INSERT INTO E_GEN
	VALUES ("8623e8bd-30d9-42b9-b22a-af4a95db89d3",
	"3b150a0d-b91c-4c97-ab93-a9dfb374e95f");
INSERT INTO V_VAL
	VALUES ("0e8105d9-9de5-41db-8d2e-fa6895d829d8",
	1,
	0,
	8,
	5,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"a2a6e5f1-b55b-41c0-82e8-355e924eee7e");
INSERT INTO V_IRF
	VALUES ("0e8105d9-9de5-41db-8d2e-fa6895d829d8",
	"9de555ce-fefd-41ac-8e3d-ff859de0e226");
INSERT INTO V_VAL
	VALUES ("1c61938e-12a3-4a41-8062-ee18ea30df58",
	1,
	0,
	8,
	14,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"a2a6e5f1-b55b-41c0-82e8-355e924eee7e");
INSERT INTO V_AVL
	VALUES ("1c61938e-12a3-4a41-8062-ee18ea30df58",
	"0e8105d9-9de5-41db-8d2e-fa6895d829d8",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("51140ddc-5fcc-4269-9994-1d3ef2f01bc1",
	0,
	0,
	8,
	25,
	25,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"a2a6e5f1-b55b-41c0-82e8-355e924eee7e");
INSERT INTO V_LIN
	VALUES ("51140ddc-5fcc-4269-9994-1d3ef2f01bc1",
	'1');
INSERT INTO V_VAL
	VALUES ("021a1f6a-aa13-4962-bce5-bd3ac4f38eaf",
	1,
	1,
	9,
	5,
	5,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"a2a6e5f1-b55b-41c0-82e8-355e924eee7e");
INSERT INTO V_IRF
	VALUES ("021a1f6a-aa13-4962-bce5-bd3ac4f38eaf",
	"3b150a0d-b91c-4c97-ab93-a9dfb374e95f");
INSERT INTO V_VAL
	VALUES ("b3dae949-3c3d-459e-b882-e432cd737239",
	0,
	0,
	9,
	9,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"a2a6e5f1-b55b-41c0-82e8-355e924eee7e");
INSERT INTO V_IRF
	VALUES ("b3dae949-3c3d-459e-b882-e432cd737239",
	"4847bb1f-52ec-4a35-9ba3-885a7e34386c");
INSERT INTO V_VAR
	VALUES ("3b150a0d-b91c-4c97-ab93-a9dfb374e95f",
	"a2a6e5f1-b55b-41c0-82e8-355e924eee7e",
	'r',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("3b150a0d-b91c-4c97-ab93-a9dfb374e95f",
	0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("868fcccf-7170-4b3a-b093-f1bdb118c82f",
	9,
	5,
	5,
	"3b150a0d-b91c-4c97-ab93-a9dfb374e95f");
INSERT INTO V_LOC
	VALUES ("7e139f05-17ff-4a7d-a37d-ab189b5a5a8c",
	10,
	31,
	31,
	"3b150a0d-b91c-4c97-ab93-a9dfb374e95f");
INSERT INTO ACT_BLK
	VALUES ("138325a6-ed68-4910-8bcf-b90a950958aa",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0580667e-514c-454d-b9c3-342f49283489",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d4b07e7e-bfb5-4083-b409-96c094c81585",
	"138325a6-ed68-4910-8bcf-b90a950958aa",
	"00000000-0000-0000-0000-000000000000",
	12,
	5,
	'row::solving line: 12');
INSERT INTO ACT_AI
	VALUES ("d4b07e7e-bfb5-4083-b409-96c094c81585",
	"886b47b9-8a9e-4852-8642-9142dc9921f4",
	"cac1873e-e1fc-4cdd-8168-8577d5c60cff",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("ad0fa555-0242-4b42-8f47-0c09fcaa2bcc",
	1,
	0,
	12,
	5,
	12,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"138325a6-ed68-4910-8bcf-b90a950958aa");
INSERT INTO V_IRF
	VALUES ("ad0fa555-0242-4b42-8f47-0c09fcaa2bcc",
	"9de555ce-fefd-41ac-8e3d-ff859de0e226");
INSERT INTO V_VAL
	VALUES ("cac1873e-e1fc-4cdd-8168-8577d5c60cff",
	1,
	0,
	12,
	14,
	21,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"138325a6-ed68-4910-8bcf-b90a950958aa");
INSERT INTO V_AVL
	VALUES ("cac1873e-e1fc-4cdd-8168-8577d5c60cff",
	"ad0fa555-0242-4b42-8f47-0c09fcaa2bcc",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"8720bb07-0cf8-4803-9f62-c4159edd49b9");
INSERT INTO V_VAL
	VALUES ("886b47b9-8a9e-4852-8642-9142dc9921f4",
	0,
	0,
	12,
	25,
	25,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"138325a6-ed68-4910-8bcf-b90a950958aa");
INSERT INTO V_LIN
	VALUES ("886b47b9-8a9e-4852-8642-9142dc9921f4",
	'0');
INSERT INTO SM_STATE
	VALUES ("b733cb6a-432a-43d2-897b-5c0bf913830b",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000",
	'solved',
	3,
	0);
INSERT INTO SM_EIGN
	VALUES ("b733cb6a-432a-43d2-897b-5c0bf913830b",
	"565ead81-20dd-40d5-a168-fbed8112e7aa",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("b733cb6a-432a-43d2-897b-5c0bf913830b",
	"565ead81-20dd-40d5-a168-fbed8112e7aa",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EIGN
	VALUES ("b733cb6a-432a-43d2-897b-5c0bf913830b",
	"102c313e-0cd7-458b-bd29-cb901f3bcf5c",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("b733cb6a-432a-43d2-897b-5c0bf913830b",
	"102c313e-0cd7-458b-bd29-cb901f3bcf5c",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("2539b77f-e7d0-46fd-b52e-7fbef9d20c4e",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"b733cb6a-432a-43d2-897b-5c0bf913830b");
INSERT INTO SM_AH
	VALUES ("2539b77f-e7d0-46fd-b52e-7fbef9d20c4e",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16");
INSERT INTO SM_ACT
	VALUES ("2539b77f-e7d0-46fd-b52e-7fbef9d20c4e",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	1,
	'select one sequence related by self->SEQUENCE[R1];
sequence.solved = true;',
	'');
INSERT INTO ACT_SAB
	VALUES ("e66b9524-858a-4656-96ec-286bf5bcbd52",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"2539b77f-e7d0-46fd-b52e-7fbef9d20c4e");
INSERT INTO ACT_ACT
	VALUES ("e66b9524-858a-4656-96ec-286bf5bcbd52",
	'state',
	0,
	"e7243358-67e4-41ee-99a9-d55662163dfa",
	"00000000-0000-0000-0000-000000000000",
	0,
	'row::solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("e7243358-67e4-41ee-99a9-d55662163dfa",
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	1,
	47,
	0,
	0,
	0,
	0,
	0,
	"e66b9524-858a-4656-96ec-286bf5bcbd52",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("90db26a8-b3f5-4461-892a-ff1c438b3016",
	"e7243358-67e4-41ee-99a9-d55662163dfa",
	"34f917c8-5691-403f-a8f1-a5d3270cd65d",
	1,
	1,
	'row::solved line: 1');
INSERT INTO ACT_SEL
	VALUES ("90db26a8-b3f5-4461-892a-ff1c438b3016",
	"dc54dcf1-ff13-4b1a-bc81-697413602924",
	1,
	'one',
	"1bd7cec4-5e1f-4730-85dc-c3d927da5167");
INSERT INTO ACT_SR
	VALUES ("90db26a8-b3f5-4461-892a-ff1c438b3016");
INSERT INTO ACT_LNK
	VALUES ("7a0fb14c-4ba5-44d0-84cb-1b51d97930eb",
	'',
	"90db26a8-b3f5-4461-892a-ff1c438b3016",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	1,
	38,
	1,
	47,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("34f917c8-5691-403f-a8f1-a5d3270cd65d",
	"e7243358-67e4-41ee-99a9-d55662163dfa",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'row::solved line: 2');
INSERT INTO ACT_AI
	VALUES ("34f917c8-5691-403f-a8f1-a5d3270cd65d",
	"f14a6670-482d-4e93-bce2-6056d1ed51b7",
	"be92bbd7-f840-4245-a5f2-d908f563d86e",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("1bd7cec4-5e1f-4730-85dc-c3d927da5167",
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"e7243358-67e4-41ee-99a9-d55662163dfa");
INSERT INTO V_IRF
	VALUES ("1bd7cec4-5e1f-4730-85dc-c3d927da5167",
	"68d6482c-0b7f-4ae1-93db-d748d1cf0caa");
INSERT INTO V_VAL
	VALUES ("0f6b3ec4-3ec7-46e1-9962-277a934cd81c",
	1,
	0,
	2,
	1,
	8,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"e7243358-67e4-41ee-99a9-d55662163dfa");
INSERT INTO V_IRF
	VALUES ("0f6b3ec4-3ec7-46e1-9962-277a934cd81c",
	"dc54dcf1-ff13-4b1a-bc81-697413602924");
INSERT INTO V_VAL
	VALUES ("be92bbd7-f840-4245-a5f2-d908f563d86e",
	1,
	0,
	2,
	10,
	15,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"e7243358-67e4-41ee-99a9-d55662163dfa");
INSERT INTO V_AVL
	VALUES ("be92bbd7-f840-4245-a5f2-d908f563d86e",
	"0f6b3ec4-3ec7-46e1-9962-277a934cd81c",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"52c42da4-a4c5-4627-bb84-a09549090418");
INSERT INTO V_VAL
	VALUES ("f14a6670-482d-4e93-bce2-6056d1ed51b7",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"e7243358-67e4-41ee-99a9-d55662163dfa");
INSERT INTO V_LBO
	VALUES ("f14a6670-482d-4e93-bce2-6056d1ed51b7",
	'TRUE');
INSERT INTO V_VAR
	VALUES ("dc54dcf1-ff13-4b1a-bc81-697413602924",
	"e7243358-67e4-41ee-99a9-d55662163dfa",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("dc54dcf1-ff13-4b1a-bc81-697413602924",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("ef632551-d791-4c2f-847f-dd9d7ffd3511",
	1,
	12,
	19,
	"dc54dcf1-ff13-4b1a-bc81-697413602924");
INSERT INTO V_LOC
	VALUES ("8e102b84-c871-4ffb-bceb-7286dbf014bc",
	2,
	1,
	8,
	"dc54dcf1-ff13-4b1a-bc81-697413602924");
INSERT INTO V_VAR
	VALUES ("68d6482c-0b7f-4ae1-93db-d748d1cf0caa",
	"e7243358-67e4-41ee-99a9-d55662163dfa",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("68d6482c-0b7f-4ae1-93db-d748d1cf0caa",
	0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO SM_NSTXN
	VALUES ("be3bd8b3-2dc8-4649-84cd-c550860908fd",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"ef7d8e7d-d0f3-4213-b1e8-9e643d3df27a",
	"565ead81-20dd-40d5-a168-fbed8112e7aa",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("de59a5a1-36df-4ede-a3c4-73c0fa909cc5",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"be3bd8b3-2dc8-4649-84cd-c550860908fd");
INSERT INTO SM_AH
	VALUES ("de59a5a1-36df-4ede-a3c4-73c0fa909cc5",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16");
INSERT INTO SM_ACT
	VALUES ("de59a5a1-36df-4ede-a3c4-73c0fa909cc5",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("7ea4daa1-be03-46be-b5af-bc2665e99091",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"de59a5a1-36df-4ede-a3c4-73c0fa909cc5");
INSERT INTO ACT_ACT
	VALUES ("7ea4daa1-be03-46be-b5af-bc2665e99091",
	'transition',
	0,
	"bd04ea72-a5f8-4c6a-8362-8a5453776ab0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'ROW1: update in solving to solving',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("bd04ea72-a5f8-4c6a-8362-8a5453776ab0",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"7ea4daa1-be03-46be-b5af-bc2665e99091",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("be3bd8b3-2dc8-4649-84cd-c550860908fd",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"ef7d8e7d-d0f3-4213-b1e8-9e643d3df27a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("bc49fd10-8b19-4d6a-9f64-dfe5dcfab056",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"ef7d8e7d-d0f3-4213-b1e8-9e643d3df27a",
	"102c313e-0cd7-458b-bd29-cb901f3bcf5c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("a77e674b-db24-44cb-9088-ab84f309178e",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"bc49fd10-8b19-4d6a-9f64-dfe5dcfab056");
INSERT INTO SM_AH
	VALUES ("a77e674b-db24-44cb-9088-ab84f309178e",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16");
INSERT INTO SM_ACT
	VALUES ("a77e674b-db24-44cb-9088-ab84f309178e",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES ("99ba375e-813b-42d1-8443-d2acbbfd98be",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"a77e674b-db24-44cb-9088-ab84f309178e");
INSERT INTO ACT_ACT
	VALUES ("99ba375e-813b-42d1-8443-d2acbbfd98be",
	'transition',
	0,
	"a49e6c84-8fbc-470c-a0da-9231096a0e17",
	"00000000-0000-0000-0000-000000000000",
	0,
	'ROW2: solved in solving to solved',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a49e6c84-8fbc-470c-a0da-9231096a0e17",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"99ba375e-813b-42d1-8443-d2acbbfd98be",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("bc49fd10-8b19-4d6a-9f64-dfe5dcfab056",
	"8756fa70-1836-4b50-a6f3-6d40024a0e16",
	"b733cb6a-432a-43d2-897b-5c0bf913830b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_OBJ
	VALUES ("cc208936-7ded-431d-abc7-dd40dbfec79d",
	'sequence',
	1,
	'SEQUENCE',
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO O_TFR
	VALUES ("de80b9f3-d4a2-444b-9de6-3729cf844dc8",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	'solve',
	'',
	"a8899e12-301b-4e3c-949d-1f327b45833d",
	0,
	'i = 0;
select many sequences from instances of SEQUENCE;
while ( 25 > i )
  j = 0;
  while ( 25 > j )
    ::display();
    
    select many eligibles from instances of ELIGIBLE;
    count1 = cardinality eligibles;
    count2 = 0;
    
    for each sequence in sequences
      k = sequence.solve_by_pruning();
    end for;
    
    select many eligibles from instances of ELIGIBLE;
    count2 = cardinality eligibles;
    
    if ( ( 81 == CELL::score() ) or ( count1 == count2 ) )
      break;
    end if;

    j = j + 1;
  end while;

  for each sequence in sequences
    k = sequence.solve_by_elimination();
  end for;
  
  if ( 81 == CELL::score() )
    break;
  end if;
  
  i = i + 1;
end while;

/*#inline
printf( "passes:  %d\n", v324_i );
*/',
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_OPB
	VALUES ("046fb1f8-8bab-4b29-9a41-5ab4dce58b27",
	"de80b9f3-d4a2-444b-9de6-3729cf844dc8");
INSERT INTO ACT_ACT
	VALUES ("046fb1f8-8bab-4b29-9a41-5ab4dce58b27",
	'class operation',
	0,
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'sequence::solve',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("d10dfd2b-463a-418b-bd1b-33b97b08cff0",
	1,
	0,
	0,
	'',
	'',
	'',
	3,
	1,
	2,
	41,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"046fb1f8-8bab-4b29-9a41-5ab4dce58b27",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("2d8bbd63-71f6-4510-9fcc-96b40a571fe8",
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0",
	"62eb33bf-18d7-4482-a92d-0e11afce2332",
	1,
	1,
	'sequence::solve line: 1');
INSERT INTO ACT_AI
	VALUES ("2d8bbd63-71f6-4510-9fcc-96b40a571fe8",
	"180d754a-9302-4928-a7f4-ea0a2bf0d143",
	"8d9a85ee-565b-46b8-b198-ea75f84af4ca",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("62eb33bf-18d7-4482-a92d-0e11afce2332",
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0",
	"4eaf9494-8b86-4dee-be69-5d7a55ace795",
	2,
	1,
	'sequence::solve line: 2');
INSERT INTO ACT_FIO
	VALUES ("62eb33bf-18d7-4482-a92d-0e11afce2332",
	"d2b1cd7a-2516-4d7c-b61c-7ed2e8787cc3",
	1,
	'many',
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	2,
	41);
INSERT INTO ACT_SMT
	VALUES ("4eaf9494-8b86-4dee-be69-5d7a55ace795",
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0",
	"00000000-0000-0000-0000-000000000000",
	3,
	1,
	'sequence::solve line: 3');
INSERT INTO ACT_WHL
	VALUES ("4eaf9494-8b86-4dee-be69-5d7a55ace795",
	"8200e905-d1e2-49f6-9ff1-d126db488510",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_VAL
	VALUES ("8d9a85ee-565b-46b8-b198-ea75f84af4ca",
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0");
INSERT INTO V_TVL
	VALUES ("8d9a85ee-565b-46b8-b198-ea75f84af4ca",
	"9af68056-7aac-4ac6-9444-486a085a7825");
INSERT INTO V_VAL
	VALUES ("180d754a-9302-4928-a7f4-ea0a2bf0d143",
	0,
	0,
	1,
	5,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0");
INSERT INTO V_LIN
	VALUES ("180d754a-9302-4928-a7f4-ea0a2bf0d143",
	'0');
INSERT INTO V_VAL
	VALUES ("66654789-a5d8-494b-b403-440440fe6776",
	0,
	0,
	3,
	9,
	10,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0");
INSERT INTO V_LIN
	VALUES ("66654789-a5d8-494b-b403-440440fe6776",
	'25');
INSERT INTO V_VAL
	VALUES ("8200e905-d1e2-49f6-9ff1-d126db488510",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0");
INSERT INTO V_BIN
	VALUES ("8200e905-d1e2-49f6-9ff1-d126db488510",
	"def60c15-a11b-4042-b923-b9ce778507d5",
	"66654789-a5d8-494b-b403-440440fe6776",
	'>');
INSERT INTO V_VAL
	VALUES ("def60c15-a11b-4042-b923-b9ce778507d5",
	0,
	0,
	3,
	14,
	14,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0");
INSERT INTO V_TVL
	VALUES ("def60c15-a11b-4042-b923-b9ce778507d5",
	"9af68056-7aac-4ac6-9444-486a085a7825");
INSERT INTO V_VAR
	VALUES ("9af68056-7aac-4ac6-9444-486a085a7825",
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0",
	'i',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("9af68056-7aac-4ac6-9444-486a085a7825",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("3e3439d8-d647-451b-96d0-53cd62fe048b",
	1,
	1,
	1,
	"9af68056-7aac-4ac6-9444-486a085a7825");
INSERT INTO V_LOC
	VALUES ("39e0ee3a-96d7-4c14-ac14-9fbdb6eda831",
	3,
	14,
	14,
	"9af68056-7aac-4ac6-9444-486a085a7825");
INSERT INTO V_LOC
	VALUES ("3afb24b9-150d-4bbc-aca5-199adc0dec54",
	34,
	3,
	3,
	"9af68056-7aac-4ac6-9444-486a085a7825");
INSERT INTO V_LOC
	VALUES ("c1000d77-ea2b-4f66-97e5-18c73ad1f599",
	34,
	7,
	7,
	"9af68056-7aac-4ac6-9444-486a085a7825");
INSERT INTO V_VAR
	VALUES ("d2b1cd7a-2516-4d7c-b61c-7ed2e8787cc3",
	"d10dfd2b-463a-418b-bd1b-33b97b08cff0",
	'sequences',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("d2b1cd7a-2516-4d7c-b61c-7ed2e8787cc3",
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("07b685b3-a547-4877-a260-aed3f01f35f1",
	2,
	13,
	21,
	"d2b1cd7a-2516-4d7c-b61c-7ed2e8787cc3");
INSERT INTO V_LOC
	VALUES ("5419d87b-dc52-4c77-ac33-1ecb01863840",
	12,
	26,
	34,
	"d2b1cd7a-2516-4d7c-b61c-7ed2e8787cc3");
INSERT INTO V_LOC
	VALUES ("c858648a-3ca5-4293-81b1-670e9738ab24",
	26,
	24,
	32,
	"d2b1cd7a-2516-4d7c-b61c-7ed2e8787cc3");
INSERT INTO ACT_BLK
	VALUES ("5c565a61-344d-4e08-89e5-9d51ce934280",
	0,
	0,
	0,
	'CELL',
	'',
	'',
	34,
	3,
	30,
	14,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"046fb1f8-8bab-4b29-9a41-5ab4dce58b27",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("47ca5738-bbf6-42c4-827b-e82e0401a33f",
	"5c565a61-344d-4e08-89e5-9d51ce934280",
	"9df67804-87c3-45e3-bb86-7751b008a140",
	4,
	3,
	'sequence::solve line: 4');
INSERT INTO ACT_AI
	VALUES ("47ca5738-bbf6-42c4-827b-e82e0401a33f",
	"c17d2c0d-1c21-4869-8dba-9c6b59c219bc",
	"5f37024c-30d9-431d-8fc1-1d83aff3e292",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9df67804-87c3-45e3-bb86-7751b008a140",
	"5c565a61-344d-4e08-89e5-9d51ce934280",
	"584edfd3-8c30-4780-bacb-5162f9651824",
	5,
	3,
	'sequence::solve line: 5');
INSERT INTO ACT_WHL
	VALUES ("9df67804-87c3-45e3-bb86-7751b008a140",
	"18beba58-6577-4561-aa59-8e7e65f66ad2",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO ACT_SMT
	VALUES ("584edfd3-8c30-4780-bacb-5162f9651824",
	"5c565a61-344d-4e08-89e5-9d51ce934280",
	"150957dd-404c-4f5e-b26e-3a733cb99e4b",
	26,
	3,
	'sequence::solve line: 26');
INSERT INTO ACT_FOR
	VALUES ("584edfd3-8c30-4780-bacb-5162f9651824",
	"ff1d0f31-c7b0-4b81-a8e0-c1bc964ecf97",
	1,
	"de87a5cb-9a90-42ea-82a6-73c859673651",
	"d2b1cd7a-2516-4d7c-b61c-7ed2e8787cc3",
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO ACT_SMT
	VALUES ("150957dd-404c-4f5e-b26e-3a733cb99e4b",
	"5c565a61-344d-4e08-89e5-9d51ce934280",
	"dfd113f4-5ab2-463a-98f5-9d60780f4243",
	30,
	3,
	'sequence::solve line: 30');
INSERT INTO ACT_IF
	VALUES ("150957dd-404c-4f5e-b26e-3a733cb99e4b",
	"3f61ce63-d380-4081-a11a-674563ac1d36",
	"b8c457d7-3919-4fb9-8299-e187532ef08a",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("dfd113f4-5ab2-463a-98f5-9d60780f4243",
	"5c565a61-344d-4e08-89e5-9d51ce934280",
	"00000000-0000-0000-0000-000000000000",
	34,
	3,
	'sequence::solve line: 34');
INSERT INTO ACT_AI
	VALUES ("dfd113f4-5ab2-463a-98f5-9d60780f4243",
	"f49b970b-6975-4b9e-956e-c25b7fc1406e",
	"d1203b55-e25a-4045-9092-2776ca57e461",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("5f37024c-30d9-431d-8fc1-1d83aff3e292",
	1,
	1,
	4,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_TVL
	VALUES ("5f37024c-30d9-431d-8fc1-1d83aff3e292",
	"efbaf538-d451-4586-b88d-ac86da2c69e5");
INSERT INTO V_VAL
	VALUES ("c17d2c0d-1c21-4869-8dba-9c6b59c219bc",
	0,
	0,
	4,
	7,
	7,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_LIN
	VALUES ("c17d2c0d-1c21-4869-8dba-9c6b59c219bc",
	'0');
INSERT INTO V_VAL
	VALUES ("c4c4e6f7-e0b0-448a-99ec-ab7fc3428587",
	0,
	0,
	5,
	11,
	12,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_LIN
	VALUES ("c4c4e6f7-e0b0-448a-99ec-ab7fc3428587",
	'25');
INSERT INTO V_VAL
	VALUES ("18beba58-6577-4561-aa59-8e7e65f66ad2",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_BIN
	VALUES ("18beba58-6577-4561-aa59-8e7e65f66ad2",
	"3b3c26db-21e7-4b0b-b7f2-48f68828256e",
	"c4c4e6f7-e0b0-448a-99ec-ab7fc3428587",
	'>');
INSERT INTO V_VAL
	VALUES ("3b3c26db-21e7-4b0b-b7f2-48f68828256e",
	0,
	0,
	5,
	16,
	16,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_TVL
	VALUES ("3b3c26db-21e7-4b0b-b7f2-48f68828256e",
	"efbaf538-d451-4586-b88d-ac86da2c69e5");
INSERT INTO V_VAL
	VALUES ("fd2a6550-3de0-4bb5-9230-f56c6264bf7c",
	0,
	0,
	30,
	8,
	9,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_LIN
	VALUES ("fd2a6550-3de0-4bb5-9230-f56c6264bf7c",
	'81');
INSERT INTO V_VAL
	VALUES ("b8c457d7-3919-4fb9-8299-e187532ef08a",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_BIN
	VALUES ("b8c457d7-3919-4fb9-8299-e187532ef08a",
	"6b5d9d6f-0e62-4c8d-8590-6a31bcd31247",
	"fd2a6550-3de0-4bb5-9230-f56c6264bf7c",
	'==');
INSERT INTO V_VAL
	VALUES ("6b5d9d6f-0e62-4c8d-8590-6a31bcd31247",
	0,
	0,
	30,
	20,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_TRV
	VALUES ("6b5d9d6f-0e62-4c8d-8590-6a31bcd31247",
	"85d40a8c-8b51-408d-85d3-824453116397",
	"00000000-0000-0000-0000-000000000000",
	1,
	30,
	14);
INSERT INTO V_VAL
	VALUES ("d1203b55-e25a-4045-9092-2776ca57e461",
	1,
	0,
	34,
	3,
	3,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_TVL
	VALUES ("d1203b55-e25a-4045-9092-2776ca57e461",
	"9af68056-7aac-4ac6-9444-486a085a7825");
INSERT INTO V_VAL
	VALUES ("3eec5bd6-883f-4ab2-9f6e-d5410696b463",
	0,
	0,
	34,
	7,
	7,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_TVL
	VALUES ("3eec5bd6-883f-4ab2-9f6e-d5410696b463",
	"9af68056-7aac-4ac6-9444-486a085a7825");
INSERT INTO V_VAL
	VALUES ("f49b970b-6975-4b9e-956e-c25b7fc1406e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_BIN
	VALUES ("f49b970b-6975-4b9e-956e-c25b7fc1406e",
	"95c5ffc1-193b-415a-af69-f4547348a6df",
	"3eec5bd6-883f-4ab2-9f6e-d5410696b463",
	'+');
INSERT INTO V_VAL
	VALUES ("95c5ffc1-193b-415a-af69-f4547348a6df",
	0,
	0,
	34,
	11,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"5c565a61-344d-4e08-89e5-9d51ce934280");
INSERT INTO V_LIN
	VALUES ("95c5ffc1-193b-415a-af69-f4547348a6df",
	'1');
INSERT INTO V_VAR
	VALUES ("efbaf538-d451-4586-b88d-ac86da2c69e5",
	"5c565a61-344d-4e08-89e5-9d51ce934280",
	'j',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("efbaf538-d451-4586-b88d-ac86da2c69e5",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("816f0708-2838-4a20-a323-43f8b80ed8ba",
	4,
	3,
	3,
	"efbaf538-d451-4586-b88d-ac86da2c69e5");
INSERT INTO V_LOC
	VALUES ("1fefb2ef-e3f0-41c7-8d3f-09669b838033",
	5,
	16,
	16,
	"efbaf538-d451-4586-b88d-ac86da2c69e5");
INSERT INTO V_LOC
	VALUES ("d9490bdb-dd3d-46ee-87d0-4b449cec9a3d",
	23,
	5,
	5,
	"efbaf538-d451-4586-b88d-ac86da2c69e5");
INSERT INTO V_LOC
	VALUES ("6686286c-023d-48ab-bc58-aa17773c6773",
	23,
	9,
	9,
	"efbaf538-d451-4586-b88d-ac86da2c69e5");
INSERT INTO V_VAR
	VALUES ("de87a5cb-9a90-42ea-82a6-73c859673651",
	"5c565a61-344d-4e08-89e5-9d51ce934280",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("de87a5cb-9a90-42ea-82a6-73c859673651",
	1,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("7d78c48a-ec83-4f70-b791-deb79efa7987",
	26,
	12,
	19,
	"de87a5cb-9a90-42ea-82a6-73c859673651");
INSERT INTO V_LOC
	VALUES ("1f74161a-6d1e-472d-ac25-573baa8ee277",
	27,
	9,
	16,
	"de87a5cb-9a90-42ea-82a6-73c859673651");
INSERT INTO ACT_BLK
	VALUES ("7eb13552-d38a-4110-a057-70b1604ec7f2",
	1,
	0,
	0,
	'CELL',
	'',
	'',
	23,
	5,
	19,
	18,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"046fb1f8-8bab-4b29-9a41-5ab4dce58b27",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0e5d6f3d-324e-4673-a93b-e728f6edfb09",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	"8428d374-a0f4-49eb-b132-2462ea5dac84",
	6,
	5,
	'sequence::solve line: 6');
INSERT INTO ACT_FNC
	VALUES ("0e5d6f3d-324e-4673-a93b-e728f6edfb09",
	"1306c98a-2790-4d7c-9822-6a721684d866",
	6,
	7);
INSERT INTO ACT_SMT
	VALUES ("8428d374-a0f4-49eb-b132-2462ea5dac84",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	"01b0abe7-6df2-45e2-a94d-64d2a3f2dcb4",
	8,
	5,
	'sequence::solve line: 8');
INSERT INTO ACT_FIO
	VALUES ("8428d374-a0f4-49eb-b132-2462ea5dac84",
	"8e425f0b-fab4-47c0-a946-4c368792d78a",
	1,
	'many',
	"497a9d44-e141-4345-bf11-bb067fb75473",
	8,
	45);
INSERT INTO ACT_SMT
	VALUES ("01b0abe7-6df2-45e2-a94d-64d2a3f2dcb4",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	"9d2e16c2-573f-4c42-8842-5379f2893c8d",
	9,
	5,
	'sequence::solve line: 9');
INSERT INTO ACT_AI
	VALUES ("01b0abe7-6df2-45e2-a94d-64d2a3f2dcb4",
	"e419969a-6714-485d-ad55-b7bbd5b49992",
	"13ecd842-47cf-4271-bf2b-2dc8562a7acb",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9d2e16c2-573f-4c42-8842-5379f2893c8d",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	"e0392b06-5809-4d83-918a-d833e67c657f",
	10,
	5,
	'sequence::solve line: 10');
INSERT INTO ACT_AI
	VALUES ("9d2e16c2-573f-4c42-8842-5379f2893c8d",
	"a3fba678-e55f-4af6-becc-6edb039e11cf",
	"cbb854f5-cacd-42f1-a211-8f3be79f86b2",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e0392b06-5809-4d83-918a-d833e67c657f",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	"c5b7c941-638e-483a-8d7e-24d3250dacad",
	12,
	5,
	'sequence::solve line: 12');
INSERT INTO ACT_FOR
	VALUES ("e0392b06-5809-4d83-918a-d833e67c657f",
	"b551efac-de63-4a44-9366-3bb924ef8247",
	1,
	"36f2cbb1-7fc9-4441-b371-fc1a0420188d",
	"d2b1cd7a-2516-4d7c-b61c-7ed2e8787cc3",
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO ACT_SMT
	VALUES ("c5b7c941-638e-483a-8d7e-24d3250dacad",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	"23157edc-e102-47be-9c92-4c05347cc9d9",
	16,
	5,
	'sequence::solve line: 16');
INSERT INTO ACT_FIO
	VALUES ("c5b7c941-638e-483a-8d7e-24d3250dacad",
	"8e425f0b-fab4-47c0-a946-4c368792d78a",
	0,
	'many',
	"497a9d44-e141-4345-bf11-bb067fb75473",
	16,
	45);
INSERT INTO ACT_SMT
	VALUES ("23157edc-e102-47be-9c92-4c05347cc9d9",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	"e5abca6c-70b9-4809-88eb-5140f5aee92e",
	17,
	5,
	'sequence::solve line: 17');
INSERT INTO ACT_AI
	VALUES ("23157edc-e102-47be-9c92-4c05347cc9d9",
	"158a3695-4831-44cf-81cd-fe1972265329",
	"943a3999-d1df-4447-a79f-7176c7559b68",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e5abca6c-70b9-4809-88eb-5140f5aee92e",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	"0682e119-9a35-47e4-afb4-c83b8d95faf0",
	19,
	5,
	'sequence::solve line: 19');
INSERT INTO ACT_IF
	VALUES ("e5abca6c-70b9-4809-88eb-5140f5aee92e",
	"459e7d2d-6806-4466-bb4f-868b400eec64",
	"734a5837-febe-44aa-9246-6c5051f8b521",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0682e119-9a35-47e4-afb4-c83b8d95faf0",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	"00000000-0000-0000-0000-000000000000",
	23,
	5,
	'sequence::solve line: 23');
INSERT INTO ACT_AI
	VALUES ("0682e119-9a35-47e4-afb4-c83b8d95faf0",
	"7f7fcc87-8629-4f09-9d0e-fa55995a3975",
	"c2f520d6-35cd-4eff-b30b-298ab44d26e8",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("13ecd842-47cf-4271-bf2b-2dc8562a7acb",
	1,
	1,
	9,
	5,
	10,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_TVL
	VALUES ("13ecd842-47cf-4271-bf2b-2dc8562a7acb",
	"d1cb84f1-ac4b-4ba0-9a04-f2721ae09eab");
INSERT INTO V_VAL
	VALUES ("e97de898-45d3-47ef-9d8e-0f547fc5a434",
	0,
	0,
	9,
	26,
	34,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_ISR
	VALUES ("e97de898-45d3-47ef-9d8e-0f547fc5a434",
	"8e425f0b-fab4-47c0-a946-4c368792d78a");
INSERT INTO V_VAL
	VALUES ("e419969a-6714-485d-ad55-b7bbd5b49992",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_UNY
	VALUES ("e419969a-6714-485d-ad55-b7bbd5b49992",
	"e97de898-45d3-47ef-9d8e-0f547fc5a434",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("cbb854f5-cacd-42f1-a211-8f3be79f86b2",
	1,
	1,
	10,
	5,
	10,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_TVL
	VALUES ("cbb854f5-cacd-42f1-a211-8f3be79f86b2",
	"5bd984e9-d336-4efd-b3de-9b9d6774638a");
INSERT INTO V_VAL
	VALUES ("a3fba678-e55f-4af6-becc-6edb039e11cf",
	0,
	0,
	10,
	14,
	14,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_LIN
	VALUES ("a3fba678-e55f-4af6-becc-6edb039e11cf",
	'0');
INSERT INTO V_VAL
	VALUES ("943a3999-d1df-4447-a79f-7176c7559b68",
	1,
	0,
	17,
	5,
	10,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_TVL
	VALUES ("943a3999-d1df-4447-a79f-7176c7559b68",
	"5bd984e9-d336-4efd-b3de-9b9d6774638a");
INSERT INTO V_VAL
	VALUES ("dfa52a67-ff2d-4945-9211-4158c98da95d",
	0,
	0,
	17,
	26,
	34,
	0,
	0,
	0,
	0,
	"53668123-e048-4263-8bc4-caf552d5730a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_ISR
	VALUES ("dfa52a67-ff2d-4945-9211-4158c98da95d",
	"8e425f0b-fab4-47c0-a946-4c368792d78a");
INSERT INTO V_VAL
	VALUES ("158a3695-4831-44cf-81cd-fe1972265329",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_UNY
	VALUES ("158a3695-4831-44cf-81cd-fe1972265329",
	"dfa52a67-ff2d-4945-9211-4158c98da95d",
	'cardinality');
INSERT INTO V_VAL
	VALUES ("df7f711e-2115-48b5-8ec4-73ec9bba2dd2",
	0,
	0,
	19,
	12,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_LIN
	VALUES ("df7f711e-2115-48b5-8ec4-73ec9bba2dd2",
	'81');
INSERT INTO V_VAL
	VALUES ("0c87a788-c39c-4cd9-9a9a-870154c3e153",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_BIN
	VALUES ("0c87a788-c39c-4cd9-9a9a-870154c3e153",
	"57b0840d-cea0-4b5b-b4df-74ef6d2042ed",
	"df7f711e-2115-48b5-8ec4-73ec9bba2dd2",
	'==');
INSERT INTO V_VAL
	VALUES ("57b0840d-cea0-4b5b-b4df-74ef6d2042ed",
	0,
	0,
	19,
	24,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_TRV
	VALUES ("57b0840d-cea0-4b5b-b4df-74ef6d2042ed",
	"85d40a8c-8b51-408d-85d3-824453116397",
	"00000000-0000-0000-0000-000000000000",
	1,
	19,
	18);
INSERT INTO V_VAL
	VALUES ("4fd38693-24f9-4abd-8bdd-6bbf84e58cde",
	0,
	0,
	19,
	39,
	44,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_TVL
	VALUES ("4fd38693-24f9-4abd-8bdd-6bbf84e58cde",
	"d1cb84f1-ac4b-4ba0-9a04-f2721ae09eab");
INSERT INTO V_VAL
	VALUES ("6dbf6b3f-efbb-465d-85db-69acead87694",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_BIN
	VALUES ("6dbf6b3f-efbb-465d-85db-69acead87694",
	"f9170354-7c9e-4a50-a5a2-b7f65350f1a3",
	"4fd38693-24f9-4abd-8bdd-6bbf84e58cde",
	'==');
INSERT INTO V_VAL
	VALUES ("f9170354-7c9e-4a50-a5a2-b7f65350f1a3",
	0,
	0,
	19,
	49,
	54,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_TVL
	VALUES ("f9170354-7c9e-4a50-a5a2-b7f65350f1a3",
	"5bd984e9-d336-4efd-b3de-9b9d6774638a");
INSERT INTO V_VAL
	VALUES ("734a5837-febe-44aa-9246-6c5051f8b521",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_BIN
	VALUES ("734a5837-febe-44aa-9246-6c5051f8b521",
	"6dbf6b3f-efbb-465d-85db-69acead87694",
	"0c87a788-c39c-4cd9-9a9a-870154c3e153",
	'or');
INSERT INTO V_VAL
	VALUES ("c2f520d6-35cd-4eff-b30b-298ab44d26e8",
	1,
	0,
	23,
	5,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_TVL
	VALUES ("c2f520d6-35cd-4eff-b30b-298ab44d26e8",
	"efbaf538-d451-4586-b88d-ac86da2c69e5");
INSERT INTO V_VAL
	VALUES ("d60eeb30-4501-4d76-a1ee-f812b192de05",
	0,
	0,
	23,
	9,
	9,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_TVL
	VALUES ("d60eeb30-4501-4d76-a1ee-f812b192de05",
	"efbaf538-d451-4586-b88d-ac86da2c69e5");
INSERT INTO V_VAL
	VALUES ("7f7fcc87-8629-4f09-9d0e-fa55995a3975",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_BIN
	VALUES ("7f7fcc87-8629-4f09-9d0e-fa55995a3975",
	"ce7e77b1-b15a-41c8-a2de-a131b6faa567",
	"d60eeb30-4501-4d76-a1ee-f812b192de05",
	'+');
INSERT INTO V_VAL
	VALUES ("ce7e77b1-b15a-41c8-a2de-a131b6faa567",
	0,
	0,
	23,
	13,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2");
INSERT INTO V_LIN
	VALUES ("ce7e77b1-b15a-41c8-a2de-a131b6faa567",
	'1');
INSERT INTO V_VAR
	VALUES ("8e425f0b-fab4-47c0-a946-4c368792d78a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	'eligibles',
	1,
	"53668123-e048-4263-8bc4-caf552d5730a");
INSERT INTO V_INS
	VALUES ("8e425f0b-fab4-47c0-a946-4c368792d78a",
	"497a9d44-e141-4345-bf11-bb067fb75473");
INSERT INTO V_LOC
	VALUES ("eece56f1-2fd3-4e87-a540-930a79563248",
	8,
	17,
	25,
	"8e425f0b-fab4-47c0-a946-4c368792d78a");
INSERT INTO V_LOC
	VALUES ("8e8ef9aa-ff5b-488b-93f4-fe612f6f7ff9",
	16,
	17,
	25,
	"8e425f0b-fab4-47c0-a946-4c368792d78a");
INSERT INTO V_VAR
	VALUES ("d1cb84f1-ac4b-4ba0-9a04-f2721ae09eab",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	'count1',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("d1cb84f1-ac4b-4ba0-9a04-f2721ae09eab",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("2fcba0fa-097e-43bc-a975-0bbc32eea4d4",
	9,
	5,
	10,
	"d1cb84f1-ac4b-4ba0-9a04-f2721ae09eab");
INSERT INTO V_LOC
	VALUES ("fdadaa5a-e846-400f-80a1-63ec79c93e2e",
	19,
	39,
	44,
	"d1cb84f1-ac4b-4ba0-9a04-f2721ae09eab");
INSERT INTO V_VAR
	VALUES ("5bd984e9-d336-4efd-b3de-9b9d6774638a",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	'count2',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("5bd984e9-d336-4efd-b3de-9b9d6774638a",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("ebcfb530-46f8-40d3-bbe0-6cbad3416ce2",
	10,
	5,
	10,
	"5bd984e9-d336-4efd-b3de-9b9d6774638a");
INSERT INTO V_LOC
	VALUES ("5e6e726a-6a52-4185-baf2-1dbfa3ee1b38",
	17,
	5,
	10,
	"5bd984e9-d336-4efd-b3de-9b9d6774638a");
INSERT INTO V_LOC
	VALUES ("6f4c4b03-62be-42e9-8e6e-9a25ca4d33bf",
	19,
	49,
	54,
	"5bd984e9-d336-4efd-b3de-9b9d6774638a");
INSERT INTO V_VAR
	VALUES ("36f2cbb1-7fc9-4441-b371-fc1a0420188d",
	"7eb13552-d38a-4110-a057-70b1604ec7f2",
	'sequence',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("36f2cbb1-7fc9-4441-b371-fc1a0420188d",
	1,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO V_LOC
	VALUES ("d62818fe-1355-40f4-b138-f64af0d6d53f",
	12,
	14,
	21,
	"36f2cbb1-7fc9-4441-b371-fc1a0420188d");
INSERT INTO V_LOC
	VALUES ("4ec90fbc-7282-4b21-a0fa-4fcf64fab67e",
	13,
	11,
	18,
	"36f2cbb1-7fc9-4441-b371-fc1a0420188d");
INSERT INTO ACT_BLK
	VALUES ("b551efac-de63-4a44-9366-3bb924ef8247",
	0,
	0,
	0,
	'',
	'',
	'',
	13,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"046fb1f8-8bab-4b29-9a41-5ab4dce58b27",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("6f6f9acc-085d-4b72-b01e-0b190d85757b",
	"b551efac-de63-4a44-9366-3bb924ef8247",
	"00000000-0000-0000-0000-000000000000",
	13,
	7,
	'sequence::solve line: 13');
INSERT INTO ACT_AI
	VALUES ("6f6f9acc-085d-4b72-b01e-0b190d85757b",
	"2db54bdd-af5b-4e70-b433-ed6f2b9c9e00",
	"9c36887f-712c-4936-a2b2-d466a332ac26",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("9c36887f-712c-4936-a2b2-d466a332ac26",
	1,
	1,
	13,
	7,
	7,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"b551efac-de63-4a44-9366-3bb924ef8247");
INSERT INTO V_TVL
	VALUES ("9c36887f-712c-4936-a2b2-d466a332ac26",
	"cf310eaa-0572-4b1d-aff3-0d39e4372bd6");
INSERT INTO V_VAL
	VALUES ("2db54bdd-af5b-4e70-b433-ed6f2b9c9e00",
	0,
	0,
	13,
	20,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"b551efac-de63-4a44-9366-3bb924ef8247");
INSERT INTO V_TRV
	VALUES ("2db54bdd-af5b-4e70-b433-ed6f2b9c9e00",
	"4b7d112b-f550-4d53-ac60-dd48b4bdf25a",
	"36f2cbb1-7fc9-4441-b371-fc1a0420188d",
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("cf310eaa-0572-4b1d-aff3-0d39e4372bd6",
	"b551efac-de63-4a44-9366-3bb924ef8247",
	'k',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("cf310eaa-0572-4b1d-aff3-0d39e4372bd6",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("5e3d7a36-c355-4737-8cac-fb0a6371c645",
	13,
	7,
	7,
	"cf310eaa-0572-4b1d-aff3-0d39e4372bd6");
INSERT INTO ACT_BLK
	VALUES ("459e7d2d-6806-4466-bb4f-868b400eec64",
	0,
	0,
	0,
	'',
	'',
	'',
	20,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"046fb1f8-8bab-4b29-9a41-5ab4dce58b27",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("97d39233-dd4a-4b30-b66d-d7cb082e2345",
	"459e7d2d-6806-4466-bb4f-868b400eec64",
	"00000000-0000-0000-0000-000000000000",
	20,
	7,
	'sequence::solve line: 20');
INSERT INTO ACT_BRK
	VALUES ("97d39233-dd4a-4b30-b66d-d7cb082e2345");
INSERT INTO ACT_BLK
	VALUES ("ff1d0f31-c7b0-4b81-a8e0-c1bc964ecf97",
	0,
	0,
	0,
	'',
	'',
	'',
	27,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"046fb1f8-8bab-4b29-9a41-5ab4dce58b27",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("9c415be6-4e2e-42b2-8e37-b8fdf512da81",
	"ff1d0f31-c7b0-4b81-a8e0-c1bc964ecf97",
	"00000000-0000-0000-0000-000000000000",
	27,
	5,
	'sequence::solve line: 27');
INSERT INTO ACT_AI
	VALUES ("9c415be6-4e2e-42b2-8e37-b8fdf512da81",
	"b8a5a897-cf06-4252-8e84-49143c490a35",
	"f1a59a94-4b02-4a70-b22e-a9235a9ff8dd",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("f1a59a94-4b02-4a70-b22e-a9235a9ff8dd",
	1,
	1,
	27,
	5,
	5,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ff1d0f31-c7b0-4b81-a8e0-c1bc964ecf97");
INSERT INTO V_TVL
	VALUES ("f1a59a94-4b02-4a70-b22e-a9235a9ff8dd",
	"a4dc089d-fed9-46fa-88e4-f24694b90175");
INSERT INTO V_VAL
	VALUES ("b8a5a897-cf06-4252-8e84-49143c490a35",
	0,
	0,
	27,
	18,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"ff1d0f31-c7b0-4b81-a8e0-c1bc964ecf97");
INSERT INTO V_TRV
	VALUES ("b8a5a897-cf06-4252-8e84-49143c490a35",
	"fd61d85c-21ad-484a-80a9-fed65bd562cd",
	"de87a5cb-9a90-42ea-82a6-73c859673651",
	1,
	0,
	0);
INSERT INTO V_VAR
	VALUES ("a4dc089d-fed9-46fa-88e4-f24694b90175",
	"ff1d0f31-c7b0-4b81-a8e0-c1bc964ecf97",
	'k',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("a4dc089d-fed9-46fa-88e4-f24694b90175",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("5c5cb5d1-165e-40b2-9f7d-18575b1695da",
	27,
	5,
	5,
	"a4dc089d-fed9-46fa-88e4-f24694b90175");
INSERT INTO ACT_BLK
	VALUES ("3f61ce63-d380-4081-a11a-674563ac1d36",
	0,
	0,
	0,
	'',
	'',
	'',
	31,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"046fb1f8-8bab-4b29-9a41-5ab4dce58b27",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f9e3f606-87e7-47d3-ae2f-a6ee3a1cdd24",
	"3f61ce63-d380-4081-a11a-674563ac1d36",
	"00000000-0000-0000-0000-000000000000",
	31,
	5,
	'sequence::solve line: 31');
INSERT INTO ACT_BRK
	VALUES ("f9e3f606-87e7-47d3-ae2f-a6ee3a1cdd24");
INSERT INTO O_TFR
	VALUES ("fd61d85c-21ad-484a-80a9-fed65bd562cd",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	'solve_by_elimination',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	1,
	'temperature = 0;
select one row related by self->ROW[R1];
if ( not_empty row )
  temperature = row.eliminate();
else
  select one column related by self->COLUMN[R1];
  if ( not_empty column )
    temperature = column.eliminate();
  else
    select one box related by self->BOX[R1];
    if ( not_empty box )
      temperature = box.eliminate();
    else
      LOG::LogFailure( message:"could not eliminate related sequence" );
    end if;
  end if;
end if;
return temperature;

',
	1,
	'',
	"de80b9f3-d4a2-444b-9de6-3729cf844dc8");
INSERT INTO ACT_OPB
	VALUES ("81bf6709-79af-4c19-a47f-efea42d5506c",
	"fd61d85c-21ad-484a-80a9-fed65bd562cd");
INSERT INTO ACT_ACT
	VALUES ("81bf6709-79af-4c19-a47f-efea42d5506c",
	'operation',
	0,
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4",
	"00000000-0000-0000-0000-000000000000",
	0,
	'sequence::solve_by_elimination',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("d24c74e2-6af9-4811-b1d6-da1e466b50c4",
	1,
	0,
	0,
	'',
	'',
	'',
	18,
	1,
	2,
	33,
	0,
	0,
	2,
	37,
	0,
	0,
	0,
	0,
	0,
	"81bf6709-79af-4c19-a47f-efea42d5506c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4dd15308-b8bb-42dc-9894-f6a25c11b54c",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4",
	"7dc70c2e-22a2-4855-9e2d-424ba54f1c7a",
	1,
	1,
	'sequence::solve_by_elimination line: 1');
INSERT INTO ACT_AI
	VALUES ("4dd15308-b8bb-42dc-9894-f6a25c11b54c",
	"43365136-0e5d-4093-90a3-4184c844f6eb",
	"589cd8b9-0632-45df-bfff-d58a085e8d4d",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7dc70c2e-22a2-4855-9e2d-424ba54f1c7a",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4",
	"b9dec32f-9bbd-430d-96ed-6b6b27988147",
	2,
	1,
	'sequence::solve_by_elimination line: 2');
INSERT INTO ACT_SEL
	VALUES ("7dc70c2e-22a2-4855-9e2d-424ba54f1c7a",
	"cffc6945-a3a6-44fc-9933-9713002fb76b",
	1,
	'one',
	"3f72c429-38ff-465e-b30d-de57bdeb977b");
INSERT INTO ACT_SR
	VALUES ("7dc70c2e-22a2-4855-9e2d-424ba54f1c7a");
INSERT INTO ACT_LNK
	VALUES ("b59d97e4-5a17-47af-96f7-fdfd914ec271",
	'',
	"7dc70c2e-22a2-4855-9e2d-424ba54f1c7a",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	2,
	33,
	2,
	37,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b9dec32f-9bbd-430d-96ed-6b6b27988147",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4",
	"c8fffab8-9865-48c9-b212-7170e4d11f47",
	3,
	1,
	'sequence::solve_by_elimination line: 3');
INSERT INTO ACT_IF
	VALUES ("b9dec32f-9bbd-430d-96ed-6b6b27988147",
	"15fd29fb-ab0a-4fee-bdd8-65d7ac835f26",
	"72cd2bb6-43db-4cee-9ad6-17cedab8806c",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("51567f57-c410-41e6-9a7c-b413f3d86fdb",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'sequence::solve_by_elimination line: 5');
INSERT INTO ACT_E
	VALUES ("51567f57-c410-41e6-9a7c-b413f3d86fdb",
	"34dd56d3-8d71-4ecf-98a0-ecc236480d22",
	"b9dec32f-9bbd-430d-96ed-6b6b27988147");
INSERT INTO ACT_SMT
	VALUES ("c8fffab8-9865-48c9-b212-7170e4d11f47",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4",
	"00000000-0000-0000-0000-000000000000",
	18,
	1,
	'sequence::solve_by_elimination line: 18');
INSERT INTO ACT_RET
	VALUES ("c8fffab8-9865-48c9-b212-7170e4d11f47",
	"1345273c-4196-4b41-ab70-1074c103584a");
INSERT INTO V_VAL
	VALUES ("589cd8b9-0632-45df-bfff-d58a085e8d4d",
	1,
	1,
	1,
	1,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4");
INSERT INTO V_TVL
	VALUES ("589cd8b9-0632-45df-bfff-d58a085e8d4d",
	"a6eef15d-9356-4941-8800-fe47b309da50");
INSERT INTO V_VAL
	VALUES ("43365136-0e5d-4093-90a3-4184c844f6eb",
	0,
	0,
	1,
	15,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4");
INSERT INTO V_LIN
	VALUES ("43365136-0e5d-4093-90a3-4184c844f6eb",
	'0');
INSERT INTO V_VAL
	VALUES ("3f72c429-38ff-465e-b30d-de57bdeb977b",
	0,
	0,
	2,
	27,
	30,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4");
INSERT INTO V_IRF
	VALUES ("3f72c429-38ff-465e-b30d-de57bdeb977b",
	"b4bd1fe1-91da-43bc-835e-0c73ea9daa30");
INSERT INTO V_VAL
	VALUES ("ac04b127-ab85-4133-9a4f-14f2aa92d4dc",
	0,
	0,
	3,
	16,
	18,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4");
INSERT INTO V_IRF
	VALUES ("ac04b127-ab85-4133-9a4f-14f2aa92d4dc",
	"cffc6945-a3a6-44fc-9933-9713002fb76b");
INSERT INTO V_VAL
	VALUES ("72cd2bb6-43db-4cee-9ad6-17cedab8806c",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4");
INSERT INTO V_UNY
	VALUES ("72cd2bb6-43db-4cee-9ad6-17cedab8806c",
	"ac04b127-ab85-4133-9a4f-14f2aa92d4dc",
	'not_empty');
INSERT INTO V_VAL
	VALUES ("1345273c-4196-4b41-ab70-1074c103584a",
	0,
	0,
	18,
	8,
	18,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4");
INSERT INTO V_TVL
	VALUES ("1345273c-4196-4b41-ab70-1074c103584a",
	"a6eef15d-9356-4941-8800-fe47b309da50");
INSERT INTO V_VAR
	VALUES ("a6eef15d-9356-4941-8800-fe47b309da50",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4",
	'temperature',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("a6eef15d-9356-4941-8800-fe47b309da50",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("6acc626a-809e-4ca0-acfc-865861e4bd44",
	1,
	1,
	11,
	"a6eef15d-9356-4941-8800-fe47b309da50");
INSERT INTO V_LOC
	VALUES ("59a851f2-2e9a-4cd1-8d20-560c3880663d",
	4,
	3,
	13,
	"a6eef15d-9356-4941-8800-fe47b309da50");
INSERT INTO V_LOC
	VALUES ("e1e36c87-52d4-49f6-865e-01dd08812356",
	8,
	5,
	15,
	"a6eef15d-9356-4941-8800-fe47b309da50");
INSERT INTO V_LOC
	VALUES ("e0652b0d-4708-45d5-a001-9d9a6a635b73",
	12,
	7,
	17,
	"a6eef15d-9356-4941-8800-fe47b309da50");
INSERT INTO V_LOC
	VALUES ("5463439b-db35-4423-a908-f038671c1eff",
	18,
	8,
	18,
	"a6eef15d-9356-4941-8800-fe47b309da50");
INSERT INTO V_VAR
	VALUES ("cffc6945-a3a6-44fc-9933-9713002fb76b",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4",
	'row',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("cffc6945-a3a6-44fc-9933-9713002fb76b",
	0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("5363d093-493a-48fd-8420-eaa6f5a5c017",
	2,
	12,
	14,
	"cffc6945-a3a6-44fc-9933-9713002fb76b");
INSERT INTO V_LOC
	VALUES ("7026ff53-5663-4358-b21a-ee7d7d8e78f0",
	4,
	17,
	19,
	"cffc6945-a3a6-44fc-9933-9713002fb76b");
INSERT INTO V_VAR
	VALUES ("b4bd1fe1-91da-43bc-835e-0c73ea9daa30",
	"d24c74e2-6af9-4811-b1d6-da1e466b50c4",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("b4bd1fe1-91da-43bc-835e-0c73ea9daa30",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO ACT_BLK
	VALUES ("15fd29fb-ab0a-4fee-bdd8-65d7ac835f26",
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"81bf6709-79af-4c19-a47f-efea42d5506c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("bd2ad1da-57f0-426b-8041-6f2cc051b48b",
	"15fd29fb-ab0a-4fee-bdd8-65d7ac835f26",
	"00000000-0000-0000-0000-000000000000",
	4,
	3,
	'sequence::solve_by_elimination line: 4');
INSERT INTO ACT_AI
	VALUES ("bd2ad1da-57f0-426b-8041-6f2cc051b48b",
	"bfda5409-f915-4ed2-9a0a-b39bedbe4e3f",
	"bf9ec6fb-d5d3-434b-9afd-f33ff5f4c739",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("bf9ec6fb-d5d3-434b-9afd-f33ff5f4c739",
	1,
	0,
	4,
	3,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"15fd29fb-ab0a-4fee-bdd8-65d7ac835f26");
INSERT INTO V_TVL
	VALUES ("bf9ec6fb-d5d3-434b-9afd-f33ff5f4c739",
	"a6eef15d-9356-4941-8800-fe47b309da50");
INSERT INTO V_VAL
	VALUES ("bfda5409-f915-4ed2-9a0a-b39bedbe4e3f",
	0,
	0,
	4,
	21,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"15fd29fb-ab0a-4fee-bdd8-65d7ac835f26");
INSERT INTO V_TRV
	VALUES ("bfda5409-f915-4ed2-9a0a-b39bedbe4e3f",
	"0c6ffade-4c66-4b70-b714-534336415dd0",
	"cffc6945-a3a6-44fc-9933-9713002fb76b",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("34dd56d3-8d71-4ecf-98a0-ecc236480d22",
	1,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	6,
	38,
	0,
	0,
	6,
	45,
	0,
	0,
	0,
	0,
	0,
	"81bf6709-79af-4c19-a47f-efea42d5506c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("cb4c48d9-0b85-4dd2-bd2f-b97e58071aec",
	"34dd56d3-8d71-4ecf-98a0-ecc236480d22",
	"bdebc1d8-cde4-407d-9812-7caabf0306be",
	6,
	3,
	'sequence::solve_by_elimination line: 6');
INSERT INTO ACT_SEL
	VALUES ("cb4c48d9-0b85-4dd2-bd2f-b97e58071aec",
	"18355f9f-1237-474b-bc37-4b1370c7760e",
	1,
	'one',
	"69405443-6fba-4ec1-9067-88b634426d14");
INSERT INTO ACT_SR
	VALUES ("cb4c48d9-0b85-4dd2-bd2f-b97e58071aec");
INSERT INTO ACT_LNK
	VALUES ("0768ec50-90bb-4f6b-96e1-ebcb7a461e14",
	'',
	"cb4c48d9-0b85-4dd2-bd2f-b97e58071aec",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	6,
	38,
	6,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("bdebc1d8-cde4-407d-9812-7caabf0306be",
	"34dd56d3-8d71-4ecf-98a0-ecc236480d22",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'sequence::solve_by_elimination line: 7');
INSERT INTO ACT_IF
	VALUES ("bdebc1d8-cde4-407d-9812-7caabf0306be",
	"95c5c9b5-5db1-4b45-8758-e9d3a8fe8e6c",
	"8cf53d0f-9592-4778-a778-174931da5d08",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("a64d30a5-de35-46a5-8e40-3fae5f5cfe45",
	"34dd56d3-8d71-4ecf-98a0-ecc236480d22",
	"00000000-0000-0000-0000-000000000000",
	9,
	3,
	'sequence::solve_by_elimination line: 9');
INSERT INTO ACT_E
	VALUES ("a64d30a5-de35-46a5-8e40-3fae5f5cfe45",
	"2f98297c-ebdf-40f8-89f3-c7ca6e3c2b61",
	"bdebc1d8-cde4-407d-9812-7caabf0306be");
INSERT INTO V_VAL
	VALUES ("69405443-6fba-4ec1-9067-88b634426d14",
	0,
	0,
	6,
	32,
	35,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"34dd56d3-8d71-4ecf-98a0-ecc236480d22");
INSERT INTO V_IRF
	VALUES ("69405443-6fba-4ec1-9067-88b634426d14",
	"b4bd1fe1-91da-43bc-835e-0c73ea9daa30");
INSERT INTO V_VAL
	VALUES ("49a046bf-cc40-4bfa-a389-cb15f93bbd8e",
	0,
	0,
	7,
	18,
	23,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"34dd56d3-8d71-4ecf-98a0-ecc236480d22");
INSERT INTO V_IRF
	VALUES ("49a046bf-cc40-4bfa-a389-cb15f93bbd8e",
	"18355f9f-1237-474b-bc37-4b1370c7760e");
INSERT INTO V_VAL
	VALUES ("8cf53d0f-9592-4778-a778-174931da5d08",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"34dd56d3-8d71-4ecf-98a0-ecc236480d22");
INSERT INTO V_UNY
	VALUES ("8cf53d0f-9592-4778-a778-174931da5d08",
	"49a046bf-cc40-4bfa-a389-cb15f93bbd8e",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("18355f9f-1237-474b-bc37-4b1370c7760e",
	"34dd56d3-8d71-4ecf-98a0-ecc236480d22",
	'column',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("18355f9f-1237-474b-bc37-4b1370c7760e",
	0,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_LOC
	VALUES ("f01bd4c9-0431-4d89-9fc0-29b139d9984f",
	6,
	14,
	19,
	"18355f9f-1237-474b-bc37-4b1370c7760e");
INSERT INTO V_LOC
	VALUES ("3dd512a5-6340-4908-bbbd-f2a8a296b8b5",
	8,
	19,
	24,
	"18355f9f-1237-474b-bc37-4b1370c7760e");
INSERT INTO ACT_BLK
	VALUES ("95c5c9b5-5db1-4b45-8758-e9d3a8fe8e6c",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"81bf6709-79af-4c19-a47f-efea42d5506c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d12180f9-290f-4389-8bfc-1622f1e84e56",
	"95c5c9b5-5db1-4b45-8758-e9d3a8fe8e6c",
	"00000000-0000-0000-0000-000000000000",
	8,
	5,
	'sequence::solve_by_elimination line: 8');
INSERT INTO ACT_AI
	VALUES ("d12180f9-290f-4389-8bfc-1622f1e84e56",
	"277b946c-39b8-4768-ac79-d294091bda3e",
	"136e39f9-962a-4a5a-aa14-59897bc3961f",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("136e39f9-962a-4a5a-aa14-59897bc3961f",
	1,
	0,
	8,
	5,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"95c5c9b5-5db1-4b45-8758-e9d3a8fe8e6c");
INSERT INTO V_TVL
	VALUES ("136e39f9-962a-4a5a-aa14-59897bc3961f",
	"a6eef15d-9356-4941-8800-fe47b309da50");
INSERT INTO V_VAL
	VALUES ("277b946c-39b8-4768-ac79-d294091bda3e",
	0,
	0,
	8,
	26,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"95c5c9b5-5db1-4b45-8758-e9d3a8fe8e6c");
INSERT INTO V_TRV
	VALUES ("277b946c-39b8-4768-ac79-d294091bda3e",
	"e184be1e-e976-4c07-baa6-c4de41296f45",
	"18355f9f-1237-474b-bc37-4b1370c7760e",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("2f98297c-ebdf-40f8-89f3-c7ca6e3c2b61",
	1,
	0,
	0,
	'',
	'',
	'',
	13,
	5,
	10,
	37,
	0,
	0,
	10,
	41,
	0,
	0,
	0,
	0,
	0,
	"81bf6709-79af-4c19-a47f-efea42d5506c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("df500d64-9435-4c9a-9b37-ec4e8c510bbe",
	"2f98297c-ebdf-40f8-89f3-c7ca6e3c2b61",
	"c7ceca22-8054-4dac-a732-fe24a2e527a7",
	10,
	5,
	'sequence::solve_by_elimination line: 10');
INSERT INTO ACT_SEL
	VALUES ("df500d64-9435-4c9a-9b37-ec4e8c510bbe",
	"22cb6e78-b71a-476d-9f46-3f4b307287c3",
	1,
	'one',
	"453ad3cf-525c-4c49-8fb5-47e0dd02870b");
INSERT INTO ACT_SR
	VALUES ("df500d64-9435-4c9a-9b37-ec4e8c510bbe");
INSERT INTO ACT_LNK
	VALUES ("43fbc741-5bb8-44c3-a9b0-73bf12cab67a",
	'',
	"df500d64-9435-4c9a-9b37-ec4e8c510bbe",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"0aa0576e-b480-43da-8919-6b6e88544902",
	10,
	37,
	10,
	41,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c7ceca22-8054-4dac-a732-fe24a2e527a7",
	"2f98297c-ebdf-40f8-89f3-c7ca6e3c2b61",
	"00000000-0000-0000-0000-000000000000",
	11,
	5,
	'sequence::solve_by_elimination line: 11');
INSERT INTO ACT_IF
	VALUES ("c7ceca22-8054-4dac-a732-fe24a2e527a7",
	"95b8ec7e-c411-4b86-bf02-fd65ba3a4615",
	"6b5742f6-62b3-41da-8132-eb2728be356d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("dc41e4f7-137f-4f83-bbeb-b5e53fb75f3a",
	"2f98297c-ebdf-40f8-89f3-c7ca6e3c2b61",
	"00000000-0000-0000-0000-000000000000",
	13,
	5,
	'sequence::solve_by_elimination line: 13');
INSERT INTO ACT_E
	VALUES ("dc41e4f7-137f-4f83-bbeb-b5e53fb75f3a",
	"3f6a09b2-1180-464a-9bb9-181e095f9855",
	"c7ceca22-8054-4dac-a732-fe24a2e527a7");
INSERT INTO V_VAL
	VALUES ("453ad3cf-525c-4c49-8fb5-47e0dd02870b",
	0,
	0,
	10,
	31,
	34,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"2f98297c-ebdf-40f8-89f3-c7ca6e3c2b61");
INSERT INTO V_IRF
	VALUES ("453ad3cf-525c-4c49-8fb5-47e0dd02870b",
	"b4bd1fe1-91da-43bc-835e-0c73ea9daa30");
INSERT INTO V_VAL
	VALUES ("c568c857-5537-498c-9c66-52cd7c6e655f",
	0,
	0,
	11,
	20,
	22,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"2f98297c-ebdf-40f8-89f3-c7ca6e3c2b61");
INSERT INTO V_IRF
	VALUES ("c568c857-5537-498c-9c66-52cd7c6e655f",
	"22cb6e78-b71a-476d-9f46-3f4b307287c3");
INSERT INTO V_VAL
	VALUES ("6b5742f6-62b3-41da-8132-eb2728be356d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"2f98297c-ebdf-40f8-89f3-c7ca6e3c2b61");
INSERT INTO V_UNY
	VALUES ("6b5742f6-62b3-41da-8132-eb2728be356d",
	"c568c857-5537-498c-9c66-52cd7c6e655f",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("22cb6e78-b71a-476d-9f46-3f4b307287c3",
	"2f98297c-ebdf-40f8-89f3-c7ca6e3c2b61",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("22cb6e78-b71a-476d-9f46-3f4b307287c3",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("4585fd11-9df1-4712-a9cc-36d635dc0955",
	10,
	16,
	18,
	"22cb6e78-b71a-476d-9f46-3f4b307287c3");
INSERT INTO V_LOC
	VALUES ("17d03bc4-a687-458c-b1b3-d933f72b5b2b",
	12,
	21,
	23,
	"22cb6e78-b71a-476d-9f46-3f4b307287c3");
INSERT INTO ACT_BLK
	VALUES ("95b8ec7e-c411-4b86-bf02-fd65ba3a4615",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"81bf6709-79af-4c19-a47f-efea42d5506c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("aafde643-acdd-48bc-86b5-ac3499792538",
	"95b8ec7e-c411-4b86-bf02-fd65ba3a4615",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	'sequence::solve_by_elimination line: 12');
INSERT INTO ACT_AI
	VALUES ("aafde643-acdd-48bc-86b5-ac3499792538",
	"38d0a0b0-5d8e-49a9-8b5c-497a8d53a44c",
	"ec25d5f8-0d78-40fd-aa50-ccbc2cb03347",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("ec25d5f8-0d78-40fd-aa50-ccbc2cb03347",
	1,
	0,
	12,
	7,
	17,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"95b8ec7e-c411-4b86-bf02-fd65ba3a4615");
INSERT INTO V_TVL
	VALUES ("ec25d5f8-0d78-40fd-aa50-ccbc2cb03347",
	"a6eef15d-9356-4941-8800-fe47b309da50");
INSERT INTO V_VAL
	VALUES ("38d0a0b0-5d8e-49a9-8b5c-497a8d53a44c",
	0,
	0,
	12,
	25,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"95b8ec7e-c411-4b86-bf02-fd65ba3a4615");
INSERT INTO V_TRV
	VALUES ("38d0a0b0-5d8e-49a9-8b5c-497a8d53a44c",
	"f511495a-58e2-4110-b856-013b6627b6ae",
	"22cb6e78-b71a-476d-9f46-3f4b307287c3",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("3f6a09b2-1180-464a-9bb9-181e095f9855",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	14,
	7,
	14,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"81bf6709-79af-4c19-a47f-efea42d5506c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3fbb8a34-8adb-4aa7-b148-7b1431c1e247",
	"3f6a09b2-1180-464a-9bb9-181e095f9855",
	"00000000-0000-0000-0000-000000000000",
	14,
	7,
	'sequence::solve_by_elimination line: 14');
INSERT INTO ACT_BRG
	VALUES ("3fbb8a34-8adb-4aa7-b148-7b1431c1e247",
	"f598b35c-392f-4d82-90a7-a4f0d9281584",
	14,
	12,
	14,
	7);
INSERT INTO V_VAL
	VALUES ("9020d366-dad0-4d26-8a88-2142273fa70e",
	0,
	0,
	14,
	32,
	68,
	0,
	0,
	0,
	0,
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	"3f6a09b2-1180-464a-9bb9-181e095f9855");
INSERT INTO V_LST
	VALUES ("9020d366-dad0-4d26-8a88-2142273fa70e",
	'could not eliminate related sequence');
INSERT INTO V_PAR
	VALUES ("9020d366-dad0-4d26-8a88-2142273fa70e",
	"3fbb8a34-8adb-4aa7-b148-7b1431c1e247",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	14,
	24);
INSERT INTO O_TFR
	VALUES ("4b7d112b-f550-4d53-ac60-dd48b4bdf25a",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	'solve_by_pruning',
	'',
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	1,
	'temperature = 0;
select one row related by self->ROW[R1];
if ( not_empty row )
  temperature = row.prune();
else
  select one column related by self->COLUMN[R1];
  if ( not_empty column )
    temperature = column.prune();
  else
    select one box related by self->BOX[R1];
    if ( not_empty box )
      temperature = box.prune();
    else
      LOG::LogFailure( message:"could not prune related sequence" );
    end if;
  end if;
end if;
return temperature;

',
	1,
	'',
	"fd61d85c-21ad-484a-80a9-fed65bd562cd");
INSERT INTO ACT_OPB
	VALUES ("fb10713d-8d35-4394-b2b4-d50f6bdb7a88",
	"4b7d112b-f550-4d53-ac60-dd48b4bdf25a");
INSERT INTO ACT_ACT
	VALUES ("fb10713d-8d35-4394-b2b4-d50f6bdb7a88",
	'operation',
	0,
	"cae4b38f-c249-422e-9270-afd69530b924",
	"00000000-0000-0000-0000-000000000000",
	0,
	'sequence::solve_by_pruning',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("cae4b38f-c249-422e-9270-afd69530b924",
	1,
	0,
	0,
	'',
	'',
	'',
	18,
	1,
	2,
	33,
	0,
	0,
	2,
	37,
	0,
	0,
	0,
	0,
	0,
	"fb10713d-8d35-4394-b2b4-d50f6bdb7a88",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("8543e5c0-a65a-4eb3-96ee-31b9768ce1e2",
	"cae4b38f-c249-422e-9270-afd69530b924",
	"fba21d2a-77ea-40ce-ad1d-5d771b32aa01",
	1,
	1,
	'sequence::solve_by_pruning line: 1');
INSERT INTO ACT_AI
	VALUES ("8543e5c0-a65a-4eb3-96ee-31b9768ce1e2",
	"3bef6a59-f2f9-4b38-af35-93f8b82c2118",
	"fdff2be0-d387-4d51-9550-254eb5cb6e97",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("fba21d2a-77ea-40ce-ad1d-5d771b32aa01",
	"cae4b38f-c249-422e-9270-afd69530b924",
	"7c8ed8e3-a2ed-44dc-bced-8e3c6038b901",
	2,
	1,
	'sequence::solve_by_pruning line: 2');
INSERT INTO ACT_SEL
	VALUES ("fba21d2a-77ea-40ce-ad1d-5d771b32aa01",
	"406367ac-a3fa-4fdf-b265-a8293fb97667",
	1,
	'one',
	"4f1a97a8-a8bf-4730-ad91-e1ce2378d942");
INSERT INTO ACT_SR
	VALUES ("fba21d2a-77ea-40ce-ad1d-5d771b32aa01");
INSERT INTO ACT_LNK
	VALUES ("2598477c-28a0-49c9-b1f0-f889707546fa",
	'',
	"fba21d2a-77ea-40ce-ad1d-5d771b32aa01",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	2,
	33,
	2,
	37,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7c8ed8e3-a2ed-44dc-bced-8e3c6038b901",
	"cae4b38f-c249-422e-9270-afd69530b924",
	"e5e2398f-07fb-4306-b165-0b0f05b1250e",
	3,
	1,
	'sequence::solve_by_pruning line: 3');
INSERT INTO ACT_IF
	VALUES ("7c8ed8e3-a2ed-44dc-bced-8e3c6038b901",
	"269bf666-ecb0-4983-b671-4c6f81f1fb6d",
	"cdc281e6-9192-4589-b7fb-ec5ca98a655d",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("56457de7-c5b0-43a2-93c4-807f0afaa035",
	"cae4b38f-c249-422e-9270-afd69530b924",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'sequence::solve_by_pruning line: 5');
INSERT INTO ACT_E
	VALUES ("56457de7-c5b0-43a2-93c4-807f0afaa035",
	"7a343c47-354c-42a7-9b68-f2d692b8fb6b",
	"7c8ed8e3-a2ed-44dc-bced-8e3c6038b901");
INSERT INTO ACT_SMT
	VALUES ("e5e2398f-07fb-4306-b165-0b0f05b1250e",
	"cae4b38f-c249-422e-9270-afd69530b924",
	"00000000-0000-0000-0000-000000000000",
	18,
	1,
	'sequence::solve_by_pruning line: 18');
INSERT INTO ACT_RET
	VALUES ("e5e2398f-07fb-4306-b165-0b0f05b1250e",
	"30aa511f-305c-4678-9c4f-3e1af6ca4cfa");
INSERT INTO V_VAL
	VALUES ("fdff2be0-d387-4d51-9550-254eb5cb6e97",
	1,
	1,
	1,
	1,
	11,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"cae4b38f-c249-422e-9270-afd69530b924");
INSERT INTO V_TVL
	VALUES ("fdff2be0-d387-4d51-9550-254eb5cb6e97",
	"7f97c4dc-703f-43dd-a2e8-d30515fcdb68");
INSERT INTO V_VAL
	VALUES ("3bef6a59-f2f9-4b38-af35-93f8b82c2118",
	0,
	0,
	1,
	15,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"cae4b38f-c249-422e-9270-afd69530b924");
INSERT INTO V_LIN
	VALUES ("3bef6a59-f2f9-4b38-af35-93f8b82c2118",
	'0');
INSERT INTO V_VAL
	VALUES ("4f1a97a8-a8bf-4730-ad91-e1ce2378d942",
	0,
	0,
	2,
	27,
	30,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"cae4b38f-c249-422e-9270-afd69530b924");
INSERT INTO V_IRF
	VALUES ("4f1a97a8-a8bf-4730-ad91-e1ce2378d942",
	"8f86bb2c-08b3-4d51-b893-12d1fc7b5acd");
INSERT INTO V_VAL
	VALUES ("2cc67668-0447-4c11-ad46-a47df6a2a095",
	0,
	0,
	3,
	16,
	18,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"cae4b38f-c249-422e-9270-afd69530b924");
INSERT INTO V_IRF
	VALUES ("2cc67668-0447-4c11-ad46-a47df6a2a095",
	"406367ac-a3fa-4fdf-b265-a8293fb97667");
INSERT INTO V_VAL
	VALUES ("cdc281e6-9192-4589-b7fb-ec5ca98a655d",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"cae4b38f-c249-422e-9270-afd69530b924");
INSERT INTO V_UNY
	VALUES ("cdc281e6-9192-4589-b7fb-ec5ca98a655d",
	"2cc67668-0447-4c11-ad46-a47df6a2a095",
	'not_empty');
INSERT INTO V_VAL
	VALUES ("30aa511f-305c-4678-9c4f-3e1af6ca4cfa",
	0,
	0,
	18,
	8,
	18,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"cae4b38f-c249-422e-9270-afd69530b924");
INSERT INTO V_TVL
	VALUES ("30aa511f-305c-4678-9c4f-3e1af6ca4cfa",
	"7f97c4dc-703f-43dd-a2e8-d30515fcdb68");
INSERT INTO V_VAR
	VALUES ("7f97c4dc-703f-43dd-a2e8-d30515fcdb68",
	"cae4b38f-c249-422e-9270-afd69530b924",
	'temperature',
	1,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a");
INSERT INTO V_TRN
	VALUES ("7f97c4dc-703f-43dd-a2e8-d30515fcdb68",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO V_LOC
	VALUES ("9c6dc6d7-f737-4ac5-a83f-05ff151c03cb",
	1,
	1,
	11,
	"7f97c4dc-703f-43dd-a2e8-d30515fcdb68");
INSERT INTO V_LOC
	VALUES ("bd813823-bb45-4362-8df3-cbff5bb2143b",
	4,
	3,
	13,
	"7f97c4dc-703f-43dd-a2e8-d30515fcdb68");
INSERT INTO V_LOC
	VALUES ("603a1848-7641-4ee8-8f67-43df38752dd1",
	8,
	5,
	15,
	"7f97c4dc-703f-43dd-a2e8-d30515fcdb68");
INSERT INTO V_LOC
	VALUES ("2a4cf6e2-f5b9-4e8e-a6d8-17d2e324ef13",
	12,
	7,
	17,
	"7f97c4dc-703f-43dd-a2e8-d30515fcdb68");
INSERT INTO V_LOC
	VALUES ("4892346b-705d-4739-82a1-b82484a562a2",
	18,
	8,
	18,
	"7f97c4dc-703f-43dd-a2e8-d30515fcdb68");
INSERT INTO V_VAR
	VALUES ("406367ac-a3fa-4fdf-b265-a8293fb97667",
	"cae4b38f-c249-422e-9270-afd69530b924",
	'row',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("406367ac-a3fa-4fdf-b265-a8293fb97667",
	0,
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a");
INSERT INTO V_LOC
	VALUES ("3a72882f-1da5-40b5-b740-5c65e4fb10a8",
	2,
	12,
	14,
	"406367ac-a3fa-4fdf-b265-a8293fb97667");
INSERT INTO V_LOC
	VALUES ("c2b23ed9-e882-44ae-9656-c09e2220890e",
	4,
	17,
	19,
	"406367ac-a3fa-4fdf-b265-a8293fb97667");
INSERT INTO V_VAR
	VALUES ("8f86bb2c-08b3-4d51-b893-12d1fc7b5acd",
	"cae4b38f-c249-422e-9270-afd69530b924",
	'self',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("8f86bb2c-08b3-4d51-b893-12d1fc7b5acd",
	0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO ACT_BLK
	VALUES ("269bf666-ecb0-4983-b671-4c6f81f1fb6d",
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"fb10713d-8d35-4394-b2b4-d50f6bdb7a88",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("00cad5dd-7dca-4dd5-aeaa-1f25f09342f8",
	"269bf666-ecb0-4983-b671-4c6f81f1fb6d",
	"00000000-0000-0000-0000-000000000000",
	4,
	3,
	'sequence::solve_by_pruning line: 4');
INSERT INTO ACT_AI
	VALUES ("00cad5dd-7dca-4dd5-aeaa-1f25f09342f8",
	"15320872-b8d7-49e2-8277-781e2b0233e9",
	"47968b03-7ad3-457e-aa2e-f9843146b5eb",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("47968b03-7ad3-457e-aa2e-f9843146b5eb",
	1,
	0,
	4,
	3,
	13,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"269bf666-ecb0-4983-b671-4c6f81f1fb6d");
INSERT INTO V_TVL
	VALUES ("47968b03-7ad3-457e-aa2e-f9843146b5eb",
	"7f97c4dc-703f-43dd-a2e8-d30515fcdb68");
INSERT INTO V_VAL
	VALUES ("15320872-b8d7-49e2-8277-781e2b0233e9",
	0,
	0,
	4,
	21,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"269bf666-ecb0-4983-b671-4c6f81f1fb6d");
INSERT INTO V_TRV
	VALUES ("15320872-b8d7-49e2-8277-781e2b0233e9",
	"974f15af-1f69-41a6-818a-7e3763126756",
	"406367ac-a3fa-4fdf-b265-a8293fb97667",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("7a343c47-354c-42a7-9b68-f2d692b8fb6b",
	1,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	6,
	38,
	0,
	0,
	6,
	45,
	0,
	0,
	0,
	0,
	0,
	"fb10713d-8d35-4394-b2b4-d50f6bdb7a88",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("2818ee23-8708-4002-8262-33f37e9d7500",
	"7a343c47-354c-42a7-9b68-f2d692b8fb6b",
	"7ec303e5-bac7-445c-bb36-8292f8c251a9",
	6,
	3,
	'sequence::solve_by_pruning line: 6');
INSERT INTO ACT_SEL
	VALUES ("2818ee23-8708-4002-8262-33f37e9d7500",
	"2e2c8cb5-fcce-42c9-acc2-c9e4953a7c2f",
	1,
	'one',
	"a0d3f88d-a3da-401c-b1e1-71349acb3f3d");
INSERT INTO ACT_SR
	VALUES ("2818ee23-8708-4002-8262-33f37e9d7500");
INSERT INTO ACT_LNK
	VALUES ("e319ceef-4935-424b-a8b7-528f4372db34",
	'',
	"2818ee23-8708-4002-8262-33f37e9d7500",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	6,
	38,
	6,
	45,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7ec303e5-bac7-445c-bb36-8292f8c251a9",
	"7a343c47-354c-42a7-9b68-f2d692b8fb6b",
	"00000000-0000-0000-0000-000000000000",
	7,
	3,
	'sequence::solve_by_pruning line: 7');
INSERT INTO ACT_IF
	VALUES ("7ec303e5-bac7-445c-bb36-8292f8c251a9",
	"6b0ad305-b1f2-40e1-8d4f-49c52fb38162",
	"8dcc4b30-5c7f-49f7-a382-b8264a0a62ac",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c2057d1b-8326-4726-b187-f812726300aa",
	"7a343c47-354c-42a7-9b68-f2d692b8fb6b",
	"00000000-0000-0000-0000-000000000000",
	9,
	3,
	'sequence::solve_by_pruning line: 9');
INSERT INTO ACT_E
	VALUES ("c2057d1b-8326-4726-b187-f812726300aa",
	"9e49dba1-c208-4fd3-9655-d13df4186ad3",
	"7ec303e5-bac7-445c-bb36-8292f8c251a9");
INSERT INTO V_VAL
	VALUES ("a0d3f88d-a3da-401c-b1e1-71349acb3f3d",
	0,
	0,
	6,
	32,
	35,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"7a343c47-354c-42a7-9b68-f2d692b8fb6b");
INSERT INTO V_IRF
	VALUES ("a0d3f88d-a3da-401c-b1e1-71349acb3f3d",
	"8f86bb2c-08b3-4d51-b893-12d1fc7b5acd");
INSERT INTO V_VAL
	VALUES ("48c7d6b3-b804-4d18-b865-f9b2c9adf633",
	0,
	0,
	7,
	18,
	23,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"7a343c47-354c-42a7-9b68-f2d692b8fb6b");
INSERT INTO V_IRF
	VALUES ("48c7d6b3-b804-4d18-b865-f9b2c9adf633",
	"2e2c8cb5-fcce-42c9-acc2-c9e4953a7c2f");
INSERT INTO V_VAL
	VALUES ("8dcc4b30-5c7f-49f7-a382-b8264a0a62ac",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"7a343c47-354c-42a7-9b68-f2d692b8fb6b");
INSERT INTO V_UNY
	VALUES ("8dcc4b30-5c7f-49f7-a382-b8264a0a62ac",
	"48c7d6b3-b804-4d18-b865-f9b2c9adf633",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("2e2c8cb5-fcce-42c9-acc2-c9e4953a7c2f",
	"7a343c47-354c-42a7-9b68-f2d692b8fb6b",
	'column',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("2e2c8cb5-fcce-42c9-acc2-c9e4953a7c2f",
	0,
	"4717be2d-8755-4321-a6af-92c4a16fe7c2");
INSERT INTO V_LOC
	VALUES ("b8151f93-f502-4032-a9b4-31aca5a4fcc4",
	6,
	14,
	19,
	"2e2c8cb5-fcce-42c9-acc2-c9e4953a7c2f");
INSERT INTO V_LOC
	VALUES ("dafef8cf-8a18-4930-955f-0574fe3e255b",
	8,
	19,
	24,
	"2e2c8cb5-fcce-42c9-acc2-c9e4953a7c2f");
INSERT INTO ACT_BLK
	VALUES ("6b0ad305-b1f2-40e1-8d4f-49c52fb38162",
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"fb10713d-8d35-4394-b2b4-d50f6bdb7a88",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c6b8b476-a329-42c3-badd-9ebfc88cbfa2",
	"6b0ad305-b1f2-40e1-8d4f-49c52fb38162",
	"00000000-0000-0000-0000-000000000000",
	8,
	5,
	'sequence::solve_by_pruning line: 8');
INSERT INTO ACT_AI
	VALUES ("c6b8b476-a329-42c3-badd-9ebfc88cbfa2",
	"5cc552c2-6449-446e-81ac-4ce94ad72199",
	"5685b903-ebf7-4183-88ac-dd29ae5aa03d",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("5685b903-ebf7-4183-88ac-dd29ae5aa03d",
	1,
	0,
	8,
	5,
	15,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6b0ad305-b1f2-40e1-8d4f-49c52fb38162");
INSERT INTO V_TVL
	VALUES ("5685b903-ebf7-4183-88ac-dd29ae5aa03d",
	"7f97c4dc-703f-43dd-a2e8-d30515fcdb68");
INSERT INTO V_VAL
	VALUES ("5cc552c2-6449-446e-81ac-4ce94ad72199",
	0,
	0,
	8,
	26,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"6b0ad305-b1f2-40e1-8d4f-49c52fb38162");
INSERT INTO V_TRV
	VALUES ("5cc552c2-6449-446e-81ac-4ce94ad72199",
	"d2362f48-e98f-4889-a32e-046f0f334fd1",
	"2e2c8cb5-fcce-42c9-acc2-c9e4953a7c2f",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("9e49dba1-c208-4fd3-9655-d13df4186ad3",
	1,
	0,
	0,
	'',
	'',
	'',
	13,
	5,
	10,
	37,
	0,
	0,
	10,
	41,
	0,
	0,
	0,
	0,
	0,
	"fb10713d-8d35-4394-b2b4-d50f6bdb7a88",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4993c3fc-1a33-4000-ba70-761d4266c8b3",
	"9e49dba1-c208-4fd3-9655-d13df4186ad3",
	"a46ed2e5-0c47-4e90-a2fe-3a7472c7b522",
	10,
	5,
	'sequence::solve_by_pruning line: 10');
INSERT INTO ACT_SEL
	VALUES ("4993c3fc-1a33-4000-ba70-761d4266c8b3",
	"db15f55b-24d0-43de-9f74-493b27717ed3",
	1,
	'one',
	"0c3c8193-1304-4f9b-8b7f-c7d97df169d4");
INSERT INTO ACT_SR
	VALUES ("4993c3fc-1a33-4000-ba70-761d4266c8b3");
INSERT INTO ACT_LNK
	VALUES ("554992b1-31f5-414f-b5eb-b2bcfc5b663b",
	'',
	"4993c3fc-1a33-4000-ba70-761d4266c8b3",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"00000000-0000-0000-0000-000000000000",
	2,
	"0aa0576e-b480-43da-8919-6b6e88544902",
	10,
	37,
	10,
	41,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a46ed2e5-0c47-4e90-a2fe-3a7472c7b522",
	"9e49dba1-c208-4fd3-9655-d13df4186ad3",
	"00000000-0000-0000-0000-000000000000",
	11,
	5,
	'sequence::solve_by_pruning line: 11');
INSERT INTO ACT_IF
	VALUES ("a46ed2e5-0c47-4e90-a2fe-3a7472c7b522",
	"d5ed1e15-8111-4265-9237-3e75862561f4",
	"d94edcc2-fd83-478a-b01e-bc974c80e25f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d60fec6f-aa8a-44d1-9617-0299d4fdd5be",
	"9e49dba1-c208-4fd3-9655-d13df4186ad3",
	"00000000-0000-0000-0000-000000000000",
	13,
	5,
	'sequence::solve_by_pruning line: 13');
INSERT INTO ACT_E
	VALUES ("d60fec6f-aa8a-44d1-9617-0299d4fdd5be",
	"e6994a19-178d-4d99-aad6-6a1697cc6520",
	"a46ed2e5-0c47-4e90-a2fe-3a7472c7b522");
INSERT INTO V_VAL
	VALUES ("0c3c8193-1304-4f9b-8b7f-c7d97df169d4",
	0,
	0,
	10,
	31,
	34,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"9e49dba1-c208-4fd3-9655-d13df4186ad3");
INSERT INTO V_IRF
	VALUES ("0c3c8193-1304-4f9b-8b7f-c7d97df169d4",
	"8f86bb2c-08b3-4d51-b893-12d1fc7b5acd");
INSERT INTO V_VAL
	VALUES ("c8122086-0fa8-404c-a56e-28317522fa9e",
	0,
	0,
	11,
	20,
	22,
	0,
	0,
	0,
	0,
	"52f78114-d517-42f3-8a73-167976a7916c",
	"9e49dba1-c208-4fd3-9655-d13df4186ad3");
INSERT INTO V_IRF
	VALUES ("c8122086-0fa8-404c-a56e-28317522fa9e",
	"db15f55b-24d0-43de-9f74-493b27717ed3");
INSERT INTO V_VAL
	VALUES ("d94edcc2-fd83-478a-b01e-bc974c80e25f",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	"9e49dba1-c208-4fd3-9655-d13df4186ad3");
INSERT INTO V_UNY
	VALUES ("d94edcc2-fd83-478a-b01e-bc974c80e25f",
	"c8122086-0fa8-404c-a56e-28317522fa9e",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("db15f55b-24d0-43de-9f74-493b27717ed3",
	"9e49dba1-c208-4fd3-9655-d13df4186ad3",
	'box',
	1,
	"52f78114-d517-42f3-8a73-167976a7916c");
INSERT INTO V_INT
	VALUES ("db15f55b-24d0-43de-9f74-493b27717ed3",
	0,
	"0aa0576e-b480-43da-8919-6b6e88544902");
INSERT INTO V_LOC
	VALUES ("fefcf8a4-584e-4f12-8893-aa1a12e53e65",
	10,
	16,
	18,
	"db15f55b-24d0-43de-9f74-493b27717ed3");
INSERT INTO V_LOC
	VALUES ("0ed9aec0-2bfc-419e-883d-26af609b3e80",
	12,
	21,
	23,
	"db15f55b-24d0-43de-9f74-493b27717ed3");
INSERT INTO ACT_BLK
	VALUES ("d5ed1e15-8111-4265-9237-3e75862561f4",
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"fb10713d-8d35-4394-b2b4-d50f6bdb7a88",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("755a2ae4-481d-4889-843a-1518086763bc",
	"d5ed1e15-8111-4265-9237-3e75862561f4",
	"00000000-0000-0000-0000-000000000000",
	12,
	7,
	'sequence::solve_by_pruning line: 12');
INSERT INTO ACT_AI
	VALUES ("755a2ae4-481d-4889-843a-1518086763bc",
	"212f3e35-cfb6-4c12-b328-f3a7ce5f0d8c",
	"b0704936-f4a4-4fe7-ba42-9257210c7219",
	0,
	0);
INSERT INTO V_VAL
	VALUES ("b0704936-f4a4-4fe7-ba42-9257210c7219",
	1,
	0,
	12,
	7,
	17,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d5ed1e15-8111-4265-9237-3e75862561f4");
INSERT INTO V_TVL
	VALUES ("b0704936-f4a4-4fe7-ba42-9257210c7219",
	"7f97c4dc-703f-43dd-a2e8-d30515fcdb68");
INSERT INTO V_VAL
	VALUES ("212f3e35-cfb6-4c12-b328-f3a7ce5f0d8c",
	0,
	0,
	12,
	25,
	-1,
	0,
	0,
	0,
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	"d5ed1e15-8111-4265-9237-3e75862561f4");
INSERT INTO V_TRV
	VALUES ("212f3e35-cfb6-4c12-b328-f3a7ce5f0d8c",
	"9eb8190d-e504-49dd-8d1c-ff3f41269990",
	"db15f55b-24d0-43de-9f74-493b27717ed3",
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES ("e6994a19-178d-4d99-aad6-6a1697cc6520",
	0,
	0,
	0,
	'LOG',
	'',
	'',
	14,
	7,
	14,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"fb10713d-8d35-4394-b2b4-d50f6bdb7a88",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("aed80991-e614-4b81-ab0b-b6e4b4087096",
	"e6994a19-178d-4d99-aad6-6a1697cc6520",
	"00000000-0000-0000-0000-000000000000",
	14,
	7,
	'sequence::solve_by_pruning line: 14');
INSERT INTO ACT_BRG
	VALUES ("aed80991-e614-4b81-ab0b-b6e4b4087096",
	"f598b35c-392f-4d82-90a7-a4f0d9281584",
	14,
	12,
	14,
	7);
INSERT INTO V_VAL
	VALUES ("8502c0db-b001-4aa3-9d4f-390e4f456528",
	0,
	0,
	14,
	32,
	64,
	0,
	0,
	0,
	0,
	"f7e2ad01-b32d-4890-987b-e3f4b7762a9f",
	"e6994a19-178d-4d99-aad6-6a1697cc6520");
INSERT INTO V_LST
	VALUES ("8502c0db-b001-4aa3-9d4f-390e4f456528",
	'could not prune related sequence');
INSERT INTO V_PAR
	VALUES ("8502c0db-b001-4aa3-9d4f-390e4f456528",
	"aed80991-e614-4b81-ab0b-b6e4b4087096",
	"00000000-0000-0000-0000-000000000000",
	'message',
	"00000000-0000-0000-0000-000000000000",
	14,
	24);
INSERT INTO O_NBATTR
	VALUES ("3b79e3cf-10c9-42f9-9de7-18e2ce966a16",
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO O_BATTR
	VALUES ("3b79e3cf-10c9-42f9-9de7-18e2ce966a16",
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO O_ATTR
	VALUES ("3b79e3cf-10c9-42f9-9de7-18e2ce966a16",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"00000000-0000-0000-0000-000000000000",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"65468da2-1083-4089-81cf-f2430c0ade46",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("52c42da4-a4c5-4627-bb84-a09549090418",
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO O_BATTR
	VALUES ("52c42da4-a4c5-4627-bb84-a09549090418",
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO O_ATTR
	VALUES ("52c42da4-a4c5-4627-bb84-a09549090418",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"3b79e3cf-10c9-42f9-9de7-18e2ce966a16",
	'solved',
	'',
	'',
	'solved',
	0,
	"3876b01a-6790-4345-8746-a6082de715ab",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("8720bb07-0cf8-4803-9f62-c4159edd49b9",
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO O_BATTR
	VALUES ("8720bb07-0cf8-4803-9f62-c4159edd49b9",
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO O_ATTR
	VALUES ("8720bb07-0cf8-4803-9f62-c4159edd49b9",
	"cc208936-7ded-431d-abc7-dd40dbfec79d",
	"52c42da4-a4c5-4627-bb84-a09549090418",
	'requests',
	'',
	'',
	'requests',
	0,
	"25e5ee33-6655-4145-8eba-d0fc6416ca0a",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO O_ID
	VALUES (1,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO O_ID
	VALUES (2,
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO SM_ISM
	VALUES ("6e4b7fc7-a8cb-4fbc-a869-e33be855a115",
	"cc208936-7ded-431d-abc7-dd40dbfec79d");
INSERT INTO SM_SM
	VALUES ("6e4b7fc7-a8cb-4fbc-a869-e33be855a115",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("6e4b7fc7-a8cb-4fbc-a869-e33be855a115");
INSERT INTO SM_LEVT
	VALUES ("79c850f1-8a80-4d28-ad9b-d884d43b3b20",
	"6e4b7fc7-a8cb-4fbc-a869-e33be855a115",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("79c850f1-8a80-4d28-ad9b-d884d43b3b20",
	"6e4b7fc7-a8cb-4fbc-a869-e33be855a115",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("79c850f1-8a80-4d28-ad9b-d884d43b3b20",
	"6e4b7fc7-a8cb-4fbc-a869-e33be855a115",
	"00000000-0000-0000-0000-000000000000",
	1,
	'update',
	0,
	'',
	'SEQUENCE1',
	'');
INSERT INTO SM_LEVT
	VALUES ("79481301-cba8-45e7-b0b0-851dbe2a56f5",
	"6e4b7fc7-a8cb-4fbc-a869-e33be855a115",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("79481301-cba8-45e7-b0b0-851dbe2a56f5",
	"6e4b7fc7-a8cb-4fbc-a869-e33be855a115",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("79481301-cba8-45e7-b0b0-851dbe2a56f5",
	"6e4b7fc7-a8cb-4fbc-a869-e33be855a115",
	"00000000-0000-0000-0000-000000000000",
	5,
	'solved',
	0,
	'',
	'SEQUENCE5',
	'');
INSERT INTO R_SUBSUP
	VALUES ("3a810d9c-f36c-4f57-a825-3a432773187f");
INSERT INTO R_REL
	VALUES ("3a810d9c-f36c-4f57-a825-3a432773187f",
	1,
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO R_SUPER
	VALUES ("cc208936-7ded-431d-abc7-dd40dbfec79d",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"3b980817-2a0c-4799-9dc7-24d82075cac9");
INSERT INTO R_RTO
	VALUES ("cc208936-7ded-431d-abc7-dd40dbfec79d",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"3b980817-2a0c-4799-9dc7-24d82075cac9",
	-1);
INSERT INTO R_OIR
	VALUES ("cc208936-7ded-431d-abc7-dd40dbfec79d",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"3b980817-2a0c-4799-9dc7-24d82075cac9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SUB
	VALUES ("c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"c9745a3d-a76a-4f18-b524-e16132f68c3c");
INSERT INTO R_RGO
	VALUES ("c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"c9745a3d-a76a-4f18-b524-e16132f68c3c");
INSERT INTO R_OIR
	VALUES ("c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"c9745a3d-a76a-4f18-b524-e16132f68c3c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SUB
	VALUES ("4717be2d-8755-4321-a6af-92c4a16fe7c2",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"fa4a9818-535e-4b23-a9eb-88a0c6c3ec04");
INSERT INTO R_RGO
	VALUES ("4717be2d-8755-4321-a6af-92c4a16fe7c2",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"fa4a9818-535e-4b23-a9eb-88a0c6c3ec04");
INSERT INTO R_OIR
	VALUES ("4717be2d-8755-4321-a6af-92c4a16fe7c2",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"fa4a9818-535e-4b23-a9eb-88a0c6c3ec04",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SUB
	VALUES ("0aa0576e-b480-43da-8919-6b6e88544902",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"7354aa91-566a-4c1a-9e8d-932643a2fa83");
INSERT INTO R_RGO
	VALUES ("0aa0576e-b480-43da-8919-6b6e88544902",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"7354aa91-566a-4c1a-9e8d-932643a2fa83");
INSERT INTO R_OIR
	VALUES ("0aa0576e-b480-43da-8919-6b6e88544902",
	"3a810d9c-f36c-4f57-a825-3a432773187f",
	"7354aa91-566a-4c1a-9e8d-932643a2fa83",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("3e9916d1-edc8-4b87-8ddc-0bbc8e66c577");
INSERT INTO R_REL
	VALUES ("3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	2,
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO R_PART
	VALUES ("c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"9c3c8405-01a4-40ee-a4da-d38b31e284a9",
	0,
	0,
	'is in');
INSERT INTO O_RTIDA
	VALUES ("bc6df04d-3498-4476-817a-f3273e8f61f2",
	"c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	1,
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"9c3c8405-01a4-40ee-a4da-d38b31e284a9");
INSERT INTO R_RTO
	VALUES ("c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"9c3c8405-01a4-40ee-a4da-d38b31e284a9",
	1);
INSERT INTO R_OIR
	VALUES ("c99972db-d508-4a9b-bfa9-7381aa04dc4a",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"9c3c8405-01a4-40ee-a4da-d38b31e284a9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_FORM
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"68c9495f-23d7-4a5a-8785-8d92642880a1",
	1,
	0,
	'has');
INSERT INTO R_RGO
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"68c9495f-23d7-4a5a-8785-8d92642880a1");
INSERT INTO R_OIR
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"3e9916d1-edc8-4b87-8ddc-0bbc8e66c577",
	"68c9495f-23d7-4a5a-8785-8d92642880a1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("959ca2b3-7a29-4f5e-b4ba-33596cfbedbb");
INSERT INTO R_REL
	VALUES ("959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	3,
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO R_PART
	VALUES ("4717be2d-8755-4321-a6af-92c4a16fe7c2",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"c21ace17-cbde-4c47-9f00-e2ec1b3cdef1",
	0,
	0,
	'is in');
INSERT INTO O_RTIDA
	VALUES ("f26a153c-9ca1-42f0-b8e3-a33ce851c778",
	"4717be2d-8755-4321-a6af-92c4a16fe7c2",
	1,
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"c21ace17-cbde-4c47-9f00-e2ec1b3cdef1");
INSERT INTO R_RTO
	VALUES ("4717be2d-8755-4321-a6af-92c4a16fe7c2",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"c21ace17-cbde-4c47-9f00-e2ec1b3cdef1",
	1);
INSERT INTO R_OIR
	VALUES ("4717be2d-8755-4321-a6af-92c4a16fe7c2",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"c21ace17-cbde-4c47-9f00-e2ec1b3cdef1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_FORM
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"81e3eff5-9e2f-4f48-90f5-30937d260be1",
	1,
	0,
	'has');
INSERT INTO R_RGO
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"81e3eff5-9e2f-4f48-90f5-30937d260be1");
INSERT INTO R_OIR
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"959ca2b3-7a29-4f5e-b4ba-33596cfbedbb",
	"81e3eff5-9e2f-4f48-90f5-30937d260be1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("4df295f0-41a3-41a0-862a-7bd6b14d0efb");
INSERT INTO R_REL
	VALUES ("4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	4,
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO R_PART
	VALUES ("0aa0576e-b480-43da-8919-6b6e88544902",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"50dfc444-259b-4f6f-bc42-2d8c95a8b197",
	0,
	0,
	'is in');
INSERT INTO R_RTO
	VALUES ("0aa0576e-b480-43da-8919-6b6e88544902",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"50dfc444-259b-4f6f-bc42-2d8c95a8b197",
	-1);
INSERT INTO R_OIR
	VALUES ("0aa0576e-b480-43da-8919-6b6e88544902",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"50dfc444-259b-4f6f-bc42-2d8c95a8b197",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_PART
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"d3126046-0728-4a37-a2ef-66ac972cb138",
	1,
	0,
	'has');
INSERT INTO R_RTO
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"d3126046-0728-4a37-a2ef-66ac972cb138",
	-1);
INSERT INTO R_OIR
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"4df295f0-41a3-41a0-862a-7bd6b14d0efb",
	"d3126046-0728-4a37-a2ef-66ac972cb138",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_ASSOC
	VALUES ("953a5200-dd38-4948-a824-2b5a7a7c38b1");
INSERT INTO R_REL
	VALUES ("953a5200-dd38-4948-a824-2b5a7a7c38b1",
	8,
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO R_AONE
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"dc9d735c-3204-41ae-8936-fb29307d3ef8",
	1,
	1,
	'is eligible for');
INSERT INTO O_RTIDA
	VALUES ("dedf8b2c-87e8-43f7-8b6f-c9b16c75eb26",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	0,
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"dc9d735c-3204-41ae-8936-fb29307d3ef8");
INSERT INTO O_RTIDA
	VALUES ("81faeef5-3440-4d38-a08b-a9fc5deea10b",
	"09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	0,
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"dc9d735c-3204-41ae-8936-fb29307d3ef8");
INSERT INTO R_RTO
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"dc9d735c-3204-41ae-8936-fb29307d3ef8",
	0);
INSERT INTO R_OIR
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"dc9d735c-3204-41ae-8936-fb29307d3ef8",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_AOTH
	VALUES ("d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"b10100b3-01e7-4b64-992f-de83c29a826b",
	1,
	1,
	'has eligible');
INSERT INTO O_RTIDA
	VALUES ("d4a31f11-b441-44fd-a723-84a3ed5bf70d",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	0,
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"b10100b3-01e7-4b64-992f-de83c29a826b");
INSERT INTO R_RTO
	VALUES ("d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"b10100b3-01e7-4b64-992f-de83c29a826b",
	0);
INSERT INTO R_OIR
	VALUES ("d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"b10100b3-01e7-4b64-992f-de83c29a826b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_ASSR
	VALUES ("497a9d44-e141-4345-bf11-bb067fb75473",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"11ef7325-8abe-421f-af5b-9418d8555bd2",
	0);
INSERT INTO R_RGO
	VALUES ("497a9d44-e141-4345-bf11-bb067fb75473",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"11ef7325-8abe-421f-af5b-9418d8555bd2");
INSERT INTO R_OIR
	VALUES ("497a9d44-e141-4345-bf11-bb067fb75473",
	"953a5200-dd38-4948-a824-2b5a7a7c38b1",
	"11ef7325-8abe-421f-af5b-9418d8555bd2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("38d358ec-8d62-405c-ba80-3c87494fc20e");
INSERT INTO R_REL
	VALUES ("38d358ec-8d62-405c-ba80-3c87494fc20e",
	9,
	'',
	"8c3eab20-04da-4b39-b4d8-4f30f1e8e7a8");
INSERT INTO R_FORM
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"308bc367-f896-4eeb-bf93-8723b4dfaad7",
	1,
	1,
	'is answer for');
INSERT INTO R_RGO
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"308bc367-f896-4eeb-bf93-8723b4dfaad7");
INSERT INTO R_OIR
	VALUES ("09be2e90-4ff6-4be2-881a-aeeb20e9ba41",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"308bc367-f896-4eeb-bf93-8723b4dfaad7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_PART
	VALUES ("d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"5fbbe4bb-9b74-49bd-91ee-35cd30b10c88",
	0,
	1,
	'has answer');
INSERT INTO O_RTIDA
	VALUES ("d4a31f11-b441-44fd-a723-84a3ed5bf70d",
	"d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	0,
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"5fbbe4bb-9b74-49bd-91ee-35cd30b10c88");
INSERT INTO R_RTO
	VALUES ("d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"5fbbe4bb-9b74-49bd-91ee-35cd30b10c88",
	0);
INSERT INTO R_OIR
	VALUES ("d9889604-5e6c-4f7a-80b8-66f1a74847e1",
	"38d358ec-8d62-405c-ba80-3c87494fc20e",
	"5fbbe4bb-9b74-49bd-91ee-35cd30b10c88",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SLD_SDP
	VALUES ("65c95f29-dab4-4f47-a406-60806c54ea6f",
	"545007a7-e245-4112-81a2-753e4134d520");
INSERT INTO S_DPK
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	'Datatypes',
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"62e883cf-bf00-4d2d-a842-ecab117979e5");
INSERT INTO S_DT
	VALUES ("62e883cf-bf00-4d2d-a842-ecab117979e5",
	"00000000-0000-0000-0000-000000000000",
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("62e883cf-bf00-4d2d-a842-ecab117979e5",
	0);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"2ebd8c9d-daf3-4632-9bef-69feb5a70570");
INSERT INTO S_DT
	VALUES ("2ebd8c9d-daf3-4632-9bef-69feb5a70570",
	"00000000-0000-0000-0000-000000000000",
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("2ebd8c9d-daf3-4632-9bef-69feb5a70570",
	1);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"f6e21bbe-3ed9-4fb6-aa29-f5964305d0d6");
INSERT INTO S_DT
	VALUES ("f6e21bbe-3ed9-4fb6-aa29-f5964305d0d6",
	"00000000-0000-0000-0000-000000000000",
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("f6e21bbe-3ed9-4fb6-aa29-f5964305d0d6",
	2);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"147c603f-d0c9-4918-bb28-4dbbc038d12e");
INSERT INTO S_DT
	VALUES ("147c603f-d0c9-4918-bb28-4dbbc038d12e",
	"00000000-0000-0000-0000-000000000000",
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("147c603f-d0c9-4918-bb28-4dbbc038d12e",
	3);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"e5db7ca6-8006-497d-84cb-ea5266de3b0c");
INSERT INTO S_DT
	VALUES ("e5db7ca6-8006-497d-84cb-ea5266de3b0c",
	"00000000-0000-0000-0000-000000000000",
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("e5db7ca6-8006-497d-84cb-ea5266de3b0c",
	4);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"41a6f78e-72ee-4541-a9b4-86449eec545d");
INSERT INTO S_DT
	VALUES ("41a6f78e-72ee-4541-a9b4-86449eec545d",
	"00000000-0000-0000-0000-000000000000",
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("41a6f78e-72ee-4541-a9b4-86449eec545d",
	5);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"ff6c05ff-837a-4697-9d0f-5917cc66464b");
INSERT INTO S_DT
	VALUES ("ff6c05ff-837a-4697-9d0f-5917cc66464b",
	"00000000-0000-0000-0000-000000000000",
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ff6c05ff-837a-4697-9d0f-5917cc66464b",
	6);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"09215497-f54b-41d5-8411-9497d5b1d3d4");
INSERT INTO S_DT
	VALUES ("09215497-f54b-41d5-8411-9497d5b1d3d4",
	"00000000-0000-0000-0000-000000000000",
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("09215497-f54b-41d5-8411-9497d5b1d3d4",
	7);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"4a31f21c-894f-4a36-82bf-b02d856f86ca");
INSERT INTO S_DT
	VALUES ("4a31f21c-894f-4a36-82bf-b02d856f86ca",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("4a31f21c-894f-4a36-82bf-b02d856f86ca",
	8);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"b9608726-f62b-4f39-a90a-c5dd4e9fa6f1");
INSERT INTO S_DT
	VALUES ("b9608726-f62b-4f39-a90a-c5dd4e9fa6f1",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("b9608726-f62b-4f39-a90a-c5dd4e9fa6f1",
	9);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"08ec1b01-beff-48a3-8d5e-cd5553736486");
INSERT INTO S_DT
	VALUES ("08ec1b01-beff-48a3-8d5e-cd5553736486",
	"00000000-0000-0000-0000-000000000000",
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("08ec1b01-beff-48a3-8d5e-cd5553736486",
	10);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"01c0a720-896b-4814-ad53-8e6098262321");
INSERT INTO S_DT
	VALUES ("01c0a720-896b-4814-ad53-8e6098262321",
	"00000000-0000-0000-0000-000000000000",
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("01c0a720-896b-4814-ad53-8e6098262321",
	11);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"2e94c0da-660b-4139-ae99-45110c3c0aa9");
INSERT INTO S_DT
	VALUES ("2e94c0da-660b-4139-ae99-45110c3c0aa9",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("2e94c0da-660b-4139-ae99-45110c3c0aa9",
	12);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"6f4f46f5-0cb4-4460-8d4c-3e63b8554a07");
INSERT INTO S_DT
	VALUES ("6f4f46f5-0cb4-4460-8d4c-3e63b8554a07",
	"00000000-0000-0000-0000-000000000000",
	'component_ref',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("6f4f46f5-0cb4-4460-8d4c-3e63b8554a07",
	13);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"7ca11ba2-06b8-4529-a3f9-14bdf9f53eef");
INSERT INTO S_DT
	VALUES ("7ca11ba2-06b8-4529-a3f9-14bdf9f53eef",
	"00000000-0000-0000-0000-000000000000",
	'date',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("7ca11ba2-06b8-4529-a3f9-14bdf9f53eef",
	"01c0a720-896b-4814-ad53-8e6098262321",
	1);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"8c988bd5-7e7f-441f-b646-be50c8a3bf4a");
INSERT INTO S_DT
	VALUES ("8c988bd5-7e7f-441f-b646-be50c8a3bf4a",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("8c988bd5-7e7f-441f-b646-be50c8a3bf4a",
	"2e94c0da-660b-4139-ae99-45110c3c0aa9",
	3);
INSERT INTO S_DIP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"7d79c32f-a688-499a-82d6-691b07ec1354");
INSERT INTO S_DT
	VALUES ("7d79c32f-a688-499a-82d6-691b07ec1354",
	"00000000-0000-0000-0000-000000000000",
	'timestamp',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("7d79c32f-a688-499a-82d6-691b07ec1354",
	"01c0a720-896b-4814-ad53-8e6098262321",
	2);
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"62e883cf-bf00-4d2d-a842-ecab117979e5",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"2ebd8c9d-daf3-4632-9bef-69feb5a70570",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"f6e21bbe-3ed9-4fb6-aa29-f5964305d0d6",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"147c603f-d0c9-4918-bb28-4dbbc038d12e",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"e5db7ca6-8006-497d-84cb-ea5266de3b0c",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"41a6f78e-72ee-4541-a9b4-86449eec545d",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"ff6c05ff-837a-4697-9d0f-5917cc66464b",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"09215497-f54b-41d5-8411-9497d5b1d3d4",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"4a31f21c-894f-4a36-82bf-b02d856f86ca",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"b9608726-f62b-4f39-a90a-c5dd4e9fa6f1",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"08ec1b01-beff-48a3-8d5e-cd5553736486",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"01c0a720-896b-4814-ad53-8e6098262321",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"2e94c0da-660b-4139-ae99-45110c3c0aa9",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"6f4f46f5-0cb4-4460-8d4c-3e63b8554a07",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"7ca11ba2-06b8-4529-a3f9-14bdf9f53eef",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"8c988bd5-7e7f-441f-b646-be50c8a3bf4a",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO SLD_SDINP
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"7d79c32f-a688-499a-82d6-691b07ec1354",
	"65c95f29-dab4-4f47-a406-60806c54ea6f");
INSERT INTO EP_SPKG
	VALUES ("545007a7-e245-4112-81a2-753e4134d520",
	"00000000-0000-0000-0000-000000000000");
