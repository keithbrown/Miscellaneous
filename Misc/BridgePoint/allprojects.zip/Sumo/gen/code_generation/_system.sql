-- root-types-contained: SystemModel_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.5

INSERT INTO S_SYS
	VALUES (1,
	'Sumo');
INSERT INTO SLD_SDP
	VALUES (1,
	2);
INSERT INTO S_DPK
	VALUES (2,
	'Datatypes',
	0,
	0);
INSERT INTO S_DIP
	VALUES (2,
	3);
INSERT INTO S_DT
	VALUES (3,
	0,
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES (3,
	0);
INSERT INTO S_DIP
	VALUES (2,
	4);
INSERT INTO S_DT
	VALUES (4,
	0,
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES (4,
	1);
INSERT INTO S_DIP
	VALUES (2,
	5);
INSERT INTO S_DT
	VALUES (5,
	0,
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES (5,
	2);
INSERT INTO S_DIP
	VALUES (2,
	6);
INSERT INTO S_DT
	VALUES (6,
	0,
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES (6,
	3);
INSERT INTO S_DIP
	VALUES (2,
	7);
INSERT INTO S_DT
	VALUES (7,
	0,
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES (7,
	4);
INSERT INTO S_DIP
	VALUES (2,
	8);
INSERT INTO S_DT
	VALUES (8,
	0,
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES (8,
	5);
INSERT INTO S_DIP
	VALUES (2,
	9);
INSERT INTO S_DT
	VALUES (9,
	0,
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (9,
	6);
INSERT INTO S_DIP
	VALUES (2,
	10);
INSERT INTO S_DT
	VALUES (10,
	0,
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (10,
	7);
INSERT INTO S_DIP
	VALUES (2,
	11);
INSERT INTO S_DT
	VALUES (11,
	0,
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (11,
	8);
INSERT INTO S_DIP
	VALUES (2,
	12);
INSERT INTO S_DT
	VALUES (12,
	0,
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (12,
	9);
INSERT INTO S_DIP
	VALUES (2,
	13);
INSERT INTO S_DT
	VALUES (13,
	0,
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (13,
	10);
INSERT INTO S_DIP
	VALUES (2,
	14);
INSERT INTO S_DT
	VALUES (14,
	0,
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (14,
	11);
INSERT INTO S_DIP
	VALUES (2,
	15);
INSERT INTO S_DT
	VALUES (15,
	0,
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (15,
	12);
INSERT INTO S_DIP
	VALUES (2,
	16);
INSERT INTO S_DT
	VALUES (16,
	0,
	'component_ref',
	'',
	'');
INSERT INTO S_CDT
	VALUES (16,
	13);
INSERT INTO S_DIP
	VALUES (2,
	17);
INSERT INTO S_DT
	VALUES (17,
	0,
	'date',
	'',
	'');
INSERT INTO S_UDT
	VALUES (17,
	14,
	1);
INSERT INTO S_DIP
	VALUES (2,
	18);
INSERT INTO S_DT
	VALUES (18,
	0,
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES (18,
	15,
	3);
INSERT INTO S_DIP
	VALUES (2,
	19);
INSERT INTO S_DT
	VALUES (19,
	0,
	'timestamp',
	'',
	'');
INSERT INTO S_UDT
	VALUES (19,
	14,
	2);
INSERT INTO SLD_SDINP
	VALUES (2,
	3,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	4,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	5,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	6,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	7,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	8,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	9,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	10,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	11,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	12,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	13,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	14,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	15,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	16,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	17,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	18,
	1);
INSERT INTO SLD_SDINP
	VALUES (2,
	19,
	1);
INSERT INTO EP_SPKG
	VALUES (2,
	0);
INSERT INTO SLD_SDP
	VALUES (1,
	20);
INSERT INTO S_DPK
	VALUES (20,
	'IO DTs',
	0,
	0);
INSERT INTO S_DIP
	VALUES (20,
	21);
INSERT INTO S_DT
	VALUES (21,
	0,
	'Direction',
	'',
	'');
INSERT INTO S_EDT
	VALUES (21);
INSERT INTO S_ENUM
	VALUES (22,
	'forward',
	'',
	21,
	23);
INSERT INTO S_ENUM
	VALUES (24,
	'backward',
	'',
	21,
	0);
INSERT INTO S_ENUM
	VALUES (23,
	'stop',
	'',
	21,
	24);
INSERT INTO S_DIP
	VALUES (20,
	25);
INSERT INTO S_DT
	VALUES (25,
	0,
	'Orientation',
	'',
	'');
INSERT INTO S_EDT
	VALUES (25);
INSERT INTO S_ENUM
	VALUES (26,
	'left',
	'',
	25,
	0);
INSERT INTO S_ENUM
	VALUES (27,
	'right',
	'',
	25,
	28);
INSERT INTO S_ENUM
	VALUES (28,
	'straight',
	'',
	25,
	26);
INSERT INTO SLD_SDINP
	VALUES (20,
	21,
	1);
INSERT INTO SLD_SDINP
	VALUES (20,
	25,
	1);
INSERT INTO EP_SPKG
	VALUES (20,
	0);
INSERT INTO CP_CP
	VALUES (29,
	0,
	1,
	1,
	'Library',
	'');
INSERT INTO C_C
	VALUES (30,
	29,
	0,
	'NXT',
	'',
	0,
	29);
INSERT INTO C_PO
	VALUES (31,
	30,
	'IO',
	0,
	0);
INSERT INTO C_IR
	VALUES (32,
	33,
	0,
	31);
INSERT INTO C_P
	VALUES (32,
	'platform',
	'Unnamed Interface',
	'');
INSERT INTO SPR_PEP
	VALUES (34,
	35,
	32);
INSERT INTO SPR_PS
	VALUES (34,
	'go',
	'',
	'd = SumoSimulatorProxy::direction2int(direction: param.direction);
SumoSimBridge::go(direction: d);',
	1);
INSERT INTO ACT_PSB
	VALUES (36,
	34);
INSERT INTO ACT_ACT
	VALUES (36,
	'signal',
	0,
	37,
	0,
	0,
	'IO::platform::go',
	0);
INSERT INTO ACT_BLK
	VALUES (37,
	0,
	0,
	0,
	'SumoSimBridge',
	'',
	'',
	2,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	36,
	0);
INSERT INTO ACT_SMT
	VALUES (38,
	37,
	39,
	1,
	1,
	'IO::platform::go line: 1');
INSERT INTO ACT_AI
	VALUES (38,
	40,
	41,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (39,
	37,
	0,
	2,
	1,
	'IO::platform::go line: 2');
INSERT INTO ACT_BRG
	VALUES (39,
	42,
	2,
	16,
	2,
	1);
INSERT INTO V_VAL
	VALUES (41,
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	5,
	37);
INSERT INTO V_TVL
	VALUES (41,
	43);
INSERT INTO V_VAL
	VALUES (40,
	0,
	0,
	1,
	25,
	-1,
	1,
	39,
	0,
	0,
	5,
	37);
INSERT INTO V_TRV
	VALUES (40,
	44,
	0,
	1,
	1,
	5);
INSERT INTO V_VAL
	VALUES (45,
	0,
	0,
	1,
	56,
	64,
	0,
	0,
	0,
	0,
	21,
	37);
INSERT INTO V_PVL
	VALUES (45,
	0,
	0,
	0,
	46);
INSERT INTO V_PAR
	VALUES (45,
	0,
	40,
	'direction',
	0,
	1,
	39);
INSERT INTO V_VAL
	VALUES (47,
	0,
	0,
	2,
	30,
	30,
	0,
	0,
	0,
	0,
	5,
	37);
INSERT INTO V_TVL
	VALUES (47,
	43);
INSERT INTO V_PAR
	VALUES (47,
	39,
	0,
	'direction',
	0,
	2,
	19);
INSERT INTO V_VAR
	VALUES (43,
	37,
	'd',
	1,
	5);
INSERT INTO V_TRN
	VALUES (43,
	0,
	'');
INSERT INTO V_LOC
	VALUES (48,
	1,
	1,
	1,
	43);
INSERT INTO V_LOC
	VALUES (49,
	2,
	30,
	30,
	43);
INSERT INTO SPR_PEP
	VALUES (50,
	51,
	32);
INSERT INTO SPR_PS
	VALUES (50,
	'turn',
	'd = SumoSimulatorProxy::orientation2int(orientation: param.orientation);
SumoSimBridge::turn(orientation: d);',
	'o = SumoSimulatorProxy::orientation2int(orientation: param.orientation);
SumoSimBridge::turn(orientation: o);',
	1);
INSERT INTO ACT_PSB
	VALUES (52,
	50);
INSERT INTO ACT_ACT
	VALUES (52,
	'signal',
	0,
	53,
	0,
	0,
	'IO::platform::turn',
	0);
INSERT INTO ACT_BLK
	VALUES (53,
	0,
	0,
	0,
	'SumoSimBridge',
	'',
	'',
	2,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	52,
	0);
INSERT INTO ACT_SMT
	VALUES (54,
	53,
	55,
	1,
	1,
	'IO::platform::turn line: 1');
INSERT INTO ACT_AI
	VALUES (54,
	56,
	57,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (55,
	53,
	0,
	2,
	1,
	'IO::platform::turn line: 2');
INSERT INTO ACT_BRG
	VALUES (55,
	58,
	2,
	16,
	2,
	1);
INSERT INTO V_VAL
	VALUES (57,
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	5,
	53);
INSERT INTO V_TVL
	VALUES (57,
	59);
INSERT INTO V_VAL
	VALUES (56,
	0,
	0,
	1,
	25,
	-1,
	1,
	41,
	0,
	0,
	5,
	53);
INSERT INTO V_TRV
	VALUES (56,
	60,
	0,
	1,
	1,
	5);
INSERT INTO V_VAL
	VALUES (61,
	0,
	0,
	1,
	60,
	70,
	0,
	0,
	0,
	0,
	25,
	53);
INSERT INTO V_PVL
	VALUES (61,
	0,
	0,
	0,
	62);
INSERT INTO V_PAR
	VALUES (61,
	0,
	56,
	'orientation',
	0,
	1,
	41);
INSERT INTO V_VAL
	VALUES (63,
	0,
	0,
	2,
	34,
	34,
	0,
	0,
	0,
	0,
	5,
	53);
INSERT INTO V_TVL
	VALUES (63,
	59);
INSERT INTO V_PAR
	VALUES (63,
	55,
	0,
	'orientation',
	0,
	2,
	21);
INSERT INTO V_VAR
	VALUES (59,
	53,
	'o',
	1,
	5);
INSERT INTO V_TRN
	VALUES (59,
	0,
	'');
INSERT INTO V_LOC
	VALUES (64,
	1,
	1,
	1,
	59);
INSERT INTO V_LOC
	VALUES (65,
	2,
	34,
	34,
	59);
INSERT INTO SPR_PEP
	VALUES (66,
	67,
	32);
INSERT INTO SPR_PS
	VALUES (66,
	'setName',
	'',
	'SumoSimBridge::register(name: param.name);

create event instance tick of SumoSimulatorProxy_A5:tick() to SumoSimulatorProxy class;
timer = TIM::timer_start_recurring(event_inst: tick, microseconds: 25000);',
	1);
INSERT INTO ACT_PSB
	VALUES (68,
	66);
INSERT INTO ACT_ACT
	VALUES (68,
	'signal',
	0,
	69,
	0,
	0,
	'IO::platform::setName',
	0);
INSERT INTO ACT_BLK
	VALUES (69,
	0,
	0,
	0,
	'TIM',
	'',
	'',
	4,
	1,
	4,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	68,
	0);
INSERT INTO ACT_SMT
	VALUES (70,
	69,
	71,
	1,
	1,
	'IO::platform::setName line: 1');
INSERT INTO ACT_BRG
	VALUES (70,
	72,
	1,
	16,
	1,
	1);
INSERT INTO ACT_SMT
	VALUES (71,
	69,
	73,
	3,
	1,
	'IO::platform::setName line: 3');
INSERT INTO E_ESS
	VALUES (71,
	1,
	0,
	3,
	31,
	3,
	53,
	3,
	63,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (71,
	1,
	74);
INSERT INTO E_CSME
	VALUES (71,
	75,
	76);
INSERT INTO E_CEA
	VALUES (71);
INSERT INTO ACT_SMT
	VALUES (73,
	69,
	0,
	4,
	1,
	'IO::platform::setName line: 4');
INSERT INTO ACT_AI
	VALUES (73,
	77,
	78,
	0,
	0);
INSERT INTO V_VAL
	VALUES (79,
	0,
	0,
	1,
	37,
	40,
	0,
	0,
	0,
	0,
	7,
	69);
INSERT INTO V_PVL
	VALUES (79,
	0,
	0,
	0,
	80);
INSERT INTO V_PAR
	VALUES (79,
	70,
	0,
	'name',
	0,
	1,
	25);
INSERT INTO V_VAL
	VALUES (78,
	1,
	1,
	4,
	1,
	5,
	0,
	0,
	0,
	0,
	18,
	69);
INSERT INTO V_TVL
	VALUES (78,
	81);
INSERT INTO V_VAL
	VALUES (77,
	0,
	0,
	4,
	14,
	-1,
	4,
	36,
	4,
	54,
	18,
	69);
INSERT INTO V_BRV
	VALUES (77,
	82,
	1,
	4,
	9);
INSERT INTO V_VAL
	VALUES (83,
	0,
	0,
	4,
	48,
	51,
	0,
	0,
	0,
	0,
	13,
	69);
INSERT INTO V_TVL
	VALUES (83,
	74);
INSERT INTO V_PAR
	VALUES (83,
	0,
	77,
	'event_inst',
	84,
	4,
	36);
INSERT INTO V_VAL
	VALUES (84,
	0,
	0,
	4,
	68,
	72,
	0,
	0,
	0,
	0,
	5,
	69);
INSERT INTO V_LIN
	VALUES (84,
	'25000');
INSERT INTO V_PAR
	VALUES (84,
	0,
	77,
	'microseconds',
	0,
	4,
	54);
INSERT INTO V_VAR
	VALUES (74,
	69,
	'tick',
	1,
	13);
INSERT INTO V_TRN
	VALUES (74,
	0,
	'');
INSERT INTO V_LOC
	VALUES (85,
	3,
	23,
	26,
	74);
INSERT INTO V_LOC
	VALUES (86,
	4,
	48,
	51,
	74);
INSERT INTO V_VAR
	VALUES (81,
	69,
	'timer',
	1,
	18);
INSERT INTO V_TRN
	VALUES (81,
	0,
	'');
INSERT INTO V_LOC
	VALUES (87,
	4,
	1,
	5,
	81);
INSERT INTO SPR_PEP
	VALUES (88,
	89,
	32);
INSERT INTO SPR_PO
	VALUES (88,
	'lineDetected',
	'',
	'',
	1);
INSERT INTO ACT_POB
	VALUES (90,
	88);
INSERT INTO ACT_ACT
	VALUES (90,
	'interface operation',
	0,
	91,
	0,
	0,
	'IO::platform::lineDetected',
	0);
INSERT INTO ACT_BLK
	VALUES (91,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	90,
	0);
INSERT INTO SPR_PEP
	VALUES (92,
	93,
	32);
INSERT INTO SPR_PO
	VALUES (92,
	'touchLeft',
	'',
	'',
	1);
INSERT INTO ACT_POB
	VALUES (94,
	92);
INSERT INTO ACT_ACT
	VALUES (94,
	'interface operation',
	0,
	95,
	0,
	0,
	'IO::platform::touchLeft',
	0);
INSERT INTO ACT_BLK
	VALUES (95,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	94,
	0);
INSERT INTO SPR_PEP
	VALUES (96,
	97,
	32);
INSERT INTO SPR_PO
	VALUES (96,
	'init',
	'',
	'',
	1);
INSERT INTO ACT_POB
	VALUES (98,
	96);
INSERT INTO ACT_ACT
	VALUES (98,
	'interface operation',
	0,
	99,
	0,
	0,
	'IO::platform::init',
	0);
INSERT INTO ACT_BLK
	VALUES (99,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	98,
	0);
INSERT INTO SPR_PEP
	VALUES (100,
	101,
	32);
INSERT INTO SPR_PO
	VALUES (100,
	'touchRight',
	'',
	'',
	1);
INSERT INTO ACT_POB
	VALUES (102,
	100);
INSERT INTO ACT_ACT
	VALUES (102,
	'interface operation',
	0,
	103,
	0,
	0,
	'IO::platform::touchRight',
	0);
INSERT INTO ACT_BLK
	VALUES (103,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	102,
	0);
INSERT INTO CN_DC
	VALUES (30,
	104);
INSERT INTO S_DOM
	VALUES (104,
	'NXT',
	'',
	0,
	105,
	0);
INSERT INTO S_DPK
	VALUES (106,
	'Datatypes',
	104,
	0);
INSERT INTO EP_SPKG
	VALUES (106,
	0);
INSERT INTO S_EEPK
	VALUES (107,
	'External Entities',
	104,
	0);
INSERT INTO S_EEPIP
	VALUES (107);
INSERT INTO PL_EEPID
	VALUES (104,
	107);
INSERT INTO S_EEIP
	VALUES (107,
	108);
INSERT INTO S_EE
	VALUES (108,
	'Time',
	'The Time external entity provides date, timestamp, and timer related operations.',
	'TIM',
	104);
INSERT INTO S_BRG
	VALUES (109,
	108,
	'current_date',
	'',
	1,
	17,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (110,
	108,
	'create_date',
	'',
	1,
	17,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (111,
	110,
	'second',
	5,
	0,
	'',
	112,
	'');
INSERT INTO S_BPARM
	VALUES (113,
	110,
	'minute',
	5,
	0,
	'',
	114,
	'');
INSERT INTO S_BPARM
	VALUES (114,
	110,
	'hour',
	5,
	0,
	'',
	115,
	'');
INSERT INTO S_BPARM
	VALUES (115,
	110,
	'day',
	5,
	0,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (112,
	110,
	'month',
	5,
	0,
	'',
	113,
	'');
INSERT INTO S_BPARM
	VALUES (116,
	110,
	'year',
	5,
	0,
	'',
	111,
	'');
INSERT INTO S_BRG
	VALUES (117,
	108,
	'get_second',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (118,
	117,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (119,
	108,
	'get_minute',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (120,
	119,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (121,
	108,
	'get_hour',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (122,
	121,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (123,
	108,
	'get_day',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (124,
	123,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (125,
	108,
	'get_month',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (126,
	125,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (127,
	108,
	'get_year',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (128,
	127,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (129,
	108,
	'current_clock',
	'',
	1,
	19,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (130,
	108,
	'timer_start',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Returns the instance
handle of the timer.',
	1,
	18,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (131,
	130,
	'microseconds',
	5,
	0,
	'',
	132,
	'');
INSERT INTO S_BPARM
	VALUES (132,
	130,
	'event_inst',
	13,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (82,
	108,
	'timer_start_recurring',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Upon expiration, the
timer will be restarted and fire again in the specified number of microseconds
generating the passed event. This bridge operation returns the instance handle
of the timer.',
	1,
	18,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (133,
	82,
	'microseconds',
	5,
	0,
	'',
	134,
	'');
INSERT INTO S_BPARM
	VALUES (134,
	82,
	'event_inst',
	13,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (135,
	108,
	'timer_remaining_time',
	'Returns the time remaining (in microseconds) for the passed timer instance. If
the timer has expired, a zero value is returned.',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (136,
	135,
	'timer_inst_ref',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (137,
	108,
	'timer_reset_time',
	'This bridge operation attempts to set the passed existing timer to expire in
the specified number of microseconds. If the timer exists (that is, it has not
expired), a TRUE value is returned. If the timer no longer exists, a FALSE value
is returned.',
	1,
	4,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (138,
	137,
	'timer_inst_ref',
	18,
	0,
	'',
	139,
	'');
INSERT INTO S_BPARM
	VALUES (139,
	137,
	'microseconds',
	5,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (140,
	108,
	'timer_add_time',
	'This bridge operation attempts to add the specified number of microseconds to a
passed existing timer. If the timer exists (that is, it has not expired), a TRUE
value is returned. If the timer no longer exists, a FALSE value is returned.',
	1,
	4,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (141,
	140,
	'timer_inst_ref',
	18,
	0,
	'',
	142,
	'');
INSERT INTO S_BPARM
	VALUES (142,
	140,
	'microseconds',
	5,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (143,
	108,
	'timer_cancel',
	'This bridge operation cancels and deletes the passed timer instance. If the 
timer exists (that is, it had not expired), a TRUE value is returned. If the
timer no longer exists, a FALSE value is returned.',
	1,
	4,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (144,
	143,
	'timer_inst_ref',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_EEIP
	VALUES (107,
	145);
INSERT INTO S_EE
	VALUES (145,
	'Sumo Simulator Interface',
	'',
	'SumoSimBridge',
	104);
INSERT INTO S_BRG
	VALUES (146,
	145,
	'feedLineDetectedEvent',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (147,
	146,
	'evt',
	13,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (148,
	146);
INSERT INTO ACT_ACT
	VALUES (148,
	'bridge',
	0,
	149,
	0,
	0,
	'Sumo Simulator Interface::feedLineDetectedEvent',
	0);
INSERT INTO ACT_BLK
	VALUES (149,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	148,
	0);
INSERT INTO S_BRG
	VALUES (42,
	145,
	'go',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (150,
	42,
	'direction',
	5,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (151,
	42);
INSERT INTO ACT_ACT
	VALUES (151,
	'bridge',
	0,
	152,
	0,
	0,
	'Sumo Simulator Interface::go',
	0);
INSERT INTO ACT_BLK
	VALUES (152,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	151,
	0);
INSERT INTO S_BRG
	VALUES (58,
	145,
	'turn',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (153,
	58,
	'orientation',
	5,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (154,
	58);
INSERT INTO ACT_ACT
	VALUES (154,
	'bridge',
	0,
	155,
	0,
	0,
	'Sumo Simulator Interface::turn',
	0);
INSERT INTO ACT_BLK
	VALUES (155,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	154,
	0);
INSERT INTO S_BRG
	VALUES (156,
	145,
	'connect',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES (157,
	156);
INSERT INTO ACT_ACT
	VALUES (157,
	'bridge',
	0,
	158,
	0,
	0,
	'Sumo Simulator Interface::connect',
	0);
INSERT INTO ACT_BLK
	VALUES (158,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	157,
	0);
INSERT INTO S_BRG
	VALUES (159,
	145,
	'sendLineDetected',
	'',
	0,
	3,
	'send IO::lineDetected();',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES (160,
	159);
INSERT INTO ACT_ACT
	VALUES (160,
	'bridge',
	0,
	161,
	0,
	0,
	'Sumo Simulator Interface::sendLineDetected',
	0);
INSERT INTO ACT_BLK
	VALUES (161,
	0,
	0,
	0,
	'IO',
	'',
	'',
	1,
	1,
	1,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	160,
	0);
INSERT INTO ACT_SMT
	VALUES (162,
	161,
	0,
	1,
	1,
	'Sumo Simulator Interface::sendLineDetected line: 1');
INSERT INTO ACT_IOP
	VALUES (162,
	88,
	0,
	1,
	10,
	1,
	6);
INSERT INTO S_BRG
	VALUES (72,
	145,
	'register',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (163,
	72,
	'name',
	7,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (164,
	72);
INSERT INTO ACT_ACT
	VALUES (164,
	'bridge',
	0,
	165,
	0,
	0,
	'Sumo Simulator Interface::register',
	0);
INSERT INTO ACT_BLK
	VALUES (165,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	164,
	0);
INSERT INTO S_BRG
	VALUES (166,
	145,
	'feedTouchLeftEvent',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (167,
	166,
	'evt',
	13,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (168,
	166);
INSERT INTO ACT_ACT
	VALUES (168,
	'bridge',
	0,
	169,
	0,
	0,
	'Sumo Simulator Interface::feedTouchLeftEvent',
	0);
INSERT INTO ACT_BLK
	VALUES (169,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	168,
	0);
INSERT INTO S_BRG
	VALUES (170,
	145,
	'sendTouchLeft',
	'',
	0,
	3,
	'send IO::touchLeft();',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES (171,
	170);
INSERT INTO ACT_ACT
	VALUES (171,
	'bridge',
	0,
	172,
	0,
	0,
	'Sumo Simulator Interface::sendTouchLeft',
	0);
INSERT INTO ACT_BLK
	VALUES (172,
	0,
	0,
	0,
	'IO',
	'',
	'',
	1,
	1,
	1,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	171,
	0);
INSERT INTO ACT_SMT
	VALUES (173,
	172,
	0,
	1,
	1,
	'Sumo Simulator Interface::sendTouchLeft line: 1');
INSERT INTO ACT_IOP
	VALUES (173,
	92,
	0,
	1,
	10,
	1,
	6);
INSERT INTO S_BRG
	VALUES (174,
	145,
	'sendTouchRight',
	'',
	0,
	3,
	'send IO::touchRight();',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES (175,
	174);
INSERT INTO ACT_ACT
	VALUES (175,
	'bridge',
	0,
	176,
	0,
	0,
	'Sumo Simulator Interface::sendTouchRight',
	0);
INSERT INTO ACT_BLK
	VALUES (176,
	0,
	0,
	0,
	'IO',
	'',
	'',
	1,
	1,
	1,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	175,
	0);
INSERT INTO ACT_SMT
	VALUES (177,
	176,
	0,
	1,
	1,
	'Sumo Simulator Interface::sendTouchRight line: 1');
INSERT INTO ACT_IOP
	VALUES (177,
	100,
	0,
	1,
	10,
	1,
	6);
INSERT INTO S_BRG
	VALUES (178,
	145,
	'feedTouchRightEvent',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (179,
	178,
	'evt',
	13,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (180,
	178);
INSERT INTO ACT_ACT
	VALUES (180,
	'bridge',
	0,
	181,
	0,
	0,
	'Sumo Simulator Interface::feedTouchRightEvent',
	0);
INSERT INTO ACT_BLK
	VALUES (181,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	180,
	0);
INSERT INTO S_BRG
	VALUES (182,
	145,
	'tick',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES (183,
	182);
INSERT INTO ACT_ACT
	VALUES (183,
	'bridge',
	0,
	184,
	0,
	0,
	'Sumo Simulator Interface::tick',
	0);
INSERT INTO ACT_BLK
	VALUES (184,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	183,
	0);
INSERT INTO S_FPK
	VALUES (185,
	'Functions',
	104,
	0);
INSERT INTO PL_FPID
	VALUES (185,
	104);
INSERT INTO S_FIP
	VALUES (185,
	186);
INSERT INTO S_SYNC
	VALUES (186,
	104,
	'startWithDelay',
	'',
	'create object instance proxy of SumoSimulatorProxy;
proxy.startupWaitTime = 2000000;
create event instance startupDelay of SumoSimulatorProxy_A6:startupDelay() to SumoSimulatorProxy class;
timer = TIM::timer_start(event_inst: startupDelay, microseconds: proxy.startupWaitTime);',
	3,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (187,
	186);
INSERT INTO ACT_ACT
	VALUES (187,
	'function',
	0,
	188,
	0,
	0,
	'startWithDelay',
	0);
INSERT INTO ACT_BLK
	VALUES (188,
	0,
	0,
	0,
	'TIM',
	'',
	'',
	4,
	1,
	4,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	187,
	0);
INSERT INTO ACT_SMT
	VALUES (189,
	188,
	190,
	1,
	1,
	'startWithDelay line: 1');
INSERT INTO ACT_CR
	VALUES (189,
	191,
	1,
	192,
	1,
	33);
INSERT INTO ACT_SMT
	VALUES (190,
	188,
	193,
	2,
	1,
	'startWithDelay line: 2');
INSERT INTO ACT_AI
	VALUES (190,
	194,
	195,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (193,
	188,
	196,
	3,
	1,
	'startWithDelay line: 3');
INSERT INTO E_ESS
	VALUES (193,
	1,
	0,
	3,
	39,
	3,
	61,
	3,
	79,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (193,
	1,
	197);
INSERT INTO E_CSME
	VALUES (193,
	198,
	76);
INSERT INTO E_CEA
	VALUES (193);
INSERT INTO ACT_SMT
	VALUES (196,
	188,
	0,
	4,
	1,
	'startWithDelay line: 4');
INSERT INTO ACT_AI
	VALUES (196,
	199,
	200,
	0,
	0);
INSERT INTO V_VAL
	VALUES (201,
	1,
	0,
	2,
	1,
	5,
	0,
	0,
	0,
	0,
	11,
	188);
INSERT INTO V_IRF
	VALUES (201,
	191);
INSERT INTO V_VAL
	VALUES (195,
	1,
	0,
	2,
	7,
	21,
	0,
	0,
	0,
	0,
	5,
	188);
INSERT INTO V_AVL
	VALUES (195,
	201,
	192,
	202);
INSERT INTO V_VAL
	VALUES (194,
	0,
	0,
	2,
	25,
	31,
	0,
	0,
	0,
	0,
	5,
	188);
INSERT INTO V_LIN
	VALUES (194,
	'2000000');
INSERT INTO V_VAL
	VALUES (200,
	1,
	1,
	4,
	1,
	5,
	0,
	0,
	0,
	0,
	18,
	188);
INSERT INTO V_TVL
	VALUES (200,
	203);
INSERT INTO V_VAL
	VALUES (199,
	0,
	0,
	4,
	14,
	-1,
	4,
	26,
	4,
	52,
	18,
	188);
INSERT INTO V_BRV
	VALUES (199,
	130,
	1,
	4,
	9);
INSERT INTO V_VAL
	VALUES (204,
	0,
	0,
	4,
	38,
	49,
	0,
	0,
	0,
	0,
	13,
	188);
INSERT INTO V_TVL
	VALUES (204,
	197);
INSERT INTO V_PAR
	VALUES (204,
	0,
	199,
	'event_inst',
	205,
	4,
	26);
INSERT INTO V_VAL
	VALUES (206,
	0,
	0,
	4,
	66,
	70,
	0,
	0,
	0,
	0,
	11,
	188);
INSERT INTO V_IRF
	VALUES (206,
	191);
INSERT INTO V_VAL
	VALUES (205,
	0,
	0,
	4,
	72,
	86,
	0,
	0,
	0,
	0,
	5,
	188);
INSERT INTO V_AVL
	VALUES (205,
	206,
	192,
	202);
INSERT INTO V_PAR
	VALUES (205,
	0,
	199,
	'microseconds',
	0,
	4,
	52);
INSERT INTO V_VAR
	VALUES (191,
	188,
	'proxy',
	1,
	11);
INSERT INTO V_INT
	VALUES (191,
	0,
	192);
INSERT INTO V_LOC
	VALUES (207,
	1,
	24,
	28,
	191);
INSERT INTO V_LOC
	VALUES (208,
	2,
	1,
	5,
	191);
INSERT INTO V_LOC
	VALUES (209,
	4,
	66,
	70,
	191);
INSERT INTO V_VAR
	VALUES (197,
	188,
	'startupDelay',
	1,
	13);
INSERT INTO V_TRN
	VALUES (197,
	0,
	'');
INSERT INTO V_LOC
	VALUES (210,
	3,
	23,
	34,
	197);
INSERT INTO V_LOC
	VALUES (211,
	4,
	38,
	49,
	197);
INSERT INTO V_VAR
	VALUES (203,
	188,
	'timer',
	1,
	18);
INSERT INTO V_TRN
	VALUES (203,
	0,
	'');
INSERT INTO V_LOC
	VALUES (212,
	4,
	1,
	5,
	203);
INSERT INTO S_SID
	VALUES (104,
	213);
INSERT INTO S_SS
	VALUES (213,
	'NXT',
	'',
	'',
	0,
	104,
	0);
INSERT INTO O_OBJ
	VALUES (192,
	'SumoSimulatorProxy',
	1,
	'SumoSimulatorProxy',
	'',
	213);
INSERT INTO O_TFR
	VALUES (44,
	192,
	'direction2int',
	'',
	5,
	0,
	'if (param.direction == Direction::backward)
  return 0;
elif (param.direction == Direction::stop)
  return 1;
elif (param.direction == Direction::forward)
  return 2;
end if;
return 0;',
	1,
	'',
	0);
INSERT INTO O_TPARM
	VALUES (214,
	44,
	'direction',
	21,
	0,
	'',
	0,
	'');
INSERT INTO ACT_OPB
	VALUES (215,
	44);
INSERT INTO ACT_ACT
	VALUES (215,
	'class operation',
	0,
	216,
	0,
	0,
	'SumoSimulatorProxy::direction2int',
	0);
INSERT INTO ACT_BLK
	VALUES (216,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5,
	26,
	0,
	215,
	0);
INSERT INTO ACT_SMT
	VALUES (217,
	216,
	218,
	1,
	1,
	'SumoSimulatorProxy::direction2int line: 1');
INSERT INTO ACT_IF
	VALUES (217,
	219,
	220,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (221,
	216,
	0,
	3,
	1,
	'SumoSimulatorProxy::direction2int line: 3');
INSERT INTO ACT_EL
	VALUES (221,
	222,
	223,
	217);
INSERT INTO ACT_SMT
	VALUES (224,
	216,
	0,
	5,
	1,
	'SumoSimulatorProxy::direction2int line: 5');
INSERT INTO ACT_EL
	VALUES (224,
	225,
	226,
	217);
INSERT INTO ACT_SMT
	VALUES (218,
	216,
	0,
	8,
	1,
	'SumoSimulatorProxy::direction2int line: 8');
INSERT INTO ACT_RET
	VALUES (218,
	227);
INSERT INTO V_VAL
	VALUES (228,
	0,
	0,
	1,
	11,
	19,
	0,
	0,
	0,
	0,
	21,
	216);
INSERT INTO V_PVL
	VALUES (228,
	0,
	0,
	214,
	0);
INSERT INTO V_VAL
	VALUES (220,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	4,
	216);
INSERT INTO V_BIN
	VALUES (220,
	229,
	228,
	'==');
INSERT INTO V_VAL
	VALUES (229,
	0,
	0,
	1,
	35,
	42,
	0,
	0,
	0,
	0,
	21,
	216);
INSERT INTO V_LEN
	VALUES (229,
	24,
	1,
	24);
INSERT INTO V_VAL
	VALUES (230,
	0,
	0,
	3,
	13,
	21,
	0,
	0,
	0,
	0,
	21,
	216);
INSERT INTO V_PVL
	VALUES (230,
	0,
	0,
	214,
	0);
INSERT INTO V_VAL
	VALUES (223,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	4,
	216);
INSERT INTO V_BIN
	VALUES (223,
	231,
	230,
	'==');
INSERT INTO V_VAL
	VALUES (231,
	0,
	0,
	3,
	37,
	40,
	0,
	0,
	0,
	0,
	21,
	216);
INSERT INTO V_LEN
	VALUES (231,
	23,
	3,
	26);
INSERT INTO V_VAL
	VALUES (232,
	0,
	0,
	5,
	13,
	21,
	0,
	0,
	0,
	0,
	21,
	216);
INSERT INTO V_PVL
	VALUES (232,
	0,
	0,
	214,
	0);
INSERT INTO V_VAL
	VALUES (226,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	4,
	216);
INSERT INTO V_BIN
	VALUES (226,
	233,
	232,
	'==');
INSERT INTO V_VAL
	VALUES (233,
	0,
	0,
	5,
	37,
	43,
	0,
	0,
	0,
	0,
	21,
	216);
INSERT INTO V_LEN
	VALUES (233,
	22,
	5,
	26);
INSERT INTO V_VAL
	VALUES (227,
	0,
	0,
	8,
	8,
	8,
	0,
	0,
	0,
	0,
	5,
	216);
INSERT INTO V_LIN
	VALUES (227,
	'0');
INSERT INTO ACT_BLK
	VALUES (219,
	0,
	0,
	0,
	'',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	215,
	0);
INSERT INTO ACT_SMT
	VALUES (234,
	219,
	0,
	2,
	3,
	'SumoSimulatorProxy::direction2int line: 2');
INSERT INTO ACT_RET
	VALUES (234,
	235);
INSERT INTO V_VAL
	VALUES (235,
	0,
	0,
	2,
	10,
	10,
	0,
	0,
	0,
	0,
	5,
	219);
INSERT INTO V_LIN
	VALUES (235,
	'0');
INSERT INTO ACT_BLK
	VALUES (222,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	215,
	0);
INSERT INTO ACT_SMT
	VALUES (236,
	222,
	0,
	4,
	3,
	'SumoSimulatorProxy::direction2int line: 4');
INSERT INTO ACT_RET
	VALUES (236,
	237);
INSERT INTO V_VAL
	VALUES (237,
	0,
	0,
	4,
	10,
	10,
	0,
	0,
	0,
	0,
	5,
	222);
INSERT INTO V_LIN
	VALUES (237,
	'1');
INSERT INTO ACT_BLK
	VALUES (225,
	0,
	0,
	0,
	'',
	'',
	'',
	6,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	215,
	0);
INSERT INTO ACT_SMT
	VALUES (238,
	225,
	0,
	6,
	3,
	'SumoSimulatorProxy::direction2int line: 6');
INSERT INTO ACT_RET
	VALUES (238,
	239);
INSERT INTO V_VAL
	VALUES (239,
	0,
	0,
	6,
	10,
	10,
	0,
	0,
	0,
	0,
	5,
	225);
INSERT INTO V_LIN
	VALUES (239,
	'2');
INSERT INTO O_TFR
	VALUES (240,
	192,
	'connect',
	'',
	3,
	0,
	'SumoSimBridge::connect();

create event instance evt of SumoSimulatorProxy_A1:lineDetected() to SumoSimulatorProxy class;
SumoSimBridge::feedLineDetectedEvent(evt: evt);

create event instance evt of SumoSimulatorProxy_A3:touchLeft() to SumoSimulatorProxy class;
SumoSimBridge::feedTouchLeftEvent(evt: evt);

create event instance evt of SumoSimulatorProxy_A4:touchRight() to SumoSimulatorProxy class;
SumoSimBridge::feedTouchRightEvent(evt: evt);

::startWithDelay();',
	1,
	'',
	60);
INSERT INTO ACT_OPB
	VALUES (241,
	240);
INSERT INTO ACT_ACT
	VALUES (241,
	'class operation',
	0,
	242,
	0,
	0,
	'SumoSimulatorProxy::connect',
	0);
INSERT INTO ACT_BLK
	VALUES (242,
	0,
	0,
	0,
	'SumoSimBridge',
	'',
	'',
	12,
	1,
	10,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	241,
	0);
INSERT INTO ACT_SMT
	VALUES (243,
	242,
	244,
	1,
	1,
	'SumoSimulatorProxy::connect line: 1');
INSERT INTO ACT_BRG
	VALUES (243,
	156,
	1,
	16,
	1,
	1);
INSERT INTO ACT_SMT
	VALUES (244,
	242,
	245,
	3,
	1,
	'SumoSimulatorProxy::connect line: 3');
INSERT INTO E_ESS
	VALUES (244,
	1,
	0,
	3,
	30,
	3,
	52,
	3,
	70,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (244,
	1,
	246);
INSERT INTO E_CSME
	VALUES (244,
	247,
	76);
INSERT INTO E_CEA
	VALUES (244);
INSERT INTO ACT_SMT
	VALUES (245,
	242,
	248,
	4,
	1,
	'SumoSimulatorProxy::connect line: 4');
INSERT INTO ACT_BRG
	VALUES (245,
	146,
	4,
	16,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES (248,
	242,
	249,
	6,
	1,
	'SumoSimulatorProxy::connect line: 6');
INSERT INTO E_ESS
	VALUES (248,
	1,
	0,
	6,
	30,
	6,
	52,
	6,
	67,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (248,
	0,
	246);
INSERT INTO E_CSME
	VALUES (248,
	250,
	76);
INSERT INTO E_CEA
	VALUES (248);
INSERT INTO ACT_SMT
	VALUES (249,
	242,
	251,
	7,
	1,
	'SumoSimulatorProxy::connect line: 7');
INSERT INTO ACT_BRG
	VALUES (249,
	166,
	7,
	16,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES (251,
	242,
	252,
	9,
	1,
	'SumoSimulatorProxy::connect line: 9');
INSERT INTO E_ESS
	VALUES (251,
	1,
	0,
	9,
	30,
	9,
	52,
	9,
	68,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (251,
	0,
	246);
INSERT INTO E_CSME
	VALUES (251,
	253,
	76);
INSERT INTO E_CEA
	VALUES (251);
INSERT INTO ACT_SMT
	VALUES (252,
	242,
	254,
	10,
	1,
	'SumoSimulatorProxy::connect line: 10');
INSERT INTO ACT_BRG
	VALUES (252,
	178,
	10,
	16,
	10,
	1);
INSERT INTO ACT_SMT
	VALUES (254,
	242,
	0,
	12,
	1,
	'SumoSimulatorProxy::connect line: 12');
INSERT INTO ACT_FNC
	VALUES (254,
	186,
	12,
	3);
INSERT INTO V_VAL
	VALUES (255,
	0,
	0,
	4,
	43,
	45,
	0,
	0,
	0,
	0,
	13,
	242);
INSERT INTO V_TVL
	VALUES (255,
	246);
INSERT INTO V_PAR
	VALUES (255,
	245,
	0,
	'evt',
	0,
	4,
	38);
INSERT INTO V_VAL
	VALUES (256,
	0,
	0,
	7,
	40,
	42,
	0,
	0,
	0,
	0,
	13,
	242);
INSERT INTO V_TVL
	VALUES (256,
	246);
INSERT INTO V_PAR
	VALUES (256,
	249,
	0,
	'evt',
	0,
	7,
	35);
INSERT INTO V_VAL
	VALUES (257,
	0,
	0,
	10,
	41,
	43,
	0,
	0,
	0,
	0,
	13,
	242);
INSERT INTO V_TVL
	VALUES (257,
	246);
INSERT INTO V_PAR
	VALUES (257,
	252,
	0,
	'evt',
	0,
	10,
	36);
INSERT INTO V_VAR
	VALUES (246,
	242,
	'evt',
	1,
	13);
INSERT INTO V_TRN
	VALUES (246,
	0,
	'');
INSERT INTO V_LOC
	VALUES (258,
	3,
	23,
	25,
	246);
INSERT INTO V_LOC
	VALUES (259,
	4,
	43,
	45,
	246);
INSERT INTO V_LOC
	VALUES (260,
	6,
	23,
	25,
	246);
INSERT INTO V_LOC
	VALUES (261,
	7,
	40,
	42,
	246);
INSERT INTO V_LOC
	VALUES (262,
	9,
	23,
	25,
	246);
INSERT INTO V_LOC
	VALUES (263,
	10,
	41,
	43,
	246);
INSERT INTO O_TFR
	VALUES (60,
	192,
	'orientation2int',
	'',
	5,
	0,
	'if (param.orientation == Orientation::left)
  return 0;
elif (param.orientation == Orientation::straight)
  return 1;
elif (param.orientation == Orientation::right)
  return 2;
end if;
return 0;',
	1,
	'',
	44);
INSERT INTO O_TPARM
	VALUES (264,
	60,
	'orientation',
	25,
	0,
	'',
	0,
	'');
INSERT INTO ACT_OPB
	VALUES (265,
	60);
INSERT INTO ACT_ACT
	VALUES (265,
	'class operation',
	0,
	266,
	0,
	0,
	'SumoSimulatorProxy::orientation2int',
	0);
INSERT INTO ACT_BLK
	VALUES (266,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5,
	28,
	0,
	265,
	0);
INSERT INTO ACT_SMT
	VALUES (267,
	266,
	268,
	1,
	1,
	'SumoSimulatorProxy::orientation2int line: 1');
INSERT INTO ACT_IF
	VALUES (267,
	269,
	270,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (271,
	266,
	0,
	3,
	1,
	'SumoSimulatorProxy::orientation2int line: 3');
INSERT INTO ACT_EL
	VALUES (271,
	272,
	273,
	267);
INSERT INTO ACT_SMT
	VALUES (274,
	266,
	0,
	5,
	1,
	'SumoSimulatorProxy::orientation2int line: 5');
INSERT INTO ACT_EL
	VALUES (274,
	275,
	276,
	267);
INSERT INTO ACT_SMT
	VALUES (268,
	266,
	0,
	8,
	1,
	'SumoSimulatorProxy::orientation2int line: 8');
INSERT INTO ACT_RET
	VALUES (268,
	277);
INSERT INTO V_VAL
	VALUES (278,
	0,
	0,
	1,
	11,
	21,
	0,
	0,
	0,
	0,
	25,
	266);
INSERT INTO V_PVL
	VALUES (278,
	0,
	0,
	264,
	0);
INSERT INTO V_VAL
	VALUES (270,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	4,
	266);
INSERT INTO V_BIN
	VALUES (270,
	279,
	278,
	'==');
INSERT INTO V_VAL
	VALUES (279,
	0,
	0,
	1,
	39,
	42,
	0,
	0,
	0,
	0,
	25,
	266);
INSERT INTO V_LEN
	VALUES (279,
	26,
	1,
	26);
INSERT INTO V_VAL
	VALUES (280,
	0,
	0,
	3,
	13,
	23,
	0,
	0,
	0,
	0,
	25,
	266);
INSERT INTO V_PVL
	VALUES (280,
	0,
	0,
	264,
	0);
INSERT INTO V_VAL
	VALUES (273,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	4,
	266);
INSERT INTO V_BIN
	VALUES (273,
	281,
	280,
	'==');
INSERT INTO V_VAL
	VALUES (281,
	0,
	0,
	3,
	41,
	48,
	0,
	0,
	0,
	0,
	25,
	266);
INSERT INTO V_LEN
	VALUES (281,
	28,
	3,
	28);
INSERT INTO V_VAL
	VALUES (282,
	0,
	0,
	5,
	13,
	23,
	0,
	0,
	0,
	0,
	25,
	266);
INSERT INTO V_PVL
	VALUES (282,
	0,
	0,
	264,
	0);
INSERT INTO V_VAL
	VALUES (276,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	4,
	266);
INSERT INTO V_BIN
	VALUES (276,
	283,
	282,
	'==');
INSERT INTO V_VAL
	VALUES (283,
	0,
	0,
	5,
	41,
	45,
	0,
	0,
	0,
	0,
	25,
	266);
INSERT INTO V_LEN
	VALUES (283,
	27,
	5,
	28);
INSERT INTO V_VAL
	VALUES (277,
	0,
	0,
	8,
	8,
	8,
	0,
	0,
	0,
	0,
	5,
	266);
INSERT INTO V_LIN
	VALUES (277,
	'0');
INSERT INTO ACT_BLK
	VALUES (269,
	0,
	0,
	0,
	'',
	'',
	'',
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	265,
	0);
INSERT INTO ACT_SMT
	VALUES (284,
	269,
	0,
	2,
	3,
	'SumoSimulatorProxy::orientation2int line: 2');
INSERT INTO ACT_RET
	VALUES (284,
	285);
INSERT INTO V_VAL
	VALUES (285,
	0,
	0,
	2,
	10,
	10,
	0,
	0,
	0,
	0,
	5,
	269);
INSERT INTO V_LIN
	VALUES (285,
	'0');
INSERT INTO ACT_BLK
	VALUES (272,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	265,
	0);
INSERT INTO ACT_SMT
	VALUES (286,
	272,
	0,
	4,
	3,
	'SumoSimulatorProxy::orientation2int line: 4');
INSERT INTO ACT_RET
	VALUES (286,
	287);
INSERT INTO V_VAL
	VALUES (287,
	0,
	0,
	4,
	10,
	10,
	0,
	0,
	0,
	0,
	5,
	272);
INSERT INTO V_LIN
	VALUES (287,
	'1');
INSERT INTO ACT_BLK
	VALUES (275,
	0,
	0,
	0,
	'',
	'',
	'',
	6,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	265,
	0);
INSERT INTO ACT_SMT
	VALUES (288,
	275,
	0,
	6,
	3,
	'SumoSimulatorProxy::orientation2int line: 6');
INSERT INTO ACT_RET
	VALUES (288,
	289);
INSERT INTO V_VAL
	VALUES (289,
	0,
	0,
	6,
	10,
	10,
	0,
	0,
	0,
	0,
	5,
	275);
INSERT INTO V_LIN
	VALUES (289,
	'2');
INSERT INTO O_NBATTR
	VALUES (202,
	192);
INSERT INTO O_BATTR
	VALUES (202,
	192);
INSERT INTO O_ATTR
	VALUES (202,
	192,
	0,
	'startupWaitTime',
	'',
	'',
	'startupWaitTime',
	0,
	5,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	192);
INSERT INTO O_ID
	VALUES (1,
	192);
INSERT INTO O_ID
	VALUES (2,
	192);
INSERT INTO SM_ASM
	VALUES (76,
	192);
INSERT INTO SM_SM
	VALUES (76,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (76);
INSERT INTO SM_LEVT
	VALUES (247,
	76,
	0);
INSERT INTO SM_SEVT
	VALUES (247,
	76,
	0);
INSERT INTO SM_EVT
	VALUES (247,
	76,
	0,
	1,
	'lineDetected',
	0,
	'',
	'SumoSimulatorProxy_A1',
	'');
INSERT INTO SM_LEVT
	VALUES (250,
	76,
	0);
INSERT INTO SM_SEVT
	VALUES (250,
	76,
	0);
INSERT INTO SM_EVT
	VALUES (250,
	76,
	0,
	3,
	'touchLeft',
	0,
	'',
	'SumoSimulatorProxy_A3',
	'');
INSERT INTO SM_LEVT
	VALUES (253,
	76,
	0);
INSERT INTO SM_SEVT
	VALUES (253,
	76,
	0);
INSERT INTO SM_EVT
	VALUES (253,
	76,
	0,
	4,
	'touchRight',
	0,
	'',
	'SumoSimulatorProxy_A4',
	'');
INSERT INTO SM_LEVT
	VALUES (75,
	76,
	0);
INSERT INTO SM_SEVT
	VALUES (75,
	76,
	0);
INSERT INTO SM_EVT
	VALUES (75,
	76,
	0,
	5,
	'tick',
	0,
	'',
	'SumoSimulatorProxy_A5',
	'');
INSERT INTO SM_LEVT
	VALUES (198,
	76,
	0);
INSERT INTO SM_SEVT
	VALUES (198,
	76,
	0);
INSERT INTO SM_EVT
	VALUES (198,
	76,
	0,
	6,
	'startupDelay',
	0,
	'',
	'SumoSimulatorProxy_A6',
	'');
INSERT INTO SM_STATE
	VALUES (290,
	76,
	0,
	'running',
	2,
	0);
INSERT INTO SM_SEME
	VALUES (290,
	247,
	76,
	0);
INSERT INTO SM_SEME
	VALUES (290,
	250,
	76,
	0);
INSERT INTO SM_SEME
	VALUES (290,
	253,
	76,
	0);
INSERT INTO SM_SEME
	VALUES (290,
	75,
	76,
	0);
INSERT INTO SM_CH
	VALUES (290,
	198,
	76,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (290,
	198,
	76,
	0);
INSERT INTO SM_MOAH
	VALUES (291,
	76,
	290);
INSERT INTO SM_AH
	VALUES (291,
	76);
INSERT INTO SM_ACT
	VALUES (291,
	76,
	1,
	'',
	'');
INSERT INTO ACT_SAB
	VALUES (292,
	76,
	291);
INSERT INTO ACT_ACT
	VALUES (292,
	'class state',
	0,
	293,
	0,
	0,
	'SumoSimulatorProxy::running',
	0);
INSERT INTO ACT_BLK
	VALUES (293,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	292,
	0);
INSERT INTO SM_STATE
	VALUES (294,
	76,
	0,
	'idle',
	1,
	0);
INSERT INTO SM_CH
	VALUES (294,
	247,
	76,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (294,
	247,
	76,
	0);
INSERT INTO SM_CH
	VALUES (294,
	250,
	76,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (294,
	250,
	76,
	0);
INSERT INTO SM_CH
	VALUES (294,
	253,
	76,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (294,
	253,
	76,
	0);
INSERT INTO SM_CH
	VALUES (294,
	75,
	76,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (294,
	75,
	76,
	0);
INSERT INTO SM_SEME
	VALUES (294,
	198,
	76,
	0);
INSERT INTO SM_MOAH
	VALUES (295,
	76,
	294);
INSERT INTO SM_AH
	VALUES (295,
	76);
INSERT INTO SM_ACT
	VALUES (295,
	76,
	1,
	'',
	'');
INSERT INTO ACT_SAB
	VALUES (296,
	76,
	295);
INSERT INTO ACT_ACT
	VALUES (296,
	'class state',
	0,
	297,
	0,
	0,
	'SumoSimulatorProxy::idle',
	0);
INSERT INTO ACT_BLK
	VALUES (297,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	296,
	0);
INSERT INTO SM_NSTXN
	VALUES (298,
	76,
	290,
	247,
	0);
INSERT INTO SM_TAH
	VALUES (299,
	76,
	298);
INSERT INTO SM_AH
	VALUES (299,
	76);
INSERT INTO SM_ACT
	VALUES (299,
	76,
	1,
	'create event instance evt of SumoSimulatorProxy_A1:lineDetected() to SumoSimulatorProxy class;
SumoSimBridge::feedLineDetectedEvent(evt: evt);
SumoSimBridge::sendLineDetected();',
	'');
INSERT INTO ACT_TAB
	VALUES (300,
	76,
	299);
INSERT INTO ACT_ACT
	VALUES (300,
	'class transition',
	0,
	301,
	0,
	0,
	'SumoSimulatorProxy_A1: lineDetected in running to running',
	0);
INSERT INTO ACT_BLK
	VALUES (301,
	0,
	0,
	0,
	'SumoSimBridge',
	'',
	'',
	3,
	1,
	3,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	300,
	0);
INSERT INTO ACT_SMT
	VALUES (302,
	301,
	303,
	1,
	1,
	'SumoSimulatorProxy_A1: lineDetected in running to running line: 1');
INSERT INTO E_ESS
	VALUES (302,
	1,
	0,
	1,
	30,
	1,
	52,
	1,
	70,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (302,
	1,
	304);
INSERT INTO E_CSME
	VALUES (302,
	247,
	76);
INSERT INTO E_CEA
	VALUES (302);
INSERT INTO ACT_SMT
	VALUES (303,
	301,
	305,
	2,
	1,
	'SumoSimulatorProxy_A1: lineDetected in running to running line: 2');
INSERT INTO ACT_BRG
	VALUES (303,
	146,
	2,
	16,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (305,
	301,
	0,
	3,
	1,
	'SumoSimulatorProxy_A1: lineDetected in running to running line: 3');
INSERT INTO ACT_BRG
	VALUES (305,
	159,
	3,
	16,
	3,
	1);
INSERT INTO V_VAL
	VALUES (306,
	0,
	0,
	2,
	43,
	45,
	0,
	0,
	0,
	0,
	13,
	301);
INSERT INTO V_TVL
	VALUES (306,
	304);
INSERT INTO V_PAR
	VALUES (306,
	303,
	0,
	'evt',
	0,
	2,
	38);
INSERT INTO V_VAR
	VALUES (304,
	301,
	'evt',
	1,
	13);
INSERT INTO V_TRN
	VALUES (304,
	0,
	'');
INSERT INTO V_LOC
	VALUES (307,
	1,
	23,
	25,
	304);
INSERT INTO V_LOC
	VALUES (308,
	2,
	43,
	45,
	304);
INSERT INTO SM_TXN
	VALUES (298,
	76,
	290,
	0);
INSERT INTO SM_NSTXN
	VALUES (309,
	76,
	290,
	250,
	0);
INSERT INTO SM_TAH
	VALUES (310,
	76,
	309);
INSERT INTO SM_AH
	VALUES (310,
	76);
INSERT INTO SM_ACT
	VALUES (310,
	76,
	1,
	'create event instance evt of SumoSimulatorProxy_A3:touchLeft() to SumoSimulatorProxy class;
SumoSimBridge::feedTouchLeftEvent(evt: evt);
SumoSimBridge::sendTouchLeft();',
	'');
INSERT INTO ACT_TAB
	VALUES (311,
	76,
	310);
INSERT INTO ACT_ACT
	VALUES (311,
	'class transition',
	0,
	312,
	0,
	0,
	'SumoSimulatorProxy_A3: touchLeft in running to running',
	0);
INSERT INTO ACT_BLK
	VALUES (312,
	0,
	0,
	0,
	'SumoSimBridge',
	'',
	'',
	3,
	1,
	3,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	311,
	0);
INSERT INTO ACT_SMT
	VALUES (313,
	312,
	314,
	1,
	1,
	'SumoSimulatorProxy_A3: touchLeft in running to running line: 1');
INSERT INTO E_ESS
	VALUES (313,
	1,
	0,
	1,
	30,
	1,
	52,
	1,
	67,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (313,
	1,
	315);
INSERT INTO E_CSME
	VALUES (313,
	250,
	76);
INSERT INTO E_CEA
	VALUES (313);
INSERT INTO ACT_SMT
	VALUES (314,
	312,
	316,
	2,
	1,
	'SumoSimulatorProxy_A3: touchLeft in running to running line: 2');
INSERT INTO ACT_BRG
	VALUES (314,
	166,
	2,
	16,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (316,
	312,
	0,
	3,
	1,
	'SumoSimulatorProxy_A3: touchLeft in running to running line: 3');
INSERT INTO ACT_BRG
	VALUES (316,
	170,
	3,
	16,
	3,
	1);
INSERT INTO V_VAL
	VALUES (317,
	0,
	0,
	2,
	40,
	42,
	0,
	0,
	0,
	0,
	13,
	312);
INSERT INTO V_TVL
	VALUES (317,
	315);
INSERT INTO V_PAR
	VALUES (317,
	314,
	0,
	'evt',
	0,
	2,
	35);
INSERT INTO V_VAR
	VALUES (315,
	312,
	'evt',
	1,
	13);
INSERT INTO V_TRN
	VALUES (315,
	0,
	'');
INSERT INTO V_LOC
	VALUES (318,
	1,
	23,
	25,
	315);
INSERT INTO V_LOC
	VALUES (319,
	2,
	40,
	42,
	315);
INSERT INTO SM_TXN
	VALUES (309,
	76,
	290,
	0);
INSERT INTO SM_NSTXN
	VALUES (320,
	76,
	290,
	253,
	0);
INSERT INTO SM_TAH
	VALUES (321,
	76,
	320);
INSERT INTO SM_AH
	VALUES (321,
	76);
INSERT INTO SM_ACT
	VALUES (321,
	76,
	1,
	'create event instance evt of SumoSimulatorProxy_A4:touchRight() to SumoSimulatorProxy class;
SumoSimBridge::feedTouchRightEvent(evt: evt);
SumoSimBridge::sendTouchRight();',
	'');
INSERT INTO ACT_TAB
	VALUES (322,
	76,
	321);
INSERT INTO ACT_ACT
	VALUES (322,
	'class transition',
	0,
	323,
	0,
	0,
	'SumoSimulatorProxy_A4: touchRight in running to running',
	0);
INSERT INTO ACT_BLK
	VALUES (323,
	0,
	0,
	0,
	'SumoSimBridge',
	'',
	'',
	3,
	1,
	3,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	322,
	0);
INSERT INTO ACT_SMT
	VALUES (324,
	323,
	325,
	1,
	1,
	'SumoSimulatorProxy_A4: touchRight in running to running line: 1');
INSERT INTO E_ESS
	VALUES (324,
	1,
	0,
	1,
	30,
	1,
	52,
	1,
	68,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (324,
	1,
	326);
INSERT INTO E_CSME
	VALUES (324,
	253,
	76);
INSERT INTO E_CEA
	VALUES (324);
INSERT INTO ACT_SMT
	VALUES (325,
	323,
	327,
	2,
	1,
	'SumoSimulatorProxy_A4: touchRight in running to running line: 2');
INSERT INTO ACT_BRG
	VALUES (325,
	178,
	2,
	16,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (327,
	323,
	0,
	3,
	1,
	'SumoSimulatorProxy_A4: touchRight in running to running line: 3');
INSERT INTO ACT_BRG
	VALUES (327,
	174,
	3,
	16,
	3,
	1);
INSERT INTO V_VAL
	VALUES (328,
	0,
	0,
	2,
	41,
	43,
	0,
	0,
	0,
	0,
	13,
	323);
INSERT INTO V_TVL
	VALUES (328,
	326);
INSERT INTO V_PAR
	VALUES (328,
	325,
	0,
	'evt',
	0,
	2,
	36);
INSERT INTO V_VAR
	VALUES (326,
	323,
	'evt',
	1,
	13);
INSERT INTO V_TRN
	VALUES (326,
	0,
	'');
INSERT INTO V_LOC
	VALUES (329,
	1,
	23,
	25,
	326);
INSERT INTO V_LOC
	VALUES (330,
	2,
	41,
	43,
	326);
INSERT INTO SM_TXN
	VALUES (320,
	76,
	290,
	0);
INSERT INTO SM_NSTXN
	VALUES (331,
	76,
	290,
	75,
	0);
INSERT INTO SM_TAH
	VALUES (332,
	76,
	331);
INSERT INTO SM_AH
	VALUES (332,
	76);
INSERT INTO SM_ACT
	VALUES (332,
	76,
	1,
	'SumoSimBridge::tick();
',
	'');
INSERT INTO ACT_TAB
	VALUES (333,
	76,
	332);
INSERT INTO ACT_ACT
	VALUES (333,
	'class transition',
	0,
	334,
	0,
	0,
	'SumoSimulatorProxy_A5: tick in running to running',
	0);
INSERT INTO ACT_BLK
	VALUES (334,
	0,
	0,
	0,
	'SumoSimBridge',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	333,
	0);
INSERT INTO ACT_SMT
	VALUES (335,
	334,
	0,
	1,
	1,
	'SumoSimulatorProxy_A5: tick in running to running line: 1');
INSERT INTO ACT_BRG
	VALUES (335,
	182,
	1,
	16,
	1,
	1);
INSERT INTO SM_TXN
	VALUES (331,
	76,
	290,
	0);
INSERT INTO SM_NSTXN
	VALUES (336,
	76,
	294,
	198,
	0);
INSERT INTO SM_TAH
	VALUES (337,
	76,
	336);
INSERT INTO SM_AH
	VALUES (337,
	76);
INSERT INTO SM_ACT
	VALUES (337,
	76,
	1,
	'IO::init();',
	'');
INSERT INTO ACT_TAB
	VALUES (338,
	76,
	337);
INSERT INTO ACT_ACT
	VALUES (338,
	'class transition',
	0,
	339,
	0,
	0,
	'SumoSimulatorProxy_A6: startupDelay in idle to running',
	0);
INSERT INTO ACT_BLK
	VALUES (339,
	0,
	0,
	0,
	'IO',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	338,
	0);
INSERT INTO ACT_SMT
	VALUES (340,
	339,
	0,
	1,
	1,
	'SumoSimulatorProxy_A6: startupDelay in idle to running line: 1');
INSERT INTO ACT_IOP
	VALUES (340,
	96,
	0,
	1,
	5,
	1,
	1);
INSERT INTO SM_TXN
	VALUES (336,
	76,
	290,
	0);
INSERT INTO S_DIS
	VALUES (104,
	341);
INSERT INTO S_DT
	VALUES (341,
	0,
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES (341,
	0);
INSERT INTO S_DIS
	VALUES (104,
	342);
INSERT INTO S_DT
	VALUES (342,
	0,
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES (342,
	1);
INSERT INTO S_DIS
	VALUES (104,
	343);
INSERT INTO S_DT
	VALUES (343,
	0,
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES (343,
	2);
INSERT INTO S_DIS
	VALUES (104,
	344);
INSERT INTO S_DT
	VALUES (344,
	0,
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES (344,
	3);
INSERT INTO S_DIS
	VALUES (104,
	345);
INSERT INTO S_DT
	VALUES (345,
	0,
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES (345,
	4);
INSERT INTO S_DIS
	VALUES (104,
	346);
INSERT INTO S_DT
	VALUES (346,
	0,
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES (346,
	5);
INSERT INTO S_DIS
	VALUES (104,
	347);
INSERT INTO S_DT
	VALUES (347,
	0,
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (347,
	6);
INSERT INTO S_DIS
	VALUES (104,
	348);
INSERT INTO S_DT
	VALUES (348,
	0,
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (348,
	7);
INSERT INTO S_DIS
	VALUES (104,
	349);
INSERT INTO S_DT
	VALUES (349,
	0,
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (349,
	8);
INSERT INTO S_DIS
	VALUES (104,
	350);
INSERT INTO S_DT
	VALUES (350,
	0,
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (350,
	9);
INSERT INTO S_DIS
	VALUES (104,
	351);
INSERT INTO S_DT
	VALUES (351,
	0,
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (351,
	10);
INSERT INTO S_DIS
	VALUES (104,
	352);
INSERT INTO S_DT
	VALUES (352,
	0,
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (352,
	11);
INSERT INTO S_DIS
	VALUES (104,
	353);
INSERT INTO S_DT
	VALUES (353,
	0,
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (353,
	12);
INSERT INTO S_DIS
	VALUES (104,
	354);
INSERT INTO S_DT
	VALUES (354,
	0,
	'date',
	'Time as known in the external world. For example, 12 October 1492,
13:25:10. The accuracy of external time is dependent on the architecture and
implementation.',
	'');
INSERT INTO S_UDT
	VALUES (354,
	352,
	1);
INSERT INTO S_DIS
	VALUES (104,
	355);
INSERT INTO S_DT
	VALUES (355,
	0,
	'timestamp',
	' The system clock counts time in ticks. The size of a tick is dependent on the
 architecture and implementation.',
	'');
INSERT INTO S_UDT
	VALUES (355,
	352,
	2);
INSERT INTO S_DIS
	VALUES (104,
	356);
INSERT INTO S_DT
	VALUES (356,
	0,
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES (356,
	353,
	3);
INSERT INTO C_C
	VALUES (357,
	29,
	0,
	'Test',
	'',
	0,
	29);
INSERT INTO C_PO
	VALUES (358,
	357,
	'IO',
	0,
	0);
INSERT INTO C_IR
	VALUES (359,
	33,
	0,
	358);
INSERT INTO C_P
	VALUES (359,
	'platform',
	'Unnamed Interface',
	'');
INSERT INTO SPR_PEP
	VALUES (360,
	35,
	359);
INSERT INTO SPR_PS
	VALUES (360,
	'go',
	'',
	'',
	1);
INSERT INTO ACT_PSB
	VALUES (361,
	360);
INSERT INTO ACT_ACT
	VALUES (361,
	'signal',
	0,
	362,
	0,
	0,
	'IO::platform::go',
	0);
INSERT INTO ACT_BLK
	VALUES (362,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	361,
	0);
INSERT INTO SPR_PEP
	VALUES (363,
	51,
	359);
INSERT INTO SPR_PS
	VALUES (363,
	'turn',
	'd = SumoSimulatorProxy::orientation2int(orientation: param.orientation);
SumoSimBridge::turn(orientation: d);',
	'',
	1);
INSERT INTO ACT_PSB
	VALUES (364,
	363);
INSERT INTO ACT_ACT
	VALUES (364,
	'signal',
	0,
	365,
	0,
	0,
	'IO::platform::turn',
	0);
INSERT INTO ACT_BLK
	VALUES (365,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	364,
	0);
INSERT INTO SPR_PEP
	VALUES (366,
	67,
	359);
INSERT INTO SPR_PS
	VALUES (366,
	'setName',
	'',
	'create object instance tc1 of TestCase1;
generate TestCase18:setName() to tc1;',
	1);
INSERT INTO ACT_PSB
	VALUES (367,
	366);
INSERT INTO ACT_ACT
	VALUES (367,
	'signal',
	0,
	368,
	0,
	0,
	'IO::platform::setName',
	0);
INSERT INTO ACT_BLK
	VALUES (368,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	1,
	31,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	367,
	0);
INSERT INTO ACT_SMT
	VALUES (369,
	368,
	370,
	1,
	1,
	'IO::platform::setName line: 1');
INSERT INTO ACT_CR
	VALUES (369,
	371,
	1,
	372,
	1,
	31);
INSERT INTO ACT_SMT
	VALUES (370,
	368,
	0,
	2,
	1,
	'IO::platform::setName line: 2');
INSERT INTO E_ESS
	VALUES (370,
	1,
	0,
	2,
	10,
	2,
	21,
	1,
	31,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (370);
INSERT INTO E_GSME
	VALUES (370,
	373,
	374);
INSERT INTO E_GEN
	VALUES (370,
	371);
INSERT INTO V_VAR
	VALUES (371,
	368,
	'tc1',
	1,
	11);
INSERT INTO V_INT
	VALUES (371,
	0,
	372);
INSERT INTO V_LOC
	VALUES (375,
	1,
	24,
	26,
	371);
INSERT INTO V_LOC
	VALUES (376,
	2,
	34,
	36,
	371);
INSERT INTO SPR_PEP
	VALUES (377,
	89,
	359);
INSERT INTO SPR_PO
	VALUES (377,
	'lineDetected',
	'',
	'',
	1);
INSERT INTO ACT_POB
	VALUES (378,
	377);
INSERT INTO ACT_ACT
	VALUES (378,
	'interface operation',
	0,
	379,
	0,
	0,
	'IO::platform::lineDetected',
	0);
INSERT INTO ACT_BLK
	VALUES (379,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	378,
	0);
INSERT INTO SPR_PEP
	VALUES (380,
	93,
	359);
INSERT INTO SPR_PO
	VALUES (380,
	'touchLeft',
	'',
	'',
	1);
INSERT INTO ACT_POB
	VALUES (381,
	380);
INSERT INTO ACT_ACT
	VALUES (381,
	'interface operation',
	0,
	382,
	0,
	0,
	'IO::platform::touchLeft',
	0);
INSERT INTO ACT_BLK
	VALUES (382,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	381,
	0);
INSERT INTO SPR_PEP
	VALUES (383,
	97,
	359);
INSERT INTO SPR_PO
	VALUES (383,
	'init',
	'',
	'',
	1);
INSERT INTO ACT_POB
	VALUES (384,
	383);
INSERT INTO ACT_ACT
	VALUES (384,
	'interface operation',
	0,
	385,
	0,
	0,
	'IO::platform::init',
	0);
INSERT INTO ACT_BLK
	VALUES (385,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	384,
	0);
INSERT INTO SPR_PEP
	VALUES (386,
	101,
	359);
INSERT INTO SPR_PO
	VALUES (386,
	'touchRight',
	'',
	'',
	1);
INSERT INTO ACT_POB
	VALUES (387,
	386);
INSERT INTO ACT_ACT
	VALUES (387,
	'interface operation',
	0,
	388,
	0,
	0,
	'IO::platform::touchRight',
	0);
INSERT INTO ACT_BLK
	VALUES (388,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	387,
	0);
INSERT INTO CN_DC
	VALUES (357,
	389);
INSERT INTO S_DOM
	VALUES (389,
	'Test',
	'',
	0,
	105,
	0);
INSERT INTO S_DPK
	VALUES (390,
	'Datatypes',
	389,
	0);
INSERT INTO EP_SPKG
	VALUES (390,
	0);
INSERT INTO S_EEPK
	VALUES (391,
	'External Entities',
	389,
	0);
INSERT INTO S_EEPIP
	VALUES (391);
INSERT INTO PL_EEPID
	VALUES (389,
	391);
INSERT INTO S_EEIP
	VALUES (391,
	392);
INSERT INTO S_EE
	VALUES (392,
	'Time',
	'The Time external entity provides date, timestamp, and timer related operations.',
	'TIM',
	389);
INSERT INTO S_BRG
	VALUES (393,
	392,
	'current_date',
	'',
	1,
	17,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (394,
	392,
	'create_date',
	'',
	1,
	17,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (395,
	394,
	'second',
	5,
	0,
	'',
	396,
	'');
INSERT INTO S_BPARM
	VALUES (397,
	394,
	'minute',
	5,
	0,
	'',
	398,
	'');
INSERT INTO S_BPARM
	VALUES (398,
	394,
	'hour',
	5,
	0,
	'',
	399,
	'');
INSERT INTO S_BPARM
	VALUES (399,
	394,
	'day',
	5,
	0,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (396,
	394,
	'month',
	5,
	0,
	'',
	397,
	'');
INSERT INTO S_BPARM
	VALUES (400,
	394,
	'year',
	5,
	0,
	'',
	395,
	'');
INSERT INTO S_BRG
	VALUES (401,
	392,
	'get_second',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (402,
	401,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (403,
	392,
	'get_minute',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (404,
	403,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (405,
	392,
	'get_hour',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (406,
	405,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (407,
	392,
	'get_day',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (408,
	407,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (409,
	392,
	'get_month',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (410,
	409,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (411,
	392,
	'get_year',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (412,
	411,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (413,
	392,
	'current_clock',
	'',
	1,
	19,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (414,
	392,
	'timer_start',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Returns the instance
handle of the timer.',
	1,
	18,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (415,
	414,
	'microseconds',
	5,
	0,
	'',
	416,
	'');
INSERT INTO S_BPARM
	VALUES (416,
	414,
	'event_inst',
	13,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (417,
	392,
	'timer_start_recurring',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Upon expiration, the
timer will be restarted and fire again in the specified number of microseconds
generating the passed event. This bridge operation returns the instance handle
of the timer.',
	1,
	18,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (418,
	417,
	'microseconds',
	5,
	0,
	'',
	419,
	'');
INSERT INTO S_BPARM
	VALUES (419,
	417,
	'event_inst',
	13,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (420,
	392,
	'timer_remaining_time',
	'Returns the time remaining (in microseconds) for the passed timer instance. If
the timer has expired, a zero value is returned.',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (421,
	420,
	'timer_inst_ref',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (422,
	392,
	'timer_reset_time',
	'This bridge operation attempts to set the passed existing timer to expire in
the specified number of microseconds. If the timer exists (that is, it has not
expired), a TRUE value is returned. If the timer no longer exists, a FALSE value
is returned.',
	1,
	4,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (423,
	422,
	'timer_inst_ref',
	18,
	0,
	'',
	424,
	'');
INSERT INTO S_BPARM
	VALUES (424,
	422,
	'microseconds',
	5,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (425,
	392,
	'timer_add_time',
	'This bridge operation attempts to add the specified number of microseconds to a
passed existing timer. If the timer exists (that is, it has not expired), a TRUE
value is returned. If the timer no longer exists, a FALSE value is returned.',
	1,
	4,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (426,
	425,
	'timer_inst_ref',
	18,
	0,
	'',
	427,
	'');
INSERT INTO S_BPARM
	VALUES (427,
	425,
	'microseconds',
	5,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (428,
	392,
	'timer_cancel',
	'This bridge operation cancels and deletes the passed timer instance. If the 
timer exists (that is, it had not expired), a TRUE value is returned. If the
timer no longer exists, a FALSE value is returned.',
	1,
	4,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (429,
	428,
	'timer_inst_ref',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_EEIP
	VALUES (391,
	430);
INSERT INTO S_EE
	VALUES (430,
	'Architecture',
	'',
	'ARCH',
	389);
INSERT INTO S_BRG
	VALUES (431,
	430,
	'shutdown',
	'',
	0,
	3,
	'control stop;',
	1,
	'');
INSERT INTO ACT_BRB
	VALUES (432,
	431);
INSERT INTO ACT_ACT
	VALUES (432,
	'bridge',
	0,
	433,
	0,
	0,
	'Architecture::shutdown',
	0);
INSERT INTO ACT_BLK
	VALUES (433,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	432,
	0);
INSERT INTO ACT_SMT
	VALUES (434,
	433,
	0,
	1,
	1,
	'Architecture::shutdown line: 1');
INSERT INTO ACT_CTL
	VALUES (434);
INSERT INTO S_EEIP
	VALUES (391,
	435);
INSERT INTO S_EE
	VALUES (435,
	'Logging',
	'',
	'LOG',
	389);
INSERT INTO S_BRG
	VALUES (436,
	435,
	'LogSuccess',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (437,
	436,
	'message',
	7,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (438,
	436);
INSERT INTO ACT_ACT
	VALUES (438,
	'bridge',
	0,
	439,
	0,
	0,
	'Logging::LogSuccess',
	0);
INSERT INTO ACT_BLK
	VALUES (439,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	438,
	0);
INSERT INTO S_BRG
	VALUES (440,
	435,
	'LogFailure',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (441,
	440,
	'message',
	7,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (442,
	440);
INSERT INTO ACT_ACT
	VALUES (442,
	'bridge',
	0,
	443,
	0,
	0,
	'Logging::LogFailure',
	0);
INSERT INTO ACT_BLK
	VALUES (443,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	442,
	0);
INSERT INTO S_BRG
	VALUES (444,
	435,
	'LogInfo',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (445,
	444,
	'message',
	7,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (446,
	444);
INSERT INTO ACT_ACT
	VALUES (446,
	'bridge',
	0,
	447,
	0,
	0,
	'Logging::LogInfo',
	0);
INSERT INTO ACT_BLK
	VALUES (447,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	446,
	0);
INSERT INTO S_BRG
	VALUES (448,
	435,
	'LogDate',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (449,
	448,
	'd',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (450,
	448,
	'message',
	7,
	0,
	'',
	449,
	'');
INSERT INTO ACT_BRB
	VALUES (451,
	448);
INSERT INTO ACT_ACT
	VALUES (451,
	'bridge',
	0,
	452,
	0,
	0,
	'Logging::LogDate',
	0);
INSERT INTO ACT_BLK
	VALUES (452,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	451,
	0);
INSERT INTO S_BRG
	VALUES (453,
	435,
	'LogTime',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (454,
	453,
	't',
	19,
	0,
	'',
	455,
	'');
INSERT INTO S_BPARM
	VALUES (455,
	453,
	'message',
	7,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (456,
	453);
INSERT INTO ACT_ACT
	VALUES (456,
	'bridge',
	0,
	457,
	0,
	0,
	'Logging::LogTime',
	0);
INSERT INTO ACT_BLK
	VALUES (457,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	456,
	0);
INSERT INTO S_BRG
	VALUES (458,
	435,
	'LogReal',
	'',
	0,
	3,
	'',
	1,
	'');
INSERT INTO S_BPARM
	VALUES (459,
	458,
	'r',
	6,
	0,
	'',
	460,
	'');
INSERT INTO S_BPARM
	VALUES (460,
	458,
	'message',
	7,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (461,
	458);
INSERT INTO ACT_ACT
	VALUES (461,
	'bridge',
	0,
	462,
	0,
	0,
	'Logging::LogReal',
	0);
INSERT INTO ACT_BLK
	VALUES (462,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	461,
	0);
INSERT INTO S_BRG
	VALUES (463,
	435,
	'LogInteger',
	'',
	0,
	3,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (464,
	463,
	'message',
	5,
	0,
	'',
	0,
	'');
INSERT INTO S_FPK
	VALUES (465,
	'Functions',
	389,
	0);
INSERT INTO PL_FPID
	VALUES (465,
	389);
INSERT INTO S_FIP
	VALUES (465,
	466);
INSERT INTO S_SYNC
	VALUES (466,
	389,
	'run',
	'',
	'send IO::init();
',
	3,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (467,
	466);
INSERT INTO ACT_ACT
	VALUES (467,
	'function',
	0,
	468,
	0,
	0,
	'run',
	0);
INSERT INTO ACT_BLK
	VALUES (468,
	0,
	0,
	0,
	'IO',
	'',
	'',
	1,
	1,
	1,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	467,
	0);
INSERT INTO ACT_SMT
	VALUES (469,
	468,
	0,
	1,
	1,
	'run line: 1');
INSERT INTO ACT_IOP
	VALUES (469,
	383,
	0,
	1,
	10,
	1,
	6);
INSERT INTO S_SID
	VALUES (389,
	470);
INSERT INTO S_SS
	VALUES (470,
	'Test',
	'',
	'',
	0,
	389,
	0);
INSERT INTO O_OBJ
	VALUES (372,
	'TestCase1',
	1,
	'TestCase1',
	'',
	470);
INSERT INTO O_NBATTR
	VALUES (471,
	372);
INSERT INTO O_BATTR
	VALUES (471,
	372);
INSERT INTO O_ATTR
	VALUES (471,
	372,
	0,
	'current_state',
	'',
	'',
	'current_state',
	0,
	9,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	372);
INSERT INTO O_ID
	VALUES (1,
	372);
INSERT INTO O_ID
	VALUES (2,
	372);
INSERT INTO SM_ISM
	VALUES (374,
	372);
INSERT INTO SM_SM
	VALUES (374,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (374);
INSERT INTO SM_LEVT
	VALUES (472,
	374,
	0);
INSERT INTO SM_SEVT
	VALUES (472,
	374,
	0);
INSERT INTO SM_EVT
	VALUES (472,
	374,
	0,
	6,
	'step',
	0,
	'',
	'TestCase16',
	'');
INSERT INTO SM_LEVT
	VALUES (373,
	374,
	0);
INSERT INTO SM_SEVT
	VALUES (373,
	374,
	0);
INSERT INTO SM_EVT
	VALUES (373,
	374,
	0,
	8,
	'setName',
	0,
	'',
	'TestCase18',
	'');
INSERT INTO SM_STATE
	VALUES (473,
	374,
	0,
	'sendLineDetected',
	3,
	0);
INSERT INTO SM_SEME
	VALUES (473,
	472,
	374,
	0);
INSERT INTO SM_CH
	VALUES (473,
	373,
	374,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (473,
	373,
	374,
	0);
INSERT INTO SM_MOAH
	VALUES (474,
	374,
	473);
INSERT INTO SM_AH
	VALUES (474,
	374);
INSERT INTO SM_ACT
	VALUES (474,
	374,
	1,
	'send IO::lineDetected();

create event instance step of TestCase16:step() to self;
timer = TIM::timer_start(microseconds: 5000000, event_inst: step);',
	'');
INSERT INTO ACT_SAB
	VALUES (475,
	374,
	474);
INSERT INTO ACT_ACT
	VALUES (475,
	'state',
	0,
	476,
	0,
	0,
	'TestCase1::sendLineDetected',
	0);
INSERT INTO ACT_BLK
	VALUES (476,
	0,
	0,
	0,
	'TIM',
	'',
	'',
	4,
	1,
	4,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	475,
	0);
INSERT INTO ACT_SMT
	VALUES (477,
	476,
	478,
	1,
	1,
	'TestCase1::sendLineDetected line: 1');
INSERT INTO ACT_IOP
	VALUES (477,
	377,
	0,
	1,
	10,
	1,
	6);
INSERT INTO ACT_SMT
	VALUES (478,
	476,
	479,
	3,
	1,
	'TestCase1::sendLineDetected line: 3');
INSERT INTO E_ESS
	VALUES (478,
	1,
	0,
	3,
	31,
	3,
	42,
	1,
	6,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (478,
	1,
	480);
INSERT INTO E_CSME
	VALUES (478,
	472,
	374);
INSERT INTO E_CEI
	VALUES (478,
	481);
INSERT INTO ACT_SMT
	VALUES (479,
	476,
	0,
	4,
	1,
	'TestCase1::sendLineDetected line: 4');
INSERT INTO ACT_AI
	VALUES (479,
	482,
	483,
	0,
	0);
INSERT INTO V_VAL
	VALUES (483,
	1,
	1,
	4,
	1,
	5,
	0,
	0,
	0,
	0,
	18,
	476);
INSERT INTO V_TVL
	VALUES (483,
	484);
INSERT INTO V_VAL
	VALUES (482,
	0,
	0,
	4,
	14,
	-1,
	4,
	26,
	4,
	49,
	18,
	476);
INSERT INTO V_BRV
	VALUES (482,
	414,
	1,
	4,
	9);
INSERT INTO V_VAL
	VALUES (485,
	0,
	0,
	4,
	40,
	46,
	0,
	0,
	0,
	0,
	5,
	476);
INSERT INTO V_LIN
	VALUES (485,
	'5000000');
INSERT INTO V_PAR
	VALUES (485,
	0,
	482,
	'microseconds',
	486,
	4,
	26);
INSERT INTO V_VAL
	VALUES (486,
	0,
	0,
	4,
	61,
	64,
	0,
	0,
	0,
	0,
	13,
	476);
INSERT INTO V_TVL
	VALUES (486,
	480);
INSERT INTO V_PAR
	VALUES (486,
	0,
	482,
	'event_inst',
	0,
	4,
	49);
INSERT INTO V_VAR
	VALUES (480,
	476,
	'step',
	1,
	13);
INSERT INTO V_TRN
	VALUES (480,
	0,
	'');
INSERT INTO V_LOC
	VALUES (487,
	3,
	23,
	26,
	480);
INSERT INTO V_LOC
	VALUES (488,
	4,
	61,
	64,
	480);
INSERT INTO V_VAR
	VALUES (481,
	476,
	'self',
	1,
	11);
INSERT INTO V_INT
	VALUES (481,
	0,
	372);
INSERT INTO V_LOC
	VALUES (489,
	3,
	52,
	55,
	481);
INSERT INTO V_VAR
	VALUES (484,
	476,
	'timer',
	1,
	18);
INSERT INTO V_TRN
	VALUES (484,
	0,
	'');
INSERT INTO V_LOC
	VALUES (490,
	4,
	1,
	5,
	484);
INSERT INTO SM_STATE
	VALUES (491,
	374,
	0,
	'final',
	4,
	1);
INSERT INTO SM_CH
	VALUES (491,
	472,
	374,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (491,
	472,
	374,
	0);
INSERT INTO SM_CH
	VALUES (491,
	373,
	374,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (491,
	373,
	374,
	0);
INSERT INTO SM_MOAH
	VALUES (492,
	374,
	491);
INSERT INTO SM_AH
	VALUES (492,
	374);
INSERT INTO SM_ACT
	VALUES (492,
	374,
	1,
	'send IO::touchLeft();',
	'');
INSERT INTO ACT_SAB
	VALUES (493,
	374,
	492);
INSERT INTO ACT_ACT
	VALUES (493,
	'state',
	0,
	494,
	0,
	0,
	'TestCase1::final',
	0);
INSERT INTO ACT_BLK
	VALUES (494,
	0,
	0,
	0,
	'IO',
	'',
	'',
	1,
	1,
	1,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	493,
	0);
INSERT INTO ACT_SMT
	VALUES (495,
	494,
	0,
	1,
	1,
	'TestCase1::final line: 1');
INSERT INTO ACT_IOP
	VALUES (495,
	380,
	0,
	1,
	10,
	1,
	6);
INSERT INTO SM_STATE
	VALUES (496,
	374,
	0,
	'idle',
	1,
	0);
INSERT INTO SM_CH
	VALUES (496,
	472,
	374,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (496,
	472,
	374,
	0);
INSERT INTO SM_SEME
	VALUES (496,
	373,
	374,
	0);
INSERT INTO SM_MOAH
	VALUES (497,
	374,
	496);
INSERT INTO SM_AH
	VALUES (497,
	374);
INSERT INTO SM_ACT
	VALUES (497,
	374,
	1,
	'',
	'');
INSERT INTO ACT_SAB
	VALUES (498,
	374,
	497);
INSERT INTO ACT_ACT
	VALUES (498,
	'state',
	0,
	499,
	0,
	0,
	'TestCase1::idle',
	0);
INSERT INTO ACT_BLK
	VALUES (499,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	498,
	0);
INSERT INTO SM_STATE
	VALUES (500,
	374,
	0,
	'delaying',
	2,
	0);
INSERT INTO SM_CH
	VALUES (500,
	373,
	374,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (500,
	373,
	374,
	0);
INSERT INTO SM_SEME
	VALUES (500,
	472,
	374,
	0);
INSERT INTO SM_MOAH
	VALUES (501,
	374,
	500);
INSERT INTO SM_AH
	VALUES (501,
	374);
INSERT INTO SM_ACT
	VALUES (501,
	374,
	1,
	'create event instance step of TestCase16:step() to self;
timer = TIM::timer_start(microseconds: 3000000, event_inst: step);',
	'');
INSERT INTO ACT_SAB
	VALUES (502,
	374,
	501);
INSERT INTO ACT_ACT
	VALUES (502,
	'state',
	0,
	503,
	0,
	0,
	'TestCase1::delaying',
	0);
INSERT INTO ACT_BLK
	VALUES (503,
	0,
	0,
	0,
	'TIM',
	'',
	'',
	2,
	1,
	2,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	502,
	0);
INSERT INTO ACT_SMT
	VALUES (504,
	503,
	505,
	1,
	1,
	'TestCase1::delaying line: 1');
INSERT INTO E_ESS
	VALUES (504,
	1,
	0,
	1,
	31,
	1,
	42,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (504,
	1,
	506);
INSERT INTO E_CSME
	VALUES (504,
	472,
	374);
INSERT INTO E_CEI
	VALUES (504,
	507);
INSERT INTO ACT_SMT
	VALUES (505,
	503,
	0,
	2,
	1,
	'TestCase1::delaying line: 2');
INSERT INTO ACT_AI
	VALUES (505,
	508,
	509,
	0,
	0);
INSERT INTO V_VAL
	VALUES (509,
	1,
	1,
	2,
	1,
	5,
	0,
	0,
	0,
	0,
	18,
	503);
INSERT INTO V_TVL
	VALUES (509,
	510);
INSERT INTO V_VAL
	VALUES (508,
	0,
	0,
	2,
	14,
	-1,
	2,
	26,
	2,
	49,
	18,
	503);
INSERT INTO V_BRV
	VALUES (508,
	414,
	1,
	2,
	9);
INSERT INTO V_VAL
	VALUES (511,
	0,
	0,
	2,
	40,
	46,
	0,
	0,
	0,
	0,
	5,
	503);
INSERT INTO V_LIN
	VALUES (511,
	'3000000');
INSERT INTO V_PAR
	VALUES (511,
	0,
	508,
	'microseconds',
	512,
	2,
	26);
INSERT INTO V_VAL
	VALUES (512,
	0,
	0,
	2,
	61,
	64,
	0,
	0,
	0,
	0,
	13,
	503);
INSERT INTO V_TVL
	VALUES (512,
	506);
INSERT INTO V_PAR
	VALUES (512,
	0,
	508,
	'event_inst',
	0,
	2,
	49);
INSERT INTO V_VAR
	VALUES (506,
	503,
	'step',
	1,
	13);
INSERT INTO V_TRN
	VALUES (506,
	0,
	'');
INSERT INTO V_LOC
	VALUES (513,
	1,
	23,
	26,
	506);
INSERT INTO V_LOC
	VALUES (514,
	2,
	61,
	64,
	506);
INSERT INTO V_VAR
	VALUES (507,
	503,
	'self',
	1,
	11);
INSERT INTO V_INT
	VALUES (507,
	0,
	372);
INSERT INTO V_LOC
	VALUES (515,
	1,
	52,
	55,
	507);
INSERT INTO V_VAR
	VALUES (510,
	503,
	'timer',
	1,
	18);
INSERT INTO V_TRN
	VALUES (510,
	0,
	'');
INSERT INTO V_LOC
	VALUES (516,
	2,
	1,
	5,
	510);
INSERT INTO SM_NSTXN
	VALUES (517,
	374,
	473,
	472,
	0);
INSERT INTO SM_TAH
	VALUES (518,
	374,
	517);
INSERT INTO SM_AH
	VALUES (518,
	374);
INSERT INTO SM_ACT
	VALUES (518,
	374,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (519,
	374,
	518);
INSERT INTO ACT_ACT
	VALUES (519,
	'transition',
	0,
	520,
	0,
	0,
	'TestCase16: step in sendLineDetected to final',
	0);
INSERT INTO ACT_BLK
	VALUES (520,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	519,
	0);
INSERT INTO SM_TXN
	VALUES (517,
	374,
	491,
	0);
INSERT INTO SM_NSTXN
	VALUES (521,
	374,
	500,
	472,
	0);
INSERT INTO SM_TAH
	VALUES (522,
	374,
	521);
INSERT INTO SM_AH
	VALUES (522,
	374);
INSERT INTO SM_ACT
	VALUES (522,
	374,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (523,
	374,
	522);
INSERT INTO ACT_ACT
	VALUES (523,
	'transition',
	0,
	524,
	0,
	0,
	'TestCase16: step in delaying to sendLineDetected',
	0);
INSERT INTO ACT_BLK
	VALUES (524,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	523,
	0);
INSERT INTO SM_TXN
	VALUES (521,
	374,
	473,
	0);
INSERT INTO SM_NSTXN
	VALUES (525,
	374,
	496,
	373,
	0);
INSERT INTO SM_TAH
	VALUES (526,
	374,
	525);
INSERT INTO SM_AH
	VALUES (526,
	374);
INSERT INTO SM_ACT
	VALUES (526,
	374,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (527,
	374,
	526);
INSERT INTO ACT_ACT
	VALUES (527,
	'transition',
	0,
	528,
	0,
	0,
	'TestCase18: setName in idle to delaying',
	0);
INSERT INTO ACT_BLK
	VALUES (528,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	527,
	0);
INSERT INTO SM_TXN
	VALUES (525,
	374,
	500,
	0);
INSERT INTO S_DIS
	VALUES (389,
	529);
INSERT INTO S_DT
	VALUES (529,
	0,
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES (529,
	0);
INSERT INTO S_DIS
	VALUES (389,
	530);
INSERT INTO S_DT
	VALUES (530,
	0,
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES (530,
	1);
INSERT INTO S_DIS
	VALUES (389,
	531);
INSERT INTO S_DT
	VALUES (531,
	0,
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES (531,
	2);
INSERT INTO S_DIS
	VALUES (389,
	532);
INSERT INTO S_DT
	VALUES (532,
	0,
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES (532,
	3);
INSERT INTO S_DIS
	VALUES (389,
	533);
INSERT INTO S_DT
	VALUES (533,
	0,
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES (533,
	4);
INSERT INTO S_DIS
	VALUES (389,
	534);
INSERT INTO S_DT
	VALUES (534,
	0,
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES (534,
	5);
INSERT INTO S_DIS
	VALUES (389,
	535);
INSERT INTO S_DT
	VALUES (535,
	0,
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (535,
	6);
INSERT INTO S_DIS
	VALUES (389,
	536);
INSERT INTO S_DT
	VALUES (536,
	0,
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (536,
	7);
INSERT INTO S_DIS
	VALUES (389,
	537);
INSERT INTO S_DT
	VALUES (537,
	0,
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (537,
	8);
INSERT INTO S_DIS
	VALUES (389,
	538);
INSERT INTO S_DT
	VALUES (538,
	0,
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (538,
	9);
INSERT INTO S_DIS
	VALUES (389,
	539);
INSERT INTO S_DT
	VALUES (539,
	0,
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (539,
	10);
INSERT INTO S_DIS
	VALUES (389,
	540);
INSERT INTO S_DT
	VALUES (540,
	0,
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (540,
	11);
INSERT INTO S_DIS
	VALUES (389,
	541);
INSERT INTO S_DT
	VALUES (541,
	0,
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (541,
	12);
INSERT INTO S_DIS
	VALUES (389,
	542);
INSERT INTO S_DT
	VALUES (542,
	0,
	'date',
	'Time as known in the external world. For example, 12 October 1492,
13:25:10. The accuracy of external time is dependent on the architecture and
implementation.',
	'');
INSERT INTO S_UDT
	VALUES (542,
	540,
	1);
INSERT INTO S_DIS
	VALUES (389,
	543);
INSERT INTO S_DT
	VALUES (543,
	0,
	'timestamp',
	' The system clock counts time in ticks. The size of a tick is dependent on the
 architecture and implementation.',
	'');
INSERT INTO S_UDT
	VALUES (543,
	540,
	2);
INSERT INTO S_DIS
	VALUES (389,
	544);
INSERT INTO S_DT
	VALUES (544,
	0,
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES (544,
	541,
	3);
INSERT INTO C_C
	VALUES (545,
	29,
	0,
	'sumo',
	'',
	0,
	29);
INSERT INTO C_PO
	VALUES (546,
	545,
	'IO',
	0,
	0);
INSERT INTO C_IR
	VALUES (547,
	33,
	0,
	546);
INSERT INTO C_R
	VALUES (547,
	'platform',
	'',
	'Unnamed Interface');
INSERT INTO SPR_REP
	VALUES (548,
	89,
	547);
INSERT INTO SPR_RO
	VALUES (548,
	'lineDetected',
	'',
	'// The constant below is the threshold for the light sensor.
//if (param.brightness < 700)
//   select any n from instances of N;
//   generate N2:line() to n;
// end if;



  select any n from instances of navigate;
  generate navigate2:line() to n;
',
	1);
INSERT INTO ACT_ROB
	VALUES (549,
	548);
INSERT INTO ACT_ACT
	VALUES (549,
	'interface operation',
	0,
	550,
	0,
	0,
	'IO::platform::lineDetected',
	0);
INSERT INTO ACT_BLK
	VALUES (550,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	9,
	3,
	8,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	549,
	0);
INSERT INTO ACT_SMT
	VALUES (551,
	550,
	552,
	8,
	3,
	'IO::platform::lineDetected line: 8');
INSERT INTO ACT_FIO
	VALUES (551,
	553,
	1,
	'any',
	554,
	8,
	34);
INSERT INTO ACT_SMT
	VALUES (552,
	550,
	0,
	9,
	3,
	'IO::platform::lineDetected line: 9');
INSERT INTO E_ESS
	VALUES (552,
	1,
	0,
	9,
	12,
	9,
	22,
	8,
	34,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (552);
INSERT INTO E_GSME
	VALUES (552,
	555,
	556);
INSERT INTO E_GEN
	VALUES (552,
	553);
INSERT INTO V_VAR
	VALUES (553,
	550,
	'n',
	1,
	11);
INSERT INTO V_INT
	VALUES (553,
	0,
	554);
INSERT INTO V_LOC
	VALUES (557,
	8,
	14,
	14,
	553);
INSERT INTO V_LOC
	VALUES (558,
	9,
	32,
	32,
	553);
INSERT INTO SPR_REP
	VALUES (559,
	93,
	547);
INSERT INTO SPR_RO
	VALUES (559,
	'touchLeft',
	'',
	'// Do something when the touch sensor on input one is activated.

select any n from instances of navigate;
generate navigate3:''leftBumper''() to n;
',
	1);
INSERT INTO ACT_ROB
	VALUES (560,
	559);
INSERT INTO ACT_ACT
	VALUES (560,
	'interface operation',
	0,
	561,
	0,
	0,
	'IO::platform::touchLeft',
	0);
INSERT INTO ACT_BLK
	VALUES (561,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	1,
	3,
	32,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	560,
	0);
INSERT INTO ACT_SMT
	VALUES (562,
	561,
	563,
	3,
	1,
	'IO::platform::touchLeft line: 3');
INSERT INTO ACT_FIO
	VALUES (562,
	564,
	1,
	'any',
	554,
	3,
	32);
INSERT INTO ACT_SMT
	VALUES (563,
	561,
	0,
	4,
	1,
	'IO::platform::touchLeft line: 4');
INSERT INTO E_ESS
	VALUES (563,
	1,
	0,
	4,
	10,
	4,
	20,
	3,
	32,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (563);
INSERT INTO E_GSME
	VALUES (563,
	565,
	556);
INSERT INTO E_GEN
	VALUES (563,
	564);
INSERT INTO V_VAR
	VALUES (564,
	561,
	'n',
	1,
	11);
INSERT INTO V_INT
	VALUES (564,
	0,
	554);
INSERT INTO V_LOC
	VALUES (566,
	3,
	12,
	12,
	564);
INSERT INTO V_LOC
	VALUES (567,
	4,
	38,
	38,
	564);
INSERT INTO SPR_REP
	VALUES (568,
	97,
	547);
INSERT INTO SPR_RO
	VALUES (568,
	'init',
	'',
	'create object instance n of navigate;
create object instance d of drive;
create object instance s of steering;

relate n to s across R1;
relate n to d across R2;

d.speed = 255;

n.retreat_duration = 1;
n.target_duration = 1;

generate navigate1:pop() to n;

send IO::setName(name: "Model");',
	1);
INSERT INTO ACT_ROB
	VALUES (569,
	568);
INSERT INTO ACT_ACT
	VALUES (569,
	'interface operation',
	0,
	570,
	0,
	0,
	'IO::platform::init',
	0);
INSERT INTO ACT_BLK
	VALUES (570,
	0,
	0,
	0,
	'IO',
	'',
	'',
	15,
	1,
	15,
	6,
	0,
	0,
	6,
	22,
	0,
	0,
	0,
	0,
	0,
	569,
	0);
INSERT INTO ACT_SMT
	VALUES (571,
	570,
	572,
	1,
	1,
	'IO::platform::init line: 1');
INSERT INTO ACT_CR
	VALUES (571,
	573,
	1,
	554,
	1,
	29);
INSERT INTO ACT_SMT
	VALUES (572,
	570,
	574,
	2,
	1,
	'IO::platform::init line: 2');
INSERT INTO ACT_CR
	VALUES (572,
	575,
	1,
	576,
	2,
	29);
INSERT INTO ACT_SMT
	VALUES (574,
	570,
	577,
	3,
	1,
	'IO::platform::init line: 3');
INSERT INTO ACT_CR
	VALUES (574,
	578,
	1,
	579,
	3,
	29);
INSERT INTO ACT_SMT
	VALUES (577,
	570,
	580,
	5,
	1,
	'IO::platform::init line: 5');
INSERT INTO ACT_REL
	VALUES (577,
	573,
	578,
	'',
	581,
	5,
	22,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (580,
	570,
	582,
	6,
	1,
	'IO::platform::init line: 6');
INSERT INTO ACT_REL
	VALUES (580,
	573,
	575,
	'',
	583,
	6,
	22,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (582,
	570,
	584,
	8,
	1,
	'IO::platform::init line: 8');
INSERT INTO ACT_AI
	VALUES (582,
	585,
	586,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (584,
	570,
	587,
	10,
	1,
	'IO::platform::init line: 10');
INSERT INTO ACT_AI
	VALUES (584,
	588,
	589,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (587,
	570,
	590,
	11,
	1,
	'IO::platform::init line: 11');
INSERT INTO ACT_AI
	VALUES (587,
	591,
	592,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (590,
	570,
	593,
	13,
	1,
	'IO::platform::init line: 13');
INSERT INTO E_ESS
	VALUES (590,
	1,
	0,
	13,
	10,
	13,
	20,
	3,
	29,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (590);
INSERT INTO E_GSME
	VALUES (590,
	594,
	556);
INSERT INTO E_GEN
	VALUES (590,
	573);
INSERT INTO ACT_SMT
	VALUES (593,
	570,
	0,
	15,
	1,
	'IO::platform::init line: 15');
INSERT INTO ACT_SGN
	VALUES (593,
	0,
	595,
	15,
	10,
	15,
	6);
INSERT INTO V_VAL
	VALUES (596,
	1,
	0,
	8,
	1,
	1,
	0,
	0,
	0,
	0,
	11,
	570);
INSERT INTO V_IRF
	VALUES (596,
	575);
INSERT INTO V_VAL
	VALUES (586,
	1,
	0,
	8,
	3,
	7,
	0,
	0,
	0,
	0,
	5,
	570);
INSERT INTO V_AVL
	VALUES (586,
	596,
	576,
	597);
INSERT INTO V_VAL
	VALUES (585,
	0,
	0,
	8,
	11,
	13,
	0,
	0,
	0,
	0,
	5,
	570);
INSERT INTO V_LIN
	VALUES (585,
	'255');
INSERT INTO V_VAL
	VALUES (598,
	1,
	0,
	10,
	1,
	1,
	0,
	0,
	0,
	0,
	11,
	570);
INSERT INTO V_IRF
	VALUES (598,
	573);
INSERT INTO V_VAL
	VALUES (589,
	1,
	0,
	10,
	3,
	18,
	0,
	0,
	0,
	0,
	5,
	570);
INSERT INTO V_AVL
	VALUES (589,
	598,
	554,
	599);
INSERT INTO V_VAL
	VALUES (588,
	0,
	0,
	10,
	22,
	22,
	0,
	0,
	0,
	0,
	5,
	570);
INSERT INTO V_LIN
	VALUES (588,
	'1');
INSERT INTO V_VAL
	VALUES (600,
	1,
	0,
	11,
	1,
	1,
	0,
	0,
	0,
	0,
	11,
	570);
INSERT INTO V_IRF
	VALUES (600,
	573);
INSERT INTO V_VAL
	VALUES (592,
	1,
	0,
	11,
	3,
	17,
	0,
	0,
	0,
	0,
	5,
	570);
INSERT INTO V_AVL
	VALUES (592,
	600,
	554,
	601);
INSERT INTO V_VAL
	VALUES (591,
	0,
	0,
	11,
	21,
	21,
	0,
	0,
	0,
	0,
	5,
	570);
INSERT INTO V_LIN
	VALUES (591,
	'1');
INSERT INTO V_VAL
	VALUES (602,
	0,
	0,
	15,
	24,
	29,
	0,
	0,
	0,
	0,
	7,
	570);
INSERT INTO V_LST
	VALUES (602,
	'Model');
INSERT INTO V_PAR
	VALUES (602,
	593,
	0,
	'name',
	0,
	15,
	18);
INSERT INTO V_VAR
	VALUES (573,
	570,
	'n',
	1,
	11);
INSERT INTO V_INT
	VALUES (573,
	0,
	554);
INSERT INTO V_LOC
	VALUES (603,
	1,
	24,
	24,
	573);
INSERT INTO V_LOC
	VALUES (604,
	5,
	8,
	8,
	573);
INSERT INTO V_LOC
	VALUES (605,
	6,
	8,
	8,
	573);
INSERT INTO V_LOC
	VALUES (606,
	10,
	1,
	1,
	573);
INSERT INTO V_LOC
	VALUES (607,
	11,
	1,
	1,
	573);
INSERT INTO V_LOC
	VALUES (608,
	13,
	29,
	29,
	573);
INSERT INTO V_VAR
	VALUES (575,
	570,
	'd',
	1,
	11);
INSERT INTO V_INT
	VALUES (575,
	0,
	576);
INSERT INTO V_LOC
	VALUES (609,
	2,
	24,
	24,
	575);
INSERT INTO V_LOC
	VALUES (610,
	6,
	13,
	13,
	575);
INSERT INTO V_LOC
	VALUES (611,
	8,
	1,
	1,
	575);
INSERT INTO V_VAR
	VALUES (578,
	570,
	's',
	1,
	11);
INSERT INTO V_INT
	VALUES (578,
	0,
	579);
INSERT INTO V_LOC
	VALUES (612,
	3,
	24,
	24,
	578);
INSERT INTO V_LOC
	VALUES (613,
	5,
	13,
	13,
	578);
INSERT INTO SPR_REP
	VALUES (614,
	101,
	547);
INSERT INTO SPR_RO
	VALUES (614,
	'touchRight',
	'',
	'// Do something when the touch sensor on input one is activated.

select any n from instances of navigate;
generate navigate4:''rightBumper''() to n;
',
	1);
INSERT INTO ACT_ROB
	VALUES (615,
	614);
INSERT INTO ACT_ACT
	VALUES (615,
	'interface operation',
	0,
	616,
	0,
	0,
	'IO::platform::touchRight',
	0);
INSERT INTO ACT_BLK
	VALUES (616,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	1,
	3,
	32,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	615,
	0);
INSERT INTO ACT_SMT
	VALUES (617,
	616,
	618,
	3,
	1,
	'IO::platform::touchRight line: 3');
INSERT INTO ACT_FIO
	VALUES (617,
	619,
	1,
	'any',
	554,
	3,
	32);
INSERT INTO ACT_SMT
	VALUES (618,
	616,
	0,
	4,
	1,
	'IO::platform::touchRight line: 4');
INSERT INTO E_ESS
	VALUES (618,
	1,
	0,
	4,
	10,
	4,
	20,
	3,
	32,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (618);
INSERT INTO E_GSME
	VALUES (618,
	620,
	556);
INSERT INTO E_GEN
	VALUES (618,
	619);
INSERT INTO V_VAR
	VALUES (619,
	616,
	'n',
	1,
	11);
INSERT INTO V_INT
	VALUES (619,
	0,
	554);
INSERT INTO V_LOC
	VALUES (621,
	3,
	12,
	12,
	619);
INSERT INTO V_LOC
	VALUES (622,
	4,
	39,
	39,
	619);
INSERT INTO SPR_REP
	VALUES (623,
	35,
	547);
INSERT INTO SPR_RS
	VALUES (623,
	'go',
	'',
	'',
	1);
INSERT INTO ACT_RSB
	VALUES (624,
	623);
INSERT INTO ACT_ACT
	VALUES (624,
	'signal',
	0,
	625,
	0,
	0,
	'IO::platform::go',
	0);
INSERT INTO ACT_BLK
	VALUES (625,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	624,
	0);
INSERT INTO SPR_REP
	VALUES (626,
	51,
	547);
INSERT INTO SPR_RS
	VALUES (626,
	'turn',
	'd = SumoSimulatorProxy::orientation2int(orientation: param.orientation);
SumoSimBridge::turn(orientation: d);',
	'',
	1);
INSERT INTO ACT_RSB
	VALUES (627,
	626);
INSERT INTO ACT_ACT
	VALUES (627,
	'signal',
	0,
	628,
	0,
	0,
	'IO::platform::turn',
	0);
INSERT INTO ACT_BLK
	VALUES (628,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	627,
	0);
INSERT INTO SPR_REP
	VALUES (595,
	67,
	547);
INSERT INTO SPR_RS
	VALUES (595,
	'setName',
	'',
	'',
	1);
INSERT INTO ACT_RSB
	VALUES (629,
	595);
INSERT INTO ACT_ACT
	VALUES (629,
	'signal',
	0,
	630,
	0,
	0,
	'IO::platform::setName',
	0);
INSERT INTO ACT_BLK
	VALUES (630,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	629,
	0);
INSERT INTO CN_DC
	VALUES (545,
	631);
INSERT INTO S_DOM
	VALUES (631,
	'sumo',
	'',
	0,
	632,
	0);
INSERT INTO S_DPK
	VALUES (633,
	'Datatypes',
	631,
	0);
INSERT INTO EP_SPKG
	VALUES (633,
	0);
INSERT INTO S_EEPK
	VALUES (634,
	'External Entities',
	631,
	0);
INSERT INTO PL_EEPID
	VALUES (631,
	634);
INSERT INTO S_EEIP
	VALUES (634,
	635);
INSERT INTO S_EE
	VALUES (635,
	'Time',
	'',
	'TIM',
	631);
INSERT INTO S_BRG
	VALUES (636,
	635,
	'current_date',
	'',
	1,
	17,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (637,
	635,
	'create_date',
	'',
	1,
	17,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (638,
	637,
	'second',
	5,
	0,
	'',
	639,
	'');
INSERT INTO S_BPARM
	VALUES (640,
	637,
	'minute',
	5,
	0,
	'',
	641,
	'');
INSERT INTO S_BPARM
	VALUES (641,
	637,
	'hour',
	5,
	0,
	'',
	642,
	'');
INSERT INTO S_BPARM
	VALUES (642,
	637,
	'day',
	5,
	0,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (639,
	637,
	'month',
	5,
	0,
	'',
	640,
	'');
INSERT INTO S_BPARM
	VALUES (643,
	637,
	'year',
	5,
	0,
	'',
	638,
	'');
INSERT INTO S_BRG
	VALUES (644,
	635,
	'get_second',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (645,
	644,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (646,
	635,
	'get_minute',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (647,
	646,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (648,
	635,
	'get_hour',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (649,
	648,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (650,
	635,
	'get_day',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (651,
	650,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (652,
	635,
	'get_month',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (653,
	652,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (654,
	635,
	'get_year',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (655,
	654,
	'date',
	17,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (656,
	635,
	'current_clock',
	'',
	1,
	19,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (657,
	635,
	'timer_start',
	'',
	1,
	18,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (658,
	657,
	'microseconds',
	5,
	0,
	'',
	659,
	'');
INSERT INTO S_BPARM
	VALUES (659,
	657,
	'event_inst',
	13,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (660,
	635,
	'timer_start_recurring',
	'',
	1,
	18,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (661,
	660,
	'microseconds',
	5,
	0,
	'',
	662,
	'');
INSERT INTO S_BPARM
	VALUES (662,
	660,
	'event_inst',
	13,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (663,
	635,
	'timer_remaining_time',
	'',
	1,
	5,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (664,
	663,
	'timer_inst_ref',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (665,
	635,
	'timer_reset_time',
	'',
	1,
	4,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (666,
	665,
	'timer_inst_ref',
	18,
	0,
	'',
	667,
	'');
INSERT INTO S_BPARM
	VALUES (667,
	665,
	'microseconds',
	5,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (668,
	635,
	'timer_add_time',
	'',
	1,
	4,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (669,
	668,
	'timer_inst_ref',
	18,
	0,
	'',
	670,
	'');
INSERT INTO S_BPARM
	VALUES (670,
	668,
	'microseconds',
	5,
	0,
	'',
	0,
	'');
INSERT INTO S_BRG
	VALUES (671,
	635,
	'timer_cancel',
	'',
	1,
	4,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (672,
	671,
	'timer_inst_ref',
	18,
	0,
	'',
	0,
	'');
INSERT INTO S_FPK
	VALUES (673,
	'Functions',
	631,
	0);
INSERT INTO PL_FPID
	VALUES (673,
	631);
INSERT INTO S_FIP
	VALUES (673,
	674);
INSERT INTO S_SYNC
	VALUES (674,
	631,
	'test',
	'',
	'select any n from instances of navigate;
generate navigate2:line() to n;',
	3,
	1,
	'');
INSERT INTO ACT_FNB
	VALUES (675,
	674);
INSERT INTO ACT_ACT
	VALUES (675,
	'function',
	0,
	676,
	0,
	0,
	'test',
	0);
INSERT INTO ACT_BLK
	VALUES (676,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	1,
	32,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	675,
	0);
INSERT INTO ACT_SMT
	VALUES (677,
	676,
	678,
	1,
	1,
	'test line: 1');
INSERT INTO ACT_FIO
	VALUES (677,
	679,
	1,
	'any',
	554,
	1,
	32);
INSERT INTO ACT_SMT
	VALUES (678,
	676,
	0,
	2,
	1,
	'test line: 2');
INSERT INTO E_ESS
	VALUES (678,
	1,
	0,
	2,
	10,
	2,
	20,
	1,
	32,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (678);
INSERT INTO E_GSME
	VALUES (678,
	555,
	556);
INSERT INTO E_GEN
	VALUES (678,
	679);
INSERT INTO V_VAR
	VALUES (679,
	676,
	'n',
	1,
	11);
INSERT INTO V_INT
	VALUES (679,
	0,
	554);
INSERT INTO V_LOC
	VALUES (680,
	1,
	12,
	12,
	679);
INSERT INTO V_LOC
	VALUES (681,
	2,
	30,
	30,
	679);
INSERT INTO S_SID
	VALUES (631,
	682);
INSERT INTO S_SS
	VALUES (682,
	'sumo',
	'',
	'',
	1,
	631,
	683);
INSERT INTO O_OBJ
	VALUES (576,
	'drive',
	2,
	'drive',
	'',
	682);
INSERT INTO O_TFR
	VALUES (684,
	576,
	'forward',
	'',
	3,
	1,
	'//self.direction = Direction::forward;
send IO::go(direction: Direction::forward);',
	1,
	'',
	0);
INSERT INTO ACT_OPB
	VALUES (685,
	684);
INSERT INTO ACT_ACT
	VALUES (685,
	'operation',
	0,
	686,
	0,
	0,
	'drive::forward',
	0);
INSERT INTO ACT_BLK
	VALUES (686,
	0,
	0,
	0,
	'IO',
	'',
	'',
	2,
	1,
	2,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	2,
	24,
	0,
	685,
	0);
INSERT INTO ACT_SMT
	VALUES (687,
	686,
	0,
	2,
	1,
	'drive::forward line: 2');
INSERT INTO ACT_SGN
	VALUES (687,
	0,
	623,
	2,
	10,
	2,
	6);
INSERT INTO V_VAL
	VALUES (688,
	0,
	0,
	2,
	35,
	41,
	0,
	0,
	0,
	0,
	21,
	686);
INSERT INTO V_LEN
	VALUES (688,
	22,
	2,
	24);
INSERT INTO V_PAR
	VALUES (688,
	687,
	0,
	'direction',
	0,
	2,
	13);
INSERT INTO O_TFR
	VALUES (689,
	576,
	'reverse',
	'',
	3,
	1,
	'//self.direction = Direction::backward;
send IO::go(direction: Direction::backward);',
	1,
	'',
	684);
INSERT INTO ACT_OPB
	VALUES (690,
	689);
INSERT INTO ACT_ACT
	VALUES (690,
	'operation',
	0,
	691,
	0,
	0,
	'drive::reverse',
	0);
INSERT INTO ACT_BLK
	VALUES (691,
	0,
	0,
	0,
	'IO',
	'',
	'',
	2,
	1,
	2,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	2,
	24,
	0,
	690,
	0);
INSERT INTO ACT_SMT
	VALUES (692,
	691,
	0,
	2,
	1,
	'drive::reverse line: 2');
INSERT INTO ACT_SGN
	VALUES (692,
	0,
	623,
	2,
	10,
	2,
	6);
INSERT INTO V_VAL
	VALUES (693,
	0,
	0,
	2,
	35,
	42,
	0,
	0,
	0,
	0,
	21,
	691);
INSERT INTO V_LEN
	VALUES (693,
	24,
	2,
	24);
INSERT INTO V_PAR
	VALUES (693,
	692,
	0,
	'direction',
	0,
	2,
	13);
INSERT INTO O_TFR
	VALUES (694,
	576,
	'stop',
	'',
	3,
	1,
	'send IO::go(direction: Direction::stop);',
	1,
	'',
	689);
INSERT INTO ACT_OPB
	VALUES (695,
	694);
INSERT INTO ACT_ACT
	VALUES (695,
	'operation',
	0,
	696,
	0,
	0,
	'drive::stop',
	0);
INSERT INTO ACT_BLK
	VALUES (696,
	0,
	0,
	0,
	'IO',
	'',
	'',
	1,
	1,
	1,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	24,
	0,
	695,
	0);
INSERT INTO ACT_SMT
	VALUES (697,
	696,
	0,
	1,
	1,
	'drive::stop line: 1');
INSERT INTO ACT_SGN
	VALUES (697,
	0,
	623,
	1,
	10,
	1,
	6);
INSERT INTO V_VAL
	VALUES (698,
	0,
	0,
	1,
	35,
	38,
	0,
	0,
	0,
	0,
	21,
	696);
INSERT INTO V_LEN
	VALUES (698,
	23,
	1,
	24);
INSERT INTO V_PAR
	VALUES (698,
	697,
	0,
	'direction',
	0,
	1,
	13);
INSERT INTO O_NBATTR
	VALUES (597,
	576);
INSERT INTO O_BATTR
	VALUES (597,
	576);
INSERT INTO O_ATTR
	VALUES (597,
	576,
	0,
	'speed',
	'',
	'',
	'speed',
	0,
	5,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	576);
INSERT INTO O_ID
	VALUES (1,
	576);
INSERT INTO O_ID
	VALUES (2,
	576);
INSERT INTO O_OBJ
	VALUES (554,
	'navigate',
	1,
	'navigate',
	'',
	682);
INSERT INTO O_NBATTR
	VALUES (599,
	554);
INSERT INTO O_BATTR
	VALUES (599,
	554);
INSERT INTO O_ATTR
	VALUES (599,
	554,
	0,
	'retreat_duration',
	'',
	'',
	'retreat_duration',
	0,
	5,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (601,
	554);
INSERT INTO O_BATTR
	VALUES (601,
	554);
INSERT INTO O_ATTR
	VALUES (601,
	554,
	599,
	'target_duration',
	'',
	'',
	'target_duration',
	0,
	5,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (699,
	554);
INSERT INTO O_BATTR
	VALUES (699,
	554);
INSERT INTO O_ATTR
	VALUES (699,
	554,
	601,
	'current_state',
	'',
	'',
	'current_state',
	0,
	9,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	554);
INSERT INTO O_ID
	VALUES (1,
	554);
INSERT INTO O_ID
	VALUES (2,
	554);
INSERT INTO SM_ISM
	VALUES (556,
	554);
INSERT INTO SM_SM
	VALUES (556,
	'',
	4);
INSERT INTO SM_MOORE
	VALUES (556);
INSERT INTO SM_LEVT
	VALUES (594,
	556,
	0);
INSERT INTO SM_SEVT
	VALUES (594,
	556,
	0);
INSERT INTO SM_EVT
	VALUES (594,
	556,
	0,
	1,
	'pop',
	0,
	'',
	'navigate1',
	'');
INSERT INTO SM_LEVT
	VALUES (555,
	556,
	0);
INSERT INTO SM_SEVT
	VALUES (555,
	556,
	0);
INSERT INTO SM_EVT
	VALUES (555,
	556,
	0,
	2,
	'line',
	0,
	'',
	'navigate2',
	'');
INSERT INTO SM_LEVT
	VALUES (565,
	556,
	0);
INSERT INTO SM_SEVT
	VALUES (565,
	556,
	0);
INSERT INTO SM_EVT
	VALUES (565,
	556,
	0,
	3,
	'leftBumper',
	0,
	'',
	'navigate3',
	'');
INSERT INTO SM_LEVT
	VALUES (620,
	556,
	0);
INSERT INTO SM_SEVT
	VALUES (620,
	556,
	0);
INSERT INTO SM_EVT
	VALUES (620,
	556,
	0,
	4,
	'rightBumper',
	0,
	'',
	'navigate4',
	'');
INSERT INTO SM_STATE
	VALUES (700,
	556,
	0,
	'resting',
	1,
	0);
INSERT INTO SM_SEME
	VALUES (700,
	594,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (700,
	555,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (700,
	555,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (700,
	565,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (700,
	565,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (700,
	620,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (700,
	620,
	556,
	0);
INSERT INTO SM_MOAH
	VALUES (701,
	556,
	700);
INSERT INTO SM_AH
	VALUES (701,
	556);
INSERT INTO SM_ACT
	VALUES (701,
	556,
	0,
	'//
',
	'');
INSERT INTO SM_STATE
	VALUES (702,
	556,
	0,
	'attacking',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES (702,
	594,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (702,
	594,
	556,
	0);
INSERT INTO SM_SEME
	VALUES (702,
	555,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (702,
	565,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (702,
	565,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (702,
	620,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (702,
	620,
	556,
	0);
INSERT INTO SM_MOAH
	VALUES (703,
	556,
	702);
INSERT INTO SM_AH
	VALUES (703,
	556);
INSERT INTO SM_ACT
	VALUES (703,
	556,
	1,
	'select one s related by self->steering[R1];
generate steering3:straight() to s;
select one d related by self->drive[R2];
d.forward();
',
	'');
INSERT INTO ACT_SAB
	VALUES (704,
	556,
	703);
INSERT INTO ACT_ACT
	VALUES (704,
	'state',
	0,
	705,
	0,
	0,
	'navigate::attacking',
	0);
INSERT INTO ACT_BLK
	VALUES (705,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	4,
	1,
	3,
	31,
	0,
	0,
	3,
	37,
	0,
	0,
	0,
	0,
	0,
	704,
	0);
INSERT INTO ACT_SMT
	VALUES (706,
	705,
	707,
	1,
	1,
	'navigate::attacking line: 1');
INSERT INTO ACT_SEL
	VALUES (706,
	708,
	1,
	'one',
	709);
INSERT INTO ACT_SR
	VALUES (706);
INSERT INTO ACT_LNK
	VALUES (710,
	'',
	706,
	581,
	0,
	2,
	579,
	1,
	31,
	1,
	40,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (707,
	705,
	711,
	2,
	1,
	'navigate::attacking line: 2');
INSERT INTO E_ESS
	VALUES (707,
	1,
	0,
	2,
	10,
	2,
	20,
	1,
	31,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (707);
INSERT INTO E_GSME
	VALUES (707,
	712,
	713);
INSERT INTO E_GEN
	VALUES (707,
	708);
INSERT INTO ACT_SMT
	VALUES (711,
	705,
	714,
	3,
	1,
	'navigate::attacking line: 3');
INSERT INTO ACT_SEL
	VALUES (711,
	715,
	1,
	'one',
	716);
INSERT INTO ACT_SR
	VALUES (711);
INSERT INTO ACT_LNK
	VALUES (717,
	'',
	711,
	583,
	0,
	2,
	576,
	3,
	31,
	3,
	37,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (714,
	705,
	0,
	4,
	1,
	'navigate::attacking line: 4');
INSERT INTO ACT_TFM
	VALUES (714,
	684,
	715,
	4,
	3,
	0,
	0);
INSERT INTO V_VAL
	VALUES (709,
	0,
	0,
	1,
	25,
	28,
	0,
	0,
	0,
	0,
	11,
	705);
INSERT INTO V_IRF
	VALUES (709,
	718);
INSERT INTO V_VAL
	VALUES (716,
	0,
	0,
	3,
	25,
	28,
	0,
	0,
	0,
	0,
	11,
	705);
INSERT INTO V_IRF
	VALUES (716,
	718);
INSERT INTO V_VAR
	VALUES (708,
	705,
	's',
	1,
	11);
INSERT INTO V_INT
	VALUES (708,
	0,
	579);
INSERT INTO V_LOC
	VALUES (719,
	1,
	12,
	12,
	708);
INSERT INTO V_LOC
	VALUES (720,
	2,
	34,
	34,
	708);
INSERT INTO V_VAR
	VALUES (718,
	705,
	'self',
	1,
	11);
INSERT INTO V_INT
	VALUES (718,
	0,
	554);
INSERT INTO V_VAR
	VALUES (715,
	705,
	'd',
	1,
	11);
INSERT INTO V_INT
	VALUES (715,
	0,
	576);
INSERT INTO V_LOC
	VALUES (721,
	3,
	12,
	12,
	715);
INSERT INTO V_LOC
	VALUES (722,
	4,
	1,
	1,
	715);
INSERT INTO SM_STATE
	VALUES (723,
	556,
	0,
	'retreating',
	3,
	0);
INSERT INTO SM_SEME
	VALUES (723,
	594,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (723,
	555,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (723,
	555,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (723,
	565,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (723,
	565,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (723,
	620,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (723,
	620,
	556,
	0);
INSERT INTO SM_MOAH
	VALUES (724,
	556,
	723);
INSERT INTO SM_AH
	VALUES (724,
	556);
INSERT INTO SM_ACT
	VALUES (724,
	556,
	1,
	'select one s related by self->steering[R1];
generate steering3:straight() to s;
select one d related by self->drive[R2];
d.reverse();
create event instance e of navigate1:pop() to self;
t = TIM::timer_start( microseconds:self.retreat_duration * 1000000, event_inst:e );',
	'');
INSERT INTO ACT_SAB
	VALUES (725,
	556,
	724);
INSERT INTO ACT_ACT
	VALUES (725,
	'state',
	0,
	726,
	0,
	0,
	'navigate::retreating',
	0);
INSERT INTO ACT_BLK
	VALUES (726,
	1,
	0,
	0,
	'TIM',
	'',
	'',
	6,
	1,
	6,
	5,
	0,
	0,
	3,
	37,
	0,
	0,
	0,
	0,
	0,
	725,
	0);
INSERT INTO ACT_SMT
	VALUES (727,
	726,
	728,
	1,
	1,
	'navigate::retreating line: 1');
INSERT INTO ACT_SEL
	VALUES (727,
	729,
	1,
	'one',
	730);
INSERT INTO ACT_SR
	VALUES (727);
INSERT INTO ACT_LNK
	VALUES (731,
	'',
	727,
	581,
	0,
	2,
	579,
	1,
	31,
	1,
	40,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (728,
	726,
	732,
	2,
	1,
	'navigate::retreating line: 2');
INSERT INTO E_ESS
	VALUES (728,
	1,
	0,
	2,
	10,
	2,
	20,
	1,
	31,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (728);
INSERT INTO E_GSME
	VALUES (728,
	712,
	713);
INSERT INTO E_GEN
	VALUES (728,
	729);
INSERT INTO ACT_SMT
	VALUES (732,
	726,
	733,
	3,
	1,
	'navigate::retreating line: 3');
INSERT INTO ACT_SEL
	VALUES (732,
	734,
	1,
	'one',
	735);
INSERT INTO ACT_SR
	VALUES (732);
INSERT INTO ACT_LNK
	VALUES (736,
	'',
	732,
	583,
	0,
	2,
	576,
	3,
	31,
	3,
	37,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (733,
	726,
	737,
	4,
	1,
	'navigate::retreating line: 4');
INSERT INTO ACT_TFM
	VALUES (733,
	689,
	734,
	4,
	3,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (737,
	726,
	738,
	5,
	1,
	'navigate::retreating line: 5');
INSERT INTO E_ESS
	VALUES (737,
	1,
	0,
	5,
	28,
	5,
	38,
	3,
	31,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (737,
	1,
	739);
INSERT INTO E_CSME
	VALUES (737,
	594,
	556);
INSERT INTO E_CEI
	VALUES (737,
	740);
INSERT INTO ACT_SMT
	VALUES (738,
	726,
	0,
	6,
	1,
	'navigate::retreating line: 6');
INSERT INTO ACT_AI
	VALUES (738,
	741,
	742,
	0,
	0);
INSERT INTO V_VAL
	VALUES (730,
	0,
	0,
	1,
	25,
	28,
	0,
	0,
	0,
	0,
	11,
	726);
INSERT INTO V_IRF
	VALUES (730,
	740);
INSERT INTO V_VAL
	VALUES (735,
	0,
	0,
	3,
	25,
	28,
	0,
	0,
	0,
	0,
	11,
	726);
INSERT INTO V_IRF
	VALUES (735,
	740);
INSERT INTO V_VAL
	VALUES (742,
	1,
	1,
	6,
	1,
	1,
	0,
	0,
	0,
	0,
	18,
	726);
INSERT INTO V_TVL
	VALUES (742,
	743);
INSERT INTO V_VAL
	VALUES (741,
	0,
	0,
	6,
	10,
	-1,
	6,
	23,
	6,
	69,
	18,
	726);
INSERT INTO V_BRV
	VALUES (741,
	657,
	1,
	6,
	5);
INSERT INTO V_VAL
	VALUES (744,
	0,
	0,
	6,
	36,
	39,
	0,
	0,
	0,
	0,
	11,
	726);
INSERT INTO V_IRF
	VALUES (744,
	740);
INSERT INTO V_VAL
	VALUES (745,
	0,
	0,
	6,
	41,
	56,
	0,
	0,
	0,
	0,
	5,
	726);
INSERT INTO V_AVL
	VALUES (745,
	744,
	554,
	599);
INSERT INTO V_VAL
	VALUES (746,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	5,
	726);
INSERT INTO V_BIN
	VALUES (746,
	747,
	745,
	'*');
INSERT INTO V_PAR
	VALUES (746,
	0,
	741,
	'microseconds',
	748,
	6,
	23);
INSERT INTO V_VAL
	VALUES (747,
	0,
	0,
	6,
	60,
	66,
	0,
	0,
	0,
	0,
	5,
	726);
INSERT INTO V_LIN
	VALUES (747,
	'1000000');
INSERT INTO V_VAL
	VALUES (748,
	0,
	0,
	6,
	80,
	80,
	0,
	0,
	0,
	0,
	13,
	726);
INSERT INTO V_TVL
	VALUES (748,
	739);
INSERT INTO V_PAR
	VALUES (748,
	0,
	741,
	'event_inst',
	0,
	6,
	69);
INSERT INTO V_VAR
	VALUES (729,
	726,
	's',
	1,
	11);
INSERT INTO V_INT
	VALUES (729,
	0,
	579);
INSERT INTO V_LOC
	VALUES (749,
	1,
	12,
	12,
	729);
INSERT INTO V_LOC
	VALUES (750,
	2,
	34,
	34,
	729);
INSERT INTO V_VAR
	VALUES (740,
	726,
	'self',
	1,
	11);
INSERT INTO V_INT
	VALUES (740,
	0,
	554);
INSERT INTO V_LOC
	VALUES (751,
	5,
	47,
	50,
	740);
INSERT INTO V_LOC
	VALUES (752,
	6,
	36,
	39,
	740);
INSERT INTO V_VAR
	VALUES (734,
	726,
	'd',
	1,
	11);
INSERT INTO V_INT
	VALUES (734,
	0,
	576);
INSERT INTO V_LOC
	VALUES (753,
	3,
	12,
	12,
	734);
INSERT INTO V_LOC
	VALUES (754,
	4,
	1,
	1,
	734);
INSERT INTO V_VAR
	VALUES (739,
	726,
	'e',
	1,
	13);
INSERT INTO V_TRN
	VALUES (739,
	0,
	'');
INSERT INTO V_LOC
	VALUES (755,
	5,
	23,
	23,
	739);
INSERT INTO V_LOC
	VALUES (756,
	6,
	80,
	80,
	739);
INSERT INTO V_VAR
	VALUES (743,
	726,
	't',
	1,
	18);
INSERT INTO V_TRN
	VALUES (743,
	0,
	'');
INSERT INTO V_LOC
	VALUES (757,
	6,
	1,
	1,
	743);
INSERT INTO SM_STATE
	VALUES (758,
	556,
	0,
	'targeting',
	4,
	0);
INSERT INTO SM_SEME
	VALUES (758,
	594,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (758,
	555,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (758,
	555,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (758,
	565,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (758,
	565,
	556,
	0);
INSERT INTO SM_EIGN
	VALUES (758,
	620,
	556,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (758,
	620,
	556,
	0);
INSERT INTO SM_MOAH
	VALUES (759,
	556,
	758);
INSERT INTO SM_AH
	VALUES (759,
	556);
INSERT INTO SM_ACT
	VALUES (759,
	556,
	1,
	'select one d related by self->drive[R2];
d.stop();
select one s related by self->steering[R1];
generate steering1:left() to s;
create event instance e of navigate1:pop() to self;
t = TIM::timer_start( microseconds:5000000, event_inst:e );',
	'');
INSERT INTO ACT_SAB
	VALUES (760,
	556,
	759);
INSERT INTO ACT_ACT
	VALUES (760,
	'state',
	0,
	761,
	0,
	0,
	'navigate::targeting',
	0);
INSERT INTO ACT_BLK
	VALUES (761,
	1,
	0,
	0,
	'TIM',
	'',
	'',
	6,
	1,
	6,
	5,
	0,
	0,
	3,
	40,
	0,
	0,
	0,
	0,
	0,
	760,
	0);
INSERT INTO ACT_SMT
	VALUES (762,
	761,
	763,
	1,
	1,
	'navigate::targeting line: 1');
INSERT INTO ACT_SEL
	VALUES (762,
	764,
	1,
	'one',
	765);
INSERT INTO ACT_SR
	VALUES (762);
INSERT INTO ACT_LNK
	VALUES (766,
	'',
	762,
	583,
	0,
	2,
	576,
	1,
	31,
	1,
	37,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (763,
	761,
	767,
	2,
	1,
	'navigate::targeting line: 2');
INSERT INTO ACT_TFM
	VALUES (763,
	694,
	764,
	2,
	3,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (767,
	761,
	768,
	3,
	1,
	'navigate::targeting line: 3');
INSERT INTO ACT_SEL
	VALUES (767,
	769,
	1,
	'one',
	770);
INSERT INTO ACT_SR
	VALUES (767);
INSERT INTO ACT_LNK
	VALUES (771,
	'',
	767,
	581,
	0,
	2,
	579,
	3,
	31,
	3,
	40,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (768,
	761,
	772,
	4,
	1,
	'navigate::targeting line: 4');
INSERT INTO E_ESS
	VALUES (768,
	1,
	0,
	4,
	10,
	4,
	20,
	3,
	31,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (768);
INSERT INTO E_GSME
	VALUES (768,
	773,
	713);
INSERT INTO E_GEN
	VALUES (768,
	769);
INSERT INTO ACT_SMT
	VALUES (772,
	761,
	774,
	5,
	1,
	'navigate::targeting line: 5');
INSERT INTO E_ESS
	VALUES (772,
	1,
	0,
	5,
	28,
	5,
	38,
	3,
	31,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (772,
	1,
	775);
INSERT INTO E_CSME
	VALUES (772,
	594,
	556);
INSERT INTO E_CEI
	VALUES (772,
	776);
INSERT INTO ACT_SMT
	VALUES (774,
	761,
	0,
	6,
	1,
	'navigate::targeting line: 6');
INSERT INTO ACT_AI
	VALUES (774,
	777,
	778,
	0,
	0);
INSERT INTO V_VAL
	VALUES (765,
	0,
	0,
	1,
	25,
	28,
	0,
	0,
	0,
	0,
	11,
	761);
INSERT INTO V_IRF
	VALUES (765,
	776);
INSERT INTO V_VAL
	VALUES (770,
	0,
	0,
	3,
	25,
	28,
	0,
	0,
	0,
	0,
	11,
	761);
INSERT INTO V_IRF
	VALUES (770,
	776);
INSERT INTO V_VAL
	VALUES (778,
	1,
	1,
	6,
	1,
	1,
	0,
	0,
	0,
	0,
	18,
	761);
INSERT INTO V_TVL
	VALUES (778,
	779);
INSERT INTO V_VAL
	VALUES (777,
	0,
	0,
	6,
	10,
	-1,
	6,
	23,
	6,
	45,
	18,
	761);
INSERT INTO V_BRV
	VALUES (777,
	657,
	1,
	6,
	5);
INSERT INTO V_VAL
	VALUES (780,
	0,
	0,
	6,
	36,
	42,
	0,
	0,
	0,
	0,
	5,
	761);
INSERT INTO V_LIN
	VALUES (780,
	'5000000');
INSERT INTO V_PAR
	VALUES (780,
	0,
	777,
	'microseconds',
	781,
	6,
	23);
INSERT INTO V_VAL
	VALUES (781,
	0,
	0,
	6,
	56,
	56,
	0,
	0,
	0,
	0,
	13,
	761);
INSERT INTO V_TVL
	VALUES (781,
	775);
INSERT INTO V_PAR
	VALUES (781,
	0,
	777,
	'event_inst',
	0,
	6,
	45);
INSERT INTO V_VAR
	VALUES (764,
	761,
	'd',
	1,
	11);
INSERT INTO V_INT
	VALUES (764,
	0,
	576);
INSERT INTO V_LOC
	VALUES (782,
	1,
	12,
	12,
	764);
INSERT INTO V_LOC
	VALUES (783,
	2,
	1,
	1,
	764);
INSERT INTO V_VAR
	VALUES (776,
	761,
	'self',
	1,
	11);
INSERT INTO V_INT
	VALUES (776,
	0,
	554);
INSERT INTO V_LOC
	VALUES (784,
	5,
	47,
	50,
	776);
INSERT INTO V_VAR
	VALUES (769,
	761,
	's',
	1,
	11);
INSERT INTO V_INT
	VALUES (769,
	0,
	579);
INSERT INTO V_LOC
	VALUES (785,
	3,
	12,
	12,
	769);
INSERT INTO V_LOC
	VALUES (786,
	4,
	30,
	30,
	769);
INSERT INTO V_VAR
	VALUES (775,
	761,
	'e',
	1,
	13);
INSERT INTO V_TRN
	VALUES (775,
	0,
	'');
INSERT INTO V_LOC
	VALUES (787,
	5,
	23,
	23,
	775);
INSERT INTO V_LOC
	VALUES (788,
	6,
	56,
	56,
	775);
INSERT INTO V_VAR
	VALUES (779,
	761,
	't',
	1,
	18);
INSERT INTO V_TRN
	VALUES (779,
	0,
	'');
INSERT INTO V_LOC
	VALUES (789,
	6,
	1,
	1,
	779);
INSERT INTO SM_NSTXN
	VALUES (790,
	556,
	700,
	594,
	0);
INSERT INTO SM_TAH
	VALUES (791,
	556,
	790);
INSERT INTO SM_AH
	VALUES (791,
	556);
INSERT INTO SM_ACT
	VALUES (791,
	556,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (792,
	556,
	791);
INSERT INTO ACT_ACT
	VALUES (792,
	'transition',
	0,
	793,
	0,
	0,
	'navigate1: pop in resting to attacking',
	0);
INSERT INTO ACT_BLK
	VALUES (793,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	792,
	0);
INSERT INTO SM_TXN
	VALUES (790,
	556,
	702,
	0);
INSERT INTO SM_NSTXN
	VALUES (794,
	556,
	723,
	594,
	0);
INSERT INTO SM_TAH
	VALUES (795,
	556,
	794);
INSERT INTO SM_AH
	VALUES (795,
	556);
INSERT INTO SM_ACT
	VALUES (795,
	556,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (796,
	556,
	795);
INSERT INTO ACT_ACT
	VALUES (796,
	'transition',
	0,
	797,
	0,
	0,
	'navigate1: pop in retreating to targeting',
	0);
INSERT INTO ACT_BLK
	VALUES (797,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	796,
	0);
INSERT INTO SM_TXN
	VALUES (794,
	556,
	758,
	0);
INSERT INTO SM_NSTXN
	VALUES (798,
	556,
	758,
	594,
	0);
INSERT INTO SM_TAH
	VALUES (799,
	556,
	798);
INSERT INTO SM_AH
	VALUES (799,
	556);
INSERT INTO SM_ACT
	VALUES (799,
	556,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (800,
	556,
	799);
INSERT INTO ACT_ACT
	VALUES (800,
	'transition',
	0,
	801,
	0,
	0,
	'navigate1: pop in targeting to attacking',
	0);
INSERT INTO ACT_BLK
	VALUES (801,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	800,
	0);
INSERT INTO SM_TXN
	VALUES (798,
	556,
	702,
	0);
INSERT INTO SM_NSTXN
	VALUES (802,
	556,
	702,
	555,
	0);
INSERT INTO SM_TAH
	VALUES (803,
	556,
	802);
INSERT INTO SM_AH
	VALUES (803,
	556);
INSERT INTO SM_ACT
	VALUES (803,
	556,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (804,
	556,
	803);
INSERT INTO ACT_ACT
	VALUES (804,
	'transition',
	0,
	805,
	0,
	0,
	'navigate2: line in attacking to retreating',
	0);
INSERT INTO ACT_BLK
	VALUES (805,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	804,
	0);
INSERT INTO SM_TXN
	VALUES (802,
	556,
	723,
	0);
INSERT INTO O_OBJ
	VALUES (579,
	'steering',
	3,
	'steering',
	'',
	682);
INSERT INTO O_NBATTR
	VALUES (806,
	579);
INSERT INTO O_BATTR
	VALUES (806,
	579);
INSERT INTO O_ATTR
	VALUES (806,
	579,
	0,
	'current_state',
	'',
	'',
	'current_state',
	0,
	9,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	579);
INSERT INTO O_ID
	VALUES (1,
	579);
INSERT INTO O_ID
	VALUES (2,
	579);
INSERT INTO SM_ISM
	VALUES (713,
	579);
INSERT INTO SM_SM
	VALUES (713,
	'',
	5);
INSERT INTO SM_MOORE
	VALUES (713);
INSERT INTO SM_LEVT
	VALUES (773,
	713,
	0);
INSERT INTO SM_SEVT
	VALUES (773,
	713,
	0);
INSERT INTO SM_EVT
	VALUES (773,
	713,
	0,
	1,
	'left',
	0,
	'',
	'steering1',
	'');
INSERT INTO SM_LEVT
	VALUES (807,
	713,
	0);
INSERT INTO SM_SEVT
	VALUES (807,
	713,
	0);
INSERT INTO SM_EVT
	VALUES (807,
	713,
	0,
	2,
	'right',
	0,
	'',
	'steering2',
	'');
INSERT INTO SM_LEVT
	VALUES (712,
	713,
	0);
INSERT INTO SM_SEVT
	VALUES (712,
	713,
	0);
INSERT INTO SM_EVT
	VALUES (712,
	713,
	0,
	3,
	'straight',
	0,
	'',
	'steering3',
	'');
INSERT INTO SM_STATE
	VALUES (808,
	713,
	0,
	'maintaining',
	1,
	0);
INSERT INTO SM_SEME
	VALUES (808,
	773,
	713,
	0);
INSERT INTO SM_SEME
	VALUES (808,
	807,
	713,
	0);
INSERT INTO SM_EIGN
	VALUES (808,
	712,
	713,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (808,
	712,
	713,
	0);
INSERT INTO SM_MOAH
	VALUES (809,
	713,
	808);
INSERT INTO SM_AH
	VALUES (809,
	713);
INSERT INTO SM_ACT
	VALUES (809,
	713,
	1,
	'send IO::turn(orientation: Orientation::straight);',
	'');
INSERT INTO ACT_SAB
	VALUES (810,
	713,
	809);
INSERT INTO ACT_ACT
	VALUES (810,
	'state',
	0,
	811,
	0,
	0,
	'steering::maintaining',
	0);
INSERT INTO ACT_BLK
	VALUES (811,
	0,
	0,
	0,
	'IO',
	'',
	'',
	1,
	1,
	1,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	28,
	0,
	810,
	0);
INSERT INTO ACT_SMT
	VALUES (812,
	811,
	0,
	1,
	1,
	'steering::maintaining line: 1');
INSERT INTO ACT_SGN
	VALUES (812,
	0,
	626,
	1,
	10,
	1,
	6);
INSERT INTO V_VAL
	VALUES (813,
	0,
	0,
	1,
	41,
	48,
	0,
	0,
	0,
	0,
	25,
	811);
INSERT INTO V_LEN
	VALUES (813,
	28,
	1,
	28);
INSERT INTO V_PAR
	VALUES (813,
	812,
	0,
	'orientation',
	0,
	1,
	15);
INSERT INTO SM_STATE
	VALUES (814,
	713,
	0,
	'lefting',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES (814,
	773,
	713,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (814,
	773,
	713,
	0);
INSERT INTO SM_SEME
	VALUES (814,
	807,
	713,
	0);
INSERT INTO SM_SEME
	VALUES (814,
	712,
	713,
	0);
INSERT INTO SM_MOAH
	VALUES (815,
	713,
	814);
INSERT INTO SM_AH
	VALUES (815,
	713);
INSERT INTO SM_ACT
	VALUES (815,
	713,
	1,
	'send IO::turn(orientation: Orientation::left);',
	'');
INSERT INTO ACT_SAB
	VALUES (816,
	713,
	815);
INSERT INTO ACT_ACT
	VALUES (816,
	'state',
	0,
	817,
	0,
	0,
	'steering::lefting',
	0);
INSERT INTO ACT_BLK
	VALUES (817,
	0,
	0,
	0,
	'IO',
	'',
	'',
	1,
	1,
	1,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	28,
	0,
	816,
	0);
INSERT INTO ACT_SMT
	VALUES (818,
	817,
	0,
	1,
	1,
	'steering::lefting line: 1');
INSERT INTO ACT_SGN
	VALUES (818,
	0,
	626,
	1,
	10,
	1,
	6);
INSERT INTO V_VAL
	VALUES (819,
	0,
	0,
	1,
	41,
	44,
	0,
	0,
	0,
	0,
	25,
	817);
INSERT INTO V_LEN
	VALUES (819,
	26,
	1,
	28);
INSERT INTO V_PAR
	VALUES (819,
	818,
	0,
	'orientation',
	0,
	1,
	15);
INSERT INTO SM_STATE
	VALUES (820,
	713,
	0,
	'righting',
	3,
	0);
INSERT INTO SM_SEME
	VALUES (820,
	773,
	713,
	0);
INSERT INTO SM_EIGN
	VALUES (820,
	807,
	713,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (820,
	807,
	713,
	0);
INSERT INTO SM_SEME
	VALUES (820,
	712,
	713,
	0);
INSERT INTO SM_MOAH
	VALUES (821,
	713,
	820);
INSERT INTO SM_AH
	VALUES (821,
	713);
INSERT INTO SM_ACT
	VALUES (821,
	713,
	1,
	'send IO::turn(orientation: Orientation::right);',
	'');
INSERT INTO ACT_SAB
	VALUES (822,
	713,
	821);
INSERT INTO ACT_ACT
	VALUES (822,
	'state',
	0,
	823,
	0,
	0,
	'steering::righting',
	0);
INSERT INTO ACT_BLK
	VALUES (823,
	0,
	0,
	0,
	'IO',
	'',
	'',
	1,
	1,
	1,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	28,
	0,
	822,
	0);
INSERT INTO ACT_SMT
	VALUES (824,
	823,
	0,
	1,
	1,
	'steering::righting line: 1');
INSERT INTO ACT_SGN
	VALUES (824,
	0,
	626,
	1,
	10,
	1,
	6);
INSERT INTO V_VAL
	VALUES (825,
	0,
	0,
	1,
	41,
	45,
	0,
	0,
	0,
	0,
	25,
	823);
INSERT INTO V_LEN
	VALUES (825,
	27,
	1,
	28);
INSERT INTO V_PAR
	VALUES (825,
	824,
	0,
	'orientation',
	0,
	1,
	15);
INSERT INTO SM_NSTXN
	VALUES (826,
	713,
	814,
	712,
	0);
INSERT INTO SM_TAH
	VALUES (827,
	713,
	826);
INSERT INTO SM_AH
	VALUES (827,
	713);
INSERT INTO SM_ACT
	VALUES (827,
	713,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (828,
	713,
	827);
INSERT INTO ACT_ACT
	VALUES (828,
	'transition',
	0,
	829,
	0,
	0,
	'steering3: straight in lefting to maintaining',
	0);
INSERT INTO ACT_BLK
	VALUES (829,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	828,
	0);
INSERT INTO SM_TXN
	VALUES (826,
	713,
	808,
	0);
INSERT INTO SM_NSTXN
	VALUES (830,
	713,
	808,
	773,
	0);
INSERT INTO SM_TAH
	VALUES (831,
	713,
	830);
INSERT INTO SM_AH
	VALUES (831,
	713);
INSERT INTO SM_ACT
	VALUES (831,
	713,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (832,
	713,
	831);
INSERT INTO ACT_ACT
	VALUES (832,
	'transition',
	0,
	833,
	0,
	0,
	'steering1: left in maintaining to lefting',
	0);
INSERT INTO ACT_BLK
	VALUES (833,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	832,
	0);
INSERT INTO SM_TXN
	VALUES (830,
	713,
	814,
	0);
INSERT INTO SM_NSTXN
	VALUES (834,
	713,
	808,
	807,
	0);
INSERT INTO SM_TAH
	VALUES (835,
	713,
	834);
INSERT INTO SM_AH
	VALUES (835,
	713);
INSERT INTO SM_ACT
	VALUES (835,
	713,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (836,
	713,
	835);
INSERT INTO ACT_ACT
	VALUES (836,
	'transition',
	0,
	837,
	0,
	0,
	'steering2: right in maintaining to righting',
	0);
INSERT INTO ACT_BLK
	VALUES (837,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	836,
	0);
INSERT INTO SM_TXN
	VALUES (834,
	713,
	820,
	0);
INSERT INTO SM_NSTXN
	VALUES (838,
	713,
	820,
	773,
	0);
INSERT INTO SM_TAH
	VALUES (839,
	713,
	838);
INSERT INTO SM_AH
	VALUES (839,
	713);
INSERT INTO SM_ACT
	VALUES (839,
	713,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (840,
	713,
	839);
INSERT INTO ACT_ACT
	VALUES (840,
	'transition',
	0,
	841,
	0,
	0,
	'steering1: left in righting to lefting',
	0);
INSERT INTO ACT_BLK
	VALUES (841,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	840,
	0);
INSERT INTO SM_TXN
	VALUES (838,
	713,
	814,
	0);
INSERT INTO SM_NSTXN
	VALUES (842,
	713,
	814,
	807,
	0);
INSERT INTO SM_TAH
	VALUES (843,
	713,
	842);
INSERT INTO SM_AH
	VALUES (843,
	713);
INSERT INTO SM_ACT
	VALUES (843,
	713,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (844,
	713,
	843);
INSERT INTO ACT_ACT
	VALUES (844,
	'transition',
	0,
	845,
	0,
	0,
	'steering2: right in lefting to righting',
	0);
INSERT INTO ACT_BLK
	VALUES (845,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	844,
	0);
INSERT INTO SM_TXN
	VALUES (842,
	713,
	820,
	0);
INSERT INTO SM_NSTXN
	VALUES (846,
	713,
	820,
	712,
	0);
INSERT INTO SM_TAH
	VALUES (847,
	713,
	846);
INSERT INTO SM_AH
	VALUES (847,
	713);
INSERT INTO SM_ACT
	VALUES (847,
	713,
	1,
	'',
	'');
INSERT INTO ACT_TAB
	VALUES (848,
	713,
	847);
INSERT INTO ACT_ACT
	VALUES (848,
	'transition',
	0,
	849,
	0,
	0,
	'steering3: straight in righting to maintaining',
	0);
INSERT INTO ACT_BLK
	VALUES (849,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	848,
	0);
INSERT INTO SM_TXN
	VALUES (846,
	713,
	808,
	0);
INSERT INTO R_SIMP
	VALUES (581);
INSERT INTO R_REL
	VALUES (581,
	1,
	'',
	682);
INSERT INTO R_PART
	VALUES (579,
	581,
	850,
	0,
	0,
	'navigates');
INSERT INTO R_RTO
	VALUES (579,
	581,
	850,
	-1);
INSERT INTO R_OIR
	VALUES (579,
	581,
	850,
	0);
INSERT INTO R_PART
	VALUES (554,
	581,
	851,
	0,
	0,
	'steers for');
INSERT INTO R_RTO
	VALUES (554,
	581,
	851,
	-1);
INSERT INTO R_OIR
	VALUES (554,
	581,
	851,
	0);
INSERT INTO R_SIMP
	VALUES (583);
INSERT INTO R_REL
	VALUES (583,
	2,
	'',
	682);
INSERT INTO R_PART
	VALUES (576,
	583,
	852,
	0,
	0,
	'directs');
INSERT INTO R_RTO
	VALUES (576,
	583,
	852,
	-1);
INSERT INTO R_OIR
	VALUES (576,
	583,
	852,
	0);
INSERT INTO R_PART
	VALUES (554,
	583,
	853,
	0,
	0,
	'motivates');
INSERT INTO R_RTO
	VALUES (554,
	583,
	853,
	-1);
INSERT INTO R_OIR
	VALUES (554,
	583,
	853,
	0);
INSERT INTO S_DIS
	VALUES (631,
	854);
INSERT INTO S_DT
	VALUES (854,
	0,
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES (854,
	0);
INSERT INTO S_DIS
	VALUES (631,
	855);
INSERT INTO S_DT
	VALUES (855,
	0,
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES (855,
	1);
INSERT INTO S_DIS
	VALUES (631,
	856);
INSERT INTO S_DT
	VALUES (856,
	0,
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES (856,
	2);
INSERT INTO S_DIS
	VALUES (631,
	857);
INSERT INTO S_DT
	VALUES (857,
	0,
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES (857,
	3);
INSERT INTO S_DIS
	VALUES (631,
	858);
INSERT INTO S_DT
	VALUES (858,
	0,
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES (858,
	4);
INSERT INTO S_DIS
	VALUES (631,
	859);
INSERT INTO S_DT
	VALUES (859,
	0,
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES (859,
	5);
INSERT INTO S_DIS
	VALUES (631,
	860);
INSERT INTO S_DT
	VALUES (860,
	0,
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (860,
	6);
INSERT INTO S_DIS
	VALUES (631,
	861);
INSERT INTO S_DT
	VALUES (861,
	0,
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (861,
	7);
INSERT INTO S_DIS
	VALUES (631,
	862);
INSERT INTO S_DT
	VALUES (862,
	0,
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (862,
	8);
INSERT INTO S_DIS
	VALUES (631,
	863);
INSERT INTO S_DT
	VALUES (863,
	0,
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (863,
	9);
INSERT INTO S_DIS
	VALUES (631,
	864);
INSERT INTO S_DT
	VALUES (864,
	0,
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (864,
	10);
INSERT INTO S_DIS
	VALUES (631,
	865);
INSERT INTO S_DT
	VALUES (865,
	0,
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (865,
	11);
INSERT INTO S_DIS
	VALUES (631,
	866);
INSERT INTO S_DT
	VALUES (866,
	0,
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (866,
	12);
INSERT INTO S_DIS
	VALUES (631,
	867);
INSERT INTO S_DT
	VALUES (867,
	0,
	'date',
	'',
	'');
INSERT INTO S_UDT
	VALUES (867,
	865,
	1);
INSERT INTO S_DIS
	VALUES (631,
	868);
INSERT INTO S_DT
	VALUES (868,
	0,
	'timestamp',
	'',
	'');
INSERT INTO S_UDT
	VALUES (868,
	865,
	2);
INSERT INTO S_DIS
	VALUES (631,
	869);
INSERT INTO S_DT
	VALUES (869,
	0,
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES (869,
	866,
	3);
INSERT INTO EP_SPKG
	VALUES (29,
	0);
INSERT INTO CP_CP
	VALUES (870,
	0,
	1,
	1,
	'SumoRobot',
	'');
INSERT INTO CL_IC
	VALUES (871,
	545,
	0,
	870,
	0,
	'',
	'Sumo::Library::sumo',
	'');
INSERT INTO CL_IIR
	VALUES (872,
	547,
	871,
	0,
	'platform',
	'');
INSERT INTO CL_IR
	VALUES (872,
	873,
	'platform',
	'');
INSERT INTO CL_IC
	VALUES (874,
	30,
	0,
	870,
	0,
	'',
	'Sumo::Library::NXT',
	'');
INSERT INTO CL_IIR
	VALUES (875,
	32,
	874,
	0,
	'platform',
	'');
INSERT INTO CL_IP
	VALUES (875,
	'platform',
	'');
INSERT INTO CL_IPINS
	VALUES (873,
	875);
INSERT INTO PA_SICP
	VALUES (870,
	873);
INSERT INTO C_SF
	VALUES (873,
	547,
	32,
	'');
INSERT INTO EP_SPKG
	VALUES (870,
	0);
INSERT INTO CP_CP
	VALUES (876,
	0,
	1,
	1,
	'TestCases',
	'');
INSERT INTO CL_IC
	VALUES (877,
	357,
	0,
	876,
	0,
	'',
	'Sumo::Library::Test',
	'');
INSERT INTO CL_IIR
	VALUES (878,
	359,
	877,
	0,
	'platform',
	'');
INSERT INTO CL_IP
	VALUES (878,
	'platform',
	'');
INSERT INTO CL_IPINS
	VALUES (879,
	878);
INSERT INTO CL_IC
	VALUES (880,
	545,
	0,
	876,
	0,
	'',
	'Sumo::Library::sumo',
	'');
INSERT INTO CL_IIR
	VALUES (881,
	547,
	880,
	0,
	'platform',
	'');
INSERT INTO CL_IR
	VALUES (881,
	879,
	'platform',
	'');
INSERT INTO PA_SICP
	VALUES (876,
	879);
INSERT INTO C_SF
	VALUES (879,
	547,
	359,
	'');
INSERT INTO EP_SPKG
	VALUES (876,
	0);
INSERT INTO IP_IP
	VALUES (882,
	0,
	1,
	1,
	0,
	0,
	'RobotInterface',
	'');
INSERT INTO C_I
	VALUES (33,
	882,
	'platform',
	'');
INSERT INTO C_EP
	VALUES (89,
	33,
	-1);
INSERT INTO C_IO
	VALUES (89,
	3,
	'lineDetected',
	'',
	1,
	'',
	97);
INSERT INTO C_EP
	VALUES (93,
	33,
	-1);
INSERT INTO C_IO
	VALUES (93,
	3,
	'touchLeft',
	'',
	1,
	'',
	89);
INSERT INTO C_EP
	VALUES (97,
	33,
	-1);
INSERT INTO C_IO
	VALUES (97,
	3,
	'init',
	'',
	1,
	'',
	0);
INSERT INTO C_EP
	VALUES (101,
	33,
	-1);
INSERT INTO C_IO
	VALUES (101,
	3,
	'touchRight',
	'',
	1,
	'',
	93);
INSERT INTO C_EP
	VALUES (35,
	33,
	-1);
INSERT INTO C_AS
	VALUES (35,
	'go',
	'',
	0,
	0);
INSERT INTO C_PP
	VALUES (46,
	35,
	21,
	'direction',
	'',
	0,
	'',
	0);
INSERT INTO C_EP
	VALUES (51,
	33,
	-1);
INSERT INTO C_AS
	VALUES (51,
	'turn',
	'd = SumoSimulatorProxy::orientation2int(orientation: param.orientation);
SumoSimBridge::turn(orientation: d);',
	0,
	35);
INSERT INTO C_PP
	VALUES (62,
	51,
	25,
	'orientation',
	'',
	0,
	'',
	0);
INSERT INTO C_EP
	VALUES (67,
	33,
	-1);
INSERT INTO C_AS
	VALUES (67,
	'setName',
	'',
	0,
	51);
INSERT INTO C_PP
	VALUES (80,
	67,
	7,
	'name',
	'',
	0,
	'',
	0);
INSERT INTO EP_SPKG
	VALUES (882,
	0);
INSERT INTO SQ_S
	VALUES (883,
	0,
	'StartupSequence',
	0,
	0,
	'',
	1,
	0,
	0);
INSERT INTO SQ_P
	VALUES (884,
	883);
INSERT INTO SQ_COP
	VALUES (884,
	0,
	'NXT',
	'NXT',
	'',
	0);
INSERT INTO SQ_P
	VALUES (885,
	883);
INSERT INTO SQ_COP
	VALUES (885,
	0,
	'sumo',
	'sumo',
	'',
	0);
INSERT INTO SQ_P
	VALUES (886,
	883);
INSERT INTO MSG_M
	VALUES (887,
	888,
	886);
INSERT INTO MSG_SM
	VALUES (887,
	'connect() / start nxt',
	'',
	'',
	'',
	'',
	0,
	'connect() / start nxt',
	'');
INSERT INTO MSG_ISM
	VALUES (887);
INSERT INTO MSG_M
	VALUES (889,
	890,
	886);
INSERT INTO MSG_AM
	VALUES (889,
	'setName(name)',
	'',
	'',
	'',
	'',
	0,
	'setName(name)',
	'');
INSERT INTO MSG_IAM
	VALUES (889);
INSERT INTO SQ_LS
	VALUES (886,
	884,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (891,
	'',
	886,
	'');
INSERT INTO SQ_TS
	VALUES (892,
	893,
	891,
	'',
	'');
INSERT INTO SQ_TM
	VALUES (893,
	'startup wait time: 2 sec',
	886,
	'');
INSERT INTO SQ_P
	VALUES (890,
	883);
INSERT INTO MSG_M
	VALUES (894,
	886,
	890);
INSERT INTO MSG_SM
	VALUES (894,
	'init()',
	'',
	'',
	'',
	'',
	0,
	'init()',
	'');
INSERT INTO MSG_ISM
	VALUES (894);
INSERT INTO SQ_LS
	VALUES (890,
	885,
	'',
	0);
INSERT INTO SQ_P
	VALUES (895,
	883);
INSERT INTO SQ_AP
	VALUES (895,
	'user',
	'',
	0);
INSERT INTO SQ_P
	VALUES (888,
	883);
INSERT INTO SQ_LS
	VALUES (888,
	895,
	'',
	0);
INSERT INTO EP_SPKG
	VALUES (883,
	0);
