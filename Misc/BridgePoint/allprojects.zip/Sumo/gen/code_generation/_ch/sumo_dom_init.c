/*----------------------------------------------------------------------------
 * File:  sumo_dom_init.c
 *
 * Initialization services for the following domain:
 * Component:  sumo
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "sumo_classes.h"
#include "sumo_dom_init.h"

/* xtUML class info (collections, sizes, etc.) */
Escher_Extent_t * const sumo_class_info[ sumo_MAX_CLASS_NUMBERS ] = {
  sumo_CLASS_INFO_INIT
};

/*
 * Array of pointers to the class event dispatcher method.
 * Index is the (model compiler enumerated) number of the state model.
 */
const EventTaker_t sumo_EventDispatcher[ sumo_STATE_MODELS ] = {
  sumo_class_dispatchers
};

void sumo_dom_init()
{

}
