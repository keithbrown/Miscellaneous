/*----------------------------------------------------------------------------
 * File:  Test_datatypes.h
 *
 * Enumerated data types in the application analysis of component:
 * Component:  Test
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef TEST_DATATYPES_H
#define TEST_DATATYPES_H

#ifdef	__cplusplus
extern "C" {
#endif



#include "Test_ports.h"

#ifdef	__cplusplus
}
#endif

#endif  /* TEST_DATATYPES_H */
