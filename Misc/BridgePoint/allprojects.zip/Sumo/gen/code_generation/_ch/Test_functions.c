/*----------------------------------------------------------------------------
 * File:  Test_functions.c"
 *
 * UML Domain Functions (Synchronous Services) and Port Operations
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "TIM_bridge.h"
#include "ARCH_bridge.h"
#include "LOG_bridge.h"
#include "Test_functions.h"



/*
 * Domain Function:  run
 */
void
Test_run( void )
{
  /* platform::init() */
  ROX_BPAL_STMT_TRACE( 1, "platform::init()" )
  Test_IO_init();

}

