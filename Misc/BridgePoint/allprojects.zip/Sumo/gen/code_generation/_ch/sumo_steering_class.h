/*----------------------------------------------------------------------------
 * File:  sumo_steering_class.h
 *
 * Class:       steering  (steering)
 * Component:   sumo
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef SUMO_STEERING_CLASS_H
#define SUMO_STEERING_CLASS_H

#ifdef	__cplusplus
extern "C" {
#endif

/*
 * Structural representation of application analysis class:
 *   steering  (steering)
 */
struct sumo_steering {
  Escher_StateNumber_t current_state;
  /* application analysis class attributes */

  /* relationship storage */
  /* Note:  No storage needed for steering->navigate[R1] */
};

#define sumo_steering_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_sumo_steering_extent;

extern void sumo_steering_R1_Link( sumo_navigate *, sumo_steering * );
/* Note:  navigate<-R1->steering unrelate accessor not needed */


/*
 * instance event:  steering1:'left'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} sumo_steeringevent1;
extern const Escher_xtUMLEventConstant_t sumo_steeringevent1c;

/*
 * instance event:  steering2:'right'
 * warning:  Event is not used in application - no code generated.
 */

/*
 * instance event:  steering3:'straight'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} sumo_steeringevent3;
extern const Escher_xtUMLEventConstant_t sumo_steeringevent3c;

/*
 * union of events targeted towards 'steering' state machine
 */
typedef union {
  sumo_steeringevent1 steering1;  
  sumo_steeringevent3 steering3;  
} sumo_steering_Events_u;

/*
 * enumeration of state model states for class
 */
#define sumo_steering_STATE_1 1  /* state [1]:  (maintaining) */
#define sumo_steering_STATE_2 2  /* state [2]:  (lefting) */
#define sumo_steering_STATE_3 3  /* state [3]:  (righting) */
/*
 * enumeration of state model event numbers
 */
#define SUMO_STEERINGEVENT1NUM 0  /* steering1:'left' */
#define SUMO_STEERINGEVENT3NUM 1  /* steering3:'straight' */
extern void sumo_steering_Dispatch( Escher_xtUMLEvent_t * );

#ifdef	__cplusplus
}
#endif

#endif  /* SUMO_STEERING_CLASS_H */


