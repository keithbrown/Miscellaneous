/*----------------------------------------------------------------------------
 * File:  Test_ports.c
 *
 * UML Component Port Messages
 * Component Name:  Test
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "Test_ports.h"
#include "sumo_ports.h"
#include "Test_classes.h"

/*
 * Interface:  platform
 * Provided Port:  IO
 * From Provider Message:  lineDetected
 */
void
Test_IO_lineDetected( void )
{
sumo_IO_lineDetected();
}

/*
 * Interface:  platform
 * Provided Port:  IO
 * From Provider Message:  touchLeft
 */
void
Test_IO_touchLeft( void )
{
sumo_IO_touchLeft();
}

/*
 * Interface:  platform
 * Provided Port:  IO
 * From Provider Message:  init
 */
void
Test_IO_init( void )
{
sumo_IO_init();
}

/*
 * Interface:  platform
 * Provided Port:  IO
 * From Provider Message:  touchRight
 */
void
Test_IO_touchRight( void )
{
sumo_IO_touchRight();
}

/*
 * Interface:  platform
 * Provided Port:  IO
 * To Provider Message:  go
 */
void
Test_IO_go( s2_t p_direction )
{
}

/*
 * Interface:  platform
 * Provided Port:  IO
 * To Provider Message:  turn
 */
void
Test_IO_turn( s2_t p_orientation )
{
}

/*
 * Interface:  platform
 * Provided Port:  IO
 * To Provider Message:  setName
 */
void
Test_IO_setName( c_t p_name[ESCHER_SYS_MAX_STRING_LEN] )
{
  Test_TestCase1 * tc1;
  /* CREATE OBJECT INSTANCE tc1 OF TestCase1 */
  ROX_BPAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE tc1 OF TestCase1" )
  tc1 = (Test_TestCase1 *) Escher_CreateInstance( Test_DOMAIN_ID, Test_TestCase1_CLASS_NUMBER );
  /* GENERATE TestCase18:setName() TO tc1 */
  ROX_BPAL_STMT_TRACE( 1, "GENERATE TestCase18:setName() TO tc1" )
  {
  Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( tc1, &Test_TestCase1event8c );
  Escher_SendEvent( e );
  }
}

