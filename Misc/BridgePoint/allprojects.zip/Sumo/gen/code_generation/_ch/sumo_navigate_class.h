/*----------------------------------------------------------------------------
 * File:  sumo_navigate_class.h
 *
 * Class:       navigate  (navigate)
 * Component:   sumo
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef SUMO_NAVIGATE_CLASS_H
#define SUMO_NAVIGATE_CLASS_H

#ifdef	__cplusplus
extern "C" {
#endif

/*
 * Structural representation of application analysis class:
 *   navigate  (navigate)
 */
struct sumo_navigate {
  Escher_StateNumber_t current_state;
  /* application analysis class attributes */
  i_t retreat_duration;  /* - retreat_duration */
  i_t target_duration;  /* - target_duration */

  /* relationship storage */
  sumo_steering * steering_R1;
  sumo_drive * drive_R2;
};

#define sumo_navigate_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_sumo_navigate_extent;



/*
 * instance event:  navigate1:'pop'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} sumo_navigateevent1;
extern const Escher_xtUMLEventConstant_t sumo_navigateevent1c;

/*
 * instance event:  navigate2:'line'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} sumo_navigateevent2;
extern const Escher_xtUMLEventConstant_t sumo_navigateevent2c;

/*
 * instance event:  navigate3:'leftBumper'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} sumo_navigateevent3;
extern const Escher_xtUMLEventConstant_t sumo_navigateevent3c;

/*
 * instance event:  navigate4:'rightBumper'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} sumo_navigateevent4;
extern const Escher_xtUMLEventConstant_t sumo_navigateevent4c;

/*
 * union of events targeted towards 'navigate' state machine
 */
typedef union {
  sumo_navigateevent1 navigate1;  
  sumo_navigateevent2 navigate2;  
  sumo_navigateevent3 navigate3;  
  sumo_navigateevent4 navigate4;  
} sumo_navigate_Events_u;

/*
 * enumeration of state model states for class
 */
#define sumo_navigate_STATE_1 1  /* state [1]:  (resting) */
#define sumo_navigate_STATE_2 2  /* state [2]:  (attacking) */
#define sumo_navigate_STATE_3 3  /* state [3]:  (retreating) */
#define sumo_navigate_STATE_4 4  /* state [4]:  (targeting) */
/*
 * enumeration of state model event numbers
 */
#define SUMO_NAVIGATEEVENT1NUM 0  /* navigate1:'pop' */
#define SUMO_NAVIGATEEVENT2NUM 1  /* navigate2:'line' */
#define SUMO_NAVIGATEEVENT3NUM 2  /* navigate3:'leftBumper' */
#define SUMO_NAVIGATEEVENT4NUM 3  /* navigate4:'rightBumper' */
extern void sumo_navigate_Dispatch( Escher_xtUMLEvent_t * );

#ifdef	__cplusplus
}
#endif

#endif  /* SUMO_NAVIGATE_CLASS_H */


