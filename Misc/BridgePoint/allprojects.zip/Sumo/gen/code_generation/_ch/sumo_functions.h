/*----------------------------------------------------------------------------
 * File:  sumo_functions.h"
 *
 * UML Domain Functions (Synchronous Services) and Port Operations
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef SUMO_FUNCTIONS_H
#define SUMO_FUNCTIONS_H

#ifdef	__cplusplus
extern "C" {
#endif

extern void sumo_test( void );


#ifdef	__cplusplus
}
#endif

#endif  /* SUMO_FUNCTIONS_H */
