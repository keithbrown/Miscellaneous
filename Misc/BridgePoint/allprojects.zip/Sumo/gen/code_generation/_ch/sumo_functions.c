/*----------------------------------------------------------------------------
 * File:  sumo_functions.c"
 *
 * UML Domain Functions (Synchronous Services) and Port Operations
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "TIM_bridge.h"
#include "sumo_functions.h"



/*
 * Domain Function:  test
 */
void
sumo_test( void )
{
    sumo_navigate * n;
  /* SELECT any n FROM INSTANCES OF navigate */
  ROX_BPAL_STMT_TRACE( 1, "SELECT any n FROM INSTANCES OF navigate" )
  n = (sumo_navigate *) Escher_SetGetAny( &pG_sumo_navigate_extent.active );
  /* GENERATE navigate2:line() TO n */
  ROX_BPAL_STMT_TRACE( 1, "GENERATE navigate2:line() TO n" )
  {
  Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( n, &sumo_navigateevent2c );
  Escher_SendEvent( e );
  }

}

