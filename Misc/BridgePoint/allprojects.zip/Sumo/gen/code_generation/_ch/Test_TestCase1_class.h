/*----------------------------------------------------------------------------
 * File:  Test_TestCase1_class.h
 *
 * Class:       TestCase1  (TestCase1)
 * Component:   Test
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef TEST_TESTCASE1_CLASS_H
#define TEST_TESTCASE1_CLASS_H

#ifdef	__cplusplus
extern "C" {
#endif

/*
 * Structural representation of application analysis class:
 *   TestCase1  (TestCase1)
 */
struct Test_TestCase1 {
  Escher_StateNumber_t current_state;
  /* application analysis class attributes */

};

#define Test_TestCase1_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_Test_TestCase1_extent;



/*
 * instance event:  TestCase16:'step'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Test_TestCase1event6;
extern const Escher_xtUMLEventConstant_t Test_TestCase1event6c;

/*
 * instance event:  TestCase18:'setName'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Test_TestCase1event8;
extern const Escher_xtUMLEventConstant_t Test_TestCase1event8c;

/*
 * union of events targeted towards 'TestCase1' state machine
 */
typedef union {
  Test_TestCase1event6 testcase16;  
  Test_TestCase1event8 testcase18;  
} Test_TestCase1_Events_u;

/*
 * enumeration of state model states for class
 */
#define Test_TestCase1_STATE_1 1  /* state [1]:  (idle) */
#define Test_TestCase1_STATE_2 2  /* state [2]:  (delaying) */
#define Test_TestCase1_STATE_3 3  /* state [3]:  (sendLineDetected) */
#define Test_TestCase1_STATE_4 4  /* state [4]:  (final) */
/*
 * enumeration of state model event numbers
 */
#define TEST_TESTCASE1EVENT6NUM 0  /* TestCase16:'step' */
#define TEST_TESTCASE1EVENT8NUM 1  /* TestCase18:'setName' */
extern void Test_TestCase1_Dispatch( Escher_xtUMLEvent_t * );

#ifdef	__cplusplus
}
#endif

#endif  /* TEST_TESTCASE1_CLASS_H */


