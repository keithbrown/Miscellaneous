/*----------------------------------------------------------------------------
 * File:  Test_dom_init.c
 *
 * Initialization services for the following domain:
 * Component:  Test
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "Test_classes.h"
#include "Test_dom_init.h"
#include "Test_functions.h"

/* xtUML class info (collections, sizes, etc.) */
Escher_Extent_t * const Test_class_info[ Test_MAX_CLASS_NUMBERS ] = {
  Test_CLASS_INFO_INIT
};

/*
 * Array of pointers to the class event dispatcher method.
 * Index is the (model compiler enumerated) number of the state model.
 */
const EventTaker_t Test_EventDispatcher[ Test_STATE_MODELS ] = {
  Test_class_dispatchers
};

void Test_dom_init()
{
  /*
   * Initialization Function:  run
   * Component:  Test
   */
  Test_run();


}
