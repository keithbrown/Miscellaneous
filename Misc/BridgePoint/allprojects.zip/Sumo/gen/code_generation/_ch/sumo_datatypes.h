/*----------------------------------------------------------------------------
 * File:  sumo_datatypes.h
 *
 * Enumerated data types in the application analysis of component:
 * Component:  sumo
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef SUMO_DATATYPES_H
#define SUMO_DATATYPES_H

#ifdef	__cplusplus
extern "C" {
#endif



#include "sumo_ports.h"

#ifdef	__cplusplus
}
#endif

#endif  /* SUMO_DATATYPES_H */
