/*----------------------------------------------------------------------------
 * File:  sumo_classes.h
 *
 * This file defines the object type identification numbers for all objects
 * in the following domain:
 *
 * Component:  sumo
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef SUMO_CLASSES_H
#define SUMO_CLASSES_H

#ifdef	__cplusplus
extern "C" {
#endif


#define sumo_STATE_MODELS 2

/* Define constants to map to class numbers.  */
#define sumo_navigate_CLASS_NUMBER 0
#define sumo_steering_CLASS_NUMBER 1
#define sumo_drive_CLASS_NUMBER 2
#define sumo_MAX_CLASS_NUMBERS 3

/* Provide a map of classes to task numbers.  */
#define sumo_TASK_NUMBERS  0, 0

#define sumo_CLASS_INFO_INIT\
  &pG_sumo_navigate_extent,\
  &pG_sumo_steering_extent,\
  &pG_sumo_drive_extent

#define sumo_class_dispatchers\
  sumo_navigate_Dispatch,\
  sumo_steering_Dispatch

/* Provide definitions of the shapes of the class structures.  */

typedef struct sumo_navigate sumo_navigate;
typedef struct sumo_steering sumo_steering;
typedef struct sumo_drive sumo_drive;

/* union of class declarations so we may derive largest class size */
#define sumo_CLASS_U \
  char sumo_dummy;\

#include "sumo_datatypes.h"

#include "sumo_drive_class.h"
#include "sumo_navigate_class.h"
#include "sumo_steering_class.h"


/*
 * roll-up of all events (with their parameters) for domain sumo
 */
typedef union {
  sumo_navigate_Events_u namespace_dummy2;
  sumo_steering_Events_u namespace_dummy3;
} sumo_DomainEvents_u;


#ifdef	__cplusplus
}
#endif

#endif  /* SUMO_CLASSES_H */

