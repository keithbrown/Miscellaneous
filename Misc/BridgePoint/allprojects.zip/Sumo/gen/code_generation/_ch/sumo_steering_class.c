/*----------------------------------------------------------------------------
 * File:  sumo_steering_class.c
 *
 * Class:       steering  (steering)
 * Component:   sumo
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "TIM_bridge.h"
#include "sumo_functions.h"
/*
 * Statically allocate space for the instance population for this class.
 * Allocate space for the class instance and its attribute values.
 * Depending upon the collection scheme, allocate containoids (collection
 * nodes) for gathering instances into free and active extents.
 */
static Escher_SetElement_s sumo_steering_container[ sumo_steering_MAX_EXTENT_SIZE ];
static sumo_steering sumo_steering_instances[ sumo_steering_MAX_EXTENT_SIZE ];
Escher_Extent_t pG_sumo_steering_extent = {
  {0}, {0}, &sumo_steering_container[ 0 ],
  (Escher_iHandle_t) &sumo_steering_instances,
  sizeof( sumo_steering ), sumo_steering_STATE_1, sumo_steering_MAX_EXTENT_SIZE
  };


/*
 * RELATE navigate TO steering ACROSS R1
 */
void
sumo_steering_R1_Link( sumo_navigate * part, sumo_steering * form )
{
  if ( (part == 0) || (form == 0) ) {
    ROX_EMPTY_HANDLE_TRACE( "steering", "sumo_steering_R1_Link" )
    return;
  }
  /* Note:  steering->navigate[R1] not navigated */
  part->steering_R1 = form;
}

/*----------------------------------------------------------------------------
 * State and transition action implementations for the following class:
 *
 * Class:      steering  (steering)
 * Component:  sumo
 *--------------------------------------------------------------------------*/

/*
 * State 1:  [maintaining]
 */
static void sumo_steering_act1( sumo_steering *, const Escher_xtUMLEvent_t * const );
static void
sumo_steering_act1( sumo_steering * self, const Escher_xtUMLEvent_t * const event )
{
  /* SEND platform::turn(orientation:straight) */
  ROX_BPAL_STMT_TRACE( 1, "SEND platform::turn(orientation:straight)" )
  sumo_IO_turn( sys_Orientation_straight_e );
}

/*
 * State 2:  [lefting]
 */
static void sumo_steering_act2( sumo_steering *, const Escher_xtUMLEvent_t * const );
static void
sumo_steering_act2( sumo_steering * self, const Escher_xtUMLEvent_t * const event )
{
  /* SEND platform::turn(orientation:left) */
  ROX_BPAL_STMT_TRACE( 1, "SEND platform::turn(orientation:left)" )
  sumo_IO_turn( sys_Orientation_left_e );
}

/*
 * State 3:  [righting]
 */
static void sumo_steering_act3( sumo_steering *, const Escher_xtUMLEvent_t * const );
static void
sumo_steering_act3( sumo_steering * self, const Escher_xtUMLEvent_t * const event )
{
  /* SEND platform::turn(orientation:right) */
  ROX_BPAL_STMT_TRACE( 1, "SEND platform::turn(orientation:right)" )
  sumo_IO_turn( sys_Orientation_right_e );
}

const Escher_xtUMLEventConstant_t sumo_steeringevent1c = {
  sumo_DOMAIN_ID, sumo_steering_CLASS_NUMBER, SUMO_STEERINGEVENT1NUM,
  ESCHER_IS_INSTANCE_EVENT };


const Escher_xtUMLEventConstant_t sumo_steeringevent3c = {
  sumo_DOMAIN_ID, sumo_steering_CLASS_NUMBER, SUMO_STEERINGEVENT3NUM,
  ESCHER_IS_INSTANCE_EVENT };



/*
 * State-Event Matrix (SEM)
 * Row index is object (MC enumerated) current state.
 * Row zero is the unitialized state (e.g., for creation event transitions).
 * Column index is (MC enumerated) state machine events.
 */
static const Escher_SEMcell_t sumo_steering_StateEventMatrix[ 3 + 1 ][ 2 ] = {
  /* row 0:  uninitialized state (for creation events) */
  { EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN },
  /* row 1:  sumo_steering_STATE_1 (maintaining) */
  { sumo_steering_STATE_2, EVENT_IS_IGNORED },
  /* row 2:  sumo_steering_STATE_2 (lefting) */
  { EVENT_IS_IGNORED, sumo_steering_STATE_1 },
  /* row 3:  sumo_steering_STATE_3 (righting) */
  { sumo_steering_STATE_2, sumo_steering_STATE_1 }
};

  /*
   * Array of pointers to the class state action procedures.
   * Index is the (MC enumerated) number of the state action to execute.
   */
  static const StateAction_t sumo_steering_acts[ 4 ] = {
    (StateAction_t) 0,
    (StateAction_t) sumo_steering_act1,  /* maintaining */
    (StateAction_t) sumo_steering_act2,  /* lefting */
    (StateAction_t) sumo_steering_act3  /* righting */
  };

  /*
   * Array of string names of the state machine names.
   * Index is the (MC enumerated) number of the state.
   */
  static const c_t * const state_name_strings[ 4 ] = {
    "",
    "maintaining",
    "lefting",
    "righting"
  };

/*
 * instance state machine event dispatching
 */
void
sumo_steering_Dispatch( Escher_xtUMLEvent_t * event )
{
  Escher_iHandle_t instance = GetEventTargetInstance( event );
  Escher_EventNumber_t event_number = GetOoaEventNumber( event );
  Escher_StateNumber_t current_state;
  Escher_StateNumber_t next_state;
  
  if ( 0 != instance ) {
    current_state = instance->current_state;
    if ( current_state > 3 ) {
      /* instance validation failure (object deleted while event in flight) */
      UserEventNoInstanceCallout( event_number )
    } else {
      next_state = sumo_steering_StateEventMatrix[ current_state ][ event_number ];
      if ( next_state <= 3 ) {
        STATE_TXN_START_TRACE( "steering", current_state, state_name_strings[ current_state ] )
        /* Execute the state action and update the current state.  */
        ( *sumo_steering_acts[ next_state ] )( instance, event );
        STATE_TXN_END_TRACE( "steering", next_state, state_name_strings[ next_state ] )
        instance->current_state = next_state;
      } else if ( next_state == EVENT_IS_IGNORED ) {
          /* event ignored */
          STATE_TXN_IG_TRACE( "steering", current_state )
      } else {
        /* empty else */
      }
    }
  }
}


