/*----------------------------------------------------------------------------
 * File:  sumo_ports.c
 *
 * UML Component Port Messages
 * Component Name:  sumo
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "Test_ports.h"
#include "sumo_ports.h"
#include "sumo_classes.h"

/*
 * Interface:  platform
 * Required Port:  IO
 * From Provider Message:  lineDetected
 */
void
sumo_IO_lineDetected( void )
{
    sumo_navigate * n;
  /* SELECT any n FROM INSTANCES OF navigate */
  ROX_BPAL_STMT_TRACE( 1, "SELECT any n FROM INSTANCES OF navigate" )
  n = (sumo_navigate *) Escher_SetGetAny( &pG_sumo_navigate_extent.active );
  /* GENERATE navigate2:line() TO n */
  ROX_BPAL_STMT_TRACE( 1, "GENERATE navigate2:line() TO n" )
  {
  Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( n, &sumo_navigateevent2c );
  Escher_SendEvent( e );
  }
}

/*
 * Interface:  platform
 * Required Port:  IO
 * From Provider Message:  touchLeft
 */
void
sumo_IO_touchLeft( void )
{
    sumo_navigate * n;
  /* SELECT any n FROM INSTANCES OF navigate */
  ROX_BPAL_STMT_TRACE( 1, "SELECT any n FROM INSTANCES OF navigate" )
  n = (sumo_navigate *) Escher_SetGetAny( &pG_sumo_navigate_extent.active );
  /* GENERATE navigate3:leftBumper() TO n */
  ROX_BPAL_STMT_TRACE( 1, "GENERATE navigate3:leftBumper() TO n" )
  {
  Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( n, &sumo_navigateevent3c );
  Escher_SendEvent( e );
  }
}

/*
 * Interface:  platform
 * Required Port:  IO
 * From Provider Message:  init
 */
void
sumo_IO_init( void )
{
  sumo_navigate * n;sumo_drive * d;sumo_steering * s;
  /* CREATE OBJECT INSTANCE n OF navigate */
  ROX_BPAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE n OF navigate" )
  n = (sumo_navigate *) Escher_CreateInstance( sumo_DOMAIN_ID, sumo_navigate_CLASS_NUMBER );
  /* CREATE OBJECT INSTANCE d OF drive */
  ROX_BPAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE d OF drive" )
  d = (sumo_drive *) Escher_CreateInstance( sumo_DOMAIN_ID, sumo_drive_CLASS_NUMBER );
  /* CREATE OBJECT INSTANCE s OF steering */
  ROX_BPAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE s OF steering" )
  s = (sumo_steering *) Escher_CreateInstance( sumo_DOMAIN_ID, sumo_steering_CLASS_NUMBER );
  /* RELATE n TO s ACROSS R1 */
  ROX_BPAL_STMT_TRACE( 1, "RELATE n TO s ACROSS R1" )
  sumo_steering_R1_Link( n, s );
  /* RELATE n TO d ACROSS R2 */
  ROX_BPAL_STMT_TRACE( 1, "RELATE n TO d ACROSS R2" )
  sumo_drive_R2_Link( n, d );
  /* ASSIGN d.speed = 255 */
  ROX_BPAL_STMT_TRACE( 1, "ASSIGN d.speed = 255" )
  d->speed = 255;
  /* ASSIGN n.retreat_duration = 1 */
  ROX_BPAL_STMT_TRACE( 1, "ASSIGN n.retreat_duration = 1" )
  n->retreat_duration = 1;
  /* ASSIGN n.target_duration = 1 */
  ROX_BPAL_STMT_TRACE( 1, "ASSIGN n.target_duration = 1" )
  n->target_duration = 1;
  /* GENERATE navigate1:pop() TO n */
  ROX_BPAL_STMT_TRACE( 1, "GENERATE navigate1:pop() TO n" )
  {
  Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( n, &sumo_navigateevent1c );
  Escher_SendEvent( e );
  }
  /* SEND platform::setName(name:'Model') */
  ROX_BPAL_STMT_TRACE( 1, "SEND platform::setName(name:'Model')" )
  sumo_IO_setName( "Model" );
}

/*
 * Interface:  platform
 * Required Port:  IO
 * From Provider Message:  touchRight
 */
void
sumo_IO_touchRight( void )
{
    sumo_navigate * n;
  /* SELECT any n FROM INSTANCES OF navigate */
  ROX_BPAL_STMT_TRACE( 1, "SELECT any n FROM INSTANCES OF navigate" )
  n = (sumo_navigate *) Escher_SetGetAny( &pG_sumo_navigate_extent.active );
  /* GENERATE navigate4:rightBumper() TO n */
  ROX_BPAL_STMT_TRACE( 1, "GENERATE navigate4:rightBumper() TO n" )
  {
  Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( n, &sumo_navigateevent4c );
  Escher_SendEvent( e );
  }
}

/*
 * Interface:  platform
 * Required Port:  IO
 * To Provider Message:  go
 */
void
sumo_IO_go( s2_t p_direction )
{
Test_IO_go(   p_direction );
}

/*
 * Interface:  platform
 * Required Port:  IO
 * To Provider Message:  turn
 */
void
sumo_IO_turn( s2_t p_orientation )
{
Test_IO_turn(   p_orientation );
}

/*
 * Interface:  platform
 * Required Port:  IO
 * To Provider Message:  setName
 */
void
sumo_IO_setName( c_t p_name[ESCHER_SYS_MAX_STRING_LEN] )
{
Test_IO_setName(   p_name );
}

