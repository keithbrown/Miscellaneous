/*----------------------------------------------------------------------------
 * File:  Test_functions.h"
 *
 * UML Domain Functions (Synchronous Services) and Port Operations
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef TEST_FUNCTIONS_H
#define TEST_FUNCTIONS_H

#ifdef	__cplusplus
extern "C" {
#endif

extern void Test_run( void );


#ifdef	__cplusplus
}
#endif

#endif  /* TEST_FUNCTIONS_H */
