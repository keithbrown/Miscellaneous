/*----------------------------------------------------------------------------
 * File:  Test_classes.h
 *
 * This file defines the object type identification numbers for all objects
 * in the following domain:
 *
 * Component:  Test
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef TEST_CLASSES_H
#define TEST_CLASSES_H

#ifdef	__cplusplus
extern "C" {
#endif


#define Test_STATE_MODELS 1

/* Define constants to map to class numbers.  */
#define Test_TestCase1_CLASS_NUMBER 0
#define Test_MAX_CLASS_NUMBERS 1

/* Provide a map of classes to task numbers.  */
#define Test_TASK_NUMBERS  0

#define Test_CLASS_INFO_INIT\
  &pG_Test_TestCase1_extent

#define Test_class_dispatchers\
  Test_TestCase1_Dispatch

/* Provide definitions of the shapes of the class structures.  */

typedef struct Test_TestCase1 Test_TestCase1;

/* union of class declarations so we may derive largest class size */
#define Test_CLASS_U \
  char Test_dummy;\

#include "Test_datatypes.h"

#include "Test_TestCase1_class.h"


/*
 * roll-up of all events (with their parameters) for domain Test
 */
typedef union {
  Test_TestCase1_Events_u namespace_dummy1;
} Test_DomainEvents_u;


#ifdef	__cplusplus
}
#endif

#endif  /* TEST_CLASSES_H */

