/*----------------------------------------------------------------------------
 * File:  sumo_drive_class.c
 *
 * Class:       drive  (drive)
 * Component:   sumo
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "TIM_bridge.h"
#include "sumo_functions.h"
/*
 * Statically allocate space for the instance population for this class.
 * Allocate space for the class instance and its attribute values.
 * Depending upon the collection scheme, allocate containoids (collection
 * nodes) for gathering instances into free and active extents.
 */
static Escher_SetElement_s sumo_drive_container[ sumo_drive_MAX_EXTENT_SIZE ];
static sumo_drive sumo_drive_instances[ sumo_drive_MAX_EXTENT_SIZE ];
Escher_Extent_t pG_sumo_drive_extent = {
  {0}, {0}, &sumo_drive_container[ 0 ],
  (Escher_iHandle_t) &sumo_drive_instances,
  sizeof( sumo_drive ), 0, sumo_drive_MAX_EXTENT_SIZE
  };

/*----------------------------------------------------------------------------
 * Operation action methods implementation for the following class:
 *
 * Class:      drive  (drive)
 * Component:  sumo
 *--------------------------------------------------------------------------*/

/*
 * instance operation:  forward
 */
void
sumo_drive_op_forward( sumo_drive * self )
{
  /* SEND platform::go(direction:forward) */
  ROX_BPAL_STMT_TRACE( 1, "SEND platform::go(direction:forward)" )
  sumo_IO_go( sys_Direction_forward_e );

}

/*
 * instance operation:  reverse
 */
void
sumo_drive_op_reverse( sumo_drive * self )
{
  /* SEND platform::go(direction:backward) */
  ROX_BPAL_STMT_TRACE( 1, "SEND platform::go(direction:backward)" )
  sumo_IO_go( sys_Direction_backward_e );

}

/*
 * instance operation:  stop
 */
void
sumo_drive_op_stop( sumo_drive * self )
{
  /* SEND platform::go(direction:stop) */
  ROX_BPAL_STMT_TRACE( 1, "SEND platform::go(direction:stop)" )
  sumo_IO_go( sys_Direction_stop_e );

}


/*
 * RELATE navigate TO drive ACROSS R2
 */
void
sumo_drive_R2_Link( sumo_navigate * part, sumo_drive * form )
{
  if ( (part == 0) || (form == 0) ) {
    ROX_EMPTY_HANDLE_TRACE( "drive", "sumo_drive_R2_Link" )
    return;
  }
  /* Note:  drive->navigate[R2] not navigated */
  part->drive_R2 = form;
}



