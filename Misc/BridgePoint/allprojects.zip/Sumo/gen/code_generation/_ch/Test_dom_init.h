/*----------------------------------------------------------------------------
 * File:  Test_dom_init.h
 *
 * Initialization services for the following domain:
 * Component:  Test
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef TEST_DOM_INIT_H
#define TEST_DOM_INIT_H

#ifdef	__cplusplus
extern "C" {
#endif

extern Escher_Extent_t * const Test_class_info[];
extern const EventTaker_t Test_EventDispatcher[];
extern void Test_dom_init( void );

#ifdef	__cplusplus
}
#endif

#endif  /* TEST_DOM_INIT_H */
