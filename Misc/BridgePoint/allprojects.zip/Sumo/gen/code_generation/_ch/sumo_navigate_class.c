/*----------------------------------------------------------------------------
 * File:  sumo_navigate_class.c
 *
 * Class:       navigate  (navigate)
 * Component:   sumo
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "TIM_bridge.h"
#include "sumo_functions.h"
/*
 * Statically allocate space for the instance population for this class.
 * Allocate space for the class instance and its attribute values.
 * Depending upon the collection scheme, allocate containoids (collection
 * nodes) for gathering instances into free and active extents.
 */
static Escher_SetElement_s sumo_navigate_container[ sumo_navigate_MAX_EXTENT_SIZE ];
static sumo_navigate sumo_navigate_instances[ sumo_navigate_MAX_EXTENT_SIZE ];
Escher_Extent_t pG_sumo_navigate_extent = {
  {0}, {0}, &sumo_navigate_container[ 0 ],
  (Escher_iHandle_t) &sumo_navigate_instances,
  sizeof( sumo_navigate ), sumo_navigate_STATE_1, sumo_navigate_MAX_EXTENT_SIZE
  };


/*----------------------------------------------------------------------------
 * State and transition action implementations for the following class:
 *
 * Class:      navigate  (navigate)
 * Component:  sumo
 *--------------------------------------------------------------------------*/

/*
 * State 1:  [resting]
 * WARNING:  unsuccessful or unparsed action
 */
static void sumo_navigate_act1( sumo_navigate *, const Escher_xtUMLEvent_t * const );
static void
sumo_navigate_act1( sumo_navigate * self, const Escher_xtUMLEvent_t * const event )
{
  /* WARNING!  Skipping unsuccessful or unparsed action for class navigate (navigate) state resting" */
}

/*
 * State 2:  [attacking]
 */
static void sumo_navigate_act2( sumo_navigate *, const Escher_xtUMLEvent_t * const );
static void
sumo_navigate_act2( sumo_navigate * self, const Escher_xtUMLEvent_t * const event )
{
  sumo_steering * s; /* s (steering) */
sumo_drive * d; /* d (drive) */

  /* SELECT one s RELATED BY self->steering[R1] */
  ROX_BPAL_STMT_TRACE( 1, "SELECT one s RELATED BY self->steering[R1]" )
  s = self->steering_R1;
  /* GENERATE steering3:straight() TO s */
  ROX_BPAL_STMT_TRACE( 1, "GENERATE steering3:straight() TO s" )
  {
  Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( s, &sumo_steeringevent3c );
  Escher_SendEvent( e );
  }
  /* SELECT one d RELATED BY self->drive[R2] */
  ROX_BPAL_STMT_TRACE( 1, "SELECT one d RELATED BY self->drive[R2]" )
  d = self->drive_R2;
  /* d.forward() */
  ROX_BPAL_STMT_TRACE( 1, "d.forward()" )
  sumo_drive_op_forward( d);
}

/*
 * State 3:  [retreating]
 */
static void sumo_navigate_act3( sumo_navigate *, const Escher_xtUMLEvent_t * const );
static void
sumo_navigate_act3( sumo_navigate * self, const Escher_xtUMLEvent_t * const event )
{
  sumo_steering * s; /* s (steering) */
sumo_drive * d; /* d (drive) */
Escher_xtUMLEvent_t * e;  /* e */
Escher_Timer_t * t;
  /* SELECT one s RELATED BY self->steering[R1] */
  ROX_BPAL_STMT_TRACE( 1, "SELECT one s RELATED BY self->steering[R1]" )
  s = self->steering_R1;
  /* GENERATE steering3:straight() TO s */
  ROX_BPAL_STMT_TRACE( 1, "GENERATE steering3:straight() TO s" )
  {
  Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( s, &sumo_steeringevent3c );
  Escher_SendEvent( e );
  }
  /* SELECT one d RELATED BY self->drive[R2] */
  ROX_BPAL_STMT_TRACE( 1, "SELECT one d RELATED BY self->drive[R2]" )
  d = self->drive_R2;
  /* d.reverse() */
  ROX_BPAL_STMT_TRACE( 1, "d.reverse()" )
  sumo_drive_op_reverse( d);
  /* CREATE EVENT INSTANCE e(  ) TO self */
  ROX_BPAL_STMT_TRACE( 1, "CREATE EVENT INSTANCE e(  ) TO self" )
  e = Escher_NewxtUMLEvent( (void *) self, &sumo_navigateevent1c );
  /* ASSIGN t = TIM::timer_start(event_inst:e, microseconds:( self.retreat_duration * 1000000 )) */
  ROX_BPAL_STMT_TRACE( 1, "ASSIGN t = TIM::timer_start(event_inst:e, microseconds:( self.retreat_duration * 1000000 ))" )
  t = TIM_timer_start( (Escher_xtUMLEvent_t *)e, ( self->retreat_duration * 1000000 ) );
}

/*
 * State 4:  [targeting]
 */
static void sumo_navigate_act4( sumo_navigate *, const Escher_xtUMLEvent_t * const );
static void
sumo_navigate_act4( sumo_navigate * self, const Escher_xtUMLEvent_t * const event )
{
  sumo_drive * d; /* d (drive) */
sumo_steering * s; /* s (steering) */
Escher_xtUMLEvent_t * e;  /* e */
Escher_Timer_t * t;
  /* SELECT one d RELATED BY self->drive[R2] */
  ROX_BPAL_STMT_TRACE( 1, "SELECT one d RELATED BY self->drive[R2]" )
  d = self->drive_R2;
  /* d.stop() */
  ROX_BPAL_STMT_TRACE( 1, "d.stop()" )
  sumo_drive_op_stop( d);
  /* SELECT one s RELATED BY self->steering[R1] */
  ROX_BPAL_STMT_TRACE( 1, "SELECT one s RELATED BY self->steering[R1]" )
  s = self->steering_R1;
  /* GENERATE steering1:left() TO s */
  ROX_BPAL_STMT_TRACE( 1, "GENERATE steering1:left() TO s" )
  {
  Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( s, &sumo_steeringevent1c );
  Escher_SendEvent( e );
  }
  /* CREATE EVENT INSTANCE e(  ) TO self */
  ROX_BPAL_STMT_TRACE( 1, "CREATE EVENT INSTANCE e(  ) TO self" )
  e = Escher_NewxtUMLEvent( (void *) self, &sumo_navigateevent1c );
  /* ASSIGN t = TIM::timer_start(event_inst:e, microseconds:5000000) */
  ROX_BPAL_STMT_TRACE( 1, "ASSIGN t = TIM::timer_start(event_inst:e, microseconds:5000000)" )
  t = TIM_timer_start( (Escher_xtUMLEvent_t *)e, 5000000 );
}

const Escher_xtUMLEventConstant_t sumo_navigateevent1c = {
  sumo_DOMAIN_ID, sumo_navigate_CLASS_NUMBER, SUMO_NAVIGATEEVENT1NUM,
  ESCHER_IS_INSTANCE_EVENT };

const Escher_xtUMLEventConstant_t sumo_navigateevent2c = {
  sumo_DOMAIN_ID, sumo_navigate_CLASS_NUMBER, SUMO_NAVIGATEEVENT2NUM,
  ESCHER_IS_INSTANCE_EVENT };

const Escher_xtUMLEventConstant_t sumo_navigateevent3c = {
  sumo_DOMAIN_ID, sumo_navigate_CLASS_NUMBER, SUMO_NAVIGATEEVENT3NUM,
  ESCHER_IS_INSTANCE_EVENT };

const Escher_xtUMLEventConstant_t sumo_navigateevent4c = {
  sumo_DOMAIN_ID, sumo_navigate_CLASS_NUMBER, SUMO_NAVIGATEEVENT4NUM,
  ESCHER_IS_INSTANCE_EVENT };



/*
 * State-Event Matrix (SEM)
 * Row index is object (MC enumerated) current state.
 * Row zero is the unitialized state (e.g., for creation event transitions).
 * Column index is (MC enumerated) state machine events.
 */
static const Escher_SEMcell_t sumo_navigate_StateEventMatrix[ 4 + 1 ][ 4 ] = {
  /* row 0:  uninitialized state (for creation events) */
  { EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN },
  /* row 1:  sumo_navigate_STATE_1 (resting) */
  { sumo_navigate_STATE_2, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED },
  /* row 2:  sumo_navigate_STATE_2 (attacking) */
  { EVENT_IS_IGNORED, sumo_navigate_STATE_3, EVENT_IS_IGNORED, EVENT_IS_IGNORED },
  /* row 3:  sumo_navigate_STATE_3 (retreating) */
  { sumo_navigate_STATE_4, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED },
  /* row 4:  sumo_navigate_STATE_4 (targeting) */
  { sumo_navigate_STATE_2, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED }
};

  /*
   * Array of pointers to the class state action procedures.
   * Index is the (MC enumerated) number of the state action to execute.
   */
  static const StateAction_t sumo_navigate_acts[ 5 ] = {
    (StateAction_t) 0,
    (StateAction_t) sumo_navigate_act1,  /* resting */
    (StateAction_t) sumo_navigate_act2,  /* attacking */
    (StateAction_t) sumo_navigate_act3,  /* retreating */
    (StateAction_t) sumo_navigate_act4  /* targeting */
  };

  /*
   * Array of string names of the state machine names.
   * Index is the (MC enumerated) number of the state.
   */
  static const c_t * const state_name_strings[ 5 ] = {
    "",
    "resting",
    "attacking",
    "retreating",
    "targeting"
  };

/*
 * instance state machine event dispatching
 */
void
sumo_navigate_Dispatch( Escher_xtUMLEvent_t * event )
{
  Escher_iHandle_t instance = GetEventTargetInstance( event );
  Escher_EventNumber_t event_number = GetOoaEventNumber( event );
  Escher_StateNumber_t current_state;
  Escher_StateNumber_t next_state;
  
  if ( 0 != instance ) {
    current_state = instance->current_state;
    if ( current_state > 4 ) {
      /* instance validation failure (object deleted while event in flight) */
      UserEventNoInstanceCallout( event_number )
    } else {
      next_state = sumo_navigate_StateEventMatrix[ current_state ][ event_number ];
      if ( next_state <= 4 ) {
        STATE_TXN_START_TRACE( "navigate", current_state, state_name_strings[ current_state ] )
        /* Execute the state action and update the current state.  */
        ( *sumo_navigate_acts[ next_state ] )( instance, event );
        STATE_TXN_END_TRACE( "navigate", next_state, state_name_strings[ next_state ] )
        instance->current_state = next_state;
      } else if ( next_state == EVENT_IS_IGNORED ) {
          /* event ignored */
          STATE_TXN_IG_TRACE( "navigate", current_state )
      } else {
        /* empty else */
      }
    }
  }
}


