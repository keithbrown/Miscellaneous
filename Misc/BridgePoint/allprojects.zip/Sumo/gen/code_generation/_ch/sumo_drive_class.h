/*----------------------------------------------------------------------------
 * File:  sumo_drive_class.h
 *
 * Class:       drive  (drive)
 * Component:   sumo
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef SUMO_DRIVE_CLASS_H
#define SUMO_DRIVE_CLASS_H

#ifdef	__cplusplus
extern "C" {
#endif

/*
 * Structural representation of application analysis class:
 *   drive  (drive)
 */
struct sumo_drive {

  /* application analysis class attributes */
  i_t speed;  /* - speed */

  /* relationship storage */
  /* Note:  No storage needed for drive->navigate[R2] */
};

#define sumo_drive_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_sumo_drive_extent;
extern void sumo_drive_op_forward( sumo_drive * );
extern void sumo_drive_op_reverse( sumo_drive * );
extern void sumo_drive_op_stop( sumo_drive * );

extern void sumo_drive_R2_Link( sumo_navigate *, sumo_drive * );
/* Note:  navigate<-R2->drive unrelate accessor not needed */


#ifdef	__cplusplus
}
#endif

#endif  /* SUMO_DRIVE_CLASS_H */


