/*----------------------------------------------------------------------------
 * File:  sumo_dom_init.h
 *
 * Initialization services for the following domain:
 * Component:  sumo
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef SUMO_DOM_INIT_H
#define SUMO_DOM_INIT_H

#ifdef	__cplusplus
extern "C" {
#endif

extern Escher_Extent_t * const sumo_class_info[];
extern const EventTaker_t sumo_EventDispatcher[];
extern void sumo_dom_init( void );

#ifdef	__cplusplus
}
#endif

#endif  /* SUMO_DOM_INIT_H */
