/*----------------------------------------------------------------------------
 * File:  Test_TestCase1_class.c
 *
 * Class:       TestCase1  (TestCase1)
 * Component:   Test
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#include "sys_types.h"
#include "TIM_bridge.h"
#include "ARCH_bridge.h"
#include "LOG_bridge.h"
#include "Test_functions.h"
/*
 * Statically allocate space for the instance population for this class.
 * Allocate space for the class instance and its attribute values.
 * Depending upon the collection scheme, allocate containoids (collection
 * nodes) for gathering instances into free and active extents.
 */
static Escher_SetElement_s Test_TestCase1_container[ Test_TestCase1_MAX_EXTENT_SIZE ];
static Test_TestCase1 Test_TestCase1_instances[ Test_TestCase1_MAX_EXTENT_SIZE ];
Escher_Extent_t pG_Test_TestCase1_extent = {
  {0}, {0}, &Test_TestCase1_container[ 0 ],
  (Escher_iHandle_t) &Test_TestCase1_instances,
  sizeof( Test_TestCase1 ), Test_TestCase1_STATE_1, Test_TestCase1_MAX_EXTENT_SIZE
  };


/*----------------------------------------------------------------------------
 * State and transition action implementations for the following class:
 *
 * Class:      TestCase1  (TestCase1)
 * Component:  Test
 *--------------------------------------------------------------------------*/

/*
 * State 3:  [sendLineDetected]
 */
static void Test_TestCase1_act3( Test_TestCase1 *, const Escher_xtUMLEvent_t * const );
static void
Test_TestCase1_act3( Test_TestCase1 * self, const Escher_xtUMLEvent_t * const event )
{
  Escher_xtUMLEvent_t * step;  /* step */
Escher_Timer_t * timer;
  /* platform::lineDetected() */
  ROX_BPAL_STMT_TRACE( 1, "platform::lineDetected()" )
  Test_IO_lineDetected();
  /* CREATE EVENT INSTANCE step(  ) TO self */
  ROX_BPAL_STMT_TRACE( 1, "CREATE EVENT INSTANCE step(  ) TO self" )
  step = Escher_NewxtUMLEvent( (void *) self, &Test_TestCase1event6c );
  /* ASSIGN timer = TIM::timer_start(event_inst:step, microseconds:5000000) */
  ROX_BPAL_STMT_TRACE( 1, "ASSIGN timer = TIM::timer_start(event_inst:step, microseconds:5000000)" )
  timer = TIM_timer_start( (Escher_xtUMLEvent_t *)step, 5000000 );
}

/*
 * State 4:  [final]
 */
static void Test_TestCase1_act4( Test_TestCase1 *, const Escher_xtUMLEvent_t * const );
static void
Test_TestCase1_act4( Test_TestCase1 * self, const Escher_xtUMLEvent_t * const event )
{
  /* platform::touchLeft() */
  ROX_BPAL_STMT_TRACE( 1, "platform::touchLeft()" )
  Test_IO_touchLeft();
}

/*
 * State 1:  [idle]
 */
static void Test_TestCase1_act1( Test_TestCase1 *, const Escher_xtUMLEvent_t * const );
static void
Test_TestCase1_act1( Test_TestCase1 * self, const Escher_xtUMLEvent_t * const event )
{
}

/*
 * State 2:  [delaying]
 */
static void Test_TestCase1_act2( Test_TestCase1 *, const Escher_xtUMLEvent_t * const );
static void
Test_TestCase1_act2( Test_TestCase1 * self, const Escher_xtUMLEvent_t * const event )
{
  Escher_xtUMLEvent_t * step;  /* step */
Escher_Timer_t * timer;
  /* CREATE EVENT INSTANCE step(  ) TO self */
  ROX_BPAL_STMT_TRACE( 1, "CREATE EVENT INSTANCE step(  ) TO self" )
  step = Escher_NewxtUMLEvent( (void *) self, &Test_TestCase1event6c );
  /* ASSIGN timer = TIM::timer_start(event_inst:step, microseconds:3000000) */
  ROX_BPAL_STMT_TRACE( 1, "ASSIGN timer = TIM::timer_start(event_inst:step, microseconds:3000000)" )
  timer = TIM_timer_start( (Escher_xtUMLEvent_t *)step, 3000000 );
}

const Escher_xtUMLEventConstant_t Test_TestCase1event6c = {
  Test_DOMAIN_ID, Test_TestCase1_CLASS_NUMBER, TEST_TESTCASE1EVENT6NUM,
  ESCHER_IS_INSTANCE_EVENT };

const Escher_xtUMLEventConstant_t Test_TestCase1event8c = {
  Test_DOMAIN_ID, Test_TestCase1_CLASS_NUMBER, TEST_TESTCASE1EVENT8NUM,
  ESCHER_IS_INSTANCE_EVENT };



/*
 * State-Event Matrix (SEM)
 * Row index is object (MC enumerated) current state.
 * Row zero is the unitialized state (e.g., for creation event transitions).
 * Column index is (MC enumerated) state machine events.
 */
static const Escher_SEMcell_t Test_TestCase1_StateEventMatrix[ 4 + 1 ][ 2 ] = {
  /* row 0:  uninitialized state (for creation events) */
  { EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN },
  /* row 1:  Test_TestCase1_STATE_1 (idle) */
  { EVENT_CANT_HAPPEN, Test_TestCase1_STATE_2 },
  /* row 2:  Test_TestCase1_STATE_2 (delaying) */
  { Test_TestCase1_STATE_3, EVENT_CANT_HAPPEN },
  /* row 3:  Test_TestCase1_STATE_3 (sendLineDetected) */
  { Test_TestCase1_STATE_4, EVENT_CANT_HAPPEN },
  /* row 4:  Test_TestCase1_STATE_4 (final) */
  { EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN }
};

  /*
   * Array of pointers to the class state action procedures.
   * Index is the (MC enumerated) number of the state action to execute.
   */
  static const StateAction_t Test_TestCase1_acts[ 5 ] = {
    (StateAction_t) 0,
    (StateAction_t) Test_TestCase1_act1,  /* idle */
    (StateAction_t) Test_TestCase1_act2,  /* delaying */
    (StateAction_t) Test_TestCase1_act3,  /* sendLineDetected */
    (StateAction_t) Test_TestCase1_act4  /* final */
  };

  /*
   * Array of string names of the state machine names.
   * Index is the (MC enumerated) number of the state.
   */
  static const c_t * const state_name_strings[ 5 ] = {
    "",
    "idle",
    "delaying",
    "sendLineDetected",
    "final"
  };

/*
 * instance state machine event dispatching
 */
void
Test_TestCase1_Dispatch( Escher_xtUMLEvent_t * event )
{
  Escher_iHandle_t instance = GetEventTargetInstance( event );
  Escher_EventNumber_t event_number = GetOoaEventNumber( event );
  Escher_StateNumber_t current_state;
  Escher_StateNumber_t next_state;
  
  if ( 0 != instance ) {
    current_state = instance->current_state;
    if ( current_state > 4 ) {
      /* instance validation failure (object deleted while event in flight) */
      UserEventNoInstanceCallout( event_number )
    } else {
      next_state = Test_TestCase1_StateEventMatrix[ current_state ][ event_number ];
      if ( next_state <= 4 ) {
        STATE_TXN_START_TRACE( "TestCase1", current_state, state_name_strings[ current_state ] )
        /* Execute the state action and update the current state.  */
        ( *Test_TestCase1_acts[ next_state ] )( instance, event );
        STATE_TXN_END_TRACE( "TestCase1", next_state, state_name_strings[ next_state ] )

        /* Self deletion state transition? */
        if ( next_state == Test_TestCase1_STATE_4 ) {          Escher_DeleteInstance( instance, Test_DOMAIN_ID, Test_TestCase1_CLASS_NUMBER );
        } else {
          instance->current_state = next_state;
        }
      } else if ( next_state == EVENT_CANT_HAPPEN ) {
          /* event cant happen */
          UserEventCantHappenCallout( current_state, next_state, event_number )
          STATE_TXN_CH_TRACE( "TestCase1", current_state )
      } else {
        /* empty else */
      }
    }
  }
}


