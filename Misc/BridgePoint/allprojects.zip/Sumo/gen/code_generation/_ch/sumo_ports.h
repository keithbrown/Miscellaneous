/*----------------------------------------------------------------------------
 * File:  sumo_ports.h"
 *
 * UML Port Messages (Operations and Signals)
 *
 * (C) Copyright 1998-2010 Mentor Graphics Corporation.  All rights reserved.
 *--------------------------------------------------------------------------*/

#ifndef SUMO_PORTS_H
#define SUMO_PORTS_H

#ifdef	__cplusplus
extern "C" {
#endif

extern void sumo_IO_lineDetected( void );
extern void sumo_IO_touchLeft( void );
extern void sumo_IO_init( void );
extern void sumo_IO_touchRight( void );
extern void sumo_IO_go( s2_t );
extern void sumo_IO_turn( s2_t );
extern void sumo_IO_setName( c_t[ESCHER_SYS_MAX_STRING_LEN] );


#ifdef	__cplusplus
}
#endif

#endif  /* SUMO_PORTS_H */
